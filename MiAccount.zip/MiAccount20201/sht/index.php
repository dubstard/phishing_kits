<?php

   (include 'redir.html');
		exit();

?>