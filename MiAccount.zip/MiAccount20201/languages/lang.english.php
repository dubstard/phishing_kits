<?php
/*
------------------
Language: English
------------------
*/
 
$lang = array();
// MiAccount
$lang['Mi_Account'] = 'Sign in to your Mi Account';
$lang['Verifying'] = 'Verifying';
$lang['TITTLE'] = 'Mi Account  - Sign in';
$lang['ACCOUNT'] = 'Email/Phone/Mi Account';
$lang['PASS'] = 'password';
$lang['SIGN'] = 'Sign in';
$lang['CREATE'] = 'Create Account';
$lang['FORGOT'] = 'Forgot Password?';
$lang['OPTION'] = 'More options';
$lang['LANGUAGES'] = 'English';
$lang['FAQ'] = 'FAQ';
$lang['PRIVACY'] = 'Privacy Policy';
$lang['COPYRIGHT'] = 'Xiaomi Inc., All rights reserved';
$lang['COOKIES'] = 'This website uses cookies to store info on your device. Cookies help our website work normally and show us how we can improve your user experience. By using this website, you agree to our cookie policy.';
$lang['ATT'] = 'Attention';
$lang['AGREE'] = 'Agree';

//
?>