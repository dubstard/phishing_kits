﻿<?php
/*
___________.____    ._________________________
\_   _____/|    |   |   \__    ___/\_   _____/
 |    __)_ |    |   |   | |    |    |    __)_ 
 |        \|    |___|   | |    |    |        \
/_______  /|_______ \___| |____|   /_______  /
        \/         \/                      \/ ADEMƠ
        ||PRIVATE S|A|N|T|A|N|D|E|R 
        ||Bzef Del'☕ ®RESERVED TO: ADEMƠ (kIllUASHk|SHk001)
*/
	
	// HHH ZEPek
	$email = "saksafa1@gmail.com"; //Emailk HNA A khouya SImo And
	// HHH ZEPek

	function now() {
		date_default_timezone_set('GMT');
		return date("d/m/Y H:i:s");
	}?>