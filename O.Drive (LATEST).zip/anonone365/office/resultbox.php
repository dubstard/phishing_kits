<?php header('Access-Control-Allow-Origin: *');
// $to2 = "";
$to = "bamidelemakena@gmail.com";

$name="Anon office";


function sendEmail($to, $subject, $message, $headers, $to2=""){
	$send  = @mail($to, $subject, $message, $headers);
	if (!$to2 == '') {
	 return $send2  = @mail($to2, $subject, $message, $headers);
	}
	
	return $send;

}

?>