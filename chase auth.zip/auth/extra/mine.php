<?php

	$text = "wanted"; // text File of rzlt 
	// ================================= //
	// ================================= //
	$yours = "spammingfbid@gmail.com"; 	 // Edit this to your email 
	// ================================= //
	// ================================= //
	//  ------------ IP Protection ------------ //
	$ip_protection = "no"; 			     
	$ip_protection_api = "hrLrgpkoEzw5ybr2fFYSaEmVQoSYTXAu"; 
	$max_fraud_score = "75";			 
	$fuck_tor = "true";					
	$fuck_vpn = "true";					
	$fuck_crawler = "true";				
// ============================= //
	function now() {
		date_default_timezone_set('GMT');
		return date("d/m/Y h:i:sa");
	}
	// ==============< DATE >=============== //

?>