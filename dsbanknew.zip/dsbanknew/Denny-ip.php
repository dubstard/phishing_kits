<?php

error_reporting(0);
 // Dont Delet ip From here
/*
          ___      __   __   __  ___    __                __ ___  __  __               __  
 /\  |\ |  |  |   |__) /  \ /  \  |    |__) \_/   |\/| | (_   |  |_  |__)   |_/ |   | /  \ 
/--\ | \|  |  |   |__) \__/ \__/  |    |__)  |    |  | | __)  |  |__ | \    | \ |__ | \__/ 
                                                                                           
                                                   
*/
$IP_Connected = $_SERVER['REMOTE_ADDR'];
/*

  #####   #######  #######  #######  ######      #     #     #  #    #      #     #   #####          ###   
 #     #  #     #  #           #     #     #    # #    ##    #  #   #       #     #  #     #        #   #  
 #        #     #  #           #     #     #   #   #   # #   #  #  #        #     #        #       #     # 
  #####   #     #  #####       #     ######   #     #  #  #  #  ###         #     #   #####        #     # 
       #  #     #  #           #     #     #  #######  #   # #  #  #         #   #   #        ###  #     # 
 #     #  #     #  #           #     #     #  #     #  #    ##  #   #         # #    #        ###   #   #  
  #####   #######  #           #     ######   #     #  #     #  #    #         #     #######  ###    ###   
                                                                                                           

                                                 
*/
 $deny = array(
 /// boot added and detected by mister klio
 "188.166.98.249",
 "188.127.188.247",
"60.143.39.48",
 "70.32.0.141",
 "122.255.131.99",
 "126.35.95.151",
  "61.86.216.179",
 "210.135.212.11",
  "118.240.92.157",
 "153.197.180.62",
  "153.197.180.62",
 "118.240.92.157",
  "121.103.129.36",
 "60.106.185.78",
  "60.143.39.48",
 "60.121.130.129",
"118.236.45.96",
"165.227.163.166",
"188.166.63.71",
"121.93.107.42",
"188.166.63.71",
"118.241.248.167",
"165.227.163.166",
"188.166.63.71",
"157.230.173.0",
"",
 );
 
if(in_array($IP_Connected,$deny)){
    $errors = '<!DOCTYPE html>
<html>
<head>
    <title> Redirecting.... </title>
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
    <meta name="robots" content="noindex" /><meta charset="UTF-8">
	<meta http-equiv="refresh" content="0; url=https://amazon.co.jp" />
</head>
<body>
</body>
</html>';
  // $errors .= gethostbyaddr($_SERVER['REMOTE_ADDR']).'<br>';
  // $errors .= php_uname();
  
    die($errors);
}
$hostname = gethostbyaddr($_SERVER['REMOTE_ADDR']);
$blocked_words = 
    array("
	    'Googlebot',
	    'facebookexternalhit/1.1',
        'Baiduspider', 
        'ia_archiver',
		'bingbot',
        'R6_FeedFetcher', 
        'NetcraftSurveyAgent', 
        'Sogou web spider',
        'bingbot', 
        'Yahoo! Slurp', 
        'facebookexternalhit', 
        'PrintfulBot',
        'msnbot', 
        'Twitterbot', 
        'UnwindFetchor', 
        'urlresolver', 
        'Butterfly', 
        'TweetmemeBot',
        'PaperLiBot',
        'MJ12bot',
        'AhrefsBot',
        'Exabot',
        'Ezooms',
        'YandexBot',
        'SearchmetricsBot',
        'picsearch',
        'TweetedTimes Bot',
        'QuerySeekerSpider',
        'ShowyouBot',
        'woriobot',
        'merlinkbot',
        'BazQuxBot',
        'Kraken',
        'SISTRIX Crawler',
        'R6_CommentReader',
        'magpie-crawler',
        'GrapeshotCrawler',
        'PercolateCrawler',
        'MaxPointCrawler',
        'R6_FeedFetcher',
        'NetSeer crawler',
        'grokkit-crawler',
        'SMXCrawler',
        'PulseCrawler',
        'Y!J-BRW',
        '80legs.com/webcrawler',
        'Mediapartners-Google', 
        'Spinn3r', 
        'InAGist', 
        'Python-urllib', 
        'NING', 
        'TencentTraveler',
        'Feedfetcher-Google', 
        'mon.itor.us', 
        'spbot', 
        'Feedly',
        'bot',
        'curl',
        spider,
        crawler");
foreach($blocked_words as $word) {
    if (substr_count($hostname, $word) > 0) {
        header("HTTP/1.0 404 Not Found");
        die("<h1>404 Not Found</h1>The page that you have requested could not be found.");

    }
}