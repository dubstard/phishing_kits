(function(f) {
    f.execute(function() {
        f.register("AmazonHelpPopup", function() {
            return function(a, c, b) {
                window.open(a, c, b).focus();
                return !1
            }
        });
        f.when("A", "ready").execute(function(a) {
            a.$(".auth-autofocus").first().focus()
        });
        f.when("A", "ready").register("auth-ango-form", function(a) {
            function c(b, d) {
                b.removeClass("ap_ango_default ap_ango_phone").addClass("ap_ango_email");
                d.addClass("auth-require-email-validaton")
            }

            function b(b, d) {
                b.removeClass("ap_ango_phone ap_ango_email").addClass("ap_ango_default");
                d.removeClass("auth-require-email-validaton")
            }

            function e(a) {
                a.jquery || (a = d(a));
                var e = a[0].value,
                    j = d(a[0].form);
                e ? e && e.indexOf("@") > -1 ? c(j, a) : m.test(e) ? (j.removeClass("ap_ango_default ap_ango_email").addClass("ap_ango_phone"), f.removeClass("auth-require-email-validaton")) : b(j, a) : b(j, a)
            }
            var d = a.$,
                m = /^\+?[()\s.0-9-]*$/,
                a = d("#ap_register_form");
            d("#auth-register-sms-marketing-checkbox").prop("disabled", !1);
            if (a.attr("data-enable-mobile-account-js")) {
                var f = d("#auth-register-email, #ap_email");
                e(f);
                f.bind("focusout", function() {
                    e(this)
                }).bind("keyup focusin",
                    function() {
                        var a = this;
                        a.jquery || (a = d(a));
                        var e = a[0],
                            m = d(e.form);
                        e.value && e.value.indexOf("@") > -1 ? c(m, a) : b(m, a)
                    })
            }
        });
        f.when("A", "ready").execute(function(a) {
            function c() {
                location.href = e.returnToAddress
            }

            function b() {
                clearTimeout(d);
                d = setTimeout(c, m)
            }
            var e = a.state("timeout-parameters");
            if (e) {
                var d = 0,
                    m = e.timeoutValue;
                document.onmousemove = b;
                document.onkeypress = b;
                document.ontouchstart = b;
                document.ontouchmove = b;
                document.ontouchend = b;
                b()
            }
        });
        f.when("A", "auth-captcha-cf").register("auth-captcha", function(a) {
            function c() {
                var d =
                    b("#auth-captcha-image").attr("data-refresh-url");
                d || f.log("Attempting to instantiate Captcha without a valid refresh url.", "FATAL", "auth-captcha");
                return d
            }
            var b = a.$,
                e = /^(http|https):\/\//,
                d = {
                    cache: !1,
                    timeout: 700,
                    error: function() {
                        f.log("Failed to refresh CAPTCHA due to error response from server", "FATAL", "auth-captcha");
                        window.location.reload(!0)
                    },
                    success: function(d) {
                        !d || !d.captchaImageUrl || !e.test(d.captchaImageUrl) ? (f.log("Failed to load new CAPTCHA due to invalid response from server", "FATAL",
                            "auth-captcha"), window.location.reload(!0)) : (b("#auth-captcha-image").attr("src", d.captchaImageUrl), b("input[type='hidden'][name='ces']").val(d.cesString))
                    }
                };
            b("#auth-captcha-image").load(function() {
                b("#auth-captcha-noop-link").hide();
                b("#auth-captcha-refresh-link").show();
                b("#auth-captcha-image-container").removeClass("a-lazy-loaded");
                b("#auth-captcha-image").fadeIn()
            });
            b(document).delegate("#auth-captcha-refresh-link", "click", function(e) {
                e.preventDefault();
                b("#auth-captcha-refresh-link").hide();
                b("#auth-captcha-noop-link").show();
                b("#auth-captcha-image").hide();
                b("#auth-captcha-image-container").addClass("a-lazy-loaded");
                e = c();
                a.ajax(e, d)
            });
            return {
                URL_REGEX: e,
                getRefreshUrl: c
            }
        });
        f.when("A").register("auth-cookie", function(a) {
            function c(d, b, c) {
                if (d) {
                    var e = "";
                    a.isFiniteNumber(c) && (c < 0 ? e = "; expires=Thu, 01 Jan 1970 00:00:00 GMT" : (e = new Date, e.setDate(e.getDate() + c), e = "; expires=" + e.toGMTString()));
                    document.cookie = d + "=" + window.encodeURIComponent(b) + e;
                    return !0
                }
                return !1
            }

            function b(d) {
                if (document.cookie.length >
                    0 && d) {
                    var b = document.cookie.indexOf(d + "=");
                    if (b > -1) {
                        b = b + d.length + 1;
                        d = document.cookie.indexOf(";", b);
                        if (d === -1) d = document.cookie.length;
                        return window.decodeURIComponent(document.cookie.substring(b, d))
                    }
                }
                return ""
            }

            function e(b) {
                c(b, "", -1)
            }
            return {
                setCookie: c,
                getCookieValue: b,
                deleteCookie: e,
                checkCookieEnabled: function(d) {
                    c("amznTest", "1");
                    var a = b("amznTest");
                    if (a) e("amznTest");
                    else if (d) document.getElementById(d).style.display = "block";
                    return !!a
                }
            }
        });
        f.when("A", "ready").register("auth-pv-resend", function(a) {
            var c =
                a.state("auth-pv-page-state");
            if (c) {
                var b = a.$,
                    e = b("#auth-pv-client-side-success-box"),
                    d = b(".auth-pv-client-side-success-messages li"),
                    f = b("#auth-pv-client-side-error-box"),
                    i = b(".auth-pv-client-side-error-messages li"),
                    k = b(".auth-server-side-message-box"),
                    g = b("#auth-resend-code-succeeded"),
                    j = b("#auth-there-was-an-error-throttled"),
                    o = b("#auth-there-was-an-error"),
                    n = function() {
                        g.show();
                        e.show()
                    },
                    l = function(b) {
                        b.http.status === 403 ? window.location = c.sessionTimeoutUrl : ((b.http.response || "").search("Throttled") >=
                            0 ? j.show() : o.show(), f.show())
                    };
                b("#auth-resend-code-link").click(function() {
                    e.hide();
                    d.hide();
                    f.hide();
                    i.hide();
                    k.hide();
                    a.ajax(c.resendUrl, {
                        method: "post",
                        success: n,
                        error: l
                    })
                });
                return {
                    successHandler: n,
                    errorHandler: l
                }
            }
        });
        f.when("A").register("auto-verification-timeout", function(a) {
            var c = a.$,
                b = c("#auth-auto-verification-failed");
            b.length && a.delay(function() {
                b[0].click()
            }, 3E4)
        });
        f.when("A", "AmazonHelpPopup", "ready").execute(function(a, c) {
            a.$("#auth-amazon-help-link").click(function() {
                return c(this.href,
                    "AmazonHelp", "width=700,height=800,resizable=1,scrollbars=1,toolbar=1,status=1")
            })
        });
        f.when("A").execute(function(a) {
            a.declarative("auth-popup", "click", function(a) {
                var b = a.data,
                    a = a.$target.closest("a")[0];
                (b = window.open(a.href, a.target, b.windowOptions)) && b.focus()
            })
        });
        f.when("auth-cookie", "ready").execute(function(a) {
            a.checkCookieEnabled("auth-cookie-warning-message")
        });
        f.when("A", "ready").register("AuthToolkit", function(a) {
            function c(b) {
                typeof e(b) !== "undefined" && e(b).hasClass("a-button-disabled") &&
                    (e(b).removeClass("a-button-disabled"), e(b).find("input").attr("disabled", !1))
            }

            function b(d, f) {
                var i = e(d).find("input").data("remaining"),
                    k = e(d).find("input").data("unit");
                i === 0 ? (c(d), e(d).find(".a-button-text").text(f), a.trigger("AuthToolkit.countDownEnd", d)) : i > 0 && (e(d).find("input").data("remaining", i - 1), e(d).find(".a-button-text").text(k.replace(/%d/, i)), a.delay(function() {
                    b(d, f)
                }, 1E3))
            }
            var e = a.$;
            return {
                disableButton: function(b) {
                    typeof e(b) !== "undefined" && !e(b).hasClass("a-button-disabled") && (e(b).addClass("a-button-disabled"),
                        e(b).find("input").attr("disabled", "disabled"))
                },
                enableButton: c,
                countingDown: function(a) {
                    if (typeof e(a) !== "undefined") {
                        var c = e(a).find(".a-button-text").text();
                        e(a).find("input").data("remaining") > 0 && b(a, c)
                    }
                }
            }
        });
        f.when("A", "ready").execute(function(a) {
            var c = a.$("#auth-external-javascript").data("external-javascripts");
            c && c.length && a.each(c, function(b) {
                f.load.js(b)
            })
        });
        f.when("A", "a-modal", "auth-validate-form-handler", "ready").register("auth-phone-verification-modal", function(a, c, b) {
            function e() {
                var b =
                    k.val();
                n.text(b);
                var a = i.find("option:selected"),
                    b = a.data(l),
                    a = a.data(h);
                j.text(b);
                o.text(a)
            }
            var d = a.$,
                f = a.state("auth-phone-verification-modal");
            if (f) {
                var i = d("#auth-country-picker"),
                    k = d("#ap_phone_number"),
                    g = d("#" + f.formIdToBindTo),
                    j = d("#auth-verify-mobile-calling-code"),
                    o = d("#auth-verify-mobile-country-code"),
                    n = d("#auth-verify-mobile-national-number"),
                    l = "calling-code",
                    h = "country-code";
                i.change(e);
                k.change(e);
                e();
                d(".auth-requires-verify-modal").click(function(a) {
                    a.preventDefault();
                    b.validate(g) &&
                        (a = d("#auth-verify-modal-action"), (a = c.get(a)) && k.is(":enabled") ? a.show() : g.submit())
                });
                a.declarative("auth-verify-modal-complete", "click", function() {
                    g.submit()
                });
                return {
                    updateVerificationModalContents: e
                }
            }
        });
        f.when("A", "a-form-controls-api", "ready").register("auth-signup", function(a, c) {
            var b = a.$;
            b("#ap_use_mobile,#ap_use_email").click(function() {
                b(".ap_email_fields,.ap_mobile_number_fields").toggle();
                b("#ap_email, #ap_phone_number, #auth-country-picker").prop("disabled", function(b, a) {
                    return !a
                });
                b("#auth-country-picker-container").toggleClass("a-button-disabled");
                b("#ap_email, #ap_phone_number").parent(".a-input-text-wrapper").toggleClass("a-form-disabled");
                var a = b("input[name=smsMarketingConsent]"),
                    d = b("#auth-sms-marketing-checkbox-container");
                c.setCheckboxState(d, a.is(":checked"), !a.is(":disabled"));
                return !1
            })
        });
        f.when("A", "ready").register("auth-validate-form-handler", function(a) {
            function c(b) {
                return !b ? void 0 : "input:enabled." + b + ", ." + b + " input:enabled"
            }

            function b(b, a, d) {
                var c = b.data("validation-id") || b.parent().data("validation-id") || b[0].name;
                c && (h || (h = {}), h[c] || (h[c] = []), h[c].push({
                    $field: b,
                    type: a,
                    extension: d
                }))
            }

            function e(a) {
                a.find(".auth-require-fields-match-group").each(function() {
                    var a = g(this).find(c("auth-require-fields-match"));
                    if (a.length > 1) {
                        var d = a.eq(0),
                            a = a.eq(1),
                            e = d.val(),
                            f = a.val();
                        e && f && e !== f && (b(d, "Check Mismatch", "-mismatch-alert"), b(a, "Check Mismatch"))
                    }
                })
            }

            function d(a) {
                a.find(c("auth-require-email-validaton")).each(function() {
                    var a = g(this),
                        d = a.val();
                    d && !o.test(d) && b(a, "Invalid Email", "-invalid-email-alert")
                })
            }

            function f(a) {
                a.find(c("auth-require-phone-validation")).each(function() {
                    var a =
                        g(this),
                        d = a.val();
                    d && n.test(d) && b(a, "Invalid Phone", "-invalid-phone-alert")
                })
            }

            function i(a) {
                a.find(c("auth-required-field")).each(function() {
                    var a = g(this),
                        d = this.name;
                    a.val() || (!j.test(d) || !h || !h[d.split("Check")[0]]) && b(a, "Missing Required", "-missing-alert")
                })
            }

            function k(b) {
                var d = g("#auth-alert-window");
                b.find(".a-form-error").removeClass("a-form-error");
                g(".auth-error-messages li, .auth-server-side-message-box").hide();
                h ? (a.each(h, function(b, d) {
                    a.each(b, function(a) {
                        var b = a.$field,
                            a = a.extension,
                            c = b.closest(".a-input-text-wrapper");
                        c.length > 0 ? c.addClass("a-form-error") : b.addClass("a-form-error");
                        a && (b = "#auth-" + d + a, a = g(b + l), a.length ? a.show() : g(b).show())
                    })
                }), g("#message-box-slot").hide(), d.show(), b.find("a-form-error").first().focus()) : d.hide()
            }
            var g = a.$,
                j = /Check$/g,
                o = /^([a-zA-Z0-9_\.\-\+])+\@(([a-zA-Z0-9\-])+\.)+([a-zA-Z0-9]{2,4})+$/,
                n = /^ *\+|[a-zA-Z]/,
                l = "",
                h;
            return {
                validate: function(a) {
                    a = a && a.jquery ? a : g(a);
                    if (a.length && a.is("form")) {
                        l = a.hasClass("ap_ango_phone") ? "-ango-phone" : a.hasClass("ap_ango_email") ?
                            "-ango-email" : "";
                        i(a);
                        d(a);
                        f(a);
                        e(a);
                        k(a);
                        var b = !h;
                        a.data("auth-validation-errors", h);
                        h = void 0;
                        return b
                    }
                },
                getErrors: function(a) {
                    return (a.jquery ? a : g(a)).data("auth-validation-errors")
                },
                getSelectorForInputsOfErrorTypeClass: c
            }
        });
        f.when("A", "AuthToolkit", "ready").register("auth-3p-phone-verification", function(a, c) {
            var b = a.$,
                e = b("#auth-pv-enter-code");
            c.countingDown("#ap-3p-get-pin-code-button");
            a.on("AuthToolkit.countDownEnd", function(a) {
                "#ap-3p-get-pin-code-button" === a && (b("#auth-phone-number").removeClass("a-form-disabled"),
                    b("#auth-phone-number").attr("disabled", !1))
            });
            e.bind("change paste keyup", function() {
                b(this).val().length > 0 ? c.enableButton("#ap-3p-pv-create-account") : c.disableButton("#ap-3p-pv-create-account")
            });
            b("#auth-verify-button").click(function() {
                var a = b("#auth-3p-pv-form");
                a.find("#insisted").val("false");
                a.find("#getPinCodeAction").val("true");
                a.submit()
            })
        });
        f.when("A", "a-modal", "ready").register("ap-3p-pv-modal", function(a, c) {
            var b = a.$,
                e = a.state("ap-3p-pv-modal");
            if (e) {
                var d = e.thirdPartyPhoneConflict;
                if (d && d.toString() !== "None") {
                    var f = b("#" + e.formIdToBindTo),
                        b = b("#ap-3p-pv-modal-action");
                    (b = c.get(b)) && d && d.toString() !== "None" && b.show();
                    a.declarative("ap-3p-pv-modal-complete", "click", function() {
                        d && d.toString() === "WeChat" && (f.find("#insisted").val("true"), f.submit())
                    })
                }
            }
        });
        f.when("A", "a-modal", "ready").register("ap-3p-account-connected-modal", function(a, c) {
            var b = a.$,
                e = a.state("ap-3p-account-connected-modal");
            e && e.thirdPartyAccountStatus && e.thirdPartyAccountStatus === "rejectWithLoginIdIfConnected" &&
                (b = b("#ap-3p-account-connected-modal-action"), (b = c.get(b)) && b.show())
        });
        f.when("A").execute(function(a) {
            function c(b) {
                var c = a.state("mshop_v2_registration_info");
                c && c.enabled && a.get("/ap/nocontent/ref=" + b + "_" + c.device, {})
            }
            a.$("#ap_use_email").click(function() {
                c("ap_mmoar_usee")
            });
            a.$("#ap_use_mobile").click(function() {
                c("ap_mmoar_usem")
            });
            a.$("#auth-country-picker-container").click(function() {
                c("ap_mmoar_ccp")
            });
            a.$("#continue").click(function() {
                c("ap_mmoar_cont")
            });
            a.on("a:popover:show:verifyContinueModal",
                function() {
                    c("ap_mmoar_vm_o")
                });
            a.on("a:popover:hide:verifyContinueModal", function() {
                c("ap_mmoar_vm_c")
            });
            a.$("#auth-verification-ok-announce").click(function() {
                c("ap_mmoar_vm_ok")
            });
            a.$("#auth-already-have-account").click(function() {
                c("ap_mmoar_signin")
            });
            a.$("#auth-verify-button").click(function() {
                c("ap_mmoar_pv_verify")
            });
            a.$("#auth-resend-code-link").click(function() {
                c("ap_mmoar_pv_resend")
            })
        });
        f.when("A", "jQuery", "ready").register("wechat-wxlogin-js", function(a, c) {
            if (c("#auth-wechat-login-container").length >
                0) {
                var b = c("#auth-wechat-login-container").data("wechatUrl");
                f.load.js(b)
            }
        });
        f.when("A", "jQuery", "wechat-wxlogin-js", "ready").register("wechat-qrcode-module", function(a, c) {
            if (c("#auth-wechat-login-container").length > 0) {
                var b = function() {
                        var a = c("div#auth-interactive-dialog-content"),
                            b = c("div#auth-wechat-qrcode-loading-container").clone();
                        b.removeClass("hidden");
                        b.appendTo(a);
                        c("div#auth-interactive-dialog").css("display", "table");
                        var e = c("#auth-wechat-login-container"),
                            a = e.data("appid"),
                            b = e.data("scope"),
                            f = e.data("redirectUrl"),
                            g = e.data("state"),
                            e = e.data("style");
                        new window.WxLogin({
                            id: "auth-wechat-qrcode-container",
                            appid: a,
                            scope: b,
                            redirect_uri: f,
                            state: g,
                            style: e
                        })
                    },
                    e = function() {
                        var a = c("div#auth-interactive-dialog-content");
                        c("div#auth-interactive-dialog").css("display", "none");
                        a.empty()
                    };
                c("div#auth-interactive-dialog-content").click(function(a) {
                    a.stopImmediatePropagation()
                });
                c("#auth-wechat-login-container").click(function() {
                    b()
                });
                c("div#auth-interactive-dialog-container").click(function() {
                    e()
                });
                return {
                    showWeChatQRCode: b,
                    hideWeChatQRCode: e
                }
            }
        })
    })
})(function() {
    var f = window.AmazonUIPageJS || P,
        a = f.attributeErrors;
    return a ? a("AuthenticationPortalAssets") : f
}());