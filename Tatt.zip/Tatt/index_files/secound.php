
<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<title>Log in</title>
	<link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.8.2/css/all.css">
	<link rel="stylesheet" type="text/css" href="secound.css">
</head>
<body> <center>	<br><br><br><br><br><br><br><br>
 <center>
	 <img src="succ.png"style="width:350px; alt="User Icon"/>

		<h4>Your data has been successfully registered</h4></body>
<body>