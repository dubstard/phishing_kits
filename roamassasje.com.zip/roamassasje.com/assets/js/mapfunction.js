// Initialize and add the map
function initMap() {
  // The location of clinic
  var clinic = {lat: 59.946390, lng: 10.643789};
  // The map, centered at Uluru
  var map = new google.maps.Map(
      document.getElementById('map'), {zoom: 15, center: clinic, fullscreenControl: false, zoomControl: false, streetViewControl: false, mapTypeControl: false});
  // The marker, positioned at clinic
  var marker = new google.maps.Marker({position: clinic, map: map});
}