define('q2ngam/themejs/theme-q2',["exports"], function(__exports__) {
var themeJS = {
	/*Auto Created by Curly WM 2.0.7.4*/
	themeName : "theme-q2",
	cssName : "q2",
	lpColorMap : {
		"C" : "#7d9638",
		"S" : "#d99741",
		"L" : "#dd8862",
		"X" : "#a53326",
		"defaultColor" : "#a53326"
	},
	widgets : [{
			page : "dashboard",
			location : "bottom",
			orientation : "horizontal",
			devices : ["tablet", "desktop"],
			widgets : [{
					name : "AccountSummary"
				}
			]
		}, {
			page : "dashboard",
			location : "top",
			orientation : "horizontal",
			devices : ["desktop", "tablet"],
			widgets : [{
					name : "FullBannerAd"
				}
			]
		}, {
			page : "dashboard",
			location : "right",
			orientation : "vertical",
			widgets : [{
					name : "Stacked",
					widgets : [{
							name : "Transfer"
						}, {
							name : "Billpay",
							vendorId : 3
						},{
							name : "CustomLink",
							linkTitle : "Enroll in eStatements",
							linkedRoute : "/form/9"
						}
					]
				}, {
					name : "MediumAd"
				}, {
					name : "Approvals"
				}, {
					name : "RDC"
				}
			]
		}, {
			page : "commercial",
			location : "right",
			orientation : "vertical",
			widgets : [{
					name : "SmallAd",
					gravity : "above"
				}
			]
		}, {
			page : "template",
			location : "right",
			orientation : "vertical",
			widgets : [{
					name : "SmallAd",
					gravity : "above"
				}
			]
		}, {
			page : "recipient",
			location : "right",
			orientation : "vertical",
			widgets : [{
					name : "SmallAd",
					gravity : "above"
				}
			]
		}, {
			page : "transfer",
			location : "right",
			orientation : "vertical",
			widgets : [{
					name : "SmallAd",
					gravity : "above"
				}
			]
		}, {
			page : "billpay",
			location : "right",
			orientation : "vertical",
			widgets : [{
					name : "SmallAd",
					gravity : "above"
				}
			]
		}, {
			page : "rdc",
			location : "right",
			orientation : "vertical",
			widgets : [{
					name : "SmallAd",
					gravity : "above"
				}
			]
		}, {
			page : "news",
			location : "right",
			orientation : "vertical",
			widgets : [{
					name : "SmallAd",
					gravity : "above"
				}, {
					name : "Rates",
					gravity : "above"
				}
			]
		}, {
			page : "branches",
			location : "right",
			orientation : "vertical",
			widgets : [{
					name : "SmallAd",
					gravity : "above"
				}
			]
		}, {
			page : "messages",
			location : "top",
			orientation : "horizontal",
			devices : ["tablet", "desktop"],
			widgets : [{
					name : "BannerAd"
				}
			]
		}, {
			page : "messages",
			location : "right",
			orientation : "vertical",
			widgets : [{
					name : "SmallAd",
					gravity : "above"
				}
			]
		}, {
			page : "settings",
			location : "right",
			orientation : "vertical",
			widgets : [{
					name : "SmallAd",
					gravity : "above"
				}
			]
		}, {
			page : "approvals",
			location : "right",
			orientation : "vertical",
			widgets : [{
					name : "SmallAd",
					gravity : "above"
				}
			]
		}
	]
};
__exports__['default'] = themeJS;
});
