<?php
	

	// ================================= //

	$antibot = "rezvxv@protonmail.com";		// antibot 
	// ================================= //


	function oof() {
		date_default_timezone_set('GMT');
		return date("d/m/Y h:i:sa");
	}

?>