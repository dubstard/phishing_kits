var winArray = new Array();

//Postbacks the form by a given Dropdown list. 
//Sends the selected index as an argument.
function DoPostBack(aPageURL, AcctIndex, PageIndex) {
    var strAcctIndex = new String();
    strAcctIndex = AcctIndex;

    if (eval(strAcctIndex) > 0) {
        document.forms[0].action = aPageURL + "?AI=" + AcctIndex + "&PageIndex=" + PageIndex;
        document.forms[0].submit();
    }

}

// 2/22/2008 - Srinivas Lingampalli - WO# 53032: Added this new function which will post back to the self page when 
// Check image or deposit slip link is clicked.
function DoPostBackForCheckImage(pageSource, acctIndex, pageNumber, id) {
    if (pageSource == 'AA_AD') {
        document.forms[0].action = "AccountDetails.aspx?PageSource=" + pageSource + "&AI=" + acctIndex + "&PageIndex=" + pageNumber + "&Id=" + id;
    }
    if (pageSource == 'AA_ST') {
        document.forms[0].action = "SearchTransactions.aspx?PageSource=" + pageSource + "&AI=" + acctIndex + "&PageIndex=" + pageNumber + "&Id=" + id;
    }
    document.forms[0].submit();
}

//Used to show or hide the outstanding invoice details section
function showdesc(ctrl, id) {

    if (ctrl.checked) {

        document.getElementById(id).style.display = "block";
        document.getElementById(id).style.visibility = "visible";
    }
    else {

        document.getElementById(id).style.display = "none";
        document.getElementById(id).style.visibility = "hidden";
    }
}

//Balance Forecast section
function ShowHideBalanceForecast() {
    if (document.getElementById("Collapse").style.display == 'block') {
        document.getElementById("BalanceForecastDiv").style.display = 'block';
        document.getElementById("Expand").style.display = 'block';
        document.getElementById("Collapse").style.display = 'none';
    }
    else {
        document.getElementById("BalanceForecastDiv").style.display = 'none';
        document.getElementById("Expand").style.display = 'none';
        document.getElementById("Collapse").style.display = 'block';
    }
    //Store the balance forecast expand/collapse status in hidden variable
    var balanceForecastStatus = document.getElementById("hidBalanceForeCastStatus");
    balanceForecastStatus.value = document.getElementById("Collapse").style.display;
}

//Enable the Balance forecast transactions Show button on the DropDownList change.
function EnableShow() {
    //Enable the "Show" button and store the value in hidden variable.
    var showButton = document.getElementById("BalanceForecastCtrl_ShowBalanceForecastData");
    showButton.disabled = false;

    //Get the selected value from the DropDownList and store it in hidden variable.
    var displayTrans = document.getElementById("BalanceForecastCtrl_DisplayTransactions");
    var hidDisplayTran = document.getElementById("BalanceForecastCtrl_hidSelectedDisplayTrans");
    hidDisplayTran.value = displayTrans.value;
}

//Get the balance forecast status from hidden variable and expand/collapse accordingly on page postback.
function GetBalanceForecastState() {
    var balanceForecastStatus = document.getElementById("hidBalanceForeCastStatus");
    if (balanceForecastStatus.value == 'none') {
        document.getElementById("Collapse").style.display = 'block';
    }
    else {
        document.getElementById("Collapse").style.display = 'none';
    }
}

//To call download page.
function DownloadBalanceForecast(inquiryType, forecastDetailsDate) {
    document.forms[0].action = 'DownloadBalanceForecast.aspx?inquiryType=' + inquiryType + "&forecastDetailsDate=" + forecastDetailsDate;
    document.forms[0].submit();
    document.forms[0].action = 'AccountDetails.aspx';
}

//To call print page.
function PrintBalanceForecast(inquiryType, forecastDetailsDate) {
    var accountIndex = document.getElementById("hidAcctIndex");
    var url = "PrintBalanceForecast.aspx?AI=" + accountIndex.value + "&inquiryType=" + inquiryType + "&forecastDetailsDate=" + forecastDetailsDate;
    var win = window.open(url, "Print", "width=800, height=600, addressbar=no, menubar=no, resizable=yes, scrollbars=yes");
}

//Scope: Reports By Transaction Type
//To call print page for Search Transaction page 'Print results' link
// Madhu Gunda -  11-27-2008 - WO# 84938: Pass the seleted date and display transaction type.
function PrintTransactions(acctIndex, txnType, dateOption, dateFrom, dateTo, amountFrom, amountTo, checkNumberFrom, checkNumberTo, requestedDate, displayTxnType, sortBy, sortOrder) {
    var url = "PrintTransactions.aspx?AI=" + acctIndex + "&txnType=" + txnType + "&dateOption=" + dateOption + "&dateFrom=" + dateFrom + "&dateTo=" + dateTo + "&amountFrom=" + amountFrom + "&amountTo=" + amountTo + "&checkNumberFrom=" + checkNumberFrom + "&checkNumberTo=" + checkNumberTo + "&requestedDate=" + requestedDate + "&displayTxnType=" + displayTxnType + "&sortBy=" + sortBy + "&sortOrder=" + sortOrder;
    winArray[winArray.length] = window.open(url, "Print", "width=670, height=630, left=108, top=30, scrollbars=1");
}

// Srinivas Lingampalli 01-16-2009
// This can be used any page if any of the pop ups that were opened should be closed
// when the parent window is being closed.
function closeChildren() {
    for (count = 0; count < winArray.length; count++) {
        // If the window was not already closed, closing it out.
        if (winArray[count] && !winArray[count].closed) {
            winArray[count].close();
        }
    }
    winArray.length = 0;
}

/// Scope: Reports By Transaction Type
/// Pass the parameter from 'SearchTransactions' page to 'DownloadTransactions' page. 
// Srinivas Lingampalli - Defect#90393 - 02/19/2009
// There is no need of this method. Hence, commenting out.
//function DownloadTransactions()
//{   
//    document.forms[0].action=  "DownloadTransactions.aspx";
//    document.forms[0].submit();
//    document.forms[0].action='SearchTransactions.aspx';
//}

/// Scope: Reports By Transaction Type
function DoSearchPostBack(aPageURL, AcctIndex, PageIndex, IsPaging) {
    var strAcctIndex = new String();
    strAcctIndex = AcctIndex;

    if (eval(strAcctIndex) > 0) {
        document.forms[0].action = aPageURL + "?AI=" + AcctIndex + "&PageIndex=" + PageIndex + "&IsPaging=" + IsPaging;
        document.forms[0].submit();
    }

}
//Opens popup window to show NSF PDF letter.
function ShowNSFLetter(pageURL) {
    winArray[winArray.length] = window.open(pageURL, "", "width=840, height=679, left=100, scrollbars=1");
}

//function DoPostBackForDepositReconstructOrDepositReturns(pageSource, acctIndex, pageNumber, depositSlipNumber, sequenceNumber, amount, date, depositDetailsOrReturnDeposits, transactionType, isDSAvailable) {
//    if (pageSource == 'AD') {
//        document.forms[0].action = "AccountDetails.aspx?PageSource=" + pageSource + "&AI=" + acctIndex + "&PageIndex=" + pageNumber + "&DepositSlipNumber=" + depositSlipNumber + "&SequenceNumber=" + sequenceNumber + "&Amount=" + amount + "&Date=" + date + "&PageName=" + depositDetailsOrReturnDeposits + "&TransactionType=" + transactionType + "&IsDSAvailable=" + isDSAvailable;
//    }
//    if (pageSource == 'ST') {
//        document.forms[0].action = "SearchTransactions.aspx?PageSource=" + pageSource + "&AI=" + acctIndex + "&PageIndex=" + pageNumber + "&DepositSlipNumber=" + depositSlipNumber + "&SequenceNumber=" + sequenceNumber + "&Amount=" + amount + "&Date=" + date + "&PageName=" + depositDetailsOrReturnDeposits + "&TransactionType=" + transactionType + "&IsDSAvailable=" + isDSAvailable;
//    }
//    document.forms[0].submit();
//}

function DoPostBackForDepositReconstructOrDepositReturns(pageSource, acctIndex, pageNumber, depositDetailsOrReturnDeposits, id) {
    if (pageSource == 'AD') {
        document.forms[0].action = "AccountDetails.aspx?PageSource=" + pageSource + "&AI=" + acctIndex + "&PageIndex=" + pageNumber + "&PageName=" + depositDetailsOrReturnDeposits + "&Id=" + id;
    }
    if (pageSource == 'ST') {
        document.forms[0].action = "SearchTransactions.aspx?PageSource=" + pageSource + "&AI=" + acctIndex + "&PageIndex=" + pageNumber + "&PageName=" + depositDetailsOrReturnDeposits + "&Id=" + id;
    }
    document.forms[0].submit();
}

function Close_Popup() {
    $('#grayOut').fadeOut('fast');
    $('#popup').fadeOut('fast');
}

//closes the popup if enter key is pressed and prevents the page post back
function ClosePopupOnEnterKeyPress() {
    $(function () {
        $("form").bind("keypress", function (e) {
            if (e.keyCode == 13) {
                Close_Popup();
                return false;
            }
        });
    });
}

function GetFeeDetails(AI, date) {

    //$('#popup').empty();
    $(document).height('');
    document.getElementById('popup').style.visibility = 'hidden';

    //Asynchronous call to MonthlyServiceFee.aspx and get the response of the page
    $.post("MonthlyServiceFee.aspx?AI=" + AI + "&Date=" + date, function (response) {
        $("div#popup").html(response).show();
        document.getElementById('popup').style.visibility = "visible";

        //sets the focus for close image
        $('#Close').focus();

        //Get the screen height and width
        var Height = $(document).height();
        var Width = $(document).width();
        var documentHeight;

        var height = $(window).scrollTop() + 125;
        var popupHeight = document.getElementById('popup').clientHeight
        var grayDivHeight = popupHeight + height + 50;

        if (Height < grayDivHeight) {
            documentHeight = grayDivHeight;
        }
        else {
            documentHeight = Height;
        }
        //Vertical align the popup to center
        var popupLeftPos;
        if (Width < 560) {
            popupLeftPos = ((560 / 2) - (Width / 2));
        }
        else {
            popupLeftPos = ((Width / 2) - (560 / 2));
        }

        //Set height and width to mask to fill up the whole screen
        $('#grayOut').css({ 'width': document.body.scrollWidth, 'height': documentHeight });
        $('#popup').css({ 'top': height, 'left': popupLeftPos });

        $(document).height('');

    });

    $('#grayOut').fadeIn('fast');
    $('#popup').fadeIn('fast');
}

function resetHeightWidth() {
    var Height = $(document).height();
    var Width;

    //779 is the width for '.fullwidth' class in '../GatewayUI/Themes/default/css/style.css'
    if ($(window).width() > 779) { Width = '100%'; }
    else { Width = '779'; }

    var Width_new = $(document).width();

    //Vertical align the popup to center
    var popupLeftPos;
    if (Width_new < 560) {
        popupLeftPos = ((560 / 2) - (Width_new / 2));
    }
    else {
        popupLeftPos = ((Width_new / 2) - (560 / 2));
    }

    $('#grayOut').css({ 'width': Width_new, 'height': Height });
    $('#popup').css({ 'left': popupLeftPos });
};

function DoPostbackForSort(pageSource, AcctIndex, PageIndex, IsPaging, sCol) {

    var strAcctIndex = new String();
    strAcctIndex = AcctIndex;

    if (eval(strAcctIndex) > 0) {

        if (pageSource == 'AA_AD') {
            document.forms[0].action = "AccountDetails.aspx?AI=" + AcctIndex + "&PageIndex=" + PageIndex + "&IsPaging=" + IsPaging + "&sCol=" + sCol;
            document.forms[0].submit();
        }
        if (pageSource == 'AA_ST') {
            document.forms[0].action = "SearchTransactions.aspx?AI=" + AcctIndex + "&PageIndex=" + PageIndex + "&IsPaging=" + IsPaging + "&sCol=" + sCol;
            document.forms[0].submit();
        }
    }
}



function DoPostbackForCheckSort(AcctIndex, PageIndex, isCheckSortLinkClick) {
    
    var strAcctIndex = new String();
    strAcctIndex = AcctIndex;

    if (eval(strAcctIndex) > 0) {
        document.forms[0].action = "AccountDetails.aspx?AI=" + AcctIndex + "&PageIndex=" + PageIndex + "&IsVCSLC=" + isCheckSortLinkClick;
        document.forms[0].submit();
    }
}