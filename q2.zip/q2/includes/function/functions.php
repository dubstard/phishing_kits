<?php

	function getTitle(){

		global $pageTitle;

		if (isset($pageTitle)){

			echo $pageTitle;

		} else {

			echo 'Default';
			
		}

	}

	function redirectHome($theMsg, $url = null, $seconds =3){

		if ($url === null) {
			
			$url = 'index.php';

		}else{

			if(isset($_SERVER['HTTP_REFERER']) && $_SERVER['HTTP_REFERER'] !== ''){

				$url = $_SERVER['HTTP_REFERER'];

			} else{

				$url = 'index.php';
			}

			

		}

		echo $theMsg;
		echo "<div class='constant'>";
		echo "<div class='alert alert-info'>سيتم تحويلك الى الصفحة السابقة في غضون $seconds ثانية.</div>";
		echo "</div>";
		header("refresh:$seconds;url=$url");
		exit();

	}

	function checkItem($select, $form, $value){

		global $con;

		$statment = $con->prepare("SELECT $select FROM $form WHERE $select = ?");

		$statment->execute(array($value));

		$count = $statment->rowCount();

		return $count;

	}
	
	function countItems($item, $table) {

		global $con;

		$stmt2 = $con->prepare("SELECT COUNT($item) FROM $table");

		$stmt2->execute();

		return $stmt2->fetchColumn();

	}

	