<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<title><?php getTitle(); ?></title>

	<link rel="stylesheet" href="<?php echo $css; ?>bootstrap.css">
	<link rel="stylesheet" href="<?php echo $css; ?>font-awesome.css">
    <link rel="stylesheet" href="https://code.ionicframework.com/ionicons/2.0.1/css/ionicons.min.css">
    <link rel="stylesheet" href="<?php echo $css; ?>dataTables.bootstrap.css">  
    <link rel="stylesheet" href="<?php echo $css; ?>AdminLTE.css">  
    <link rel="stylesheet" href="<?php echo $css; ?>skin-blue.min.css">
    <link rel="stylesheet" href="<?php echo $css; ?>_all-skins.min.css">
    <link rel="stylesheet" href="<?php echo $css; ?>bootstrap-rtl.min.css"> 
    <link rel="stylesheet" href="<?php echo $css; ?>blue.css"> 
     <link rel="stylesheet" href="<?php echo $css; ?>morris.css"> 

    <link rel="stylesheet" href="<?php echo $css; ?>style.css">
  
</head>
<body class="skin-blue sidebar-mini">


