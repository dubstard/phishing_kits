          <div class="wrapper">
      <header class="main-header">

        <a href="dashboard.php" class="logo">
          <span class="logo-mini"><b>A</b>LT</span>
          <span class="logo-lg">لوحة التحكم</span>
        </a>

        <nav class="navbar navbar-static-top" role="navigation">
          <a href="#" class="sidebar-toggle" data-toggle="offcanvas" role="button">
            <span class="sr-only">Toggle navigation</span>
          </a>
          <div class="navbar-custom-menu">
            <ul class="nav navbar-nav">
              
              
              
              <li>
                <a href="members.php?do=Edit&Userid=<?php echo $_SESSION['ID'] ?>" ><?php echo $_SESSION['Username'] ?></a>
               </li>
               <li> <a href="logeout.php" >تسجيل الخروج</a></li>
               
             
            
            </ul>
          </div>
        </nav>
      </header>
      <aside class="main-sidebar">

        <section class="sidebar">

          <ul class="sidebar-menu">
          <?php if ($_SESSION['DepID'] == 1 || $_SESSION['DepID'] == 2) { 
            
          echo "
           <li class='active'><a href='members.php'><i class='fa fa-link'></i> <span>الأعضاء</span></a></li>
            <li><a href='dep.php'><i class='fa fa-link'></i> <span>الدوائر</span></a></li>
            <li><a href='message.php'><i class='fa fa-link'></i> <span>الرسالة</span></a></li>
           ";
            } ?>
           

        
         
          

          </ul>
        </section>
      </aside>

      <div class="content-wrapper">
        <section class="content-header">
          <h1>
            
          </h1>
        
        </section>