
	
	<script src="<?php echo $js; ?>jquery-2.1.1.min.js"></script>
	<script src="<?php echo $js; ?>bootstrap.min.js"></script>
	<script src="<?php echo $js; ?>jquery.dataTables.min.js"></script>
	<script src="<?php echo $js; ?>dataTables.bootstrap.min.js"></script>
	<script src="<?php echo $js; ?>jquery.slimscroll.min.js"></script>
	<script src="<?php echo $js; ?>fastclick.min.js"></script>
	<script src="<?php echo $js; ?>app.min.js"></script>
	<script src="<?php echo $js; ?>demo.js"></script>
	<script src="<?php echo $js; ?>icheck.min.js"></script>
	<script src="<?php echo $js; ?>backend.js"></script>
	<script src="<?php echo $js; ?>raphael-min.js"></script>
	<script src="<?php echo $js; ?>morris.min.js"></script>



</body>
</html>

		