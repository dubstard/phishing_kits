<!DOCTYPE html>
<html>
<head>
	<title>قياس مدى رضا العملاء</title>

	<link rel="stylesheet" href="layout/css/bootstrap.css">
	<link rel="stylesheet" href="layout/css/font-awesome.css">
    <link rel="stylesheet" href="https://code.ionicframework.com/ionicons/2.0.1/css/ionicons.min.css">
    <link rel="stylesheet" href="layout/css/bootstrap-rtl.min.css"> 
    <link rel="stylesheet" href="layout/css/style2.css">
</head>
<?php include 'connect.php';
	
	$stmt = $con->prepare("SELECT * FROM department WHERE id != 1 AND id != 2 ");

	$stmt->execute();

	$rows = $stmt->fetchAll();
?>
<body>
<header>
	<h2>قياس مستوى رضى العملاء</h2>
</header>

<div class="container welcome">
	<h2 class="wel">اهلاً وسهلاً بك</h2>
</div>
<div>
	<div class="col-sm-4">
		<img class="man1" src="layout/images/man1.png">
	</div>
	<div class="col-sm-8">
		<img class="logo" src="layout/images/logo.png">
	</div>
	<h2 class="wel2 ">اختر دائرة</h2>
	<div class="col-sm-5">
		<?php
			  foreach ($rows as $row)
			   {?>
			<div class="col-sm-4 col-xs-6 link-a no-padding">
			 	<a href="cat.php?id=<?php echo $row['id'] ?>"><?php echo $row['name']; ?></a>
			 </div>
			 <?php } ?>

			 <p class=" col-sm-12 ar">جميع الحقوق محفوظة / الاشراف التربوي / موسى الخليفة</p>
	</div>
</div>

<script src="layout/js/jquery-2.1.1.min.js"></script>
<script src="layout/js/bootstrap.min.js"></script>
<script src="layout/js/backend.js"></script>
</body>
</html>