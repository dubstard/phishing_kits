$(function() {
	'use strict';

	$('[placeholder]').focus(function() {

		$(this).attr('data-text', $(this).attr('placeholder'));
		$(this).attr('placeholder', '');

	}).blur(function() {
		
		$(this).attr('placeholder', $(this).attr('data-text'));

	})

	// Add asterisk on required filed

	$('input').each(function () {

		if($(this).attr('required') == 'required') {

			$(this).after('<span class="asterisk">*</span>')

		}


	});

		
	$('.confirm').click(function(){

		return confirm('Are You Sure?');

	});
	
        $("#example1").DataTable();
        $('#example2').DataTable({
          "paging": true,
          "lengthChange": false,
          "searching": false,
          "ordering": true,
          "info": true,
          "autoWidth": false
        });
      $('input').iCheck({
          checkboxClass: 'icheckbox_square-blue',
          radioClass: 'iradio_square-blue',
          increaseArea: '20%' // optional
        });

});