<!DOCTYPE html>
<html>
<head>
	<title>قياس مدى رضا العملاء</title>
	<link rel="stylesheet" href="layout/css/bootstrap.css">
	<link rel="stylesheet" href="layout/css/font-awesome.css">
    <link rel="stylesheet" href="https://code.ionicframework.com/ionicons/2.0.1/css/ionicons.min.css">
    <link rel="stylesheet" href="layout/css/bootstrap-rtl.min.css"> 
    <link rel="stylesheet" href="layout/css/style2.css">
</head>
<?php

  include 'connect.php';
	
	$id = $_GET["id"];
	$stmt = $con->prepare("SELECT * FROM cat where id = $id ");

	$stmt->execute();

	$rows = $stmt->fetchAll();
	
?>
<body>
<header>
	<h2>قياس مستوى رضى العملاء</h2>
</header>

 <div class="container welcome">
	
</div> 
<div>
	<div class="col-sm-4">
	<a href="."><img class="logo logo2 img-responsive" src="layout/images/logo.png"></a>
	</div>
	<div class="col-sm-4">
	<?php
	 foreach ($rows as $row)
   {?>
 <?php 
   $r1 = $row['result_1'] ;
   $r2 = $row['result_2'] ;
   $r3 = $row['result_3'] ;
   $r4 = $row['result_4'] ;
   $r5 = $row['result_5'] ;
   $r6 = $row['result_6'] ;

  } 
 
 $result1 = $_POST["result1"];
 $result2 = $_POST["result2"];
 $result3 = $_POST["result3"];
 $result4 = $_POST["result4"];
 $result5 = $_POST["result5"];
 $result6 = $_POST["result6"];

 $a = $r1 + $result1;
 $b = $r2 + $result2;
 $c = $r3 + $result3;
 $d = $r4 + $result4;
 $e = $r5 + $result5;
 $f = $r6 + $result6;
 
 $formErrors = array();

if (isset($_POST['ss']) && (!empty($result1) || !empty($result2) || !empty($result3) || !empty($result4) || !empty($result5) || !empty($result6) )) {

 $stmt = $con->prepare("UPDATE cat SET result_1 = ?, result_2 = ?, result_3 = ? ,result_4 = ?, result_5 = ?, result_6 = ?  WHERE id = ? ");
				$stmt->execute(array($a, $b, $c, $d, $e, $f, $id));
				$stmt2 = $con->prepare("SELECT * FROM message");

					$stmt2->execute();

					$rows2 = $stmt2->fetchAll();
					foreach ($rows2 as $row) {
						
				echo '<div class="alert alert-success">'. $row['messag'] . ' </div>';
				}
				$stmt3 = $con->prepare("SELECT * FROM cat where id = $id");

					$stmt3->execute();

					$rows3 = $stmt3->fetchAll();
					foreach ($rows3 as $row) {
			echo '<meta http-equiv="refresh" content="2;url=cat.php?id='.$row['Dep_id'].'">';
			}
		}

		if (isset($_POST['ss']) && (empty($result1) && empty($result2) && empty($result3) && empty($result4) && empty($result5) && empty($result6) )) {
			echo '<div class="alert alert-danger">الرجاء اختيار اجابة</div>';
		}

 ?>
	<form action="" method="post">
		<h2 class="wel2 wel3">هل تمت خدمتك ؟</h2>
		<div class="col-xs-4 bottom-a right-m">
			<div class="checkbox_wrapper checkbox1">
			    <input type="radio" name="result1" value="1" class="cradio" />
			    <label></label>
			</div>
		</div>
		<div class="col-xs-4 bottom-a">
			<div class="checkbox_wrapper checkbox2">
			    <input type="radio" name="result2" value="1" class="cradio" />
			    <label></label>
			</div>
		</div>
		<div class="col-xs-4 bottom-a">
			<div class="checkbox_wrapper checkbox3">
			    <input type="radio" name="result3" value="1" class="cradio"/>
			    <label></label>
			</div>
		</div>

		<h2 class="wel2 wel3 wel4">كيف كانت طريقة التعامل معك ؟</h2>
		<div class="col-xs-4 right-m">
			<div class="checkbox_wrapper checkbox1">
			    <input type="radio" name="result4" value="1" class="cradio2"/>
			    <label></label>
			</div>
		</div>
		<div class="col-xs-4">
			<div class="checkbox_wrapper checkbox2">
			    <input type="radio" name="result5" value="1" class="cradio2"/>
			    <label></label>
			</div>
		</div>
		<div class="col-xs-4">
			<div class="checkbox_wrapper checkbox3">
			    <input type="radio" name="result6" value="1" class="cradio2"/>
			    <label></label>
			</div>
		</div>

		<input type="submit" value="ارسل" name="ss" class="btn btn2">

		<p class="ar">جميع الحقوق محفوظة / الاشراف التربوي / موسى الخليفة</p>
		</form>
	</div>
	<div class="col-sm-4">
	<?php
		$stmt = $con->prepare("SELECT * FROM cat where id = $id ");

		$stmt->execute();

		$rows = $stmt->fetch();
	 ?>
		<img class="man1 img-responsive" src="layout/images/<?php echo $rows['img'] ?>">
	</div>
	
	<div class="col-sm-5">
		
	</div>
</div>


<script src="layout/js/jquery-2.1.1.min.js"></script>
<script src="layout/js/bootstrap.min.js"></script>
<script src="layout/js/backend.js"></script>
<script type="text/javascript">
	$(".cradio").change(function () {
   $('.cradio').not(this).prop('checked', false);
});

	$(".cradio2").change(function () {
   $('.cradio2').not(this).prop('checked', false);
});

</script>
</body>
</html>