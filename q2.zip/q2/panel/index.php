<?php  
 ob_start();
	session_start();
		

	$noNavbar='';
	$pageTitle = 'Login';
	if(isset($_SESSION['Username'])){
		header('Location: dep.php');
	}
	include 'init.php';


	if($_SERVER['REQUEST_METHOD'] == 'POST'){

		$username = $_POST['user'];
		$password = $_POST['pass'];
		$hashedPass = sha1($password);
		

		$stmt = $con->prepare("SELECT UserID, Username, Password, Dep_ID FROM users WHERE Username = ? AND Password = ?  LIMIT 1");
		$stmt->execute(array($username, $hashedPass));
		$row = $stmt->fetch();
		$count = $stmt->rowCount();

		if($count > 0){
			$_SESSION['Username'] = $username;
			$_SESSION['ID'] = $row['UserID'];
			$_SESSION['DepID'] = $row['Dep_ID'];
			header('Location: dep.php');
			exit();
		}
		
		else{
			echo "<h4>البيانات غير صحيحة</h4>";
		}
	}

 ?>


		 <div class="login-box">
		     <div class="login-logo">
		        <a href="#"></a>
		      </div><!-- .login-logo --> 
		      <div class="login-box-body">
		        <p class="login-box-msg">الدخول الى لوحة التحكم</p>
		        <form action="<?php echo $_SERVER['PHP_SELF']?> "  method="POST" >
		          <div class="form-group has-feedback">
		            <input type="text" class="form-control" name="user" placeholder="اسم المستخدم"/>
		            <span class="glyphicon glyphicon-user form-control-feedback"></span>
		          </div>
		          <div class="form-group has-feedback">
		            <input type="password" class="form-control" name="pass" placeholder="كلمة المرور" />
		            <span class="glyphicon glyphicon-lock form-control-feedback"></span>		           
		          </div>
		          <div class="row">
			          <div class="col-xs-4">
			              <button type="submit" class="btn btn-primary btn-block btn-flat">دخول</button>
			            </div>
			         
		            
		          </div>
		        </form>


		      </div><!-- .login-box-body -->
		    </div><!-- .login-box -->


<?php  include $tpl .'footer.php'; 
  ob_end_flush();
  ?>