<?php  
ob_start();
	session_start();
	$pageTitle = 'الاقسام';

	if(isset($_SESSION['Username']) && $_SESSION['DepID'] == 1){
		
		include 'init.php';
		include '../includes/templates/up-nav.php';

		$do = isset($_GET['do']) ? $_GET['do'] : 'Manage';

		if ($do == 'Manage'){

			$stmt = $con->prepare("SELECT * FROM message ");

			$stmt->execute();

			$rows = $stmt->fetchAll();


		 ?>

			<div class="content">

			<div class="col-md-8">
				<div class="box box-info">
	                <div class="box-header with-border">
	                </div><!-- /.box-header -->
	                <!-- form start -->
	                <?php
	                	if (isset($_POST['save'])) {
	                		
	                $id = $_POST['id'];
					$name = $_POST['name'];
	                $stmt = $con->prepare("UPDATE message SET messag = ?  WHERE id = ? ");
					$stmt->execute(array($name , $id));
					echo '<div class="alert alert-success">تم التحديث</div>';
	               echo '<meta http-equiv="refresh" content="1;url=message.php">';
	                	}
	                 ?>
	                <form class="form-horizontal" action="" method="POST">
	                  <div class="box-body">
	                    <div class="form-group">
	                      <label for="inputEmail3" class="col-sm-2 control-label">الرسالة</label>
	                      <?php foreach ($rows as $row) {?>
	                      	
	                      
	                      <div class="col-sm-10">
	                       <input type="hidden" name="id" value="<?php echo $row['id'] ?>" />
	                        <input type="text" name="name" class="form-control" value="<?php echo $row['messag'] ?>" required="required"/>
	                       <?php } ?>
	                      </div>
	                    </div>
	               
	                  </div><!-- /.box-body -->
	                  <div class="box-footer">
	                   <div class="col-sm-offset-2 col-sm-9">
							<input type="submit" value="حفظ" name="save" class="btn btn-primary " />
						</div>
	                  </div><!-- /.box-footer -->
	                </form>

	                

	            </div><!-- /.box -->
		 	</div>
			
		</div>
	<?php } 

		include '../includes/templates/down-nav.php' ;
		include $tpl .'footer.php';


	} // end if Settion
	else{
		header('Location: index.php');
		exit();
	}
ob_end_flush();
	?>
