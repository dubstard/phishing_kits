<?php  
ob_start();
	session_start();
	$pageTitle = 'الدوائر';

	if(isset($_SESSION['Username'])){
		
		include 'init.php';
		include '../includes/templates/up-nav.php';

		$do = isset($_GET['do']) ? $_GET['do'] : 'Manage';

		if ($do == 'Manage'){
			if($_SESSION['DepID'] == 1 || $_SESSION['DepID'] == 2){
			$stmt = $con->prepare("SELECT * FROM department WHERE id != 1 AND id != 2 ");

			$stmt->execute();

			$rows = $stmt->fetchAll();
		}
		else{
			$stmt = $con->prepare("SELECT * FROM department WHERE id = {$_SESSION['DepID']}");

			$stmt->execute();

			$rows = $stmt->fetchAll();
		}

		 ?>

			<section class="content">
          <div class="row">
            <div class="col-xs-12">
      	      <div class="box">
                <div class="box-header">
                  <h3 class="box-title">إدارة الدوائرة</h3>
                  <?php if ($_SESSION['DepID'] == 1) { ?>
                  	<a href="dep.php?do=Add" class="btn btn-primary"><i class="fa fa-plus"></i> اضافة دائرة </a>
                  <?php } ?>
                </div><!-- /.box-header -->
                <div class="box-body">
                  <table id="example1" class="table table-bordered table-striped main-table">
                    <thead>
                     
                        <th>االرقم</th>
                        <th>اسم الدائرة</th>
                         <?php if ($_SESSION['DepID'] == 1 || $_SESSION['DepID'] == 2) {?>
                        <th>الاقسام</th>
                      <?php } ?>
                        	<th>النتائج</th>
                       
                        <th>تاريخ الاضافة</th>              
                       <?php if ($_SESSION['DepID'] == 1) {?>
                        	<th>التحكم</th>
                       <?php } ?>
                      </tr>
                    </thead>
                    <tbody>
                    <?php 
                    	
                    	foreach ($rows as $row) {
                    		if(!isset($counter))
							    {
							        $counter = 1;
							    }
    
                    		
                    		echo "<tr>";
                    		  echo "<td>" .  $counter++ . "</td>";
                    		  echo "<td>".  
                    		  			$row['name'] .
                    		  		"</td>";
                    		   if ($_SESSION['DepID'] == 1 || $_SESSION['DepID'] == 2) {
                    		    echo "<td> 
                    		 <a href='cat.php?do=Manage&id=" . $row['id'] ."'>الاقسام</a>
                    		  		</td>";
                    		  	}
                    		 echo "<td> <a href='results.php?do=show&id=" . $row['id'] ."'> النتائج </a> </td>";
                    		
                              echo "<td>" . $row['Date'] . "</td>";
                    		  if ($_SESSION['DepID'] == 1) {
                    		  	echo "<td> 
									 <a href='dep.php?do=Edit&Userid=" . $row['id'] ."' class='btn btn-success btn-sm'><i class='fa fa-edit'></i> تعديل</a>
									 <a href='dep.php?do=Delete&Userid=" . $row['id'] ."' class='btn btn-danger btn-sm confirm'><i class='fa fa-close'></i> حذف</a>
										 </td>";
										}
                    		echo "</tr>";
                    	}
                    ?>
                    
                    </tbody>
                  </table>
                </div><!-- /.box-body -->
              </div><!-- /.box -->
            </div><!-- /.col -->
          </div><!-- /.row -->

			</section>
	<?php } elseif ($do == 'Add') {?>
			
		<div class="content">

			<div class="col-md-8">
				<div class="box box-info">
	                <div class="box-header with-border">
	                </div><!-- /.box-header -->
	                <!-- form start -->
	                <form class="form-horizontal" action="?do=Insert" method="POST">
	                  <div class="box-body">
	                    <div class="form-group">
	                      <label for="inputEmail3" class="col-sm-2 control-label">اسم الدائرة</label>
	                      <div class="col-sm-10">
	                        <input type="text" name="name" class="form-control" required="required"/>
	                      </div>
	                    </div>
	               
	                  </div><!-- /.box-body -->
	                  <div class="box-footer">
	                   <div class="col-sm-offset-2 col-sm-9">
							<input type="submit" value="حفظ" class="btn btn-primary " />
						</div>
	                  </div><!-- /.box-footer -->
	                </form>


	            </div><!-- /.box -->
		 	</div>
			
		</div>

	<?php 
	}elseif ($do == 'Insert') {?>

			<div class="content">
			<?php if ($_SERVER['REQUEST_METHOD'] == 'POST') {
			

			
			echo '<h1 class="text-center">اضافة عضو</h1>'; 

			
 			
			$user = $_POST['name'];



			// validate the form

			$formErrors = array();

			if (strlen($user) < 2) {
				
				$formErrors[] = 'اسم القسم لا يمكن ان يكون اقل من <strong>2 احرف</strong>';

			}

			
			if (empty($user)) {

				$formErrors[] = 'اسم القسم لا يمكن ان يكون <strong>فارغ</strong>';
				 
			}

			//Loop into error array and echo it

			foreach ($formErrors as $error) {
				
				echo '<div class="alert alert-danger">' . $error . '</div>';

			}

			// Check if there's no error proceed the update operation
			// Update data

			if (empty($formErrors)) {

				$check = checkItem("name", "department", $user);

				if ($check == 1) {

					echo "<div class='alert alert-danger'>" . 'الدائرة المضاف موجود سابقا</div> ';
					echo "<div class='alert alert-info'>سيتم تحويلك الى الصفحة السابقة في غضون 3 ثانية.</div>";
			        echo '<meta http-equiv="refresh" content="3;url=dep.php">';

				}else{
				
		
					$stmt = $con->prepare("INSERT INTO department (name ,Date) VALUES(:zuser, now())");
					$stmt->execute(array(

						'zuser' => $user,


					));


					echo "<div class='alert alert-success'>" . 'تم الاضافة' . $stmt->rowCount() . '</div> ';
					echo "<div class='alert alert-info'>سيتم تحويلك الى الصفحة السابقة في غضون 3 ثانية.</div>";
			        echo '<meta http-equiv="refresh" content="3;url=dep.php">';

					}
			}		
 
			

			
		} else{

			echo '<div class="alert alert-danger">' . 'لا يمكن عرض الصفحة المطلوبة.</div>';
			echo "<div class='alert alert-info'>سيتم تحويلك الى الصفحة السابقة في غضون 3 ثانية.</div>";
			        echo '<meta http-equiv="refresh" content="3;url=dep.php">';

		}?>

		</div>

		
	 
	<?php }



	elseif ($do == 'Edit') { 

		if ($_SESSION['DepID'] == 1) {
		 $userid = isset($_GET['Userid']) && is_numeric($_GET['Userid']) ? intval($_GET['Userid']) : 0 ;

		$stmt = $con->prepare("SELECT * FROM department WHERE id = ? LIMIT 1");

		$stmt->execute(array($userid));

		$row = $stmt->fetch();

		$count = $stmt->rowCount();?>

	    <div class="content">

		<?php if ($stmt->rowCount() > 0){  ?>

			<div class="col-md-8">
					<div class="box box-info">

		               
		                <form class="form-horizontal" action="?do=Update" method="POST" />
		                <input type="hidden" name="userid" value="<?php echo $userid ?>" />
		                  <div class="box-body">
		                    <div class="form-group">
		                      <label for="inputEmail3" class="col-sm-2 control-label">القسم</label>
		                      <div class="col-sm-10">
		                        <input type="text" name="name" class="form-control" required="required" value="<?php echo $row['name']; ?>" />
		                      </div>
		                    </div>

		                  </div><!-- /.box-body -->
		                  <div class="box-footer">
		                   <div class="col-sm-offset-2 col-sm-9">
								<input type="submit" value="حفظ" class="btn btn-primary " />
							</div>
		                   </div><!-- /.box-footer -->
		                   
		                </form>
				     </div><!-- /.box -->
			 		</div>
			</div>

	 <?php  
	 } else {
	 	
	 		echo '<div class="alert alert-danger">' . 'لا يمكن عرض الصفحة المطلوبة.</div>';
			echo "<div class='alert alert-info'>سيتم تحويلك الى الصفحة السابقة في غضون 3 ثانية.</div>";
			        echo '<meta http-equiv="refresh" content="3;url=dep.php">';
			
	 }
		}
		else{
			header('Location: index.php');
			exit();
		}
	
	} elseif ($do == 'Update') {
		echo '<h1 class="text-center">تحديث الاقسام</h1>';
		echo '<div class="content">';
 
		if($_SERVER['REQUEST_METHOD'] == 'POST'){

			$id = $_POST['userid'];
			$user = $_POST['name'];


			// validate the form

			$formErrors = array();

			if (strlen($user) < 4) {
				
				$formErrors[] = '<div class="alert alert-danger">اسم القسم يجب ان يكون اكبر من <strong>2 احرف</strong> </div>';

			}

			if (empty($user)) {

				$formErrors[] = '<div class="alert alert-danger">اسم القسم لا يمكن ان يكون<strong>فارغ</strong> </div>';
				 
			}

			
			//Loop into error array and echo it

			foreach ($formErrors as $error) {
				
				echo $error ;

			}

			// Check if there's no error proceed the update operation
			// Update data

			if (empty($formErrors)) {
				
				$stmt = $con->prepare("UPDATE department SET name = ?  WHERE id = ? ");
				$stmt->execute(array($user , $id));
				echo "<div class='alert alert-success'>" . 'تم تحديث ' . $stmt->rowCount() . '</div> ';
				echo "<div class='alert alert-info'>سيتم تحويلك الى الصفحة السابقة في غضون 3 ثانية.</div>";
			        echo '<meta http-equiv="refresh" content="3;url=dep.php">';

			}

			

			
		} else{
			echo '<div class="alert alert-danger">' . 'لا يمكن عرض الصفحة المطلوبة.</div>';
			echo "<div class='alert alert-info'>سيتم تحويلك الى الصفحة السابقة في غضون 3 ثانية.</div>";
			        echo '<meta http-equiv="refresh" content="3;url=dep.php">';
		}

		echo '</div>';// End if do == Update
	} elseif ($do == 'Delete') {
		if ($_SESSION['DepID'] == 1) {
			echo '<h1 class="text-center">حذف الاقسام</h1>';
		echo '<div class="content">';
		$userid = isset($_GET['Userid']) && is_numeric($_GET['Userid']) ? intval($_GET['Userid']) : 0 ;

		$check = checkItem('id', 'department', $userid);


		if ($check > 0){  

			$stmt = $con->prepare("DELETE FROM department WHERE id = :zuser");

			$stmt->bindParam(":zuser", $userid);

			$stmt->execute();

			echo "<div class='alert alert-success'>" . $stmt->rowCount() . ' تم الحذف </div> ';
			echo "<div class='alert alert-info'>سيتم تحويلك الى الصفحة السابقة في غضون 3 ثانية.</div>";
			        echo '<meta http-equiv="refresh" content="3;url=dep.php">';
		

		}
		else {
			
		 	echo '<div class="alert alert-danger">' . 'تاكد من الصفحة المطلوبة.</div>';

		 	echo "<div class='alert alert-info'>سيتم تحويلك الى الصفحة السابقة في غضون 3 ثانية.</div>";
			        echo '<meta http-equiv="refresh" content="3;url=dep.php">';
		 	
		}
		echo '</div>';
		}
		else{
			header('Location: index.php');
		}
	}

		include '../includes/templates/down-nav.php' ;
		include $tpl .'footer.php';


	} // end if Settion
	else{
		header('Location: index.php');
		exit();
	}
ob_end_flush();
	?>
