<?php  
 ob_start();
	session_start();
	$pageTitle = 'الاعضاء';

	if(isset($_SESSION['Username'])){
		
		include 'init.php';
		include '../includes/templates/up-nav.php';

		$do = isset($_GET['do']) ? $_GET['do'] : 'Manage';

		if ($do == 'Manage'){
			if ($_SESSION['DepID'] == 1 || $_SESSION['DepID'] == 2 ) {
				# code...
			
			$stmt = $con->prepare("SELECT * FROM users ");

			$stmt->execute();

			$rows = $stmt->fetchAll();


		 ?>

			<section class="content">
          <div class="row">
            <div class="col-xs-12">
      	      <div class="box">
                <div class="box-header">
                  <h3 class="box-title">إدارة الأعضاء</h3>
                  <?php  if ($_SESSION['DepID'] == 1) { ?>
                  <a href="members.php?do=Add" class="btn btn-primary"><i class="fa fa-plus"></i> اضافة اعضاء </a>
                  <?php } ?>
                </div><!-- /.box-header -->
                <div class="box-body">
                  <table id="example1" class="table table-bordered table-striped main-table">
                    <thead>
                     
                        <th>االرقم</th>
                        <th>اسم المستخدم</th>
                        <th>البريد الالكتروني</th>
                        <th>الاسم</th>
                        <th>تاريخ التسجيل</th>
                        <?php if ($_SESSION['DepID'] == 1) {?>
                        	<th>التحكم</th>
                        <?php } ?> 
                        
                      </tr>
                    </thead>
                    <tbody>
                    <?php 
                    	
                    	foreach ($rows as $row) {
                    		if(!isset($counter))
							    {
							        $counter = 1;
							    }
    
                    		
                    		echo "<tr>";
                    		  echo "<td>" .  $counter++ . "</td>";
                    		  echo "<td>" . $row['Username'] . "</td>";
                    		  echo "<td>" . $row['Email'] . "</td>";
                    		  echo "<td>" . $row['FullName'] . "</td>";
                              echo "<td>" . $row['Date'] . "</td>";
                                if ($_SESSION['DepID'] == 1) {
                    		  echo "<td> 
									 <a href='members.php?do=Edit&Userid=" . $row['UserID'] ."' class='btn btn-success btn-sm'><i class='fa fa-edit'></i> تعديل</a>
									 <a href='members.php?do=Delete&Userid=" . $row['UserID'] ."' class='btn btn-danger btn-sm confirm'><i class='fa fa-close'></i> حذف</a>
										 </td>";
										}
                    		echo "</tr>";
                    	}
                    ?>
                    
                    </tbody>
                  </table>
                </div><!-- /.box-body -->
              </div><!-- /.box -->
            </div><!-- /.col -->
          </div><!-- /.row -->

			</section>
	<?php }
			else{
					header('Location: index.php');
								exit();
					}
			} elseif ($do == 'Add') {

		$stmt = $con->prepare("SELECT * FROM department ");

			$stmt->execute();

			$rows = $stmt->fetchAll();

			?>
			
		<div class="content">

			<div class="col-md-8">
				<div class="box box-info">
	                <div class="box-header with-border">
	                </div><!-- /.box-header -->
	                <!-- form start -->
	                <form class="form-horizontal" action="?do=Insert" method="POST">
	                  <div class="box-body">
	                    <div class="form-group">
	                      <label for="inputEmail3" class="col-sm-2 control-label">اسم الدخول</label>
	                      <div class="col-sm-10">
	                        <input type="text" name="username" class="form-control" required="required"/>
	                      </div>
	                    </div>
	                    <div class="form-group">
	                      <label for="inputPassword3" class="col-sm-2 control-label">كلمة السر</label>
	                      <div class="col-sm-10">
							<input type="password" name="password" class="form-control" required="required"/>

	                      </div>
	                    </div>

	                    <div class="form-group">
	                      <label for="inputEmail3" class="col-sm-2 control-label">البريد الالكتروني</label>
	                      <div class="col-sm-10">
	                        <input type="email" name="email" class="form-control" required="required"/>
	                      </div>
	                    </div>
	                    <div class="form-group">
	                      <label for="inputEmail3" class="col-sm-2 control-label">الاسم</label>
	                      <div class="col-sm-10">
	                      <input type="text" name="full" class="form-control" required="required"/>
	                      </div>
	                    </div>

	                    <div class="form-group">
	                      <label for="inputEmail3" class="col-sm-2 control-label">الدائرة</label>
	                      <div class="col-sm-10">
	                        <select class="form-control" name="dep">
	                        	<?php foreach ($rows as $row) { ?>
	                        		<option value="<?php echo $row['id']; ?>"><?php echo $row['name']; ?></option>
	                        	<?php } ?>
	                        </select>
	                      </div>
	                    </div>
	                    
	                  </div><!-- /.box-body -->
	                  <div class="box-footer">
	                   <div class="col-sm-offset-2 col-sm-9">
							<input type="submit" value="حفظ" class="btn btn-primary " />
						</div>
	                  </div><!-- /.box-footer -->
	                </form>


	            </div><!-- /.box -->
		 	</div>
			
		</div>

	<?php 
	}elseif ($do == 'Insert') {?>

			<div class="content">
			<?php if ($_SERVER['REQUEST_METHOD'] == 'POST') {
			

			
			echo '<h1 class="text-center">اضافة عضو</h1>'; 

			
 			
			$user = $_POST['username'];
			$pass = $_POST['password'];
			$email = $_POST['email'];
			$name = $_POST['full'];
			$dep = $_POST['dep'];
			$hashPass = sha1($_POST['password']);


			// validate the form

			$formErrors = array();

			if (strlen($user) < 4) {
				
				$formErrors[] = 'اسم المستخدم لا يمكن ان يكون اقل من <strong>4 احرف</strong>';

			}

			
			if (empty($user)) {

				$formErrors[] = 'اسم المستخدم لا يمكن ان يكون <strong>فارغ</strong>';
				 
			}

			if (empty($pass)) {

				$formErrors[] = 'كلمة المرور لا يمكن ان تكون <strong>فارغة</strong>';
				 
			}

			if (empty($name)) {
				
				$formErrors[] = 'الاسم لا يمكن ان يكون <strong>فارغ</strong>';
				
			}

			if (empty($email)) {

				$formErrors[] = 'البريد الالكرتوني لا يمكن ان يكون <strong>empty</strong>';

			}

			//Loop into error array and echo it

			foreach ($formErrors as $error) {
				
				echo '<div class="alert alert-danger">' . $error . '</div>';

			}

			// Check if there's no error proceed the update operation
			// Update data

			if (empty($formErrors)) {

				$check = checkItem("Username", "users", $user);

				if ($check == 1) {

					 echo  "<div class='alert alert-danger'>" . 'الاسم المضاف موجود سابقا</div> ';
					 echo "<div class='alert alert-info'>سيتم تحويلك الى الصفحة السابقة في غضون 3 ثانية.</div>";
					echo '<meta http-equiv="refresh" content="3;url=members.php">';

				}else{
				
		
					$stmt = $con->prepare("INSERT INTO users(Username, Password, Email, FullName,Date ,Dep_ID) VALUES(:zuser, :zpass, :zmail, :zname, now(), :zdep)");
					$stmt->execute(array(

						'zuser' => $user,
						'zpass' => $hashPass,
						'zmail' => $email,
						'zname' => $name,
						'zdep' => $dep,

					));


					$theMsg = "<div class='alert alert-success'>" . 'تم الاضافة' . $stmt->rowCount() . '</div> ';
					redirectHome($theMsg, 'back');

					}
			}		
 
			

			
		} else{

			echo '<div class="alert alert-danger">' . 'لا يمكن عرض الصفحة المطلوبة.</div>';
			 echo "<div class='alert alert-info'>سيتم تحويلك الى الصفحة السابقة في غضون 3 ثانية.</div>";
					echo '<meta http-equiv="refresh" content="3;url=members.php">';

		}?>

		</div>

		
	 
	<?php }



	elseif ($do == 'Edit') { 
		if ($_GET['Userid'] == $_SESSION['ID'] || $_SESSION['DepID'] == 1) {
			
		$userid = isset($_GET['Userid']) && is_numeric($_GET['Userid']) ? intval($_GET['Userid']) : 0 ;

		$stmt = $con->prepare("SELECT * FROM users WHERE UserID = ? LIMIT 1");

		$stmt->execute(array($userid));

		$row = $stmt->fetch();

		$count = $stmt->rowCount();

		$stmt1 = $con->prepare("SELECT * FROM department ");

			$stmt1->execute();

			$rows_d = $stmt1->fetchAll();


		?>




	    <div class="content">

		<?php if ($stmt->rowCount() > 0){  ?>

			<div class="col-md-8">
					<div class="box box-info">

		                <div class="box-header with-border">
		                  <h3 class="box-title">السيد <?php echo $row['Username']; ?> </h3>
		                </div><!-- /.box-header -->
		                <!-- form start -->
		                <form class="form-horizontal" action="?do=Update" method="POST" />
		                <input type="hidden" name="userid" value="<?php echo $userid ?>" />
		                  <div class="box-body">
		                    <div class="form-group">
		                      <label for="inputEmail3" class="col-sm-2 control-label">اسم الدخول</label>
		                      <div class="col-sm-10">
		                        <input type="text" name="username" class="form-control" required="required" value="<?php echo $row['Username']; ?>" />
		                      </div>
		                    </div>
		                    <div class="form-group">
		                      <label for="inputPassword3" class="col-sm-2 control-label">كلمة السر</label>
		                      <div class="col-sm-10">
		                       <input type="hidden" name="oldpassword" value="<?php echo $row['Password'];?>"/>
								<input type="password" name="newpassword" class="form-control" />

		                      </div>
		                    </div>

		                    <div class="form-group">
		                      <label for="inputEmail3" class="col-sm-2 control-label">البريد الالكتروني</label>
		                      <div class="col-sm-10">
		                      <input type="email" name="email" class="form-control" required="required" value="<?php echo $row['Email']; ?>" />
		                      </div>
		                    </div>
		                    <div class="form-group">
		                      <label for="inputEmail3" class="col-sm-2 control-label">الاسم</label>
		                      <div class="col-sm-10">
		                      <input type="text" name="full" class="form-control" required="required" value="<?php echo $row['FullName']; ?>" />
		                      </div>
		                    </div>

		                 <div class="form-group">
	                      <label for="inputEmail3" class="col-sm-2 control-label">الدائرة</label>
	                      <div class="col-sm-10">
	                        <select class="form-control" name="dep">
	                        	<option value="<?php echo $row['Dep_ID']; ?>"></option>
	                        	<?php foreach ($rows_d as $rows_d) { ?>
	                        		<option value="<?php echo $rows_d['id']; ?>"><?php echo $rows_d['name']; ?></option>
	                        	<?php } ?>
	                        </select>
	                      </div>
	                    </div>
		                    
		                  </div><!-- /.box-body -->
		                  <div class="box-footer">
		                   <div class="col-sm-offset-2 col-sm-9">
								<input type="submit" value="حفظ" class="btn btn-primary " />
							</div>
		                   </div><!-- /.box-footer -->
		                   
		                </form>
				     </div><!-- /.box -->
			 		</div>
			</div>

	 <?php  
	 } else {
	 	
	 		echo '<div class="alert alert-danger">' . 'لا يمكن عرض الصفحة المطلوبة.</div>';
			echo "<div class='alert alert-info'>سيتم تحويلك الى الصفحة السابقة في غضون 3 ثانية.</div>";
			echo '<meta http-equiv="refresh" content="3;url=members.php">';
			
	 }
	
		}
		else{
			header('Location: index.php');
			exit();
		}
	} elseif ($do == 'Update') {
		echo '<h1 class="text-center">تحديث الاعضاء</h1>';
		echo '<div class="content">';
 
		if($_SERVER['REQUEST_METHOD'] == 'POST'){

			$id = $_POST['userid'];
			$user = $_POST['username'];
			$email = $_POST['email'];
			$name = $_POST['full'];
			$dep = $_POST['dep'];

			$pass = '';

			if(empty($_POST['newpassword'])){

				$pass = $_POST['oldpassword'];

			} else {

				$pass = sha1($_POST['newpassword']);

			}


			// validate the form

			$formErrors = array();

			if (strlen($user) < 4) {
				
				$formErrors[] = '<div class="alert alert-danger">اسم المستخدم يجب ان يكون اكبر من <strong>4 احرف</strong> </div>';

			}

			if (empty($user)) {

				$formErrors[] = '<div class="alert alert-danger">اسم المستخدم لا يمكن ان يكون<strong>فارغ</strong> </div>';
				 
			}

			if (empty($name)) {
				
				$formErrors[] = '<div class="alert alert-danger">الاسم لا يمكن ان يكون<strong>فارغ</strong> </div>';
				
			}

			if (empty($email)) {

				$formErrors[] = '<div class="alert alert-danger">لا يمكن ان يكون البريد االالكتروني<strong>فارغ</strong> </div>';

			}

			//Loop into error array and echo it

			foreach ($formErrors as $error) {
				
				echo $error ;

			}

			// Check if there's no error proceed the update operation
			// Update data

			if (empty($formErrors)) {
				
				$stmt = $con->prepare("UPDATE users SET Username = ?, Email = ?, FullName = ?, Dep_ID = ?, Password = ? WHERE UserID = ? ");
				$stmt->execute(array($user, $email, $name, $dep, $pass, $id));
				$theMsg = "<div class='alert alert-success'>" . 'تم تحديث ' . $stmt->rowCount() . '</div> ';
				redirectHome($theMsg, 'back');

			}

			

			
		} else{
			$theMsg = '<div class="alert alert-danger">' . 'لا يمكن عرض الصفحة المطلوبة.</div>';
			redirectHome($theMsg);
		}

		echo '</div>';// End if do == Update
	} elseif ($do == 'Delete') {
		if ($_SESSION['DepID'] == 1) {
			echo '<h1 class="text-center">حذف الاعضاء</h1>';
		echo '<div class="content">';
		$userid = isset($_GET['Userid']) && is_numeric($_GET['Userid']) ? intval($_GET['Userid']) : 0 ;

		$check = checkItem('Userid', 'users', $userid);


		if ($check > 0){  

			$stmt = $con->prepare("DELETE FROM users WHERE UserID = :zuser");

			$stmt->bindParam(":zuser", $userid);

			$stmt->execute();

			$theMsg = "<div class='alert alert-success'>" . $stmt->rowCount() . ' تم الحذف </div> ';
			
			redirectHome($theMsg, 'back');
		}
		else {
			
		 	echo'<div class="alert alert-danger">' . 'تاكد من الصفحة المطلوبة.</div>';

		 	echo "<div class='alert alert-info'>سيتم تحويلك الى الصفحة السابقة في غضون 3 ثانية.</div>";
			echo '<meta http-equiv="refresh" content="3;url=members.php">';
		 	
		}
		echo '</div>';
		}
		else{
			header('Location: index.php');
		}
	}

		include '../includes/templates/down-nav.php' ;
		include $tpl .'footer.php';


	} // end if Settion
	else{
		header('Location: index.php');
		exit();
	}
ob_end_flush();
	?>
