<?php
	
	include 'connect.php';

	$tpl = '../includes/templates/'; // templates directory 
	$func = '../includes/function/';
	$css = '../layout/css/'; // css directory 
	$js = '../layout/js/'; // js directory 
	
	include $func. 'functions.php';
	include $tpl . 'header.php'; 

 
	
	