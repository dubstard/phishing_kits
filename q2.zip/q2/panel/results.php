<?php  
	ob_start();
	session_start();
	$pageTitle = 'النتائج';

	if(isset($_SESSION['Username'])){
		
		include 'init.php';
		include '../includes/templates/up-nav.php';

		$do = isset($_GET['do']) ? $_GET['do'] : 'Manage';
		if ($do == 'Manage') {
			echo "<div class='alert alert-danger'>" . 'لا يوجد نتائج اتجه لصفحة الدوائر من <a href="dep.php">هنا</a></div> ';

		}

		elseif ($do == 'show'){

			$stmt = $con->prepare("SELECT * FROM cat WHERE Dep_id = {$_GET['id']} ");


			$stmt->execute();

			$rows = $stmt->fetchAll();


		 ?>
		 

			<section class="content">
          <div class="row">

            <div class="col-xs-12">
      	      <div class="box">
				<div class="box-body chart-responsive">
                  <div class="chart" id="bar-chart" style="height: 300px;">
                    
                  </div>
                </div><!-- /.box-body -->  
                  <div class="box-body">
                  <table id="example1" class="table table-bordered table-striped main-table">
                    <thead>
                     
                        <th>االرقم</th>
                        <th>اسم القسم</th>
                        <th> <img src="../layout/images/happy.png" width="40" /> </th>
                        <th> <img src="../layout/images/sceptic.png" width="40" /> </th>
                        <th> <img src="../layout/images/sad.png" width="40" /> </th>              
                        <?php if ($_SESSION['DepID'] == 1) {?>
                        	<th>التحكم</th>
                       <?php } ?>
                      </tr>
                    </thead>
                    <tbody>
                    <?php 
                    	
                    	foreach ($rows as $row) {
                    		if(!isset($counter))
							    {
							        $counter = 1;
							    }
    
                    		
                    		echo "<tr>";
                    		  echo "<td>" .  $counter++ . "</td>";
                    		  echo "<td>" . $row['name'] . "</td>";
                              echo "<td>" . $row['result_1'] . "</td>";
                              echo "<td>" . $row['result_2'] . "</td>";
                              echo "<td>" . $row['result_3'] . "</td>";
                    		 if ($_SESSION['DepID'] == 1) {
                    		 	 echo "<td> 
									 
									 <a href='results.php?do=MoveItem&Userid=" . $row['id'] ."' class='btn btn-danger btn-sm confirm'><i class='fa fa-close'></i> تفريغ</a>
										 </td>";
                    		 }
                    		echo "</tr>";
                    	}
                    ?>
                    
                    </tbody>
                  </table>
                </div><!-- /.box-body -->
              </div><!-- /.box -->
            </div><!-- /.col -->
          </div><!-- /.row -->

			</section>
	<?php }

	elseif ($do == 'MoveItem') {
		echo '<h1 class="text-center">تفريغ النتائج</h1>';
		echo '<div class="container">';

		$appealid = isset($_GET['Userid']) && is_numeric($_GET['Userid']) ? intval($_GET['Userid']) : 0 ;

		$check = checkItem('id', 'cat', $appealid);

		if ($check > 0){  

			$stmt = $con->prepare("UPDATE cat SET result_1 = 0, result_2 = 0, result_3 = 0 WHERE id = ?");

			$stmt->execute(array($appealid));

			$theMsg = "<div class='alert alert-success'>" . $stmt->rowCount() . ' تم  </div> ';

			redirectHome($theMsg);
		

		}
		else {
			echo "<div class='container'>";
		 	$theMsg = '<div class="alert alert-danger">' . 'Thers no such ID .</div>';

		 	redirectHome($theMsg);
		 	echo "</div>";
		}
		echo '</div>';
	}

		include '../includes/templates/down-nav.php' ;
		include $tpl .'footer.php';


	} // end if Settion
	else{
		header('Location: dep.php');
		exit();
	}

	?>
<?php
    
   
			if ($_SESSION['DepID'] == 1 || $_SESSION['DepID'] == 2) {
				$stmt = $con->prepare("SELECT * FROM cat WHERE Dep_id = {$_GET['id']}");

			$stmt->execute();

			$rows = $stmt->fetchAll();
			}
			else{
				$stmt = $con->prepare("SELECT * FROM cat WHERE Dep_id = {$_SESSION['DepID']}");

			$stmt->execute();

			$rows = $stmt->fetchAll();
			}
			ob_end_flush();

?>

	<script>
      $(function () {
        "use strict";

        // AREA CHART
       
        // LINE CHART
  
        //BAR CHART
        var bar = new Morris.Bar({
          element: 'bar-chart',
          resize: true,
         

        
          data: [
           <?php foreach ($rows as $row){?>
            {y: '<?php echo $row['name'] ?>', a: <?php echo $row['result_1'] ?>, b: <?php echo $row['result_2'] ?> ,c:<?php echo $row['result_3'] ?>},
             <?php } ?>
          ],
         
          barColors: ['#00a65a', '#3c8dbc', '#f56954'],
          xkey: 'y',
          ykeys: ['a', 'b', 'c'],
          labels: ['راضي', 'مقبول', 'غير راضي'],
          hideHover: 'auto'
        });
      });
    </script>