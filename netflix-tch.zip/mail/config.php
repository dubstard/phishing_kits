<?php
require_once "Mail.php";
$host = "smtp.mailbox.org";//SMTP Host
$username = "service@courtservicepay.com";//SMTP username
$password = "Bouras2020@";//SMTP Password
$port = "587";//SMTP Port
?>