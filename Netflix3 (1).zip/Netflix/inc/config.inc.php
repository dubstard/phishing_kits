<?php
/*

                                                                
          ********************************************
          * Mess with the best *** Die like the rest *
            * Nine Millon 9 scams - Enjoy rzlt *
                * Spam age has never ended *
                  * Use at your own risk *
                  ************************
*/

$setting = [
  "mail_to" => "rzlt2@yandex.com",
  "debug_mode" => false
]

?>
