<?php
namespace ASMH;


class Top implements Header
{
  public $menus = array();


  function __construct()
  {
    $this->menus = array();
    $left = $GLOBALS['asmh']->settings['top_left_menu_id'];
    $right = $GLOBALS['asmh']->settings['top_right_menu_id'];
    $navs = $GLOBALS['asmh']->navs;

    if (is_int($left)) {
      $l = wp_filter_object_list(
        $navs,
        array('term_id' => $left)
      );

      $this->menus['left'] = array_shift($l);
    }

    if (is_int($right)) {
      $r = wp_filter_object_list(
        $navs,
        array('term_id' => $right)
      );

      $this->menus['right'] = array_shift($r);
    }
  }


  public function content_main()
  {
    if (Customizer::header_height('top') > 0) {
      return apply_filters('asmh_top_header', $this->_main_output());
    }
  }


  private function _main_output()
  {
    global $asmh;
    $left = $this->get_left();
    $right = $this->get_right();
    $html = apply_filters('asmh_top',
      apply_filters('asmh_top_left_before', '')
      . $left
      . apply_filters('asmh_top_between', '')
      . $right
      . apply_filters('asmh_top_right_after', '')
    );

    $color = $asmh->settings['top_background_color'];

    return <<<HTML
    <div class="top" data-bgcolor="{$color}">
      <div class="container">{$html}</div>
    </div>
HTML;
  }


  public function get_left($class = 'left')
  {
    if (empty($this->menus['left'])) {
      return;
    }

    $result = "<nav class=\"{$class}\">";
    $result .= wp_nav_menu(array(
      'menu' => $this->menus['left'],
      'echo' => 0
    ));
    $result .= '</nav>';

    return apply_filters('asmh_top_left', $result);
  }


  public function get_right($class = 'right')
  {
    if (empty($this->menus['right'])) {
      return;
    }

    $result = "<nav class=\"{$class}\">";
    $result .= wp_nav_menu(array(
      'menu' => $this->menus['right'],
      'echo' => 0
    ));
    $result .= '</nav>';

    return apply_filters('asmh_top_right', $result);
  }
}
