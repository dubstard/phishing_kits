<?php
namespace ASMH;


class Bottom implements Header
{
  function __construct()
  {
    add_filter('wp_nav_menu_objects', array($this, 'sub_menu'), 10, 2);
  }


  public function content_main()
  {
    if (Customizer::header_height('bottom') > 0) {
      return apply_filters('asmh_bottom_header', $this->_main_output());
    }
  }


  private function _main_output()
  {
    global $asmh;
    $left = $this->left();
    $right = $this->right();
    $html = apply_filters('asmh_bottom',
      apply_filters('asmh_bottom_left_before', '')
      . $left
      . apply_filters('asmh_bottom_between', '')
      . $right
      . apply_filters('asmh_bottom_right_after', '')
    );

    $color = $asmh->settings['bottom_background_color'];

    return <<<HTML
    <div class="bottom" data-bgcolor="{$color}">
      <div class="container">{$html}</div>
    </div>
HTML;
  }


  public function left()
  {
    return apply_filters('asmh_bottom_left', $this->show_side('left'));
  }


  public function right()
  {
    return apply_filters('asmh_bottom_right', $this->show_side('right'));
  }


  public function show_side($side)
  {
    global $asmh;

    switch ($asmh->settings['bottom_' . $side])
    {
    case 'breadcrumbs':
      if (!$asmh->is_preview) {
        return Breadcrumbs::get_html();
      } else {
        return Breadcrumbs::get_html_preview($side);
      }

      break;

    case 'menu':
      return $this->get_menu($side);
      break;

    case 'submenu':
      return $this->get_submenu($side);
      break;

    case 'title':
      return $this->get_title($side);
      break;
    }
  }


  public function get_menu($side)
  {
      global $asmh;

      $result = '<nav class="bottom-menu ' . $side . '">';

      $result .= wp_nav_menu(array(
          'menu' => $asmh->settings["bottom_{$side}_menu_id"],
          'container' => false,
          'echo' => false,
          'bottom' => true,
          'depth' => 1));

      $result .= '</nav>';

      return apply_filters("asmh_bottom_{$side}_menu_before", '')
        . apply_filters("asmh_bottom_{$side}_menu", $result)
        . apply_filters("asmh_bottom_{$side}_menu_after", '');
  }


  public function get_submenu($side)
  {
    global $asmh;
    $result = '<nav class="submenu ' . $side . '">';

    if (!$asmh->is_preview) {
      $result .= wp_nav_menu(array(
        'menu' => $GLOBALS['asmh']->middle->id,
        'container' => false,
        'echo' => false,
        'sub_menu' => true
      ));

    } else {
      $result .= '<ul><li><a href="#">Link 1</a></li>'
        . '<li><a href="#">Link 2</a></li>'
        . '<li><a href="#">Link 3</a></li>'
        . '</ul>';
    }

    $result .= '</nav>';

    return apply_filters('asmh_bottom_submenu', $result);
  }


  public function get_title($side)
  {
    $defaults = array(
      'tag' => 'span',
      'before' => '',
      'after' => '',
      'class' => 'header-title',
      'id' => '',
      'show_home' => true,
      'home_title' => get_bloginfo('title')
    );

    $args = wp_parse_args(
      apply_filters('asmh_bottom_title_attrs', array()),
      $defaults
    );

    if (!$args['show_home']) {
      return;
    }

    $result = '<div'
      . (!empty($args['id'])? ' id="'.$args['id'].'"' : '')
      . ' class="' . $side
        . (!empty($args['class'])? ' '.$args['class'] : '') . '">';
    $result .= '<' . $args['tag'] . '>'
      . $args['before']
      . $this->bottom_title($args)
      . $args['after']
      .'</' . $args['tag'] . '>';
    $result .= '</div>';

    return apply_filters('asmh_bottom_title', $result);
  }


  public function bottom_title($args)
  {
    global $asmh;

    if ($asmh->is_preview) {
      return __('Title', ASMH_LANG);

    } else {
      if (is_home() && !is_front_page()) {
        return asmh_blog_page_title();

      } elseif (is_home() || is_front_page()) {
        return $args['home_title'];

      } else {
        if (is_category()) {
          return single_cat_title('', false);
        }

        elseif (is_tag()) {
          return single_tag_title('', false);
        }

        elseif (is_day()) {
          return get_the_time('F jS, Y');
        }

        elseif (is_month()) {
          return get_the_time('F, Y');
        }

        elseif (is_year()) {
          return get_the_time('Y');
        }

        elseif (is_author()) {
          return __('Author', ASMH_LANG);
        }

        else {
          if (function_exists('is_woocommerce') && is_woocommerce()) {
            if (is_shop()) {
              return asmh_shop_title();
            } elseif (is_product()) {
              return get_the_title();
            } elseif (is_product_category()) {
              return single_cat_title('', false);
            } elseif (is_product_tag()) {
              return single_tag_title('', false);
            }
          } else
          return get_the_title();
        }
      }
    }
  }


  public function sub_menu($menu_items, $args)
  {
    if (!isset($args->sub_menu)) {
      return $menu_items;
    }

    $root_id = 0;

    foreach ($menu_items as $menu_item)
    {
      if ($menu_item->current) {
        $root_id = ($menu_item->menu_item_parent) ?
          $menu_item->menu_item_parent : $menu_item->ID;
        break;
      }
    }

    if (!isset($args->direct_parent)) {
      $prev_root_id = $root_id;

      while ($prev_root_id != 0)
      {
        foreach ($menu_items as $menu_item)
        {
          if ($menu_item->ID == $prev_root_id)
          {
            $prev_root_id = $menu_item->menu_item_parent;

            if ($prev_root_id != 0) {
              $root_id = $menu_item->menu_item_parent;
            }

            break;
          }
        }
      }
    }

    $menu_item_parents = array();

    foreach ($menu_items as $key => $item)
    {
      if ($item->ID == $root_id) {
        $menu_item_parents[] = $item->ID;
      }

      if (in_array($item->menu_item_parent, $menu_item_parents))
      {
        $menu_item_parents[] = $item->ID;
      }
      else if (!(isset($args->show_parent) &&
        in_array($item->ID, $menu_item_parents)))
      {
        unset($menu_items[$key]);
      }
    }

    if (!array_values($menu_items)) {
      return $menu_items;
    }

    $current_menu_item = array_filter($menu_items, function($item) {
      return $item->current === true;
    });

    $current_menu_item = array_shift($current_menu_item);

    if ($current_menu_item instanceof \WP_Post) {
      $show_id = $current_menu_item->ID;
    }

    // Remove sub-children
    if (!isset($show_id)) $show_id = array_values($menu_items)[0]->menu_item_parent;

    $menu_items = array_filter($menu_items, function($item) use ($show_id) {
      return $item->menu_item_parent == $show_id;
    });

    return apply_filters('asmh_bottom_submenu_items', $menu_items);
  }
}
