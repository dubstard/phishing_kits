<?php
global $asmh;
$s = $settings = $asmh->settings;
$c = $asmh->customizer;

// php version < 5.5 produces error on empty function
// "Can't use function return value in write context"
function _asmh_empty_s($val) {
    if (!isset($val)) return true;
    return empty($val);
}
?>
.asmh-header
{
  min-height: <?php echo $s['middle_height'] + $c::header_height('top') + $c::header_height('bottom'); ?>px;
<?php if ($s['position'] == 'center') { ?>
  margin: 0 auto;
  max-width: <?php if ($s['stretch']) echo '100%;'; else {
    echo empty($s['width'])? '100%' : $c::num_to_px($s['width']);
  } ?>;
<?php } else { ?>
  width: 100%;
<?php } ?>
  overflow: visible;
}

.asmh-header > div
{
<?php if ($s['position'] == 'center') { ?>
  width: 100%;
<?php } else { ?>
  width: <?php echo empty($s['width'])? '100%' : $c::num_to_px($s['width']); ?>;
<?php } ?>
<?php if ($s['position'] == 'center') { ?>
  margin: 0 auto;
<?php } elseif ($s['position'] == 'right') { ?>
  float: right;
<?php } ?>
}

.asmh-header.sticky > div.stick
{
  position: fixed;
  max-width: 100%;
<?php if (is_admin_bar_showing()) { ?>
  top: 32px;
<?php } else { ?>
  top: 0;
<?php } ?>
  z-index: 99;
<?php if ($asmh->settings['sticky_animate']) { ?>
  -webkit-transition: top .5s ease-in-out;
  -moz-transition: top .5s ease-in-out;
  -o-transition: top .5s ease-in-out;
  transition: top .5s ease-in-out;
<?php } ?>
<?php if ($s['position'] == 'left' || $s['position'] == 'right') { ?>
  width: <?php echo $c::num_to_px($s['width']); ?>;
<?php } ?>
<?php if ($s['position'] == 'left') { ?>
  left: 0;
<?php } else ?>
<?php if ($s['position'] == 'right') { ?>
  right: 0;
<?php } else { ?>
  left: 0;
<?php } ?>
}

.asmh-header .brand img
{
  max-width: <?php echo $s['logo_max_width']; ?>px;
}

<?php if ($s['logo_type'] == 'image') { ?>
.asmh-header .stick .middle .brand
{
  font-size: 0;
}
<?php } ?>

<?php if ($s['hide_top_sticky']) { ?>
.asmh-header.sticky > div.stick .top
{
  display: none;
}
<?php } ?>

<?php if ($s['hide_bottom_sticky']) { ?>
.asmh-header.sticky > div.stick .bottom
{
  display: none;
}
<?php } ?>

.asmh-header a
{
<?php if ($s['hover_transition']) { ?>
  transition: color 0.2s linear;
<?php } ?>
  text-decoration: none;
}

.asmh-header ul > li > a,
.asmh-header ul > li > a > span
{
  display: inline-block;
}

.asmh-header .container:after
{
  clear: both;
}

.asmh-header .primary:after,
.asmh-header .primary:after ul
{
  clear: both;
}

.asmh-header .primary li
{
  position: relative;
}

.asmh-header, .asmh-header .container
{
  -moz-box-sizing: border-box;
  -webkit-box-sizing: border-box;
  box-sizing: border-box;
}

.asmh-header ul:before, .asmh-header ul:after,
.asmh-header nav:before, .asmh-header nav:after,
.asmh-header div:before, .asmh-header div:after
{
  content: " ";
  display: table;
  -moz-box-sizing: border-box;
  -webkit-box-sizing: border-box;
  box-sizing: border-box;
}

.asmh-header .container
{
  position: relative;
<?php if ($s['stretch'] && !empty($s['width'])) { ?>
  max-width: <?php echo $c::num_to_px($s['width']); ?>;
<?php } else { ?>
  width: 100%;
<?php } ?>
  margin-left: auto;
  margin-right: auto;
  padding-left: 15px;
  padding-right: 15px;
}

.asmh-header .stick .container
{
  max-width: <?php if (empty($s['width'])) echo '100%';
    else echo $c::num_to_px($settings['width']); ?>;
}



/***************************        *****************************/
/*************************** MIDDLE *****************************/
/***************************        *****************************/



.asmh-header .middle
{
<?php if (!empty($s['middle_text_color'])) { ?>
  color: <?php echo $c::to_color($s['middle_text_color']); ?>;
<?php } ?>
  font-size: <?php echo $c::num_to_px($s['middle_text_size']); ?>;
  border-top-style: solid;
  border-bottom-style: solid;
<?php if (!_asmh_empty_s($c::to_color($s['middle_top_border_color']))) { ?>
  border-top-color: <?php echo $c::to_color($s['middle_top_border_color']); ?>;
<?php } ?>
<?php if (!_asmh_empty_s($c::to_color($s['middle_bottom_border_color']))) { ?>
  border-bottom-color: <?php echo $c::to_color($s['middle_bottom_border_color']); ?>;
<?php } ?>
<?php if ($c::to_color($s['middle_top_border_width'])) { ?>
  border-top-width: <?php echo $c::num_to_px($s['middle_top_border_width']); ?>;
<?php } else { ?>
  border-top-width: 0px;
<?php } ?>
<?php if ($c::to_color($s['middle_bottom_border_width'])) { ?>
  border-bottom-width: <?php echo $c::num_to_px($s['middle_bottom_border_width']); ?>;
<?php } else { ?>
  border-bottom-width: 0px;
<?php } ?>
}

.asmh-header .middle
{
  background-color: <?php echo $c::to_color($s['middle_background_color']); ?>;
<?php if (!$s['middle_transparency_level_on_sticky']) { ?>
  background-color: rgba(<?php
      echo $c::hex2rgb(
              $s['middle_background_color'],
              $s['middle_transparency_level']
      ); ?>);
<?php } ?>
  display: <?php echo $c::block_from_bool($s['middle_enabled']); ?>;
  <?php if (!empty($s['middle_background_image'])) {
    echo 'background-image: '
      . $c::to_url($s['middle_background_image']) . ';';
  } ?>
  background-repeat: <?php echo $s['middle_background_repeat']; ?>;
}

<?php if ($s['middle_transparency_level_on_sticky']) { ?>
.asmh-header .stick .middle
{
  background-color: rgba(<?php
      echo $c::hex2rgb(
              $s['middle_background_color'],
              $s['middle_transparency_level']
      ); ?>);
}
<?php } ?>

.asmh-header .nav-wrap
{
  overflow: hidden;
<?php if ($s['middle_position'] == 'left') { ?>
  float: right;
  text-align: right;
<?php } elseif ($s['middle_position'] == 'center') { ?>
  float: none;
  margin: 0 auto;
  text-align: center;
<?php } else { ?>
  float: left;
<?php } ?>
  padding: <?php echo $s['brand_padding']; ?>px 0;
}

.asmh-header .stick .nav-wrap
{
  padding: <?php echo $s['brand_padding_sticky']; ?>px 0;
}

.asmh-header .brand
{
  display: block;
  font-size: <?php echo $c::num_to_px($s['site_title_font_size']); ?>;
  line-height: 1;
}

<?php if ($s['middle_position'] == 'center' && !$s['show_description']) { ?>
.asmh-header .brand img
{
  vertical-align: middle;
}
<?php } ?>

.asmh-header .description
{
  font-size: <?php echo $s['site_desc_font_size']; ?>px;
  margin: 0;
  line-height: 1;
<?php if (!empty($s['middle_text_color'])) { ?>;
  color: <?php echo $c::to_color($s['middle_text_color']); ?>;
<?php } ?>
}

@media (max-width: <?php echo $c::num_to_px($s['middle_hide_menu_width']); ?>)
{
  .asmh-header .description
  {
    line-height: 2;
  }
}

.asmh-header .brand img
{
  height: auto;
}

<?php if ($s['middle_position'] != 'center') { ?>
<?php if (!$s['show_description']) { ?>
.asmh-header .brand img
{
  vertical-align: middle;
}
<?php } ?>

.asmh-header .stick .brand img
{
  width: 80%;
  padding: 5px 0;
}
<?php } ?>

.asmh-header .primary
{
  overflow: visible;
}

.asmh-header .primary > ul
{
<?php if ($s['middle_position'] == 'left') { ?>
  float: left;
  margin:  0 0 0 <?php echo -1 * $s['header_paddings']; ?>px;
<?php } elseif ($s['middle_position'] == 'center') { ?>
  float: none;
  text-align: center;
  margin: 0;
<?php } else { ?>
  float: right;
  margin: 0;
<?php } ?>
  padding: 0;
  list-style: none;
}

.asmh-header .primary > ul > li
{
<?php if ($s['middle_position'] == 'center') { ?>
  float: none;
  display: inline-block;
<?php } else { ?>
  float: left;
  display: block;
<?php } ?>
  text-align: left;
  position: relative;
  padding: <?php echo $s['menu_padding']; ?>px 0;
<?php if ($s['hover_transition']) { ?>
  transition: background-color 0.4s ease-in-out;
<?php } ?>
}

<?php if (!empty($s['middle_menu_item_background_active_color'])) { ?>
.asmh-header .primary > ul > li.active,
.asmh-header .primary > ul > li.current-menu-item,
.asmh-header .primary > ul > li.current_page_item
{
  background-color: #<?php echo $s['middle_menu_item_background_active_color']; ?>;
}
<?php } ?>

<?php if (!empty($s['middle_menu_item_background_color'])) { ?>
.asmh-header .primary > ul > li:hover
{
  background-color: #<?php echo $s['middle_menu_item_background_color']; ?>;
}
<?php } ?>

.asmh-header .primary > ul > li.search:hover,
.asmh-header .primary > ul > li.secondary:hover
{
  background-color: transparent !important;
}

<?php if ($s['middle_position'] == 'right') { ?>
.asmh-header .primary > ul > li:last-child
{
  padding-right: 0 !important;
}
<?php } ?>

<?php if ($s['middle_position'] == 'left') { ?>
.asmh-header .primary > ul > li:first-child
{
  padding-left: 0 !important;
}
<?php } ?>

@media (max-width: <?php echo $c::num_to_px($s['middle_hide_menu_width']); ?>)
{
  .asmh-header .primary > ul > li.secondary.dropdown
  {
    padding: 0;
    margin-top: 0;
    width: 100%;
    height: auto;
  }
}

.asmh-header .primary > ul > li.search
{
  line-height: 1;
}

@media (max-width: <?php echo $c::num_to_px($s['middle_hide_menu_width']); ?>) {
  .asmh-header .primary > ul > li.search
  {
    line-height: normal;
  }
}

.asmh-header .primary > ul > li.search > a
{
  display: inline-block;
  padding-bottom: 0;
  vertical-align: top;
}

.asmh-header .primary > ul > li.search
{
  background-color: transparent;
}

.asmh-header .primary > ul > li.search > a:before
{
  display: inline-block;
  vertical-align: middle;
  margin-top: -1px;
}

.asmh-header .primary > ul > li.search form
{
  width: 0;
  visibility: hidden;
  display: inline-block;
  overflow: visible !important;
  bottom: 0px;
  position: relative;
  padding: 0;
<?php if (!empty($s['middle_link_color'])) { ?>
  border-bottom: 1px solid <?php echo $c::to_color($s['middle_link_color']); ?>;
<?php } else { ?>
  border-bottom: 1px solid gray;
<?php } ?>
  transition: all 0.4s ease;
  -o-transition: all 0.4s ease;
  -moz-transition: all 0.4s ease;
  -webkit-transition: all 0.4s ease;
}

.asmh-header .stick .primary > ul > li.search form
{
  bottom: 2px;
}

@media (max-width: <?php echo $c::num_to_px($s['middle_hide_menu_width']); ?>)
{
  .asmh-header .primary > ul > li.search.a form
  {
    margin: 6px 0;
  }
}

<?php if (!$s['search_on_click']) { ?>
.asmh-header .primary > ul > li.search:hover form,
<?php } ?>
.asmh-header .primary > ul > li.search.a form,
.asmh-header .primary > ul > li.search.plain form
{
  width: 180px;
  visibility: visible;
}

@media (max-width: <?php echo $c::num_to_px($s['middle_hide_menu_width']); ?>)
{
<?php if (!$s['search_on_click']) { ?>
  .asmh-header .primary > ul > li.search:hover form,
<?php } ?>
  .asmh-header .primary > ul > li.search.a form,
  .asmh-header .primary > ul > li.search.plain form
  {
    width: 80%;
  }
}

.asmh-header .primary > ul > li.search.plain form
{
  border-bottom: 0 none;
  bottom: 4px;
  margin-left: 10px;
}

.asmh-header .stick .primary > ul > li.search.plain form
{
  bottom: 5px;
}

.asmh-header .primary > ul > li.search.plain form input
{
  border: 1px solid;
  padding-top: 2px;
  padding-bottom: 2px;
  padding-right: 25px;
  padding-left: 5px;
}

.asmh-header .primary > ul > li.search.plain a.icon-search
{
  position: absolute;
  bottom: 9px;
  right: 4px;
  opacity: 0.5;
}

@media (max-width: <?php echo $c::num_to_px($s['middle_hide_menu_width']); ?>)
{
  .asmh-header .primary > ul > li.search.plain a.icon-search
  {
    position: relative;
    bottom: auto;
    right: auto;
    opacity: 1.0;
  }

  .asmh-header .primary > ul > li.search.plain form
  {
    margin-left: 0;
    bottom: auto;
    margin-top: auto;
    margin-bottom: auto;
    padding-top: 7px;
    padding-bottom: 7px;
  }

  .asmh-header .primary > ul > li.search.plain form input
  {
    padding-right: 5px;
    margin: 0 0 0;
  }
}

.asmh-header .stick .primary > ul > li.search.plain a.icon-search
{
  bottom: 11px;
}

.asmh-header .primary > ul > li.search.below form
{
  position: absolute;
  border-bottom: 0 none;
  bottom: -20px;
}

.asmh-header .primary > ul > li.search.below a
{
  cursor: pointer;
}

.asmh-header .search-wrap
{
  position: absolute;
  z-index: 1;
  right: <?php echo $s['header_paddings']; ?>px;
<?php if (!empty($s['middle_bottom_border_color'])) { ?>
  border: 1px solid #<?php echo $s['middle_bottom_border_color']; ?>;
<?php } ?>
  display: none;
  padding: 20px;
<?php if (!empty($s['middle_background_color'])) { ?>
  background-color: <?php echo $c::to_color($s['middle_background_color']); ?>;
<?php if (!$s['middle_transparency_level_on_sticky']) { ?>
  background-color: rgba(<?php
      echo $c::hex2rgb(
              $s['middle_background_color'],
              $s['middle_transparency_level']
           ); ?>);
<?php } ?>
<?php } ?>
}

.asmh-header .primary > ul > li.search.click a
{
  cursor: pointer;
}
<?php if ($s['search_on_click']) { ?>
.asmh-header .primary > ul > li.search a
{
  cursor: pointer;
}
<?php } ?>

.asmh-header .primary > ul > li.search:hover > .icon-search,
.asmh-header .primary > ul > li.search.a > .icon-search
{
  position: relative;
}

@media (max-width: <?php echo $c::num_to_px($s['middle_hide_menu_width']); ?>)
{
  .asmh-header .primary > ul > li.search:hover > .icon-search,
  .asmh-header .primary > ul > li.search.a > .icon-search
  {
    margin-left: 0;
    left: 0;
  }
}

.asmh-header .primary > ul > li.search.a form input
{
  visibility: visible;
}

.asmh-header .primary > ul > li.search > div:before,
.asmh-header .primary > ul > li.search > div:after
{
  content: "";
  display: none;
}

.asmh-header .primary > ul > li.search > div
{
  position: relative;
  width: 1px;
  height: 5px;
  bottom: -9px;
  display: none;
<?php if (!empty($s['middle_link_color'])) { ?>
  border-right: 1px solid <?php echo $c::to_color($s['middle_link_color']); ?>;
<?php } else { ?>
  border-right: 1px solid gray;
<?php } ?>
}

.asmh-header .primary > ul > li.search:hover > div,
.asmh-header .primary > ul > li.search.a > div
{
  display: inline-block;
}

.asmh-header .primary > ul > li.search form input
{
  width: 100%;
  border: none;
<?php if ( !empty($s['middle_text_color']) ) { ?>
  color: <?php echo $c::to_color($s['middle_text_color']); ?>;
<?php } ?>
  background: transparent;
  -webkit-box-shadow: none;
  -moz-box-shadow: none;
  box-shadow: none;
  padding: 0 7px;
  margin: 0 0 2px;
  font-size: <?php echo $c::num_to_px($s['middle_text_size'] - 2); ?>;
<?php if ($s['middle_position'] == 'center') { ?>
  height: 32px;
<?php } ?>
}

.asmh-header .primary > ul > li.search.underline form input
{
  padding-left: 5px;
  padding-right: 5px;
}

.asmh-header .stick .primary > ul > li.search form input
{
  font-size: <?php echo $s['middle_font_size_sticky']; ?>px;
}

@media (max-width: <?php echo $c::num_to_px($s['middle_hide_menu_width']); ?>)
{
  .asmh-header .primary > ul > li.search form input
  {
    padding: 0 7px;
  }
}

<?php if (!empty($s['middle_text_color'])) { ?>
.asmh-header input[type="text"]
{
  color: <?php echo $c::to_color($s['middle_text_color']); ?>;
}
<?php } ?>

@media (max-width: <?php echo $c::num_to_px($s['middle_hide_menu_width']); ?>)
{
  .asmh-header .primary > ul > li
  {
    padding: 0;
  }
}

<?php if ($s['middle_position'] == 'center') { ?>
.asmh-header .primary > ul > li.search
{
  padding: <?php echo $s['menu_padding'] - 10; ?>px 10px;
}
<?php } else { ?>
.asmh-header .primary > ul > li.search
{
  padding: <?php echo $s['menu_padding']; ?>px 0 0;
}
<?php } ?>

@media (max-width: <?php echo $c::num_to_px($s['middle_hide_menu_width']); ?>)
{
  .asmh-header .primary > ul > li.search > a
  {
    padding: 10px <?php echo $c::num_to_px($s['header_paddings']); ?> !important;
  }

  .asmh-header .primary > ul > li.search
  {
    padding: 0;
  }
}

.asmh-header .primary > ul > li > a
{
<?php if (!empty($s['middle_link_color'])) { ?>
  color: <?php echo $c::to_color($s['middle_link_color']); ?>;
<?php } ?>
  font-size: <?php echo $c::num_to_px($s['middle_text_size']); ?>;
  padding: 0 <?php echo $c::num_to_px($s['middle_items_padding']); ?>;
  line-height: 1;
  display: block;
<?php if ($s['hover_transition']) { ?>
  transition: color 0.4s ease-in-out;
<?php } ?>
}

.asmh-header .stick .primary > ul > li > a
{
  padding: 0 <?php echo $c::num_to_px($s['middle_items_padding_sticky']); ?>;
}

.asmh-header .stick .primary > ul > li > a
{
  font-size: <?php echo $c::num_to_px($s['middle_font_size_sticky']); ?>;
}

.asmh-header .primary > ul > li.search > a
{
  padding: 0 0 0 <?php echo $c::num_to_px($s['middle_items_padding']); ?>;
}

.asmh-header .primary .sub-menu li > a
{
<?php if (!empty($s['middle_link_color'])) { ?>
  color: <?php echo $c::to_color($s['middle_link_color']); ?>;
<?php } ?>
  font-size: <?php echo $c::num_to_px($s['middle_text_size'] - 2); ?>;
  padding: 10px;
  line-height: 1;
  display: block;
}

.asmh-header .primary li .desc
{
  margin: 0;
  line-height: 1;
<?php if (!empty($s['middle_text_color'])) { ?>
  color: <?php echo $c::to_color($s['middle_text_color']); ?>;
<?php } ?>
  font-size: <?php echo $c::num_to_px($s['middle_text_size'] - 4); ?>;
}

.asmh-header .primary div.sub-menu
{
  padding: 10px;
}

.asmh-header .primary div.sub-menu ul
{
  padding: 0;
  margin: 0;
}

.asmh-header .primary div.sub-menu li > a
{
  padding: 10px 0;
  line-height: 1;
}

<?php if ($s['logo_type'] == 'image') { ?>
.asmh-header .stick .middle .brand,
.asmh-header .stick .middle .brand img
{
  vertical-align: middle;
  display: inline-block;
}
<?php } ?>

.asmh-header .stick .primary > ul > li
{
  padding: <?php echo $s['menu_padding_sticky']; ?>px 0;
}

<?php if ($s['middle_position'] == 'center') { ?>
.asmh-header .stick .primary > ul > li.search
{
  padding: <?php echo $s['menu_padding_sticky'] - 10; ?>px 0;
}
<?php } else { ?>
.asmh-header .stick .primary > ul > li.search
{
  padding: <?php echo $s['menu_padding_sticky']; ?>px 0 0 0;
}
<?php } ?>

.asmh-header .primary .sub-menu li
{
<?php if ($s['hover_transition']) { ?>
  transition: background-color 0.2s;
<?php } ?>
<?php if ($s['middle_position'] == 'center') { ?>
  text-align: left;
<?php } ?>
}

.asmh-header .primary .sub-menu li > a:hover
{
<?php if (!empty($s['middle_submenu_hover_color'])) { ?>
  background: <?php echo $c::to_color($s['middle_submenu_hover_color']); ?>;
<?php } else { ?>
  background: transparent;
<?php } ?>
}

<?php if (!empty($s['middle_submenu_hover_color'])) { ?>
@media (max-width: <?php echo $c::num_to_px($s['middle_hide_menu_width']); ?>) {
  .asmh-header .primary li > a:hover
  {
    background: <?php echo $c::to_color($s['middle_submenu_hover_color']); ?>;
  }
}
<?php } ?>

.asmh-header .primary .dropdown .sub-menu > li .sub-menu
{
  display: none;
  top: 0;
<?php if ($s['sub_menu_orientation'] == 'right') { ?>
  left: 100%;
<?php } else { ?>
  left: -100%;
<?php } ?>
  margin-top: -6px;
}

.asmh-header .primary .secondary.dropdown
{
  position: relative;
  width: 35px;
  padding: <?php echo $s['menu_padding']; ?>px 0 0;
}

.asmh-header .stick .primary .secondary.dropdown
{
  width: 25px;
  padding: <?php echo $s['menu_padding_sticky']; ?>px 0 0;
}

.asmh-header .primary .secondary.dropdown > a.icon-ellipsis-vert:before
{
  padding: 0;
}

.asmh-header .primary .secondary.dropdown > a.icon-ellipsis-vert
{
  position: absolute;
  right: 0;
  top: <?php echo $s['menu_padding'] - 12; ?>px;
  margin: 0;
  padding: 12px;
}

.asmh-header .stick .primary .secondary.dropdown > a.icon-ellipsis-vert
{
  top: <?php echo $s['menu_padding_sticky'] - 5; ?>px;
  padding: 5px 8px;
}

@media (max-width: <?php echo $c::num_to_px($s['middle_hide_menu_width']); ?>)
{
  .asmh-header .primary .secondary.dropdown > a.icon-ellipsis-vert
  {
    display: none;
  }
}

.asmh-header .primary .secondary.dropdown:hover > a.icon-ellipsis-vert
{
  padding-top: 11px;
  background-color: #<?php echo $s['middle_background_color']; ?>;
<?php if ($s['middle_bottom_border_width'] > 0) { ?>
  border: 1px solid #<?php echo $s['middle_bottom_border_color']; ?>;
  border: 1px solid rgba(<?php echo $c::hex2rgb($s['middle_bottom_border_color']); ?>, 0.3);
<?php } elseif ($s['middle_top_border_width'] > 0) { ?>
  border: 1px solid #<?php echo $s['middle_bottom_border_color']; ?>;
  border: 1px solid rgba(<?php echo $c::hex2rgb($s['middle_top_border_color']); ?>, 0.3);
<?php } else { ?>
  border: 1px solid rgb(0,0,0);
  border: 1px solid rgba(0,0,0, 0.3);
<?php } ?>
  border-bottom: none;
  right: -1px;
  z-index: 6;
}

.asmh-header .stick .primary .secondary.dropdown:hover > a.icon-ellipsis-vert
{
  padding-top: 4px;
}

.asmh-header .middle .primary .secondary.dropdown .sub-menu
{
  left: auto;
<?php if ($s['middle_position'] != 'center') { ?>
  right: -1px;
<?php } else { ?>
  right: 10px;
<?php } ?>
<?php if (!empty($s['middle_background_color'])) { ?>
  background-color: #<?php echo $s['middle_background_color']; ?>;
<?php } ?>
<?php if (!empty($s['middle_text_color'])) { ?>
  color: #<?php echo $s['middle_text_color']; ?>;
<?php } ?>
}

<?php if (!empty($s['middle_link_color'])) { ?>
.asmh-header .middle .primary .secondary.dropdown .sub-menu a
{
  color: #<?php echo $s['middle_link_color']; ?>;
}
<?php } ?>

<?php if (!empty($s['middle_hover_color'])) { ?>
.asmh-header .middle .primary .secondary.dropdown .sub-menu a:hover
{
  color: #<?php echo $s['middle_hover_color']; ?>;
}
<?php } ?>

.asmh-header .primary .secondary.dropdown:hover .sub-menu
{
  z-index: 5;
<?php if ($s['middle_bottom_border_width'] > 0) { ?>
  border: 1px solid #<?php echo $s['middle_bottom_border_color']; ?>;
  border: 1px solid rgba(<?php echo $c::hex2rgb($s['middle_bottom_border_color']); ?>, 0.3);
<?php } elseif ($s['middle_top_border_width'] > 0) { ?>
  border: 1px solid #<?php echo $s['middle_bottom_border_color']; ?>;
  border: 1px solid rgba(<?php echo $c::hex2rgb($s['middle_top_border_color']); ?>, 0.3);
<?php } else { ?>
  border: 1px solid rgb(0,0,0);
  border: 1px solid rgba(0,0,0, 0.3);
<?php } ?>
}

@media (max-width: <?php echo $c::num_to_px($s['middle_hide_menu_width']); ?>)
{
  .asmh-header .primary .secondary.dropdown:hover .sub-menu
  {
    border: 0 none;
    margin-top: 0;
  }
}

.asmh-header .primary .sub-menu li:hover .sub-menu
{
  display: block;
}

.asmh-header .primary .dropdown .sub-menu > li .sub-menu .sub-menu
{
  display: none;
}

.asmh-header .primary .dropdown .sub-menu > li .sub-menu li:hover .sub-menu
{
  display: block;
}

<?php if (!empty($s['site_title_text_color'])) { ?>
.asmh-header .middle .brand
{
  color: <?php echo $c::to_color($s['site_title_text_color']); ?>;
}
<?php } ?>

<?php if (!empty($s['site_desc_text_color'])) { ?>
.asmh-header .description
{
  color: #<?php echo $s['site_desc_text_color']; ?>;
}
<?php } ?>

<?php if (!empty($s['middle_hover_color'])) { ?>
.asmh-header .middle .brand:hover,
.asmh-header .primary ul > li > a:hover
{
  color: <?php echo $c::to_color($s['middle_hover_color']); ?>;
}
<?php } ?>

<?php if (!empty($s['middle_active_color'])) { ?>
.asmh-header .primary .current-menu-item > a,
.asmh-header .primary .current-menu-parent > a,
.asmh-header .primary .current-menu-ancestor > a
{
  color: <?php echo $c::to_color($s['middle_active_color']); ?> !important;
}
<?php } ?>

.asmh-header .middle .sub-menu
{
  position: absolute;
  top: 100%;
  left: 0;
  z-index: 1000;
  display: none;
  float: left;
  min-width: 180px;
  padding: 5px 0;
  margin: 0;
  list-style: none;
  font-size: 14px;
  background-color: <?php echo $c::to_color($s['middle_submenu_background_color']); ?>;
<?php if (!$s['submenu_transparency_level_on_sticky']) { ?>
  background-color: rgba(<?php
      echo $c::hex2rgb(
              $s['middle_submenu_background_color'],
              $s['submenu_transparency_level']
           ); ?>);
<?php } ?>
  border: 1px solid <?php echo $c::to_color($s['middle_bottom_border_color']); ?>;
  border: 1px solid rgba(<?php echo $c::hex2rgb($s['middle_bottom_border_color']); ?>, 0.3);
  border-radius: 2px;
  -webkit-box-shadow: 0 3px 6px rgba(0,0,0,0.175);
  box-shadow: 0 3px 6px rgba(0,0,0,0.175);
  background-clip: padding-box;
}

.asmh-header .stick .middle .secondary .sub-menu
{
  min-width: 140px;
  padding: 5px;
}

<?php if ($s['submenu_transparency_level_on_sticky']) { ?>
.asmh-header .stick .middle .sub-menu
{
  background-color: rgba(<?php
      echo $c::hex2rgb(
              $s['middle_submenu_background_color'],
              $s['submenu_transparency_level']
           ); ?>);
}
<?php } ?>

.asmh-header .middle .dropdown:hover .sub-menu
{
  display: block;
  margin-top: 0;
  border-top-right-radius: 0;
  border-top-left-radius: 0;
  border-top-color: <?php echo $c::to_color($s['middle_bottom_border_color']); ?>;
}

/***************************     *****************************/
/*************************** TOP *****************************/
/***************************     *****************************/


.asmh-header .top
{
  background-color: <?php echo $c::to_color($s['top_background_color']); ?>;
<?php if (!$s['top_transparency_level_on_sticky']) { ?>
  background-color: rgba(<?php
      echo $c::hex2rgb(
              $s['top_background_color'],
              $s['top_transparency_level']
      ); ?>);
<?php } ?>
  display: <?php echo $c::block_from_bool($s['top_enabled']); ?>;
  <?php if (!empty($s['top_background_image'])) {
    echo 'background-image: '
      . $c::to_url($s['top_background_image']) . ';';
  } ?>
  background-repeat: <?php echo $s['top_background_repeat']; ?>;
  border-top-style: solid;
  border-bottom-style: solid;
<?php if (!_asmh_empty_s($c::to_color($s['top_top_border_color']))) { ?>
  border-top-color: <?php echo $c::to_color($s['top_top_border_color']); ?>;
<?php } ?>
<?php if (!_asmh_empty_s($c::to_color($s['top_bottom_border_color']))) { ?>
  border-bottom-color: <?php echo $c::to_color($s['top_bottom_border_color']); ?>;
<?php } ?>
<?php if ($c::to_color($s['top_top_border_width'])) { ?>
  border-top-width: <?php echo $c::num_to_px($s['top_top_border_width']); ?>;
<?php } else { ?>
  border-top-width: 0px;
<?php } ?>
<?php if ($c::to_color($s['top_bottom_border_width'])) { ?>
  border-bottom-width: <?php echo $c::num_to_px($s['top_bottom_border_width']); ?>;
<?php } else { ?>
  border-bottom-width: 0px;
<?php } ?>
}

<?php if ($s['top_transparency_level_on_sticky']) { ?>
.asmh-header .stick .top
{
  background-color: rgba(<?php
      echo $c::hex2rgb(
              $s['top_background_color'],
              $s['top_transparency_level']
      ); ?>);
}
<?php } ?>

.asmh-header .top ul li
{
  display: block;
  float: left;
}

.asmh-header .top ul > li > a
{
  font-size: <?php echo $c::num_to_px($settings['top_text_size']); ?>;
<?php if (!empty($s['top_link_color'])) { ?>
  color: <?php echo $c::to_color($s['top_link_color']); ?>;
<?php } ?>
  padding: 0 7px;
}

.asmh-header .stick .top ul > li > a
{
  font-size: <?php echo $c::num_to_px($settings['top_font_size_sticky']); ?>;
}

.asmh-header li > a
{
  box-sizing: content-box;
}

<?php if (!empty($s['top_hover_color'])) { ?>
.asmh-header .top a:hover
{
  color: <?php echo $c::to_color($s['top_hover_color']); ?>;
}
<?php } ?>


/***************************        *****************************/
/*************************** BOTTOM *****************************/
/***************************        *****************************/


.asmh-header .bottom
{
<?php if (!empty($s['bottom_text_color'])) { ?>
  color: <?php echo $c::to_color($s['bottom_text_color']); ?>;
<?php } ?>
  background-color: <?php echo $c::to_color($s['bottom_background_color']); ?>;
<?php if (!$s['bottom_transparency_level_on_sticky']) { ?>
  background-color: rgba(<?php
      echo $c::hex2rgb(
              $asmh->settings['bottom_background_color'],
              $asmh->settings['bottom_transparency_level']
      ); ?>);
<?php } ?>
  display: <?php echo $c::block_from_bool($s['bottom_enabled']); ?>;
  <?php if (!empty($s['bottom_background_image'])) {
    echo 'background-image: '
      . $c::to_url($s['bottom_background_image']) . ';';
  } ?>
  background-repeat: <?php echo $s['bottom_background_repeat']; ?>;
  font-size: <?php echo $c::num_to_px($s['bottom_text_size']); ?>;
  border-top-style: solid;
  border-bottom-style: solid;
<?php if (!_asmh_empty_s($c::to_color($s['bottom_top_border_color']))) { ?>
  border-top-color: <?php echo $c::to_color($s['bottom_top_border_color']); ?>;
<?php } ?>
<?php if (!_asmh_empty_s($c::to_color($s['bottom_bottom_border_color']))) { ?>
  border-bottom-color: <?php echo $c::to_color($s['bottom_bottom_border_color']); ?>;
<?php } ?>
<?php if ($c::to_color($s['bottom_top_border_width'])) { ?>
  border-top-width: <?php echo $c::num_to_px($s['bottom_top_border_width']); ?>;
<?php } else { ?>
  border-top-width: 0px;
<?php } ?>
<?php if ($c::to_color($s['bottom_bottom_border_width'])) { ?>
  border-bottom-width: <?php echo $c::num_to_px($s['bottom_bottom_border_width']); ?>;
<?php } else { ?>
  border-bottom-width: 0px;
<?php } ?>
}

<?php if ($s['bottom_transparency_level_on_sticky']) { ?>
.asmh-header .stick .bottom
{
  background-color: rgba(<?php
      echo $c::hex2rgb(
              $asmh->settings['bottom_background_color'],
              $asmh->settings['bottom_transparency_level']
      ); ?>);
}
<?php } ?>

.asmh-header .bottom a
{
<?php if (!empty($s['bottom_link_color'])) { ?>
  color: <?php echo $c::to_color($s['bottom_link_color']); ?>;
<?php } ?>
}

.asmh-header .bottom
{
  font-size: <?php echo $c::num_to_px($s['bottom_text_size']); ?>;
}

.asmh-header .stick .bottom
{
  font-size: <?php echo $c::num_to_px($s['bottom_font_size_sticky']); ?>;
}

<?php if (!empty($s['bottom_hover_color'])) { ?>
.asmh-header .bottom a:hover
{
  color: <?php echo $c::to_color($s['bottom_hover_color']); ?>;
}
<?php } ?>

.asmh-header .bottom a,
.asmh-header .bottom span
{
  line-height: 1;
  padding: 0 7px;
}

.asmh-header .breadcrumbs
{
  line-height: <?php echo $c::num_to_px($s['bottom_height']); ?>;
}

.asmh-header .bottom .breadcrumbs a,
.asmh-header .bottom .breadcrumbs span
{
  padding: 0;
}

.asmh-header .bottom .breadcrumbs > span
{
  padding: 0 7px;
}

.asmh-header .bottom .breadcrumbs > span:first-child
{
  padding: 0 7px 0 0;
}

@media (max-width: <?php echo $c::num_to_px($s['middle_hide_menu_width']); ?>)
{
  .asmh-header .bottom .breadcrumbs > span:first-child
  {
    padding: 0;
  }
}

.asmh-header .bottom .breadcrumbs span span,
.asmh-header .bottom .breadcrumbs span:first-child span,
.asmh-header .bottom .breadcrumbs span:last-child span
{
  padding: 0;
}

.asmh-header .left
{
  float: left;
}

.asmh-header .right
{
  float: right;
}

.asmh-header .right ul,
.asmh-header .left ul
{
  padding: 0;
  margin: 0;
}

.asmh-header .bottom .header-title
{
  line-height: <?php echo $s['bottom_height']; ?>px;
}

/*************************** CENTERING *****************************/
<?php if (!$s['center_content_bottom']) { ?>
.asmh-header .bottom .left
{
  float: left;
}

.asmh-header .bottom .right
{
  float: right;
}
<?php } else { ?>
.asmh-header .bottom .left,
.asmh-header .bottom .right
{
  float: none;
  text-align: center;
}
<?php } ?>

.asmh-header .bottom li
{
  line-height: <?php echo $c::num_to_px($s['bottom_height']); ?>;
  height: <?php echo $c::num_to_px($s['bottom_height']); ?>;
  margin-bottom: 0;
}

<?php if (!$s['center_content_bottom']) { ?>
.asmh-header .bottom li
{
  display: block;
  float: left;
}
<?php } else { ?>
.asmh-header .bottom li
{
  display: inline-block;
  float: none;
}
<?php } ?>

<?php if (!$s['center_content_top']) { ?>
.asmh-header .top .left
{
  float: left;
}

.asmh-header .top .right
{
  float: right;
}
<?php } else { ?>
.asmh-header .top .left,
.asmh-header .top .right
{
  float: none;
  text-align: center;
}
<?php } ?>

<?php if (!$s['center_content_top']) { ?>
.asmh-header .top .right ul li,
.asmh-header .top .left ul li
{
  display: block;
  float: left;
}
<?php } else { ?>
.asmh-header .top .right ul li,
.asmh-header .top .left ul li
{
  display: inline-block;
  float: none;
}
<?php } ?>

<?php if (!$s['center_content_top']) { ?>
.asmh-header .top ul li:first-child > a
{
  padding-left: 0 !important;
}

.asmh-header .top ul li:last-child > a
{
  padding-right: 0 !important;
}
<?php } ?>

<?php if (!$s['center_content_bottom']) { ?>
.asmh-header .bottom ul li:first-child > a
{
  padding-left: 0 !important;
}

.asmh-header .bottom ul li:last-child > a
{
  padding-right: 0 !important;
}
<?php } ?>
/*************************** /CENTERING ****************************/

.asmh-caret
{
  display: inline-block;
  width: 0;
  height: 0;
  margin-left: 2px;
  vertical-align: middle;
  border-top: 4px solid;
  border-right: 4px solid transparent;
  border-left: 4px solid transparent;
}

.asmh-header .top li
{
  padding: <?php echo $s['top_menu_padding']; ?>px 0;
}

<?php if ($s['use_genericons']) { ?>
<?php echo $c::get_css_a_genericons('header'); ?>
{
<?php if ($s['use_genericons_text']) { ?>
  width: auto;
<?php } else { ?>
  width: <?php echo $s['top_text_size'] + 2; ?>px;
<?php } ?>
  height: <?php echo $s['top_text_size'] + 2; ?>px;
  line-height: <?php echo $s['top_text_size'] + 2; ?>px;
  overflow: hidden;
  text-align: center;
<?php if ($s['use_genericons_text']) { ?>
  padding: 0 7px !important;
<?php } else { ?>
  padding: 0 5px !important;
<?php } ?>
  font-size: <?php echo $s['top_text_size']; ?>px;
  -webkit-font-smoothing: antialiased;
  font-family: 'Genericons';
  vertical-align: middle;
  white-space: nowrap;
  display: inline-block;
  text-decoration: none;
  text-transform: none;
  font-weight: normal;
  font-style: normal;
  font-variant: normal;
  position: relative;
<?php if ($s['use_genericons']) { ?>
  margin-bottom: 2px;
<?php } ?>
  speak: none;
}

<?php echo $c::get_css_a_genericons_before('header'); ?>
{
<?php if ($s['use_genericons_text']) { ?>
  margin-right: 2px;
<?php } else { ?>
  margin-right: 8px;
<?php } ?>
}

.asmh-header li a[href*="twitter.com"]:before {
  content: '\f202';
}
.asmh-header li a[href*="facebook.com"]:before {
  content: '\f203';
}
.asmh-header li a[href*="plus.google.com"]:before {
  content: '\f206';
}
.asmh-header li a[href*="linkedin.com"]:before {
  content: '\f208';
}
.asmh-header li a[href*="pinterest.com"]:before {
  content: '\f210';
}
.asmh-header li a[href*="wordpress.com"]:before,
.asmh-header li a[href*="wordpress.org"]:before {
  content: '\f205';
}
.asmh-header li a[href*="vimeo.com"]:before {
  content: '\f212';
}
.asmh-header li a[href*="youtube.com"]:before {
  content: '\f213';
}
.asmh-header li a[href*="tumblr.com"]:before {
  content: '\f214';
}
.asmh-header li a[href*="instagram.com"]:before {
  content: '\f215';
}
.asmh-header li a[href*="path.com"]:before {
  content: '\f219';
}
.asmh-header li a[href*="reddit.com"]:before {
  content: '\f222';
}
.asmh-header li a[href*="stumbleupon.com"]:before {
  content: '\f223';
}
.asmh-header li a[href*="dribbble.com"]:before {
  content: '\f201';
}
.asmh-header li a[href*="github.com"]:before {
  content: '\f200';
}
<?php } ?>


/***************************            *****************************/
/*************************** RESPONSIVE *****************************/
/***************************            *****************************/

@media (min-width: <?php echo $c::num_to_px($s['middle_hide_menu_width']); ?>)
{
  .asmh-header .primary
  {
    display: block;
  }
}

@media (max-width: <?php echo $c::num_to_px($s['middle_hide_menu_width']); ?>) {
  .asmh-header .primary
  {
    display: none;
    clear: both;
    margin: 0 -<?php echo $c::num_to_px($s['header_paddings']); ?>;
    float: none;
  }

  .asmh-header .primary.expand
  {
    display: block;
    background-color: <?php echo $c::to_color($s['middle_submenu_background_color']); ?>;
  }

  .asmh-header div.nav-wrap
  {
    width: 100%;
    padding: 15px 0;
    margin: 0 auto;
    float: none;
    text-align: center;
  }

  .asmh-header div.brand-wrap
  {
    float: left;
  }

  .asmh-header div.toggle-wrap
  {
    text-align: center;
    display: block;
    margin-top: 10px;
  }

  .asmh-header div.brand-wrap
  {
    float: none;
  }

  .asmh-header div.toggle-wrap
  {
    float: none;
  }

  .asmh-header .primary > ul
  {
    float: none;
    margin: 0;
  }

  .asmh-header .primary > ul > li
  {
    display: block;
    float: none;
    position: relative;
    text-align: left;
  }

  .asmh-header .primary ul > li > a
  {
    line-height: 1;
    padding: 10px <?php echo $c::num_to_px($s['header_paddings']); ?>;
  }

  .asmh-header nav.primary > ul > li:first-child > a
  {
    padding-left: <?php echo $c::num_to_px($s['header_paddings']); ?>;
  }

  .asmh-header .primary ul .sub-menu
  {
    position: static;
    top: 0;
    width: auto;
    float: none;
    display: block !important;
  }

  .asmh-header .primary .dropdown .sub-menu > li .sub-menu
  {
    display: block;
    left: auto;
  }

  .asmh-header .middle .primary > ul,
  .asmh-header .middle li
  {
    border-top: 1px solid rgba(<?php echo $c::hex2rgb($s['middle_bottom_border_color']); ?>, 0.2);
  }

  .asmh-header .middle .menu > li:first-child
  {
    border-top: none;
  }

  .asmh-header .middle .dropdown .sub-menu
  {
    border: none;
    background: none;
    box-shadow: none;
    -webkit-box-shadow: none;
  }

  .asmh-header .middle .dropdown:hover > ul.sub-menu
  {
    margin: 0 !important;
    padding: 0 !important;
  }

  .asmh-header .middle .sub-menu
  {
    padding: 0 0;
    margin: 0 0 0;
  }

  .asmh-header .middle .dropdown > .sub-menu > li > a
  {
    padding-left: <?php echo $c::num_to_px($s['header_paddings'] * 2); ?>;
  }

  .asmh-header .middle .dropdown > .sub-menu > li > .sub-menu > li > a
  {
    padding-left: <?php echo $c::num_to_px($s['header_paddings'] * 3); ?>;
  }

  .asmh-header .middle .dropdown > .sub-menu > li > .sub-menu > li > .sub-menu > li > a
  {
    padding-left: <?php echo $c::num_to_px($s['header_paddings'] * 4); ?>;
  }

  .asmh-header .primary .dropdown .sub-menu > li .sub-menu
  {
    margin-top: 0;
  }

  .asmh-header .primary > ul > li.search form
  {
    margin-top: 2px;
  }

  .asmh-header .top,
  .asmh-header .bottom {
    height: auto;
    text-align: center;
  }

  .asmh-header .top .left ul li,
  .asmh-header .top .right ul li,
  .asmh-header .bottom .left ul li,
  .asmh-header .bottom .right ul li,
  .asmh-header .top .left,
  .asmh-header .top .right,
  .asmh-header .bottom .left,
  .asmh-header .bottom .right {
    float: none;
  }

  .asmh-header .top .left,
  .asmh-header .top .right,
  .asmh-header .bottom .left,
  .asmh-header .bottom .right {
    overflow: hidden;
    text-align: center;
  }

  .asmh-header .top .left ul li,
  .asmh-header .top .right ul li,
  .asmh-header .bottom .left ul li,
  .asmh-header .bottom .right ul li
  {
    display: inline-block;
  }

  .asmh-header .top .left ul li:first-child,
  .asmh-header .top .right ul li:last-child
  {
    padding: 0 4px;
  }
}



/*************************** TOGGLE *****************************/

.asmh-header .toggle-wrap
{
  float: right;
  display: none;
  padding: 0;
}

.asmh-header .toggle
{
  background-color: transparent;
  background: transparent;
  padding: 0;
  border: none;
  height: 18px;
  width: 18px;
  margin: auto;
  cursor: pointer;
  position: relative;
}

.asmh-header .toggle .icon-bar {
  display: block;
  position: absolute;
  height: 2px;
  width: 100%;
  background: <?php echo $c::to_color($s['hamburger_color']); ?>;
  border-radius: 9px;
  opacity: 1;
  left: 0px;
  transform: rotate(0deg);
  transition: all 0.25s ease-in-out 0s;
}

.asmh-header .toggle .icon-bar:nth-child(1) {
  top: 0px;
}

.asmh-header .toggle .icon-bar:nth-child(2),
.asmh-header .toggle .icon-bar:nth-child(3) {
  top: 5px;
}

.asmh-header .toggle .icon-bar:nth-child(4) {
  top: 10px;
}

.asmh-header .toggle.open .icon-bar:nth-child(1) {
  top: 5px;
  width: 0%;
  left: 50%;
}

.asmh-header .toggle.open .icon-bar:nth-child(2) {
  -webkit-transform: rotate(45deg);
  -moz-transform: rotate(45deg);
  -o-transform: rotate(45deg);
  transform: rotate(45deg);
}

.asmh-header .toggle.open .icon-bar:nth-child(3) {
  -webkit-transform: rotate(-45deg);
  -moz-transform: rotate(-45deg);
  -o-transform: rotate(-45deg);
  transform: rotate(-45deg);
}

.asmh-header .toggle.open .icon-bar:nth-child(4) {
  top: 5px;
  width: 0%;
  left: 50%;
}

/*************************** END TOGGLE *****************************/


<?php
//
// Custom CSS
//
if (!empty($s['custom_css'])) {
  echo $s['custom_css'];
}
