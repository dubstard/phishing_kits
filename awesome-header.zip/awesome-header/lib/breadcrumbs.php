<?php
namespace ASMH;



class Breadcrumbs {

  public static function get_html($force_print = false) {
    global $asmh;
    $args = self::set_args();

    if ($force_print !== true) {
        if ($asmh->settings['bottom_left'] == 'breadcrumbs') {
          $args['side'] = 'left';

        } elseif ($asmh->settings['bottom_right'] == 'breadcrumbs') {
          $args['side'] = 'right';

        } else {
          return;
        }
    }

    $home = is_home();
    $front = is_front_page();

    $result = '<' . $args['tag'] . ' class="' . $args['class'] . ' ' . $args['side'] . '">';

    if ($args['show_home']) {
      $result .= '<span ' . self::vocab_scope() . '>'
          . '<a href="' . get_home_url() . '" ' . self::vocab_url() . '>'
              . '<span ' . self::vocab_title() . '>' . __('Home', ASMH_LANG) . '</span>'
          . '</a>'
      . '</span>';
    }

    $result .= Breadcrumbs::get_path($args);

    $result .= '</' . $args['tag'] . '>';

    return apply_filters('asmh_breadcrumbs', $result);
  }


  public static function get_html_preview($side) {
    $args = self::set_args ();

    $result = '<' . $args ['tag'] . ' class="' . $args ['class'] . ' ' . $side . '">';

    $result .= '<span><a href="#">' . __ ( 'Home', ASMH_LANG ) . '</a></span>';

    $result .= $args ['separator'];

    $result .= '<span>' . __ ( 'Blog', ASMH_LANG ) . '</span>';

    $result .= '</' . $args ['tag'] . '>';

    return apply_filters ( 'asmh_breadcrumbs', $result );
  }


  public static function set_args() {
    $defaults = array (
        'show_home' => true,
        'tag' => 'nav',
        'class' => 'breadcrumbs',
        'separator' => ' &rarr; ',
        'not_found' => __ ( 'Not found', ASMH_LANG ),
        'show_not_found' => true,
        'archive_text' => '',
        'category_text' => '',
        'tag_text' => '',
        'side' => ''
    );

    return wp_parse_args(apply_filters('asmh_breadcrumbs_args', array()), $defaults);
  }


  public static function get_path($args) {
    $result = '';
    $home = is_home();
    $front = is_front_page();
    $obj = get_queried_object();

    if ((! $home && ! $front) || (!$front && $home)) {

      if (function_exists('is_bbpress') && is_bbpress ()) {
        if (bbp_is_single_forum()) {
          $result .= $args['separator'];
          $result .= self::trail_link(bbp_get_forums_url(), __('Forums', ASMH_LANG));
          $result .= $args['separator'];
          $result .= self::trail($obj->post_title);
        }
        elseif (bbp_is_single_topic()) {
          $result .= $args['separator'];
          $result .= self::trail_link(bbp_get_forums_url(), __('Forums', ASMH_LANG));
          $result .= $args['separator'];
          $forum_id = bbp_get_topic_forum_id($obj->ID);
          $result .= self::trail_link(bbp_get_forum_permalink($forum_id), bbp_get_forum_title($forum_id));
          $result .= $args['separator'];
          $result .= self::trail($obj->post_title);
        } else {
          $result .= $args['separator'];
          $result .= self::trail(__('Forums', ASMH_LANG));
        }
      }

      elseif (is_single() && function_exists('is_woocommerce') && !is_woocommerce()) {
        $obj = get_queried_object();

        if (get_post_type($obj) != 'post') {
          $result .= $args ['separator'];
          $result .= self::trail(get_the_title());

        } else {
          $result .= self::blog_crumb($args['separator']);
          $result .= $args['separator'];
          $result .= self::trail(get_the_title());
        }

      } elseif (is_page()) {
        if (isset($obj->post_parent) && $obj->post_parent > 0) {
          $parents = array();
          $old_obj = $obj;

          while ($obj->post_parent > 0) {
            $obj = get_post($obj->post_parent);
            $parents[] = $obj;
          }

          $parents = array_reverse($parents);

          foreach ($parents as $post) {
            $result .= $args ['separator'];
            $result .= self::trail_link(get_permalink($post->ID), $post->post_title);
          }

          $obj = $old_obj;

          $result .= $args ['separator'];
          $result .= self::trail(get_the_title());

        } else {
          $result .= $args ['separator'];
          $result .= self::trail(get_the_title());
        }

      } elseif(is_home()) {
        if (is_single ()) {
          $result .= $args ['separator'];
          $result .= self::trail_link(asmh_blog_page_url(), asmh_blog_page_title());

        } else {
          $result .= $args ['separator'];
          $result .= self::trail ( asmh_blog_page_title () );
        }

        if (is_single ()) {
          $result .= $args ['separator'];
          $result .= self::trail ( get_the_title () );
        }
      }

      elseif (function_exists('is_woocommerce') && is_woocommerce()) {
        if (is_shop ()) {
          $result .= $args ['separator'];
          $result .= self::trail ( asmh_shop_title () );
        }

        elseif (is_product ()) {
          $result .= self::shop_crumb ( $args ['separator'] );

          $result .= $args ['separator'];
          $result .= self::trail ( get_the_title () );

        } elseif (is_product_category ()) {
          $result .= self::shop_crumb ( $args ['separator'] );

          $result .= $args ['separator'];
          $result .= self::trail ( single_cat_title ( '', false ) );

        } elseif (is_product_tag ()) {
          $result .= self::shop_crumb ( $args ['separator'] );

          $result .= $args ['separator'];
          $result .= self::trail ( single_tag_title ( '', false ) );
        }

        elseif (is_cart ()) {
          $result .= self::shop_crumb ( $args ['separator'] );
          $result .= $args ['separator'];
          $result .= self::trail ( __ ( 'Cart', ASMH_LANG ) );
        }

        elseif (is_checkout ()) {
          $result .= self::shop_crumb ( $args ['separator'] );
          $result .= $args ['separator'];
          $result .= self::trail ( __ ( 'Checkout', ASMH_LANG ) );
        }

        elseif (is_account_page ()) {
          $result .= self::shop_crumb ( $args ['separator'] );
          $result .= $args ['separator'];
          $result .= self::trail ( __ ( 'Account', ASMH_LANG ) );
        }
      }

      elseif (is_category ()) {
        $result .= self::blog_crumb ( $args ['separator'] );
        $result .= $args ['separator'];
        $result .= self::trail ( $args ['category_text'] . single_cat_title ( '', false ) );
      }

      elseif (is_tag ()) {
        $result .= self::blog_crumb ( $args ['separator'] );
        $result .= $args ['separator'];
        $result .= self::trail ( $args ['tag_text'] . single_tag_title ( '', false ) );
      }

      elseif (is_day ()) {
        $result .= $args ['separator'];
        $result .= self::trail ( $args ['archive_text'] . get_the_time ( 'F jS, Y' ) );
      }

      elseif (is_month ()) {
        $result .= $args ['separator'];
        $result .= self::trail ( $args ['archive_text'] . get_the_time ( 'F, Y' ) );
      }

      elseif (is_year ()) {
        $result .= $args['separator'];
        $result .= self::trail($args['archive_text'] . get_the_time('Y'));
      }

      elseif (is_author ()) {
        $result .= $args['separator'];
        $result .= self::trail(__( 'Author', ASMH_LANG));
      }

      elseif (isset($_GET['paged']) && !empty($_GET['paged'])) {
        $result .= $args['separator'];
        $result .= self::trail_link(asmh_blog_page_url(), asmh_blog_page_title());
      }

      elseif (is_search()) {
        $result .= $args['separator'];
        $result .= self::trail(__('Search', ASMH_LANG));
      }

      elseif (is_404() && $args['show_not_found']) {
        $result .= $args['separator'];
        $result .= self::trail($args['not_found']);
      }

      else {
        $obj = get_queried_object();

        if ($obj instanceof \WP_Post) {
          if ($obj->post_type == 'post') {
              $result .= self::blog_crumb($args['separator']);
          }

          $result .= $args['separator'];
          $result .= self::trail(get_the_title($obj->ID));

        } elseif (isset($obj->labels)) {
          $result .= $args ['separator'];

          if (!empty($obj->has_archive)) {
            $result .= self::trail(ucfirst($obj->has_archive));
          } else {
            $result .= self::trail($obj->label);
          }
        }
      }
    }

    return $result;
  }
  public static function vocab_scope() {
    return 'itemscope itemtype="http://data-vocabulary.org/Breadcrumb"';
  }
  public static function vocab_url() {
    return 'itemprop="url"';
  }
  public static function vocab_title() {
    return 'itemprop="title"';
  }
  public static function trail($anchor) {
    return '<span ' . self::vocab_scope () . '>' . '<span ' . self::vocab_title () . '>' . $anchor . '</span></span>';
  }
  public static function trail_link($href, $anchor) {
    return '<span ' . self::vocab_scope () . '>' . '<a href="' . $href . '" ' . self::vocab_url () . '>' . '<span ' . self::vocab_title () . '>' . $anchor . '</span></a></span>';
  }


  public static function blog_crumb($sep) {
    if (asmh_is_blog_home ()) {
      return;
    }

    $result = $sep;
    $result .= self::trail_link ( asmh_blog_page_url (), asmh_blog_page_title () );

    return $result;
  }


  public static function shop_crumb($sep) {
    if (asmh_is_shop_home ()) {
      return;
    }

    $result = $sep;
    $result .= self::trail_link ( asmh_shop_url (), asmh_shop_title () );

    return $result;
  }


  public static function extras() {
    global $asmh;

    if ($asmh->settings['bottom_left'] == 'breadcrumbs' || $asmh->settings['bottom_right'] == 'breadcrumbs') {
      add_filter('bbp_get_breadcrumb', '__return_false');
    }
  }
}
