<?php
namespace ASMH;

class Nav
{
  public static function init()
  {
      add_filter('wp_nav_menu_args', array(__CLASS__, 'nav_args'));
      add_filter('wp_nav_menu_items', array(__CLASS__, 'search_nav'), 10, 2);
      add_filter('wp_nav_menu_items', array(__CLASS__, 'ellipsis_nav'), 20, 2);
      add_filter('asmh_nav_search_item', array(__CLASS__, 'search_item'), 10, 2);
  }


  public static function nav_args($args = '')
  {
      global $asmh;
      $menu_args = array();

      if (!$args['depth']) {
          $menu_args['depth'] = $GLOBALS['asmh']->settings['menu_depth'];
      }

      return array_merge($args, $menu_args);
  }


  public static function search_nav($items, $args) {
      if (isset($args->bottom) && $args->bottom === true) {
          return $items;
      }

      if ($args->menu === $GLOBALS['asmh']->middle->id) {
          if (empty($items)) {
              return;
          }

          if (isset($args->sub_menu) && $args->sub_menu === true) {
              return $items;
          }

          return $items . apply_filters(
              'asmh_nav_search_item',
              array(
                  'search'
              ),
              array('icon-search')
          );

      } else {
          return $items;
      }
  }


  public static function ellipsis_nav($items, $args)
  {
      global $asmh;

      if (isset($args->bottom) && $args->bottom === true) {
          return $items;
      }

      $result = '';

      if (!is_admin() && !$asmh->settings['has_secondary']) {
          return $items;
      }

      if (!$asmh->settings['secondary_menu_id']) {
          return $items;
      }

      if ($args->menu === $asmh->middle->id) {
          if (empty($items)) {
              $result = '';
          }

          // if not bottom sub-menu which uses items of main menu
          elseif (isset($args->sub_menu) && $args->sub_menu === true) {
              $result = $items;

          } else {
              $sub_menu = '<div class="sub-menu">'
                  . apply_filters('asmh_secondary_menu_before', '')
                  . apply_filters('asmh_secondary_menu', wp_nav_menu(array(
                      'menu' => $asmh->settings['secondary_menu_id'],
                      'container' => false,
                      'echo' => false,
                      'depth' => -1
                  )))
                  . apply_filters('asmh_secondary_menu_after', '')
                  . '</div>';

              if (is_admin()) {
                  $display = !$asmh->settings['has_secondary']? 'style="display:none;" ' : '';
                  $result = "{$items}<li {$display}class=\"secondary dropdown\"><a class=\"icon-ellipsis-vert\"></a>{$sub_menu}</li>";

              } else {
                  $result = "{$items}<li class=\"secondary dropdown\"><a class=\"icon-ellipsis-vert\"></a>{$sub_menu}</li>";
              }
          }

      } else {
          $result = $items;
      }

      return $result;
  }


  public static function search_item($li_classes, $classes) {
    global $asmh;

    if (!is_admin() && !$GLOBALS['asmh']->settings['has_search']) {
      return;
    }

    if (!is_array($li_classes) && !empty($li_classes)) {
      return;
    }

    if (!is_array($classes) && !empty($classes)) {
      return;
    }

    $a = '<a class="' . implode(' ', $classes) . '"></a>';

    array_push($li_classes, $asmh->settings['search_type']);
    $li_classes = implode(' ', $li_classes);
    //(!$GLOBALS['asmh']->settings['has_search']? 'style="display:none;"' : '')

    $placeholder = apply_filters('asmh_search_placeholder', $asmh->settings['search_placeholder']);

    if ($asmh->settings['search_type'] == 'below') {
        $div = '<div class="search-wrap ">';
        $div_closing = '</div>';
    } else {
        $div = '';
        $div_closing = '';
    }

    if (is_admin()) {
        return <<<HTML
            <li class="{$li_classes}">
                {$a}
                {$div}
                <input type="text" name="s" value=""
                        tabindex="0" placeholder="{$placeholder}">
                {$div_closing}
            </li>
HTML;

    } else {
        $action = esc_url(home_url('/'));
        $val = get_search_query();

        return <<<HTML
            <li class="{$li_classes}">
                {$a}
                {$div}
                <form action="$action" role="search" method="get">
                    <input type="search" name="s" value="{$val}"
                            tabindex="0" placeholder="{$placeholder}">
                </form>
                {$div_closing}
            </li>
HTML;
    }
  }
}
