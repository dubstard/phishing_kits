<?php
namespace ASMH;

interface Header
{
}
