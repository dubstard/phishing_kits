var Asmh = (function() {
  function Asmh($) {
    this.jq = $;
  }


//  Asmh.prototype.setSearchItem = function() {
//    var $ = this.jq,
//        search = $('.middle li.search'),
//        eventName = 'hover';
//
//    var form = search.find('form');
//
//    if (asmhObject.search_on_click) {
//      eventName = 'click';
//    }
//
//    search.on(eventName, function() {
//      $(this).addClass('a');
//      setTimeout(function() { form.find('input').focus(); }, 400);
//    });
//
//    form.find('input').on('focusout', function() {
//      $(this).closest('.search').removeClass('a');
//    });
//  }


  Asmh.prototype.setSearchItem = function() {
    var $ = this.jq,
        search = $('.asmh-header .middle li.search'),
        eventName = 'hover';


    var hasWrap = $('.asmh-header li.search .search-wrap').length;

    if (hasWrap) {
      $('.asmh-header li.search .search-wrap').appendTo('.asmh-header .middle > .container');
      $('.asmh-header .search-wrap').css({
        top: $('.asmh-header .middle').height() + 'px'
      });
    }

    if (asmhObject.search_on_click || hasWrap) {
      eventName = 'click';
    }

    search.on(eventName, function() {

      if (search.hasClass('below')) {

        var searchWrap = $('.asmh-header .search-wrap');

        searchWrap.css({
          top: $('.asmh-header .middle').height() + 'px'
        });

        if (searchWrap.is(':visible')) {
          searchWrap.slideUp();
        } else {
          searchWrap.slideDown( function() { searchWrap.find('input').focus(); } );
        }

        return;
      }

      $(this).addClass('a');
      setTimeout(function() { $('li.search input').focus(); }, 400);
    });

    $('.asmh-header').on('focusout', 'li.search input', function() {
      if (search.hasClass('a')) {
        search.removeClass('a');
      }
    });
  }


  Asmh.prototype.toggleNav = function() {
    var $ = this.jq;

    $('.asmh-header .toggle').on('click', function(e) {
      $('.asmh-header .primary, .nav-wrap').toggleClass('expand');
      $(this).toggleClass('open');
    });
  }


  Asmh.prototype.setSecondaryMenuHeight = function() {
    var $ = this.jq,
        el = $('.asmh-header .primary .dropdown.secondary'),
        height = el.closest('ul').find('> li:first').height();

    if (!el.length) return;

    if ($('.asmh-header').width() < asmhObject.hide_menu_width) {
      el.css('height', 'auto');
      el.find('.sub-menu').css('top', 'auto');
    } else {
      el.height(height);
      el.find('.sub-menu').css({
        top: parseInt(el.find('> a').css('top')) + el.find('> a').outerHeight() - 1 + 'px'
      });
    }
  }


  Asmh.prototype.handleSticky = function() {
    var $ = this.jq,
      self = this,
      header = $('.asmh-header.sticky > div'),
      admin_bar_height = $('#wpadminbar').height();

    if (header.find('.toggle-wrap').is(':visible')) {
      header.removeClass('stick');
      return;
    }

    header.parent().css({
      minHeight: header.height() + 'px'
    });

    var is_sticky_only = false;
    if ($('.asmh-header.sticky.only').length) {
      is_sticky_only = true;
    }

    if (admin_bar_height === null || !admin_bar_height) {
      admin_bar_height = 0;
    }

    if (header.length < 1) return;

//    $('.dropdown.secondary').hover(function() {
//      if ($(window).scrollTop() > asmhObject.sticky_scroll_position) {
//        $(this).find('> .sub-menu').css({
//          marginTop: -1 * (asmhObject.menu_padding_sticky - 10 + 1) + 'px'
//        });
//      }
//    });

    $(window).scroll(function() {
      if ($(window).scrollTop() > asmhObject.sticky_scroll_position) {
        header[0].style.top = admin_bar_height + 'px';
        header.addClass('stick');
        self.setSecondaryMenuHeight();

      } else {
        header[0].style.top = -header.height() + 'px';
//        header.find('.secondary.dropdown > .sub-menu').removeAttr('style');

        if (!is_sticky_only) {
          header.removeClass('stick');
          self.setSecondaryMenuHeight();
        }
      }
    });
  }


  return Asmh;
})();


var asmh = new Asmh(jQuery);


jQuery(document).ready(function($) {
  asmh.setSearchItem();
  asmh.toggleNav();
  asmh.handleSticky();
  asmh.setSecondaryMenuHeight();
});
