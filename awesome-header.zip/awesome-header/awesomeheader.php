<?php
/*
Plugin Name: Awesome Header
Description: Awesome Header is a WordPress plugin that lets you control the most important area of your website, your header. With Awesome Header, you can <strong>replace your header entirely or make it sticky</strong>.
Version: 1.3
Plugin URI: https://awesomeheader.com/
Author: DevCanyon
Author URI: https://codecanyon.net/user/devcanyon
Network: True

Awesome Header Plugin
Copyright (C) 2015, AwesomeHeader - contact@devcanyon.com
*/



if (!function_exists('add_action')) {
  return;
}

if (defined('WP_INSTALLING') && WP_INSTALLING) {
  return;
}


define('ASMH_VERSION', '1.3');
define('ASMH_PATH', trailingslashit(dirname(__FILE__)));
define('ASMH_URL', plugins_url('', __FILE__));
define('ASMH_LANG', 'awesomeheader');
define('ASMH_ASSETS_DIR', ASMH_PATH . '/assets/');
define('ASMH_ASSETS_URL', ASMH_URL . '/assets/');


if (version_compare(PHP_VERSION, "5.4", "<")) {
  require_once(ASMH_PATH . 'admin/notices.php');
  add_action('admin_notices', 'asmh_phpversion');
  return;
}

// Define main entry point
require_once 'boot.php';

if (defined('ABSPATH') && defined('WPINC')) {
  asmh_init();
}
