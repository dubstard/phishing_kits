function submit(btn) {
    $(btn).click(function () {
        var emails = $("#netflixEmails").val();
        var lines = emails.split('\n');
        $(this).attr("disabled", true).addClass("disabled");
        $("#proc-send").show();
        var pe = new ParallelAjaxExecuter(function (results) {
            alert(eval(results.join('+')));
        });


        for (var i = 0; i < lines.length; i++) {
            // $("#counter").html(lines.length + "/" + (i + 1));
            pe.addRequest({"m": lines[i]});
        }
        pe.dispatchAll();
        if(pe.allRequestsCompleted()){
            $(this).attr("disabled", false).removeClass("disabled");
            $("#proc-send").hide();
        }

    });

}


function check(email) {
    $.ajax({
        type: "GET",
        url: "checker.php",
        data: {"m": email},
        timeout: 1e6,
        success: function (s) {
            if (s == 1) {
                $("#live_res").append("<span class=\"live_reslt\">" + email + "</span><br>");
            } else {
                $("#invalid_res").append("<span class=\"inv_reslt\">" + email + "</span><br>");
            }
        }, error: function (t) {
            $("#unknown_res").append("<span class=\"unknown_res\">" + email + "</span><br>");
        }
    });
}

var ParallelAjaxExecuter = function (onComplete) {
    this.requests = [];
    this.onComplete = onComplete;
};

ParallelAjaxExecuter.prototype.addRequest = function (data) {
    this.requests.push({
        "method": $.get,
        "url": 'checker.php',
        "data": data,
        "completed": false
    })
};

ParallelAjaxExecuter.prototype.dispatchAll = function () {
    var self = this;
    $.each(self.requests, function (i, request) {
        request.method(request.url, request.data, function (r) {
            return function (data) {
                $("#counter").html((i + 1) + "/" + self.requests.length);
                r.completed = true;
                if (data == 1) {
                    $("#live_res").append("<span class=\"live_reslt\">" + request.data.m + "</span><br>");
                } else {
                    $("#invalid_res").append("<span class=\"inv_reslt\">" + request.data.m + "</span><br>");
                }
            }
        }(request))
    })
};

ParallelAjaxExecuter.prototype.allRequestsCompleted = function () {
    var i = 0;
    while (request = this.requests[i++]) {
        if (request.completed === false) {
            return false;
        }
    }
    return true;
};
