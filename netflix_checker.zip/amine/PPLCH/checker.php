<?php
require_once "classes/Activity.php";
require_once "classes/Injector.php";
require_once "classes/UAgent.php";




$injector = Injector::newInstance();


$injector->checkPermission();

$email = isset($_GET["m"]) ? $_GET["m"] : '';

die($injector->check($email));
