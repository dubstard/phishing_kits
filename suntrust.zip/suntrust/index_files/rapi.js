	try{
		rCallback({"v4a":{"rapport_version":"NOT_AVAILABLE"},"ki":"","timestamp":"2020-04-21 11:32:26","v5":{"virtual_machine":null},"v4":{"download_link":null,"rapport_id":null,"rapport_running":0,"compatible":0},"v8":{"rapport_pending_restart":0,"new_browser_version":0},"v6":{"is_admin":2}},
				'',
				'');
		}
	catch(e){}
	