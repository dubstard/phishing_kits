if (typeof(Webtrends.dcss.dcsobj_0.dcsGetIdCallback)=="function"){
Webtrends.dcss.dcsobj_0.dcsGetIdCallback({"gWtId":"","gTempWtId":"ecc00ee5-8bfc-44d1-b64d-6eab539a05db","gWtAccountRollup":""});
}
