<?php
# FileName="Connection_php_mysql.htm"
# Type="MYSQL"
# HTTP="true"
$hostname_massadb = "localhost";
$database_massadb = "massadb";
$username_massadb = "root";
$password_massadb = "";
$massadb = mysql_pconnect($hostname_massadb, $username_massadb, $password_massadb) or trigger_error(mysql_error(),E_USER_ERROR); 
?>