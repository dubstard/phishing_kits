<?php
include('config.php');
?>

<?php
if(isset($_POST['BtnAdd'])){
$query='insert into volunteeringopportunities 
(OpportunityName ,volunteerprovider ,opportunitystatus ,opportunityType ,opportunityNo ,AgeRequired ,SexRequired ,city ,tasks ,conditions ,StartDate ,EndDate ,VolunteerHours) values
	("'.$_POST['OpportunityName'].'",'.$_POST['volunteerprovider'].',"'.$_POST['opportunitystatus'].'",'.$_POST['opportunityType'].','.$_POST['opportunityNo'].',"'.$_POST['AgeRequired'].'","'.$_POST['SexRequired'].'","'.$_POST['city'].'","'.$_POST['tasks'].'","'.$_POST['conditions'].'","'.$_POST['StartDate'].'","'.$_POST['EndDate'].'","'.$_POST['VolunteerHours'].'")';

$result=mysqli_query($db,$query) or die(mysqli_error($db));
$msg='<h3>لقد تمت عملية الاضافة بنجاح</h3>';
echo "<meta http-equiv='refresh' content='2'>";
}
?>
<!DOCTYPE html>
<!--[if lt IE 7 ]><html class="ie ie6" lang="en"> <![endif]-->
<!--[if IE 7 ]><html class="ie ie7" lang="en"> <![endif]-->
<!--[if IE 8 ]><html class="ie ie8" lang="en"> <![endif]-->
<!--[if (gte IE 9)|!(IE)]><!--><html class="not-ie" lang="en"> <!--<![endif]-->

<head>
	<!-- Basic Meta Tags -->
  <meta charset="utf-8">
  <title>فرص التطوع</title>
		<meta name="description" content="مأسسة العمل التطوعي">
	<meta name="keywords" content="مأسسة العمل التطوعي, تطوع , جمعية">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <!--[if (gte IE 9)|!(IE)]>
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta http-equiv="Content-Type" content="text/html;charset=utf-8">
  <![endif]--> 

  <!-- Favicon -->
  <link href="../img/favicon.ico" rel="icon" type="image/png">

  <!-- Styles -->
  <link href="../css/styles.css" rel="stylesheet">
  <link href="../css/bootstrap-override.css" rel="stylesheet">

  <!-- Font Avesome Styles -->
  <link href="../css/font-awesome/font-awesome.css" rel="stylesheet">
	<!--[if IE 7]>
		<link href="css/font-awesome/font-awesome-ie7.min.css" rel="stylesheet">
	<![endif]-->

  <!-- FlexSlider Style -->
  <link rel="stylesheet" href="../css/flexslider.css" type="text/css" media="screen">

	<!-- Internet Explorer condition - HTML5 shim, for IE6-8 support of HTML5 elements -->
	<!--[if lt IE 9]>
		<script src="http://html5shim.googlecode.com/svn/trunk/html5.js"></script>
	<![endif]-->   

</head>       
<body>
   <!-- Header -->
  <header id="header">
    <div class="container">
      <div class="row t-container">

        <!-- Logo -->
        <div class="span3">
          <div class="logo">
            <a href="index.php"><img src="img/logo-header.png" alt=""></a>
          </div>            
        </div>

        <div class="span9">
          <div class="row space60"></div>
          <?php
		 include('../include/admin- menu.php');
		 ?>
         </div> 
      </div> 
       <div class="row space40"></div>
  </div> 
</header>
<!-- Header End -->

<!-- Titlebar
================================================== -->
<section id="titlebar">
	<!-- Container -->
	<div class="container">      
		<div class="eight columns">
			<h3 class="right">فرص التطوع</h3>
		</div>
		
		<div class="eight columns">
			<nav id="breadcrumbs">
				<ul>
					<li>:</li>
					<li><a href="../index.htm">الرئيسية</a></li> 
				</ul>
			
			</nav>
		</div>

	</div>
	<!-- Container / End -->
</section>

  <!-- Content -->
  <div id="content">
    <div class="container">

       <div class="row">
        <div class="span12">
		 <div class="row space50"></div> 
          <div dir="rtl">
		   <form name="form2" method="post" action="">
		   <div> <?php echo $msg;?>
		   </div>
			<div>اسم الفرصة    </div>
			<input name="OpportunityName" type="text"> 
			<div>مقدم الفرصة</div>
			   <?php
			  $query='select * from volunteerprovider';
			  $result=mysqli_query($db,$query) or die(mysqli_error($db));
			  ?>
		<select name="volunteerprovider" id="volunteerprovider">
			  <?php
			  while($row=mysqli_fetch_array($result))
			  {
			  echo'<option value='.$row['ID'].'>';
			  echo $row['ProviderName'].'</option>';
			  }
			  ?>
         </select>
 			<div>حالة الفرصة	<div>  
			<input type="radio" name="opportunitystatus" value="1" checked="true">  مفتوحة
			<input type="radio" name="opportunitystatus" value="0">  مغلقة
		   <div>نوع الفرصة </div>
			   <?php
			  $query='select * from volunteeringopportunitiestypes';
			  $result=mysqli_query($db,$query) or die(mysqli_error($db));
			  ?>
		<select name="opportunityType" id="opportunityType">
			  <?php
			  while($row=mysqli_fetch_array($result))
			  {
			  echo'<option value='.$row['ID'].'>';
			  echo $row['opportunityType'].'</option>';
			  }
			  ?>
         </select>
           <div> عدد الفرص</div>
			 <input name="opportunityNo" type="text"> 
            <div>العمر المطلوب </div>
			 <input name="AgeRequired" type="text"> 
		<div>الفئة المستهدفة</div>
		    <select  name="SexRequired" id="SexRequired" onChange="showCustomer(this.value)">
                <option value="ذكور و اناث">ذكور و اناث</option>
                <option value="ذكور فقط">ذكور فقط</option>
                <option value="اناث فقط">اناث فقط</option>
              </select>
		   <div>المدينة </div>
			 <input name="city" type="text"> 
           <div>المهام والمسؤليات </div>
			 <textarea name="tasks" rows="5" cols="40"></textarea>
			 <div> الشروط والمؤهلات المطلوبة </div>
			 <textarea name="conditions" rows="5" cols="40"></textarea>
			<div>  تاريخ البداية </div>
			<input type="date" id="StartDate" name="StartDate"> 
		  <div>تاريخ النهاية </div>
			<input type="date" id="EndDate" name="EndDate">
		 <div> ساعات التطوع </div>
			 <input name="VolunteerHours" type="text"> 
            </br>
			
			
			<input class="btn btn-blue" name="BtnAdd" type="submit" value="اضافة الفرصة">		
		    </form>
			

			
		  </div> 
		                          
          </div> 
                                   
<!--           <div class="row space50"></div> 
 -->		   
        </div>
      </div>
    </div>
  </div> 
  
  <!-- Content End -->  

  <!-- Footer -->
  <footer id="footer">
    <div class="container">
      <div class="row">
	  
	  <div class="span5">
        <?php
		include('../include/contact-us.php');
		?>
       </div>
        
		
       <div class="span3 offset3">
        <?php
		include('../include/address.php');
		?>
       </div>
        
	   <div class="verybottom">
       <div class="row space15"> </div>
		<?php
		include('../include/footer.php');
		?>
		</div>
		
  </div> </div>
  </footer>
  <!-- Footer End -->
  <!-- JavaScripts -->
  <script type="text/javascript" src="../js/jquery-1.8.3.min.js"></script> 
  <script type="text/javascript" src="../js/bootstrap.min.js"></script>  
  <script type="text/javascript" src="../js/functions.js"></script>
  <script type="text/javascript" defer src="../js/jquery.flexslider.js"></script>

</body>
</html>
  
