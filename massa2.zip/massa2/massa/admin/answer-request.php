<?php require_once('../../Connections/massadb.php'); ?>
<?php
mysql_select_db($database_massadb, $massadb);
$volunteer_ID= $_GET["volunteerID"];
$query_RecordsetOpportunities = "SELECT volunteerName FROM volunteers
  where volunteerID= $volunteer_ID;";
 
$RecordsetOpportunities = mysql_query($query_RecordsetOpportunities, $massadb) or die(mysql_error());
$row_RecordsetOpportunities = mysql_fetch_assoc($RecordsetOpportunities);
$totalRows_RecordsetOpportunities = mysql_num_rows($RecordsetOpportunities);
mysql_query("SET NAMES 'utf8'");
mysql_query('SET CHARACTER SET utf8');
?>



<?php
mysql_select_db($database_massadb, $massadb);
if(isset($_POST['BtnAccept'])){
$query='update volunteeringopportunitiesbook set Status ="1" where ID= '.$_POST['ID'].'';
$result = mysql_query($query, $massadb) or die(mysql_error());

$masg='<h3>لقد تمت عملية قبول الطلب بنجاح</h3>';
echo "<meta http-equiv='refresh' content='2'; URL=volunteer-requests.php'>";
}
?>

<?php
mysql_select_db($database_massadb, $massadb);
if(isset($_POST['BtnReject'])){
$query='update volunteeringopportunitiesbook set Status ="0" where ID= '.$_POST['ID'].'';
$result = mysql_query($query, $massadb) or die(mysql_error());

$masg='<h3><font color="#FF0000">لقد تمت عملية رفض الطلب بنجاح</font></h3>';
echo "<meta http-equiv='refresh' content='2'; URL=volunteer-requests.php'>";
}
?>
<!DOCTYPE html>
<!--[if lt IE 7 ]><html class="ie ie6" lang="en"> <![endif]-->
<!--[if IE 7 ]><html class="ie ie7" lang="en"> <![endif]-->
<!--[if IE 8 ]><html class="ie ie8" lang="en"> <![endif]-->
<!--[if (gte IE 9)|!(IE)]><!--><html class="not-ie" lang="en"> <!--<![endif]-->

<head>
	<!-- Basic Meta Tags -->
  <meta charset="utf-8">
  <title>الرد على المتطوع</title>
		<meta name="description" content="مأسسة العمل التطوعي">
	<meta name="keywords" content="مأسسة العمل التطوعي, تطوع , جمعية">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <!--[if (gte IE 9)|!(IE)]>
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta http-equiv="Content-Type" content="text/html;charset=utf-8">
  <![endif]--> 

  <!-- Favicon -->
  <link href="../img/favicon.ico" rel="icon" type="image/png">

  <!-- Styles -->
  <link href="../css/styles.css" rel="stylesheet">
  <link href="../css/bootstrap-override.css" rel="stylesheet">

  <!-- Font Avesome Styles -->
  <link href="../css/font-awesome/font-awesome.css" rel="stylesheet">
	<!--[if IE 7]>
		<link href="css/font-awesome/font-awesome-ie7.min.css" rel="stylesheet">
	<![endif]-->

  <!-- FlexSlider Style -->
  <link rel="stylesheet" href="../css/flexslider.css" type="text/css" media="screen">

	<!-- Internet Explorer condition - HTML5 shim, for IE6-8 support of HTML5 elements -->
	<!--[if lt IE 9]>
		<script src="http://html5shim.googlecode.com/svn/trunk/html5.js"></script>
	<![endif]-->   

</head>       
<body>
  <!-- Header -->
     <!-- Header -->
  <header id="header">
    <div class="container">
      <div class="row t-container">

        <!-- Logo -->
        <div class="span3">
          <div class="logo">
            <a href="index.php"><img src="img/logo-header.png" alt=""></a>
          </div>            
        </div>

        <div class="span9">
          <div class="row space60"></div>
          <?php
		 include('../include/admin- menu.php');
		 ?>
        </div> 
      </div> 
       <div class="row space40"></div>
  </div> 
</header>
<!-- Header End -->
  <!-- Header End -->

<!-- Titlebar
================================================== -->
<section id="titlebar">
	<!-- Container -->
		<div class="container">
		<div class="eight columns">
		<h3 class="right"> الرد على المتطوع/
			 <?php echo $row_RecordsetOpportunities['volunteerName']; ?>  </h3>
		</div>
		
		<div class="eight columns">
			<nav id="breadcrumbs">
				
			
			</nav>
		</div>

	</div>
	<!-- Container / End -->
</section>

  <!-- Content -->
  <div id="content">
    <div class="container">
      <div class="row">
<!--         <div class="span12">
 -->		
  		 <div class="row space50"></div> 
         <div dir="rtl" class="f-right">
		  <form name="form2" method="post" action="">
		  <table class="pricing-tables">
		  <tr> <?php echo $masg;?></tr>
		   <tr> <td>المتطوع:
			<strong><?php echo $row_RecordsetOpportunities['volunteerName']; ?> </strong>
		   </td></tr>
		    
			<input type="hidden" name="ID" value="<?php echo $ID= $_GET["ID"]; ?>">
			
			<tr>
			<td><input name="BtnAccept" type="submit"  value="قبول الطلب" class="btn-blue">
		      <input name="BtnReject" type="submit"  value="رفص الطلب" class="btn-danger"></td>
		   </form>
		   	
			<form  action="volunteesr-requests.php" method="get" name="frm1">
			<input type="hidden" name="OpportunityID" value="<?php echo $_GET["OpportunityID"]; ?>">
			<input name="BtnBack" type="submit"  value="رجوع" class="btn-info">
			</form>
		  </tr>
		  </table>                      
        </div> 
                                   
<!--           <div class="row space50"></div>  
 -->       
      </div>
    </div>
  </div>
  <!-- Content End -->  

  <!-- Footer -->
  <footer id="footer">
    <div class="container">
      <div class="row">
	  
	  <div class="span5">
        <?php
		include('../include/contact-us.php');
		?>
       </div>
        
		
       <div class="span3 offset3">
        <?php
		include('../include/address.php');
		?>
       </div>
        
	   <div class="verybottom">
       <div class="row space15"> </div>
		<?php
		include('../include/footer.php');
		?>
		</div>
		
  </div> </div>
  </footer>
  <!-- Footer End -->


  <!-- JavaScripts -->
  <script type="text/javascript" src="../js/jquery-1.8.3.min.js"></script> 
  <script type="text/javascript" src="../js/bootstrap.min.js"></script>  
  <script type="text/javascript" src="../js/functions.js"></script>
  <script type="text/javascript" defer src="../js/jquery.flexslider.js"></script>

</body>
</html>
  