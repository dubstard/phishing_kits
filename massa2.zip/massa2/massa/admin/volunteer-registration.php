<?php
include('config.php');
?>

<?php
if(isset($_POST['BtnAdd'])){
$query='insert into volunteers 
(VolunteerName ,Gender,BirthDate ,MaritalStatus ,NationalityID ,Address ,phone ,email ,QualificationID ,assessment ,specialization ,Job, phonelogin, passwordlogin) values
	("'.$_POST['VolunteerName'].'","'.$_POST['Gender'].'","'.$_POST['BirthDate'].'","'.$_POST['MaritalStatus'].'",'.$_POST['NationalityID'].',"'.$_POST['Address'].'","'.$_POST['phone'].'","'.$_POST['email'].'",'.$_POST['QualificationID'].',"'.$_POST['assessment'].'","'.$_POST['specialization'].'","'.$_POST['Job'].'",'.$_POST['phonelogin'].',"'.$_POST['passwordlogin'].'")';

$result=mysqli_query($db,$query) or die(mysqli_error($db));
$msg='<h3>لقد تمت عملية الاضافة بنجاح</h3>';
echo "<meta http-equiv='refresh' content='2'x>";
}
?>
<!DOCTYPE html>
<!--[if lt IE 7 ]><html class="ie ie6" lang="en"> <![endif]-->
<!--[if IE 7 ]><html class="ie ie7" lang="en"> <![endif]-->
<!--[if IE 8 ]><html class="ie ie8" lang="en"> <![endif]-->
<!--[if (gte IE 9)|!(IE)]><!--><html class="not-ie" lang="en"> <!--<![endif]-->

<head>
	<!-- Basic Meta Tags -->
  <meta charset="utf-8">
  <title>المتطوعين</title>
		<meta name="description" content="مأسسة العمل التطوعي">
	<meta name="keywords" content="مأسسة العمل التطوعي, تطوع , جمعية">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <!--[if (gte IE 9)|!(IE)]>
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta http-equiv="Content-Type" content="text/html;charset=utf-8">
  <![endif]--> 

  <!-- Favicon -->
  <link href="../img/favicon.ico" rel="icon" type="image/png">

  <!-- Styles -->
  <link href="../css/styles.css" rel="stylesheet">
  <link href="../css/bootstrap-override.css" rel="stylesheet">

  <!-- Font Avesome Styles -->
  <link href="../css/font-awesome/font-awesome.css" rel="stylesheet">
	<!--[if IE 7]>
		<link href="css/font-awesome/font-awesome-ie7.min.css" rel="stylesheet">
	<![endif]-->

  <!-- FlexSlider Style -->
  <link rel="stylesheet" href="../css/flexslider.css" type="text/css" media="screen">

	<!-- Internet Explorer condition - HTML5 shim, for IE6-8 support of HTML5 elements -->
	<!--[if lt IE 9]>
		<script src="http://html5shim.googlecode.com/svn/trunk/html5.js"></script>
	<![endif]-->   

</head>       
<body>
   <!-- Header -->
  <header id="header">
    <div class="container">
      <div class="row t-container">

        <!-- Logo -->
        <div class="span3">
          <div class="logo">
            <a href="index.php"><img src="img/logo-header.png" alt=""></a>
          </div>            
        </div>

        <div class="span9">
          <div class="row space60"></div>
          <?php
		 include('../include/admin- menu.php');
		 ?>
         </div> 
      </div> 
       <div class="row space40"></div>
  </div> 
</header>
<!-- Header End -->
<!-- Titlebar
================================================== -->
<section id="titlebar">
	<!-- Container -->
	<div class="container">      
		<div class="eight columns">
			<h3 class="right">بيانات المتطوعين</h3>
		</div>
		
		<div class="eight columns">
			<nav id="breadcrumbs">
				<ul>
					<li>:</li>
					<li><a href="../index.htm">الرئيسية</a></li> 
				</ul>
			
			</nav>
		</div>

	</div>
	<!-- Container / End -->
</section>

  <!-- Content -->
  <div id="content">
    <div class="container">

       <div class="row">
        <div class="span12">
		 <div class="row space50"></div> 
          <div dir="rtl">
		  <div> <?php echo $msg; ?>
		   <form name="form2" method="post" action="">
			<div>الاسم رباعي   </div>
			<input name="VolunteerName" type="text"> 
           <div>النوع</div>
			<input type="radio" name="Gender" value="ذكر">  ذكر
			<input type="radio" name="Gender" value="انثئ">  انثئ
		   <div> تاريخ الميلاد</div>
			<!-- <input name="BirthDate" type="text" value="yyyy-mm-dd">  <!--  value="dd/mm/yyyy" --> 
			<input type="date" id="BirthDate" name="BirthDate"> 
		   <div> الحالة الاجتماعية</div>
              <select  name="MaritalStatus" id="MaritalStatus" onChange="showCustomer(this.value)">
              <option value="">---&gt; حدد الحالة الاجتماعية &lt;---</option>
                <option value="عازب">عازب</option>
                <option value="متزوج">متزوج</option>
                <option value="مطلق">مطلق</option>
              </select>
	      <div>	الجنسية</div>
			   <?php
			  $query='select * from nationalities';
			  $result=mysqli_query($db,$query) or die(mysqli_error($db));
			  ?>
		<select name="NationalityID" id="NationalityID">
			  <?php
			  while($row=mysqli_fetch_array($result))
			  {
			  echo'<option value='.$row['NationalityID'].'>';
			  echo $row['NationalityName'].'</option>';
			  }
			  ?>
         </select>
			<div>العنوان</div>
			 <input name="Address" type="text"> 
            <div> الهاتف</div>
			 <input name="phone" type="tel">       
			<div>البريد الالكتروني</div>
			 <input name="email" type="email"> 
           <div>المؤهل</div>
			  <?php
			  $query='select * from qualifications';
			  $result=mysqli_query($db,$query) or die(mysqli_error($db));
			  ?>
		<select name="QualificationID" id="QualificationID">
			  <?php
			  while($row=mysqli_fetch_array($result))
			  {
			  echo'<option value='.$row['QualificationID'].'>';
			  echo $row['QualificationName'].'</option>';
			  }
			  ?>
         </select>
		 <div>	التقييم</div>
			 <input name="assessment" type="text"> 
          <div>	التخصص</div>
			 <input name="specialization" type="text">       
			<div> الوظيفة</div>
			 <input name="Job" type="text"> 
            </br>
			
			<fieldset><legend class="blue-dark"><strong>بيانات تسجيل الدخول</strong></legend>
			
			<div>قم بادخال رقم الهاتف بدون صفر مثلاً: 966128337777</div>
			 <input name="phonelogin" type="tel">       
			<div> كلمة المرور</div>
			 <input name="passwordlogin" type="text"> 
			 
			</fieldset>
			
			
			<input class="btn btn-blue" name="BtnAdd" type="submit" value="موافق">		
		    </form>
		  </div> 
		                          
          </div> 
                                   
<!--           <div class="row space50"></div> 
 -->		   
        </div>
      </div>
    </div>
  </div> 
  
  <!-- Content End -->  

  <!-- Footer -->
  <footer id="footer">
    <div class="container">
      <div class="row">
	  
	  <div class="span5">
        <?php
		include('../include/contact-us.php');
		?>
       </div>
        
		
       <div class="span3 offset3">
        <?php
		include('../include/address.php');
		?>
       </div>
        
	   <div class="verybottom">
       <div class="row space15"> </div>
		<?php
		include('../include/footer.php');
		?>
		</div>
		
  </div> </div>
  </footer>
  <!-- Footer End -->

  <!-- JavaScripts -->
  <script type="text/javascript" src="../js/jquery-1.8.3.min.js"></script> 
  <script type="text/javascript" src="../js/bootstrap.min.js"></script>  
  <script type="text/javascript" src="../js/functions.js"></script>
  <script type="text/javascript" defer src="../js/jquery.flexslider.js"></script>

</body>
</html>
  
