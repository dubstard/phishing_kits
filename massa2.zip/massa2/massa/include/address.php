<?php
    echo '<h3>العنوان</h3>
		  شارع81
		  <br>
         جدة 
		 <br>
          السعودية
		  <br>
          
          <i class="icon-phone"></i> 00966-128337777<br>
          <i class="icon-envelope"></i><a href="mailto:info@massa.com">info@massa.com</a><br>';
?>