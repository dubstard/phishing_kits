<?php
    echo '<div class="row" >
        <div class="span6 left" >
		
          <div class="logo-footer">
		 مأسسة العمل التطوعي
          </div>                       
        </div>
        <div class="span6 right">
         جميع الحقوق محفوظة 2019  &copy;
        </div> 
      </div>
	   </div>
    </div> </div>
  </footer>';
?>