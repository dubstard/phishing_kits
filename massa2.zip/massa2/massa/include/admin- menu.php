
<?php
echo '<nav id="nav" role="navigation">
               	<a href="#nav" title="Show navigation">Show navigation</a>
	            <a href="#" title="Hide navigation">Hide navigation</a>
	            <ul class="clearfix">
				
	          <li> <a href="../index.php"><i class="icon-home"></i> الرئيسية </a></li>

			   <li> <a href="../about-us.php"><i class="icon-book"></i> من نحن </a>
                   <ul> 
                      <li><a href="../about-us.php">نبذة عنا</a></li>
                      <li><a href="../structure.php">الهيكل التنظيمي </a></li>
				  </ul>       
               </li>
                
				<li><a href="#"><i class="icon-leaf"></i> مجالات التطوع</a>
					<ul> 
                      	<li><a href="">الخيري</a></li>
						<li><a href="">التعليم</a></li>
						<li><a href="">الصحة</a></li>
						<li><a href="">البيئة</a></li>
						<li><a href="">الدعوة</a></li>
						<li><a href="">الاعلام</a></li>
						<li><a href="">اخرى</a></li>
                    </ul>       
               </li>
				  
			  <li class="active"><a href="allopportunities.php"><i class="icon-briefcase"></i> فرص التطوع </a> </li>  
			  
			  <li> <a href="../contact.php"><i class="icon-envelope-alt"></i> اتصل بنا</a></li>
			  
	         </ul>
          </nav>';
?>