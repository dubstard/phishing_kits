<?php
    echo '<h3>تواصل معنا</h3>
        <div>         
          <form class="form-main" name="ajax-form" id="ajax-form" action="#" method="post">
            <div id="ajaxsuccess">تم ارسال الايميل بنجاح</div> 
            <div class="error" id="err-name"> الرجاء ادخال اسم</div>
            <input name="name" id="name" type="text" value="الاسم" onfocus="if(this.value == \'Name\');" onblur="if(this.value == \'\') this.value=\'Name\';">
            
            <div class="error" id="err-email">الرجاء ادخال ايميل</div>
		        <div class="error" id="err-emailvld">البريد الالكتروني غير صحيح</div>
            <input  name="email" id="email" type="text" value="البريد الالكتروني" onfocus="if(this.value == \'E-mail\') this.value=\'\';" onblur="if(this.value == \'\');">

            <div class="error" id="err-message">الرجاء كتابة رسالة</div>
            <textarea  name="message" id="message" onfocus="if(this.value == \'Message\') this.value=\'\';" onblur="if(this.value == \'\') this.value=\'Message\';">رسالة</textarea><br>
            <div>
            	<div class="error" id="err-form">There was a problem validating the form please check!</div>
            	<div class="error" id="err-timedout">The connection to the server timed out!</div>
            	<div class="error" id="err-state"></div>
            </div>
            <button id="send" class="btn f-right">ارسال الرسالة <i class="icon-ok"></i></button>
          </form>
        </div>';
?>