<?php require_once('Connections/massadb.php'); ?>
<?php
mysql_select_db($database_massadb, $massadb);
$ID= $_GET["OpportunityID"];

$query_RecordsetOpportunities = "SELECT OpportunityID, OpportunityName, volunteerprovider.ProviderName, SexRequired, volunteeringopportunitiestypes.opportunityType,
 volunteeringopportunities.city, volunteeringopportunities.StartDate, volunteeringopportunities.EndDate, volunteeringopportunities.VolunteerHours FROM 
 volunteeringopportunities, volunteerprovider, volunteeringopportunitiestypes
  where volunteeringopportunities.volunteerprovider= volunteerprovider.ID and 
  		volunteeringopportunities.opportunityType= volunteeringopportunitiestypes.ID and volunteeringopportunities.opportunitystatus='1'";
 
$RecordsetOpportunities = mysql_query($query_RecordsetOpportunities, $massadb) or die(mysql_error());
$row_RecordsetOpportunities = mysql_fetch_assoc($RecordsetOpportunities);
$totalRows_RecordsetOpportunities = mysql_num_rows($RecordsetOpportunities);
mysql_query("SET NAMES 'utf8'");
mysql_query('SET CHARACTER SET utf8');
?>

<!DOCTYPE html>
<!--[if lt IE 7 ]><html class="ie ie6" lang="en"> <![endif]-->
<!--[if IE 7 ]><html class="ie ie7" lang="en"> <![endif]-->
<!--[if IE 8 ]><html class="ie ie8" lang="en"> <![endif]-->
<!--[if (gte IE 9)|!(IE)]><!--><html class="not-ie" lang="en"> <!--<![endif]-->

<head>
	<!-- Basic Meta Tags -->
  <meta charset="utf-8">
  <title>مأسسة العمل التطوعي</title>
	<meta name="description" content="مأسسة العمل التطوعي">
	<meta name="keywords" content="مأسسة العمل التطوعي, تطوع , جمعية">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <!--[if (gte IE 9)|!(IE)]>
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta http-equiv="Content-Type" content="text/html;charset=utf-8">
  <![endif]--> 

  <!-- Favicon -->
  <link href="img/favicon.ico" rel="icon" type="image/png">

  <!-- Styles -->
  <link href="css/styles.css" rel="stylesheet">
  <link href="css/bootstrap-override.css" rel="stylesheet">

  <!-- Font Avesome Styles -->
  <link href="css/font-awesome/font-awesome.css" rel="stylesheet">
	<!--[if IE 7]>
		<link href="css/font-awesome/font-awesome-ie7.min.css" rel="stylesheet">
	<![endif]-->

  <!-- FlexSlider Style -->
  <link rel="stylesheet" href="css/flexslider.css" type="text/css" media="screen">

	<!-- Internet Explorer condition - HTML5 shim, for IE6-8 support of HTML5 elements -->
	<!--[if lt IE 9]>
		<script src="http://html5shim.googlecode.com/svn/trunk/html5.js"></script>
	<![endif]-->   

    <style type="text/css">
<!--
.style1 {color: #009495;
right:30px}
-->
    </style>
</head>       
<body>
  <!-- Header -->
  <header id="header" >
  <div class="login" >
   <div class="span9 right"> 
   		<form  action="admin/login.php" method="get" name="frm-login">
		 <h3 class="btn"><i class="icon-user"> <input class="btn btn-blue" name="BtnLogin" type="submit"  value="دخول" > </i> </h3>
		 </form>   
     </div> 
  </div>
    <div class="container" >
      <div class="row t-container" >

        <!-- Logo -->
        <div class="span3">
          <div class="logo">
            <a href="index.htm"><img src="img/logo-header.png" alt=""></a>
          </div>            
        </div>

        <div class="span9" >
          <div class="row space60"></div>
	     <?php
		 include('include/menu.php');
		 ?>
         </div> 
      </div> 
	  
       <div class="row space40"></div>
          <div class="slider1 flexslider">  <!-- Slider -->
            <ul class="slides">
              <li>
    	    	    <img src="img/slider/1.jpg" alt="">
    	    		</li>
    	    		<li>
    	    	    <img src="img/slider/2.jpg" alt="">
    	    		</li>
    	    		<li>
    	    	    <img src="img/slider/3.jpg" alt="">
    	    		</li>
                    <li>
    	    	    <img src="img/slider/4.jpg" alt="">
    	    		</li>
            </ul>
          </div>  <!-- Slider End -->
  </div> 
   <div class="login" >
 
  </div>
</header>
  <!-- Header End -->
  <!-- Content -->
  <div id="content">
    <div class="container">
       
      
      <div class="row space40"></div>
      <div class="row">
        <div class="span12">
          <div class="row">
            <!-- Service Container --> 
            <div class="span4">
              <!-- Service Icon --> 
              <div class="ic-1"><i class="icon-lightbulb"></i></div>
              <!-- Service Title --> 
              <div class="title-1"><h4>ما يمكن أن تتوقعه من المنظمة</h4></div>
              <!-- Service Content --> 
              <div class="text-1"> 
             التعريف الكامل بالمنظمة وسياساتها و بدوركم التطوعي وما يمكن أن تساهموا به لخدمة أهداف المنظمة ، والتعريف بسياسات وإجراءات التطوع والتوجيه المباشر  لمساعدتكم على القيام بدوركم وكذلك التدريب والتأهيل، والدعم المقدم من مرجعكم الإداري ومدير التطوع والرئيس المباشر، أيضا التقدير والتكريم لكل ما تقدمونه من خلال دوركم، وإصدار الشهادات التطوعية بعدد الساعات التي قمتم بالتطوع فيها .
المشاركة في وضع خطط وأهداف المنظمة وحضور اجتماعاتها العامة وتقديم المقترحات . 
              </div>
            </div>
            <!-- Service Container End --> 
            <div class="span4">
              <div class="ic-1"><i class="icon-resize-small"></i></div>
              <div class="title-1"><h4>ما تتوقعه المنظمة منكم</h4></div>
              <div class="text-1">         
                نتوقع منكم التطوع في الأوقات المتفق عليها وإعلامها لأي طارئ يطرأ عليكم وترغبون في تعديل هذه الاوقات، وكذلك الالتزام بأهداف المؤسسة وسياساتها الموضحة في دليل السياسات والإجراءات والذي سيتم تعريفكم عليه .
              </div>
            </div>
            <div class="span4">
              <div class="ic-1"><i class="icon-eye-open"></i></div>
              <div class="title-1"><h4>التطوع والسياسات والإجراءات </h4></div>
              <div class="text-1">
			  تؤكد دولة السعودية على ثقافة العمل التطوعي في تعزيز التنمية المستدامة، وبناء مستقبل أفضل للأجيال الجديدة. يوجد العديد من المؤسسات التطوعية التي تنظم العمل التطوعي وأنشطة خدمة المجتمع في جميع أنحاء العالم.
				<br>
              تقوم الجمعية باختيار السياسة المناسبة او كتابة السياسات الخاصة بهم ومن ثم كتابة الإجراءات الخاصة بكل سياسة .
			 
			  سوف ندعم المتطوعين العاملين لدينا ونحمي حقوقهم كما هو منصوص عليه في أدواتنا التي تعرف بحقوق المتطوعين.
              </div>
            </div>    
          </div>   
        </div>   
      </div>
     
      <!-- Typography Row -->
      <div class="row t-row">
        <!-- Line -->
        <div class="span12"><hr></div>
		<h3 class="style1">اخر الفرص التطوعية</h3>
       <!--  <div class="span3">
     
        </div> -->
<?php do { ?>		
	 <div class="span3">	
          <h3>فرصة تطوعية / <?php echo $row_RecordsetOpportunities['OpportunityName']; ?></h3>
			  <p>
			  <strong class="blue-dark">مقدم الفرصة:</strong> <td><?php echo $row_RecordsetOpportunities['ProviderName']; ?>
			  <br> 
			  <strong class="blue-dark">الجنس المطلوب:</strong> <?php echo $row_RecordsetOpportunities['SexRequired']; ?>
			  <br>
			  <strong class="blue-dark">مجال التطوع:</strong>  <?php echo $row_RecordsetOpportunities['opportunityType']; ?>
			  <br>
			  <strong class="blue-dark">المدينة:</strong> <?php echo $row_RecordsetOpportunities['city']; ?>
			  <br>
			  <strong class="blue-dark">من:</strong>  <?php echo $row_RecordsetOpportunities['StartDate']; ?>
			  <br>
              <strong class="blue-dark">الى:</strong> <?php echo $row_RecordsetOpportunities['EndDate']; ?>
			  <br>
              <strong class="blue-dark">ساعات التطوع:</strong> <?php echo $row_RecordsetOpportunities['VolunteerHours']; ?>
			  </p>  
		
		<form  action="admin/desc-opportunity.php" method="get" name="frm-desc-opportunity">
				<input type="hidden" name="OpportunityID" value="<?php echo $row_RecordsetOpportunities['OpportunityID']; ?>">
				<h3><input name="BtnDesc" type="submit"  value="التفاصيل" class="btn btn-blue"></h3>
				</form>
		
    </div>    
 <?php } while ($row_RecordsetOpportunities = mysql_fetch_assoc($RecordsetOpportunities)); ?>
		
   
       <div class="span12"><hr></div>
      </div>
      <!-- Typography Row End-->
        
      

              
    
    </div>
  </div>
  <!-- Content End -->
  
  <!-- Footer -->
  <footer id="footer">
    <div class="container">
      <div class="row">
	  
	  <div class="span5">
        <?php
		include('include/contact-us.php');
		?>
       </div>
        
		
       <div class="span3 offset3">
        <?php
		include('include/address.php');
		?>
       </div>
        
	   <div class="verybottom">
       <div class="row space15"> </div>
		<?php
		include('include/footer.php');
		?>
		</div>
		
  </div> </div>
  </footer>
  <!-- Footer End -->

  <!-- JavaScripts -->
  <script type="text/javascript" src="js/jquery-1.8.3.min.js"></script> 
  <script type="text/javascript" src="js/bootstrap.min.js"></script>  
  <script type="text/javascript" src="js/functions.js"></script>
  <script type="text/javascript" defer src="js/jquery.flexslider.js"></script>

</body>
</html>
  