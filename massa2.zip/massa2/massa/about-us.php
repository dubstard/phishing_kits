<!DOCTYPE html>
<!--[if lt IE 7 ]><html class="ie ie6" lang="en"> <![endif]-->
<!--[if IE 7 ]><html class="ie ie7" lang="en"> <![endif]-->
<!--[if IE 8 ]><html class="ie ie8" lang="en"> <![endif]-->
<!--[if (gte IE 9)|!(IE)]><!--><html class="not-ie" lang="en"> <!--<![endif]-->

<head>
	<!-- Basic Meta Tags -->
  <meta charset="utf-8">
  <title>مأسسة العمل الطوعي | نبذة عنا</title>
	<meta name="description" content="مأسسة العمل التطوعي">
	<meta name="keywords" content="مأسسة العمل التطوعي, تطوع , جمعية">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <!--[if (gte IE 9)|!(IE)]>
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta http-equiv="Content-Type" content="text/html;charset=utf-8">
  <![endif]--> 

  <!-- Favicon -->
  <link href="img/favicon.ico" rel="icon" type="image/png">

  <!-- Styles -->
  <link href="css/styles.css" rel="stylesheet">
  <link href="css/bootstrap-override.css" rel="stylesheet">

  <!-- Font Avesome Styles -->
  <link href="css/font-awesome/font-awesome.css" rel="stylesheet">
	<!--[if IE 7]>
		<link href="css/font-awesome/font-awesome-ie7.min.css" rel="stylesheet">
	<![endif]-->

  <!-- FlexSlider Style -->
  <link rel="stylesheet" href="css/flexslider.css" type="text/css" media="screen">

	<!-- Internet Explorer condition - HTML5 shim, for IE6-8 support of HTML5 elements -->
	<!--[if lt IE 9]>
		<script src="http://html5shim.googlecode.com/svn/trunk/html5.js"></script>
	<![endif]-->   

</head>       
<body>
  <!-- Header -->
  <header id="header">
  <div class="login" >
   <div class="span9 right"> 
   		<form  action="admin/login.php" method="get" name="frm-login">
		 <h3 class="btn"><i class="icon-user"> <input class="btn btn-blue" name="BtnLogin" type="submit"  value="دخول" > </i> </h3>
		 </form>   
     </div> 
  </div>
    <div class="container">
      <div class="row t-container">

        <!-- Logo -->
        <div class="span3">
          <div class="logo">
            <a href="index.php"><img src="img/logo-header.png" alt=""></a>
          </div>            
        </div>

        <div class="span9">
          <div class="row space60"></div>
          <?php
		 include('include/menu.php');
		 ?>
         </div> 
      </div> 
       <div class="row space40"></div>
  </div> 
</header>
<!-- Header End -->

<!-- Titlebar
================================================== -->
<section id="titlebar">
	<!-- Container -->
	<div class="container">
	
		<div class="eight columns">
			<h3 class="right">مأسسة العمل الطوعي</h3>
		</div>
		
		<div class="eight columns">
			<nav id="breadcrumbs">
				<ul>
					<li>:</li>
					<li><a href="index.php">الرئيسية</a></li>
					<li>من نحن</li>
				</ul>
			</nav>
		</div>

	</div>
	<!-- Container / End -->
</section>

  <!-- Content -->
  <div id="content">
    <div class="container">

      <div class="row">
        <div class="span12">
		
		<h3> مأسسة العمل الطوعي</h3>
        <p>هي جمعية متخصصة غير ربحية تسعى لنشر ثقافة العمل التطوعي وتعزيز مفهوم المواطنة الصالحة في المملكة العربية السعودية بين أفراد المجتمع وذلك من خلال تنظيم الجهود التطوعية بين المتطوعين و الجهات المستفيدة ونشر وتطوير ثقافة العمل التطوعي وغرس مفهوم المبادرة والشعور بالمسئولية. </p>    
       
	   <h3>رؤيتنا</h3>
	   <p>نتطلع الي تعميق روح العمل التطوعي، باعتباره قيمة ايجابية لبناء المواطن الصالح و دعامة بارزة لتنمية المجتمع.</p>

	    <h3>لماذا نشرك المتطوعين ؟</h3>                        
		<ul dir="rtl">
			<li> حفظ أوقات الشباب  </li>
			<li> 	اشراك الشباب في خدمة المجتمع</li>
			<li>استثمار طاقات الشباب </li>
			<li>	اكساب المتطوعين الخبرات في العمل الاجتماعي والتطوعي</li>
		</ul>
        
		<h3>ماهي حقوق المتطوعين؟</h3>                        
		<ul dir="rtl">
		<strong>سوف ندعم المتطوعين العاملين لدينا ونحمي حقوقهم كما هو منصوص عليه في أدواتنا التي تعرف بحقوق المتطوعين وأبرزها:</strong>
			<li> توفير بيئة جاذبة وآمنة </li>
			<li> حفظ حقوقهم من ساعات التطوع التي نفذوها </li>
			<li> تسليمهم شهادات خبرة وتشجيعهم بالحوافز المناسبة </li>
		</ul>
		                      
         <div class="row space50"></div> 
		  
        </div>
      </div>
    </div>
  </div>
  <!-- Content End -->
  
 <!-- Footer -->
  <footer id="footer">
    <div class="container">
      <div class="row">
	  
	  <div class="span5">
        <?php
		include('include/contact-us.php');
		?>
       </div>
        
		
       <div class="span3 offset3">
        <?php
		include('include/address.php');
		?>
       </div>
        
	   <div class="verybottom">
       <div class="row space15"> </div>
		<?php
		include('include/footer.php');
		?>
		</div>
		
  </div> </div>
  </footer>
  <!-- Footer End -->


  <!-- JavaScripts -->
  <script type="text/javascript" src="js/jquery-1.8.3.min.js"></script> 
  <script type="text/javascript" src="js/bootstrap.min.js"></script>  
  <script type="text/javascript" src="js/functions.js"></script>
  <script type="text/javascript" defer src="js/jquery.flexslider.js"></script>

</body>
</html>
  