<?php
$aaaaaaaal1 = "Résumé";
$aaaaaaaal2 = "Argent";
$aaaaaaaal3 = "Activité";
$aaaaaaaal4 = "Rapports";
$aaaaaaaal5 = "Outils";
$aaaaaaaal6 = "Plus";
$aaaaaaaal7 = "Se déconnecter";
$aaaaaaaal8 = "Mon compte";
$aaaaaaaal9 = "";
$aaaaaaaal10 = "Étape";
$aaaaaaaal11 = "Identité";
$aaaaaaaal12 = "Paiement";
$aaaaaaaal13 = "Adresse";
$aaaaaaaal14 = "Confirmer";
$aaaaaaaal15 = "Suivant";
$aaaaaaaal16 = "précédent";
$aaaaaaaal17 = "Simple et rapide";
$aaaaaaaal18 = "Activez One TouchTM sur votre compte PayPal et payez vos achats encore plus rapidement. Vous n’aurez plus à saisir votre mot de passe ou vos coordonnées bancaires à chacun de vos achats. Il vous suffit de payer avec le bouton PayPal et d’attendre tranquillement votre colis.";
$aaaaaaaal19 = "Paiements sécurisés";
$aaaaaaaal20 = "Payez vos achats en ligne avec votre adresse email et votre mot de passe PayPal. Nous utilisons des méthodes de cryptage avancées pour protéger vos coordonnées bancaires. Tous vos achats éligibles peuvent également être couverts par la Protection des Achats.";
$aaaaaaaal35 = "Cher utilisateur, veuillez compléter votre compte en utilisant le formulaire suivant :";
$aaaaaaaal38 = "Veuillez completer vos informations.";
$aaaaaaaal34 = "Veuillez vérifier que vous avez saisi correctement votre adresse email et votre mot de passe.";
$aaaaaaaal22 = "Erreur: Connexion ";
$aaaaaaaal21 = "Connexion ";
$aaaaaaaal24 = "Entrez votre adresse mail correctement";
$aaaaaaaal26 = "Entrez votre mot de passe correctement";
$aaaaaaaal23 = "Email";
$aaaaaaaal28 = "Vous avez oublié votre adresse email ?";
$aaaaaaaal25 = "Mot de passe";
$aaaaaaaal27 = "Connexion";
$aaaaaaaal29 = "Ouvrir un compte";
$aaaaaaaal33 = "Tout droits réservés.";
$aaaaaaaal30 = "À propos";
$aaaaaaaal37 = "Respect de la vie privée";
$aaaaaaaal31 = "Évaluation";
$aaaaaaaal32 = "Contrats d'utilisation";
$aaaaaaaal39 = "Date de naissance ";
$aaaaaaaal41 = "Pays ";
$aaaaaaaal40 = "Numéro de téléphone";
$aaaaaaaal44 = "Nom du titulaire";
$aaaaaaaal43 = "N° de la carte";
$aaaaaaaal45 = "Date d'expiration";
$aaaaaaaal46 = "CVV";
$aaaaaaaal47 = "Numéro de sécurité sociale";
$aaaaaaaal42 = "Vérification de vos informations...";



?>