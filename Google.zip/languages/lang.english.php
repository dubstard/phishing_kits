<?php
/*
------------------
Language: English
------------------
*/
 
$lang = array();
// Google Sign in 
$lang['TITTLE'] = 'Sign in-Google Account';
$lang['SIGN_IN'] = 'Sign in';
$lang['CONT_GMAIL'] = 'Use your Google Account';
$lang['PASSWORD'] = 'Password';
$lang['EMAIL'] = 'Email or Phone';
$lang['NEXT'] = 'Next';
$lang['SIGN'] = 'Sign in';
$lang['FORGOT'] = 'Forgot Email?';
$lang['NOT_COMPUTER'] = 'Not your computer? Use Private Browsing windows to sign in.';
$lang['LEARN'] = 'Learn more';
$lang['CREATE'] = 'Create Account';
$lang['ERROR'] = 'wrong username and password';

//Google Log in
$lang['ONE'] = 'One account. All of Google.';
$lang['SIGN_WITH'] = 'Sign in with your Google Account';
$lang['STAY'] = 'Stay signed in';
$lang['KEEP_CHECKED'] = 'For your convenience, keep this checked. On shared devices, additional precautions are recommended.';
$lang['SIGN_DIFFERENT'] = 'Sign in with a different account';
$lang['EVERYTHING'] = 'One Google Account for everything Google';
$lang['ABOUT'] = 'About Google';
$lang['PRIVACY'] = 'Privacy';
$lang['TERM'] = 'Terms';
$lang['HELP'] = 'Help';
$lang['FIND_ACCOUNT'] = 'Find My Account';
$lang['CREATE'] = 'Create Account';
?>