<?php
/*
------------------
Language: Chinese
------------------
*/
 
$lang = array();
// Header 
$lang['TITTLE'] = '登录Google帐户';
$lang['SIGN_IN'] = '登入';
$lang['CONT_GMAIL'] = '继续使用Gmail';
$lang['PASSWORD'] = '密码';
$lang['EMAIL'] = '邮件或者电话';
$lang['NEXT'] = '下一个';
$lang['SIGN'] = '登入';
$lang['FORGOT'] = '忘记密码？';
$lang['ERROR'] = '用户名和密码错误';

//Google Log in
$lang['ONE'] = '一个帐户。 全部Google.';
$lang['SIGN_WITH'] = '使用您的Google帐户登录';
$lang['STAY'] = '保持登录';
$lang['KEEP_CHECKED'] = '为了您的方便，请选中此复选框。 在共享设备上，建议采取其他预防措施.';
$lang['SIGN_DIFFERENT'] = '使用其他帐户登录';
$lang['EVERYTHING'] = '一个Google帐户可用于处理所有Google';
$lang['ABOUT'] = '关于谷歌';
$lang['PRIVACY'] = '隐私';
$lang['TERM'] = '条款';
$lang['HELP'] = '救命';
$lang['FIND_ACCOUNT'] = '查找我的帐户';
$lang['CREATE'] = '创建帐号';
?>