<?php
/*
------------------
Language: Hungary
------------------
*/
 
$lang = array();
// Header 
$lang['TITTLE'] = 'Bejelentkezés - Google-fiók';
$lang['SIGN_IN'] = 'Bejelentkezés';
$lang['CONT_GMAIL'] = 'hogy továbblépjen a Gmailbe';
$lang['PASSWORD'] = 'Jelszó';
$lang['EMAIL'] = 'Mailben vagy telefonon';
$lang['NEXT'] = 'Következő';
$lang['SIGN'] = 'Bejelentkezés';
$lang['FORGOT'] = 'Elfelejtette a jelszavát?';
$lang['ERROR'] = 'rossz felhasználónév és jelszó';

//Google Log in
$lang['ONE'] = 'Egy számla. Az összes Google.';
$lang['SIGN_WITH'] = 'Jelentkezzen be Google Fiókjával';
$lang['STAY'] = 'Maradjon bejelentkezve';
$lang['KEEP_CHECKED'] = 'Az Ön kényelme érdekében tartsa ezt ellenőrizve. A megosztott eszközökön további óvintézkedések ajánlottak.';
$lang['SIGN_DIFFERENT'] = 'Jelentkezzen be egy másik fiókkal';
$lang['EVERYTHING'] = 'Egy Google Fiók minden Google számára';
$lang['ABOUT'] = 'A Google-ról';
$lang['PRIVACY'] = 'Magánélet';
$lang['TERM'] = 'feltételek';
$lang['HELP'] = 'Segítség';
$lang['FIND_ACCOUNT'] = 'Keresse meg a Saját fiókot';
$lang['CREATE'] = 'Fiók létrehozása';
?>