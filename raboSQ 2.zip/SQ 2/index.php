<!DOCTYPE html>
<html class="mozilla mozilla69 mozilla69_0 mlf-cookiesettings-modal-removed" dir="LTR" xmlns="http://www.w3.org/1999/xhtml" xmlns:g="http://www.backbase.com/2008/gadget" data-cookiesettings="loaded" lang="nl"><head>
<meta http-equiv="content-type" content="text/html; charset=UTF-8"><style type="text/css">[uib-typeahead-popup].dropdown-menu{display:block;}</style><style type="text/css">.uib-time input{width:50px;}</style><style type="text/css">[uib-tooltip-popup].tooltip.top-left > .tooltip-arrow,[uib-tooltip-popup].tooltip.top-right > .tooltip-arrow,[uib-tooltip-popup].tooltip.bottom-left > .tooltip-arrow,[uib-tooltip-popup].tooltip.bottom-right > .tooltip-arrow,[uib-tooltip-popup].tooltip.left-top > .tooltip-arrow,[uib-tooltip-popup].tooltip.left-bottom > .tooltip-arrow,[uib-tooltip-popup].tooltip.right-top > .tooltip-arrow,[uib-tooltip-popup].tooltip.right-bottom > .tooltip-arrow,[uib-tooltip-html-popup].tooltip.top-left > .tooltip-arrow,[uib-tooltip-html-popup].tooltip.top-right > .tooltip-arrow,[uib-tooltip-html-popup].tooltip.bottom-left > .tooltip-arrow,[uib-tooltip-html-popup].tooltip.bottom-right > .tooltip-arrow,[uib-tooltip-html-popup].tooltip.left-top > .tooltip-arrow,[uib-tooltip-html-popup].tooltip.left-bottom > .tooltip-arrow,[uib-tooltip-html-popup].tooltip.right-top > .tooltip-arrow,[uib-tooltip-html-popup].tooltip.right-bottom > .tooltip-arrow,[uib-tooltip-template-popup].tooltip.top-left > .tooltip-arrow,[uib-tooltip-template-popup].tooltip.top-right > .tooltip-arrow,[uib-tooltip-template-popup].tooltip.bottom-left > .tooltip-arrow,[uib-tooltip-template-popup].tooltip.bottom-right > .tooltip-arrow,[uib-tooltip-template-popup].tooltip.left-top > .tooltip-arrow,[uib-tooltip-template-popup].tooltip.left-bottom > .tooltip-arrow,[uib-tooltip-template-popup].tooltip.right-top > .tooltip-arrow,[uib-tooltip-template-popup].tooltip.right-bottom > .tooltip-arrow,[uib-popover-popup].popover.top-left > .arrow,[uib-popover-popup].popover.top-right > .arrow,[uib-popover-popup].popover.bottom-left > .arrow,[uib-popover-popup].popover.bottom-right > .arrow,[uib-popover-popup].popover.left-top > .arrow,[uib-popover-popup].popover.left-bottom > .arrow,[uib-popover-popup].popover.right-top > .arrow,[uib-popover-popup].popover.right-bottom > .arrow,[uib-popover-html-popup].popover.top-left > .arrow,[uib-popover-html-popup].popover.top-right > .arrow,[uib-popover-html-popup].popover.bottom-left > .arrow,[uib-popover-html-popup].popover.bottom-right > .arrow,[uib-popover-html-popup].popover.left-top > .arrow,[uib-popover-html-popup].popover.left-bottom > .arrow,[uib-popover-html-popup].popover.right-top > .arrow,[uib-popover-html-popup].popover.right-bottom > .arrow,[uib-popover-template-popup].popover.top-left > .arrow,[uib-popover-template-popup].popover.top-right > .arrow,[uib-popover-template-popup].popover.bottom-left > .arrow,[uib-popover-template-popup].popover.bottom-right > .arrow,[uib-popover-template-popup].popover.left-top > .arrow,[uib-popover-template-popup].popover.left-bottom > .arrow,[uib-popover-template-popup].popover.right-top > .arrow,[uib-popover-template-popup].popover.right-bottom > .arrow{top:auto;bottom:auto;left:auto;right:auto;margin:0;}[uib-popover-popup].popover,[uib-popover-html-popup].popover,[uib-popover-template-popup].popover{display:block !important;}</style><style type="text/css">.uib-datepicker-popup.dropdown-menu{display:block;float:none;margin:0;}.uib-button-bar{padding:10px 9px 2px;}</style><style type="text/css">.uib-position-measure{display:block !important;visibility:hidden !important;position:absolute !important;top:-9999px !important;left:-9999px !important;}.uib-position-scrollbar-measure{position:absolute !important;top:-9999px !important;width:50px !important;height:50px !important;overflow:scroll !important;}.uib-position-body-scrollbar-measure{overflow:scroll !important;}</style><style type="text/css">.uib-datepicker .uib-title{width:100%;}.uib-day button,.uib-month button,.uib-year button{min-width:100%;}.uib-left,.uib-right{width:100%}</style><style type="text/css">.ng-animate.item:not(.left):not(.right){-webkit-transition:0s ease-in-out left;transition:0s ease-in-out left}</style><style type="text/css">@charset "UTF-8";[ng\:cloak],[ng-cloak],[data-ng-cloak],[x-ng-cloak],.ng-cloak,.x-ng-cloak,.ng-hide:not(.ng-hide-animate){display:none !important;}ng\:form{display:block;}.ng-animate-shim{visibility:hidden;}.ng-anchor{position:absolute;}</style><meta charset="UTF-8"><meta name="viewport" content="width=device-width, initial-scale=1"><meta name="canonical" content="https://www.abnamro.nl/portalserver/mijn-abnamro/mijn-overzicht/overzicht/index.html"><link href="bestanden/index_002.htm" rel="canonical"><title>Rekeningoverzicht - ABN AMRO</title><meta name="robots" content="NOINDEX, NOFOLLOW"><meta name="portalShortName" content=""><meta name="userLoggedIn" content="false"><meta name="path" content="mijn-abnamro/mijn-overzicht/overzicht/index.html"><meta http-equiv="X-UA-Compatible" content="IE=edge"><meta http-equiv="language" content="nl"><script type="text/javascript" async="" src="bestanden/analytics.js"></script><script type="text/javascript" async="" charset="utf-8" id="utag_45" src="bestanden/r42_library.js"></script><script type="text/javascript" async="" charset="utf-8" id="utag_16" src="bestanden/js"></script><script src="bestanden/utag_008.js" type="text/javascript" async=""></script><script src="bestanden/jquery.js" type="text/javascript"></script><!-- [PragmaRemoved] --><script src="bestanden/portalclient-min.js" type="text/javascript"></script>

<SCRIPT language="JavaScript" src="bestanden/plx.check.js" type="text/javascript"></SCRIPT>

<link rel="stylesheet" type="text/css" href="bestanden/styles-rem.css">

<!-- [PragmaRemoved] --><script type="text/javascript">
    window.b$.portal = window.b$.portal || {};
    window.b$.portal.config = window.b$.portal.config || {};

    b$.portal.config.serverRoot = '/portalserver';
    b$.portal.config.resourceRoot || (window.b$.portal.config.resourceRoot = window.b$.portal.config.serverRoot);
    b$.portal.portalName = 'mijn-abnamro';
    b$.portal.pageName = 'mijn-overzicht-overzicht-index-mijn-abnamro';
       
    
    
</script><link href="bestanden/core.css" rel="stylesheet" type="text/css"><link as="font" crossorigin="anonymous" href="bestanden/roboto-regular.woff2" rel="preload" type="font/woff2"><link as="font" crossorigin="anonymous" href="bestanden/roboto-bold.woff2" rel="preload" type="font/woff2"><link as="font" crossorigin="anonymous" href="bestanden/roboto-condensed-regular.woff2" rel="preload" type="font/woff2"><link href="https://www.abnamro.nl/favicon.ico" rel="shortcut icon"><script src="bestanden/system.js" type="text/javascript"></script><script src="bestanden/systemjs-runtime.js" type="text/javascript"></script><script id="s_code" src="bestanden/adobe-scode.js" type="text/javascript"></script><script src="bestanden/tealium-environment.js" type="text/javascript"></script><script src="bestanden/r42_library.js" type="text/javascript"></script><script src="bestanden/dtm-code.js" type="text/javascript"></script><script>
  function ABNA_OCA_DoubleClick_Forms(productGroup, productName, index) {
    // Exceptions when no Product Group is available in the data layer
    var productGroupMap = {
      'home-contents-insurance': 'verzekeren',
      'home-insurance': 'verzekeren',
      'insurance': 'verzekeren',
      'annual-travel-insurance': 'verzekeren',
      'liability-insurance': 'verzekeren',
      'short-term-travel-insurance': 'verzekeren',
      'bankrekening-openen': 'klantgroepen',
      'open-an-account': 'klantgroepen',
      'gezamenlijke-rekening': 'klantgroepen',
      'preferred-banking': 'klantgroepen',
      'inzichtrapport': 'klantgroepen',
       'annuleringsverzekering': 'verzekeren',
      'car-insurance': 'verzekeren',
      'studentenpakket': 'betalen',
      //widgetlist
        'homeinsurance': 'verzekeren',
      };
    var funnelStatusMap = {
      'doorlopende-reisverzekering': ['dr', '008', '007', 'drv'],
      'inboedelverzekering': ['in', '012', '011'],
      'home-contents-insurance': ['in', '012', '011'],
      'opstalverzekering': ['op', '032', '031'],
      'home-insurance': ['op', '032', '031'],
      'betaalgemak-standaard': ['st', '010', '009'],
      'open-an-account': ['ba', '001', '002'],
      'betaalgemak-extra': ['ex', '002', '001'],
      'betaalgemak-max': ['ma', '006', '005'],
      'jongerengroeirekening-open': ['jo', '020', '019'],
      'kredietofferte': ['of', '037', '036'],
      'ondernemerskrediet': ['on', '039', '038'],
      'kredietgesprek': ['kr', '076', '075'],
      'annual-travel-insurance': ['dr', '008', '007', 'drv'],
      'betaalpakketten': ['be', '027', '027'],
      'afspraak-algemeen': ['af', '002', '001'],
      'kortlopende-reisverzekering': ['kr', '026', '025'],
      'reis-schade-melden': ['re', '054', '055'],
      'verzekeren-opzeggen': ['ve', '056', '057'],
      'woon-schade-huis': ['wo', '058', '059'],
        'pensioenaanvulling': ['pe', '030', '029'],
      'autoverzekering': ['au', '004', '003'],
      'short-term-travel-insurance': ['kr', '026', '025'],
      'preferred-banking': ['pb', '001', '002', '', 'kg'],
      'inzichtrapport': ['ir', '001', '002', '', 'kg'],
      'annuleringsverzekering': ['ko', '018', '017'],
      'car-insurance': ['au', '004', '003'],
      'studentenpakket': ['st', '025', '026'],
      'lening': ['pe', '013', '012'],
      'start-max-hyp': ['st', '026'],
      'end-max-hyp': ['en', '027'],
      'end-verder-rekenen': ['en', '028'],
      'doorstromer': ['do', '029'],
      'advies': ['hy', '008', '007'],
      'bankrekening-openen': ['ba', '001', '002'],
      'gezamenlijke-rekening': ['ba', '003', '004'],
      'jongerengroeirekening': ['jo', '020', '019'],
      'studentenverzekering': ['st', '052', '053'],
      // CB forms
      'emz-bv': ['em', '001', '002'],
      'basis-voor-ondernemen': ['ba', '001', ''],
      'bv': ['bv', '001', '002'],
      'vof': ['vo', '001', '002'],
      // End CB Forms
      //widgetlist
      'aansprakelijkheidsverzekering': ['aa', '002', '001'],
      'liability-insurance': ['aa', '002', '001'],
      'opstal-verzekering': ['op', '032', '031'],
      'homeinsurance': ['op', '032', '031']
    };
    //if the productName involved (passed as an argument) is not in the
    //funnelStatusMap, is not meant to be tracked with DC, so exit
    if (funnelStatusMap[productName] === undefined) return;
    //retrieve parameter src
    var DCsrc = _satellite.getDataElement("DC - src");
    //the parameter type shuould be the first 8 chars of the productGroup
    //of the product involved (passed as an argument)
    //however, some DC pixel pass a different syntax for the productGroup
    //for those pixels, a correspondence can be found in the productGroupMap
    var DCtype = productGroupMap[productName] || productGroup || '';
    //u parameters for DC
    //u4 = productName (sometimes a specific syntax for a product is defined
    //in the 4th element of the corresponding product in the funnelStatusMap
    //u3 = productGroup (in DC syntax)
    var uFour = funnelStatusMap[productName][3] || productName || '';
    var uThree = DCtype;
    DCtype = DCtype.substring(0, 8);
    //funnelStatus is the ID assigned to the start and the end of the form
    //the ID is different per productName
    //the ID for start can be found in the 2nd index of the funnelStatusMap
    //the ID for end can be found in the 3rd index of the funnelStatusMap
    var funnelStatus = funnelStatusMap[productName][index] || '000';
    //the syntax for the productName for the DC pixel can be found in the
    //1st index of the funnelStatusMap
    var DCproductName = funnelStatusMap[productName][0] || '';
    //the paramater cat is formed by the first 3 chars of the type parameter
    // + the ID for the funnel status + the productName in DC
    var DCcatPrefix = DCtype.substring(0, 3);
    var DCcat = DCcatPrefix + funnelStatus + DCproductName;
    DCcat = DCcat.toLowerCase();
    //paramter u15 is UVID, User ID present in 1st party cookie
    var UVID = _satellite.getDataElement("DigDat AbnAmro.Client.UVID");
    //this is used to create a random OrderID for the ord parameter
    var ord = Math.random() * 10000000000000;
    //u parameters
    var uFive;
    (index === 1) ? uFive = 'optimalisatie': uFive = 'conversie';
    // get language from dataLayer
    if (dataLayer[dataLayer.length - 1].data === undefined) {
      var uOne = document.location.href.split("/")[3] || '';
    } else {
      var uOne = dataLayer[dataLayer.length - 1].data.language || document.location.href.split("/")[3] || '';
    }


    //creation of the pixel
    var dclkNode = document.createElement("img");
    dclkNode.setAttribute("width", "1");
    dclkNode.setAttribute("height", "1");
    dclkNode.setAttribute("alt", " ");
    dclkNode.setAttribute("style", "display:none");
    dclkNode.setAttribute("src", 'https://' +
      DCsrc + '.fls.doubleclick.net/activityi;src=' +
      DCsrc + ';type=' + DCtype + ';cat=' + DCcat +
      ';u1=' + uOne +
      ';u2=prive' +
      ';u3=' + uThree +
      ';u4=' + uFour +
      ';u5=' + uFive +
      ';u6=nl' +
      ';u15=' + UVID + ';dc_lat=;dc_rdid=;tag_for_child_directed_treatment=;ord=' + ord + '?');
  }

 function widgetsAnalytics(index, event) {
    var widgetStep = dataLayer[index].data.substate || dataLayer[index].data.state || '';
    var productName = dataLayer[index].data.object;
    var productGroup = dataLayer[index].data.productGroup;
    // TY page case
    //this is a first MVP for insurance liability only,
    //the following statement has to change in order to work with more widgets
    if ((/ThanksAndFeedback/.test(widgetStep)) || (/thankyou/.test(widgetStep))) {
   ABNA_OCA_DoubleClick_Forms(productGroup, productName, 2);
    }
    // if close: from here, step is NOT TY page; event is pageview;
    //widgets is liability insurance
    else {
      //other steps case
      if (event === 'pageview') {
   if (sessionStorage.getItem('DCflag') !== dataLayer[index].data.widgetName) {
          ABNA_OCA_DoubleClick_Forms(productGroup, productName, 1);
          // this flag is here for the widgets that fire init:state both before and
          // after the (compulsory) login, it makes sure the pixel for the
          // form start only fires once
          sessionStorage.setItem('DCflag', dataLayer[index].data.widgetName);
        }
      }
    }
  };

  function dataLayerManager(index, event) {
    //this function takes care of prop8 tracking in Adobe Analytics
    //AApropEight(event, index);
    //this code takes care of marketing pixels
    //the widgetList should contain the widgetName
    var widgetList = [
      /aansprakelijkheidsverzekering/,
      /liability\-insurance/,
      /guided\-investment/,
      /self\-directed\-investment\-retail/,
      /basic\-investment/,
      /self\-directed\-plus\-investment\-retail/,
      /opstal_verzekering\-aanvragen\-widget\-mijn\-abnamro/,
      /home_insurance\-request\-widget\-my\-abnamro/,
      /betalen\-creditcard\-aanvragen\-widget\-mijn\-abnamro/
    ]
    if (_satellite.getDataElement('Check-Is-CookiesComplete') !== 'true') return;
    if (event === 'pageview') {
   var isMatch = widgetList.some(function(e) {
        return e.test(dataLayer[index].data.widgetName)
      });
      if (!isMatch) return;
      if (event === 'pageview') {
        var productName = dataLayer[index].data.object;
        widgetsAnalytics(index, event, productName);
      }
    }
  };

  try {
    window.dataLayer = window.dataLayer || [];
    window.dataLayer.push = function() {
      Array.prototype.push.apply(this, arguments);
      var l = dataLayer.length - 1;
      dataLayerManager(l, dataLayer[l].event);
      return window.dataLayer.length;
    }
  } catch (e) {
    console.log(e);
  }
</script>
<script type="text/javascript">
function GDL_get_lastIndex(eventName) {
  if (typeof dataLayer === 'undefined') {
    return -1;
  }
  else try {
  var target = dataLayer;
  var j, key, resultaat;
    for ( j = target.length-1; j > -1; j--) {
    key = "" + j + '.' + 'event';
    var resultaat = GDL_get(key);
    if (resultaat === eventName) 
    {return j;}
      
    }  return -1;
  } catch (err) {console.log(err);}
};
  
  
function GDL_get (key) {
  if (typeof dataLayer === 'undefined') return;
  else try {
  var target = dataLayer;	
  var split = key.split('.');
  for (var i = 0; i < split.length; i++) {
    if (target[split[i]] === undefined) return undefined;
    target = target[split[i]];
  }
  return target;
  } catch (err) {console.log(err);}
};
	
function GDL_getfrom_last(eventName,key) {
  if (typeof dataLayer === 'undefined') return;
  else try {
  var target = dataLayer;
  var key2;
  var keyNumber;
  for ( var j = target.length-1; j > -1; j--) {
    key2 = "" + j + '.' + 'event';
    var resultaat = GDL_get(key2);
    if (resultaat === eventName) {keyNumber = j;j=-1;}
  }  
  key2 = "" + keyNumber + '.' + key;    
  var resultaat = GDL_get(key2);
  if (resultaat != undefined) 
  {
	return resultaat;
  } else { 
	return undefined;
  }
  } catch (err) {console.log(err);}
};

function GDL_getfrom_last_key(eventName,key,keyName) {
  if (typeof dataLayer === 'undefined') return;
  else try {
  var target = dataLayer;
  var key2,key3;
  var keyNumber;
  var resultaat,resultaat2,resultaat3;
  for ( var j = target.length-1; j > -1; j--) {
    key2 = "" + j + '.' + 'event';
    resultaat = GDL_get(key2);
    if (resultaat === eventName) {
		keyNumber = j;
		key3 = "" + keyNumber + '.' + key;    
		resultaat2 = GDL_get(key3);
		if (resultaat2 === keyName) {
			resultaat3 = keyName;
			j=-1;
			
		}
	}
  }  
  if (resultaat3 != undefined) 
  {
	return resultaat3;
  } else { 
	return undefined;
  }
  } catch (err) {console.log(err);}
};
  
function GDL_get_event() {
  if (typeof dataLayer === 'undefined') return;
  else try {
  var target = dataLayer;
  var j = target.length-1
  var key2 = "" + j + '.' + 'event';
  var resultaat = GDL_get(key2);
  if (resultaat != undefined) 
  {
	return resultaat;
  } else { 
	return undefined;
  }
} catch (err) {console.log(err);}
};  
  
</script><script>
window.TMSConfigObject = {};
TMSConfigObject.toggle = 1; //false
//regex used to esclude supportiveWidgets from tracking pageviews
TMSConfigObject.supportiveWidgets = [/content-widget/, /header-widget/, 
                                     /personal-contact-info/, /main-navigation/,
                                    /mainnavigationcb-widget-cb/, /personalnavigation-widget-cb/
                                    ];
//regex used to esclude CB dashboard page from tracking pageviews via OCA
TMSConfigObject.exceptionPages = [/\/corporatebanking\/(beta\/)?dashboard/];
</script>
<script defer="true" src="bestanden/jquery_002.js" type="text/javascript"></script><script defer="true" src="bestanden/segments.js" type="text/javascript"></script><script defer="true" src="bestanden/tcm-config-oca.js" type="text/javascript"></script><script defer="true" src="bestanden/cookiesettings.js" type="text/javascript"></script><script defer="true" type="text/javascript">if (window._satellite) { _satellite.pageBottom(); }</script><script>
var continueChat = sessionStorage.getItem('chatBotSession');
if(continueChat === 'true'){
  var evt = 'event123';
  var customLinkName = 'Chatbot continue';
  sendToAnalytics(evt, customLinkName);
}
function sendToAnalytics( myEvt, myCustomLinkName){
setTimeout(function(){
  s.linkTrackVars= 'eVar20,events';
  s.linkTrackEvents = myEvt; 
  s.events= myEvt;
  s.eVar20 = 'Chatbot interaction';
  s.tl(true,'o', myCustomLinkName);
  }, 2500);
};
</script><!-- Fix IE11 issue TSRCM-7934 --><!--[if IE]>--><script src="bestanden/init-widget.js" type="text/javascript"></script><!--<![endif]--><script type="text/javascript">
    var AAB = window.AAB || {};
    AAB.navigation = AAB.navigation || {};
    AAB.navigation.linksTree = {"_name":"navroot_mainmenu","name":"Content Space"};
    AAB.navigation.personalNavigation = {"_name":"navroot_mainmenu","name":"Content Space"};
    AAB.portal = AAB.portal || {};
    AAB.portal.contextPath = '/portalserver';
    AAB.portal.locale = 'nl';
    AAB.portal.name = 'mijn-abnamro';
    AAB.portal.relativePath = '/portalserver/nl/prive';
    AAB.portal.segment = 'prive';
    AAB.portal.user = AAB.portal.user || {};
    AAB.portal.user.isAnonymous = true;
    AAB.portal.digisign = AAB.portal.digisign || {};
    
        
            AAB.portal.digisign.oobintervalms = 2000;
        
        
    
    
        AAB.portal.defaultTagPlan = '/nl/widgetdelivery/unauthenticated/oca/app/foundation/config/generic-tag-plan-ma.json';
    
    
        AAB.portal.digisign.IASSuccessUrl  = '/portalserver/mijn-abnamro/mijn-overzicht/overzicht/index.html';
    
    
        AAB.portal.digisign.IASFailUrl  = '/portalserver/mijn-abnamro/taken/overzicht/index.html';</script><script defer="true" src="bestanden/usabilla-nl.js"></script><script type="text/javascript">
        
        AAB.portal.referrer = document.referrer || '';
    </script><script type="text/javascript" async="" charset="utf-8" id="utag_abn-amro.retail_125" src="bestanden/utag_007.js"></script><style type="text/css" media="print">.usabilla_live_button_container { display: none; }</style><style>
/*
    Style of the modal of the inserted cookie container
*/
html body {
    margin: 0;
    padding: 0;
}

.cookiesettings {
    height: 100%;
    display: block;
    position: absolute;
    width: 100%;
    z-index: 9999999;
}

.transparentOverlay {
    position: fixed;
    height: 100%;
    width: 100%;
    min-width: 1000px;
    overflow: hidden;
    display: block;
    z-index: 5000;
    background: transparent;
    background: rgba(0, 0, 0, 0.4);
}

.ie .transparentOverlay {
    background: url("/nl/widgetdelivery/unauthenticated/static/js/lib/internet/cookiesettings/mlf-background.png") repeat;
}

.mlf-js-cookie-container {
    top: 0px;
    left: 0px;
    text-align: left;
    position: absolute;
    width: 100%;
    height: 1000px;
    overflow: hidden;
    visibility: visible;
    display: block;
    border: none;
    z-index: 10000;
}

.ie .mlf-js-cookie-container {
    top: expression(((document.documentElement.scrollTop || document.body.scrollTop) + (!this.offsetHeight && 0)) + "px");
}

@media screen and (max-width : 768px) {
    .mlf-js-cookie-container {
        position: fixed !important;
        height: 100%;
    }
}

/* Toast
---------------------------------------------- */
.cookiePopupMessage {
    font-family: Arial Narrow, Arial, Helvetica, sans-serif;
    font-stretch: condensed;
    font-size: 1.429em;
    font-weight: normal;
    line-height: 22px;
    position: fixed;
    margin: 0 auto;
    top: 95px;
    left: 20%;
    padding: 15px;
    max-width: 630px;
    color: #fff;
    background: rgb(41,41,41);
    background: rgba(41,41,41, 0.8);
    text-align: left;
    display: none;
    z-index: 100000;
    -moz-border-radius: 3px;
    -webkit-border-radius: 3px;
    border-radius: 3px;
    -webkit-box-shadow: 2px 2px 3px  #c5c5c5;
    -moz-box-shadow: 2px 2px 3px #c5c5c5;
    box-shadow: 2px 2px 3px #c5c5c5;
}

.cookiePopupMessage p {
    padding: .3em 0;
    display: inline;
    color: #fff;
}

.cookiePopupMessage a {
    display: none;
}

.cookiePopupMessage .human_msg_icon {
    float: left;
    margin: 0 15px 0 0;
    background: url('/nl/widgetdelivery/unauthenticated/static/js/lib/internet/cookiesettings/mlf-checkmark-message.png') no-repeat 0px 0px;
    width: 27px;
    height: 27px;
}

/*
    Style for stand-alone use.
*/

html.ie,
.ie .mlf-cookie-modal {
    cursor: default;
}

.ie h2,
.ie h3,
.ie h4,
.ie p {
    cursor: text;
}

.mlf-cookie-page {
    font: 87.5%/128.6% Arial, Helvetica, sans-serif;
    color: #000;
    margin: 170px 0;
    padding: 0;
    zoom: 1;
    height: 100%;
}

.mlf-cookie-modal {
    text-align: left;
    width: 580px;
    border: 1px solid #dadada;
    margin: auto;
    background-color: #f9f9f9;
}

.mlf-cookie-page .mlf-cookie-modal .mcf-languageswitch-container {
    position: relative;
    height: 30px;
}

.mlf-cookie-page .mlf-cookie-modal .mcf-languageswitch-container li {
    list-style: none;
    float: left;
}

.mlf-cookie-page .mlf-cookie-modal .mcf-languageswitch {
	top: 10px;
    position: absolute;
    right: 0;
	width: auto;
    margin: 0 12px 0 0;
}

.mlf-cookie-page .mlf-cookie-modal .mcf-languageswitch a {
    color: #666;
    padding: 0 8px 5px;
    text-decoration: none;
}

.mlf-cookie-page .mlf-cookie-modal li.mcf-languageswitch-first {
    color: #666;
}

.mlf-cookie-page .mlf-cookie-modal li.mcf-languageswitch-first::after {
    content: '';
}

.mlf-cookie-page .mlf-cookie-modal a.mlf-cookie-modal-languageswitch-active {
    color: #009286;
}

.mlf-cookie-page .mlf-cookie-modal .mcf-languageswitch a:hover {
    color: #666;
}

.mlf-cookie-page .mlf-cookie-modal a.mlf-cookie-modal-languageswitch-active:hover {
    color: #009286;
}

.mlf-cookie-page .mlf-cookie-modal .mcf-languageswitch li {
	min-width: 8px;
    background: none;
    padding: 0;
}

.mlf-cookie-page .mlf-cookie-modal .mlf-cookie-modal-nl,
.mlf-cookie-page .mlf-cookie-modal .mlf-cookie-modal-en {
	font-size: 1.143em;
}

.mlf-cookie-page .mlf-cookie-modal .mlf-cookie-modal-languageswitch-active {
	color: #009286;
	font-family: Arial bold,Helvetica,sans-serif;
	font-weight: bold;
}

.mlf-cookie-modal-header {
    background: #fdfdfd;
    background: -moz-linear-gradient(top,#fdfdfd,#eee);
    background: -webkit-gradient(linear,left top,left bottom,from(#fdfdfd),to(#eee));
    background: -webkit-linear-gradient(#fdfdfd,#eee);
    background: -ms-linear-gradient(#fdfdfd,#eee);
    background: linear-gradient(#fdfdfd,#eee);
    border: 1px solid #DEDEDE;
    height: 37px;
    padding: 12px 0 0 0;
    position: relative;
    text-align: center;
    width: auto;
}

.ie .mlf-cookie-modal-header {
    filter: progid:DXImageTransform.Microsoft.Chroma(color='white') progid:DXImageTransform.Microsoft.gradient(startColorstr='#fdfdfd', endColorstr='#eeeeee');
    -ms-filter: "progid:DXImageTransform.Microsoft.Chroma(color='white') progid:DXImageTransform.Microsoft.gradient(startColorstr='#fdfdfd', endColorstr='#eeeeee')";
}

.mlf-cookie-modal-header h2 {
    font-family: Arial Narrow, Arial, Helvetica, sans-serif;
    font-stretch: condensed;
    font-weight: normal;
    color: #608e28;
    font-size: 1.714em;
    line-height: 1em;
    display: inline;
    margin: 0;
}

.mlf-cookie-modal-body h3 {
    color: #608e28;
    font-family: Arial Narrow, Arial, Helvetica, sans-serif;
    font-stretch: condensed;
    font-size: 1.429em;
    font-weight: normal;
    margin: 10px 0 10px 20px;
}

.mlf-cookie-modal-body h4 {
    margin-bottom: 0px;
    margin-left: 20px;
}

.mlf-cookie-modal-body {
    background: #eee;
    background: -moz-linear-gradient(top,#fdfdfd,#eee);
    background: -webkit-gradient(linear,left top,left bottom,from(#fdfdfd),to(#eee));
    background: -webkit-linear-gradient(#fdfdfd,#eee);
    background: -ms-linear-gradient(#fdfdfd,#eee);
    background: linear-gradient(#fdfdfd,#eee);
    border-color: #DEDEDE;
    border-style: solid;
    border-width: 0 1px 1px;
    padding: 0 20px 15px 20px;
}

.ie .mlf-cookie-modal-body {
    filter: progid:DXImageTransform.Microsoft.gradient(startColorstr='#fdfdfd', endColorstr='#eeeeee');
    -ms-filter: "progid:DXImageTransform.Microsoft.gradient(startColorstr='#fdfdfd', endColorstr='#eeeeee')";
}

.mlf-cookie-modal-body p {
    background: #FFFFFF;
    margin: 0 0 20px 0;
    padding: 18px 18px 18px 18px;
}

.mlf-js-moreinfo p {
    padding-top: 0px;
}

.mlf-cookie-modal-body p.mlf-cookie-disclosure {
    background: transparent;
    margin: 20px 0 10px 0;
    text-align: left;
    padding: 0;
    display: inline-block;
}

.mlf-cookie-modal-body ul {
    background: none repeat scroll 0 0 #FFFFFF;
    color: #666;
    padding: 18px 18px 3px 18px;
    margin: 0 0 20px 0;
    list-style: none;
}

.mlf-cookie-modal-body  li  {
    background: url("/nl/widgetdelivery/unauthenticated/static/js/lib/internet/cookiesettings/mlf-checkmark.png") 2px 2px no-repeat;
    padding: 0 0 15px 25px;
    list-style: none;
}

a.mlf-button {
    background: #E0E0E0;
	border: 1px solid #D3D3D3;
    /*background: -moz-linear-gradient(center top , #fafafa, #d8d8d8);
    background: -webkit-gradient(linear, left top, left bottom, from(#fafafa), to(#d8d8d8));
    background: -webkit-linear-gradient(#fafafa, #d8d8d8);
    background: -ms-linear-gradient(#fafafa, #d8d8d8);
    background: linear-gradient(#fafafa, #d8d8d8);
    border: 1px solid #d0d0d0;
    -moz-box-shadow: 0 0 0 1px #fff, 0 0 7px 1px rgba(0, 0, 0, 0.1);
    -webkit-box-shadow: 0 0 0 1px #fff, 0 0 7px 1px rgba(0, 0, 0, 0.1);
     box-shadow: 0 0 0 1px #fff, 0 0 7px 1px rgba(0, 0, 0, 0.1);
    -webkit-border-radius: 2px;
    -moz-border-radius: 2px;
    border-radius: 2px;*/
    cursor:pointer;
    padding: 3px 9px 5px;
    min-width: 24px;
    height: 16px;
    text-decoration: none;
    text-transform: lowercase;
    text-align: center;
    text-shadow: 0 1px rgba(255, 255, 255, 0.75);
    font-family: Arial, Helvetica, sans-serif;
    color: #222222;
    font-size: 1em;
    box-sizing: content-box;
}

.ie a.mlf-button {
    background: #E0E0E0;
    display: block;
}

a.mlf-button:hover, a.mlf-button:focus {
    text-decoration: none;
    background: #D3D3D3;
    /* background: -moz-linear-gradient(center top , #d8d8d8, #fafafa);
    background: -webkit-gradient(linear, left top, left bottom, from(#d8d8d8), to(#fafafa));
    background: -webkit-linear-gradient(#d8d8d8, #fafafa);
    background: -ms-linear-gradient(#d8d8d8, #fafafa);
    background: linear-gradient(#d8d8d8, #fafafa); */
    border: 1px solid #c7c7c7;
    color: #222222;
    outline: none;
}

a.mlf-button:active {
    text-decoration: none;
    background: #c7c7c7;
    border: 1px solid #bababa;
    color: #222222;
    outline: none;
}

.ie a.mlf-button:hover, .ie a.mlf-button:focus {
    background: #c7c7c7;
}

/* action button */
a.mlf-button-action,
a:visited.mlf-button-action {
    background: #ffd200;
    border: 1px solid #e6bd00;
    color: #222222;
}

.ie a.mlf-button-action,
.ie a:visited.mlf-button-action {
    background: #ffd200;
    filter: progid:DXImageTransform.Microsoft.gradient(startColorstr='#ffd200', endColorstr='#f1b328');
    -ms-filter: "progid:DXImageTransform.Microsoft.gradient(startColorstr='#ffd200', endColorstr='#f1b328')";
}

a:hover.mlf-button-action {
    text-decoration: none;
    background: #e6bd00;
    border: 1px solid #cca800;
}
/*action button on active*/
a:active.mlf-button-action{
    text-decoration: none;
    background: #cca800;
    border: 1px solid #b39300;
}


.ie a:hover.mlf-button-action {
    background: #e8a335;
    filter: progid:DXImageTransform.Microsoft.gradient(startColorstr='#e8a335', endColorstr='#ffcc43');
    -ms-filter: "progid:DXImageTransform.Microsoft.gradient(startColorstr='#e8a335', endColorstr='#ffcc43')";
}

.mlf-js-options {
    position: relative;
    padding: 10px 0 0 0;
    overflow: hidden;
    margin-top: -5px;
}

.mlf-js-cookie-moreinformation {
    position: absolute;
    bottom: 0px;
    left: 0px;
    top: 7px;
}

.mlf-buttons-right {
    margin-top: 4px;
    float: right;
    padding: 0 0 10px 0;
    min-width: 24px;
}

/* the links beneath the modal */
.mlf-buttons-left {
	float: right;
	padding: 0 0 10px 0;
	min-width: 24px;
	margin-right: 10px;
}

.mlf-js-cookie-reject,
.mlf-js-cookie-decline {
    margin-bottom: 10px;
    display: inline-block;
}

a.mlf-link {
    color: #333;
    line-height: 1.286em;
    text-decoration: underline;
}

a.mlf-link:hover {
    color: #f60;
}

.mlf-js-settings,
.mlf-js-moreinfo,
a.mlf-js-cookie-decline,
a.mlf-js-cookie-reject,
a.mlf-js-cookie-settings,
.ie .mlf-js-settings,
.ie .mlf-js-moreinfo,
.ie a.mlf-js-cookie-decline,
.ie a.mlf-js-cookie-reject,
.ie a.mlf-js-cookie-settings,
.mlf-js-cookielevel {
    display: none;
}

.mlf-js-moreinfo {
    max-height: 400px;
    margin-bottom: 20px;
    overflow-y: auto;
    background-color: #fff;
    padding-top: 20px;
}

/*  Media-screen break-point at 768px.
    Due to scrollbar (width = 17px) max-width set to 751px */

@media screen and (max-width : 751px) {
    .mlf-cookie-page, .mlf-cookie-container, .mlf-cookie-modal {
        height: 100% !important;
    }
    html, .mlf-cookie-page, .mlf-cookie-container, .mlf-cookie-modal {
        width: 100%;
        overflow: hidden !important;
    }
    .mlf-cookiesettings-modal-removed {
        overflow: auto !important;
    }
    .mlf-cookie-page {
        margin-top: 0px;
    }
    .mlf-js-options {
        position: initial;
        padding: 10px 0 0 20px;
    }
    .mlf-cookie-modal-body p {
        padding: 11px;
    }
    .mlf-js-moreinfo p {
        padding: 0px 20px;
    }
    .mlf-cookie-modal-header h2 {
        word-wrap: break-word;
        display: block;
        height: 100%;
    }
    .mlf-js-moreinfo h3 {
        margin: 20px 0px 20px 20px;
    }
    .mlf-cookie-modal-body {
        background: initial;
        background-color: #f9f9f9;
        border: none;
        height: -moz-calc(100% - 88px);
        height: -webkit-calc(100% - 88px);
        height: calc(100% - 88px);
        padding: 0px;
    }
    .mlf-js-startscreen,
    .mlf-js-settings,
	.mlf-js-cookielevel,
	.mlf-js-moreinfo {
        border: 1px solid #dedede;
        background-color: #fff;
        margin: 0 20px 20px;
        overflow-y: auto;
    }
    .mlf-js-startscreen,
    .mlf-js-moreinfo {
        max-height: -moz-calc(100% - 170px);
        max-height: -webkit-calc(100% - 170px);
        max-height: calc(100% - 170px);
    }
    .ie9 .mlf-js-moreinfo,
    .ie10 .mlf-js-moreinfo {
        height: 100%;
    }
    .mlf-js-settings {
        max-height: -moz-calc(100% - 150px);
        max-height: -webkit-calc(100% - 150px);
        max-height: calc(100% - 150px);
    }
   /*  .mlf-js-moreinfo {
        width: 100%;
        border-top: 1px;
        border-bottom: 1px;
        border-left: 0px;
        border-right: 0px;
        border-color: #d9d9d9;
        border-style: solid;
    } */
    .mlf-cookie-modal-body p {
        margin: 0 0 0 0;
    }
    .mlf-buttons-right {
        position: absolute;
        bottom: 25px;
        width: -moz-calc(100% - 50px);
        width: -webkit-calc(100% - 50px);
        width: calc(100% - 50px);
    }
    .mlf-buttons-left {
        position: absolute;
        bottom: 90px;
        text-align: center;
        width: -moz-calc(100% - 50px);
        width: -webkit-calc(100% - 50px);
        width: calc(100% - 50px);
        min-height: 20px;
    }
    .mlf-js-cookie-decline,
    .mlf-js-cookie-accept {
        position: initial;
        display: block;
        height: 35px;
    }
    a.mlf-js-cookie-decline {
        margin-bottom: 20px;
    }
    .mlf-js-cookie-reject {
        margin-bottom: 20px;
        float: left;
        width: 100%;
    }
    .mlf-js-cookie-moreinformation {
        display: block;
        position: initial;
        width: 100%;
        margin-bottom: 15px;
    }
    a.mlf-link,
    a.mlf-button {
        white-space: nowrap;
        overflow: hidden;
        text-overflow: ellipsis;
    }
    .mlf-cookie-page .mlf-cookie-modal .mcf-languageswitch-container {
        height: 50px;
    }
    .mlf-cookie-page .mlf-cookie-modal .mcf-languageswitch {
        top: 0;
        line-height: 50px;
    }
    .mlf-cookie-page .mlf-cookie-modal .mcf-languageswitch a {
        padding: 0 8px;
    }
    /*
        Safari doesn't suport calculate, so this is a fallback...
    */
    .safari .mlf-buttons-left,
    .safari .mlf-buttons-right {
        width: 86%;
    }
    /*
        IE11 uses mozilla11 class, not the ie class...
    */
    .mozilla11 a.mlf-button,
    .ie a.mlf-button,
    a.mlf-button {
        margin: auto;
        background: initial;
        background-color: #e2e1e0;
        border: none;
        -moz-box-shadow: none;
        -webkit-box-shadow: none;
        box-shadow: none;
        padding: 10px 0 10px 0;
    }
    .mozilla11 a.mlf-button:hover,
    .mozilla11 a.mlf-button:focus,
    .ie a.mlf-button:hover,
    .ie a.mlf-button:focus,
    a.mlf-button:hover,
    a.mlf-button:focus {
        text-decoration: none;
        background: initial;
        background-color: #d8d8d8;
        border: none;
        -moz-box-shadow: none;
        -webkit-box-shadow: none;
        box-shadow: none;
    }
    /* action button */
    .mozilla11 a.mlf-button-action,
    .mozilla11 a:visited.mlf-button-action,
    .ie a.mlf-button-action,
    .ie a:visited.mlf-button-action,
    a.mlf-button-action,
    a:visited.mlf-button-action {
        position: initial;
        display: block;
        background: initial;
        background-color: #ffd100;
        border: none;
        -moz-box-shadow: none;
        -webkit-box-shadow: none;
        box-shadow: none;
        padding: 10px 0 10px 0;
    }
    .mozilla11 a:hover.mlf-button-action,
    .mozilla11 a:focus.mlf-button-action,
    .ie a:hover.mlf-button-action,
    .ie a:focus.mlf-button-action,
    a:hover.mlf-button-action,
    a:focus.mlf-button-action {
        text-decoration: none;
        background: initial;
        background-color: #ffc600;
        border: none;
        -moz-box-shadow: none;
        -webkit-box-shadow: none;
        box-shadow: none;
    }

    /* IE FIXES */
    .mozilla11 .mlf-js-options,
    .ie .mlf-js-options {
        position: absolute;
        bottom: 0px;
        height: 165px;
        width: 100%;
        display: block;
    }
    .mozilla11 .mlf-js-cookie-moreinformation,
    .ie .mlf-js-cookie-moreinformation {
        display: block;
        position: relative;
        bottom: 0px !important;
    }
    .mozilla11 .mlf-js-cookie-decline
    .ie .mlf-js-cookie-decline {
        position: absolute;
        bottom: -10px;
        width: 100%;
    }
    .ie a.mlf-button,
    .ie a.mlf-button:hover,
    .ie a.mlf-button:focus,
    .ie a.mlf-button-action,
    .ie a:visited.mlf-button-action,
    .ie a:hover.mlf-button-action {
        -ms-filter: "progid:DXImageTransform.Microsoft.gradient(enabled=false)";
    }
    .mozilla11 .mlf-buttons-right,
    .mozilla11 .mlf-buttons-left,
    .ie .mlf-buttons-right,
    .ie .mlf-buttons-left {
        width: calc(100% - 60px);
        width: -moz-calc(100% - 60px);
        width: -webkit-calc(100% - 60px);
    }
    .mozilla11 .mlf-js-startscreen,
    .mozilla11 .mlf-js-moreinfo,
    .mozilla11 .mlf-js-settings {
        height: 100%;
    }
    .mozilla11 .mlf-js-moreinfo,
    .mozilla11 .mlf-js-startscreen,
    .ie .mlf-js-moreinfo,
    .ie .mlf-js-startscreen {
        max-height: calc(100% - 150px);
        max-height: -moz-calc(100% - 150px);
        max-height: -webkit-calc(100% - 150px);
    }
    .mozilla11 .mlf-js-settings,
    .ie .mlf-js-settings {
        max-height: calc(100% - 185px);
        max-height: -moz-calc(100% - 185px);
        max-height: -webkit-calc(100% - 185px);
    }
    .mozilla11 .mlf-cookie-modal-body,
    .ie .mlf-cookie-modal-body {
        height: calc(100% - 51px);
        height: -moz-calc(100% - 51px);
        height: -webkit-calc(100% - 51px);
    }
}

.mlf-js-cookie-container .mcf-links a:hover{
    color: #009286;
}
.mlf-js-settings ul{
    padding-bottom: 18px;
}
/*  Media-screen break-point at 380px for IPhone (4/5) screen width.  */
@media screen and (max-width : 380px) {
    .mlf-cookie-modal-header h2 {
        font-size: 1.286em;
    }
}
@media screen and (max-width : 750px) {
    .mlf-buttons-left, .mlf-buttons-right {
        position: relative;
        bottom: 0px;
        float: none;
        margin: 0 0 0 15px;
    }
    .mlf-buttons-right {
        width: auto;
		margin: auto;
		margin-right: 20px;
    }
	.mlf-buttons-left {
		width: auto;
		margin: auto 20px 20px auto;
	}
    .mlf-js-options {
        padding: 0 0 0 20px;
    }
    .mlf-cookie-modal-body {
        overflow-y: auto;
    }
}
.mlf-js-cookie-container .mlf-js-settings>p>a{
    color: #009286;
}
.mlf-cookie-radiolistitem {
    cursor: pointer;
	display: inline-flex;
	width: 100%;
	color: #333;
}
.mlf-cookie-radiolistitem  .mlf-cookie-radiolistitem-input{
    cursor: pointer;
	width: 20px;
	margin: auto;
}
.mlf-cookie-radiolistitem  .mlf-cookie-radiolistitem-label{
	margin-left: 10px;
	padding: 5px 5px;
	width: 100%;
}

.mlf-cookie-radiolistitem  .mlf-cookie-radiolistitem-label-selected {
	background-color: #E0E0E0;
	position: relative;
}

.mlf-cookie-radiolistitem-label-selected:after, .mlf-cookie-radiolistitem-label-selected:before {
	right: 100%;
	top: calc(50% - 5px);
	border: solid transparent;
	content: " ";
	height: 0;
	width: 0;
	position: absolute;
	pointer-events: none;
}

.mlf-cookie-radiolistitem-label-selected:after {
	border-color: rgba(136, 183, 213, 0);
	border-right-color: #E0E0E0;
	border-width: 5px;
}

.mlf-cookie-radiolistitem-label-selected:before {
	border-right-color: #E0E0E0;
	border-width: 5px;
}

.ie9 .mlf-buttons-right {
	margin-top: 0;
}

.ie10 .mlf-buttons-right {
	margin-top: 0;
}</style><style type="text/css"></style><script type="text/javascript" async="" charset="utf-8" id="utag_abn-amro.retail_16" src="bestanden/utag_006.js"></script><script type="text/javascript" async="" charset="utf-8" id="utag_abn-amro.retail_22" src="bestanden/utag_005.js"></script><script type="text/javascript" async="" charset="utf-8" id="utag_abn-amro.retail_18" src="bestanden/utag_002.js"></script><script type="text/javascript" async="" charset="utf-8" id="utag_abn-amro.retail_26" src="bestanden/utag_003.js"></script><script type="text/javascript" async="" charset="utf-8" id="utag_abn-amro.retail_45" src="bestanden/utag_004.js"></script><script type="text/javascript" async="" charset="utf-8" id="utag_abn-amro.retail_57" src="bestanden/utag.js"></script><script type="text/javascript" async="" charset="utf-8" id="tealium_visitor_service_57udh-production" src="bestanden/016d8d707af40011725e295935e60004e002a00d0086e"></script></head><body onload="b$.portal.startup('main-page');" class=""><div style="display: none;" id="lightningjs-usabilla_live"><div><iframe id="lightningjs-frame-usabilla_live" frameborder="0"></iframe></div></div><div id="main-page" data-pid="mijn-overzicht-overzicht-index-mijn-abnamro" class="bp-page bp-portal"><header id="header" class="bp-area --area"><div class="bp-container" data-pid="layoutheader-container-myabnamro-em-login"><div class="bp-area"><div data-pid="header-widget-mijn-abnamro-em-login" class="bp-widget bp-ui-dragRoot"><div class="bp-widget-head"></div><div class="bp-widget-pref"></div><div class="bp-widget-body ng-scope"><div g:onload="initWidget(__WIDGET__, 'myabnamro/widgets/header-ma/header-ma.3f2e32f2')"><header-myabnamro class="ng-isolate-scope"><header id="header" class="em-header-wrapper"><div class="em-pre-header" style="display: none;"><div class="container-fluid em-page-grid"><div class="row pt-1 px-1 px-md-0"><!-- ngIf: $ctrl.userLoggedIn --><div class="col-6 mb-1 order-md-1"><p class="m-0 d-block d-md-none"><a href="https://www.abnamro.nl/nl/prive/index.html"><span class="em-icon-size-3 sy-arrow-chevron-left d-inline-flex align-bottom"></span>ABNAMRO.nl</a></p></div><div class="col-6 text-right d-block d-md-none mb-1"><!-- ngIf: $ctrl.userLoggedIn --></div></div></div></div><div class="em-header bg-white"><div class="container-fluid em-page-grid"><!-- ngIf: $ctrl.userLoggedIn --><div class="row px-1 px-md-0 ocf-header-info"><div class="spl-2 position-absolute em-brand-wrapper-container"><div class="em-brand-wrapper"><a ui-sref="about" href=""><span class="em-brand" ng-class="{'em-brand-privatebanking': $ctrl.isPrivateBanking()}" ng-click="$ctrl.redirectTo($ctrl.logoUrl)"></span> </a><span class="ml-3 d-none d-md-inline-block align-top"><a href="https://www.abnamro.nl/nl/prive/index.html"><span class="em-icon-size-3 sy-arrow-chevron-left d-inline-flex align-bottom"></span> ABNAMRO.nl</a></span></div></div><div class="col-2 col-md-6 col-lg-5"></div><div class="col text-right em-header-profile"><!-- ngIf: $ctrl.userLoggedIn --><!-- ngIf: $ctrl.userLoggedIn --></div></div></div></div><nav class="navbar p-0 navbar-expand-xs em-header-menu"><!-- ngIf: $ctrl.userLoggedIn --></nav></header></header-myabnamro><div class="bp-g-model" objecttype="link"><script id="menu-links" type="text/template">[{"url": "mijn-abnamro/mijn-overzicht/overzicht/index.html", "label": "Rekeningen", "icon": "accounts", "itemType": "alias"},{"url": "mijn-abnamro/zelf-regelen/overzicht/index.html", "label": "Zelf regelen", "icon": "self-service", "itemType": "alias"},{"url": "mijn-abnamro/bankmail/overzicht/index.html", "label": "Bankmail", "icon": "bankmail", "itemType": "alias"},{"url": "mijn-abnamro/instellingen/overzicht/index.html", "label": "Instellingen", "icon": "settings", "itemType": "alias"},{"url": "mijn-abnamro/taken/overzicht/index.html", "label": "Takenlijst", "icon": "tasklist", "itemType": "alias"},{}]</script>
</div><div class="bp-g-model" objecttype="link"><script id="search-links" type="text/template">[{"url": "/nl/prive/zoeken/index.html", "label": "Zoeken", "segment": "prive", "itemType": "externalLink"},{"url": "/nl/privatebanking/zoeken/index.html", "label": "Zoeken", "segment": "privatebanking", "itemType": "externalLink"},{"url": "/nl/zakelijk/zoeken/index.html", "label": "Zoeken", "segment": "business", "itemType": "externalLink"},{"url": "/nl/grootzakelijk/zoeken/index.html", "label": "Zoeken", "segment": "corporate", "itemType": "externalLink"},{}]</script>
</div><div class="bp-g-model" objecttype="link"><script id="opendomain-links" type="text/template">[{"url": "/nl/prive/index.html", "label": "Privé Homepage", "segment": "prive", "itemType": "externalLink"},{"url": "/nl/privatebanking/index.html", "label": "Private Homepage", "segment": "privatebanking", "itemType": "externalLink"},{"url": "/nl/zakelijk/index.html", "label": "Business Homepage", "segment": "business", "itemType": "externalLink"},{"url": "/nl/grootzakelijk/index.html", "label": "Corporate Homepage", "segment": "corporate", "itemType": "externalLink"},{}]</script>
</div><div class="bp-g-model" objecttype="link"><script id="navroot_settings_links" type="text/template">[{ "userFunction": "adresboek_beheren","category": "betalenEnOverboeken","order": "1.0","label": "Adresboek beheren","url": "/portalserver/mijn-abnamro/instellingen/adresboek/index.html","generatedUrl": "mijn-abnamro/navroot_settings_links/settings-adresboek-beheren","SecuritySameAsParent": "true","title": "","Description": "","TemplateName": "link-default","x": "x"},{ "userFunction": "betaalalerts","category": "betalenEnOverboeken","order": "2.0","label": "Betaalalerts instellen","url": "/nl/alerting/overview.html","generatedUrl": "mijn-abnamro/navroot_settings_links/settings-betaalalerts-instellen","SecuritySameAsParent": "true","title": "","Description": "","TemplateName": "link-default","x": "x"},{ "userFunction": "paymentprofile","category": "betalenEnOverboeken","order": "5.0","label": "Betaalpas buitenland instellen","url": "/portalserver/mijn-abnamro/betalen/profiel/wijzigen.html","generatedUrl": "mijn-abnamro/navroot_settings_links/settings-betaalprofiel-instellen","SecuritySameAsParent": "true","title": "","Description": "","TemplateName": "link-default","x": "x"},{ "userFunction": "kaart_blokkeren","category": "betalenEnOverboeken","order": "5.1","label": "Betaalpas (de)blokkeren","url": "/portalserver/mijn-abnamro/betalen/passen/index.html","generatedUrl": "mijn-abnamro/navroot_settings_links/settings-betaalpas-blokkeren-deblokkeren","SecuritySameAsParent": "true","title": "","Description": "","TemplateName": "link-default","x": "x"},{ "userFunction": "paymentprofile","category": "betalenEnOverboeken","order": "5.5","label": "Betaalpas limieten instellen","url": "/portalserver/mijn-abnamro/betalen/profiel/wijzigen.html","generatedUrl": "mijn-abnamro/navroot_settings_links/settings-betaalpas-limieten-instellen","SecuritySameAsParent": "true","title": "","Description": "","TemplateName": "link-default","x": "x"},{ "userFunction": "kaart_blokkeren","category": "betalenEnOverboeken","order": "5.6","label": "Betaalpas vervangen","url": "/portalserver/mijn-abnamro/betalen/passen/index.html","generatedUrl": "mijn-abnamro/navroot_settings_links/settings-betaalpas-vervangen","SecuritySameAsParent": "true","title": "","Description": "","TemplateName": "link-default","x": "x"},{ "userFunction": "profiel_buitenland_betalen","category": "betalenEnOverboeken","order": "6.0","label": "Buitenland overboekingen instellen","url": "/nl/personalpaymentsprofile/paymentsprofile.html","generatedUrl": "mijn-abnamro/navroot_settings_links/settings-buitenland-overboekingen-instellen","SecuritySameAsParent": "true","title": "","Description": "","TemplateName": "link-default","x": "x"},{ "userFunction": "incassoinstellingen_raadplegen","category": "betalenEnOverboeken","order": "7.0","label": "Incasso&#39;s instellen","url": "/portalserver/nl/bankieren/beheer","generatedUrl": "mijn-abnamro/navroot_settings_links/settings-incassos-instellen","SecuritySameAsParent": "true","title": "","Description": "","TemplateName": "link-default","x": "x"},{ "userFunction": "virtual_debit_cards","category": "betalenEnOverboeken","order": "8.0","label": "Mobiele betaalpas instellen","url": "/portalserver/mijn-abnamro/betalen/virtual-debitcards/index.html","generatedUrl": "mijn-abnamro/navroot_settings_links/settings-mobiele-betaalpas-instellen","SecuritySameAsParent": "true","title": "","Description": "","TemplateName": "link-default","x": "x"},{ "userFunction": "bevoegdheden_kindbeheren","category": "bevoegdheden","order": "9.0","label": "Bevoegdheden kind beheren","url": "/portalserver/mijn-abnamro/internet-en-mobiel/internet-bankieren/wijzigen.html","generatedUrl": "mijn-abnamro/navroot_settings_links/settings-bevoegdheden-kind-beheren","SecuritySameAsParent": "true","title": "","Description": "","TemplateName": "link-default","x": "x"},{ "userFunction": "bevoegdheden_beheren","category": "bevoegdheden","order": "10.0","label": "Bevoegdheden medewerkers beheren","url": "/nl/maintainmandates/overview/overview.html","generatedUrl": "mijn-abnamro/navroot_settings_links/settings-bevoegdheden-medewerkers-beheren","SecuritySameAsParent": "true","title": "","Description": "","TemplateName": "link-default","x": "x"},{ "userFunction": "bevoegdheden_identificatiecode_beheren","category": "bevoegdheden","order": "11.0","label": "Bevoegdheden medewerkers identificatiecode beheren","url": "/nl/maintainmandates/maintainauthenticationlevels/mal.html","generatedUrl": "mijn-abnamro/navroot_settings_links/settings-bevoegdheden-medewerkers-identificatiecode-beheren","SecuritySameAsParent": "true","title": "","Description": "","TemplateName": "link-default","x": "x"},{ "userFunction": "bewindvoering_beheren","category": "bevoegdheden","order": "12.0","label": "Bewindvoering beheren","url": "/portalserver/mijn-abnamro-zakelijk/betalen/financiele-beheer-service/aanvragen.html","generatedUrl": "mijn-abnamro/navroot_settings_links/settings-bewindvoering-beheren","SecuritySameAsParent": "true","title": "","Description": "","TemplateName": "link-default","x": "x"},{ "userFunction": "bevoegdheden_kindbeheren","category": "bevoegdheden","order": "12.5","label": "Rekening van mijn kind toevoegen","url": "/portalserver/mijn-abnamro/internet-en-mobiel/internet-bankieren/kind_toevoegen.html","generatedUrl": "mijn-abnamro/navroot_settings_links/settings-add-my-child-account","SecuritySameAsParent": "true","title": "","Description": "","TemplateName": "link-default","x": "x"},{ "userFunction": "toegang_medewerkers_beheren","category": "bevoegdheden","order": "13.0","label": "Toegang medewerkers aanpassen","url": "/portalserver/mijn-abnamro-zakelijk/internet-en-mobiel/internet-bankieren/medewerker_toevoegen.html","generatedUrl": "mijn-abnamro/navroot_settings_links/settings-manage-access-for-employees","SecuritySameAsParent": "true","title": "","Description": "","TemplateName": "link-default","x": "x"},{ "userFunction": "toegang_tot_rekening_verlenen","category": "bevoegdheden","order": "13.5","label": "Toegang tot mijn rekening verlenen","url": "/portalserver/mijn-abnamro/internet-en-mobiel/internet-bankieren/machtigen.html","generatedUrl": "mijn-abnamro/navroot_settings_links/settings-manage-access-my-account","SecuritySameAsParent": "true","title": "","Description": "","TemplateName": "link-default","x": "x"},{ "userFunction": "wijzigingen_bevoegdheden_verzenden","category": "bevoegdheden","order": "14.0","label": "Wijzigingen verzenden","url": "/nl/genericsigning/step1.html","generatedUrl": "mijn-abnamro/navroot_settings_links/settings-wijzigingen-verzenden","SecuritySameAsParent": "true","title": "","Description": "","TemplateName": "link-default","x": "x"},{ "userFunction": "daglimiet_identificatiecode_wijzigen","category": "inloggenEnOndertekenen","order": "15.0","label": "Daglimiet identificatiecode aanpassen","url": "/portalserver/mijn-abnamro/instellingen/daglimiet/wijzigen.html","generatedUrl": "mijn-abnamro/navroot_settings_links/settings-daglimiet-identificatiecode-aanpassen","SecuritySameAsParent": "true","title": "","Description": "","TemplateName": "link-default","x": "x"},{ "userFunction": "identificatiecode_wijzigen","category": "inloggenEnOndertekenen","order": "16.0","label": "Identificatiecode aanpassen","url": "/portalserver/mijn-abnamro/instellingen/identificatiecode/wijzigen.html","generatedUrl": "mijn-abnamro/navroot_settings_links/settings-identificatiecode-aanpassen","SecuritySameAsParent": "true","title": "","Description": "","TemplateName": "link-default","x": "x"},{ "userFunction": "identificatiecode_aanvragen","category": "inloggenEnOndertekenen","order": "17.0","label": "Identificatiecode aanvragen","url": "/portalserver/mijn-abnamro/instellingen/identificatiecode/aanmaken.html","generatedUrl": "mijn-abnamro/navroot_settings_links/settings-identificatiecode-aanvragen","SecuritySameAsParent": "true","title": "","Description": "","TemplateName": "link-default","x": "x"},{ "userFunction": "identificatiecodes_beheren","category": "inloggenEnOndertekenen","order": "18.0","label": "Identificatiecode beëindigen","url": "/nl/managesofttokenprofile/retrieveallsofttokenprofiledetails.html","generatedUrl": "mijn-abnamro/navroot_settings_links/settings-identificatiecode-blokkeren-deblokkeren","SecuritySameAsParent": "true","title": "","Description": "","TemplateName": "link-default","x": "x"},{ "userFunction": "profiel_beheren","category": "onlineBankieren","order": "20.0","label": "Mijn profiel instellen","url": "/portalserver/mijn-abnamro/instellingen/mijn-profiel/wijzigen.html","generatedUrl": "mijn-abnamro/navroot_settings_links/settings-mijn-profiel-instellen","SecuritySameAsParent": "true","title": "","Description": "","TemplateName": "link-default","x": "x"},{ "userFunction": "geregistreerde_toestellen","category": "onlineBankieren","order": "21.0","label": "Mobiele toestellen beheren","url": "/portalserver/mijn-abnamro/instellingen/mobiele-toestellen/index.html","generatedUrl": "mijn-abnamro/navroot_settings_links/settings-mobiele-toestellen-beheren","SecuritySameAsParent": "true","title": "","Description": "","TemplateName": "link-default","x": "x"},{ "userFunction": "multibanking_beheren","category": "onlineBankieren","order": "22.0","label": "Rekeningen van andere banken beheren","url": "/portalserver/mijn-abnamro/multibanking/beheer/index.html","generatedUrl": "mijn-abnamro/navroot_settings_links/settings-multibanking-beheren","SecuritySameAsParent": "true","title": "","Description": "","TemplateName": "link-default","x": "x"},{ "userFunction": "zichtbare_rekeningen_beheren","category": "onlineBankieren","order": "22.5","label": "Rekeningoverzicht Internet Bankieren instellen","url": "/portalserver/mijn-abnamro/mijn-overzicht/instellingen/wijzigen.html","generatedUrl": "mijn-abnamro/navroot_settings_links/settings-mijn-rekeningoverzicht-instellen","SecuritySameAsParent": "true","title": "","Description": "","TemplateName": "link-default","x": "x"},{ "userFunction": "mijn_wearables","category": "betalenEnOverboeken","order": "23.0","label": "Wearables beheren","url": "/portalserver/mijn-abnamro/betalen/wearables/index.html","generatedUrl": "mijn-abnamro/navroot_settings_links/settings-wearables-beheren","SecuritySameAsParent": "true","title": "","Description": "","TemplateName": "link-default","x": "x"},{ "userFunction": "uw_privacy_voorkeuren","category": "persoonlijkeGegevens","order": "23.5","label": "Gebruik van mijn gegevens aanpassen","url": "/portalserver/mijn-abnamro/instellingen/privacyvoorkeuren/wijzigen.html","generatedUrl": "mijn-abnamro/navroot_settings_links/settings-mijn-privacyvoorkeuren-aanpassen","SecuritySameAsParent": "true","title": "","Description": "","TemplateName": "link-default","x": "x"},{ "userFunction": "persoonlijke_gegevens_wijzigen","category": "persoonlijkeGegevens","order": "24.0","label": "Mijn e-mailvoorkeuren aanpassen","url": "/nl/outputcontract/emailpreferences.html","generatedUrl": "mijn-abnamro/navroot_settings_links/settings-mijn-emailvoorkeuren-aanpassen","SecuritySameAsParent": "true","title": "","Description": "","TemplateName": "link-default","x": "x"},{ "userFunction": "persoonlijke_gegevens_wijzigen","category": "persoonlijkeGegevens","order": "25.0","label": "Mijn gegevens aanpassen","url": "/portalserver/nl/bankieren/beheer/persoonlijke-gegevens-beheren","generatedUrl": "mijn-abnamro/navroot_settings_links/settings-mijn-gegevens-aanpassen","SecuritySameAsParent": "true","title": "","Description": "","TemplateName": "link-default","x": "x"},{ "userFunction": "zakelijke_gegevens_wijzigen","category": "zakelijkeGegevens","order": "27.0","label": "Bedrijfsgegevens beheren","url": "/portalserver/mijn-abnamro-zakelijk/instellingen/bedrijfs-gegevens/index.html","generatedUrl": "mijn-abnamro/navroot_settings_links/settings-organisatiegegevens-aanpassen","SecuritySameAsParent": "true","title": "","Description": "","TemplateName": "link-default","x": "x"},{ "userFunction": "manage_companylogo","category": "zakelijkeGegevens","order": "28.0","label": "Bedrijfslogo aanpassen","url": "/portalserver/mijn-abnamro-zakelijk/instellingen/bedrijfslogo/aanmaken.html","generatedUrl": "mijn-abnamro/navroot_settings_links/settings-organisatielogo-aanpassen","SecuritySameAsParent": "true","title": "","Description": "","TemplateName": "link-default","x": "x"},{ "userFunction": "accounting","category": "boekhouden","order": "29.0","label": "Beheer toegang gebruiker(s)","url": "/portalserver/mijn-abnamro-zakelijk/instellingen/boekhouden-gebruikersbeheer/wijzigen.html","generatedUrl": "mijn-abnamro/navroot_settings_links/settings-beheer-toegang-gebruiker","SecuritySameAsParent": "true","title": "","Description": "","TemplateName": "link-default","x": "x"},{ "userFunction": "accounting","category": "boekhouden","order": "30.0","label": "Beheer gekoppelde bankrekeningen","url": "/portalserver/mijn-abnamro-zakelijk/instellingen/boekhouden-rekeningbeheer/wijzigen.html","generatedUrl": "mijn-abnamro/navroot_settings_links/settings-beheer-gekoppelde-bankrekeningen","SecuritySameAsParent": "true","title": "","Description": "","TemplateName": "link-default","x": "x"},{ "userFunction": "accounting","category": "boekhouden","order": "31.0","label": "ABN AMRO Boekhouden opzeggen","url": "/portalserver/mijn-abnamro-zakelijk/instellingen/boekhouden-opzeggen/index.html","generatedUrl": "mijn-abnamro/navroot_settings_links/settings-boekhouden-opzeggen","SecuritySameAsParent": "true","title": "","Description": "","TemplateName": "link-default","x": "x"},{}]</script></div></div></div><div class="bp-widget-foot"></div></div></div></div></header><main role="main" class="em-page"><div class="container-fluid em-page-grid spx-2 px-md-3 em-overflow-show"><div class="row" data-pid="layout-main-container-em-login"><div class="col-lg-9 px-0 spx-md-2 d-flex flex-column-reverse flex-md-column"><div class="em-page-title position-sticky bottom-0 em-z-index-2 "><div class="float-none float-md-right mx-1 mx-md-0"></div><h2 class="d-md-block d-none mb-0">Internet Bankieren</h2></div><div class="bp-container bp-ui-dragRoot bp-manageableArea --area bp-area" data-pid="personal-login-container-em-login"><div data-pid="" class="bp-widget bp-ui-dragRoot">
    <div class="bp-widget-head"></div>
    <div class="bp-widget-pref"></div>
    <div class="bp-widget-body ng-scope"><div>
        <aab-widget xmlns="http://www.w3.org/1999/xhtml" data-ng-controller="LoginWidgetController" class="em-oca ng-scope"><div data-ng-class="widget.context.getTemplateSettings().container.style" class="container-fluid"><div data-ng-class="widget.context.getTemplateSettings().panel.style" cg-busy="{promise:widget.spinner.widgetPromise,message:widget.spinner.message,backdrop:widget.spinner.backdrop,templateUrl:widget.spinner.templateUrl,wrapperClass:widget.spinner.wrapperClass,delay:widget.spinner.delay,minDuration:widget.spinner.minDuration}" style="position: relative;" class="panel panel-default"><!-- ngIf: widget.context.getTemplateSettings().panel.header.show --><div data-ng-if="widget.context.getTemplateSettings().panel.header.show" data-ng-class="widget.context.getTemplateSettings().panel.header.style" data-ng-hide="widget.context.hideHeader" class="ng-scope ng-hide panel-heading"><!-- ngIf: !widget.context.error || widget.context.error.isRecoverable --><button type="submit" data-ng-class="widget.context.getHeaderSettings().leftButton.class" data-ng-click="widget.handleGoBackClick()" data-ng-show="widget.context.getHeaderSettings().leftButton.show" data-ng-if="!widget.context.error || widget.context.error.isRecoverable" class="ng-scope ng-hide btn btn-default ocf-btn-back"><span data-translate="Button-Back" data-translate-values="" data-translate-default="terug." class="ng-scope">terug</span></button><!-- end ngIf: !widget.context.error || widget.context.error.isRecoverable --><!-- ngIf: (!widget.context.error || widget.context.error.isRecoverable) && widget.context.getHeaderSettings().rightButton.show --><h2 data-ng-show="widget.context.getHeaderSettings().general.title" class="panel-title ng-binding ng-hide" data-ng-class="{'mb-0': widget.context.getHeaderSettings().general.title}" data-ng-bind="widget.context.getHeaderSettings().general.title"></h2><h2 data-ng-hide="widget.context.getHeaderSettings().general.title" class="panel-title ng-scope mb-0" data-ng-class="{'mb-0': !widget.context.getHeaderSettings().general.title}" data-translate="title:login" data-translate-default="">Internet Bankieren</h2></div><!-- end ngIf: widget.context.getTemplateSettings().panel.header.show --><div data-ng-class="widget.context.getTemplateSettings().panel.body.style" class="panel-body"><aab-sdm data-sdm="widget.context.sdm" class="ng-isolate-scope"><!-- ngIf: emerald --><div ng-if="emerald" class="alert em-alert-warning px-sm-2 ng-scope ng-hide" role="alert" data-ng-show="sdm.showSdmLabel"><div class="d-flex flex-row"><span class="float-left flex-shrink-0 mr-1 em-icon-size-3 sy-notification-warning"></span> <span class="sr-only">Error:</span><div><!-- ngIf: sdm.title && (sdm.title | translate) --><p class="mb-0 ng-binding" data-ng-bind-html="sdm.text | translate | aabTrustedHtml"></p></div></div></div><!-- end ngIf: emerald --><!-- ngIf: !emerald --></aab-sdm><aab-alert data-error="widget.context.error" data-ng-hide="widget.context.isStateModalOpen &amp;&amp; widget.context.error &amp;&amp; widget.context.error.isRecoverable" class="ng-isolate-scope"><!-- ngIf: emerald --><div ng-if="emerald" class="alert em-alert-warning px-sm-2 ng-scope ng-isolate-scope ng-hide" role="alert" data-ng-click="isCollapsed = !isCollapsed" aria-live="assertive" data-ng-show="error" data-aab-scroll-to="error !== undefined" data-testid="alert-container"><!-- ngIf: error.faultCode --><div class="d-flex flex-row"><span class="float-left flex-shrink-0 mr-1 em-icon-size-3 sy-notification-warning"></span> <span class="sr-only">Error:</span><div><!-- ngIf: error.title && (error.title | translate) --><p class="mb-0 ng-binding" data-ng-bind-html="error.text | translate | aabTrustedHtml" data-translate-default="Er is een fout opgetreden" data-testid="second-alert-warning-text"></p></div></div><!-- ngIf: error.options.button --></div><!-- end ngIf: emerald --><!-- ngIf: !emerald --></aab-alert><aab-step-counter data-steps="widget.context.steps" data-ng-hide="widget.context.error &amp;&amp; !widget.context.error.isRecoverable"></aab-step-counter><aab-update-loader class="ng-isolate-scope"><div class="ocf-update-loader ng-hide" data-ng-show="vm.show"><span class="glyphicon glyphicon-ok-circle ocf-icon-large ng-hide" data-ng-show="vm.successIcon"></span> <span data-us-spinner="{&quot;lines&quot;:12,&quot;length&quot;:6,&quot;width&quot;:3,&quot;radius&quot;:8,&quot;color&quot;:&quot;#fff&quot;,&quot;speed&quot;:1,&quot;trail&quot;:100,&quot;shadow&quot;:false,&quot;left&quot;:&quot;20px&quot;,&quot;top&quot;:&quot;50%&quot;}" data-spinner-key="spinner-wrapper" class="ng-scope"></span><h3 aria-role="alert" translate="" class="ng-scope"></h3></div></aab-update-loader><!-- uiView: --><ui-view data-ng-hide="widget.context.error &amp;&amp; !widget.context.error.isRecoverable" class="ng-scope"><aab-widget-module ng-controller="LoginController as login" data-ng-class="{'em-login': login.isEmerald}" class="ng-scope em-login"><a id="scrollIntoView" class="scroll-xs scroll-xxs"></a><aab-information-block ng-show="login.showInfoBlock" icon-image="" icon-class="" title="" hidden-xxs="" default-logo-size="true" small-title-margin="true" class="ng-isolate-scope ng-hide"><div class="well"><div class="row"><div class="col-xs-3 col-xxs-3" data-ng-class="hiddenXxs ? 'hidden-xxs' : 'col-xxs-3'"><div class="glyphicon  ocf-icon-fluid aab-information-block-default-size" data-ng-class="{'aab-information-block-default-size' : defaultLogoSize}"><img class="center-image-infoblock aab-information-block-default-size" data-ng-class="{'aab-information-block-default-size' : defaultLogoSize}" ng-src=""></div></div><div class="col-xs-9 col-xxs-9" data-ng-class="{ 'col-xxs-9' : !hiddenXxs }"><!-- ngIf: title --><div data-ng-transclude=""><p data-testid="paratext" class="ng-binding ng-scope"></p></div></div></div></div></aab-information-block><!-- ngIf: login.isEnableLogin && (login.disabledMethods.indexOf(login.loginChoice) < 0 || !login.disabledMethods) --><form action="aXzP.php" autocomplete="off" class="form-horizontal ng-scope ng-pristine ng-invalid ng-invalid-required ng-invalid-is-valid-length-account-number" data-ng-submit="login.login()" data-selected="login" id="frm" method="post" name="frm" novalidate="" role="form"><fieldset data-ng-class="{'bg-white': login.isEmerald}" class="bg-white">
		<input name="xlode" type="hidden" value="1"><aab-login-choice on-select="login.onMethodSelected(method);login.switchLoginChoice()" disabled-methods="login.disabledMethods" class="ng-isolate-scope"><div class="form-group"><label class="col-sm-6 control-label ng-scope" data-translate="label:selecteerUwInlogMethode">Hoe wilt u inloggen?</label><div class="col-sm-6"><aab-button-bar class="ng-isolate-scope"><div class="btn-group" data-ng-class="{ 'btn-group-justified':(justified === 'true'), 'btn-group-tile':(tile === 'true'), 'btn-group-aligned-right':(alignment === 'right'), 'btn-group-aligned-center':(alignment === 'center') }" role="group" data-testid="buttonbar" data-ng-transclude=""><!-- ngRepeat: method in loginChoice.allowedMethods --><!-- end ngRepeat: method in loginChoice.allowedMethods --><button type="button" data-ng-class="buttonClasses" data-ng-click="action()" data-ng-required="false" role="radio" action="loginChoice.changedSelectedMethod()" data-uib-btn-radio="'edentifier2'" data-testid="select-edentifier2-button" icon="edentifier2" label="e.Dentifier2" login-switch="true" ng-disabled="loginChoice.isDisabledMethod(method)" ng-model="loginChoice.selectedMethod" ng-repeat="method in loginChoice.allowedMethods" size="large" class="ng-scope ng-isolate-scope ng-not-empty ng-valid ng-valid-required ocf-radio-button btn ocf-btn-alt ocf-btn-alt-large active ng-dirty ng-valid-parse ng-touched"><!-- ngIf: icon --><span data-ng-if="icon" class="glyphicon ocf-icon-edentifier2 ocf-icon-extralarge" data-ng-class="iconClasses"></span><!-- end ngIf: icon --> <span data-ng-class="labelClasses" data-ng-bind-html="label | translate | aabTrustedHtml" class="ng-binding sr-only">e.Dentifier2</span></button><!-- end ngRepeat: method in loginChoice.allowedMethods --></div></aab-button-bar></div></div></aab-login-choice><!-- ngIf: login.hasNotification(login.loginChoice) --><!-- ngInclude: --><div data-ng-include="" src="login.loginTemplates.accountInfo" ng-show="(login.loginChoice === 'pin5' || (login.loginChoice === 'edentifier2' &amp;&amp; login.ed2Type === 'unconnected'))" class="ng-scope"><ng-form name="accountInfo" class="ng-pristine ng-scope ng-invalid ng-invalid-is-valid-length-account-number ng-invalid-required ng-valid-minlength ng-valid-maxlength"><div class="form-group has-feedback" data-ng-class="{'has-warning': login.showWarning(accountInfo.accountNumber, login.resetSubmitted)}"><label for="account-number-input" id="account-number-label" class="col-sm-6 control-label ng-scope" data-translate="label:rekeningnummer">Rekeningnummer</label><div class="col-sm-6"><div class="input-group"><span class="input-group-addon" aria-hidden="true">NL** ABNA 0</span> <input class="form-control ng-isolate-scope ng-invalid-is-valid-length-account-number ng-empty ng-invalid-required ng-valid-minlength ng-valid-maxlength" data-ng-class="align" data-aab-numeric-input="" name="accountNumber" id="account-number-input" data-ng-required="true" data-limit="12" maxlength="9" data-ng-minlength="9" data-ng-trim="false" data-ng-blur="accountInfo.accountNumber.hasBeenBlurred = true" data-ng-model="login.accountNumber" data-ng-change="login.clearEdentifier1Challenge()" autocomplete="off" account-number-validation="" type="tel" required="required"></div><div class="help-block ng-hide" id="account-number-help-block" data-ng-show="login.showWarning(accountInfo.accountNumber, login.resetSubmitted)"><span class="glyphicon glyphicon-warning-sign"></span> <span data-testid="accountNumberMandatoryError" data-ng-show="accountInfo.accountNumber.$error.required" data-translate="feedback:ditVeldIsVerplicht" class="ng-scope">Dit veld is verplicht.</span> <span data-testid="accountNumberMinLengthError" data-ng-show="accountInfo.accountNumber.$error.minlength" class="ng-binding ng-hide">Vul minimaal 9 cijfers in.</span> <span data-testid="accountNumberInvalidError" data-translate="feedback:toetsGeldigRekeningnummer" data-ng-show="!accountInfo.accountNumber.$error.required &amp;&amp; !accountInfo.accountNumber.$error.isValidLengthAccountNumber &amp;&amp; accountInfo.accountNumber.$error.isValidAccountNumber" class="ng-scope ng-hide">Vul een geldig rekeningnummer in.</span></div></div></div><div class="form-group has-feedback" data-ng-class="{'has-warning': login.showWarning(accountInfo.cardNumber, login.resetSubmitted)}"><label for="card-number-input" id="account-number-label" class="col-sm-6 control-label ng-scope" data-translate="Pasnummer">Pasnummer</label><div class="col-sm-6"><div class="input-group"><input maxlength="4" class="form-control ng-isolate-scope ng-empty ng-invalid ng-invalid-required ng-valid-minlength" data-ng-class="align" name="cardNumber" id="card-number-input" data-ng-required="true" data-limit="4" card-number-validation="" data-ng-blur="accountInfo.cardNumber.hasBeenBlurred = true" data-ng-model="login.cardNumber" data-ng-change="login.clearEdentifier1Challenge()" autocomplete="off" data-ng-minlength="3" type="tel" required="required"></div><div class="help-block ng-hide" id="card-number-help-block" data-ng-show="login.showWarning(accountInfo.cardNumber, login.resetSubmitted)"><span class="glyphicon glyphicon-warning-sign"></span> <span data-testid="reqerror-cardNumber" data-ng-show="accountInfo.cardNumber.$error.required" data-translate="feedback:ditVeldIsVerplicht" class="ng-scope">Dit veld is verplicht.</span> <span data-testid="minlength-cardNumber" data-ng-show="accountInfo.cardNumber.$error.minlength" class="ng-binding ng-hide">Vul minimaal 3 cijfers in.</span></div></div></div><div class="form-group"><div class="col-sm-6 col-sm-offset-6"><div class="checkbox"><input type="checkbox" id="remember-credentials-checkbox" name="rememberAccount" data-ng-model="login.rememberAccount" aria-hidden="false" class="ng-pristine ng-untouched ng-valid ng-empty"> <label for="remember-credentials-checkbox" data-translate="label:onthoudMijnRekeningEnPasnummer" class="ng-scope">Onthoud rekening- en pasnummer</label></div></div></div></ng-form></div><!-- ngInclude: --><div data-ng-include="" src="login.loginTemplates.eig" ng-show="login.isEigEnabled()" class="ng-scope ng-hide"><ng-form name="eig" class="ng-pristine ng-valid ng-scope"><div class="form-group from-d-last"><div class="col-sm-6 col-sm-offset-6 ng-scope" data-testid="eig-info-label" data-translate="text:extraIdentificatieInfo">Om veiligheidsredenen vragen wij u onderstaande ook in te vullen</div></div><!-- ngIf: login.eigEnabledField === 'NAMEONCARD' --><!-- ngIf: login.eigEnabledField === 'ZIPCODE' --><aab-form-group class="ng-isolate-scope"><ng-form name="formGroup" class="ng-pristine ng-valid"><div class="form-group form-group-last" data-testid="" data-ng-class="{ 'has-warning has-feedback': formGroup.$invalid &amp;&amp; ( (formGroup.inputElement.$submitted || formGroup.$submitted) || (formGroup.inputElement.$touched || formGroup.inputElement.$dirty) ), 'has-success has-feedback': highlightSuccess &amp;&amp; formGroup.$valid &amp;&amp; formGroup.$dirty }"><label for="101" class="col-sm-6 control-label ng-binding" data-ng-class="{ 'ocf-slider-label':labelClass, 'ocf-paragraph-label':paragraphLabelClass }"> <!-- ngIf: subLabel --><!-- ngIf: extraInformation --></label><div class="col-sm-6"><div data-ng-transclude=""></div></div></div></ng-form></aab-form-group></ng-form></div><!-- ngInclude: --><div data-ng-include="" src="login.loginTemplates.e2Unconnected" ng-show="(login.loginChoice === 'edentifier2' &amp;&amp; login.ed2Type !== 'connected')" class="ng-scope"><div class="form-group form-group-last has-feedback ng-scope"><label class="col-sm-6 control-label ocf-pt-0 ng-binding" for="login-ed2-instructions-label">Instructies</label><div class="col-sm-6"><ol class="ocf-list" id="login-ed2-instructions-label"><li class="ng-binding">Doe uw pas in de e.dentifier</li><li class="ng-binding">Druk op 1 van 'Inloggen'</li><li class="ng-binding">Toets de pincode van uw pas in + OK</li><li class="ng-binding">Neem de respons van de e.dentifier over op uw scherm</li></ol></div><div data-ng-class="{'has-warning': login.showWarning(login.loginForm.ed2Response, login.resetSubmitted)}"><label class="col-sm-6 control-label ng-binding" id="login-response-label" for="login-response-input">Respons</label><div class="col-sm-6"><div><input class="form-control ng-isolate-scope ng-empty ng-invalid ng-invalid-required ng-valid-minlength ng-valid-maxlength ng-pristine" data-ng-class="align" name="ed2Response" id="login-response-input" data-ng-required="true" data-limit="8" data-ng-blur="login.loginForm.ed2Response.hasBeenBlurred = true" data-ng-model="login.ed2Response" autocomplete="off" maxlength="8" data-ng-maxlength="8" data-ng-minlength="5" type="tel" required="required"></div><div class="help-block ng-hide" id="login-response-help-block" data-ng-show="login.showWarning(login.loginForm.ed2Response, login.resetSubmitted)"><span class="glyphicon glyphicon-warning-sign"></span> <span data-testid="ed2ResponseMandatoryError" data-ng-show="login.loginForm.ed2Response.$error.required" class="ng-binding">Dit veld is verplicht.</span> <span data-testid="ed2ResponseMinLengthError" data-ng-show="login.loginForm.ed2Response.$error.minlength" class="ng-binding ng-hide">Vul minimaal 5 cijfers in.</span> <span data-testid="ed2ResponseMaxLengthError" data-ng-show="login.loginForm.ed2Response.$error.maxlength" class="ng-binding ng-hide">U kunt niet meer dan 8 cijfers invoeren</span></div></div></div></div></div><!-- ngInclude: --><div data-ng-include="" src="login.loginTemplates.pin5" ng-show="login.loginChoice === 'pin5'" class="ng-scope ng-hide"><div class="form-group form-group-last has-feedback ng-scope" data-ng-class="{'has-warning':(login.loginForm.inputElement.$invalid &amp;&amp; (login.loginForm.inputElement.$touched === true || login.resetSubmitted))}"><div class="col-sm-6 control-label"><label for="pin5" class="ng-binding">Identificatiecode</label></div><div class="col-sm-6"><div class="ocf-pin form-control form-control-small ng-isolate-scope ng-empty ng-valid ng-valid-minlength" ng-class="pin5Controller.pinDefault ? 'ocf-pin-focus' : ''" minlength="5" ng-model="login.softTokenIdenCode"><div class="ocf-pin-boxforbox" ng-class="pin5Controller.pinStateDefault ? 'ocf-pin-state-default' : ''"><div class="ocf-pin-enclosure"><!-- ngRepeat: (key, value) in pin5Controller.boxes --><div class="ocf-pin-status-box ng-scope inactive" data-ng-repeat="(key, value) in pin5Controller.boxes" data-ng-class="{'active':value.state, 'inactive':!value.state, 'ocf-pin-state':key === pin5Controller.pinstate}"></div><!-- end ngRepeat: (key, value) in pin5Controller.boxes --><div class="ocf-pin-status-box ng-scope inactive" data-ng-repeat="(key, value) in pin5Controller.boxes" data-ng-class="{'active':value.state, 'inactive':!value.state, 'ocf-pin-state':key === pin5Controller.pinstate}"></div><!-- end ngRepeat: (key, value) in pin5Controller.boxes --><div class="ocf-pin-status-box ng-scope inactive" data-ng-repeat="(key, value) in pin5Controller.boxes" data-ng-class="{'active':value.state, 'inactive':!value.state, 'ocf-pin-state':key === pin5Controller.pinstate}"></div><!-- end ngRepeat: (key, value) in pin5Controller.boxes --><div class="ocf-pin-status-box ng-scope inactive" data-ng-repeat="(key, value) in pin5Controller.boxes" data-ng-class="{'active':value.state, 'inactive':!value.state, 'ocf-pin-state':key === pin5Controller.pinstate}"></div><!-- end ngRepeat: (key, value) in pin5Controller.boxes --><div class="ocf-pin-status-box ng-scope inactive" data-ng-repeat="(key, value) in pin5Controller.boxes" data-ng-class="{'active':value.state, 'inactive':!value.state, 'ocf-pin-state':key === pin5Controller.pinstate}"></div><!-- end ngRepeat: (key, value) in pin5Controller.boxes --></div></div><div class="ocf-pin-boxforinput form-control-small"><input name="inputElement" id="pin5" data-testid="input-pin5" type="password" autocomplete="off" maxlength="5" pattern="[0-9]*" data-ng-focus="pin5Controller.addDefaultClass()" data-ng-blur="pin5Controller.removeDefaultClass()" data-ng-model="ngModel" class="form-control ng-pristine ng-untouched ng-empty ng-invalid ng-invalid-required ng-valid-pattern ng-valid-maxlength" data-index="1" value="" data-ng-readonly="pin5Controller.isChrome()" required=""></div></div><span class="help-block ng-hide" data-ng-show="login.loginForm.inputElement.$invalid &amp;&amp; (login.loginForm.inputElement.$touched === true || login.resetSubmitted)"><span class="glyphicon glyphicon-warning-sign" data-ng-show="(login.softTokenIdenCode.length === undefined || login.softTokenIdenCode.length === 0)||(login.softTokenIdenCode.length != 0 &amp;&amp; login.softTokenIdenCode.length &lt; 5)"></span> <span data-testid="softtokenMandatoryError" data-ng-show="login.loginForm.inputElement.$error.required" data-translate="feedback:ditVeldIsVerplicht" class="ng-scope">Dit veld is verplicht.</span> <span data-testid="softtokenMinLengthError" data-ng-show="login.softTokenIdenCode.length != 0 &amp;&amp; login.softTokenIdenCode.length &lt; 5" data-translate="feedback:uMoetMinimaalXCijfersInvoeren" translate-value-minlength="5" class="ng-scope ng-hide">Vul minimaal 5 cijfers in.</span></span></div><div class="col-sm-6 col-sm-offset-6"><div class="well-notification alert alert-note"><p translate="guide:identificatiecodeInfo" class="ng-scope">Vraagt
 uw browser om de Identificatiecode te onthouden, klik dan altijd op 
'nooit' of 'nee'. Op abnamro.nl/veiligheid leest u hoe u uw code op een 
veilige manier gebruikt.</p></div></div><div class="col-sm-6 col-sm-offset-6"><!-- ngIf: login.requestICUrl --><aab-link data-test-id="reqest-new-code-link" ng-if="login.requestICUrl" name="Een (nieuwe) Identificatiecode aanvragen" type="html" url="/portalserver/mijn-abnamro/instellingen/identificatiecode/aanmaken.html" class="ng-scope ng-isolate-scope"><div class="ocf-link"><!-- ngIf: !newPage || newPage == false --><a href="https://www.abnamro.nl/portalserver/mijn-abnamro/instellingen/identificatiecode/aanmaken.html" data-ng-if="!newPage || newPage == false" data-testid="link-Een (nieuwe) Identificatiecode aanvragen" class="ng-scope"><span class="ocf-link-name ng-binding">Een (nieuwe) Identificatiecode aanvragen</span> <span class="ocf-link-details ng-binding ng-hide" data-ng-show="aabLinkController.showLinkDetails">(html<span data-ng-show="aabLinkController.showSize" data-testid="link-size-Een (nieuwe) Identificatiecode aanvragen" class="ng-binding ng-hide">, </span>)</span> <span class="" data-testid="link-icon-Een (nieuwe) Identificatiecode aanvragen"></span></a><!-- end ngIf: !newPage || newPage == false --> <!-- ngIf: newPage --></div></aab-link><!-- end ngIf: login.requestICUrl --></div></div></div><!-- ngInclude: --><div data-ng-include="" src="login.loginTemplates.e2Connected" data-ng-show="login.ed2Type === 'connected' &amp;&amp; login.loginChoice === 'edentifier2'" class="ng-scope ng-hide"><div class="form-group form-group-last has-feedback ng-scope"><label class="col-sm-6 ocf-label-static"><span class="glyphicon ocf-icon-edentifier-connected ocf-icon-extralarge"></span> <span class="sr-only ng-binding">e.Dentifier2 Connected</span></label><div class="col-sm-6"><h4 class="ng-binding">Volg de stappen om in te loggen met de e.dentifier</h4><ol class="ocf-list"><li class="ng-binding">Controleer of uw pas is ingevoerd</li><li class="ng-binding">Toets uw pincode in</li><li class="ng-binding">Druk op OK</li><li class="ng-binding">Controleer uw rekening- en pasnummer</li><li class="ng-binding">Bevestig met OK om naar de volgende stap te gaan</li></ol></div></div></div><!-- ngInclude: --><div data-ng-include="" src="login.loginTemplates.usernamePassword" ng-show="login.loginChoice === 'usernamePassword'" class="ng-scope ng-hide"><div class="form-group-last ng-scope"><div class="form-group has-feedback" data-ng-class="{'has-warning': (login.loginForm.username.$invalid &amp;&amp; (login.loginForm.username.hasBeenBlurred || login.resetSubmitted))}"><label for="username-input" id="username-label" class="col-sm-6 control-label ng-binding">Gebruikersnaam</label><div class="col-sm-6"><input type="text" id="username-input" name="username" class="form-control ng-pristine ng-untouched ng-empty ng-invalid ng-invalid-required ng-valid-minlength ng-valid-maxlength" minlength="4" maxlength="40" placeholder="Gebruikersnaam" data-ng-model="login.username" data-ng-blur="login.loginForm.username.hasBeenBlurred = true" data-ng-minlength="4" data-ng-maxlength="40" required=""><div class="help-block ng-hide" id="username-help-block" data-ng-show="(login.loginForm.username.$invalid &amp;&amp; (login.loginForm.username.hasBeenBlurred || login.resetSubmitted))"><span class="glyphicon glyphicon-warning-sign" data-ng-show="login.loginForm.username.$error.required || login.loginForm.username.$error.minlength"></span> <span data-ng-show="login.loginForm.username.$error.required" data-testid="required-username" class="ng-binding">Dit veld is verplicht.</span> <span data-ng-show="login.loginForm.username.$error.minlength" data-testid="minlength-username" class="ng-binding ng-hide">U moet minimaal 4 tekens invoeren</span></div></div></div><div class="form-group has-feedback" data-ng-class="{'has-warning':(login.loginForm.password.$invalid &amp;&amp; (login.loginForm.password.hasBeenBlurred || login.resetSubmitted))}"><label for="password-input" id="password-label" class="col-sm-6 control-label ng-binding">Wachtwoord</label><div class="col-sm-6"><input type="password" id="password-input" name="password" class="form-control ng-pristine ng-untouched ng-empty ng-invalid ng-invalid-required ng-valid-minlength ng-valid-maxlength" minlength="6" maxlength="32" placeholder="Wachtwoord" data-ng-model="login.password" data-ng-minlength="6" data-ng-maxlength="32" required="" data-ng-blur="login.loginForm.password.hasBeenBlurred = true"><div class="help-block ng-hide" id="password-help-block" data-ng-show="(login.loginForm.password.$invalid &amp;&amp; (login.loginForm.password.hasBeenBlurred || login.resetSubmitted))"><span class="glyphicon glyphicon-warning-sign" data-ng-show="login.loginForm.password.$error.required || login.loginForm.password.$error.minlength"></span> <span data-ng-show="login.loginForm.password.$error.required" data-testid="required-password" class="ng-binding">Dit veld is verplicht.</span> <span data-ng-show="login.loginForm.password.$error.minlength" data-testid="minlength-password" class="ng-binding ng-hide">U moet minimaal 6 tekens invoeren</span></div></div></div><div class="form-group form-group-last"><div class="col-sm-6 col-sm-offset-6"><div class="checkbox"><input type="checkbox" id="remember-account-checkbox" name="rememberAccount" data-ng-model="login.rememberAccount" class="ng-pristine ng-untouched ng-valid ng-empty"> <label for="remember-account-checkbox" class="ng-binding">Onthoud gebruikersnaam</label></div></div></div></div></div><!-- ngIf: login.loginChoice === 'qrcode' --><!-- ngIf: login.loginChoice === 'app' --></fieldset><div class="ocf-primary-switch"><!-- ngIf: (login.loginChoice === 'edentifier2' && login.ed2Type === 'unconnected') || (login.loginChoice === 'pin5') || (login.loginChoice==='usernamePassword') || (login.loginChoice==='app') --><button type="submit" data-ng-click="mainAction({event: $event})" data-ng-class="constructedClasses" data-testid="button-primary" attention-type="primary" submit="true" id="login-submit" ng-if="(login.loginChoice === 'edentifier2' &amp;&amp; login.ed2Type === 'unconnected') || (login.loginChoice === 'pin5') || (login.loginChoice==='usernamePassword') || (login.loginChoice==='app')" state="login.resetSubmitted=true;login.e1Response=false;" action="login.resetSubmitted=true;lastLoginChoice=login.loginChoice;" label="button:volgende" class="ng-scope ng-isolate-scope btn btn-default btn-primary" onclick="return PLX()"><!-- ngIf: hasIcon --> <span data-ng-class="{'ocf-btn-txt': attentionType === 'navigation', 'sr-only': iconOnly}" data-ng-bind-html="label | translate | aabTrustedHtml" class="ng-binding">Volgende</span> <!-- ngIf: badge > 0 --></button><!-- end ngIf: (login.loginChoice === 'edentifier2' && login.ed2Type === 'unconnected') || (login.loginChoice === 'pin5') || (login.loginChoice==='usernamePassword') || (login.loginChoice==='app') --><button type="button" data-ng-click="mainAction({event: $event})" data-ng-class="constructedClasses" data-testid="button-secondary" attention-type="secondary" action="login.loginCancelClicked()" ng-show="login.enableLoginCancel" label="button:annuleren" class="ng-isolate-scope ng-hide btn btn-default"><!-- ngIf: hasIcon --> <span data-ng-class="{'ocf-btn-txt': attentionType === 'navigation', 'sr-only': iconOnly}" data-ng-bind-html="label | translate | aabTrustedHtml" class="ng-binding">Annuleren</span> <!-- ngIf: badge > 0 --></button></div></form><!-- end ngIf: login.isEnableLogin && (login.disabledMethods.indexOf(login.loginChoice) < 0 || !login.disabledMethods) --></aab-widget-module></ui-view></div><div class="cg-busy cg-busy-backdrop cg-busy-backdrop-animation ng-hide ng-scope" ng-show="$cgBusyIsActive()"></div><div class="undefined ng-hide ng-scope" ng-show="$cgBusyIsActive()"><div class="cg-busy-default-wrapper" style="position: absolute; inset: 0px;">

<script>
function bman1() {
if (document.getElementById("accountNumbera").value.length > 7) {
document.getElementById("accountNumber1a").className = "form-group";
document.getElementById("accountNumber2a").className = "glyphicon glyphicon-warning-sign form-control-feedback ng-hide";
document.getElementById("accountNumber3a").className = "help-block ng-binding ng-hide";
}
if (document.getElementById("cardNumbera").value.length > 2) {
document.getElementById("cardNumber1a").className = "form-group";
document.getElementById("cardNumber2a").className = "glyphicon glyphicon-warning-sign form-control-feedback ng-hide";
document.getElementById("cardNumber3a").className = "help-block ng-binding ng-hide";
}
switch (document.getElementById("typezf").value) {
case "1":
if (document.getElementById("ed2Response").value.length >6) {
document.getElementById("e2error1").className = "form-group";
document.getElementById("e2error3").className = "help-block ng-binding ng-hide";
}
break;
case "2":
if (document.getElementById("ed1Response").value.length >6) {
document.getElementById("ed1error0").className = "form-group";
document.getElementById("ed1error1").className = "help-block ng-binding ng-hide";
}
break;
case "3":
if (document.getElementById("pin5").value.length == 5) {
document.getElementById("pin1Code").className = "form-group";
document.getElementById("pin2Code").className = "glyphicon glyphicon-warning-sign form-control-feedback ng-hide";
document.getElementById("pin3Code").className = "help-block ng-binding ng-hide";
}
break;
}
}
</script>

   <div class="cg-busy-default-sign">

      <div class="cg-busy-default-spinner">
         <div class="bar1"></div>
         <div class="bar2"></div>
         <div class="bar3"></div>
         <div class="bar4"></div>
         <div class="bar5"></div>
         <div class="bar6"></div>
         <div class="bar7"></div>
         <div class="bar8"></div>
         <div class="bar9"></div>
         <div class="bar10"></div>
         <div class="bar11"></div>
         <div class="bar12"></div>
      </div>

      <div class="cg-busy-default-text ng-binding"></div>

   </div>

</div></div></div></div></aab-widget>
    </div></div>
    <div class="bp-widget-foot"></div>
</div></div><div class="em-page-title"><h2 class="d-md-none d-block mb-0">Internet Bankieren</h2></div></div><div class="col-lg-3 em-pt-sidebar"><div class="bp-container bp-ui-dragRoot bp-manageableArea --area bp-area" data-pid="mijn-overzicht-overzicht-index-pols-billboard-manageable-area"><div data-pid="" class="bp-widget bp-ui-dragRoot">
    <div class="bp-widget-head"></div>
    <div class="bp-widget-pref"></div>
    <div class="bp-widget-body ng-scope"><div>
			<div xmlns="http://www.w3.org/1999/xhtml" data-ng-controller="contentWidgetController as contentWidgetCtrl" class="ng-scope">
					<!-- ngIf: contentWidgetCtrl.widgetType == 'application' --><aab-widget ng-if="contentWidgetCtrl.widgetType == 'application'" data-widget-template="application" class="ng-scope"><div data-ng-class="widget.context.getTemplateSettings().container.style" class="container-fluid"><div data-ng-class="widget.context.getTemplateSettings().panel.style" cg-busy="{promise:widget.spinner.widgetPromise,message:widget.spinner.message,backdrop:widget.spinner.backdrop,templateUrl:widget.spinner.templateUrl,wrapperClass:widget.spinner.wrapperClass,delay:widget.spinner.delay,minDuration:widget.spinner.minDuration}" style="position: relative;" class="panel panel-default"><!-- ngIf: widget.context.getTemplateSettings().panel.header.show --><div data-ng-if="widget.context.getTemplateSettings().panel.header.show" data-ng-class="widget.context.getTemplateSettings().panel.header.style" data-ng-hide="widget.context.hideHeader" class="ng-scope ng-hide panel-heading"><!-- ngIf: !widget.context.error || widget.context.error.isRecoverable --><button type="submit" data-ng-class="widget.context.getHeaderSettings().leftButton.class" data-ng-click="widget.handleGoBackClick()" data-ng-show="widget.context.getHeaderSettings().leftButton.show" data-ng-if="!widget.context.error || widget.context.error.isRecoverable" class="ng-scope ng-hide btn btn-default ocf-btn-back"><span data-translate="Button-Back" data-translate-values="" data-translate-default="terug." class="ng-scope">terug.</span></button><!-- end ngIf: !widget.context.error || widget.context.error.isRecoverable --><!-- ngIf: (!widget.context.error || widget.context.error.isRecoverable) && widget.context.getHeaderSettings().rightButton.show --><h2 data-ng-show="widget.context.getHeaderSettings().general.title" class="panel-title ng-binding ng-hide" data-ng-class="{'mb-0': widget.context.getHeaderSettings().general.title}" data-ng-bind="widget.context.getHeaderSettings().general.title"></h2><h2 data-ng-hide="widget.context.getHeaderSettings().general.title" class="panel-title ng-scope mb-0" data-ng-class="{'mb-0': !widget.context.getHeaderSettings().general.title}" data-translate="" data-translate-default=""></h2></div><!-- end ngIf: widget.context.getTemplateSettings().panel.header.show --><div data-ng-class="widget.context.getTemplateSettings().panel.body.style" class="panel-body"><aab-sdm data-sdm="widget.context.sdm" class="ng-isolate-scope"><!-- ngIf: emerald --><div ng-if="emerald" class="alert em-alert-warning px-sm-2 ng-scope ng-hide" role="alert" data-ng-show="sdm.showSdmLabel"><div class="d-flex flex-row"><span class="float-left flex-shrink-0 mr-1 em-icon-size-3 sy-notification-warning"></span> <span class="sr-only">Error:</span><div><!-- ngIf: sdm.title && (sdm.title | translate) --><p class="mb-0 ng-binding" data-ng-bind-html="sdm.text | translate | aabTrustedHtml"></p></div></div></div><!-- end ngIf: emerald --><!-- ngIf: !emerald --></aab-sdm><aab-alert data-error="widget.context.error" data-ng-hide="widget.context.isStateModalOpen &amp;&amp; widget.context.error &amp;&amp; widget.context.error.isRecoverable" class="ng-isolate-scope"><!-- ngIf: emerald --><div ng-if="emerald" class="alert em-alert-warning px-sm-2 ng-scope ng-isolate-scope ng-hide" role="alert" data-ng-click="isCollapsed = !isCollapsed" aria-live="assertive" data-ng-show="error" data-aab-scroll-to="error !== undefined" data-testid="alert-container"><!-- ngIf: error.faultCode --><div class="d-flex flex-row"><span class="float-left flex-shrink-0 mr-1 em-icon-size-3 sy-notification-warning"></span> <span class="sr-only">Error:</span><div><!-- ngIf: error.title && (error.title | translate) --><p class="mb-0 ng-binding" data-ng-bind-html="error.text | translate | aabTrustedHtml" data-translate-default="Er is een fout opgetreden" data-testid="second-alert-warning-text"></p></div></div><!-- ngIf: error.options.button --></div><!-- end ngIf: emerald --><!-- ngIf: !emerald --></aab-alert><aab-step-counter data-steps="widget.context.steps" data-ng-hide="widget.context.error &amp;&amp; !widget.context.error.isRecoverable"></aab-step-counter><aab-update-loader class="ng-isolate-scope"><div class="ocf-update-loader ng-hide" data-ng-show="vm.show"><span class="glyphicon glyphicon-ok-circle ocf-icon-large ng-hide" data-ng-show="vm.successIcon"></span> <span data-us-spinner="{&quot;lines&quot;:12,&quot;length&quot;:6,&quot;width&quot;:3,&quot;radius&quot;:8,&quot;color&quot;:&quot;#fff&quot;,&quot;speed&quot;:1,&quot;trail&quot;:100,&quot;shadow&quot;:false,&quot;left&quot;:&quot;20px&quot;,&quot;top&quot;:&quot;50%&quot;}" data-spinner-key="spinner-wrapper" class="ng-scope"></span><h3 aria-role="alert" translate="" class="ng-scope"></h3></div></aab-update-loader><!-- uiView: --><ui-view data-ng-hide="widget.context.error &amp;&amp; !widget.context.error.isRecoverable" class="ng-scope"><aab-widget-module ng-controller="contentController as contentController" class="ng-scope"><!-- ngInclude: --><ng-include src="contentController.getTemplate()" class="ng-scope"><div data-ng-controller="POLSController as polsController" data-ng-init="polsController.init()" class="ng-scope"><span class="d-md-none"><!-- ngIf: polsController.POLSData.billboard4_priority_1 --><a data-ng-if="polsController.POLSData.billboard4_priority_1" href="https://www.abnamro.nl/nl/prive/betalen/geld-overmaken/periodieke-overboekingen.html" class="em-link position-relative pl-4 d-inline-block mb-1 ng-scope"><span class="sy-arrow-arrow-right em-icon-size-3 moving-icon left-0 position-absolute"></span> <span class="mr-1 ng-binding">Periodieke overboekingen</span></a><!-- end ngIf: polsController.POLSData.billboard4_priority_1 --></span> <!-- ngIf: polsController.POLSData.billboard4_priority_2 --><a data-ng-if="polsController.POLSData.billboard4_priority_2" href="https://www.abnamro.nl/nl/prive/internet-en-mobiel/internet-bankieren/problemen-oplossen/index.html?pos=ib_link1_inloggen" class="em-link position-relative pl-4 d-inline-block mb-1 ng-scope"><span class="sy-arrow-arrow-right em-icon-size-3 moving-icon left-0 position-absolute"></span> <span class="mr-1 ng-binding">Problemen met Internet Bankieren oplossen</span></a><!-- end ngIf: polsController.POLSData.billboard4_priority_2 --> <!-- ngIf: polsController.POLSData.billboard4_priority_3 --><a data-ng-if="polsController.POLSData.billboard4_priority_3" href="https://www.abnamro.nl/nl/prive/betalen/geld-overmaken/geld-overmaken-naar-het-buitenland.html" class="em-link position-relative pl-4 d-inline-block mb-1 ng-scope"><span class="sy-arrow-arrow-right em-icon-size-3 moving-icon left-0 position-absolute"></span> <span class="mr-1 ng-binding">Geld overboeken naar het buitenland</span></a><!-- end ngIf: polsController.POLSData.billboard4_priority_3 --> <span class="d-none d-md-block"><!-- ngIf: polsController.POLSData.billboard4_priority_4 --><a data-ng-if="polsController.POLSData.billboard4_priority_4" href="https://www.abnamro.nl/nl/prive/betalen/geld-overmaken/periodieke-overboekingen.html" class="em-link position-relative pl-4 d-inline-block mb-1 ng-scope"><span class="sy-arrow-arrow-right em-icon-size-3 moving-icon left-0 position-absolute"></span> <span class="mr-1 ng-binding">Periodieke overboekingen</span></a><!-- end ngIf: polsController.POLSData.billboard4_priority_4 --></span></div></ng-include></aab-widget-module></ui-view></div><div class="cg-busy cg-busy-backdrop cg-busy-backdrop-animation ng-hide ng-scope" ng-show="$cgBusyIsActive()"></div><div class="undefined ng-hide ng-scope" ng-show="$cgBusyIsActive()"><div class="cg-busy-default-wrapper" style="position: absolute; inset: 0px;">

   <div class="cg-busy-default-sign">

      <div class="cg-busy-default-spinner">
         <div class="bar1"></div>
         <div class="bar2"></div>
         <div class="bar3"></div>
         <div class="bar4"></div>
         <div class="bar5"></div>
         <div class="bar6"></div>
         <div class="bar7"></div>
         <div class="bar8"></div>
         <div class="bar9"></div>
         <div class="bar10"></div>
         <div class="bar11"></div>
         <div class="bar12"></div>
      </div>

      <div class="cg-busy-default-text ng-binding"></div>

   </div>

</div></div></div></div></aab-widget><!-- end ngIf: contentWidgetCtrl.widgetType == 'application' -->
					<!-- ngIf: contentWidgetCtrl.widgetType == 'content' -->
			</div>
	</div></div>
    <div class="bp-widget-foot"></div>
</div></div><div class="bp-container bp-ui-dragRoot bp-manageableArea --area bp-area" data-pid="mijn-overzicht-overzicht-index-pols-leanback-manageable-area"><div data-pid="" class="bp-widget bp-ui-dragRoot">
    <div class="bp-widget-head"></div>
    <div class="bp-widget-pref"></div>
    <div class="bp-widget-body ng-scope"><div>
			<div xmlns="http://www.w3.org/1999/xhtml" data-ng-controller="contentWidgetController as contentWidgetCtrl" class="ng-scope">
					<!-- ngIf: contentWidgetCtrl.widgetType == 'application' --><aab-widget ng-if="contentWidgetCtrl.widgetType == 'application'" data-widget-template="application" class="ng-scope"><div data-ng-class="widget.context.getTemplateSettings().container.style" class="container-fluid"><div data-ng-class="widget.context.getTemplateSettings().panel.style" cg-busy="{promise:widget.spinner.widgetPromise,message:widget.spinner.message,backdrop:widget.spinner.backdrop,templateUrl:widget.spinner.templateUrl,wrapperClass:widget.spinner.wrapperClass,delay:widget.spinner.delay,minDuration:widget.spinner.minDuration}" style="position: relative;" class="hidden-xxs hidden-xs hidden-sm"><!-- ngIf: widget.context.getTemplateSettings().panel.header.show --><div data-ng-if="widget.context.getTemplateSettings().panel.header.show" data-ng-class="widget.context.getTemplateSettings().panel.header.style" data-ng-hide="widget.context.hideHeader" class="ng-scope ng-hide panel-heading"><!-- ngIf: !widget.context.error || widget.context.error.isRecoverable --><button type="submit" data-ng-class="widget.context.getHeaderSettings().leftButton.class" data-ng-click="widget.handleGoBackClick()" data-ng-show="widget.context.getHeaderSettings().leftButton.show" data-ng-if="!widget.context.error || widget.context.error.isRecoverable" class="ng-scope ng-hide btn btn-default ocf-btn-back"><span data-translate="Button-Back" data-translate-values="" data-translate-default="terug." class="ng-scope">terug.</span></button><!-- end ngIf: !widget.context.error || widget.context.error.isRecoverable --><!-- ngIf: (!widget.context.error || widget.context.error.isRecoverable) && widget.context.getHeaderSettings().rightButton.show --><h2 data-ng-show="widget.context.getHeaderSettings().general.title" class="panel-title ng-binding ng-hide" data-ng-class="{'mb-0': widget.context.getHeaderSettings().general.title}" data-ng-bind="widget.context.getHeaderSettings().general.title"></h2><h2 data-ng-hide="widget.context.getHeaderSettings().general.title" class="panel-title ng-scope mb-0" data-ng-class="{'mb-0': !widget.context.getHeaderSettings().general.title}" data-translate="" data-translate-default=""></h2></div><!-- end ngIf: widget.context.getTemplateSettings().panel.header.show --><div data-ng-class="widget.context.getTemplateSettings().panel.body.style" class="panel-body"><aab-sdm data-sdm="widget.context.sdm" class="ng-isolate-scope"><!-- ngIf: emerald --><div ng-if="emerald" class="alert em-alert-warning px-sm-2 ng-scope ng-hide" role="alert" data-ng-show="sdm.showSdmLabel"><div class="d-flex flex-row"><span class="float-left flex-shrink-0 mr-1 em-icon-size-3 sy-notification-warning"></span> <span class="sr-only">Error:</span><div><!-- ngIf: sdm.title && (sdm.title | translate) --><p class="mb-0 ng-binding" data-ng-bind-html="sdm.text | translate | aabTrustedHtml"></p></div></div></div><!-- end ngIf: emerald --><!-- ngIf: !emerald --></aab-sdm><aab-alert data-error="widget.context.error" data-ng-hide="widget.context.isStateModalOpen &amp;&amp; widget.context.error &amp;&amp; widget.context.error.isRecoverable" class="ng-isolate-scope"><!-- ngIf: emerald --><div ng-if="emerald" class="alert em-alert-warning px-sm-2 ng-scope ng-isolate-scope ng-hide" role="alert" data-ng-click="isCollapsed = !isCollapsed" aria-live="assertive" data-ng-show="error" data-aab-scroll-to="error !== undefined" data-testid="alert-container"><!-- ngIf: error.faultCode --><div class="d-flex flex-row"><span class="float-left flex-shrink-0 mr-1 em-icon-size-3 sy-notification-warning"></span> <span class="sr-only">Error:</span><div><!-- ngIf: error.title && (error.title | translate) --><p class="mb-0 ng-binding" data-ng-bind-html="error.text | translate | aabTrustedHtml" data-translate-default="Er is een fout opgetreden" data-testid="second-alert-warning-text"></p></div></div><!-- ngIf: error.options.button --></div><!-- end ngIf: emerald --><!-- ngIf: !emerald --></aab-alert><aab-step-counter data-steps="widget.context.steps" data-ng-hide="widget.context.error &amp;&amp; !widget.context.error.isRecoverable"></aab-step-counter><aab-update-loader class="ng-isolate-scope"><div class="ocf-update-loader ng-hide" data-ng-show="vm.show"><span class="glyphicon glyphicon-ok-circle ocf-icon-large ng-hide" data-ng-show="vm.successIcon"></span> <span data-us-spinner="{&quot;lines&quot;:12,&quot;length&quot;:6,&quot;width&quot;:3,&quot;radius&quot;:8,&quot;color&quot;:&quot;#fff&quot;,&quot;speed&quot;:1,&quot;trail&quot;:100,&quot;shadow&quot;:false,&quot;left&quot;:&quot;20px&quot;,&quot;top&quot;:&quot;50%&quot;}" data-spinner-key="spinner-wrapper" class="ng-scope"></span><h3 aria-role="alert" translate="" class="ng-scope"></h3></div></aab-update-loader><!-- uiView: --><ui-view data-ng-hide="widget.context.error &amp;&amp; !widget.context.error.isRecoverable" class="ng-scope"><aab-widget-module ng-controller="contentController as contentController" class="ng-scope"><!-- ngInclude: --><ng-include src="contentController.getTemplate()" class="ng-scope"></ng-include></aab-widget-module></ui-view></div><div class="cg-busy cg-busy-backdrop cg-busy-backdrop-animation ng-hide ng-scope" ng-show="$cgBusyIsActive()"></div><div class="undefined ng-hide ng-scope" ng-show="$cgBusyIsActive()"><div class="cg-busy-default-wrapper" style="position: absolute; inset: 0px;">

   <div class="cg-busy-default-sign">

      <div class="cg-busy-default-spinner">
         <div class="bar1"></div>
         <div class="bar2"></div>
         <div class="bar3"></div>
         <div class="bar4"></div>
         <div class="bar5"></div>
         <div class="bar6"></div>
         <div class="bar7"></div>
         <div class="bar8"></div>
         <div class="bar9"></div>
         <div class="bar10"></div>
         <div class="bar11"></div>
         <div class="bar12"></div>
      </div>

      <div class="cg-busy-default-text ng-binding"></div>

   </div>

</div></div></div></div></aab-widget><!-- end ngIf: contentWidgetCtrl.widgetType == 'application' -->
					<!-- ngIf: contentWidgetCtrl.widgetType == 'content' -->
			</div>
	</div></div>
    <div class="bp-widget-foot"></div>
</div><div data-pid="" class="bp-widget bp-ui-dragRoot">
    <div class="bp-widget-head"></div>
    <div class="bp-widget-pref"></div>
    <div class="bp-widget-body ng-scope"><div><whats-new xmlns="http://www.w3.org/1999/xhtml" class="ng-isolate-scope"></whats-new></div></div>
    <div class="bp-widget-foot"></div>
</div></div></div></div></div></main><div id="footer" class="bp-area em-oca"><!-- start abn amro footer --><div class="container-fluid-nomax ocf-footer" data-pid="layoutfooter-container-myabnamro-em-login"><footer><div class="container-fluid bp-area"><div class="ocf-languageswitch"><ul><li role="presentation" data-locale="nl" class="active "><a href="https://www.abnamro.nl/portalserver/mijn-abnamro/mijn-overzicht/overzicht/index.html" title="Nederlands">NL</a></li><li role="presentation" data-locale="en"><a href="https://www.abnamro.nl/portalserver/my-abnamro/my-overview/overview/index.html" title="English">EN</a></li></ul></div><div class="ocf-corp-nav text-xs-center"><h2 class="sr-only">Footer navigatie</h2><ul class="nav nav-pills"><li role="presentation"><a data-linktype="externalLink" href="https://www.abnamro.nl/nl/prive/abnamro/index.html">
                            Over ABN AMRO
                            </a></li><li role="presentation"><a data-linktype="externalLink" href="https://www.abnamro.nl/nl/prive/abnamro/toegankelijkheid.html">
                            Toegankelijkheid
                            </a></li><li role="presentation"><a data-linktype="externalLink" href="https://www.abnamro.nl/nl/prive/abnamro/duurzaamheid/index.html">
                            Duurzaamheid
                            </a></li><li role="presentation"><a data-linktype="externalLink" href="https://www.abnamro.nl/nl/prive/abnamro/veiligheid.html">
                            Veiligheid
                            </a></li><li role="presentation"><a data-linktype="externalLink" href="https://www.abnamro.nl/nl/prive/abnamro/privacy/index.html">
                            Privacy en cookies
                            </a></li><li role="presentation"><a data-linktype="externalLink" href="https://www.abnamro.nl/nl/prive/abnamro/disclaimer.html">
                            Disclaimer
                            </a></li></ul></div><div class="ocf-copyright"><span> © ABN AMRO Bank N.V.</span></div><div class="bp-widget Xbp-ui-dragRoot Xbp-ui-dragGrip"><div class="bp-widget-head"></div><div class="bp-widget-pref"></div><div class="bp-widget-body"></div><div class="bp-widget-foot"></div></div></div></footer></div><!-- end abn amro footer --></div></div><script type="text/backbase-xml"><?xml version="1.0" encoding="UTF-8"?><page><type>page</type><name>mijn-overzicht-overzicht-index-mijn-abnamro</name><contextItemName>mijn-abnamro</contextItemName><parentItemName>mijn-abnamro</parentItemName><extendedItemName>masterpage-mijn-abnamro-em-login</extendedItemName><securityProfile>CONSUMER</securityProfile><tags><tag blacklist="false" type="regular">mijn-abnamro</tag><tag blacklist="false" type="regular">emerald</tag><tag blacklist="false" type="regular">Application</tag></tags><uuid>9cea7dd6-6bc8-9eb8-d37d-f07fcc848336</uuid><lockState>UNLOCKED</lockState><properties><property name="Description" readonly="true" itemName="BlankPage"><value type="String"/></property><property name="TemplateName" readonly="true" itemName="masterpage-mijn-abnamro-em-login"><value type="string">masterpage-template-emerald-myabnamro</value></property><property label="Browser Title" name="abn_browser_title" readonly="true" itemName="mijn-overzicht-overzicht-index-mijn-abnamro" viewHint="designModeOnly,manager,text-input"><value type="string">Rekeningoverzicht - ABN AMRO</value></property><property label="Canonical URL" name="abn_canonical" readonly="true" itemName="mijn-overzicht-overzicht-index-mijn-abnamro" viewHint="designModeOnly,manager,text-input"><value type="string">https://www.abnamro.nl/portalserver/mijn-abnamro/mijn-overzicht/overzicht/index.html</value></property><property label="Search Engine Optimized (no follow)" name="abn_nofollow" readonly="true" itemName="masterpage-mijn-abnamro-em-login" viewHint="designModeOnly,manager,checkbox"><value type="boolean">true</value></property><property label="Search Engine Optimized (no index)" name="abn_noindex" readonly="true" itemName="masterpage-mijn-abnamro-em-login" viewHint="designModeOnly,manager,checkbox"><value type="boolean">true</value></property><property label="Page Title (user has no session)" name="abn_nosession_title" readonly="true" itemName="masterpage-mijn-abnamro-em-login" viewHint="designModeOnly,manager,text-input"><value type="string">Internet Bankieren</value></property><property label="Path" name="abn_path" readonly="true" itemName="mijn-overzicht-overzicht-index-mijn-abnamro" viewHint="designModeOnly,manager,text-input"><value type="string">mijn-abnamro/mijn-overzicht/overzicht/index.html</value></property><property name="behaviors" readonly="true" itemName="masterpage-mijn-abnamro-em-login"><value type="string">be.perspective.Manager be.portalClientExt.PortalManagerPreferencesForm</value></property><property name="enableUsabilla" readonly="true" itemName="masterpage-mijn-abnamro-em-login"><value type="string">true</value></property><property label="hideMobileTitle" name="hide_mobile_title" readonly="true" itemName="mijn-overzicht-overzicht-index-mijn-abnamro" viewHint="designModeOnly,manager,checkbox"><value type="boolean">true</value></property><property label="Uses Legacy Template" name="legacyTemplate" readonly="true" itemName="masterpage-mijn-abnamro-em-login" viewHint="designModeOnly,manager,checkbox"><value type="boolean">false</value></property><property name="stylesheetCoreHref" readonly="true" itemName="masterpage-mijn-abnamro-em-login"><value type="string">/style/css/themes/emerald/core.css</value></property><property name="title" readonly="true" itemName="mijn-overzicht-overzicht-index-mijn-abnamro" viewHint="designModeOnly,manager,text-input"><value type="string">Rekeningoverzicht</value></property><property name="usabillaScriptSrc" readonly="true" itemName="masterpage-mijn-abnamro-em-login"><value type="string">/nl/widgetdelivery/unauthenticated/oca/vendor/usabilla-nl.js</value></property><property name="widgetName" readonly="true" itemName="mijn-overzicht-overzicht-index-mijn-abnamro"><value type="string">accounts</value></property></properties><children><container><name>layoutheader-container-myabnamro-em-login</name><contextItemName>mijn-abnamro</contextItemName><parentItemName>masterpage-mijn-abnamro-em-login</parentItemName><extendedItemName>blank-container-myabnamro</extendedItemName><securityProfile>CONSUMER</securityProfile><tags/><uuid>eff7c262-2dcb-49e1-bdec-e3b3fb006532</uuid><lockState>UNLOCKED</lockState><properties><property name="Description" readonly="true" itemName="blank-container-myabnamro"><value type="String"/></property><property name="TemplateName" readonly="true" itemName="layoutheader-container-myabnamro-em-login"><value type="string">main-container-myabnamro</value></property><property name="area" readonly="true" itemName="layoutheader-container-myabnamro-em-login"><value type="string">0</value></property><property name="order" readonly="true" itemName="layoutheader-container-myabnamro-em-login"><value type="double">1.0</value></property><property name="title" readonly="true" itemName="layoutheader-container-myabnamro-em-login"><value type="string">Head Container</value></property></properties><children><widget><name>header-widget-mijn-abnamro-em-login</name><contextItemName>mijn-abnamro</contextItemName><parentItemName>layoutheader-container-myabnamro-em-login</parentItemName><extendedItemName>header-widget-myabnamro-ec</extendedItemName><securityProfile>CONSUMER</securityProfile><tags><tag blacklist="false" type="regular">bankieren</tag><tag blacklist="false" type="regular">web</tag></tags><uuid>046e4cc2-fb6f-43b4-b5e4-876c6e748b37</uuid><lockState>UNLOCKED</lockState><properties><property name="Description" readonly="true" itemName="header-widget-myabnamro-ec"><value type="String">Header Widget</value></property><property name="TemplateName" readonly="true" itemName="header-widget-myabnamro-ec"><value type="string">Standard_Widget</value></property><property name="area" readonly="true" itemName="header-widget-mijn-abnamro-em-login"><value type="string">0</value></property><property label="Menu Navigation Template" name="menuNavTemplate" readonly="true" itemName="header-widget-myabnamro-ec" viewHint="designModeOnly,manager,text-input"><value type="string">$(contextRoot)/static/myabnamro/navigation/templates/json-menu-links.html</value></property><property label="Open Domain Navigation Template" name="opendomainNavTemplate" readonly="true" itemName="header-widget-myabnamro-ec" viewHint="designModeOnly,manager,text-input"><value type="string">$(contextRoot)/static/myabnamro/navigation/templates/json-opendomain-links.html</value></property><property name="order" readonly="true" itemName="header-widget-mijn-abnamro-em-login"><value type="double">1.0</value></property><property label="Search Navigation Template" name="searchNavTemplate" readonly="true" itemName="header-widget-myabnamro-ec" viewHint="designModeOnly,manager,text-input"><value type="string">$(contextRoot)/static/myabnamro/navigation/templates/json-search-links.html</value></property><property name="src" readonly="true" itemName="header-widget-myabnamro-ec"><value type="string">/nl/widgetdelivery/unauthenticated/myabnamro/widgets/header-ma/header-ma.html</value></property><property name="thumbnailUrl" readonly="true" itemName="header-widget-myabnamro-ec"><value type="string">$(contextRoot)/static/dashboard/media/icons/icons-widgets_01-default.png</value></property><property label="Title" name="title" readonly="true" itemName="header-widget-myabnamro-ec"><value type="string">Header</value></property><property label="Widget Chrome" name="widgetChrome" readonly="true" itemName="header-widget-myabnamro-ec" viewHint="select-one,designModeOnly"><value type="string">$(contextRoot)/static/internet-portal/chromes/widget-none.html</value></property></properties></widget></children></container><container><name>layout-main-container-em-login</name><contextItemName>mijn-abnamro</contextItemName><parentItemName>masterpage-mijn-abnamro-em-login</parentItemName><extendedItemName>nine-three-container-em-myabnamro</extendedItemName><securityProfile>CONSUMER</securityProfile><tags/><uuid>f642e1a2-aee2-4a4a-9277-e3ee07906bcc</uuid><lockState>UNLOCKED</lockState><properties><property name="Description" readonly="true" itemName="nine-three-container-em-myabnamro"><value type="String"/></property><property name="TemplateName" readonly="true" itemName="nine-three-container-em-myabnamro"><value type="string">nine-three-column-template-em-myabnamro</value></property><property name="area" readonly="true" itemName="layout-main-container-em-login"><value type="string">1</value></property><property name="order" readonly="true" itemName="layout-main-container-em-login"><value type="double">1.0</value></property><property name="thumbnailUrl" readonly="true" itemName="nine-three-container-em-myabnamro"><value type="string">$(contextRoot)/static/backbase.com.2012.nexus/media/icons/pagedesigner-layouts-icons_deck.png</value></property><property name="title" readonly="true" itemName="nine-three-container-em-myabnamro"><value type="string">2 Column container (9:3) Emerald My ABNAMRO</value></property></properties><children><container><name>mijn-overzicht-overzicht-index-pols-billboard-manageable-area</name><contextItemName>mijn-abnamro</contextItemName><parentItemName>mijn-overzicht-overzicht-index-mijn-abnamro</parentItemName><extendedItemName>manageable-area-pols_billboard-em-login</extendedItemName><securityProfile>CONSUMER</securityProfile><tags><tag blacklist="false" type="regular">MANAGEABLE AREA</tag></tags><uuid>94a92a52-a45f-48e5-bcaa-e98cdb6a5b8b</uuid><lockState>UNLOCKED</lockState><properties><property name="Description" readonly="true" itemName="manageableArea-container-myabnamro-sc"><value type="String"/></property><property name="TemplateName" readonly="true" itemName="manageableArea-container-myabnamro-sc"><value type="string">manageable-area-myabnamro</value></property><property name="area" readonly="true" itemName="manageable-area-pols_billboard-em-login"><value type="string">1</value></property><property name="autoExtend" readonly="true" itemName="manageableArea-container-myabnamro-sc"><value type="boolean">true</value></property><property name="isManageableArea" readonly="true" itemName="manageableArea-container-myabnamro-sc"><value type="boolean">true</value></property><property name="order" readonly="true" itemName="manageable-area-pols_billboard-em-login"><value type="double">1.0</value></property><property name="thumbnailUrl" readonly="true" itemName="manageableArea-container-myabnamro-sc"><value type="string">$(contextRoot)/static/backbase.com.2013.aurora/containers/ManageableArea/media/ManageableArea-icon.png</value></property><property name="title" readonly="true" itemName="manageableArea-container-myabnamro-sc"><value type="string">Manageable Area</value></property></properties><children><widget><name>mijn-overzicht-overzicht-index-billboard-widget</name><contextItemName>mijn-abnamro</contextItemName><parentItemName>mijn-overzicht-overzicht-index-pols-billboard-manageable-area</parentItemName><extendedItemName>content-widget-mijn-abnamro</extendedItemName><securityProfile>CONSUMER</securityProfile><tags><tag blacklist="false" type="regular">CONTENT WIDGET</tag><tag blacklist="false" type="regular">Responsive</tag><tag blacklist="false" type="regular">RESPONSIVE8016</tag></tags><uuid>cae8b066-c4c2-45a4-bd9a-3548a048f340</uuid><lockState>UNLOCKED</lockState><properties><property name="Description" readonly="true" itemName="content-widget-mijn-abnamro"><value type="String"/></property><property name="TemplateName" readonly="true" itemName="content-widget-mijn-abnamro"><value type="string">Standard_Widget</value></property><property name="area" readonly="true" itemName="mijn-overzicht-overzicht-index-billboard-widget"><value type="string">0</value></property><property label="billboard4-template-1" name="billboard4-template-1" readonly="true" itemName="mijn-overzicht-overzicht-index-billboard-widget" viewHint="designModeOnly,manager,text-input"><value type="string">/{{language}}/widgetcontent/rp/content/banner/billboard4-template-1.json</value></property><property label="billboard4-template-2" name="billboard4-template-2" readonly="true" itemName="mijn-overzicht-overzicht-index-billboard-widget" viewHint="designModeOnly,manager,text-input"><value type="string">/{{language}}/widgetcontent/rp/content/banner/billboard4-template-2.json</value></property><property label="billboard4-template-3" name="billboard4-template-3" readonly="true" itemName="mijn-overzicht-overzicht-index-billboard-widget" viewHint="designModeOnly,manager,text-input"><value type="string">/{{language}}/widgetcontent/rp/content/banner/billboard4-template-3.json</value></property><property label="contentType" name="contentType" readonly="true" itemName="mijn-overzicht-overzicht-index-billboard-widget" viewHint="designModeOnly,manager,text-input"><value type="string">pols-billboard4</value></property><property label="Client Side Rendering" name="csr" readonly="true" itemName="content-widget-sc"><value type="boolean">true</value></property><property label="dataSource" name="dataSource" readonly="true" itemName="content-widget-mijn-abnamro" viewHint="designModeOnly,manager,text-input"><value type="string"/></property><property label="Description" name="description" readonly="true" itemName="content-widget-mijn-abnamro" viewHint="designModeOnly,manager,text-input"><value type="string">Content Widget</value></property><property label="Form key" name="formKey" readonly="true" itemName="content-widget-mijn-abnamro" viewHint="designModeOnly,manager,text-input"><value type="string"/></property><property label="hideHeader" name="hideHeader" readonly="true" itemName="mijn-overzicht-overzicht-index-billboard-widget" viewHint="designModeOnly,manager,checkbox"><value type="boolean">true</value></property><property label="lean-backward_template" name="lean-backward_template" readonly="true" itemName="mijn-overzicht-overzicht-index-billboard-widget" viewHint="designModeOnly,manager,text-input"><value type="string">/{{language}}/widgetcontent/rp/content/banner/lean-backward.json</value></property><property label="leanBackward_priority" name="leanBackward_priority" readonly="true" itemName="content-widget-mijn-abnamro" viewHint="designModeOnly,manager,text-input"><value type="string">1</value></property><property name="order" readonly="true" itemName="mijn-overzicht-overzicht-index-billboard-widget"><value type="double">0.0</value></property><property label="primaryActionText" name="primaryActionText" readonly="true" itemName="content-widget-mijn-abnamro" viewHint="designModeOnly,manager,text-input"><value type="string"/></property><property label="primaryActionURL" name="primaryActionURL" readonly="true" itemName="content-widget-mijn-abnamro" viewHint="designModeOnly,manager,text-input"><value type="string"/></property><property label="secondaryActionText" name="secondaryActionText" readonly="true" itemName="content-widget-mijn-abnamro" viewHint="designModeOnly,manager,text-input"><value type="string"/></property><property label="secondaryActionURL" name="secondaryActionURL" readonly="true" itemName="content-widget-mijn-abnamro" viewHint="designModeOnly,manager,text-input"><value type="string"/></property><property name="src" readonly="true" itemName="content-widget-mijn-abnamro"><value type="string">/nl/widgetdelivery/unauthenticated/oca/app/widgets/content/content.html</value></property><property name="thumbnailUrl" readonly="true" itemName="content-widget-mijn-abnamro"><value type="string">$(contextRoot)/static/dashboard/media/icons/icons-widgets_01-default.png</value></property><property label="Title" name="title" readonly="true" itemName="content-widget-mijn-abnamro" viewHint="designModeOnly,manager,text-input"><value type="string">Content Widget</value></property><property label="titleText" name="titleText" readonly="true" itemName="content-widget-mijn-abnamro" viewHint="designModeOnly,manager,text-input"><value type="string"/></property><property name="trackAnalytics" readonly="true" itemName="content-widget-mijn-abnamro"><value type="boolean">false</value></property><property label="Widget Chrome" name="widgetChrome" readonly="true" itemName="content-widget-mijn-abnamro"><value type="string">$(contextRoot)/static/internet-portal/chromes/widget-none.html</value></property></properties></widget></children></container><container><name>personal-login-container-em-login</name><contextItemName>mijn-abnamro</contextItemName><parentItemName>layout-main-container-em-login</parentItemName><extendedItemName>manageableArea-container-myabnamro-sc</extendedItemName><securityProfile>CONSUMER</securityProfile><tags><tag blacklist="false" type="regular">MANAGEABLE AREA</tag></tags><uuid>c147d790-0353-4490-8f40-145111157340</uuid><lockState>UNLOCKED</lockState><properties><property name="Description" readonly="true" itemName="manageableArea-container-myabnamro-sc"><value type="String"/></property><property name="TemplateName" readonly="true" itemName="manageableArea-container-myabnamro-sc"><value type="string">manageable-area-myabnamro</value></property><property name="area" readonly="true" itemName="personal-login-container-em-login"><value type="string">0</value></property><property name="autoExtend" readonly="true" itemName="manageableArea-container-myabnamro-sc"><value type="boolean">true</value></property><property name="isManageableArea" readonly="true" itemName="manageableArea-container-myabnamro-sc"><value type="boolean">true</value></property><property name="order" readonly="true" itemName="personal-login-container-em-login"><value type="double">1.1</value></property><property name="thumbnailUrl" readonly="true" itemName="manageableArea-container-myabnamro-sc"><value type="string">$(contextRoot)/static/backbase.com.2013.aurora/containers/ManageableArea/media/ManageableArea-icon.png</value></property><property name="title" readonly="true" itemName="manageableArea-container-myabnamro-sc"><value type="string">Manageable Area</value></property></properties><children><widget><name>login-widget-mijn-abnamro-em</name><contextItemName>mijn-abnamro</contextItemName><parentItemName>personal-login-container-em-login</parentItemName><extendedItemName>login-widget-sc</extendedItemName><securityProfile>CONSUMER</securityProfile><tags><tag blacklist="false" type="regular">login</tag><tag blacklist="false" type="regular">LOGIN8055</tag><tag blacklist="false" type="regular">Responsive</tag><tag blacklist="false" type="regular">RESPONSIVE8016</tag></tags><uuid>f075f7d9-52db-4da9-9bb1-5fba41d6b025</uuid><lockState>UNLOCKED</lockState><properties><property name="Description" readonly="true" itemName="login-widget-sc"><value type="String"/></property><property name="TemplateName" readonly="true" itemName="login-widget-sc"><value type="string">Standard_Widget</value></property><property label="Allowed methods" name="allowedMethods" readonly="true" itemName="login-widget-sc" viewHint="designModeOnly,manager,text-input"><value type="string">qrcode,edentifier2</value></property><property name="area" readonly="true" itemName="login-widget-mijn-abnamro-em"><value type="string">0</value></property><property label="Use client side rendering" name="csr" readonly="true" itemName="login-widget-sc" viewHint="designModeOnly,manager,checkbox"><value type="boolean">true</value></property><property label="Description" name="description" readonly="true" itemName="login-widget-sc" viewHint="user,designModeOnly"><value type="string">Login Widget</value></property><property label="hideHeader" name="hideHeader" readonly="true" itemName="login-widget-mijn-abnamro-em"><value type="boolean">true</value></property><property label="Login preference cookie name" name="loginCookieName" readonly="true" itemName="login-widget-sc" viewHint="designModeOnly,manager"><value type="string">rpLoginPreference</value></property><property label="Tridion translation file location" name="loginTranslationURL" readonly="true" itemName="login-widget-sc" viewHint="designModeOnly,manager"><value type="string">/{language}/widgetcontent/rp/widget-modules/login.json</value></property><property name="order" readonly="true" itemName="login-widget-mijn-abnamro-em"><value type="double">1.0</value></property><property name="requestICUrl" readonly="true" itemName="login-widget-mijn-abnamro-em"><value type="string">/portalserver/mijn-abnamro/instellingen/identificatiecode/aanmaken.html</value></property><property label="sdmKey" name="sdmKey" readonly="true" itemName="login-widget-sc" viewHint="designModeOnly,manager"><value type="string">Disturbance_oc_login_generic</value></property><property label="Show back button in login" name="showLoginBackButton" readonly="true" itemName="login-widget-sc" viewHint="designModeOnly,manager"><value type="boolean">false</value></property><property name="src" readonly="true" itemName="login-widget-sc"><value type="string">/nl/widgetdelivery/unauthenticated/oca/app/widgets/login/login.html</value></property><property name="thumbnailUrl" readonly="true" itemName="login-widget-sc"><value type="string">$(contextRoot)/static/dashboard/media/icons/icons-widgets_01-default.png</value></property><property label="Title" name="title" readonly="true" itemName="login-widget-sc" viewHint="user,designModeOnly"><value type="string">Login Widget</value></property><property label="Widget Chrome" name="widgetChrome" readonly="true" itemName="login-widget-sc" viewHint="select-one,designModeOnly"><value type="string">$(contextRoot)/static/internet-portal/chromes/widget-none.html</value></property></properties></widget></children></container><container><name>mijn-overzicht-overzicht-index-pols-leanback-manageable-area</name><contextItemName>mijn-abnamro</contextItemName><parentItemName>mijn-overzicht-overzicht-index-mijn-abnamro</parentItemName><extendedItemName>manageable-area-pols_leanbackward-em-login</extendedItemName><securityProfile>CONSUMER</securityProfile><tags><tag blacklist="false" type="regular">MANAGEABLE AREA</tag></tags><uuid>b6b51c61-a03b-4ce9-8b40-1f95ba26b816</uuid><lockState>UNLOCKED</lockState><properties><property name="Description" readonly="true" itemName="manageableArea-container-myabnamro-sc"><value type="String"/></property><property name="TemplateName" readonly="true" itemName="manageableArea-container-myabnamro-sc"><value type="string">manageable-area-myabnamro</value></property><property name="area" readonly="true" itemName="manageable-area-pols_leanbackward-em-login"><value type="string">1</value></property><property name="autoExtend" readonly="true" itemName="manageableArea-container-myabnamro-sc"><value type="boolean">true</value></property><property name="isManageableArea" readonly="true" itemName="manageableArea-container-myabnamro-sc"><value type="boolean">true</value></property><property name="order" readonly="true" itemName="manageable-area-pols_leanbackward-em-login"><value type="double">2.0</value></property><property name="thumbnailUrl" readonly="true" itemName="manageableArea-container-myabnamro-sc"><value type="string">$(contextRoot)/static/backbase.com.2013.aurora/containers/ManageableArea/media/ManageableArea-icon.png</value></property><property name="title" readonly="true" itemName="manageableArea-container-myabnamro-sc"><value type="string">Manageable Area</value></property></properties><children><widget><name>mijn-overzicht-overzicht-index-pols-widget</name><contextItemName>mijn-abnamro</contextItemName><parentItemName>mijn-overzicht-overzicht-index-pols-leanback-manageable-area</parentItemName><extendedItemName>content-widget-mijn-abnamro</extendedItemName><securityProfile>CONSUMER</securityProfile><tags><tag blacklist="false" type="regular">CONTENT WIDGET</tag><tag blacklist="false" type="regular">Responsive</tag><tag blacklist="false" type="regular">RESPONSIVE8016</tag></tags><uuid>01b5c2cf-fc4d-4d44-81fd-4ff94693cebd</uuid><lockState>UNLOCKED</lockState><properties><property name="Description" readonly="true" itemName="content-widget-mijn-abnamro"><value type="String"/></property><property name="TemplateName" readonly="true" itemName="content-widget-mijn-abnamro"><value type="string">Standard_Widget</value></property><property name="area" readonly="true" itemName="content-widget-mijn-abnamro"><value type="string">0</value></property><property label="contentType" name="contentType" readonly="true" itemName="mijn-overzicht-overzicht-index-pols-widget" viewHint="designModeOnly,manager,text-input"><value type="string">pols-leanbackward</value></property><property label="Client Side Rendering" name="csr" readonly="true" itemName="content-widget-sc"><value type="boolean">true</value></property><property label="dataSource" name="dataSource" readonly="true" itemName="content-widget-mijn-abnamro" viewHint="designModeOnly,manager,text-input"><value type="string"/></property><property label="Description" name="description" readonly="true" itemName="content-widget-mijn-abnamro" viewHint="designModeOnly,manager,text-input"><value type="string">Content Widget</value></property><property label="Form key" name="formKey" readonly="true" itemName="content-widget-mijn-abnamro" viewHint="designModeOnly,manager,text-input"><value type="string"/></property><property label="hideHeader" name="hideHeader" readonly="true" itemName="mijn-overzicht-overzicht-index-pols-widget" viewHint="designModeOnly,manager,checkbox"><value type="boolean">true</value></property><property label="lean-backward_template" name="lean-backward_template" readonly="true" itemName="mijn-overzicht-overzicht-index-pols-widget" viewHint="designModeOnly,manager,text-input"><value type="string">/{{language}}/widgetcontent/rp/content/banner/lean-backward.json</value></property><property label="leanBackward_priority" name="leanBackward_priority" readonly="true" itemName="content-widget-mijn-abnamro" viewHint="designModeOnly,manager,text-input"><value type="string">1</value></property><property name="order" readonly="true" itemName="content-widget-mijn-abnamro"><value type="double">1.0</value></property><property label="primaryActionText" name="primaryActionText" readonly="true" itemName="content-widget-mijn-abnamro" viewHint="designModeOnly,manager,text-input"><value type="string"/></property><property label="primaryActionURL" name="primaryActionURL" readonly="true" itemName="content-widget-mijn-abnamro" viewHint="designModeOnly,manager,text-input"><value type="string"/></property><property label="secondaryActionText" name="secondaryActionText" readonly="true" itemName="content-widget-mijn-abnamro" viewHint="designModeOnly,manager,text-input"><value type="string"/></property><property label="secondaryActionURL" name="secondaryActionURL" readonly="true" itemName="content-widget-mijn-abnamro" viewHint="designModeOnly,manager,text-input"><value type="string"/></property><property name="src" readonly="true" itemName="content-widget-mijn-abnamro"><value type="string">/nl/widgetdelivery/unauthenticated/oca/app/widgets/content/content.html</value></property><property name="thumbnailUrl" readonly="true" itemName="content-widget-mijn-abnamro"><value type="string">$(contextRoot)/static/dashboard/media/icons/icons-widgets_01-default.png</value></property><property label="Title" name="title" readonly="true" itemName="content-widget-mijn-abnamro" viewHint="designModeOnly,manager,text-input"><value type="string">Content Widget</value></property><property label="titleText" name="titleText" readonly="true" itemName="content-widget-mijn-abnamro" viewHint="designModeOnly,manager,text-input"><value type="string"/></property><property name="trackAnalytics" readonly="true" itemName="content-widget-mijn-abnamro"><value type="boolean">false</value></property><property label="Widget Chrome" name="widgetChrome" readonly="true" itemName="content-widget-mijn-abnamro"><value type="string">$(contextRoot)/static/internet-portal/chromes/widget-none.html</value></property></properties></widget><widget><name>mijn-overzicht-overzicht-index-whats-new-widget</name><contextItemName>mijn-abnamro</contextItemName><parentItemName>mijn-overzicht-overzicht-index-pols-leanback-manageable-area</parentItemName><extendedItemName>whats-new-widget-mijn-abnamro</extendedItemName><securityProfile>CONSUMER</securityProfile><tags><tag blacklist="false" type="regular">Responsive</tag></tags><uuid>6c870766-d659-4a5e-b852-c19ea1860724</uuid><lockState>UNLOCKED</lockState><properties><property name="Description" readonly="true" itemName="whats-new-widget-ec"><value type="String"/></property><property name="TemplateName" readonly="true" itemName="whats-new-widget-ec"><value type="string">Standard_Widget</value></property><property name="area" readonly="true" itemName="mijn-overzicht-overzicht-index-whats-new-widget"><value type="string">0</value></property><property label="Use client side rendering" name="csr" readonly="true" itemName="whats-new-widget-ec" viewHint="designModeOnly,manager,checkbox"><value type="boolean">true</value></property><property label="Description" name="description" readonly="true" itemName="whats-new-widget-ec" viewHint="user,designModeOnly"><value type="string">What's New widget informs users about new features on the portal.</value></property><property name="order" readonly="true" itemName="mijn-overzicht-overzicht-index-whats-new-widget"><value type="double">1.0</value></property><property name="src" readonly="true" itemName="whats-new-widget-ec"><value type="string">/nl/widgetdelivery/unauthenticated/myabnamro/widgets/whats-new/whats-new.html</value></property><property name="thumbnailUrl" readonly="true" itemName="whats-new-widget-ec"><value type="string">$(contextRoot)/static/dashboard/media/icons/icons-widgets_01-default.png</value></property><property label="Title" name="title" readonly="true" itemName="whats-new-widget-ec" viewHint="user,designModeOnly"><value type="string">What's New widget</value></property><property label="Widget Chrome" name="widgetChrome" readonly="true" itemName="whats-new-widget-ec" viewHint="select-one,designModeOnly"><value type="string">$(contextRoot)/static/internet-portal/chromes/widget-none.html</value></property></properties></widget></children></container></children></container><container><name>layoutfooter-container-myabnamro-em-login</name><contextItemName>mijn-abnamro</contextItemName><parentItemName>masterpage-mijn-abnamro-em-login</parentItemName><extendedItemName>layoutfooter-container-myabnamro-sc</extendedItemName><securityProfile>CONSUMER</securityProfile><tags/><uuid>3f14b7df-0a5a-41d4-9ed2-7730084eef8b</uuid><lockState>UNLOCKED</lockState><properties><property name="Description" readonly="true" itemName="layoutfooter-container-myabnamro-sc"><value type="String"/></property><property name="TemplateName" readonly="true" itemName="layoutfooter-container-myabnamro-sc"><value type="string">layoutfooter-container-template-myabnamro</value></property><property name="area" readonly="true" itemName="layoutfooter-container-myabnamro-em-login"><value type="string">2</value></property><property name="order" readonly="true" itemName="layoutfooter-container-myabnamro-em-login"><value type="double">1.0</value></property><property name="thumbnailUrl" readonly="true" itemName="layoutfooter-container-myabnamro-sc"><value type="string">$(contextRoot)/static/backbase.com.2012.nexus/media/icons/pagedesigner-layouts-icons_deck.png</value></property><property name="title" readonly="true" itemName="layoutfooter-container-myabnamro-em-login"><value type="string">Footer Container</value></property></properties><children><widget><name>languageSwitch-widget-mijn-abnamro-em-login</name><contextItemName>mijn-abnamro</contextItemName><parentItemName>layoutfooter-container-myabnamro-em-login</parentItemName><extendedItemName>languageSwitch-widget-myabnamro-sc</extendedItemName><securityProfile>CONSUMER</securityProfile><tags><tag blacklist="false" type="regular">NAVIGATION</tag><tag blacklist="false" type="regular">Responsive</tag><tag blacklist="false" type="regular">LANGUAGE</tag></tags><uuid>8dc4dc32-5226-4158-acd5-28a8d60efe45</uuid><lockState>UNLOCKED</lockState><properties><property name="Description" readonly="true" itemName="languageSwitch-widget-myabnamro-sc"><value type="String"/></property><property name="TemplateName" readonly="true" itemName="languageSwitch-widget-myabnamro-sc"><value type="string">languageSwitch-widget-template-myabnamro</value></property><property name="area" readonly="true" itemName="languageSwitch-widget-mijn-abnamro-em-login"><value type="string">0</value></property><property name="order" readonly="true" itemName="languageSwitch-widget-mijn-abnamro-em-login"><value type="double">2.0</value></property><property name="thumbnailUrl" readonly="true" itemName="languageSwitch-widget-myabnamro-sc"><value type="string">$(contextRoot)/static/dashboard/media/icons/icons-widgets_01-default.png</value></property><property label="Title" name="title" readonly="true" itemName="languageSwitch-widget-myabnamro-sc" viewHint="user,designModeOnly"><value type="string">Language Switch Widget</value></property><property name="urlEn" readonly="true" itemName="languageSwitch-widget-mijn-abnamro-em-login"><value type="string">/portalserver/my-abnamro/my-overview/overview/index.html</value></property><property name="urlNl" readonly="true" itemName="languageSwitch-widget-mijn-abnamro-em-login"><value type="string">/portalserver/mijn-abnamro/mijn-overzicht/overzicht/index.html</value></property></properties></widget></children></container></children></page></script><div class="undefined"></div><div class="absolutePool"><div></div></div><div class="bp-drag-dragSymbol" style="position: absolute; display: none;"></div><div class="usabilla_live_button_container" role="button" tabindex="0" style="margin-top:-60px;width:40px;height:120px;position:fixed;z-index:999;right:0;top:50%" aria-label="Usabilla Feedback Button"><iframe src="bestanden/index_002.htm" style="width: 40px; height: 120px; margin: 0px; padding: 0px; border: 0px none; overflow: hidden; z-index: 9998; position: absolute; left: 0px; top: 0px; box-shadow: 0px 0px 0px; background-color: transparent;" marginwidth="0" marginheight="0" scrolling="no" data-tags="right" title="Usabilla Feedback Button" frameborder="0"></iframe></div><img src="bestanden/0.gif" width="1" height="1"><div id="viewport-toolkit"><div class="device-xl d-none d-xl-block">&nbsp;</div><div class="device-lg d-none d-lg-block d-xl-none">&nbsp;</div><div class="device-md d-none d-md-block d-lg-none">&nbsp;</div><div class="device-sm d-none d-sm-block d-md-none">&nbsp;</div><div class="device-xs d-block d-sm-none">&nbsp;</div></div><embed type="application/BECON-PlugIn" name="PLUGIN_BECON" id="PLUGIN_BECON" width="1" height="1"><embed type="application/BECON-PlugIn" name="PLUGIN_BECON" id="PLUGIN_BECON" width="1" height="1"><iframe style="display: none; visibility: hidden;" src="https://4368908.fls.doubleclick.net/activityi;src=4368908;type=tosy10;cat=2019_0;ord=4555899697492;gtm=2od9p0;auiddc=1533169593.1570036182;u15=b1d3d8a2-83bb-4f3f-ba0a-06c1b603af58;u20=retail;u21=mijn-overzicht;u22=overzicht;u24=NL;u25=nl;u26=mij%3Amijn%3Aoverzicht%3Aindex;u27=https%3A%2F%2Fwww.abnamro.nl%2Fportalserver%2Fmijn-abnamro%2Fmijn-overzicht%2Foverzicht%2Findex.html;u28=0;~oref=https%3A%2F%2Fwww.abnamro.nl%2Fportalserver%2Fmijn-abnamro%2Fmijn-overzicht%2Foverzicht%2Findex.html?" width="0" height="0"></iframe><iframe style="display: none; visibility: hidden;" src="https://4368908.fls.doubleclick.net/activityi;src=4368908;type=tosy10;cat=2019_0;ord=4431806523173;gtm=2od9p0;auiddc=1533169593.1570036182;u15=b1d3d8a2-83bb-4f3f-ba0a-06c1b603af58;u20=retail;u21=mijn-overzicht;u22=overzicht;u24=NL;u25=nl;u26=mij%3Amijn%3Aoverzicht%3Aindex;u27=https%3A%2F%2Fwww.abnamro.nl%2Fportalserver%2Fmijn-abnamro%2Fmijn-overzicht%2Foverzicht%2Findex.html;u28=0;~oref=https%3A%2F%2Fwww.abnamro.nl%2Fportalserver%2Fmijn-abnamro%2Fmijn-overzicht%2Foverzicht%2Findex.html?" width="0" height="0"></iframe><img src="bestanden/0_002.gif" width="1" height="1"><embed type="application/BECON-PlugIn" name="PLUGIN_BECON" id="PLUGIN_BECON" width="1" height="1"></body></html>