//~~tv:4049.20190226
//~~tc: Add support for purchase-details
//~~tc: Prepend "DC-" Advertiser ID prefix if not present
//~~tc: Add flag for firing purchase event when Order Id is present
//~~tc: Convert Counting Method to lower case

//tealium universal tag - utag.sender.4049 ut4.0.201909301229, Copyright 2019 Tealium.com Inc. All Rights Reserved.
try {
  (function (id, loader) {
    var u = {"id" : id};
    utag.o[loader].sender[id] = u;
    // Please do not modify
    if (utag.ut === undefined) { utag.ut = {}; }
    // Start Tealium loader 4.41
    var match = /ut\d\.(\d*)\..*/.exec(utag.cfg.v);
    if (utag.ut.loader === undefined || !match || parseInt(match[1]) < 41) { u.loader = function(o, a, b, c, l, m) { utag.DB(o); a = document; if (o.type == "iframe") { m = a.getElementById(o.id); if (m && m.tagName == "IFRAME") { b = m; } else { b = a.createElement("iframe"); } o.attrs = o.attrs || {}; utag.ut.merge(o.attrs, { "height": "1", "width": "1", "style": "display:none" }, 0); } else if (o.type == "img") { utag.DB("Attach img: " + o.src); b = new Image(); } else { b = a.createElement("script"); b.language = "javascript"; b.type = "text/javascript"; b.async = 1; b.charset = "utf-8"; } if (o.id) { b.id = o.id; } for (l in utag.loader.GV(o.attrs)) { b.setAttribute(l, o.attrs[l]); } b.setAttribute("src", o.src); if (typeof o.cb == "function") { if (b.addEventListener) { b.addEventListener("load", function() { o.cb(); }, false); } else { b.onreadystatechange = function() { if (this.readyState == "complete" || this.readyState == "loaded") { this.onreadystatechange = null; o.cb(); } }; } } if (o.type != "img" && !m) { l = o.loc || "head"; c = a.getElementsByTagName(l)[0]; if (c) { utag.DB("Attach to " + l + ": " + o.src); if (l == "script") { c.parentNode.insertBefore(b, c); } else { c.appendChild(b); } } } }; } else { u.loader = utag.ut.loader; }
    // End Tealium loader
    // Start Tealium typeOf 4.35
    if (utag.ut.typeOf === undefined) { u.typeOf = function(e) {return ({}).toString.call(e).match(/\s([a-zA-Z]+)/)[1].toLowerCase();};} else { u.typeOf = utag.ut.typeOf; }
    // End Tealium typeOf

    u.ev = {"view" : 1, "link": 1};

    u.hasgtagjs = function (){
      window.gtagRename = window.gtagRename || "" || "gtag";
      if (utag.ut.gtagScriptRequested) {
        return true;
      }
      var i, s = document.getElementsByTagName("script");
      for (i = 0; i < s.length; i++) {
        if (s[i].src && s[i].src.indexOf("gtag/js") >= 0) {
          return true;
        }
      }
      window.dataLayer = window.dataLayer || [];
      if ( typeof window[window.gtagRename] !== "function" ) {
        window[window.gtagRename] = function() { dataLayer.push(arguments); };
        window[window.gtagRename]("js", new Date());
      }
      return false;
    };

    u.scriptrequested = u.hasgtagjs();

    u.o = window[window.gtagRename];

    u.map_func = function (arr, obj, item) {
      var i = arr.shift();
      obj[i] = obj[i] || {};
      if (arr.length > 0) {
        u.map_func(arr,obj[i], item);
      } else {
        obj[i] = item;
      }
    };

    u.hasOwn = function (o, a) {
      return o != null && Object.prototype.hasOwnProperty.call(o, a);
    };

    u.isEmptyObject = function (o, a) {
      for (a in o) { if (u.hasOwn(o, a)) {return false;}} return true;
    };

    u.toBoolean = function (val) {
      val = val || "";
      return val === true || val.toLowerCase() === "true" || val.toLowerCase() === "on";
    };

  u.map={"tealium_event:view":"conversion","tealium_event:link":"conversion","doubleclick_src":"advertiser_id","doubleclick_type":"activity_group","doubleclick_cat":"activity","tealium_random":"custom.num","_sm_22_6":"custom.ord","page_location":"custom.u1,custom.u24","organization_business_line":"custom.u2,custom.u20","dom.pathname_3":"custom.u3,custom.u21","product_name":"custom.u4,custom.u22","doubleclick_u5":"custom.u5","page_language":"custom.u6,custom.u25","cp.UVID":"custom.u15","page_type":"custom.u19","user_client_group_code":"custom.u23","page_name":"custom.u26","dom.protocol_domain_pathname":"custom.u27","user_is_logged_in":"custom.u28"};
  u.extend=[function(a,b){
try{b['_sm_22_6']="1";}catch(e){utag.DB(e);}
},
function(a,b,c,d,e,f,g){if(1){d=b['user_is_logged_in'];if(typeof d=='undefined')return;c=[{'false':'0'},{'true':'1'}];var m=false;for(e=0;e<c.length;e++){for(f in c[e]){if(d==f){b['user_is_logged_in']=c[e][f];m=true};};if(m)break};if(!m)b['user_is_logged_in']='0';   }},
function(a,b,c,d,e,f,g){if(1){d=b['organization_business_line'];if(typeof d=='undefined')return;c=[{'retail':'DC-4368908'},{'commercial':'DC-6385531'},{'private':'DC-6363828'}];var m=false;for(e=0;e<c.length;e++){for(f in c[e]){if(d==f){b['doubleclick_src']=c[e][f];m=true};};if(m)break};   }},
function(a,b){ try{ if((b['is_conversion']=='true'&&b['event_name']!='send_doubleclick_floodlights')||(b['is_optimization']=='true'&&b['event_name']!='send_doubleclick_floodlights')){
(function setTypeCatU5(b, uid) {
  /* This function takes the data layer ("b") and checks a list of URL mappings against it. It relies on the "Set
  optimization and conversion points extension" in the "lib-utag-data" library for b.is_optimization and b.is_conversion.
  That means that to implement a new DoubleClick Floodlight on an interaction that is not yet marked as an optimization or
  conversion, you'd need to add a mapping in that extension first.

  The additionalConditions can be used to further restrict the firing of Floodlights on the given pathname. Its keys are data
  layer variables and its values are the condition on which a Floodlight should fire. */

  function Mapping(pathname, additionalConditions, type, cat) {
    this.pathname = pathname;
    this.additionalConditions = additionalConditions;
    this.type = type;
    this.cat = cat;

    this.test = function testMapping(b) {
      if (this.pathname !== b['dom.pathname']) return false;

      if (this.additionalConditions != null) {
        // If a condition is provided...
        return Object.keys(this.additionalConditions).every(function checkAdditionalConditions(key) {
          if (b[key] == null) {
            // ... but the data layer variable doesn't exist, break
            return false;
          } else if (Array.isArray(b[key])) {
            // ... and it's an array, check if one of that array's elements match exactly (e.g. product_name)
            return b[key].some(function checkArrayItem(item) {
              return this.additionalConditions[key] === item;
            }, this);
          } else {
            // ... and it's something other than an array, check if that variable is an exact match
            return this.additionalConditions[key] === b[key];
          }
        }, this);
      }

      return true;
    };
  }

  var optimizationMappings = [
    /* Set the conditions to trigger optimization Floodlights. Mappings take these 4 arguments:

    1. The dom.pathname to match
    2. An object containing key-value-pairs with additional conditions to match*, "undefined" if not applicable
    3. The Activity Group ("type") to use in the Floodlight
    4. The Activity ("cat") to use in the Floodlight

    *Exact match when the value in the data layer variable is a string, "indexOf" match when it's an array (e.g.
    product_name in the Woontool). */

    // SterCK flow
    new Mapping('/portalserver/mijn-abnamro/lenen/lening/persoonlijke-lening/aanvragen.html', undefined, 'lenen', 'len024pr'),
    new Mapping('/portalserver/mijn-abnamro/lenen/lening/persoonlijke-lening/aanvragen_prospect.html', undefined, 'lenen', 'len028pr'),

    // Woontool
    new Mapping('/portalserver/mijn-abnamro/verzekeren/woonverzekeringen/aanvragen.html', undefined, 'verzeker', 'ver001wo'),

    // Medici & Senioren
    new Mapping('/portalserver/mijn-abnamro/betalen/bankrekening-medisch/aanvragen.html', undefined, 'klantgro', 'kla001ba'),
    new Mapping('/portalserver/mijn-abnamro/lenen/medisch-ondernemerskrediet/aanvragen.html', undefined, 'klantgro', 'kla003me'),
    new Mapping('/portalserver/mijn-abnamro/lenen/medisch-krediet/aanvragen.html', undefined, 'klantgro', 'kla005me'),
    new Mapping('/portalserver/mijn-abnamro/zelf-regelen/medici-vrije-beroepen-dga/afspraak_maken.html', undefined, 'klantgro', 'kla007me'),
    new Mapping('/portalserver/mijn-abnamro/advies/erven-schenken-nalaten/afspraak_maken.html', undefined, 'klantgro', 'kla001sc'),
    new Mapping('/portalserver/mijn-abnamro/zelf-regelen/senioren/zorgcoach/afspraak_maken.html', undefined, 'klantgro', 'kla001zo'),

    // Quiz: type student
    new Mapping('/portalserver/mijn-abnamro/studenten/quiz-type-student/checken.html', undefined, 'rem', 'pa001st'),

    // GROW tool (TODO this is incorrect, the form is only embedded on index2.html)
    new Mapping('/nl/prive/betalen/betaalpakketten/studenten-pakket/index.html', {event_name: 'update/info'}, 'betalen', 'bet025st'),
    new Mapping('/nl/prive/betalen/betaalpakketten/studenten-pakket/index1.html', {event_name: 'update/info'}, 'betalen', 'bet025st'),
    new Mapping('/nl/prive/betalen/betaalpakketten/studenten-pakket/index2.html', {event_name: 'update/info'}, 'betalen', 'bet025st'),

    // Jurrien's latest additions
    new Mapping('/portalserver/mijn-abnamro/advies/pensioen/afspraak_maken.html', undefined, 'pensioen', 'pen002af'),
    new Mapping('/portalserver/mijn-abnamro/advies/vermogen/afspraak_maken.html', undefined, 'beleggen', 'bel024ve'),
    new Mapping('/portalserver/mijn-abnamro/sparen/kindertoekomst-spaarrekening/aanvragen.html', undefined, 'sparen', 'spa008ki'),
    new Mapping('/portalserver/mijn-abnamro/beleggen/begeleid-beleggen/aanvragen.html', undefined, 'beleggen', 'bel031be'),
    new Mapping('/portalserver/mijn-abnamro/beleggen/zelf-beleggen/aanvragen.html', undefined, 'beleggen', 'bel026ze'),
    new Mapping('/portalserver/mijn-abnamro/beleggen/zelf-beleggen-plus/aanvragen.html', undefined, 'beleggen', 'bel026ze'),
    new Mapping('/portalserver/mijn-abnamro/beleggen/basis-beleggen/aanvragen.html', undefined, 'beleggen', 'bel026ze'),

    new Mapping('/portalserver/mijn-abnamro/betalen/creditcard/aanvragen.html', {product_name: 'creditcard'}, 'betalen', 'bet016cr'),
    new Mapping('/portalserver/mijn-abnamro/betalen/creditcard/aanvragen.html', {product_name: 'standard'}, 'betalen', 'bet016cr'),
    new Mapping('/portalserver/mijn-abnamro/betalen/creditcard/aanvragen.html', {product_name: 'gold'}, 'betalen', 'bet018go'),
    new Mapping('/portalserver/mijn-abnamro/betalen/creditcard/aanvragen.html', {product_name: 'student'}, 'betalen', 'bet024st'),

    // AN2572 Financieel inzicht
    new Mapping('/portalserver/mijn-abnamro/vermogen/financieel-inzicht/aanvragen.html', undefined, 'klantgro', 'kla001ir'),

    // AN2523 All flows to be migrated to GROW tool
    new Mapping('/nl/prive/themas/schenken/afspraak-maken.html', undefined, 'klantgro', 'kla001sc'),
    new Mapping('/nl/prive/betalen/creditcards/studenten-creditcard/aanvragen.html', undefined, 'klantgro', 'bet024st'),
    new Mapping('/nl/prive/betalen/betaalpakketten/studenten-pakket/aanvragen.html', undefined, 'klantgro', 'bet025st'),
    new Mapping('/nl/prive/lenen/medisch-krediet/aanvragen-tot-50000.html', undefined, 'klantgro', 'parti000'),
    new Mapping('/nl/prive/lenen/medisch-krediet/aanvragen-vanaf-50000.html', undefined, 'klantgro', 'parti0'),
    new Mapping('/nl/prive/verzekeren/studentenverzekering/aanvragen.html', undefined, 'klantgro', 'ver052st'),
    new Mapping('/nl/prive/verzekeren/studentenverzekering/berekenen.html', undefined, 'klantgro', 'ver050st'),
    new Mapping('/nl/prive/speciaal-voor/medici/contact-medici/afspraak-maken.html', undefined, 'klantgro', 'parti002'),
    new Mapping('/nl/prive/speciaal-voor/senioren/zorgcoach/afspraak-maken.html', undefined, 'klantgro', 'kla001zo'),
    new Mapping('/nl/prive/beleggen/afspraak-maken.html', undefined, 'beleggen', 'bel002af'),
    new Mapping('/nl/prive/beleggen/beleggingsvormen/vermogensbeheer/afspraak-maken.html', undefined, 'beleggen', 'bel024ve'),
    new Mapping('/nl/prive/pensioen/afspraak-maken.html', undefined, 'pensioen', 'pen030pe'),
    new Mapping('/prive/hypotheken/advies/afspraak-maken.html', undefined, 'hypothek', 'hyp008hy'),
    new Mapping('/en/personal/mortgage/mortgage-advice/make-appointment.html', undefined, 'hypothek', 'hyp008hy'),
    new Mapping('/prive/advies/hypotheken/kennis-en-ervaringstoets.html', undefined, 'hypothek', 'hyp008hy'),
    new Mapping('/prive/hypotheken/hypotheek-zonder-advies/afspraak-maken.html', undefined, 'hypothek', 'hyp008hy'),
    new Mapping('/en/personal/advice/mortgages/knowledge-and-experience/test.html', undefined, 'hypothek', 'hyp008hy'),
    new Mapping('/prive/lenen/lening/aanvragen.html', undefined, 'lenen', 'len013pe'),
    new Mapping('/nl/prive/betalen/bankrekening-openen/aanvragen.html', undefined, 'betalen', 'bet010st'),
    new Mapping('/nl/prive/betalen/jongerengroeirekening/aanvragen.html', undefined, 'betalen', 'bet020jo'),
    new Mapping('/nl/prive/verzekeren/reisverzekeringen/doorlopende-reisverzekering/aanvragen.html', undefined, 'verzeker', 'ver008dr'),
    new Mapping('/nl/prive/verzekeren/reisverzekeringen/annuleringsverzekering/aanvragen.html', undefined, 'verzeker', 'ver018ko'),
    new Mapping('/nl/prive/verzekeren/woonverzekeringen/kostbaarhedenverzekering/berekenen.html', undefined, 'verzeker', 'ver022ko'),
    new Mapping('/nl/prive/verzekeren/reisverzekeringen/kortlopende-reisverzekering/aanvragen.html', undefined, 'verzeker', 'ver026kr'),
    new Mapping('/nl/prive/verzekeren/overlijdensrisicoverzekering/aanvragen.html', undefined, 'verzeker', 'ver034ov'),
    new Mapping('/nl/prive/verzekeren/woonverzekeringen/laptopverzekering/aanvragen.html', undefined, 'verzeker', 'ver038pc'),
  ];

  var conversionMappings = [
    /* See optimizationMappings for notes on how to fill this list. */

    // SterCK flow
    new Mapping('/portalserver/mijn-abnamro/lenen/lening/persoonlijke-lening/aanvragen.html', {widget_state: 'opel-offer-OK-slider'}, 'lenen', 'len025pr'),
    new Mapping('/portalserver/mijn-abnamro/lenen/lening/persoonlijke-lening/aanvragen.html', {widget_state: 'opel-offer-manual-assessment'}, 'lenen', 'len026pr'),
    new Mapping('/portalserver/mijn-abnamro/lenen/lening/persoonlijke-lening/aanvragen.html', {widget_state: 'opel-offer-decline'}, 'lenen', 'len027pr'),
    new Mapping('/portalserver/mijn-abnamro/lenen/lening/persoonlijke-lening/aanvragen_prospect.html', {widget_state: 'opel-offer-OK-slider'}, 'lenen', 'len029pr'),
    new Mapping('/portalserver/mijn-abnamro/lenen/lening/persoonlijke-lening/aanvragen_prospect.html', {widget_state: 'opel-offer-manual-assessment-prospect'}, 'lenen', 'len030pr'),
    new Mapping('/portalserver/mijn-abnamro/lenen/lening/persoonlijke-lening/aanvragen_prospect.html', {widget_state: 'opel-offer-decline'}, 'lenen', 'len031pr'),

    // Woontool
    new Mapping('/portalserver/mijn-abnamro/verzekeren/woonverzekeringen/aanvragen.html', {product_name: 'Liability Insurance'}, 'verzeker', 'ver002wo'),
    new Mapping('/portalserver/mijn-abnamro/verzekeren/woonverzekeringen/aanvragen.html', {product_name: 'Home Content Insurance'}, 'verzeker', 'ver003wo'),
    new Mapping('/portalserver/mijn-abnamro/verzekeren/woonverzekeringen/aanvragen.html', {product_name: 'Home Insurance'}, 'verzeker', 'ver004wo'),

    // Medici & Senioren
    new Mapping('/portalserver/mijn-abnamro/betalen/bankrekening-medisch/aanvragen.html', undefined, 'klantgro', 'kla002ba'),
    new Mapping('/portalserver/mijn-abnamro/lenen/medisch-ondernemerskrediet/aanvragen.html', undefined, 'klantgro', 'parti00'),
    new Mapping('/portalserver/mijn-abnamro/lenen/medisch-krediet/aanvragen.html', undefined, 'klantgro', 'parti001'),
    new Mapping('/portalserver/mijn-abnamro/zelf-regelen/medici-vrije-beroepen-dga/afspraak_maken.html', undefined, 'klantgro', 'parti003'),
    new Mapping('/portalserver/mijn-abnamro/advies/erven-schenken-nalaten/afspraak_maken.html', undefined, 'klantgro', 'kla002sc'),
    new Mapping('/portalserver/mijn-abnamro/zelf-regelen/senioren/zorgcoach/afspraak_maken.html', undefined, 'klantgro', 'kla002zo'),

    // Quiz: type student
    new Mapping('/nl/prive/speciaal-voor/studenten/bijdehand/bedankt-acteur.html', undefined, 'rem', 'pa002st'),
    new Mapping('/nl/prive/speciaal-voor/studenten/bijdehand/bedankt-avonturier.html', undefined, 'rem', 'pa002st'),
    new Mapping('/nl/prive/speciaal-voor/studenten/bijdehand/bedankt-leider.html', undefined, 'rem', 'pa002st'),
    new Mapping('/nl/prive/speciaal-voor/studenten/bijdehand/bedankt-carrieretijger.html', undefined, 'rem', 'pa002st'),
    new Mapping('/nl/prive/speciaal-voor/studenten/bijdehand/bedankt-levensgenieter.html', undefined, 'rem', 'pa002st'),
    new Mapping('/nl/prive/speciaal-voor/studenten/bijdehand/bedankt-organisator.html', undefined, 'rem', 'pa002st'),
    new Mapping('/nl/prive/speciaal-voor/studenten/bijdehand/bedankt-denker.html', undefined, 'rem', 'pa002st'),
    new Mapping('/nl/prive/speciaal-voor/studenten/bijdehand/bedankt-dromer.html', undefined, 'rem', 'pa002st'),

    // vermogensbeheer
    new Mapping('/nl/prive/beleggen/beleggingsvormen/vermogensbeheer/cmn-bedankt.html', undefined, 'beleggen', 'beleg0'),

    // GROW tool
    new Mapping('/nl/cicd/form-studenten-pakket-aanvragen.html', undefined, 'betalen', 'bet026st'), // TODO Remove when AN-2226 is done
    new Mapping('/nl/prive/betalen/betaalpakketten/studenten-pakket/index.html', undefined, 'betalen', 'bet026st'),
    new Mapping('/nl/prive/betalen/betaalpakketten/studenten-pakket/index2.html', undefined, 'betalen', 'bet026st'),

    // Pensioenaanvulling
    new Mapping('/portalserver/mijn-abnamro/pensioen/pensioenaanvulling-met-variabele-rente/aanvragen.html', undefined, 'pensioen', 'pen040pe'),

    // Jurrien's latest additions
    new Mapping('/portalserver/mijn-abnamro/advies/pensioen/afspraak_maken.html', undefined, 'pensioen', 'pen001af'),
    new Mapping('/portalserver/mijn-abnamro/advies/vermogen/afspraak_maken.html', undefined, 'beleggen', 'bel023ve'),
    new Mapping('/portalserver/mijn-abnamro/sparen/kindertoekomst-spaarrekening/aanvragen.html', undefined, 'sparen', 'spa007ki'),
    new Mapping('/portalserver/mijn-abnamro/beleggen/begeleid-beleggen/aanvragen.html', undefined, 'beleggen', 'bel030be'),
    new Mapping('/portalserver/mijn-abnamro/beleggen/zelf-beleggen/aanvragen.html', undefined, 'beleggen', 'bel025ze'),
    new Mapping('/portalserver/mijn-abnamro/beleggen/zelf-beleggen-plus/aanvragen.html', undefined, 'beleggen', 'bel027ze'),
    new Mapping('/portalserver/mijn-abnamro/beleggen/basis-beleggen/aanvragen.html', undefined, 'beleggen', 'bel025ze'),

    // AN-2532 New conversions lenen
    new Mapping('/portalserver/mijn-abnamro/lenen/contact/afspraak_maken.html', undefined, 'lenen', 'parti0'),
    new Mapping('/portalserver/mijn-abnamro/lenen/maatwerkkrediet/afspraak_maken.html', undefined, 'lenen', 'parti00'),
    new Mapping('/portalserver/mijn-abnamro/hypotheken/orientation-proposition/index.html', undefined, 'lenen', 'parti000'),

    new Mapping('/portalserver/mijn-abnamro/betalen/creditcard/aanvragen.html', {product_name: 'standard'}, 'betalen', 'bet015cr'),
    new Mapping('/portalserver/mijn-abnamro/betalen/creditcard/aanvragen.html', {product_name: 'gold'}, 'betalen', 'bet017go'),
    new Mapping('/portalserver/mijn-abnamro/betalen/creditcard/aanvragen.html', {product_name: 'student'}, 'betalen', 'bet023st'),

    // AN2572 Financieel inzicht
    new Mapping('/portalserver/mijn-abnamro/vermogen/financieel-inzicht/aanvragen.html', undefined, 'klantgro', 'kla002ir'),

    // AN2523 All flows to be migrated to GROW tool
    new Mapping('/nl/prive/themas/schenken/afspraak-maken.html', undefined, 'klantgro', 'kla002sc'),
    new Mapping('/nl/prive/betalen/creditcards/studenten-creditcard/aanvragen.html', undefined, 'klantgro', 'bet023st'),
    new Mapping('/nl/prive/betalen/betaalpakketten/studenten-pakket/aanvragen.html', undefined, 'klantgro', 'bet026st'),
    new Mapping('/nl/prive/lenen/medisch-krediet/aanvragen-tot-50000.html', undefined, 'klantgro', 'parti001'),
    new Mapping('/nl/prive/lenen/medisch-krediet/aanvragen-vanaf-50000.html', undefined, 'klantgro', 'parti00'),
    new Mapping('/nl/prive/verzekeren/studentenverzekering/aanvragen.html', undefined, 'klantgro', 'ver053st'),
    new Mapping('/nl/prive/verzekeren/studentenverzekering/berekenen.html', undefined, 'klantgro', 'ver051st'),
    new Mapping('/nl/prive/speciaal-voor/medici/contact-medici/afspraak-maken.html', undefined, 'klantgro', 'parti003'),
    new Mapping('/nl/prive/speciaal-voor/senioren/zorgcoach/afspraak-maken.html', undefined, 'klantgro', 'kla002zo'),
    new Mapping('/en/personal/contact/make-appointment.html', undefined, 'klantgro', 'exp001co'),
    new Mapping('/nl/prive/beleggen/afspraak-maken.html', undefined, 'beleggen', 'bel001af'),
    new Mapping('/nl/prive/beleggen/beleggingsvormen/vermogensbeheer/afspraak-maken.html', undefined, 'beleggen', 'bel023ve'),
    new Mapping('/nl/prive/pensioen/afspraak-maken.html', undefined, 'pensioen', 'pen029pe'),
    new Mapping('/prive/hypotheken/advies/afspraak-maken.html', undefined, 'hypothek', 'hyp007hy'),
    new Mapping('/en/personal/mortgage/mortgage-advice/make-appointment.html', undefined, 'hypothek', 'hyp007hy'),
    new Mapping('/prive/advies/hypotheken/kennis-en-ervaringstoets.html', undefined, 'hypothek', 'hyp007hy'),
    new Mapping('/prive/hypotheken/hypotheek-zonder-advies/afspraak-maken.html', undefined, 'hypothek', 'hyp007hy'),
    new Mapping('/en/personal/advice/mortgages/knowledge-and-experience/test.html', undefined, 'hypothek', 'hyp007hy'),
    new Mapping('/prive/lenen/lening/aanvragen.html', undefined, 'lenen', 'len012pe'),
    new Mapping('/nl/prive/betalen/bankrekening-openen/aanvragen.html', undefined, 'betalen', 'bet009st'),
    new Mapping('/nl/prive/betalen/jongerengroeirekening/aanvragen.html', undefined, 'betalen', 'bet019jo'),
    new Mapping('/nl/prive/verzekeren/reisverzekeringen/doorlopende-reisverzekering/aanvragen.html', undefined, 'verzeker', 'ver007dr'),
    new Mapping('/nl/prive/verzekeren/reisverzekeringen/annuleringsverzekering/aanvragen.html', undefined, 'verzeker', 'ver017ko'),
    new Mapping('/nl/prive/verzekeren/woonverzekeringen/kostbaarhedenverzekering/berekenen.html', undefined, 'verzeker', 'ver021ko'),
    new Mapping('/nl/prive/verzekeren/reisverzekeringen/kortlopende-reisverzekering/aanvragen.html', undefined, 'verzeker', 'ver025kr'),
    new Mapping('/nl/prive/verzekeren/overlijdensrisicoverzekering/aanvragen.html', undefined, 'verzeker', 'ver033ov'),
    new Mapping('/nl/prive/verzekeren/woonverzekeringen/laptopverzekering/aanvragen.html', undefined, 'verzeker', 'ver037pc'),
  ];

  var matchedMappings = [];

  /* Test all optimization mappings against the current data layer ("b") and store the ones that match. */
  if (b.is_optimization === 'true') {
    var matchedOptimizations = optimizationMappings.filter(function filterOptimization(item) {
      return item.test(b);
    });
    matchedOptimizations.forEach(function addU5(mapping) { mapping.u5 = 'optimalisatie'; })
    matchedMappings = matchedMappings.concat(matchedOptimizations);
  }

  /* Do the same for conversion mappings */
  if (b.is_conversion === 'true') {
    var matchedConversions = conversionMappings.filter(function filterConversion(item) {
      return item.test(b);
    });
    matchedConversions.forEach(function addU5(mapping) { mapping.u5 = 'conversie'; })
    matchedMappings = matchedMappings.concat(matchedConversions);
  }

  /* Set the DoubleClick variables in the data layer to the values of the first matched mapping. */
  if (matchedMappings.length > 0) {
    b.doubleclick_type = matchedMappings[0].type;
    b.doubleclick_cat = matchedMappings[0].cat;
    b.doubleclick_u5 = matchedMappings[0].u5;

    if (matchedMappings.length > 1) {
      /* If more than one Floodlight should fire for this interaction, trigger extra utag.link calls to the DoubleClick tag.
      (Because this extension is scoped to the DoubleClick tag, "uid" will match that tag's UID.) */

      for (var i = 1; i < matchedMappings.length; i++) {
        utag.link(Object.assign(JSON.parse(JSON.stringify(b)), {
          /* Re-use everything that was part of the original utag.view or utag.link call, except for these properties: */
          event_name: 'send_doubleclick_floodlights',
          state_name: undefined, // Overwrite any existing state_name to prevent that from triggering again
          doubleclick_type: matchedMappings[i].type,
          doubleclick_cat: matchedMappings[i].cat,
          doubleclick_u5: matchedMappings[i].u5,
        }), false, [uid]);
      }
    }
  }

  return {
    matchedMappings: matchedMappings,
  };
}(b, u.id));

} } catch(e){ utag.DB(e) }  },
function(a,b){ try{ if(b['dom.pathname']=='/portalserver/mijn-abnamro/betalen/bankrekening-medisch/aanvragen.html'||b['dom.pathname']=='/portalserver/mijn-abnamro/lenen/medisch-ondernemerskrediet/aanvragen.html'||b['dom.pathname']=='/portalserver/mijn-abnamro/lenen/medisch-krediet/aanvragen.html'||b['dom.pathname']=='/portalserver/mijn-abnamro/zelf-regelen/medici-vrije-beroepen-dga/afspraak_maken.html'||b['dom.pathname']=='/portalserver/mijn-abnamro/advies/erven-schenken-nalaten/afspraak_maken.html'||b['dom.pathname']=='/portalserver/mijn-abnamro/zelf-regelen/senioren/zorgcoach/afspraak_maken.html'){b['product_category']='klantgroepen'} } catch(e){ utag.DB(e) }  },
function(a,b){ try{ if(1){try{b['product_name']=(Array.isArray(b.product_name) ? b.product_name.join(";") : b.product_name)}catch(e){}} } catch(e){ utag.DB(e) }  }];


    u.send = function (a, b) {
      if (u.ev[a] || u.ev.all !== undefined) {
        utag.DB("send:22");
        utag.DB(b);

        var c, d, e, f, h, i, j, k, _event, p, key;

        u.data = {
          "qsp_delim" : "&",
          "kvp_delim" : "=",
          "base_url" : "https://www.googletagmanager.com/gtag/js",
          "advertiser_id" : "DC-4368908",
          "activity_group" : "",
          "activity" : "",
          "counting_method" : "unique",
          "fire_purchase" : "false",
          "custom_scripts" :  "true",
          "session_id" : "",
          "product_id" : [],
          "product_quantity" : [],
          "product_unit_price" : [],
          "dc_custom_params" : {},
          "event_name" : "",
          "event" : [],
          "custom" : {}
        };

        // Start tag-scoped extensions
        for(c=0;c<u.extend.length;c++){try{d=u.extend[c](a,b);if(d==false)return}catch(e){if(typeof utag_err!='undefined'){utag_err.push({e:'extension error:'+e,s:utag.cfg.path+'utag.'+id+'.js',l:c,t:'ex'})}}};
        utag.DB("send:22:EXTENSIONS");
        utag.DB(b);
        // End tag-scoped extensions

        // Start Mapping
        for (d in utag.loader.GV(u.map)) {
          if (b[d] !== undefined && b[d] !== "") {
            e = u.map[d].split(",");
            for (f = 0; f < e.length; f++) {
              u.map_func(e[f].split("."), u.data, b[d]);
            }
          } else {
            h = d.split(":");
            if (h.length === 2 && b[h[0]] === h[1]) {
              if (u.map[d]) {
                u.data.event = u.data.event.concat(u.map[d].split(","));
              }
            }
          }
        }
        utag.DB("send:22:MAPPINGS");
        utag.DB(u.data);
        // End Mapping

        // Pull E-Commerce extension values
        // Mappings override E-Commerce extension values
        u.data.order_id = u.data.order_id || b._corder || "";
        u.data.order_total = u.data.order_total || b._ctotal || "";
        if (u.data.product_quantity.length === 0 && b._cquan !== undefined) { u.data.product_quantity = b._cquan.slice(0); }

        if(typeof(u.data.advertiser_id) === "string"){ u.data.advertiser_id = u.data.advertiser_id.split(","); }
        if(typeof(u.data.activity_group) === "string"){ u.data.activity_group = u.data.activity_group.split(","); }
        if(typeof(u.data.activity) === "string"){ u.data.activity = u.data.activity.split(","); }
        if(typeof(u.data.counting_method) === "string"){ u.data.counting_method = u.data.counting_method.split(","); }
        if(typeof(u.data.session_id) === "string"){ u.data.session_id = u.data.session_id.split(","); }
        if (u.data.product_id.length === 0 && b._cprod !== undefined) { u.data.product_id = b._cprod.slice(0); }
        if (u.data.product_quantity.length === 0 && b._cquan !== undefined) { u.data.product_quantity = b._cquan.slice(0); }
        if (u.data.product_unit_price.length === 0 && b._cprice !== undefined) { u.data.product_unit_price = b._cprice.slice(0); }

        // Report required config is missing, and stop tag from firing.
        if (!u.data.advertiser_id) {
          utag.DB(u.id + ": Tag not fired: Required attribute not populated");
          return;
        }

        // Prepend "DC-" Advertiser ID prefix if not present
        for (i = 0; i < u.data.advertiser_id.length; i++) {
          if (!/^[a-zA-Z]{2}-/.test(u.data.advertiser_id[i]) ) {
            u.data.advertiser_id[i] = "DC-" + u.data.advertiser_id[i];
          }
        }

        u.data.base_url += "?id=" + (u.data.advertiser_id[0]);

        for (i = 0; i < u.data.advertiser_id.length; i++) {
          u.o("config", u.data.advertiser_id[i]);
        }
  
        if (u.data.order_id) {
          // p is the flag for a purchase event present in the event list
          for (i = 0; i < u.data.event.length; i++) {
            if (u.data.event[i] === "purchase") {
              p = true;
            }
          }
          if (!p && u.toBoolean(u.data.fire_purchase)) {
            u.data.event.push("purchase");
            // Default to transaction if no counting method set
            if (u.data.counting_method[0] === "") {
              u.data.counting_method[0] = "transactions";
            }
          }
        }
  
        var total_qty = 0;
        if (typeof (u.data.product_quantity) === "number") {
          total_qty = u.data.product_quantity;
        } else if (u.data.product_quantity.length === 1) {
          total_qty = u.data.product_quantity[0];
        } else if (u.data.product_quantity.length > 1) {
          for (i = 0; i < u.data.product_quantity.length; i++) {
            total_qty += parseInt(u.data.product_quantity[i], 10);
          }
        } else {
          total_qty = 1;
        }
  
        for (i = 0; i < u.data.event.length; i++) {
          _event = u.data.event[i];
  
          for (j = 0; j < u.data.advertiser_id.length; j++) {
            var eventIdData = {};
  
            if (u.data.custom_scripts === "true" || u.data.custom_scripts) {
              eventIdData.allow_custom_scripts = true;
            } else if (u.data.custom_scripts === "false" || !u.data.custom_scripts) {
              eventIdData.allow_custom_scripts = false;
            }
  
            if (u.data.session_id.length === 1 && u.data.session_id[0] !== "") {
              eventIdData.session_id = u.data.session_id[0];
            } else if (u.data.session_id[j] !== "") {
              eventIdData.session_id = u.data.session_id[j];
            }
  
            if (u.data.order_total) {
              eventIdData.value = u.data.order_total;
              eventIdData.transaction_id = u.data.order_id;
            }
            if (u.data.product_quantity) {
              eventIdData.quantity = total_qty;
            }

            eventIdData.items = [];

            for (k = 0; k < u.data.product_id.length; k++) {
              if(typeof(u.data.product_unit_price[k]) === "undefined" || typeof(u.data.product_quantity[k]) === "undefined") {
                utag.DB("No matching unit price or quantity for product ID " + u.data.product_id[k]);
              } else {
                eventIdData.items.push({
                  "id":  u.data.product_id[k],
                  "price": u.data.product_unit_price[k],
                  "quantity": u.data.product_quantity[k]
                });
              }
            }
  
            for (key in u.data.custom) {
              eventIdData[key] = u.data.custom[key];
            }
  
  
            if (!u.isEmptyObject(u.data.dc_custom_params)) {
              eventIdData.dc_custom_params = {};
              for (key in u.data.dc_custom_params) {
                eventIdData.dc_custom_params[key] = u.data.dc_custom_params[key];
              }
  
            }

            if (u.data.counting_method[j] && u.data.counting_method[j] !== u.data.counting_method[j].toLowerCase()) {
              u.data.counting_method[j] = u.data.counting_method[j].toLowerCase();
              utag.DB("Counting Method not supplied in proper case - converted to lower case");
            }
  
            eventIdData.send_to = u.data.advertiser_id[j] + "/" + u.data.activity_group[j]  + "/" + u.data.activity[j]  + "+" + u.data.counting_method[j];
            if (_event === "purchase") {
              u.o("event", "purchase", eventIdData);
            }
            if (_event === "conversion") {
              u.o("event", "conversion", eventIdData);
            }
          }
        }

        if (!u.hasgtagjs()) {
          u.scriptrequested = true;
          utag.ut.gtagScriptRequested = true;
          u.loader({
            "type" : "script",
            "src" : u.data.base_url,
            "cb" : null,
            "loc" : "script",
            "id" : "utag_22",
            "attrs" : {}
          });
        }

        utag.DB("send:22:COMPLETE");
      }
    };
    utag.o[loader].loader.LOAD(id);
  }("22", "abn-amro.retail"));
} catch (error) {
  utag.DB(error);
}
//end tealium universal tag
