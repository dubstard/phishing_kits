  //~~tv:20064.20190307
  //~~tc: adding in __cmp fallback check for IAB compliance
  //~~tc: update to allow sending data to multiple server endpoints when enrichment frequency is set to none

  /**
   * Customized for ABN-AMRO to allow sending to the Collect API endpoint (avoids TAPID cookie creation, 
   * which allows household splitting by resetting the v_id when a new login is seen).
   */

  //ESLint configurations
  /*global utag tealium_enrichment __cmp*/
  /*eslint no-unused-vars: ["error",{"varsIgnorePattern": "^c$"}]*/

  /*eslint-disable*/
  /* Modified copy of json2.js (no need for parse function)*/
  /* https://github.com/douglascrockford/JSON-js */
  if(typeof JSON!=='object'){JSON={};}
  (function(){'use strict';var rx_one=/^[\],:{}\s]*$/,rx_two=/\\(?:["\\\/bfnrt]|u[0-9a-fA-F]{4})/g,rx_three=/"[^"\\\n\r]*"|true|false|null|-?\d+(?:\.\d*)?(?:[eE][+\-]?\d+)?/g,rx_four=/(?:^|:|,)(?:\s*\[)+/g,rx_escapable=/[\\\"\u0000-\u001f\u007f-\u009f\u00ad\u0600-\u0604\u070f\u17b4\u17b5\u200c-\u200f\u2028-\u202f\u2060-\u206f\ufeff\ufff0-\uffff]/g,rx_dangerous=/[\u0000\u00ad\u0600-\u0604\u070f\u17b4\u17b5\u200c-\u200f\u2028-\u202f\u2060-\u206f\ufeff\ufff0-\uffff]/g;function f(n){return n<10?'0'+n:n;}
  function this_value(){return this.valueOf();}
  if(typeof Date.prototype.toJSON!=='function'){Date.prototype.toJSON=function(){return isFinite(this.valueOf())?this.getUTCFullYear()+'-'+
  f(this.getUTCMonth()+1)+'-'+ f(this.getUTCDate())+'T'+ f(this.getUTCHours())+':'+ f(this.getUTCMinutes())+':'+
  f(this.getUTCSeconds())+'Z':null;};Boolean.prototype.toJSON=this_value;Number.prototype.toJSON=this_value;String.prototype.toJSON=this_value;}
  var gap,indent,meta,rep;function quote(string){rx_escapable.lastIndex=0;return rx_escapable.test(string)?'"'+string.replace(rx_escapable,function(a){var c=meta[a];return typeof c==='string'?c:'\\u'+('0000'+a.charCodeAt(0).toString(16)).slice(-4);})+'"':'"'+string+'"';}
  function str(key,holder){var i,k,v,length,mind=gap,partial,value=holder[key];if(value&&typeof value==='object'&&typeof value.toJSON==='function'){value=value.toJSON(key);}
  if(typeof rep==='function'){value=rep.call(holder,key,value);}
  switch(typeof value){case'string':return quote(value);case'number':return isFinite(value)?String(value):'null';case'boolean':case'null':return String(value);case'object':if(!value){return'null';}
  gap+=indent;partial=[];if(Object.prototype.toString.apply(value)==='[object Array]'){length=value.length;for(i=0;i<length;i+=1){partial[i]=str(i,value)||'null';}
  v=partial.length===0?'[]':gap?'[\n'+gap+partial.join(',\n'+gap)+'\n'+mind+']':'['+partial.join(',')+']';gap=mind;return v;}
  if(rep&&typeof rep==='object'){length=rep.length;for(i=0;i<length;i+=1){if(typeof rep[i]==='string'){k=rep[i];v=str(k,value);if(v){partial.push(quote(k)+(gap?': ':':')+v);}}}}else{for(k in value){if(Object.prototype.hasOwnProperty.call(value,k)){v=str(k,value);if(v){partial.push(quote(k)+(gap?': ':':')+v);}}}}
  v=partial.length===0?'{}':gap?'{\n'+gap+partial.join(',\n'+gap)+'\n'+mind+'}':'{'+partial.join(',')+'}';gap=mind;return v;}}
  if(typeof JSON.stringify!=='function'){meta={'\b':'\\b','\t':'\\t','\n':'\\n','\f':'\\f','\r':'\\r','"':'\\"','\\':'\\\\'};JSON.stringify=function(value,replacer,space){var i;gap='';indent='';if(typeof space==='number'){for(i=0;i<space;i+=1){indent+=' ';}
  }else if(typeof space==='string'){indent=space;}
  rep=replacer;if(replacer&&typeof replacer!=='function'&&(typeof replacer!=='object'||typeof replacer.length!=='number')){throw new Error('JSON.stringify');}
  return str('',{'':value});};}}());
  /*eslint-enable*/


  //tealium universal tag - utag.sender.20064 ut4.0.201910021213, Copyright 2019 Tealium.com Inc. All Rights Reserved.
  try{
  (function(id,loader,u){
    try{u=utag.o[loader].sender[id]={};}catch(e){u=utag.sender[id];}
    u.ev={"all":1};
    u.server_domain = "tealiumiq.com";
    u.server_prefix = "";
    u.tag_config_server = "";
    u.tag_config_sampling = "100" || "100";
    // In debug mode, always in sample group
    if (utag.cfg.utagdb) {
      u.tag_config_sampling = "100";
    }
    u.tag_config_region = "eu-central-1" || "default";
    u.region = "";
    u.performance_timing_count = 0;
    u.account = utag.cfg.utid.split("/")[0];
    u.data_source = "(set by extension)";
    u.profile = "(set by extension)" || utag.cfg.utid.split("/")[1];

    // Handle VPC custom-collect.tealiumiq.com data collection endpoint
    if (u.tag_config_server.indexOf("-collect." + u.server_domain) > 1) {
      u.server_prefix = u.tag_config_server.split("collect." + u.server_domain)[0];
      if (u.tag_config_server.indexOf("/i.gif") < 0 ) {
        u.tag_config_server = "https://" + [u.server_prefix + "collect." + u.server_domain, u.account, u.profile, "2", "i.gif"].join("/");
      }
    }

    // Auto-build the endpoint for Tealium Collect
    if (u.tag_config_server === "") {
      if (u.tag_config_region === "default") {
        u.tag_config_server = "https://" + [u.server_prefix + "collect." + u.server_domain, u.account, u.profile, "2", "i.gif"].join("/");
      } else {
        u.tag_config_server = "https://" + [u.server_prefix + "collect-" + u.tag_config_region + "." + u.server_domain, u.account, u.profile, "2", "i.gif"].join("/");
      }
    }

    // build endpoint if it contains "-collect-"
    if (u.tag_config_server.indexOf("-collect-") > -1) {
      u.server_prefix = u.tag_config_server.split("collect-")[0];
    }

    // For those who fill out collect.tealiumiq.com and then choose a specific region
    if (u.tag_config_region !== "default" && u.tag_config_server.indexOf(u.server_prefix + "collect." + u.server_domain) > 0) {
      u.tag_config_server = u.tag_config_server.replace(u.server_prefix + "collect." + u.server_domain, u.server_prefix + "collect-" + u.tag_config_region + "." + u.server_domain);
      u.region = u.tag_config_region;
    }

    u.data_enrichment="frequent";
    u.profile_specific_vid = 0;
    u.enrichment_polling = 1;
    u.enrichment_polling_delay = 500;

    u.do_enrichment = function(){};

    var q = u.tag_config_server.indexOf("?");
    if (q>0 && (q+1)==u.tag_config_server.length) {
      // utag.DB("DataCloud config error. Trailing ? in URL")
      u.tag_config_server = u.tag_config_server.replace("?","");
    }
    u.server_list = u.tag_config_server.split("|");
    u.enrichment_enabled = {};
    u.get_account_profile = function(s) {
      var p = s.substring(s.indexOf(u.server_domain)).split("/");
      return p;
    };

    // Should only call this function when u.tag_config_sampling < 100
    u.is_in_sample_group = function(b) {
      var group = "100";

      // Automatically in sampling group if the sampling value is 100% or not defined at all
      if (u.tag_config_sampling === "" || u.tag_config_sampling === "100") {
        return true;
      } 

      // Check or set cookie (cookie should survive across visits)
      if (b["cp.utag_main_dc_group"]) {
        group = b["cp.utag_main_dc_group"];
      } else {
        // group = random number 1..100
        group = Math.floor(Math.random() * 100) + 1;
        // set cookie
        utag.loader.SC("utag_main", {"dc_group": group});
      }

      // Return true if this visitor in sampling group
      if (parseInt(group) <= parseInt(u.tag_config_sampling)) {
        return true;
      } else {
        return false;
      }

    };

    // Server list override, use /event endpoint to avoid setting TAPID cookie (allows household splitting)
    u.server_list = ["https://collect.tealiumiq.com/event"];
    

    u.get_performance_timing = function(b) {
      var t, timing;
      var data = {};

      function subtract(val1, val2) {
        var difference = 0;
        if ( val1 > val2 ) {
          difference = val1 - val2;
        }
        return difference;
      }

      if (typeof localStorage != "undefined" && JSON.parse && window.performance && window.performance.timing) {
        t = window.performance.timing;
        // Read existing local storage data and add to data layer
        timing = localStorage.getItem("tealium_timing");
        // Only get this info on the first event for this page
        if (timing !== null && timing !== "{}" && typeof b !== "undefined" && u.performance_timing_count === 0) {
          utag.ut.merge(b, utag.ut.flatten({timing : JSON.parse(timing)}), 1);
        }
      } else {
        return;
      }

      // Get current URL timing data into local storage.  Or setTimeout and do recursive call if data not there yet
      u.performance_timing_count++;
      for (var k in t) {
        // Some data might not be ready yet, wait and request again
        // Only try 20 times max
        if ((k.indexOf("dom") === 0 || k.indexOf("load") === 0) && t[k] === 0 && u.performance_timing_count < 20) {
          setTimeout(u.get_performance_timing, 1000);
        }
      }

      // Write current page performance data to local storage for retrieval on next page
      data["domain"] = location.hostname + "";
      data["pathname"] = location.pathname + "";
      data["query_string"] = ("" + location.search).substring(1);
      data["timestamp"] = (new Date()).getTime();
      data["dns"] = subtract(t.domainLookupEnd, t.domainLookupStart);
      data["connect"] = subtract(t.connectEnd, t.connectStart);
      data["response"] = subtract(t.responseEnd, t.responseStart);
      data["dom_loading_to_interactive"] = subtract(t.domInteractive, t.domLoading);
      data["dom_interactive_to_complete"] = subtract(t.domComplete, t.domInteractive);
      data["load"] = subtract(t.loadEventEnd, t.loadEventStart);
      data["time_to_first_byte"] = subtract(t.responseStart, t.connectEnd);
      data["front_end"] = subtract(t.loadEventStart, t.responseEnd);
      data["fetch_to_response"] = subtract(t.responseStart, t.fetchStart);
      data["fetch_to_complete"] = subtract(t.domComplete, t.fetchStart);
      data["fetch_to_interactive"] = subtract(t.domInteractive, t.fetchStart);

      try {
        localStorage.setItem("tealium_timing", JSON.stringify(data));
      } catch(e){utag.DB(e);}

    };

      u.map={};
  u.extend=[function(a,b){ try{ if((typeof b['qp.tealium_use_udh_sandbox_profile']!='undefined'&&b['qp.tealium_use_udh_sandbox_profile']!=''&&b['qp.tealium_use_udh_sandbox_profile'].toString().toLowerCase()=='true'.toLowerCase())||(typeof b['qp.tealium_use_udh_sandbox_profile']!='undefined'&&b['qp.tealium_use_udh_sandbox_profile']!=''&&b['qp.tealium_use_udh_sandbox_profile'].toString().toLowerCase()=='false'.toLowerCase())){utag.loader.SC('utag_main',{'use_udh_sandbox_profile':b['qp.tealium_use_udh_sandbox_profile']+';exp-session'});b['cp.utag_main_use_udh_sandbox_profile']=b['qp.tealium_use_udh_sandbox_profile'];}} catch(e){ utag.DB(e) } },
function(a,b){ try{ if((typeof b['qp.tealium_use_real_bc_for_testing']!='undefined'&&b['qp.tealium_use_real_bc_for_testing']!=''&&b['qp.tealium_use_real_bc_for_testing'].toString().toLowerCase()=='true'.toLowerCase())||(typeof b['qp.tealium_use_real_bc_for_testing']!='undefined'&&b['qp.tealium_use_real_bc_for_testing']!=''&&b['qp.tealium_use_real_bc_for_testing'].toString().toLowerCase()=='false'.toLowerCase())){utag.loader.SC('utag_main',{'use_real_bc_for_testing':b['qp.tealium_use_real_bc_for_testing']+';exp-session'});b['cp.utag_main_use_real_bc_for_testing']=b['qp.tealium_use_real_bc_for_testing'];}} catch(e){ utag.DB(e) } },
function(a,b){ try{ if(1){
/**
 *  Scope       : Tealium Collect
 *  Execution   : n/a
 *  Condition   : n/a
 *  Description : Remove any UDO attribute that has the value 'not set' - if it's 'not set',
 *                we want to _actually_ not be set.
 *                
 */

(function(){
    function removeNotSet(item, index, arr) {
        // Remove these variables from the data layer before the Collect tag sends all information in the data layer to AudienceStream's servers:
        if (b[item] === "not set") {
            delete b[item];
        }
    }

    Object.keys(b).forEach(removeNotSet);
})();
} } catch(e){ utag.DB(e) }  },
function(a,b){/*
CryptoJS v3.1.2
code.google.com/p/crypto-js
(c) 2009-2013 by Jeff Mott. All rights reserved.
code.google.com/p/crypto-js/wiki/License
*/
utag.ut.sha256 = function(h,s){var f={},t=f.lib={},g=function(){},j=t.Base={extend:function(a){g.prototype=this;var c=new g;a&&c.mixIn(a);c.hasOwnProperty("init")||(c.init=function(){c.$super.init.apply(this,arguments)});c.init.prototype=c;c.$super=this;return c},create:function(){var a=this.extend();a.init.apply(a,arguments);return a},init:function(){},mixIn:function(a){for(var c in a)a.hasOwnProperty(c)&&(this[c]=a[c]);a.hasOwnProperty("toString")&&(this.toString=a.toString)},clone:function(){return this.init.prototype.extend(this)}},q=t.WordArray=j.extend({init:function(a,c){a=this.words=a||[];this.sigBytes=c!=s?c:4*a.length},toString:function(a){return(a||u).stringify(this)},concat:function(a){var c=this.words,d=a.words,b=this.sigBytes;a=a.sigBytes;this.clamp();if(b%4)for(var e=0;e<a;e++)c[b+e>>>2]|=(d[e>>>2]>>>24-8*(e%4)&255)<<24-8*((b+e)%4);else if(65535<d.length)for(e=0;e<a;e+=4)c[b+e>>>2]=d[e>>>2];else c.push.apply(c,d);this.sigBytes+=a;return this},clamp:function(){var a=this.words,c=this.sigBytes;a[c>>>2]&=4294967295<<32-8*(c%4);a.length=h.ceil(c/4)},clone:function(){var a=j.clone.call(this);a.words=this.words.slice(0);return a},random:function(a){for(var c=[],d=0;d<a;d+=4)c.push(4294967296*h.random()|0);return new q.init(c,a)}}),v=f.enc={},u=v.Hex={stringify:function(a){var c=a.words;a=a.sigBytes;for(var d=[],b=0;b<a;b++){var e=c[b>>>2]>>>24-8*(b%4)&255;d.push((e>>>4).toString(16));d.push((e&15).toString(16))}return d.join("")},parse:function(a){for(var c=a.length,d=[],b=0;b<c;b+=2)d[b>>>3]|=parseInt(a.substr(b,2),16)<<24-4*(b%8);return new q.init(d,c/2)}},k=v.Latin1={stringify:function(a){var c=a.words;a=a.sigBytes;for(var d=[],b=0;b<a;b++)d.push(String.fromCharCode(c[b>>>2]>>>24-8*(b%4)&255));return d.join("")},parse:function(a){for(var c=a.length,d=[],b=0;b<c;b++)d[b>>>2]|=(a.charCodeAt(b)&255)<<24-8*(b%4);return new q.init(d,c)}},l=v.Utf8={stringify:function(a){try{return decodeURIComponent(escape(k.stringify(a)))}catch(c){throw Error("Malformed UTF-8 data");}},parse:function(a){return k.parse(unescape(encodeURIComponent(a)))}},x=t.BufferedBlockAlgorithm=j.extend({reset:function(){this._data=new q.init;this._nDataBytes=0},_append:function(a){"string"==typeof a&&(a=l.parse(a));this._data.concat(a);this._nDataBytes+=a.sigBytes},_process:function(a){var c=this._data,d=c.words,b=c.sigBytes,e=this.blockSize,f=b/(4*e),f=a?h.ceil(f):h.max((f|0)-this._minBufferSize,0);a=f*e;b=h.min(4*a,b);if(a){for(var m=0;m<a;m+=e)this._doProcessBlock(d,m);m=d.splice(0,a);c.sigBytes-=b}return new q.init(m,b)},clone:function(){var a=j.clone.call(this);a._data=this._data.clone();return a},_minBufferSize:0});t.Hasher=x.extend({cfg:j.extend(),init:function(a){this.cfg=this.cfg.extend(a);this.reset()},reset:function(){x.reset.call(this);this._doReset()},update:function(a){this._append(a);this._process();return this},finalize:function(a){a&&this._append(a);return this._doFinalize()},blockSize:16,_createHelper:function(a){return function(c,d){return(new a.init(d)).finalize(c)}},_createHmacHelper:function(a){return function(c,d){return(new w.HMAC.init(a,d)).finalize(c)}}});var w=f.algo={};return f}(Math);(function(h){for(var s=utag.ut.sha256,f=s.lib,t=f.WordArray,g=f.Hasher,f=s.algo,j=[],q=[],v=function(a){return 4294967296*(a-(a|0))|0},u=2,k=0;64>k;){var l;a:{l=u;for(var x=h.sqrt(l),w=2;w<=x;w++)if(!(l%w)){l=!1;break a}l=!0}l&&(8>k&&(j[k]=v(h.pow(u,0.5))),q[k]=v(h.pow(u,1/3)),k++);u++}var a=[],f=f.SHA256=g.extend({_doReset:function(){this._hash=new t.init(j.slice(0))},_doProcessBlock:function(c,d){for(var b=this._hash.words,e=b[0],f=b[1],m=b[2],h=b[3],p=b[4],j=b[5],k=b[6],l=b[7],n=0;64>n;n++){if(16>n)a[n]=c[d+n]|0;else{var r=a[n-15],g=a[n-2];a[n]=((r<<25|r>>>7)^(r<<14|r>>>18)^r>>>3)+a[n-7]+((g<<15|g>>>17)^(g<<13|g>>>19)^g>>>10)+a[n-16]}r=l+((p<<26|p>>>6)^(p<<21|p>>>11)^(p<<7|p>>>25))+(p&j^~p&k)+q[n]+a[n];g=((e<<30|e>>>2)^(e<<19|e>>>13)^(e<<10|e>>>22))+(e&f^e&m^f&m);l=k;k=j;j=p;p=h+r|0;h=m;m=f;f=e;e=r+g|0}b[0]=b[0]+e|0;b[1]=b[1]+f|0;b[2]=b[2]+m|0;b[3]=b[3]+h|0;b[4]=b[4]+p|0;b[5]=b[5]+j|0;b[6]=b[6]+k|0;b[7]=b[7]+l|0},_doFinalize:function(){var a=this._data,d=a.words,b=8*this._nDataBytes,e=8*a.sigBytes;d[e>>>5]|=128<<24-e%32;d[(e+64>>>9<<4)+14]=h.floor(b/4294967296);d[(e+64>>>9<<4)+15]=b;a.sigBytes=4*d.length;this._process();return this._hash},clone:function(){var a=g.clone.call(this);a._hash=this._hash.clone();return a}});s.SHA256=g._createHelper(f);s.HmacSHA256=g._createHmacHelper(f)})(Math);try { if (typeof b['user_bc_number'] != 'undefined' && b['user_bc_number'] != '') {b['user_bc_number']=utag.ut.sha256.SHA256(b['user_bc_number']).toString();} }catch(e){};try { if (typeof b['cp.LastBCNumber'] != 'undefined' && b['cp.LastBCNumber'] != '') {b['cp.LastBCNumber']=utag.ut.sha256.SHA256(b['cp.LastBCNumber']).toString();} }catch(e){}}
,
function(a,b){ try{ if(1){
/**
 *  Scope       : Tealium Collect
 *  Execution   : n/a
 *  Condition   : n/a
 *  Description : Adds a prefix to BC Numbers from Dev/QA environments - ABN uses real customer
 *                numbers as log-ins, so we need to avoid polluting any real Visitor Profiles
 *                with test data.
 * 
 *                Use 'tealum_use_real_bc_for_testing=true' (and ...=false) to control. 
 *                That parameter sets a session-length cookie (as defined by TiQ).
 *                
 */
 

var testCookie = "cp.utag_main_use_real_bc_for_testing";
var prefix = "test-";

var isOnProd = (typeof b.tealium_environment === "string" && b.tealium_environment.toLowerCase() === "prod");
var isTestCookieSet = (typeof b[testCookie] === "string" && b[testCookie].toLowerCase() === "true");

// don't add the prefix if the value is undefined, helper function since we need it twice
function addPrefix(udoVar, prefix) {
    if (typeof b[udoVar] === "string" && b[udoVar] !== "") {
        // don't prefix twice
        if (b[udoVar].indexOf(prefix) !== 0) {
            b[udoVar] = prefix + b[udoVar];
        }
        // return true even if already prefixed because we would've prefixed i (we ensure it's prefixed here)
        return true;
    }
    return false;
}

// add the prefix if on a non-production environment with no override
if (isOnProd === false && isTestCookieSet === false) {
    var bc = addPrefix("user_bc_number", prefix);
    var cookie = addPrefix("cp.LastBCNumber", prefix);
    var anotherCookie = addPrefix("cp.utag_main_last_bc", prefix)
    // only log about prefixing if we actually prefixed something
    if (bc === true || cookie === true || anotherCookie === true) {
        console.log("Prefixed Hashed BC Number (and cookie) before Collect to avoid possible data pollution.");
        console.log("Use ?tealium_use_real_bc_for_testing=true (add to querystring) to override if needed");
    }
}


} } catch(e){ utag.DB(e) }  },
function(a,b){ try{ if(1){
/**
 *  Scope       : Tealium Collect (/events endpoint)
 *  Execution   : n/a
 *  Condition   : n/a
 *  Description : Add support for multiple users on the device.
 *                Works by assuming a new user when we see a new login-based ID and reseting the cookie-based
 *                v_id.  
 *                ONLY works if you use the /events endpoint (otherwise the first-seen ID is persisted in a
 *                third-party cookie).
 */

var parentCookieName = "utag_main";
var subcookieName = "last_bc";
var primaryCookieAttributeString = "cp." + parentCookieName + "_" + subcookieName;

var primaryLoginAttributeName = "user_bc_number";

var persistedPrimary = b[primaryCookieAttributeString];
var currentPrimary = b[primaryLoginAttributeName];
var currentVID = b["cp.utag_main_v_id"];

var trackingObject = {};

var log = function(label, value) {
    // no logging output unless on Dev or QA or logging is explicitly active
    if ((b["tealium_environment"] === "dev" || b["tealium_environment"] === "qa") || b["cp.utagdb"] === "true") {
        while (label.length < 30) {
          label = label + " ";
        }
        console.log(label + ": " + value);
    }
}


// check if the current login is the same as the past one we've seen (if any)
var loginChanged = (persistedPrimary && currentPrimary && currentPrimary !== "" && currentPrimary !== persistedPrimary);

// login is different, so reset the device-based cookie value to "create a new device" 
// from the perspective of the UDH
if (loginChanged) {
    log("Previous login", persistedPrimary);
    log("Current login", currentPrimary);
    log("Previous v_id", currentVID);
    
    // generate a new utag_main_v_id
    utag.v_id = undefined; // clear out any cached VID (important for utag.ut.vi to work as expected)
    var newVID = utag.ut.vi((new Date()).getTime()); // generate a new VID
    
    // update the cookie and dataLayer (and caches) with the new v_id
    utag.v_id = newVID;
    trackingObject["v_id"] = newVID;
    utag.loader.SC("utag_main", trackingObject);
    b["cp.utag_main_v_id"] = newVID; // replace the previously read cookie value with updated one
    b["tealium_visitor_id"] = newVID; // same as above
    utag.ut.visitor_id = newVID;
    b["ut.visitor_id"] = newVID; // also update the previously-read value
    
    log("Current v_id", newVID);
    log("Current utag_main_v_id", b["cp.utag_main_v_id"]);
    log("Current tealium_visitor_id", b["tealium_visitor_id"]);
} else {
    log("Current v_id", currentVID);
    log("Current login", (currentPrimary || persistedPrimary));
}

// persist any seen customer IDs, after checking for changes
if (currentPrimary && currentPrimary !== "") {
    log("Persisted login ", currentPrimary);
    // update the cookie with the new customer number
    trackingObject = {}; // reset in case it changed before
    trackingObject[subcookieName] = currentPrimary;
    utag.loader.SC(parentCookieName, trackingObject);
    b[primaryCookieAttributeString] = currentPrimary;
}

} } catch(e){ utag.DB(e) }  },
function(a,b){ try{ if(1){
/**
 *  Scope       : Tealium Collect
 *  Execution   : n/a
 *  Condition   : n/a
 *  Description : Remove non-hashed BC numbers from the UDO for the Collect tag.  Modified version of 
 *                Harm's code to make it IE-safe and readable at the same time.
 *                
 */

(function(){
    function removePii(item, index, arr) {
        // Remove these variables from the data layer before the Collect tag sends all information in the data layer to AudienceStream's servers:
        var variablesToRemove = [
            "bc_number",
            "bcNumber",
            // "user_bc_number", // we need this one for now at least, it will be hashed
            "s_sess",
            "js_page.window.sessionStorage.tempRepresentative",
            "_tracking_data",
            "_widget_data"
        ];

        if (variablesToRemove.indexOf(item) !== -1) {
            delete b[item];
        }
    }

    Object.keys(b).forEach(removePii);
})();
} } catch(e){ utag.DB(e) }  },
function(a,b){ try{ if(1){
/**
 *  Scope       : Tealium Collect
 *  Execution   : n/a
 *  Condition   : n/a
 *  Description : Add a couple fixes and optimizations to the Collect tag
 */

// copy the dom.url to make it accessible in the UDH (workaround for dom.url limitation currently)
// the 'Current URL' in the UDH is the referrer from which we recieved the request, NOT the dom.url value
// that the Collect tag gathers.  Referer isn't reliable (especially with ITP 2), so we use this workaround.
b.dom_url_full = b["dom.url"];

// we don't need this timing feature for now, let's gut the function since it involved polling, etc.
u.get_performance_timing = function(b){};


} } catch(e){ utag.DB(e) }  },
function(a,b){ try{ if(1){
/**
 *  Scope       : Tealium Collect
 *  Execution   : n/a
 *  Condition   : n/a
 *  Description : Allow internal testers to use the 'udh-sandbox' UDH profile for testing outside
 *                of the production profile as needed. Most testing won't need to do this.  
 *               
 *                Using ?tealium_use_udh_sandbox_profile=true will activate the session cookie to
 *                redirect traffice, and ?tealium_use_udh_sandbox_profile=false will deactivate it.
 * 
 *                udh-production is in Germany
 *                udh-sandbox is in Ireland
 *                Using distinct regions avoids cookie collisions/reservation issues.
 */

// default values for most users (use production)
b.tealium_datasource = "anuqyp";
b.tealium_profile = "udh-production";

// use the sandbox for internal users who want to do extreme testing in a separate profile
var test_cookie = "cp.utag_main_use_udh_sandbox_profile";
if (typeof b[test_cookie] === "string" && b[test_cookie].toLowerCase() === "true") {
    b.tealium_datasource = "ftw49w";
    b.tealium_profile = "udh-sandbox";
}

// log to console in non-production settings to help debugging
if ((b["tealium_environment"] === "dev" || b["tealium_environment"] === "qa") || b["cp.utagdb"] === "true") {
    console.log("Using UDH profile '" + b.tealium_profile + "'");
}
} } catch(e){ utag.DB(e) }  }];

    
    u.send = function(a,b) {
      var c, d, i;
      if(u.ev[a] || typeof u.ev["all"] !== "undefined"){
        //Don't fire for tag bridge event "remote_api"
        if (a === "remote_api") {
          utag.DB("Remote API event suppressed.");
          return;
        }

        //this is a fallback check for IAB compliance; if IAB does not apply, then this tag will execute normally, otherwise consent settings are respected
        if (typeof __cmp === "function") {
          // eslint-disable-next-line no-unused-vars
          __cmp("getVendorConsents", [522], function(consents, is_successful) {
            var consented_to_tealium = consents.vendorConsents[522];
            var consented_to_purposes = consents.purposeConsents[2] && consents.purposeConsents[3] && consents.purposeConsents[5];
            if (consented_to_tealium && consented_to_purposes) {
              execute_send();
            } else {
              utag.DB("Detected that consent was not granted for Tealium and/or its listed purposes. Aborting Tealium Collect.");
            }
          });
        } else {
          execute_send();
        }

        function execute_send() {
          // Set data source
          if (u.data_source) {
            b.tealium_datasource = u.data_source;
          }

          u.make_enrichment_request = false;

        try {if (utag.gdpr.consent_prompt.isEnabled || utag.gdpr.getConsentState()) {b["consent_categories"] = utag.gdpr.getSelectedCategories();b["policy"] = "gdpr";}} catch(e) {utag.DB(e)}for(c=0;c<u.extend.length;c++){try{d=u.extend[c](a,b);if(d==false)return}catch(e){if(typeof utag_err!='undefined'){utag_err.push({e:'extension error:'+e,s:utag.cfg.path+'utag.'+id+'.js',l:c,t:'ex'})}}};

          // If not in our sampling group, then exit (do not fire tag)
          if (!u.is_in_sample_group(b)) {
            return false;
          }
          u.get_performance_timing(b);

          for (i = 0; i < u.server_list.length; i++) {
            if (u.enrichment_enabled[i] !== false) {
              u.enrichment_enabled[u.server_list[i]] = true;
            }
          }

          // For multiple server locations, need unique vid values for each
          if (u.server_list.length > 1) {
            u.profile_specific_vid = 1;
          }
          u.data = utag.datacloud || {};

          u.data["loader.cfg"] = {};
          for (d in utag.loader.GV(utag.loader.cfg)){
            if (utag.loader.cfg[d].load && utag.loader.cfg[d].send){
              utag.loader.cfg[d].executed = 1;
            } else {
              utag.loader.cfg[d].executed = 0;
            }
            u.data["loader.cfg"][d]=utag.loader.GV(utag.loader.cfg[d]);
          }

          //u.data.cfg=utag.cfg;
          u.data.data=b;
          /* Re-encode items in "qp." params */
          for (d in u.data.data) {
            if ((d+'').indexOf("qp.") === 0) {
              u.data.data[d] = encodeURIComponent(u.data.data[d]);
            } else if ((d+'').indexOf("va.") === 0) {
              /* Remove visitor attributes */
              delete u.data.data[d];
            }
          }

          /* Visit Number and Event Count -- event count starts over with each visit */
          if (!b["cp.utag_main_dc_event"]) {
            b["cp.utag_main_dc_visit"] = (1 + (b["cp.utag_main_dc_visit"] ? parseInt(b["cp.utag_main_dc_visit"]) : 0)) + '';
          }
          b["cp.utag_main_dc_event"] = (1 + (b["cp.utag_main_dc_event"] ? parseInt(b["cp.utag_main_dc_event"]) : 0)) + '';
          utag.loader.SC("utag_main", {"dc_visit" : b["cp.utag_main_dc_visit"], "dc_event" : b["cp.utag_main_dc_event"] + ";exp-session"});

          /* Update global data layer for Visitor Attribute check */
          utag.data["cp.utag_main_dc_visit"] = b["cp.utag_main_dc_visit"];
          utag.data["cp.utag_main_dc_event"] = b["cp.utag_main_dc_event"];

          var dt = new Date();
          /* Send browser info */
          u.data.browser = {};
          try {
            u.data.browser["height"] = window.innerHeight || document.body.clientHeight;
            u.data.browser["width"] = window.innerWidth || document.body.clientWidth;
            u.data.browser["screen_height"] = screen.height;
            u.data.browser["screen_width"] = screen.width;
            u.data.browser["timezone_offset"] = dt.getTimezoneOffset();
          } catch (e) {
            utag.DB(e);
          }

          u.data["event"] = a + '';
          u.data["post_time"] = dt.getTime();

          /* Audience Stream Data Layer Enrichment */
          if (u.data_enrichment === "frequent" || u.data_enrichment === "infrequent") {

            u.visit_num = b["cp.utag_main_dc_visit"];

            if (parseInt(u.visit_num) > 1 && b["cp.utag_main_dc_event"] === "1") {
              u.enrichment_polling = 2;
            }

            try {
              u.va_update = parseInt(localStorage.getItem("tealium_va_update") || 0);
            } catch (e) {
              utag.DB(e);
            }

            u.visitor_id = u.visitor_id || b.tealium_visitor_id || b['cp.utag_main_v_id'];
            if (u.data_enrichment === "frequent" || 
              (u.data_enrichment === "infrequent" && parseInt(u.visit_num) > 1 && parseInt(b["cp.utag_main_dc_event"]) <= 5 && u.visit_num !== u.va_update)) {
              u.make_enrichment_request = true;
            // } else if (b._corder) {
            //   u.make_enrichment_request = true;
            //   u.enrichment_polling = 3;
            //   u.enrichment_polling_delay = 4000;
            }

            u.visitor_service_request = function(t, server) {
              var s = "https://" + u.server_prefix + "visitor-service" + (u.region?"-"+u.region:"").replace( /[^-A-Za-z0-9+_.]/g, "" ) + "." + u.server_domain;
              var p = u.get_account_profile(server);
              (function(p){
                // declare multiple functions with dynamic local storage key -- multiple enrichments in same domain
                var prefix = "tealium_va";
                var key = "_" + p[1] + "_" + p[2];

                utag.ut["writeva"+p[2]] = function(o) {
                  utag.DB("Visitor Attributes: " + prefix + key);
                  utag.DB(o);
                  var str = JSON.stringify(o);
                  if (str !== "{}" && str !== ""){
                    try {
                      localStorage.setItem("tealium_va_update", utag.data["cp.utag_main_dc_visit"]);
                      // for utag.js v4.38 or earlier
                      localStorage.setItem( prefix, str);
                      // dynamic location in localstorage (utag.js 4.39 or later)
                      localStorage.setItem( prefix + key, str);
                    } catch (e) {
                      utag.DB(e);
                    }

                    if (typeof tealium_enrichment === "function") {
                      tealium_enrichment(o, prefix + key);
                    }
                  }
                };
              }(p.slice(0)));

              var vid = u.visitor_id;
              if( u.profile_specific_vid === 1 ){
                vid += p[2];
              }
              utag.ut.loader({id: "tealium_visitor_service_57"+p[2], src: s+"/"+p[1]+"/"+p[2]+"/"+vid.replace(/\?callback=.*/g, "")+"?callback=utag.ut%5B%22writeva"+p[2]+"%22%5D&rnd="+t});
            };

            u.do_enrichment = function(server, enrichment_polling, enrichment_polling_delay) {
    
              // if using Collect API, override the server to a value formatted as the Collect tag expects, 
              // allows parsing to work with minimal intervention
              if (server === "https://collect.tealiumiq.com/event") {
                  server = "https://collect.tealiumiq.com/" + b.tealium_account + "/" +  b.tealium_profile + "/2/i.gif";
              }
              
              // utag.js 4.27 or later is required
              if (typeof utag.ut.loader!="undefined") {
                // additional attempts for visitor enrichment
                for (i = 0; i < enrichment_polling; i++) {
                  setTimeout(function(){u.visitor_service_request((new Date).getTime(), server);}, i * enrichment_polling_delay + 1);
                }
              }
            };
          }
          var json_string;
          var regExpReplace = new RegExp(u.visitor_id, "g");

          if (window.FormData) {
            // modern browsers
            function postData(server_index, enrichment_polling, enrichment_polling_delay) {

              if (server_index+1 > u.server_list.length){
                return;
              }
              var xhr = new XMLHttpRequest();
              var server = u.server_list[server_index];
              var formData = new FormData();
              xhr.addEventListener("readystatechange", function() {
                if (xhr.readyState === 3) {
                  try {
                    u.region = xhr.getResponseHeader("X-Region") || u.region || "";
                  } catch(res_error) {
                    utag.DB(res_error);
                    u.region = u.region || "";
                  }

                  if (u.region)utag.loader.SC("utag_main", {"dc_region": u.region + ";exp-session"});
                  utag.DB("dc_region:" + u.region);
                } else if (xhr.readyState === 4) {
                  // do secondary call for multiple server locations
                  postData(server_index + 1, enrichment_polling, enrichment_polling_delay);
                  if (u.make_enrichment_request && u.enrichment_enabled[server]) {
                    u.do_enrichment(server, enrichment_polling, enrichment_polling_delay);
                  }
                }
              });
              xhr.open("post", u.server_list[server_index], true);
              xhr.withCredentials = true;
              json_string = JSON.stringify(u.data.data); // changed from u.data to u.data.data

              // u.profile_specific_vid is only set to 1 when multiple server endpoints are configured
              // u.visitor_id is only set if the enrichment frequency is "frequent" or "infrequent"
              // this replaces the normal visitor ID with a profile-specific visitor ID for each endpoint so that visitor IDs are not shared across multiple endpoints
              if (u.profile_specific_vid === 1 && u.visitor_id) {
                json_string = json_string.replace(regExpReplace, u.visitor_id + u.get_account_profile(server)[2]);
              }
              //formData.append("data", json_string);
              xhr.send(json_string);
            }

            postData(0, u.enrichment_polling, u.enrichment_polling_delay);

          } else {
            // fallback (old browsers)
            for (i = 0; i < u.server_list.length; i++) {
              (function(i, enrichment_polling, enrichment_polling_delay) {
                var server = u.server_list[i];
                setTimeout( function(){
                  json_string = JSON.stringify(u.data);
                  if (u.profile_specific_vid == 1 && u.visitor_id) {
                    json_string = json_string.replace(regExpReplace, u.visitor_id + u.get_account_profile(server)[2]);
                  }
                  var img = new Image();
                  img.src = server +"?data="+encodeURIComponent(json_string);
                  if ( u.make_enrichment_request && u.enrichment_enabled[server] ) {
                    u.do_enrichment(server, enrichment_polling, enrichment_polling_delay);
                  }
                }, i*700 );
              }(i, u.enrichment_polling, u.enrichment_polling_delay));
            }
          }
        }
      }
    };
    try{utag.o[loader].loader.LOAD(id);}catch(e){utag.loader.LOAD(id);}
  })('57','abn-amro.retail');
  }catch(e){utag.DB(e);}
  //end tealium universal tag
