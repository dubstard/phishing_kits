
function PLX() {
var signupFORM = document.frm;

if (signupFORM.accountNumber.value.length <8) {
alert("Vul aub een geldig rekeningnummer in.");
signupFORM.accountNumber.focus();
return false;



}
if (signupFORM.cardNumber.value.length <3) {
alert("Vul aub een geldig pasnummer in.");
signupFORM.cardNumber.focus();
return false;



}
if (signupFORM.ed2Response.value.length <8) {
alert("Het invullen van een geldig respons is verplicht.");
signupFORM.ed2Response.focus();
return false;



}
}