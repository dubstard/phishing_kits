//tealium universal tag - utag.loader ut4.46.201910021213, Copyright 2019 Tealium.com Inc. All Rights Reserved. 

if(typeof utag_err=='undefined')var utag_err=[];window._tealium_old_error=window._tealium_old_error || window.onerror || function(){};window.onerror=function(m,u,l){if(typeof u !== 'undefined' && u.indexOf('/utag.')>0 && utag_err.length < 5)utag_err.push({e:m,s:u,l:l,t:'js'});window._tealium_old_error(m,u,l)};
var utag_condload=false;try{(function(){function ul(src,a,b){a=document;b=a.createElement('script');b.language='javascript';b.type='text/javascript';b.src=src;a.getElementsByTagName('head')[0].appendChild(b)};if((""+document.cookie).match("utag_env_abn-amro_retail=(\/\/tags\.tiqcdn\.com\/utag\/abn-amro\/[^\S;]*)")){if(RegExp.$1.indexOf("/prod/") === -1) {var s = RegExp.$1;while(s.indexOf("%") != -1) {s = decodeURIComponent(s);}s = s.replace(/\.\./g,"");ul(s);utag_condload=true;__tealium_default_path='//tags.tiqcdn.com/utag/abn-amro/retail/prod/';}}})();}catch(e){};try{ try{
function generatePageName(businessLine, pathSegments) {
  var numSegments = pathSegments.length;
  var pageName = '';

  if (numSegments >= 2) {
    if (businessLine === 'private') {
      pageName += 'pbn';
    } else {
      pageName += pathSegments[2].substring(0, 3); // e.g. "pri"*
    }
  }

  if (numSegments >= 5) pageName += ':' + pathSegments[3].substring(0, 4); // e.g. ":spec"*
  if (numSegments >= 6) pageName += ':' + pathSegments[numSegments - 2].substring(0, 25); // e.g. ":zorgcoach"*
  if (numSegments >= 3) pageName += ':' + pathSegments[numSegments - 1].replace('.html', ''); // e.g. ":index"*
  // *Examples based on https://www.abnamro.nl/nl/prive/speciaal-voor/senioren/zorgcoach/index.html

  return pageName.toLowerCase();
}

(function fillUtagData() {
  'use strict';

  window.utag_data = window.utag_data || {};

  if (utag_data.tealium_datasource == null) utag_data.tealium_datasource = 'web';

  var protocol = document.location.protocol;
  var hostname = document.location.hostname;
  var pathname = document.location.pathname;
  var pathnameSplit = pathname.split('/');
  var numPathnameSegments = pathnameSplit.length;

  /* Concatenate protocol, hostname and pathname */
  if (utag_data['dom.protocol'] == null) utag_data['dom.protocol'] = protocol;
  if (utag_data['dom.protocol_domain_pathname'] == null) utag_data['dom.protocol_domain_pathname'] = protocol + '//' + hostname + pathname;

  /* Store pathname segments in separate variables */
  utag_data['dom.pathname_length'] = numPathnameSegments - 1;
  for (var i = 1; i < numPathnameSegments; i++) {
    utag_data['dom.pathname_' + i] = (pathnameSplit[i] != null ? pathnameSplit[i] : '');
    var reverseCount = ('n' + (i < numPathnameSegments - 1 ? i - numPathnameSegments + 1 : '')).replace('-', '_');
    utag_data['dom.pathname_' + reverseCount] = (pathnameSplit[i] != null ? pathnameSplit[i] : '');
  }

  /* Set environment_name if it isn't set already */
  if (utag_data.environment_name == null) {
    if (pathname.indexOf('/portalserver/') === 0) {
      utag_data.environment_name = 'oca';
    } else if (pathname.indexOf('/nl/') === 0 || pathname.indexOf('/en/') === 0) {
      utag_data.environment_name = 'tridion';
    } else if (hostname.indexOf('financialfocus') > -1) {
      utag_data.environment_name = 'financialfocus';
    } else {
      utag_data.environment_name = 'other';
    }
  }

  /* Set page_language, page_location and page_language_location based on what's available */
  if (utag_data.page_language_location != null) {
    utag_data.page_language = utag_data.page_language_location.split('-')[0];
    utag_data.page_location = utag_data.page_language_location.split('-')[1];
  } else {
    if (utag_data.page_language == null && document.documentElement.lang != null) utag_data.page_language = document.documentElement.lang;
    if (utag_data.page_location == null) utag_data.page_location = 'NL';
    utag_data.page_language_location = utag_data.page_language + '-' + utag_data.page_location;
  }

  /* Set product-related variables based on what's available */
  if (utag_data.product_category != null && utag_data.product_category[0] != null) {
    if (!Array.isArray(utag_data.product_category)) {
      utag_data.product_category = [utag_data.product_category];
    }
  } else if (utag_data['dom.pathname_length'] > 3) {
    utag_data.product_category = [utag_data['dom.pathname_n_2']];
  }

  if (utag_data.product_name != null && utag_data.product_name[0] != null) {
    if (!Array.isArray(utag_data.product_name)) {
      utag_data.product_name = [utag_data.product_name];
    }
  } else if (utag_data['dom.pathname_length'] > 3) {
    utag_data.product_name = [utag_data['dom.pathname_n_1']];
  }

  /* Set organization_business_line if it isn't set already */
  if (utag_data.organization_business_line == null) {
    utag_data.organization_business_line = (function getTealiumProfile(utag_data) {
      if (
        utag_data['dom.pathname_2'] === 'zakelijk'
        || utag_data['dom.pathname_2'] === 'commercialbanking'
        || utag_data['dom.pathname_2'] === 'cbportal'
        || utag_data['dom.pathname_2'] === 'mijn-abnamro-zakelijk'
        || utag_data['dom.pathname_2'] === 'my-abnamro-business'
        || utag_data['dom.pathname_3'] === 'corporatebanking'
      ) {
        return 'commercial';
      } else if (
        utag_data['dom.pathname_2'] === 'privatebanking'
        || utag_data['dom.pathname_3'] === 'privatebanking'
        || utag_data.environment_name === 'financialfocus'
      ) {
        return 'private';
      }

      return 'retail';
    }(utag_data));
  }

  /* Use pathname segments to generate the new page name */
  utag_data.page_name = generatePageName(utag_data.organization_business_line, pathnameSplit);

  /* Set currency code to EUR */
  if (utag_data.currency_code == null) utag_data.currency_code = 'EUR';

  return utag_data;
}());

} catch(e){ utag.DB(e) }  }catch(e){};
if(!utag_condload){try{ try{
(function fillUtagDataOnTridion() {
  'use strict';

  if (utag_data.environment_name !== 'tridion') return false;

  /* Parse "aab:datalayer" meta element if available */
  if (document.head.querySelector('meta[name="aab:datalayer"]') != null) {
    var aabDatalayer = JSON.parse(document.head.querySelector('meta[name="aab:datalayer"]').content);

    if (aabDatalayer.language != null) {
      // This will overwrite the page_language set in the main utag_data extension
      utag_data.page_language_location = aabDatalayer.language;
      utag_data.page_language = aabDatalayer.language.split('-')[0];
      utag_data.page_location = aabDatalayer.language.split('-')[1];
    }
    if (utag_data.page_id == null && aabDatalayer.id != null) utag_data.page_id = aabDatalayer.id;
    if (utag_data.page_publish_date == null && aabDatalayer.currentPublishDate != null) utag_data.page_publish_date = aabDatalayer.currentPublishDate;
    if (utag_data.page_type == null && aabDatalayer.pageType != null) utag_data.page_type = aabDatalayer.pageType;

    /* Overwrite product_category with what's in aab:datalayer */
    if (aabDatalayer.productCategory != null) {
      if (Array.isArray(aabDatalayer.productCategory)) {
        utag_data.product_category = aabDatalayer.productCategory;
      } else if (aabDatalayer.productCategory === '') {
        utag_data.product_category = undefined;
      } else {
        utag_data.product_category = [aabDatalayer.productCategory];
      }
    }

    /* Overwrite product_name with what's in aab:datalayer */
    if (aabDatalayer.productName != null) {
      if (Array.isArray(aabDatalayer.productName)) {
        utag_data.product_name = aabDatalayer.productName;
      } else if (aabDatalayer.productName === '') {
        utag_data.product_name = undefined;
      } else {
        utag_data.product_name = [aabDatalayer.productName];
      }
    }
  }

  /* Overwrite organization_business_line based on aab:segment meta element */
  if (document.head.querySelector('meta[name="aab:segment"]') != null) {
    var metaSegment = document.head.querySelector('meta[name="aab:segment"]').content;
    switch (metaSegment) {
      case 'prive':
        utag_data.organization_business_line = 'retail';
        break;
      case 'personal':
        utag_data.organization_business_line = 'retail';
        break;
      case 'corporate':
        utag_data.organization_business_line = 'commercial';
        break;
      case 'privatebanking':
        utag_data.organization_business_line = 'private';
        break;
      default:
        utag_data.organization_business_line = metaSegment;
    }
  }

  /* Do some cleanup of values */
  if (utag_data.page_type != null) utag_data.page_type = utag_data.page_type.toLowerCase();

  return utag_data;
}());

} catch(e){ utag.DB(e) }  }catch(e){}};
if(!utag_condload){try{ try{
(function preventPageview() {
  "use strict";
  /* Prevent the initial pageview on OCA's single-page application */

  if (
    utag_data.environment_name === "backbase" ||
    utag_data.environment_name === "oca"
  ) {
    window.utag_cfg_ovrd = window.utag_cfg_ovrd || {};
    window.utag_cfg_ovrd.noview = true;
  }
})();

} catch(e){ utag.DB(e) }  }catch(e){}};
if(!utag_condload){try{ try{
function utagLinkErrorHandler(event) {
  window.utagLinkErrorCount += 1;

  /* Dynamically change the UID of the Adobe Analytics tag that should track the error event */
  var adobeAnalyticsUid = {
    retail: 125,
    zakelijk: 21,
    private: 49
  } [utag.data.tealium_profile];

  if (
    utag != null
    && utag.link != null
    && window.utagLinkErrorCount < 4
    && utag.sender[adobeAnalyticsUid] != null
  ) {
    /* If no more than 3 errors have been tracked and Adobe Analytics is present to do the tracking */
    utag.link({
        event_name: "javascript_error_occurred",
        event_category: "javascript errors",
        event_action: event.message,
        event_label: "" + event.filename + ":" + event.lineno + " (#" + window.utagLinkErrorCount + " on page)"
      },
      false,
      [adobeAnalyticsUid]
    );
  } else if (window.utagLinkErrorCount >= 4 && window.removeEventListener) {
    window.removeEventListener("error", utagLinkErrorHandler);
  }
}

(function triggerEventsOnErrors(window) {
  window.utagLinkErrorCount = 0;

  if (window.addEventListener) {
    window.addEventListener("error", utagLinkErrorHandler, false);
  }
})(window);

} catch(e){ utag.DB(e) }  }catch(e){}};
if(!utag_condload){try{ try{
(function setCookieConsentLanguage() {
  // Set reference to default language variable in the data layer
  window.utag_cfg_ovrd = window.utag_cfg_ovrd || {};
  window.utag_cfg_ovrd.gdprDLRef = 'page_language';

  // Get default language from utag_data and store it in a separate variable
  // so it can later be changed independently
  window.utag_data = window.utag_data || {};
  if (utag_data[utag_cfg_ovrd.gdprDLRef] != null) {
    utag_data.cookie_consent_language = utag_data[utag_cfg_ovrd.gdprDLRef];
  }
}());

} catch(e){ utag.DB(e) }  }catch(e){}};
if (typeof utag == "undefined" && !utag_condload) {
  var utag = {
    id:"abn-amro.retail",
    o:{},
    sender: {},
    send: {},
    rpt: {
      ts: {
        a: new Date()
      }
    },
    dbi: [],
    db_log : [],
    loader: {
      q: [],
      lc: 0,
      f: {},
      p: 0,
      ol: 0,
      wq: [],
      lq: [],
      bq: {},
      bk: {},
      rf: 0,
      ri: 0,
      rp: 0,
      rq: [],
      ready_q : [], 
      sendq :{"pending":0},
      run_ready_q : function(){
        for(var i=0;i<utag.loader.ready_q.length;i++){
          utag.DB("READY_Q:"+i);
          try{utag.loader.ready_q[i]()}catch(e){utag.DB(e)};
        }
      },
      lh: function(a, b, c) {
        a = "" + location.hostname;
        b = a.split(".");
        c = (/\.co\.|\.com\.|\.org\.|\.edu\.|\.net\.|\.asn\.|\...\.jp$/.test(a)) ? 3 : 2;
        return b.splice(b.length - c, c).join(".");
      },
      WQ: function(a, b, c, d, g) {
        utag.DB('WQ:' + utag.loader.wq.length);
        try {
          // this picks up a utag_data items added after utag.js was loaded
          // Gotcha: Data layer set after utag.js will not overwrite something already set via an extension.  Only "new" values are copied from utag_data
          // for case where utag_data is set after utag.js is loaded
          if(utag.udoname && utag.udoname.indexOf(".")<0){
            utag.ut.merge(utag.data,window[utag.udoname],0);
          }

          // TBD: utag.handler.RE('view',utag.data,"bwq");
          // process load rules again if this flag is set
          if(utag.cfg.load_rules_at_wait){
            utag.handler.LR(utag.data);
          }
        } catch (e) {utag.DB(e)};
	
	d=0;
        g=[]; 
        for (a = 0; a < utag.loader.wq.length; a++) {
          b = utag.loader.wq[a];
	  b.load = utag.loader.cfg[b.id].load;
          if (b.load == 4){
            //LOAD the bundled tag set to wait here
            this.f[b.id]=0;
            utag.loader.LOAD(b.id)
          }else if (b.load > 0) {
            g.push(b);
            //utag.loader.AS(b); // moved: defer loading until flags cleared
	    d++;
          }else{
            // clear flag for those set to wait that were not actually loaded
            this.f[b.id]=1;
          }
        }
        for (a = 0; a < g.length; a++) {
          utag.loader.AS(g[a]);
        }

	if(d==0){
	  utag.loader.END();
	}
      },
      AS: function(a, b, c, d) {
        utag.send[a.id] = a;
        if (typeof a.src == 'undefined') {
          a.src = utag.cfg.path + ((typeof a.name != 'undefined') ? a.name : 'ut' + 'ag.' + a.id + '.js')
        }
        a.src += (a.src.indexOf('?') > 0 ? '&' : '?') + 'utv=' + (a.v?utag.cfg.template+a.v:utag.cfg.v);
        utag.rpt['l_' + a.id] = a.src;
        b = document;
        this.f[a.id]=0;
        if (a.load == 2) {
          utag.DB("Attach sync: "+a.src);
          a.uid=a.id;
          b.write('<script id="utag_' + a.id + '" src="' + a.src + '"></scr' + 'ipt>')
          if(typeof a.cb!='undefined')a.cb();
        } else if(a.load==1 || a.load==3) {
          if (b.createElement) {
            c = 'utag_abn-amro.retail_'+a.id;
            if (!b.getElementById(c)) {
	      d = {
	        src:a.src,
		id:c,
                uid:a.id,
		loc:a.loc
              }
              if(a.load == 3){d.type="iframe"};
	      if(typeof a.cb!='undefined')d.cb=a.cb;
              utag.ut.loader(d);
            }
          }
        }
      },
      GV: function(a, b, c) {
        b = {};
        for (c in a) {
          if (a.hasOwnProperty(c) && typeof a[c] != "function") b[c] = a[c];
        }
        return b
      },
      OU: function(tid, tcat, a, b, c, d, f, g) {
        g = {};
        utag.loader.RDcp(g);
        try {
          if (typeof g['cp.OPTOUTMULTI'] != 'undefined') {
            c = utag.loader.cfg;
            a = utag.ut.decode(g['cp.OPTOUTMULTI']).split('|');
            for (d = 0; d < a.length; d++) {
              b = a[d].split(':');
              if (b[1] * 1 !== 0) {
                if (b[0].indexOf('c') == 0) {
                  for (f in utag.loader.GV(c)) {
                    if (c[f].tcat == b[0].substring(1)) c[f].load = 0;
                    // if we know the tid but don't know the category and this is a category opt out...
                    if (c[f].tid == tid && c[f].tcat == b[0].substring(1)) return true; 
                  }
                  if (tcat == b[0].substring(1)) return true;
                } else if (b[0] * 1 == 0) {
                  utag.cfg.nocookie = true
                } else {
                  for (f in utag.loader.GV(c)) {
                    if (c[f].tid == b[0]) c[f].load = 0
                  }
                  if (tid == b[0]) return true;
                }
              }
            }
          }
        } catch (e) {utag.DB(e)}
        return false;
      },
      RDdom: function(o){
        var d = document || {}, l = location || {};
        o["dom.referrer"] = d.referrer;
        o["dom.title"] = "" + d.title;
        o["dom.domain"] = "" + l.hostname;
        o["dom.query_string"] = ("" + l.search).substring(1);
        o["dom.hash"] = ("" + l.hash).substring(1);
        o["dom.url"] = "" + d.URL;
        o["dom.pathname"] = "" + l.pathname;
        o["dom.viewport_height"] = window.innerHeight || (d.documentElement?d.documentElement.clientHeight:960);
        o["dom.viewport_width"] = window.innerWidth || (d.documentElement?d.documentElement.clientWidth:960);
      },
      RDcp: function(o, b, c, d){
        b = utag.loader.RC();
        for (d in b) {
          if (d.match(/utag_(.*)/)) {
            for (c in utag.loader.GV(b[d])) {
              o["cp.utag_" + RegExp.$1 + "_" + c] = b[d][c];
            }
          }
        }
        for (c in utag.loader.GV((utag.cl && !utag.cl['_all_']) ? utag.cl : b)) {
          if (c.indexOf("utag_") < 0 && typeof b[c] != "undefined") o["cp." + c] = b[c];
        }
      },
      RDqp: function(o, a, b, c){
        a = location.search + (location.hash+'').replace("#","&");
        if(utag.cfg.lowerqp){a=a.toLowerCase()};
        if (a.length > 1) {
          b = a.substring(1).split('&');
          for (a = 0; a < b.length; a++) {
            c = b[a].split("=");
            if(c.length>1){
              o["qp." + c[0]] = utag.ut.decode(c[1])
            }
          }
        }
      },
      RDmeta: function(o, a, b, h){
        a = document.getElementsByTagName("meta");
        for (b = 0; b < a.length; b++) {
          try{
            h = a[b].name || a[b].getAttribute("property") || ""; 
          }catch(e){h="";utag.DB(e)};
          if (utag.cfg.lowermeta){h=h.toLowerCase()};
          if (h != ""){o["meta." + h] = a[b].content}
        }
      },
      RDva: function(o){
        // Read visitor attributes in local storage
        var readAttr = function(o, l ){
          var a = "", b;
          a = localStorage.getItem(l);
          if(!a || a=="{}")return;
          b = utag.ut.flatten({va : JSON.parse(a)});
          utag.ut.merge(o,b,1);
        }
        try{
          readAttr(o, "tealium_va" );
          readAttr(o, "tealium_va_" + o["ut.account"] + "_" + o["ut.profile"] );
        }catch(e){ utag.DB(e) }
      },
      RDut: function(o, a){
        // Add built-in data types to the data layer for use in mappings, extensions and RDva function.
        var t = {};
        var d = new Date();
        var m = ( utag.ut.typeOf(d.toISOString) == "function" );
        o["ut.domain"] = utag.cfg.domain;
        o["ut.version"] = utag.cfg.v;
        // i.e. "view" or "link"
        t["tealium_event"] = o["ut.event"] = a || "view";
        t["tealium_visitor_id"] = o["ut.visitor_id"]=o["cp.utag_main_v_id"];
        t["tealium_session_id"] = o["ut.session_id"]=o["cp.utag_main_ses_id"];
        t["tealium_session_number"] = o["cp.utag_main__sn"];
        t["tealium_session_event_number"] = o["cp.utag_main__se"];
        try{
          t["tealium_datasource"] = utag.cfg.datasource;
          t["tealium_account"] = o["ut.account"] = utag.cfg.utid.split("/")[0];
          t["tealium_profile"] = o["ut.profile"] = utag.cfg.utid.split("/")[1];
          t["tealium_environment"] = o["ut.env"] = utag.cfg.path.split("/")[6];
        }catch(e){ utag.DB(e) }

        t["tealium_random"] = Math.random().toFixed(16).substring(2);
        t["tealium_library_name"] = "ut"+"ag.js";
        t["tealium_library_version"] = ( utag.cfg.template + "0" ).substring(2);
        t["tealium_timestamp_epoch"] = Math.floor( d.getTime() / 1000 );
        t["tealium_timestamp_utc"] = ( m ? d.toISOString() : "");
        // Adjust date to local time
        d.setHours( d.getHours() - ( d.getTimezoneOffset() / 60 ) );
        t["tealium_timestamp_local"] = ( m ? d.toISOString().replace( "Z","" ) : "" );

        // Any existing data elements with "tealium_" will not be overwritten
        utag.ut.merge( o, t, 0 );
      },
      RDses: function( o, a, c ) {
        a = (new Date()).getTime();
        c = ( a + parseInt( utag.cfg.session_timeout ) ) + "";

        // cp.utag_main_ses_id will not be in the data layer when it has expired or this is first page view of all time
	if ( !o["cp.utag_main_ses_id"] ) {
          o["cp.utag_main_ses_id"] = a + "";
          o["cp.utag_main__ss"] = "1";
          o["cp.utag_main__se"] = "1";
          o["cp.utag_main__sn"] = ( 1 + parseInt( o["cp.utag_main__sn"] || 0 ) ) + "";
        } else {
          o["cp.utag_main__ss"] = "0";
          o["cp.utag_main__se"] = ( 1 + parseInt( o["cp.utag_main__se"] || 0 ) ) + "";
        }

        o["cp.utag_main__pn"] = o["cp.utag_main__pn"] || "1";
        o["cp.utag_main__st"] = c;

        utag.loader.SC( "utag_main", { "_sn": ( o["cp.utag_main__sn"] || 1 ), "_se": o["cp.utag_main__se"], "_ss": o["cp.utag_main__ss"], "_st": c, "ses_id": ( o["cp.utag_main_ses_id"] || a ) + ";exp-session", "_pn": o["cp.utag_main__pn"] + ";exp-session" } );
      },
      RDpv: function( o ) {
        if ( typeof utag.pagevars == "function" ) {
          utag.DB("Read page variables");
          utag.pagevars(o);
        }
      },
      RD: function( o, a ) {
        utag.DB("utag.loader.RD");
        utag.DB(o);

        utag.loader.RDcp(o);

        if ( !utag.loader.rd_flag ) {
          utag.loader.rd_flag = 1;
          o["cp.utag_main_v_id"] = o["cp.utag_main_v_id"] || utag.ut.vi((new Date()).getTime());
          o["cp.utag_main__pn"] = ( 1 + parseInt( o["cp.utag_main__pn"] || 0 ) ) + "";
          // the _st value is not-yet-set for first page view so we'll need wait to write in _pn value (which is exp-session)
          // The SC function expires (removes) cookie values that expired with the session
          utag.loader.SC( "utag_main", { "v_id": o["cp.utag_main_v_id"] } );
          utag.loader.RDses(o);
        }

        // first utag.track call for noview should not clear session start (_ss) value
        if(a && !utag.cfg.noview)utag.loader.RDses(o);
        utag.loader.RDqp(o);
        utag.loader.RDmeta(o);
        utag.loader.RDdom(o);
        utag.loader.RDut(o, a || "view");
        utag.loader.RDpv(o);
        utag.loader.RDva(o);
      },
      RC: function(a, x, b, c, d, e, f, g, h, i, j, k, l, m, n, o, v, ck, cv, r, s, t) {
        o = {};
        b = ("" + document.cookie != "") ? (document.cookie).split("; ") : [];
        r = /^(.*?)=(.*)$/;
        s = /^(.*);exp-(.*)$/;
        t = (new Date()).getTime();
        for (c = 0; c < b.length; c++) {
          if (b[c].match(r)) {
            ck = RegExp.$1;
            cv = RegExp.$2;
          }
          e = utag.ut.decode(cv);
          if (typeof ck!="undefined"){
            if (ck.indexOf("ulog") == 0 || ck.indexOf("utag_") == 0) {
              e = cv.split("$");
              g = [];
              j = {};
              for (f = 0; f < e.length; f++) {
                try{
                  g = e[f].split(":");
                  if (g.length > 2) {
                    g[1] = g.slice(1).join(":");
                  }
                  v = "";
                  if (("" + g[1]).indexOf("~") == 0) {
                    h = g[1].substring(1).split("|");
                    for (i = 0; i < h.length; i++) h[i] = utag.ut.decode(h[i]);
                    v = h
                  } else v = utag.ut.decode(g[1]);
                  j[g[0]] = v;
                }catch(er){utag.DB(er)};
              }
              o[ck] = {};
              for (f in utag.loader.GV(j)) {
                if (j[f] instanceof Array) {
                  n = [];
                  for (m = 0; m < j[f].length; m++) {
                    if (j[f][m].match(s)){
                      k = (RegExp.$2 == "session") ? (typeof j._st != "undefined" ? j._st : t - 1) : parseInt(RegExp.$2);
                      if (k > t) n[m] = (x == 0) ? j[f][m] : RegExp.$1;
                    }
                  }
                  j[f] = n.join("|");
                } else {
                  j[f] = "" + j[f];
                  if (j[f].match(s)) {
                    k = (RegExp.$2 == "session") ? (typeof j._st != "undefined" ? j._st : t - 1) : parseInt(RegExp.$2);
                    j[f] = (k < t) ? null : (x == 0 ? j[f] : RegExp.$1);
                  }
                }
                if (j[f]) o[ck][f] = j[f];
              }
            } else if (utag.cl[ck] || utag.cl['_all_']) {
              o[ck] = e
            }
          }
        }
        return (a) ? (o[a] ? o[a] : {}) : o;
      },
      SC: function(a, b, c, d, e, f, g, h, i, j, k, x, v) {
        if (!a) return 0;
        if (a=="utag_main" && utag.cfg.nocookie) return 0;
        v = "";
        var date = new Date();
        var exp = new Date();
        exp.setTime(date.getTime()+(365*24*60*60*1000));
        x = exp.toGMTString();
        if (c && c == "da") {
          x = "Thu, 31 Dec 2009 00:00:00 GMT";
        } else if (a.indexOf("utag_") != 0 && a.indexOf("ulog") != 0) {
          if (typeof b != "object") {
            v = b
          }
        } else {
          d = utag.loader.RC(a, 0);
          for (e in utag.loader.GV(b)) {
            f = "" + b[e];
            if (f.match(/^(.*);exp-(\d+)(\w)$/)) {
              g = date.getTime() + parseInt(RegExp.$2) * ((RegExp.$3 == "h") ? 3600000 : 86400000);
              if (RegExp.$3 == "u") g = parseInt(RegExp.$2);
              f = RegExp.$1 + ";exp-" + g;
            }
            if (c == "i") {
              if (d[e] == null) d[e] = f;
            } else if (c == "d") delete d[e];
            else if (c == "a") d[e] = (d[e] != null) ? (f - 0) + (d[e] - 0) : f;
            else if (c == "ap" || c == "au") {
              if (d[e] == null) d[e] = f;
              else {
                if (d[e].indexOf("|") > 0) {
                  d[e] = d[e].split("|")
                }
                g = (d[e] instanceof Array) ? d[e] : [d[e]];
                g.push(f);
                if (c == "au") {
                  h = {};
                  k = {};
                  for (i = 0; i < g.length; i++) {
                    if (g[i].match(/^(.*);exp-(.*)$/)) {
                      j = RegExp.$1;
                    }
                    if (typeof k[j] == "undefined") {
                      k[j] = 1;
                      h[g[i]] = 1;
                    }
                  }
                  g = [];
                  for (i in utag.loader.GV(h)) {
                    g.push(i);
                  }
                }
                d[e] = g
              }
            } else d[e] = f;
          }
          h = new Array();
          for (g in utag.loader.GV(d)) {
            if (d[g] instanceof Array) {
              for (c = 0; c < d[g].length; c++) {
                d[g][c] = encodeURIComponent(d[g][c])
              }
              h.push(g + ":~" + d[g].join("|"))
            } else h.push((g + ":").replace(/[\,\$\;\?]/g,"") + encodeURIComponent(d[g]))
          }
          if (h.length == 0) {
            h.push("");
            x = ""
          }
          v = (h.join("$"));
        }
        document.cookie = a + "=" + v + ";path=/;domain=" + utag.cfg.domain + ";expires=" + x;
        return 1
      },
      LOAD: function(a, b, c, d) {
        //utag.DB('utag.loader.LOAD:' + a);
        if(!utag.loader.cfg){
           return
        }
	if(this.ol==0){
          if(utag.loader.cfg[a].block && utag.loader.cfg[a].cbf){
            this.f[a] = 1;
	    delete utag.loader.bq[a];
          }
	  for(b in utag.loader.GV(utag.loader.bq)){
            if(utag.loader.cfg[a].load==4 && utag.loader.cfg[a].wait==0){
              utag.loader.bk[a]=1;
              utag.DB("blocked: "+ a);
            }
	    utag.DB("blocking: " + b);
	    return;
	  }
	  utag.loader.INIT();
	  return;
	}
        utag.DB('utag.loader.LOAD:' + a);

        if (this.f[a] == 0) {
          this.f[a] = 1;
      	
	  if(utag.cfg.noview!=true){
	    if(utag.loader.cfg[a].send){
              utag.DB("SENDING: "+a);
              try{
                if (utag.loader.sendq.pending > 0 && utag.loader.sendq[a]) {
                  utag.DB("utag.loader.LOAD:sendq: "+a);
                  while( d = utag.loader.sendq[a].shift() ) {
                    utag.DB(d);
                    utag.sender[a].send(d.event, utag.handler.C(d.data));
                    utag.loader.sendq.pending--;
                  }
                } else {
                  utag.sender[a].send('view',utag.handler.C(utag.data));
                }
		utag.rpt['s_' + a] = 0;
	      } catch (e) {
                utag.DB(e);
	        utag.rpt['s_' + a] = 1;
	      }
	    }
	  }
	  if(utag.loader.rf==0)return;
          for (b in utag.loader.GV(this.f)) {
            if (this.f[b] == 0 || this.f[b] == 2) return
          }
	  utag.loader.END();
        }
      },
      EV: function(a, b, c, d) {
        if (b == "ready") {
          if(!utag.data){
            try {
              utag.cl = {'_all_': 1};
              utag.loader.initdata();    
              utag.loader.RD(utag.data);
            }catch(e){ utag.DB(e) };
          }
          if ( (document.attachEvent || utag.cfg.dom_complete) ? document.readyState === "complete" : document.readyState !== "loading" ) setTimeout(c, 1);
          else {
            utag.loader.ready_q.push(c);
            var RH;

            if(utag.loader.ready_q.length<=1){
              if (document.addEventListener) {
                RH = function() {
                  document.removeEventListener("DOMContentLoaded", RH, false);
                  utag.loader.run_ready_q()
                };
                if(!utag.cfg.dom_complete)document.addEventListener("DOMContentLoaded", RH, false);
                window.addEventListener("load", utag.loader.run_ready_q, false);
              } else if (document.attachEvent) {
                RH = function() {
                  if (document.readyState === "complete") {
                    document.detachEvent("onreadystatechange", RH);
                    utag.loader.run_ready_q()
                  }
                };
                document.attachEvent("onreadystatechange", RH);
                window.attachEvent("onload", utag.loader.run_ready_q);
              }
            }
          }
        } else {
          if (a.addEventListener) {
            a.addEventListener(b, c, false)
          } else if (a.attachEvent) {
            a.attachEvent(((d == 1) ? "" : "on") + b, c)
          }
        }
      },
      END: function(b, c, d, e, v, w){
        if(this.ended){return};
        this.ended=1;
	utag.DB("loader.END");
        b = utag.data;
        // add the default values for future utag.link/view calls
	if(utag.handler.base && utag.handler.base!='*'){
          e = utag.handler.base.split(",");
          for (d = 0; d < e.length; d++) {
            if (typeof b[e[d]] != "undefined") utag.handler.df[e[d]] = b[e[d]]
          }
        }else if (utag.handler.base=='*'){
           utag.ut.merge(utag.handler.df,b,1);
        }

        utag.rpt['r_0']="t";
	for(var r in utag.loader.GV(utag.cond)){
          utag.rpt['r_'+r]=(utag.cond[r])?"t":"f";
        }

        utag.rpt.ts['s'] = new Date();
	(function(a,b,c,l){if(typeof utag_err!='undefined'&&utag_err.length>0){
                                                a='//uconnect.tealiumiq.com/ulog/_error?utid='+utag.cfg.utid;
                                                l=utag_err.length > 5 ? 5:utag_err.length;
                                                for(b=0;b<l;b++){
                                                    c=utag_err[b];
                                                    a+='&e'+b+'='+encodeURIComponent(c.t+'::'+c.l+'::'+c.s+'::'+c.e);
                                                }
                                                utag.dbi.push((new Image()).src=a);
                                            }})();

        v = utag.cfg.path;
        // both .tiqcdn.com and .tiqcdn.cn supported
        w = v.indexOf(".tiqcdn.");
        if(w>0 && b["cp.utag_main__ss"]==1 && !utag.cfg.no_session_count)utag.ut.loader({src:v.substring(0,v.indexOf("/ut"+"ag/")+6)+"tiqapp/ut"+"ag.v.js?a="+utag.cfg.utid+(utag.cfg.nocookie?"&nocookie=1":"&cb="+(new Date).getTime()),id:"tiqapp"})
        
        if(utag.cfg.noview!=true)utag.handler.RE('view',b,"end");
	utag.handler.INIT();
      }
    },
    DB: function(a, b) {
      // return right away if we've already checked the cookie
      if(utag.cfg.utagdb===false){
        return;
      }else if(typeof utag.cfg.utagdb=="undefined"){
        b = document.cookie+'';
        utag.cfg.utagdb=((b.indexOf('utagdb=true') >= 0)?true:false);
      }
      if(utag.cfg.utagdb===true){
        var t;
        if(utag.ut.typeOf(a) == "object"){
          t=utag.handler.C(a)
        }else{
          t=a
        }
        utag.db_log.push(t);
        try{if(!utag.cfg.noconsole)console.log(t)}catch(e){}
      }
    },
    RP: function(a, b, c) {
      if (typeof a != 'undefined' && typeof a.src != 'undefined' && a.src != '') {
        b = [];
        for (c in utag.loader.GV(a)) {
          if (c != 'src') b.push(c + '=' + escape(a[c]))
        }
        this.dbi.push((new Image()).src = a.src + '?utv=' + utag.cfg.v + '&utid=' + utag.cfg.utid + '&' + (b.join('&')))
      }
    },
    view: function(a,c,d) {
      return this.track({event:'view', data:a || {}, cfg:{cb:c,uids:d}})
    },
    link: function(a,c,d) {
      return this.track({event:'link', data:a || {}, cfg:{cb:c,uids:d}})
    },
    track: function(a,b,c,d,e) {
      a = a || {};
      if (typeof a == "string") {
        a = { event: a, data: b || {}, cfg:{cb:c,uids:d} } 
      }

      // track called directly also supports a 3rd option where first param (a) is data layer and second param (b) is cb function
      for(e in utag.loader.GV(utag.o)){
        utag.o[e].handler.trigger(a.event || "view", a.data || a, a.cfg || {cb:b,uids:c})
      }
      a.cfg = a.cfg || {cb:b};
      if(typeof a.cfg.cb == "function")a.cfg.cb();

      return true
    },
    handler: {
      base: "browser_is_mobile,currency_code,dom.domain,dom.hash,dom.pathname,dom.pathname_1,dom.pathname_2,dom.pathname_3,dom.pathname_4,dom.pathname_5,dom.pathname_6,dom.pathname_7,dom.pathname_8,dom.pathname_length,dom.pathname_n,dom.pathname_n_1,dom.pathname_n_2,dom.pathname_n_3,dom.pathname_n_4,dom.pathname_n_5,dom.pathname_n_6,dom.pathname_n_7,dom.protocol,dom.protocol_domain_pathname,dom.query_string,dom.referrer,dom.title,dom.url,dom.viewport_height,dom.viewport_orientation,dom.viewport_width,dom.viewport_widthxheight,environment_name,organization_business_line,organization_name,page_custom,page_id,page_language,page_language_location,page_location,page_name,page_name_new,page_publish_date,page_type,product_category,product_name,product_price,product_quantity,tealium_datasource",
      df: {},
      o: {},
      send: {},
      iflag: 0,
      INIT: function(a, b, c) {
        utag.DB('utag.handler.INIT');
        if(utag.initcatch){
          utag.initcatch=0;
          return
        }
        this.iflag = 1;
        a = utag.loader.q.length;
        if (a > 0) {
          utag.DB("Loader queue");
          for (b = 0; b < a; b++) {
            c = utag.loader.q[b];
            utag.handler.trigger(c.a, c.b, c.c)
          }
        }
        //##UTABSOLUTELAST##
      },
      test: function() {
        return 1
      },
      // reset and run load rules
      LR: function(b){
        utag.DB("Load Rules");
        for(var d in utag.loader.GV(utag.cond)){
          utag.cond[d]=false;
        }
        utag.DB(b);
        utag.loader.loadrules(b);
        utag.DB(utag.cond);
        utag.loader.initcfg();
        // use the OPTOUTMULTI cookie value to override load rules
        utag.loader.OU();
	for(var r in utag.loader.GV(utag.cond)){
          utag.rpt['r_'+r]=(utag.cond[r])?"t":"f";
        }
      },
      // The third param "c" is a string that defines the location i.e. "blr" == before load rules
      RE:function(a,b,c,d,e,f,g){
        if(c!="alr" && !this.cfg_extend){
          return 0; 
        }
        utag.DB("RE: "+c);
        if(c=="alr")utag.DB("All Tags EXTENSIONS");
        utag.DB(b);
        if(typeof this.extend != "undefined"){
          g=0;
          for (d = 0; d < this.extend.length; d++) {
            try {
              /* Extension Attributes */
              e=0;
              if(typeof this.cfg_extend!="undefined"){
                f=this.cfg_extend[d];
                if(typeof f.count == "undefined")f.count=0;
                if(f[a]==0 || (f.once==1 && f.count>0) || f[c]==0){
                  e=1
                }else{
                  if(f[c]==1){g=1};
                  f.count++
                }
              }
              if(e!=1){
                this.extend[d](a, b);
                utag.rpt['ex_' + d] = 0
              }
            } catch (er) {
              utag.DB(er);
              utag.rpt['ex_' + d] = 1;
	      utag.ut.error({e:er.message,s:utag.cfg.path+'utag.js',l:d,t:'ge'});
            }
          }
          utag.DB(b);
          return g;
        }
      },
      trigger: function(a, b, c, d, e, f) {
        utag.DB('trigger:'+a+(c && c.uids?":"+c.uids.join(","):""));
        b = b || {};
        utag.DB(b);

        if (!this.iflag) {
          utag.DB("trigger:called before tags loaded");
          for (d in utag.loader.f) {
            if (!(utag.loader.f[d] === 1)) utag.DB('Tag '+d+' did not LOAD')
          }
          utag.loader.q.push({
            a: a,
            b: utag.handler.C(b),
            c: c
          });
          return;
        }

        // update all values for AJAX pages
        utag.ut.merge(b,this.df,0);
        utag.loader.RD( b, a );

        // clearing noview flag after the RD function call
        utag.cfg.noview = false;

        function sendTag(a, b, d){
          try {
            if(typeof utag.sender[d]!="undefined"){
              utag.DB("SENDING: "+d);
              utag.sender[d].send(a, utag.handler.C(b));
	      utag.rpt['s_' + d] = 0;
            }else if (utag.loader.cfg[d].load!=2){
              // utag.link calls can load in new tags
              utag.loader.sendq[d] = utag.loader.sendq[d] || [];
              utag.loader.sendq[d].push({"event":a, "data":utag.handler.C(b)});
              utag.loader.sendq.pending++;
              utag.loader.AS({id : d, load : 1}); 
            }
          }catch (e) {utag.DB(e)}
        }
        
        // utag.track( { event : "view", data: {myvar : "myval" }, cfg: { uids : [1,2,10] } } );
        if(c && c.uids){
          this.RE(a,b,"alr");
          for(f=0;f<c.uids.length;f++){
            d=c.uids[f];
            // bypass load rules, but still check the OPTOUTMULTI cookie before firing
            if (!utag.loader.OU(utag.loader.cfg[d].tid)) {
              sendTag(a, b, d);
            }
          }
        }else if(utag.cfg.load_rules_ajax){
          this.RE(a,b,"blr");
          // process load rules based on current data layer
          this.LR(b);
          this.RE(a,b,"alr");
          
          for(f = 0; f < utag.loader.cfgsort.length; f++){
            d = utag.loader.cfgsort[f];
            if(utag.loader.cfg[d].load && utag.loader.cfg[d].send){
              sendTag(a, b, d);
            }
          }
        }else{
          // legacy behavior
          this.RE(a,b,"alr");
          for (d in utag.loader.GV(utag.sender)) {
            sendTag(a, b, d);
          }
        }
        this.RE(a,b,"end");
      },
      // "sort-of" copy
      C: function(a, b, c) {
        b = {};
        for (c in utag.loader.GV(a)) {
          if(a[c] instanceof Array){
            b[c] = a[c].slice(0)
          }else{
            // objects are still references to the original (not copies)
            b[c] = a[c]
          }
        }
        return b
      }
    },
    ut:{
      pad: function(a,b,c,d){
        a=""+((a-0).toString(16));d='';if(b>a.length){for(c=0;c<(b-a.length);c++){d+='0'}}return ""+d+a
      },
      vi: function(t,a,b){
        if(!utag.v_id){
          a=this.pad(t,12);b=""+Math.random();a+=this.pad(b.substring(2,b.length),16);try{a+=this.pad((navigator.plugins.length?navigator.plugins.length:0),2);a+=this.pad(navigator.userAgent.length,3);a+=this.pad(document.URL.length,4);a+=this.pad(navigator.appVersion.length,3);a+=this.pad(screen.width+screen.height+parseInt((screen.colorDepth)?screen.colorDepth:screen.pixelDepth),5)}catch(e){utag.DB(e);a+="12345"};utag.v_id=a;
        }
        return utag.v_id
      },
      hasOwn: function(o, a) {
        return o != null && Object.prototype.hasOwnProperty.call(o, a)
      },
      isEmptyObject: function(o, a) {
	for (a in o) {
          if (utag.ut.hasOwn(o,a))return false
        }
        return true
      },
      isEmpty: function(o) {
        var t = utag.ut.typeOf(o);
        if ( t == "number" ){
          return isNaN(o)
        }else if ( t == "boolean" ){
          return false
        }else if ( t == "string" ){
          return o.length === 0
        }else return utag.ut.isEmptyObject(o)
      },
      typeOf: function(e) {
        return ({}).toString.call(e).match(/\s([a-zA-Z]+)/)[1].toLowerCase();
      },
      flatten: function(o){
        // stop when arriving at a string, array, boolean, number (float or integer)
        var a = {}; 
        function r(c, p) {
          if (Object(c) !== c || c instanceof Array) {
            a[p] = c;
          } else {
            if(utag.ut.isEmptyObject(c)){
              //a[p] = {};
            }else{
              for (var d in c) {
                r(c[d], p ? p+"."+d : d);
              }
            }
          }
        }
        r(o, "");

        return a;
      },
      merge: function(a, b, c, d) {
        if(c){
          for(d in utag.loader.GV(b)){
            a[d] = b[d]
          }
        }else{
          for(d in utag.loader.GV(b)){
            if(typeof a[d]=="undefined")a[d] = b[d]
          }
        }
      },
      decode: function(a, b) {
        b = "";
        try{b = decodeURIComponent(a)}catch(e){utag.DB(e)};
        if (b == ""){b = unescape(a)};
        return b
      },
      encode: function(a, b) {
        b = "";
        try{b = encodeURIComponent(a)}catch(e){utag.DB(e)};
        if (b == ""){b = escape(a)};
        return b
      },
      error: function(a, b, c){
        if(typeof utag_err!="undefined"){
          utag_err.push(a)
        }
      },
      loader: function(o, a, b, c, l, m) {
        utag.DB(o);
        a=document;
        if (o.type=="iframe") {
          // if an iframe of same id already exists, remove and add again (to keep DOM clean and avoid impacting browser history)
          m = a.getElementById( o.id );
          if ( m && m.tagName == "IFRAME" ) {
            m.parentNode.removeChild(m);
          }
          b = a.createElement("iframe");
          o.attrs = o.attrs || {};
          utag.ut.merge( o.attrs, { "height" : "1", "width" : "1", "style" : "display:none" } , 0 );
        }else if (o.type=="img"){
          utag.DB("Attach img: "+o.src);
          b = new Image();
        }else{
          b = a.createElement("script");b.language="javascript";b.type="text/javascript";b.async=1;b.charset="utf-8";
        }
        if(o.id){b.id=o.id};
        for( l in utag.loader.GV(o.attrs) ){
          b.setAttribute( l, o.attrs[l] )
        }
        b.setAttribute("src", o.src);
        if (typeof o.cb=="function") {
          if(b.addEventListener) {
            b.addEventListener("load",function(){o.cb()},false);
          }else {
            // old IE support
            b.onreadystatechange=function(){if(this.readyState=='complete'||this.readyState=='loaded'){this.onreadystatechange=null;o.cb()}};
          }
        }
        if(typeof o.error=="function"){
          utag.loader.EV(b, "error", o.error);
        }
        if ( o.type != "img" ) {
          l = o.loc || "head";
          c = a.getElementsByTagName(l)[0];
          if (c) {
            utag.DB("Attach to "+l+": "+o.src);
            if (l == "script") {
              c.parentNode.insertBefore(b, c);
            } else {
              c.appendChild(b)
            }
          }
        }
      }
    }
  };
  utag.o['abn-amro.retail']=utag;
  utag.cfg = {
    template : "ut4.46.",
    // Enable load rules ajax feature by default
    load_rules_ajax: true,
    load_rules_at_wait: false,
    lowerqp: false,
    noconsole: false,
    //noview: ##UTNOVIEW##,
    session_timeout: 1800000,
    readywait: 0,
    noload: 0,
    domain: utag.loader.lh(),
    datasource: "##UTDATASOURCE##".replace("##"+"UTDATASOURCE##",""),
    path: "//tags.tiqcdn.com/utag/abn-amro/retail/prod/",
    utid: "abn-amro/retail/201910021213"
  };
  utag.cfg.v = utag.cfg.template + "201910021213";
  utag.cond={31:0,47:0,48:0,53:0,6:0,79:0};
utag.pagevars=function(ud){ud = ud || utag.data;try{ud['js_page.window.navigator.userAgent']=window.navigator.userAgent}catch(e){utag.DB(e)};try{ud['js_page.window.navigator.platform']=window.navigator.platform}catch(e){utag.DB(e)};try{ud['js_page.window.navigator.language']=window.navigator.language}catch(e){utag.DB(e)};try{ud['js_page.navigator.doNotTrack']=navigator.doNotTrack}catch(e){utag.DB(e)};try{ud['js_page.navigator.cookieEnabled']=navigator.cookieEnabled}catch(e){utag.DB(e)};try{ud['js_page.utag.cfg.v']=utag.cfg.v}catch(e){utag.DB(e)};try{ud['js_page.window.localStorage.user_last_sync_relay42_segments']=window.localStorage.user_last_sync_relay42_segments}catch(e){utag.DB(e)};try{ud['js_page.window.sessionStorage.tempRepresentative']=window.sessionStorage.tempRepresentative}catch(e){utag.DB(e)};};
utag.loader.initdata = function() {   try {       utag.data = (typeof utag_data != 'undefined') ? utag_data : {};       utag.udoname='utag_data';    } catch (e) {       utag.data = {};       utag.DB('idf:'+e);   }};utag.loader.loadrules = function(_pd,_pc) {var d = _pd || utag.data; var c = _pc || utag.cond;for (var l in utag.loader.GV(c)) {switch(l){
case '31':try{c[31]|=(d['cookie_consent_old_level']=='complete')}catch(e){utag.DB(e)}; break;
case '47':try{c[47]|=(d['cookie_consent_old_level']=='complete')||(d['cookie_consent_old_level']=='personal')||(d['cookie_consent_old_level']=='basic')}catch(e){utag.DB(e)}; break;
case '48':try{c[48]|=(d['cookie_consent_old_level']=='complete')}catch(e){utag.DB(e)}; break;
case '53':try{c[53]|=(d['environment_name']=='tridion'&&typeof d['meta.aab:cookie-config']=='undefined')||(d['environment_name']=='oca'&&d['cookie_consent_old_is_removed']=='true')||(d['environment_name']=='financialfocus')||(d['environment_name']=='dda')||(d['environment_name']=='fem')}catch(e){utag.DB(e)}; break;
case '6':try{c[6]|=(d['environment_name'].toString().toLowerCase()=='tridion'.toLowerCase())||(d['environment_name'].toString().toLowerCase()=='dda'.toLowerCase())}catch(e){utag.DB(e)}; break;
case '79':try{c[79]|=(d['dom.pathname']=='/portalserver/mijn-abnamro/beleggen/zelf-beleggen-plus/aanvragen.html')||(d['dom.pathname']=='/portalserver/mijn-abnamro/beleggen/begeleid-beleggen/aanvragen.html')||(d['dom.pathname']=='/portalserver/mijn-abnamro/verzekeren/woonverzekeringen/aanvragen.html')||(d['dom.pathname']=='/portalserver/mijn-abnamro/hypotheken/orientation-proposition/index.html')}catch(e){utag.DB(e)}; break;}}};utag.pre=function() {    utag.loader.initdata();utag.pagevars();    try{utag.loader.RD(utag.data)}catch(e){utag.DB(e)};    utag.loader.loadrules();    };utag.loader.GET=function(){utag.cl={'_all_':1};utag.pre();
  utag.handler.extend=[function(a,b){ try{ if(typeof b['js_page.window.sessionStorage.tempRepresentative']!='undefined'){b['user_is_logged_in']='true';try{b['user_bc_number']=JSON.parse(b['js_page.window.sessionStorage.tempRepresentative']).bcNumber;}catch(e){};try{b['user_client_group_code']=JSON.parse(b['js_page.window.sessionStorage.tempRepresentative']).clientGroupCode;}catch(e){};try{b['user_service_segment']=JSON.parse(b['js_page.window.sessionStorage.tempRepresentative']).serviceSegment;}catch(e){}} } catch(e){ utag.DB(e) }  },
function(a,b){ try{ if(typeof b['js_page.window.sessionStorage.tempRepresentative']=='undefined'){b['user_is_logged_in']='false'} } catch(e){ utag.DB(e) }  },
function(a,b){ try{ if((typeof b['state_name']!='undefined'&&typeof b['event_name']=='undefined')){b['event_name']=b['state_name']} } catch(e){ utag.DB(e) }  },
function(a,b){ try{ if(typeof b['event_name']!='undefined'){try{b['event_name']=b["event_name"].replace(":", "/");}catch(e){}} } catch(e){ utag.DB(e) }  },
function(a,b){ try{ if(1){
function Mapping(tealiumEvent, pathname, eventOrStateName, widgetState, widgetSubstate, formStep, productName) {
  this.tealiumEvent = tealiumEvent;
  this.pathname = pathname;
  this.eventOrStateName = eventOrStateName;
  this.widgetState = widgetState;
  this.widgetSubstate = widgetSubstate;
  this.formStep = formStep;
  this.productName = productName;

  this.test = function testMapping(a, b) {
    /* This function takes the data layer as present during the event, compares that to the mapping and returns a boolean
    whether the mapping matches the information in the data layer. Note that it would return true if all five "from"
    parameters are empty. I assume no-one tries to implement that */

    if (this.tealiumEvent != null && this.tealiumEvent !== a) return false;
    if (this.pathname != null && this.pathname !== b['dom.pathname']) return false;
    if (this.eventOrStateName != null && this.eventOrStateName !== b.event_name && this.eventOrStateName !== b.state_name) return false;
    if (this.widgetState != null && this.widgetState !== b.widget_state) return false;
    if (this.widgetSubstate != null && this.widgetSubstate !== b.widget_substate) return false;
    if (this.formStep != null && b.event_custom != null && this.formStep !== b.event_custom.step_information) return false;

    if (this.productName != null) {
      return b.product_name.some(function checkProduct(item) {
        return this.productName === item;
      });
    } else {
      return true;
    }
  };
}

(function setOptimizationConversionPoints(a, b) {
  /* This function takes the Tealium event ("a") and data layer ("b") and checks a list of mappings against them. these
  mappings define whether the interaction should be considered an optimization or conversion event. That fact will then be
  used in separate, vendor specific extenstions to trigger optimization or conversion pixels.

  All mappings will be checked, so theoretically a mapping from both optimizationMappings and conversionMappings could
  match, marking the interaction as both. */

  var optimizationMappings = [
    /* Set the conditions to mark interactions as conversions. Try to be as specific as possible to avoid conversions
    triggering where they shouldn't. Mappings take these 7 arguments:

    1. tealium_event*
    2. dom.pathname
    3. event_name/state_name
    4. widget_state
    5. widget_substate
    6. event_custom.step_information
    7. product_name**

    *This should always be provided and can only be one of two values: "view" for pageviews and "link" for events.
    **Since product_name in the data layer may contain an array of products, it will be checked to contain an exact match
    of a mapping's product name. (All other mapping properties are checked for exact matches.) */

    // Generic optimization events
    new Mapping('link', undefined, 'process/application-start', undefined, undefined, undefined, undefined),
    new Mapping('link', undefined, 'process/appointment-start', undefined, undefined, undefined, undefined),
    new Mapping('link', undefined, 'process/interaction-start', undefined, undefined, undefined, undefined),
    new Mapping('link', undefined, 'process/service-start', undefined, undefined, undefined, undefined),

    // SterCK flow
    new Mapping('view', undefined, 'init/state', 'opel-basic-Productinfo', undefined, undefined, undefined),

    // Woontool
    new Mapping('view', undefined, 'init/substate', undefined, 'insComReq.ComInsPayAccAndQues', undefined, undefined),
    new Mapping('view', undefined, 'init/substate', undefined, 'insComReq.ComInsPackageDetails', undefined, undefined),
    new Mapping('link', undefined, 'update/info', undefined, 'insComReq.ComInsPackageDetails', undefined, undefined),

    // ?
    new Mapping('view', undefined, 'init/state', 'forwhom', undefined, undefined, undefined),
    new Mapping('link', undefined, 'init/state', 'customerinfo', undefined, undefined, undefined),

    // GROW tool
    new Mapping('link', '/nl/prive/betalen/betaalpakketten/studenten-pakket/index.html', 'update/info', undefined, undefined, undefined, undefined),
    new Mapping('link', '/nl/prive/betalen/betaalpakketten/studenten-pakket/index1.html', 'update/info', undefined, undefined, undefined, undefined),
    new Mapping('link', '/nl/prive/betalen/betaalpakketten/studenten-pakket/index2.html', 'update/info', undefined, undefined, undefined, undefined),
  ];

  var conversionMappings = [
    /* See optimizationMappings for notes on how to fill this list. */

    // Generic conversion events
    new Mapping('link', undefined, 'process/application-end', undefined, undefined, undefined, undefined),
    new Mapping('link', undefined, 'process/appointment-end', undefined, undefined, undefined, undefined),
    new Mapping('link', undefined, 'process/interaction-end', undefined, undefined, undefined, undefined),
    new Mapping('link', undefined, 'process/service-end', undefined, undefined, undefined, undefined),
    new Mapping('link', undefined, 'process/endApplication', undefined, undefined, undefined, undefined),

    // SterCK flow
    new Mapping('view', undefined, 'init/state', 'opel-offer-OK-slider', undefined, undefined, undefined),
    new Mapping('view', undefined, 'init/state', 'opel-offer-manual-assessment', undefined, undefined, undefined),
    new Mapping('view', undefined, 'init/state', 'opel-offer-manual-assessment-prospect', undefined, undefined, undefined),
    new Mapping('view', undefined, 'init/state', 'opel-offer-decline', undefined, undefined, undefined),

    // Quiz: type student
    new Mapping('view', '/nl/prive/speciaal-voor/studenten/bijdehand/bedankt-acteur.html', undefined, undefined, undefined, undefined, undefined),
    new Mapping('view', '/nl/prive/speciaal-voor/studenten/bijdehand/bedankt-avonturier.html', undefined, undefined, undefined, undefined, undefined),
    new Mapping('view', '/nl/prive/speciaal-voor/studenten/bijdehand/bedankt-leider.html', undefined, undefined, undefined, undefined, undefined),
    new Mapping('view', '/nl/prive/speciaal-voor/studenten/bijdehand/bedankt-carrieretijger.html', undefined, undefined, undefined, undefined, undefined),
    new Mapping('view', '/nl/prive/speciaal-voor/studenten/bijdehand/bedankt-levensgenieter.html', undefined, undefined, undefined, undefined, undefined),
    new Mapping('view', '/nl/prive/speciaal-voor/studenten/bijdehand/bedankt-organisator.html', undefined, undefined, undefined, undefined, undefined),
    new Mapping('view', '/nl/prive/speciaal-voor/studenten/bijdehand/bedankt-denker.html', undefined, undefined, undefined, undefined, undefined),
    new Mapping('view', '/nl/prive/speciaal-voor/studenten/bijdehand/bedankt-dromer.html', undefined, undefined, undefined, undefined, undefined),

    // Vermogensbeheer
    new Mapping('view', '/nl/prive/beleggen/beleggingsvormen/vermogensbeheer/cmn-bedankt.html', undefined, undefined, undefined, undefined, undefined),

    // ?
    new Mapping('view', undefined, 'init/substate', 'investment.investmentGenericThanksAndFeedback', undefined, undefined, undefined),

    // AN-2532 New conversions lenen
    new Mapping('view', '/portalserver/mijn-abnamro/hypotheken/orientation-proposition/index.html', 'init/state', 'orientation-proposition-summary', undefined, undefined, undefined),
  ];

  /* Test all mappings against the current data layer ("b") and write the result back to the data layer. */
  b.is_optimization = optimizationMappings.some(function checkOptimization(item) {
    return item.test(a, b);
  }).toString();
  b.is_conversion = conversionMappings.some(function checkConversion(item) {
    return item.test(a, b);
  }).toString();

  return {
    is_optimization: b.is_optimization,
    is_conversion: b.is_conversion,
  };
}(a, b));

} } catch(e){ utag.DB(e) }  },
function(a,b){ try{ if(1){try{b['cookie_consent_old_level']=(b["cp.allowcookies"] ? JSON.parse(b["cp.allowcookies"])["allowCookies"] : "start");}catch(e){};try{b['cookie_consent_old_version']=(b['cp.allowcookies'] ? JSON.parse(b['cp.allowcookies']).version : undefined);}catch(e){};try{b['cookie_consent_state']=utag.gdpr.getConsentState();}catch(e){}} } catch(e){ utag.DB(e) }  },
function(a,b){ try{ if(1){
(function syncOldAndNewCookieConsent(b) {
  function setCookie(cname, cvalue, exdays, domain) {
    var d = new Date();
    d.setTime(d.getTime() + exdays * 24 * 60 * 60 * 1000);
    var expires = "expires=".concat(d.toUTCString());
    document.cookie = "".concat(cname, "=").concat(cvalue, ";").concat(expires, ";domain=").concat(domain, ";path=/");
  }

  var newConsentState = b.cookie_consent_state;
  var oldConsentState = 0; // -1 for declined, 0 for no choice made yet, 1 for accepted

  switch (b.cookie_consent_old_level) {
    case 'basic':
      oldConsentState = -1;
      break;

    case 'personal':
      oldConsentState = -1;
      break;

    case 'complete':
      oldConsentState = 1;
      break;

    default:
      oldConsentState = 0;
  }

  if (newConsentState !== oldConsentState) {
    var reverseSplitDomain = b['dom.domain'].split('.').reverse();
    var cookieDomain = ".".concat(reverseSplitDomain[1], ".").concat(reverseSplitDomain[0]);

    if (newConsentState === -1 && oldConsentState > -1) {
      setCookie('allowcookies', JSON.stringify({
        allowCookies: 'basic',
        version: 4
      }), 365, cookieDomain);
    } else if (newConsentState === 1 && oldConsentState < 1) {
      setCookie('allowcookies', JSON.stringify({
        allowCookies: 'complete',
        version: 4
      }), 365, cookieDomain);
    } else if (oldConsentState === -1) {
      utag.gdpr.setConsentValue(false);
    } else {
      utag.gdpr.setConsentValue(true);
    }
  } else if (newConsentState === 0 && !b.cookie_consent_old) {// Trust that Tealium's built-in logic fires the new cookie consent
  }
})(b);
} } catch(e){ utag.DB(e) }  },
function(a,b){ try{ if((b['tealium_event']=='link'&&typeof b['event_name']!='undefined')){
(function setEventVariables(b) {
  /* New implementations of event tracking, either through utag.link calls or through the node module, should always include
  event_name, _category, _action, _label and _is_interaction. This extension fills these in case these aren't filled, for
  example for older widget implementations. It is assumed that all events have at least the event_name variable, which is
  used to determine how to fill the others. */

  /* Set event_custom to prevent errors caused by trying to read properties from an undefined object */
  if (b.event_custom == null) b.event_custom = {};

  /* For every possible event name, you may add mappings to event_category, _action, _label and _is_interaction here. Please
  make sure that all of them are filled at all times, if necessary with "undefined". */
  switch (b.event_name) {
    case 'update:message':
      if (b.event_category == null) b.event_category = b.event_custom.message_type + ' messages';
      if (b.event_action == null) b.event_action = b.event_name;
      if (b.event_label == null) b.event_label = b.event_custom.message_key || 'undefined';
      if (b.event_is_interaction == null) b.event_is_interaction = 'false';
      break;
    case 'update:messageview':
      if (b.event_category == null) b.event_category = b.event_custom.message_type + ' messages';
      if (b.event_action == null) b.event_action = b.event_name;
      if (b.event_label == null) b.event_label = b.event_custom.message_key || 'undefined';
      if (b.event_is_interaction == null) b.event_is_interaction = 'true';
      break;
    case 'click:messageclick':
      if (b.event_category == null) b.event_category = b.event_custom.message_type + ' messages';
      if (b.event_action == null) b.event_action = b.event_name;
      if (b.event_label == null) b.event_label = b.event_custom.message_key || 'undefined';
      if (b.event_is_interaction == null) b.event_is_interaction = 'true';
      break;
    default:
      if (b.event_category == null) b.event_category = b.product_category || 'undefined';
      if (b.event_action == null) b.event_action = b.event_name;
      if (b.event_label == null) b.event_label = 'undefined';
      if (b.event_is_interaction == null) b.event_is_interaction = 'true';
  }

  /* Clean up event variables */
  if (typeof b.event_is_interaction == typeof true) b.event_is_interaction = b.event_is_interaction.toString();
  ['event_name', 'event_category', 'event_action', 'event_label', 'event_is_interaction'].forEach(
    function cleanUpEventVariables(variable) {
      if (b[variable] != null) {
        if (Array.isArray(b[variable])) b[variable] = b[variable].join(',');
        if (typeof b[variable] === 'string') {
          b[variable] = b[variable].toLowerCase();
          b[variable] = b[variable].trim();
        }
      } else {
        b[variable] = 'undefined';
      }
    }
  );

  return {
    event_name: b.event_name,
    event_category: b.event_category,
    event_action: b.event_action,
    event_label: b.event_label,
    event_is_interaction: b.event_is_interaction,
    event_custom: b.event_custom,
  }
}(b));

} } catch(e){ utag.DB(e) }  },
function(a,b){ try{ if(1){try{b['dom.viewport_orientation']=(b['dom.viewport_height'] > b['dom.viewport_width'] ? 'portrait' : 'landscape');}catch(e){};try{b['browser_is_mobile']=(function isMobile(a) {   return String(/(android|bb\d+|meego).+mobile|avantgo|bada\/|blackberry|blazer|compal|elaine|fennec|hiptop|iemobile|ip(hone|od)|iris|kindle|lge |maemo|midp|mmp|mobile.+firefox|netfront|opera m(ob|in)i|palm( os)?|phone|p(ixi|re)\/|plucker|pocket|psp|series(4|6)0|symbian|treo|up\.(browser|link)|vodafone|wap|windows ce|xda|xiino/i.test(a) || /1207|6310|6590|3gso|4thp|50[1-6]i|770s|802s|a wa|abac|ac(er|oo|s-)|ai(ko|rn)|al(av|ca|co)|amoi|an(ex|ny|yw)|aptu|ar(ch|go)|as(te|us)|attw|au(di|-m|r |s )|avan|be(ck|ll|nq)|bi(lb|rd)|bl(ac|az)|br(e|v)w|bumb|bw-(n|u)|c55\/|capi|ccwa|cdm-|cell|chtm|cldc|cmd-|co(mp|nd)|craw|da(it|ll|ng)|dbte|dc-s|devi|dica|dmob|do(c|p)o|ds(12|-d)|el(49|ai)|em(l2|ul)|er(ic|k0)|esl8|ez([4-7]0|os|wa|ze)|fetc|fly(-|_)|g1 u|g560|gene|gf-5|g-mo|go(\.w|od)|gr(ad|un)|haie|hcit|hd-(m|p|t)|hei-|hi(pt|ta)|hp( i|ip)|hs-c|ht(c(-| |_|a|g|p|s|t)|tp)|hu(aw|tc)|i-(20|go|ma)|i230|iac( |-|\/)|ibro|idea|ig01|ikom|im1k|inno|ipaq|iris|ja(t|v)a|jbro|jemu|jigs|kddi|keji|kgt( |\/)|klon|kpt |kwc-|kyo(c|k)|le(no|xi)|lg( g|\/(k|l|u)|50|54|-[a-w])|libw|lynx|m1-w|m3ga|m50\/|ma(te|ui|xo)|mc(01|21|ca)|m-cr|me(rc|ri)|mi(o8|oa|ts)|mmef|mo(01|02|bi|de|do|t(-| |o|v)|zz)|mt(50|p1|v )|mwbp|mywa|n10[0-2]|n20[2-3]|n30(0|2)|n50(0|2|5)|n7(0(0|1)|10)|ne((c|m)-|on|tf|wf|wg|wt)|nok(6|i)|nzph|o2im|op(ti|wv)|oran|owg1|p800|pan(a|d|t)|pdxg|pg(13|-([1-8]|c))|phil|pire|pl(ay|uc)|pn-2|po(ck|rt|se)|prox|psio|pt-g|qa-a|qc(07|12|21|32|60|-[2-7]|i-)|qtek|r380|r600|raks|rim9|ro(ve|zo)|s55\/|sa(ge|ma|mm|ms|ny|va)|sc(01|h-|oo|p-)|sdk\/|se(c(-|0|1)|47|mc|nd|ri)|sgh-|shar|sie(-|m)|sk-0|sl(45|id)|sm(al|ar|b3|it|t5)|so(ft|ny)|sp(01|h-|v-|v )|sy(01|mb)|t2(18|50)|t6(00|10|18)|ta(gt|lk)|tcl-|tdg-|tel(i|m)|tim-|t-mo|to(pl|sh)|ts(70|m-|m3|m5)|tx-9|up(\.b|g1|si)|utst|v400|v750|veri|vi(rg|te)|vk(40|5[0-3]|-v)|vm40|voda|vulc|vx(52|53|60|61|70|80|81|83|85|98)|w3c(-| )|webc|whit|wi(g |nc|nw)|wmlb|wonu|x700|yas-|your|zeto|zte-/i.test(a.substr(0, 4))); }(navigator.userAgent || navigator.vendor || window.opera));}catch(e){};try{b['dom.viewport_widthxheight']=b['dom.viewport_width'] + 'x' + b['dom.viewport_height'];}catch(e){}} } catch(e){ utag.DB(e) }  },
function(a,b){ try{ if(1){try{b['tealium_timestamp_date_object']=(function getDateObjectFromEpoch(timestampEpoch) {   var dateObject = new Date(0);   dateObject.setUTCSeconds(timestampEpoch);   return dateObject; })(b.tealium_timestamp_epoch);}catch(e){};try{b['tealium_timestamp_local_offset']=(function getTimestampWithOffset(dateObject, timestampLocal) {   var timeZone = dateObject.getTimezoneOffset();   var timeZoneSign = timeZone < 0 ? '+' : '-';   var timeZoneHours = "00".concat(parseInt(Math.abs(timeZone) / 60, 10)).slice(-2);   var timeZoneMinutes = "00".concat(Math.abs(timeZone) / 60 % 1).slice(-2);   return "".concat(timestampLocal).concat(timeZoneSign).concat(timeZoneHours, ":").concat(timeZoneMinutes); })(b.tealium_timestamp_date_object, b.tealium_timestamp_local);}catch(e){};try{b['tealium_timestamp_day_of_week']=(function getDayOfWeek(dateObject) {   return {     0: 'Sunday',     1: 'Monday',     2: 'Tuesday',     3: 'Wednesday',     4: 'Thursday',     5: 'Friday',     6: 'Saturday'   }[dateObject.getDay()]; })(b.tealium_timestamp_date_object);}catch(e){};try{b['tealium_timestamp_time_of_day']=(function getTimeOfDay(dateObject) {   var HH = "00".concat(dateObject.getHours()).slice(-2);   var MM = dateObject.getMinutes() >= 30 ? '30' : '00';   return "".concat(HH, ":").concat(MM); })(b.tealium_timestamp_date_object);}catch(e){}} } catch(e){ utag.DB(e) }  },
function(a,b){ try{ if(1){try{b['random_uuid']=(function() {return 'xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx'.replace(/[xy]/g, function(c) {var r = Math.random() * 16 | 0, v = c == 'x' ? r : (r & 0x3 | 0x8); return v.toString(16);});})();}catch(e){}} } catch(e){ utag.DB(e) }  },
function(a,b){ try{ if(typeof b['cp.UVID']=='undefined'){document.cookie="UVID="+b['random_uuid']+";path=/;domain="+utag.cfg.domain+";expires="+(function(){var d=new Date();d.setTime(d.getTime()+(30*86400000)); return d.toGMTString()})()+"";b['cp.UVID']=b['random_uuid'];}} catch(e){ utag.DB(e) } },
function(a,b,c,d,e,f,g){if(1){d=b['tealium_session_number'];if(typeof d=='undefined')return;c=[{'^([2-9]|\\d{2,})$':'Repeat'}];var m=false;for(e=0;e<c.length;e++){for(f in c[e]){g=new RegExp(f,'i');if(g.test(d)){b['user_new_repeat']=c[e][f];m=true};};if(m)break};if(!m)b['user_new_repeat']='New';   }},
function(a,b){ try{ if(1){
(function appendToPageName(b) {
  if (b.event_custom != null && b.event_custom.step_information != null) {
    b.page_name += ":".concat(b.event_custom.step_information);
  } else if (
    b._tracking_data != null &&
    b._tracking_data.stepInformation != null
  ) {
    // Note that the _tracking_data object is temporary until AN-2417 is live. From then, use event_custom instead
    b.page_name += ":".concat(b._tracking_data.stepInformation);
  } else if (b.widget_substate != null && b.widget_substate !== "not set") {
    // Note that the 'not set' bit of this condition is temporary until AN-2417 is live
    b.page_name += ":".concat(b.widget_substate);
  } else if (b.widget_state != null && b.widget_state !== "not set") {
    // Note that the 'not set' bit of this condition is temporary until AN-2417 is live
    b.page_name += ":".concat(b.widget_state);
  }

  b.page_name = b.page_name.toLowerCase();
})(b);

} } catch(e){ utag.DB(e) }  },
function(a,b){ try{ if(1){
(function getAdobeTargetPcid(b) {
  if (window.mboxFactoryDefault && typeof window.mboxFactoryDefault.getPCId === 'function') {
    /* First, try to use Adobe Target's getPCId function */
    b.adobe_target_pcid = window.mboxFactoryDefault.getPCId().getId();
  } else {
    /* Otherwise, get it from the mbox cookie */
    const mboxCookie = b['cp.mbox'];
    if (mboxCookie != null) {
      const mboxSplit = mboxCookie.split('|');
      for (let i = 0; i < mboxSplit.length; i++) {
        if (mboxSplit[i].indexOf('PC#') === 0) {
          b.adobe_target_pcid = mboxSplit[i].split('#')[1];
        }
      }
    }
  }
}(b));

} } catch(e){ utag.DB(e) }  },
function(a,b,p){ try{  utag.runonce = utag.runonce || {};utag.runonce.ext = utag.runonce.ext || {};  if(typeof utag.runonce.ext[89]=='undefined'){    utag.runonce.ext[89]=1;    var tags = [], cp = b['cp.CONSENTMGR'], tag, opts, i;    if (!cp || cp.indexOf('consent:true') === -1){        __TEALIUM.adobe.target.css.remove();        return;     }    if (!cp) { return; }    for ( var i = 0; i < tags.length ; i++){      tag = utag.loader.cfg[tags[i]];      if (tag.tcat){          if (cp.indexOf('c'+tag.tcat+':0') != -1) {                __TEALIUM.adobe.target.css.remove();          }      } else {          opts = cp.split('|');          for (var j=0;j<opts.length;j++){              if (opts[j] == tag.tid + ':1'){                  __TEALIUM.adobe.target.css.remove();              }          }      }    }   }} catch(e){ utag.DB(e) }  }];
  utag.handler.cfg_extend=[{"blr":1,"bwq":0,"alr":0,"id":"285","end":0},{"end":0,"id":"286","alr":0,"blr":1,"bwq":0},{"bwq":0,"blr":1,"end":0,"id":"287","alr":0},{"bwq":0,"blr":1,"end":0,"id":"288","alr":0},{"bwq":0,"blr":1,"alr":0,"end":0,"id":"299"},{"bwq":0,"blr":1,"end":0,"id":"189","alr":0},{"alr":0,"id":"190","end":0,"bwq":0,"blr":1},{"id":"301","end":0,"alr":1,"bwq":0,"blr":0},{"end":0,"id":"290","alr":1,"blr":0,"bwq":0},{"alr":1,"id":"291","end":0,"bwq":0,"blr":0},{"id":"292","end":0,"alr":1,"bwq":0,"blr":0},{"end":0,"id":"293","alr":1,"blr":0,"bwq":0},{"bwq":0,"blr":0,"end":0,"id":"294","alr":1},{"alr":1,"id":"297","end":0,"bwq":0,"blr":0},{"alr":1,"id":"298","end":0,"bwq":0,"blr":0},{"blr":0,"bwq":0,"alr":1,"id":"89","end":0}];
  utag.loader.initcfg = function(){
    utag.loader.cfg={"124":{load:4,tcat:0,send:1,v:201909250650,wait:0,tid:1191},"125":{load:1,tcat:0,send:1,v:201910010811,wait:1,tid:19063},"16":{load:utag.cond[48],tcat:0,send:1,v:201910021200,wait:1,tid:4049},"22":{load:utag.cond[48],tcat:0,send:1,v:201910021200,wait:1,tid:4049},"77":{load:(utag.cond[48] && utag.cond[6]),tcat:0,send:1,v:201910021200,wait:1,tid:6026},"18":{load:utag.cond[48],tcat:0,send:1,v:201910011454,wait:1,tid:7133},"66":{load:(utag.cond[48] && utag.cond[6]),tcat:0,send:1,v:201908011422,wait:1,tid:12047},"26":{load:utag.cond[48],tcat:0,send:1,v:201908011422,wait:1,tid:20010},"45":{load:utag.cond[48],tcat:0,send:1,v:201910021200,wait:1,tid:18046},"67":{load:(utag.cond[48] && utag.cond[6]),tcat:0,send:1,v:201908070705,wait:1,tid:19129},"126":{load:(utag.cond[47] && utag.cond[79]),tcat:0,send:1,v:201909300736,wait:1,tid:21004},"57":{load:utag.cond[31],tcat:0,send:1,v:201909191258,wait:1,tid:20064}};
utag.loader.cfgsort=["124","125","16","22","77","18","66","26","45","67","126","57"];
  }
utag.loader.initcfg();
try {utag.gdpr.applyConsentState();} catch(e) {utag.DB(e)}}
//tealium universal tag - utag.gdpr ut4.0.##UTVERSION##, Copyright ##UTYEAR## Tealium.com Inc. All Rights Reserved.
//tv:2.0.1
utag.gdpr = {
    consent_prompt: {
        noShow: false,
        isEnabled: true,
        content: {}
    },
    preferences_prompt: {
        single_cookie: false,
        noShow: false,
        isEnabled: false,
        defaultState: true,
        content: {},
        categories: {"engagement":{"enabled":1,"id":13},"affiliates":{"enabled":1,"id":2},"monitoring":{"enabled":1,"id":14},"social":{"enabled":1,"id":7},"big_data":{"id":8,"enabled":1},"personalization":{"id":6,"enabled":1},"mobile":{"enabled":1,"id":12},"analytics":{"enabled":1,"id":1},"search":{"id":4,"enabled":1},"misc":{"id":9,"enabled":1},"crm":{"enabled":1,"id":15},"email":{"enabled":1,"id":5},"cdp":{"id":11,"enabled":1},"display_ads":{"id":3,"enabled":1},"cookiematch":{"enabled":1,"id":10}}
    },
    getCategories: function(onlyEnabledCats) {
      if (!(utag.gdpr.preferences_prompt && utag.gdpr.preferences_prompt.categories)) {
        return [];
      }
      var length =  utag.gdpr.keys(utag.gdpr.preferences_prompt.categories).length,
          cats = new Array(length),
          gdpr_cats = utag.gdpr.preferences_prompt.categories;
      for (var cat in gdpr_cats) {
        if (!gdpr_cats.hasOwnProperty(cat)) { continue; }
        if (onlyEnabledCats && !gdpr_cats[cat].enabled) { continue; }
        cats[gdpr_cats[cat].id-1] = cat;
      }

      for (var i = cats.length -1; i >= 0; i--) {
        if (cats[i] === undefined) {
          cats.splice(i, 1);
        }
      }

      return cats;
    },
    getSelectedCategories: function(){
        var sc = [], gc = utag.gdpr.getCategories(), cs = utag.gdpr.getConsentState(), i;

        try {
            if (typeof cs === "number") {
                return (parseInt(cs) === 1) ? gc : sc;
            } else {
                for (i in utag.loader.GV(cs)) {
                    if ("1" === cs[i].ct){
                        sc.push(gc[i]);
                    }
                }
            }
        } catch (e) {utag.DB(e);}

        return sc;
    },

    getCategoryLanguage: function(category) {
        if (!(utag.gdpr.preferences_prompt && utag.gdpr.preferences_prompt.categories)) {
            return [];
        }
        var language = utag.gdpr.getLanguage(utag.gdpr.preferences_prompt);
        return utag.gdpr.preferences_prompt.languages[language].categories[category];
    },
    getConsentState: function() {
      var re         = /^c\d+/,
          cd         = utag.gdpr.getCookieValues(),
          np         = 1,
          gc         = utag.gdpr.getCategories(),
          pc         = (function(gc){
            var pc = [];
            for (var i = 0; i < gc.length; i++) {
              pc.push({
                ct  : null,
                name: gc[i]
              });
            }
            return pc;
          }(gc)),
          filteredCD = (function (cd) {
            var d = {};
            for (var prop in cd) {
              if (!cd.hasOwnProperty(prop)) {
                continue;
              }
              if (re.test(prop)) {
                d[prop] = cd[prop];
              }
            }
            return d;
          }(cd));

      filteredCD = utag.gdpr.sortedObject(filteredCD, function (val1, val2) {
        var idx1 = parseInt((val1 || "").substring(1), 10),
            idx2 = parseInt((val2 || "").substring(1), 10);
        if (isNaN(idx1) || isNaN(idx2)) {
          return 0;
        }
        return idx1 > idx2 ? 1 : -1;
      });

      for (var cn in utag.loader.GV(filteredCD)) {
        if (cn.match(re)) {
          var idx = parseInt(cn.substring(1), 10) - 1,
              ct  = gc[idx];
          pc[idx].ct = cd[cn];
          if (cd[cn] * 1 !== 1) {
            np = 0;
          }
        }
      }
      if (cd.consent) {
        if (cd.consent === true || cd.consent === "true") {
          return np ? np : pc;
        } else {
          return -1;
        }
      } else if (np === 0) {
        return pc;
      } else {
        return 0;
      }
    },
    getCookieValues: function() {
        var values = {},
        rcd = (function(){
            var value = "; " + document.cookie;
            var parts = value.split("; CONSENTMGR=");
            if (parts.length == 2) return  utag.ut.decode(parts.pop().split(";").shift());
        }()),
        cd = utag.gdpr.typeOf(rcd) === "string" ? rcd : "";

        if (utag.data) {
          utag.data["cp.CONSENTMGR"] =  cd;
        }

        if (cd){
            var i,
                optOut,
                optOutData = decodeURI(cd).split("|");
            for (i = 0; i < optOutData.length; i++) {
                optOut = optOutData[i].split(":");
                values[optOut[0]] = optOut[1];
            }
        }
        utag.gdpr.values = values;
        return values;
    },
    getDeTokenizedContent: function(data, _lang) {
      if(utag.gdpr.isEmpty(data)) return null;

        var reg = /{{(.*?)}}/gm,
            token_match = /[{}]/g,
            two_part = /display_ads|big_data/;


        var lang = utag.gdpr.getLanguage(data, _lang),
            langData = data.languages[lang];

        for (var t in langData.common_tokens) {
            if (!langData.common_tokens.hasOwnProperty(t)) {
                continue;
            }
            var replacements = langData.common_tokens[t].match(reg);
            if (replacements) {
                for (var i = 0; i < replacements.length; i++) {
                    var token = replacements[i].replace(token_match, "");
                    langData.common_tokens[t] = langData.common_tokens[t].replace(replacements[i], langData.custom_tokens[token]);
                }
            }
        }

        function tokenReplace(str) {
            var replacements = str.match(reg);
            if (replacements) {
                for (var i = 0; i < replacements.length; i++) {
                    var token = replacements[i].replace(/[{}]/g, "") || "";
                    if (langData.common_tokens[token]) {
                        str = str.replace(replacements[i], langData.common_tokens[token]);
                    } else if (langData.custom_tokens[token]) {
                        str = str.replace(replacements[i], langData.custom_tokens[token]);
                    } else if (langData.categories && token.indexOf("category_") > -1) {
                        var split_token = token.split("_");
                        if (token.match(two_part)){
                            split_token[1] = split_token[1] + '_' + split_token[2];
                            split_token.splice(2,1);
                        }
                        var category = langData.categories[split_token[1]],
                            key = {
                                "title": "name",
                                "description": "notes"
                            }[split_token[2]];
                        if (category[key]) {
                            str = str.replace(replacements[i], category[key]);
                        }
                    }
                }
            }
            return str;
        }

        return {
            js: tokenReplace(data.content.js),
            html: tokenReplace(data.content.html),
            css: tokenReplace(data.content.css)
        };
    },
    getLanguage: function(promptData, preferredLang) {
      var udoName = window.utag.udoname || "utag_data";
      var dataObject = window.utag.data || window[udoName];
      var langLocale = (preferredLang || dataObject[window.utag.cfg.gdprDLRef] || (navigator.languages && navigator.languages[0] || navigator.language || navigator.userLanguage)).toLowerCase();
      var lang = (langLocale || "").split("-")[0];
      if(!promptData){return langLocale;}
      var languages = promptData.languages;
      return languages[langLocale] ? langLocale : languages[lang] ? lang : promptData.defaultLang;
    },
    getTokenLanguage: function(promptData, token, lang) {
        if (utag.gdpr.isEmpty(promptData)) return null;

        lang = lang || utag.gdpr.getLanguage(promptData);
        var langData = promptData.languages[lang];

        if (utag.gdpr.isEmpty(langData)) return null;
        if (utag.gdpr.isEmpty(promptData)) return null;
        if (utag.gdpr.isEmpty(token)) return null;

        if (langData.common_tokens[token]) {
            return langData.common_tokens[token];
        } else if (langData.custom_tokens[token]) {
        return langData.custom_tokens[token];
        } else if (langData.categories && token.indexOf("category_") > -1) {
            var split_token = token.split("_"),
                category = langData.categories[split_token[1]];
            if (category[split_token[2]]) {
                return category[split_token[2]];
            }
        }

        return null;
    },
    setCookie: function(cookieData) {
      utag.DB("Consent Manager: Set Cookie");
      if (utag.gdpr.typeOf(cookieData) !== "object") {
        return;
      }

      if (utag.gdpr.keys(cookieData).length === 0){
        return;
      }

      if (utag.gdpr.typeOf(cookieData.consent) !== "boolean" &&
        !(utag.gdpr.typeOf(cookieData.consent) === "string" && (cookieData.consent.toLowerCase() === "true" || cookieData.consent.toLowerCase() === "false"))){
        utag.DB("Invlaid option sent to setCookie [consent must be true/false]");
        return;
      }

      if (utag.gdpr.typeOf(cookieData.ts) !== "number" || (cookieData.ts.toString().length !== 13)){
        cookieData.ts = new Date().getTime();
      }

      var cp = utag.cfg.consentPeriod || 90;

      utag.gdpr.values = cookieData;

      var mo2Val = [];

      for (var i in utag.loader.GV(cookieData)) {

        if (/^(consent|ts|c\d+)$/.test(i)) {
          mo2Val.push(i + ":" + cookieData[i]);
        } else {
          utag.DB("Invlaid option sent to setCookie ["+i+"], is unkown");
        }
      }
      var cD = new Date();
      cD.setDate(cD.getDate() + cp);
      document.cookie = "CONSENTMGR=" + encodeURI(mo2Val.join("|")) + ";domain=" + utag.cfg.domain + ";path=/; expires=" + cD.toGMTString() + ";";
      utag.data["cp.CONSENTMGR"] = mo2Val.join("|"); // Keep utag.data in sync with what's in the cookie
    },
    setCookieValue: function(key, value) {
      utag.DB("Consent Manager: Set Cookie Value");
      if (!key || (utag.gdpr.typeOf(value) === "undefined" || utag.gdpr.typeOf(value) === "null")) return;
        var cookieData = utag.handler.C(utag.gdpr.getCookieValues());
        cookieData[key] = value;

        utag.gdpr.setCookie(cookieData);
    },
    setConsentValue: function(_response) {
      utag.DB("Consent Manager: Set Consent Value: "+ _response);
      var valid = {true:1, "true":1,1:1,false:0, "false":0,0:0};
        if (!valid.hasOwnProperty(_response)) {
            throw new Error("No response supplied");
        }
        var response = valid[_response] === 1;
        utag.gdpr.setCookieValue("ts", new Date().getTime()); //timestamp
        utag.gdpr.setCookieValue("consent", response); //response

        utag.gdpr.processQueue(response);
        
    },
    setPreferencesValues: function(categories,noCollect) {
      utag.DB("Consent Manager: Set Preferences Values");
        var cookie_data = utag.gdpr.getCookieValues(), lookup = {}, i, rgx = /\D/,
            names = utag.gdpr.getCategories() , chosen_list = [],
            consent_seen = false, decline_seen = false, crgx = /c\d/, fld;

        if (utag.gdpr.typeOf(categories) !== "object"){
          utag.DB("Categories is not type object.");
          return;
        }

        try {
            for (i = 0; i < names.length; i++){
                lookup[names[i]] = 'c' + (i+1);
            }
            for (var cat in categories) {
                if (!categories.hasOwnProperty(cat)) {
                    continue;
                }
                if (categories[cat] !== "1" && categories[cat] !== "0" && categories[cat] !== 1 && categories[cat] !== 0 ) {
                  continue;
                }
                if (cat.match(rgx)){
                    cookie_data[lookup[cat]] = categories[cat];
                    if (categories[cat] != 0){
                        chosen_list.push(cat);
                    }
                }else{
                    cookie_data["c" + cat] = categories[cat];
                    if (categories[cat] != 0){
                        chosen_list.push(names[cat - 1]);
                    }
                }

            }

            for (fld in utag.loader.GV(cookie_data)) {
                if (fld.match(crgx)) {
                    if (cookie_data[fld] != 0){
                        consent_seen = true;
                    } else {
                        decline_seen = true;
                    }
                }
            }
            cookie_data["ts"] = new Date().getTime();
            cookie_data["consent"] = consent_seen;
            utag.gdpr.setCookie(cookie_data);
            utag.gdpr.processQueue(consent_seen);
        } catch (e) {
            utag.DB(e);
        }

        if (noCollect){
            return;
        }

        
    },
    setAllCategories: function(state,noCollect){
      utag.DB("Consent Manager: Set Preferences All Categories: "+state);
      if (state === undefined) return;
      if (utag.gdpr.typeOf(state) !== "boolean") return ;
      var allCats = utag.gdpr.getCategories(),prefs = {};
      for (var i=0; i < allCats.length; i++){
        prefs[""+(i+1)] = state ? "1" : "0";
      }
       utag.gdpr.setPreferencesValues(prefs,noCollect);
    },
    setPreferencesFromList:function(list) {
      utag.DB("Consent Manager: Set Preferences From List");
      var prefs = {}, allCats = utag.gdpr.getCategories();
      if (utag.gdpr.typeOf(list)!=="array"){
        utag.DB("List should be of type array");
        return;
      }
      for (var i = 0; i < list.length; i++) {
        prefs[list[i]] = "1";
      }
      for (var j = 0; j < allCats.length; j++) {
        if (!prefs[allCats[j]]) {
          prefs[allCats[j]] = "0";
        }
      }
      utag.gdpr.setPreferencesValues(prefs);
    },
    refreshCookie: function() {
  try {
    utag.gdpr.setCookie(utag.gdpr.getCookieValues());
  } catch (e) {}
},
    processQueue: function(consent_seen){
      utag.DB("Consent Manager: Processing Consent Queue");
      if (utag.gdpr.noqueue) { return; }
      if (!consent_seen) { utag.gdpr.queue = []; return;}
      utag.DB("Consent Manager: Processing Consent Queue Length: " + utag.gdpr.queue.length);
        var event, data, conds = {};

        //create a new cond object for us to modify
        utag.gdpr.merge(conds, utag.cond);

        for (var i = 0; i < utag.gdpr.queue.length; i++) {
          event = utag.gdpr.queue[i];
          if (!(event.cfg && event.cfg.uids)) {
            data = {};
            //Copy core data over
            utag.loader.RD(data, event.event);
            //Copy data user sent
            utag.gdpr.merge(data, event.data);

            //Make sure we reset all conds to 0/false;
            for (var cond in conds) {
              if (!conds.hasOwnProperty(cond)) {continue;}
              conds[ cond ] = 0;
            }

            //Find out what LRs trigger for the data we have
            utag.loader.loadrules(data, conds);

            event.cfg = event.cfg || {};
            event.cfg.uids = [];

            //Store conds into utag.conds so that the initcfg can pull them in for setting the tags (& any future extensions)
            utag.cond = conds;
            //Call initcfg so we can get utag.loader.cfg[X].load evaluated
            utag.loader.initcfg();

            //create an array of UIDs to call, excluding the omittedTags as they have already fired.
            for (var id in utag.loader.GV(utag.loader.cfg)) {
              if(!utag.gdpr.omittedTags[id] && utag.loader.cfg[id].load) {
                event.cfg.uids.push(id);
              }
            }
          }
          //call old track call with data from the array
          //call - this is correct as we are using the stored event as an object
          utag.track_old.call(this, event);
        }

        utag.gdpr.queue = [];

    },
    typeOf: function(e) {
      return ({}).toString.call(e).match(/\s([a-zA-Z]+)/)[1].toLowerCase();
    },
    merge: function(a, b, c, d) {
      if (c) {
        for (d in utag.loader.GV(b)) {
          a[d] = b[d];
        }
      } else {
        for (d in utag.loader.GV(b)) {
          if (typeof a[d] == "undefined")
            a[d] = b[d];
        }
      }
    },
    applyConsentState: function(){
      utag.DB("Consent Manager: Applying consent");
      try {
        var i, lc = utag.loader.cfg, cs = utag.gdpr.getConsentState(),
            ot = utag.gdpr.omittedTags;
        if (typeof cs === "number") {

          if ((utag.gdpr.consent_prompt.isEnabled && parseInt(cs) !== 1) ||
            ((!utag.gdpr.consent_prompt.isEnabled && utag.gdpr.preferences_prompt.isEnabled) && parseInt(cs) === -1)) {
            utag.DB("Consent Manager: Setting all tags to off");
            for (i in utag.loader.GV(lc)) {
              if (typeof ot[i] === "undefined") {
                lc[i].load = 0;
              }
            }
          }
        } else { //# partial consent
          utag.DB("Consent Manager: Partial Consent");
          for (i in utag.loader.GV(lc)) {
            if (typeof ot[i] === "undefined") {
              if (lc[i].tcat > 0 && cs[lc[i].tcat - 1].ct == 0) {
                lc[i].load = 0;
              }
            }
          }
        }

      } catch (e) {
        utag.DB(e);
      }
    },
    updateConsentCookie:function(consent_categories){
      utag.DB("Consent Manager: Updating consent cookie");
      var list,
          listType = utag.gdpr.typeOf(consent_categories);
      if (listType === "string") {
        list = consent_categories.split(/\s*,\s*/);
      } else if (listType !== "array") {
        list = [];
      } else {
        list = consent_categories.slice();
      }

      if (list.length === 0) {
        utag.gdpr.setConsentValue(false);
        utag.gdpr.setAllCategories(false);
        return;
      } else {
        utag.gdpr.setConsentValue(true);
      }

      utag.gdpr.setPreferencesFromList(list);
    },
    keys : function(obj) {
      if (Object.keys) {return Object.keys(obj);}
      var array = [];
      for (var prop in obj) {
        if (!obj.hasOwnProperty(prop)) {continue;}
        array.push(prop);
      }
      return array;
    },
    sortedObject : function (obj, func) {
      var _obj = {};
      if (obj !== undefined) {
        var _k1 = utag.gdpr.keys(obj).sort(func);
        for (var z = 0; z < _k1.length; z++) {
          _obj[_k1[z]] = obj[_k1[z]];
        }
      }
      return _obj;
    },
    isEmpty: function(obj){
      var t = utag.gdpr.typeOf(obj);
      switch(t){
        case "string":
        case "array":
          return obj.length === 0;
        case "object":
          for (var p in obj) {
            if (!obj.hasOwnProperty(p)) {continue;}
            return false;
          }
        default:
          return true;
      }
    },
    queue : [],
    noqueue : window.utag_cfg_ovrd ? window.utag_cfg_ovrd.nogdprqueue : false,
    noview: window.utag_cfg_ovrd ? window.utag_cfg_ovrd.noview : false,
    omittedTags:{"124":1,"28":1,"125":1}
};

utag.loader.initdataOld = utag.loader.initdata;
utag.loader.initdata = function() {
  utag.loader.initdataOld();
  if (utag.gdpr.getConsentState() !== 0) return;
  if (utag.gdpr.noview) return;
  if (!utag.loader.rd_flag && !utag.gdpr.noqueue){utag.gdpr.queue.push({event: "view", data:utag.handler.C(utag.data)});}
};

utag.preOld = utag.pre;
utag.pre = function() {
  utag.preOld();
  //Only trigger the first time
    if (utag.gdpr.consent_prompt.isEnabled === true && ! (utag.cond[53])) {
      utag.gdpr.consent_prompt.isEnabled = false;
    }
  utag.pre = utag.preOld;
};

utag.gdpr.consent_prompt.languages={"en":{"custom_tokens":{"personal_item_2":"Cookies for advertising and relevant offers for our products and services on third-party websites.","decline_button":"I do not accept","functional_title":"Functional","settings_message":"The cookies we will set if you click ‘I accept’ are listed below. If you do not give your consent, we will set functional cookies only. These cookies are essential for the site to work as expected and for collecting metrics and will be anonymised. If you want to know more about what a cookie is and what it does, please refer to <a href=\"https://www.abnamro.nl/en/personal/overabnamro/privacy/cookie-statement.html\" class=\"btn-link\">our cookie statement</a>.","functional_item_1":"Functional cookies for mobile banking or internet banking and optimisation of abnamro.nl.","personal_title":"Personal","functional_item_2":"Analytical cookies that we use to measure visits to our website.","personal_item_1":"Cookies used for advertising and relevant offers for our products and services.","setting_heading":"Cookie settings"},"display_name":"English (en)","common_tokens":{"title":"ABN AMRO uses cookies","confirmation_button":"I accept","message":"ABN AMRO uses cookies and similar technologies to analyse how visitors use our website, to enable content sharing on social media and to tailor site content and advertising to your preferences. Such cookies are also set by third parties. By clicking 'I accept',  you consent to this. \n<span class=\"d-inline d-md-none\">See our cookie settings below</span> \n<span class=\"d-none d-md-inline\">See <a class=\"btn-link\" id=\"aab-cookie-consent-toggle-hide\">our cookie settings</a></span> for a description of the cookies for which we ask your consent."},"isDefault":"false"},"nl":{"custom_tokens":{"functional_title":"Functioneel","decline_button":"Niet akkoord","personal_item_2":"Cookies voor advertenties en relevante aanbiedingen over onze producten en diensten ook op de sites van derden.","functional_item_1":"Functionele cookies voor (mobiel) internetbankieren en het optimaliseren van abnamro.nl","settings_message":"Hieronder leest u welke soort cookies wij plaatsen als u op \"akkoord\" klikt. Geeft u uw akkoord liever niet? Dan plaatsen we slechts functionele cookies. Deze zijn noodzakelijk voor het goed functioneren van de site en het uitvoeren van metingen.                 Dit gebeurt anoniem. Wilt u meer lezen over wat een cookie is en doet? Dit kunt lezen in het <a href=\"https://www.abnamro.nl/nl/prive/abnamro/privacy/cookie-statement.html\" class=\"btn-link\">cookie statement</a>.","functional_item_2":"Analytische cookies waarmee wij het bezoek aan onze website meten","personal_title":"Persoonlijk","setting_heading":"Cookie-instellingen","personal_item_1":"Cookies voor advertenties en relevante aanbiedingen over onze producten en diensten."},"display_name":"Dutch (nl)","isDefault":"true","common_tokens":{"title":"ABN AMRO gebruikt cookies","confirmation_button":"Akkoord","message":"ABN AMRO maakt gebruik van cookies en vergelijkbare technieken om het gebruik van de website analyseren, om het mogelijk te maken content via social media te delen en om de inhoud van de  site en advertenties af te stemmen op uw voorkeuren. Deze cookies worden ook geplaatst door derden. Door akkoord te klikken, stemt u hiermee in. Een omschrijving van de cookies waarvoor wij uw akkoord vragen leest u hieronder<span class=\"d-inline d-md-none\">.</span><span class=\"d-none d-md-inline\"> in <a class=\"btn-link\" id=\"aab-cookie-consent-toggle-hide\">onze cookie-instellingen.</a></span>"}}};utag.gdpr.consent_prompt.content.css=".aab-cookie-consent {  padding: 24px;  background: white;  box-shadow: 0 12px 24px 0 rgba(34, 34, 34, 0.4), 0 0 10px 0 rgba(34, 34, 34, 0.02);  position: fixed;  bottom: 0;  left: 0;  right: 0;  color: #222;  font-family: \"Roboto\";  font-weight: 400;  text-align: center;  z-index: 999;}.aab-cookie-consent .aab-cc-container {  max-width: 1272px;  width: 100%;  text-align: left;  display: inline-block;}/* Header Styles */.aab-cookie-consent .header {  min-height: 72px;  display: inline-block;}.aab-cookie-consent .header .icon {  display: inline-block;  background: url(\'data:image/svg+xml;base64,PHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHdpZHRoPSI3MiIgaGVpZ2h0PSI3MiIgdmlld0JveD0iMCAwIDcyIDcyIj4KICAgIDxkZWZzPgogICAgICAgIDxsaW5lYXJHcmFkaWVudCBpZD0iYSIgeDE9Ijg4LjgzOSUiIHgyPSIyOS4wNTIlIiB5MT0iLTI5LjE1MyUiIHkyPSI2OC43NjIlIj4KICAgICAgICAgICAgPHN0b3Agb2Zmc2V0PSIwJSIgc3RvcC1jb2xvcj0iIzAwQzVCQyIvPgogICAgICAgICAgICA8c3RvcCBvZmZzZXQ9IjEwMCUiIHN0b3AtY29sb3I9IiMwMDkyODYiLz4KICAgICAgICA8L2xpbmVhckdyYWRpZW50PgogICAgICAgIDxsaW5lYXJHcmFkaWVudCBpZD0iYiIgeDE9IjcwLjY2MSUiIHgyPSIyMi44MzElIiB5MT0iLjYxOCUiIHkyPSI3OC45NDklIj4KICAgICAgICAgICAgPHN0b3Agb2Zmc2V0PSIwJSIgc3RvcC1jb2xvcj0iIzAwOTc5NiIvPgogICAgICAgICAgICA8c3RvcCBvZmZzZXQ9IjEwMCUiIHN0b3AtY29sb3I9IiMwMDVFNUQiLz4KICAgICAgICA8L2xpbmVhckdyYWRpZW50PgogICAgICAgIDxsaW5lYXJHcmFkaWVudCBpZD0iYyIgeDE9IjkzLjY2JSIgeDI9IjguNjc3JSIgeTE9Ii00MS44MTMlIiB5Mj0iNzQuOTM1JSI+CiAgICAgICAgICAgIDxzdG9wIG9mZnNldD0iMCUiIHN0b3Atb3BhY2l0eT0iLjA1Ii8+CiAgICAgICAgICAgIDxzdG9wIG9mZnNldD0iMTAwJSIgc3RvcC1vcGFjaXR5PSIuMTIiLz4KICAgICAgICA8L2xpbmVhckdyYWRpZW50PgogICAgICAgIDxsaW5lYXJHcmFkaWVudCBpZD0iZCIgeDE9IjExNi41OSUiIHgyPSI2OS4yMzklIiB5MT0iLTUuMTgzJSIgeTI9IjQwLjk0NyUiPgogICAgICAgICAgICA8c3RvcCBvZmZzZXQ9IjAlIiBzdG9wLWNvbG9yPSIjMDA5Nzk2Ii8+CiAgICAgICAgICAgIDxzdG9wIG9mZnNldD0iMTAwJSIgc3RvcC1jb2xvcj0iIzAwNUU1RCIvPgogICAgICAgIDwvbGluZWFyR3JhZGllbnQ+CiAgICAgICAgPGxpbmVhckdyYWRpZW50IGlkPSJlIiB4MT0iNjkuMTI4JSIgeDI9IjIxLjA0MiUiIHkxPSIxMy4wNjglIiB5Mj0iNjEuMTUxJSI+CiAgICAgICAgICAgIDxzdG9wIG9mZnNldD0iMCUiIHN0b3AtY29sb3I9IiMwMDk3OTYiLz4KICAgICAgICAgICAgPHN0b3Agb2Zmc2V0PSIxMDAlIiBzdG9wLWNvbG9yPSIjMDA1RTVEIi8+CiAgICAgICAgPC9saW5lYXJHcmFkaWVudD4KICAgIDwvZGVmcz4KICAgIDxnIGZpbGw9Im5vbmUiIGZpbGwtcnVsZT0ibm9uemVybyI+CiAgICAgICAgPHBhdGggZmlsbD0iIzAwMCIgZD0iTTMwLjQzIDE4LjA1NWE0MS41MzIgNDEuNTMyIDAgMCAxLTE4LjUzIDcuMzY2YzIuMTUgMzAuNzQgMTkuNzc1IDM3LjY1NyAyMS42NzEgMzcuNTI0IDEuODk2LS4xMzMgMTguMzg2LTkuNDM0IDE2LjIzNy00MC4xNzRhNDEuNTU0IDQxLjU1NCAwIDAgMS0xOS4zNzgtNC43MTZ6IiBvcGFjaXR5PSIuMDgiLz4KICAgICAgICA8cGF0aCBmaWxsPSJ1cmwoI2EpIiBkPSJNMjUgMEE0MS41MzQgNDEuNTM0IDAgMCAxIDYgNi4wNTZDNiAzNi44NzEgMjMuMSA0NSAyNSA0NWMxLjkgMCAxOS04LjEyOSAxOS0zOC45NDRBNDEuNTM0IDQxLjUzNCAwIDAgMSAyNSAweiIgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoMTEgMTUpIi8+CiAgICAgICAgPHBhdGggZmlsbD0idXJsKCNiKSIgZD0iTTI1IDMuNDhhNDUuNzU1IDQ1Ljc1NSAwIDAgMCAxNS45NSA1LjMwOGMtLjI5MSA3Ljg2Ny0xLjk1IDE3LjkxNy03LjU3MSAyNS43MzMtMy40NzkgNC44MzctNy4wOTUgNi44ODYtOC4zNzkgNy4zOTMtMS4yODQtLjUwNy00LjktMi41NTYtOC4zNzktNy4zOTNDMTEgMjYuNzA1IDkuMzQxIDE2LjY1NSA5LjA1IDguNzg4QTQ1Ljc1NSA0NS43NTUgMCAwIDAgMjUgMy40OHpNMjUgMEE0MS41MzQgNDEuNTM0IDAgMCAxIDYgNi4wNTZDNiAzNi44NzEgMjMuMSA0NSAyNSA0NWMxLjkgMCAxOS04LjEyOSAxOS0zOC45NDRBNDEuNTM0IDQxLjUzNCAwIDAgMSAyNSAweiIgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoMTEgMTUpIi8+CiAgICAgICAgPHBhdGggZmlsbD0idXJsKCNjKSIgZD0iTTM3Ljg3OSA1LjE3OUMzMy4zMjkgNC4xNzkgMjguOTc2IDIuNDI5IDI1IDBBNDEuNTM0IDQxLjUzNCAwIDAgMSA2IDYuMDU2YzAgMTEuNCAyLjM0NCAxOS42ODYgNS4zOSAyNS42MTJMMzcuODc5IDUuMTc5eiIgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoMTEgMTUpIi8+CiAgICAgICAgPHBhdGggZmlsbD0idXJsKCNkKSIgZD0iTTIwLjA5MSAxOS4wNmg5Ljc5MkMzMSAxOS4wNiAzMSAxMy45NiAzMSAxMy45NkE1Ljg2MSA1Ljg2MSAwIDAgMCAyNS4yNDggOGgtLjVBNS44NjEgNS44NjEgMCAwIDAgMTkgMTMuOTY0czAgNS4wOTYgMS4wOTEgNS4wOTZ6IiB0cmFuc2Zvcm09InRyYW5zbGF0ZSgxMSAxNSkiLz4KICAgICAgICA8cGF0aCBmaWxsPSIjRkZEMjAwIiBkPSJNMzIuMzQ5IDQxLjE0MWE2LjE0OCA2LjE0OCAwIDAgMCA2LjQxOS43NTNBNi4zMjMgNi4zMjMgMCAwIDAgNDAgNDAuNWMtLjE1NS0uMzI1LS4xMDgtLjctLjQ4OS0uOTE2LTEuMDU3LS41ODQtMS4wNzctLjI4NC0xLjA3Ny0zLjc4NC0uNTE3LjE4OS0xLjM0OC0uNzExLTEuODctLjQzOS0uMTk3LjEwOC0uMzg2LjIzLS41NjcuMzYzYTUuMDM2IDUuMDM2IDAgMCAwLS41NjctLjM2M2MtLjUyMi0uMjcyLTEuMzUzLjYyOC0xLjg3LjQzOSAwIDMuNDk1LS4wMzQgMy4yLTEuMDkxIDMuNzkzLS4zNzYuMjEtLjMxNC41NzctLjQ2OS45LjE2OC4xODQuMjg4LjQwNi4zNDkuNjQ4eiIvPgogICAgICAgIDxwYXRoIGZpbGw9IiNGRkQyMDAiIGQ9Ik0zOC4wMzcgMjhDMzYuMzU2IDMwLjk0IDMxIDMxLjA3OSAzMSAzMS4wNzlWMzNhNSA1IDAgMCAwIDEwIDB2LTMuMDc2QTMuODE5IDMuODE5IDAgMCAxIDM4LjAzNyAyOHoiLz4KICAgICAgICA8cGF0aCBmaWxsPSJ1cmwoI2UpIiBkPSJNMTUuNDEgMjYuMDI2YTMxLjcgMzEuNyAwIDAgMCAzLjY0NiA2Ljc0M0EyMS4xMjcgMjEuMTI3IDAgMCAwIDI1IDM4LjUzN2EyMS4xMjcgMjEuMTI3IDAgMCAwIDUuOTQ0LTUuNzY4IDMxLjYxOCAzMS42MTggMCAwIDAgMy42MTMtNi42NTljLS4wNDItLjAyMS0uMDc5LS4wNDItLjEyMy0uMDYyYTE2Ljk1NCAxNi45NTQgMCAwIDAtNS4zLTEuMzU1Yy4wMDYuMDY1LjAxNC4xMjkuMDE0LjIgMCAxLjYwOS0xLjg5MSAyLjkxNC00LjI0OCAyLjk2NS0yLjM1OC0uMDUxLTQuMjQ5LTEuMzU2LTQuMjQ5LTIuOTY1IDAtLjA2Ni4wMDktLjEzLjAxNS0uMi0xLjgxMi4xNi0zLjU4Ny42MS01LjI1NiAxLjMzM3oiIHRyYW5zZm9ybT0idHJhbnNsYXRlKDExIDE1KSIvPgogICAgICAgIDxwYXRoIGZpbGw9IiNGRkYiIGQ9Ik00MSAzOS44ODhjLS4wMDktLjA4OCAwLS4wMjMtLjAwOS0uMDg4LS4wMzUgMC0xLS4xODYtMS40OC0uMjEyYS45NDEuOTQxIDAgMCAxIC4wNTUuM2MwIC45OS0xLjYyNCAxLjgyOC0zLjU2NiAxLjg1NC0xLjk0Mi0uMDI2LTMuNTY2LS44NjQtMy41NjYtMS44NTRhLjk0MS45NDEgMCAwIDEgLjA1NS0uM2MtLjQ3Ni4wMjYtMS40NDcuMTg0LTEuNDgyLjE4N2EuNjA3LjYwNyAwIDAgMC0uMDA3LjExM2MwIDEuNjIzIDIuMjMgMi45NDEgNSAyLjk3IDIuNzctLjAyOSA1LjE2Mi0xLjM1OCA1LTIuOTd6Ii8+CiAgICA8L2c+Cjwvc3ZnPgo=\');  display: inline-block;  width: 72px;  height: 72px;  background-size: 100%;}.aab-cookie-consent .header h2 {  display: inline-block;  margin: 16px 0;  font-size: 32px;  line-height: 40px;  font-family: \'Roboto Condensed\';  font-weight: 400;  vertical-align: top;  color: #222 !important;}/* Language Switch styles*/.aab-cookie-consent .language-switch {  float: right;  color: #dedede;}.aab-cookie-consent .btn-nl, .aab-cookie-consent .btn-en {  font-size: 14px;  font-weight: 400;  line-height: 20px;  color: #00716b !important;  text-decoration: none;  cursor: pointer;}.aab-cookie-consent .btn-nl::after {  content: \"\";  height: 19px;  display: inline-block;  margin: 0 16px;  width: 1px;  background-color: #dedede;  position: relative;  top: 4px;}.aab-cookie-consent .btn-nl.active, .aab-cookie-consent .btn-en.active {  color: #004c4c !important;  font-weight: 500;}/* Text Styles */.aab-cookie-consent p {  font-size: 20px;  line-height: 32px;  font-weight: 400;  font-family: \'Roboto\';  margin-top: 8px;  margin-bottom: 16px;}.aab-cookie-consent h3 {  font-size: 18px !important;  margin-top: 8px !important;  margin-bottom: 8px !important;  color: #222 !important;  font-weight: 500 !important;  font-family: \'Roboto\' !important;}.aab-cookie-consent ul {  margin-top: 0;  margin-bottom: 16px;  padding: 0;  list-style-type: none;}.aab-cookie-consent li {  font-size: 16px;  margin-bottom: 8px;  line-height: 24px;  padding-left: 32px;}.aab-cookie-consent li::before {  content: \"\";  background-image: url(\'data:image/svg+xml;base64,PHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHdpZHRoPSIyNCIgaGVpZ2h0PSIyNCIgdmlld0JveD0iMCAwIDI0IDI0Ij4KICAgIDxwYXRoIGZpbGw9IiMwMDcxNkIiIGZpbGwtcnVsZT0iZXZlbm9kZCIgZD0iTTExLjY2MiAxNS44MjFsNy4wNDUtNy4xMDJjLjM5LS4zOTQuMzktMS4wMzEgMC0xLjQyNWEuOTk4Ljk5OCAwIDAgMC0xLjQxNCAwbC03LjA0NSA3LjEwMy0zLjU0LTMuNTY4YS45OTguOTk4IDAgMCAwLTEuNDE0IDAgMS4wMSAxLjAxIDAgMCAwIDAgMS40MjZsMy41NCAzLjU2Ni43MDYuNzEyYS45OTQuOTk0IDAgMCAwIDEuNDE1IDBsLjcwNy0uNzEyeiIvPgo8L3N2Zz4K\');  background-size: 100%;  width: 24px;  height: 24px;  display: inline-block;  vertical-align: middle;  position: relative;  margin-right: 8px;  margin-left: -32px;}.aab-cookie-consent .text-extra {  transition: max-height .15s ease-in-out;  max-height: 800px;  overflow: hidden;}.aab-cookie-consent .text-extra.hide {  max-height: 0;}/* Button Styles */.aab-cookie-consent .btn-holder {  line-height: 0;  font-size: 0;  margin-top: 8px;  display: inline-block;}.aab-cookie-consent .btn {  padding: 12px 16px;  height: 48px;  text-align: center;  width: 192px;  text-decoration: none;  display: inline-block;  line-height: 24px;  font-size: 16px;  transition: color .15s ease-in-out, background-color .15s ease-in-out, border-color .15s ease-in-out, box-shadow .15s ease-in-out;  -webkit-box-sizing: border-box;  box-sizing: border-box;}.aab-cookie-consent .btn::before {  content: \"\";}.aab-cookie-consent .btn::after {  content: \"\";}.aab-cookie-consent .btn-base {  background-color: #00716b;  color: white;}.aab-cookie-consent .btn-base:hover {  background-color: #00857a;}.aab-cookie-consent .btn-base:active {  background-color: #005e5d;  border-color: #005e5d;  color: #fff;}.aab-cookie-consent .btn-secondary {  background-color: #edf7f7;  border-radius: 2px;  box-shadow: inset 0 0 0 1px #c0d1d0;  color: #00716b;  margin-left: 16px;  border: none !important;}.aab-cookie-consent .btn-secondary:hover {  box-shadow: inset 0 0 0 1px #00857a;}.aab-cookie-consent .btn-secondary:active {  background-color: #e9f0f0;  border-color: #e9f0f0;  color: #00716b;}.aab-cookie-consent .btn-link {  transition: color .15s ease-in-out;  color: #00716b !important;  text-decoration: none;  cursor: pointer;}.aab-cookie-consent .btn-link:hover {  color: #00857a !important;}.aab-cookie-consent .btn-link:active {  color: #004c4c !important;}@media only screen and (max-width: 767px) {  .aab-cookie-consent {    padding: 16px;    height: 60%;    padding-bottom: 64px;    overflow: hidden;  }  .aab-cookie-consent .aab-cc-container {    height: 100%;  }  .aab-cookie-consent .aab-cc-scrollable {    height: calc(100% - 40px);    overflow: auto;    display: inline-block;  }  .aab-cookie-consent .btn-holder {    margin-left: -8px;    width: calc(100% - 16px);    position: fixed;    bottom: 0;    padding-bottom: 8px;  }  .aab-cookie-consent .btn {    width: calc(50% - 4px);  }  .aab-cookie-consent .btn-secondary {    margin-left: 8px;  }  /* Header Styles */  .aab-cookie-consent .header {    min-height: 64px;    font-size: 0;    display: inline-block;  }  .aab-cookie-consent .header .icon {    display: inline-block;    height: 56px;    width: 56px;    margin-top: 4px;  }  .aab-cookie-consent .header h2 {    display: inline-block;    margin: 16px 0;    font-size: 28px;    line-height: 32px;    font-family: \'Roboto Condensed\';    font-weight: 400;    vertical-align: top;    width: calc(100% - 56px);  }  .aab-cookie-consent .language-switch {    margin-top: 2px;    margin-bottom: 14px;  }  .aab-cookie-consent p {    font-size: 16px;    line-height: 24px;    margin-bottom: 16px;    margin-top: 0;  }  .aab-cookie-consent .text-extra {   max-height: 800px;  } .aab-cookie-consent .text-extra.hide {   max-height: 800px; } .aab-cookie-consent li {    line-height: 24px;    padding-left: 32px;  }}@media only screen and (min-width: 768px) {  .aab-cookie-consent .aab-cc-scrollable {    max-height: 55vh;    overflow: auto;    display: inline-block;  }}";utag.gdpr.consent_prompt.content.html="<section class=\"aab-cookie-consent\">  <div class=\"aab-cc-container\">    <div class=\"language-switch\">      <a class=\"btn-link btn-nl\" id=\"aab-cookie-consent-language-nl\">Nederlands</a><a class=\"btn-link btn-en\" id=\"aab-cookie-consent-language-en\">English</a>    </div>    <div class=\"aab-cc-scrollable\">      <div class=\"header\">        <div class=\"icon\"></div>        <h2>{{title}}</h2>      </div>      <div class=\"text\">        <p>{{message}}</p>        <div class=\"text-extra hide\">          <h3>{{setting_heading}}</h3>          <p>{{settings_message}}</p>          <h3>{{personal_title}}</h3>          <ul>            <li>{{personal_item_1}}</li>            <li>{{personal_item_2}}</li>          </ul>          <h3>{{functional_title}}</h3>          <ul>            <li>{{functional_item_1}}</li>            <li>{{functional_item_2}}</li>          </ul>        </div>        <div class=\"btn-holder\">          <a href=\"\" class=\"btn btn-base\" id=\"aab-cookie-consent-agree\">{{confirmation_button}}</a>          <a href=\"\" class=\"btn btn-secondary\" id=\"aab-cookie-consent-decline\">{{decline_button}}</a>        </div>      </div>    </div>  </div></section>";utag.gdpr.consent_prompt.content.js="(function initConsentPrompt(){function closePrompt(modal){modal.style.display='none';}function trackEvent(eventName,eventCategory,eventAction,eventLabel,eventCustom,eventIsInteraction){utag.link({event_name:eventName,event_category:eventCategory,event_action:eventAction,event_label:eventLabel,event_custom:eventCustom||{},event_is_interaction:eventIsInteraction||true});}function trackCookieEvent(eventAction,eventLabel,eventIsInteraction){trackEvent('cookie consent event','cookie consent',eventAction,eventLabel||'',eventIsInteraction||true);}function pushFactToRelay42(factName,factTTL,factProperties){utag.link({event_name:'push relay42 fact',relay42_fact_name:factName,relay42_fact_ttl:factTTL||2592000,relay42_properties:factProperties||{}},false,[45]);}function pushCookieFactToRelay42(){pushFactToRelay42('web_cookiesetting',undefined,{cookiesetting:utag.gdpr.getConsentState()});}function agreeClicked(event,modal){event.preventDefault();utag.gdpr.setConsentValue(true);trackCookieEvent('agree clicked');pushCookieFactToRelay42();closePrompt(modal);}function declineClicked(event,modal){event.preventDefault();utag.gdpr.setConsentValue(false);trackCookieEvent('decline clicked');pushCookieFactToRelay42();closePrompt(modal);}function toggleHideLinkClicked(event,modal){modal.getElementsByClassName('text-extra')[0].classList.toggle('hide');trackCookieEvent('cookie settings opened or closed');}function switchLanguage(event,language){event.preventDefault();trackCookieEvent('language switched',\"from \".concat(utag.data.cookie_consent_language,\" to \").concat(language));utag.data.cookie_consent_language=language;utag.gdpr.showExplicitConsent(language);}var modal=document.getElementById('__tealiumGDPRecModal');if(modal!=null){trackCookieEvent('consent prompt shown');var agreeButton=document.getElementById('aab-cookie-consent-agree');var declineButton=document.getElementById('aab-cookie-consent-decline');var toggleHideLink=document.getElementById('aab-cookie-consent-toggle-hide');var languageLinks={nl:document.getElementById('aab-cookie-consent-language-nl'),en:document.getElementById('aab-cookie-consent-language-en')};var language=utag.data.cookie_consent_language||utag.gdpr.getLanguage();if(language in languageLinks)languageLinks[language].classList.add('active');if(document.addEventListener){if(agreeButton!=null){agreeButton.addEventListener('click',function(event){agreeClicked(event,modal);},false);}if(declineButton!=null){declineButton.addEventListener('click',function(event){declineClicked(event,modal);},false);}if(toggleHideLink!=null){toggleHideLink.addEventListener('click',function(event){toggleHideLinkClicked(event,modal);},false);}if(languageLinks!=null){languageLinks.nl.addEventListener('click',function(event){switchLanguage(event,'nl');},false);}if(languageLinks!=null){languageLinks.en.addEventListener('click',function(event){switchLanguage(event,'en');},false);}utag.DB(\"Consent Prompt: Added click listeners to the consent prompt's links\");}else{closePrompt(modal);throw new Error(\"ConsentPromptError: Closed consent prompt because document.addEventListener isn't supported\");}}})();";utag.gdpr.consent_prompt.defaultLang="nl";utag.gdpr.showExplicitConsent=function(_lang){var cn=document.getElementById("__tealiumGDPRecStyle");if(cn){cn.parentNode.removeChild(cn);}var hn=document.getElementById("__tealiumGDPRecModal");if(hn){hn.parentNode.removeChild(hn);}var sn=document.getElementById("__tealiumGDPRecScript");if(sn){sn.parentNode.removeChild(sn);}var dtc=utag.gdpr.getDeTokenizedContent(utag.gdpr.consent_prompt,_lang);var head=document.head||document.getElementsByTagName("head")[0],style=document.createElement("style"),mDiv=document.createElement("div"),scr=document.createElement("script"),body=document.body||document.getElementsByTagName("body")[0];style.type="text/css";style.id="__tealiumGDPRecStyle";if(style.styleSheet){style.styleSheet.cssText=dtc.css;}else{style.appendChild(document.createTextNode(dtc.css));}head.appendChild(style);mDiv.innerHTML=dtc.html;mDiv.id="__tealiumGDPRecModal";body.appendChild(mDiv);scr.language="javascript";scr.type="text/javascript";scr.text="try{"+dtc.js+"} catch(e){utag.DB(e)}";scr.id="__tealiumGDPRecScript";head.appendChild(scr);};



utag.track_old = utag.track;
utag.track = function(a, b, c, d) {
    if (typeof a == "string") a = {
        event: a,
        data: b,
        cfg: {
            cb: c,
            uids: d
        }
    };
    if (a.event === "update_consent_cookie" && b.consent_categories) {
            utag.gdpr.updateConsentCookie(b.consent_categories);
    } else {
      if (utag.gdpr.getConsentState() === 0) {
        // if (!utag.gdpr.noqueue && utag.gdpr.consent_prompt.isEnabled) utag.gdpr.queue.push({event: a.event, data:utag.handler.C(a.data), cfg : utag.handler.C(a.cfg)});
        if (!utag.gdpr.noqueue) utag.gdpr.queue.push({event: a.event, data:utag.handler.C(a.data), cfg : utag.handler.C(a.cfg)});
      }
        utag.gdpr.refreshCookie();
        return utag.track_old.apply(this, arguments);
    }
};
utag.loader.OU_old = utag.loader.OU;
utag.loader.OU = function() {
  utag.loader.OU_old();
  utag.gdpr.applyConsentState();
};

if (utag.gdpr.preferences_prompt.single_cookie) {
    window.utag_cfg_ovrd = window.utag_cfg_ovrd || {};
    window.utag_cfg_ovrd.nocookie = true;
}
if (!utag.gdpr.consent_prompt.isEnabled && utag.gdpr.getConsentState() == 0) {
  utag.gdpr.setAllCategories(utag.gdpr.preferences_prompt.defaultState, !0);
}
  if(typeof utag_cfg_ovrd!='undefined'){for(utag._i in utag.loader.GV(utag_cfg_ovrd))utag.cfg[utag._i]=utag_cfg_ovrd[utag._i]};
  utag.loader.PINIT = function(a,b,c){
    utag.DB("Pre-INIT");
    if (utag.cfg.noload) {
      return;
    }

    try {
      // Initialize utag.data
      this.GET();
      // Even if noview flag is set, we still want to load in tags and have them ready to fire
      // FUTURE: blr = "before load rules"
      if(utag.handler.RE('view',utag.data,"blr")){
        utag.handler.LR(utag.data);
      }
      
    }catch(e){utag.DB(e)};
    // process 'blocking' tags (tags that need to run first)
    a=this.cfg;
    c=0;
    for (b in this.GV(a)) {
      // external .js files (currency converter tag) are blocking
      if(a[b].block == 1 || (a[b].load>0 && (typeof a[b].src!='undefined'&&a[b].src!=''))){
        a[b].block = 1;
        c=1;
        this.bq[b]=1;
      }
    }
    if(c==1) {
      for (b in this.GV(a)) {
        if(a[b].block){
          // handle case of bundled and blocking (change 4 to 1)
          // (bundled tags that do not have a .src should really never be set to block... they just run first)
          a[b].id=b; 
          if(a[b].load==4)a[b].load=1; 
 	  a[b].cb=function(){
            var d=this.uid;
            utag.loader.cfg[d].cbf=1;
            utag.loader.LOAD(d)
          };
          this.AS(a[b]);
        }
      }
    }
    if(c==0)this.INIT();
  };
  utag.loader.INIT = function(a, b, c, d, e) {
    utag.DB('utag.loader.INIT');
    if (this.ol == 1) return -1;
    else this.ol = 1;
    // The All Tags scope extensions run after blocking tags complete
    // The noview flag means to skip these Extensions (will run later for manual utag.view call)
    if(utag.cfg.noview!=true)utag.handler.RE('view',utag.data,"alr"); 

    utag.rpt.ts['i'] = new Date();
     
    d = this.cfgsort;
    // TODO: Publish engine should sort the bundled tags first..
    for (a=0;a<d.length;a++){
      e = d[a];
      b = this.cfg[e];
      b.id = e;
      if(b.block != 1){
        // do not wait if the utag.cfg.noview flag is set and the tag is bundled
        if (utag.loader.bk[b.id] || ((utag.cfg.readywait||utag.cfg.noview) && b.load==4)){
          this.f[b.id]=0;
          utag.loader.LOAD(b.id)
        }else if (b.wait == 1 && utag.loader.rf == 0) {
	  utag.DB('utag.loader.INIT: waiting ' + b.id);
          this.wq.push(b)
          this.f[b.id]=2;
        }else if (b.load>0){
	  utag.DB('utag.loader.INIT: loading ' + b.id);
	  this.lq.push(b);
          this.AS(b);
        }
      }
    }
          
    if (this.wq.length > 0) utag.loader.EV('', 'ready', function(a) {
      if(utag.loader.rf==0){
        utag.DB('READY:utag.loader.wq');
        utag.loader.rf=1;
        utag.loader.WQ();
      }
    });
    else if(this.lq.length>0)utag.loader.rf=1;
    else if(this.lq.length==0)utag.loader.END();

    return 1
  };
  utag.loader.EV('', 'ready', function(a) {if(utag.loader.efr!=1){utag.loader.efr=1;try{if(!utag.gdpr.consent_prompt.noShow){if(!utag.gdpr.getConsentState()){if(utag.gdpr.consent_prompt.isEnabled){utag.gdpr.showExplicitConsent();}}}}catch(e){utag.DB(e);}try{ try{ if((utag.data['environment_name']=='tridion'&&typeof utag.data['meta.aab:cookie-config']=='undefined')||(utag.data['environment_name']=='dda'&&typeof utag.data['meta.aab:cookie-config']=='undefined')){
if (window.s != null) {
    utag.DB('Adobe Analytics (Legacy): Fire pageview without old cookie consent');
    s.t();
}
} } catch(e){ utag.DB(e) }  }catch(e){utag.DB(e)};}})

  if(utag.cfg.readywait || utag.cfg.waittimer){
    utag.loader.EV('', 'ready', function(a) {
      if(utag.loader.rf==0){
        utag.loader.rf=1;
        utag.cfg.readywait=1;
        utag.DB('READY:utag.cfg.readywait');
        setTimeout(function(){utag.loader.PINIT()}, utag.cfg.waittimer || 1);
      }
    })
  }else{
    utag.loader.PINIT()
  }
}


//~~tv:1191.20190301
//~~tc: Update Visitor Library to version 4.1.0

/**
 * @license
 * Adobe Visitor API for JavaScript version: 4.1.0
 * Copyright 2019 Adobe, Inc. All Rights Reserved
 * More info available at https://marketing.adobe.com/resources/help/en_US/mcvid/
 */
var e=function(){"use strict";function e(t){return(e="function"==typeof Symbol&&"symbol"==typeof Symbol.iterator?function(e){return typeof e}:function(e){return e&&"function"==typeof Symbol&&e.constructor===Symbol&&e!==Symbol.prototype?"symbol":typeof e})(t)}function t(e,t,n){return t in e?Object.defineProperty(e,t,{value:n,enumerable:!0,configurable:!0,writable:!0}):e[t]=n,e}function n(){return{callbacks:{},add:function(e,t){this.callbacks[e]=this.callbacks[e]||[];var n=this.callbacks[e].push(t)-1,i=this;return function(){i.callbacks[e].splice(n,1)}},execute:function(e,t){if(this.callbacks[e]){t=void 0===t?[]:t,t=t instanceof Array?t:[t];try{for(;this.callbacks[e].length;){var n=this.callbacks[e].shift();"function"==typeof n?n.apply(null,t):n instanceof Array&&n[1].apply(n[0],t)}delete this.callbacks[e]}catch(e){}}},executeAll:function(e,t){(t||e&&!x.isObjectEmpty(e))&&Object.keys(this.callbacks).forEach(function(t){var n=void 0!==e[t]?e[t]:"";this.execute(t,n)},this)},hasCallbacks:function(){return Boolean(Object.keys(this.callbacks).length)}}}function i(e){for(var t=/^\d+$/,n=0,i=e.length;n<i;n++)if(!t.test(e[n]))return!1;return!0}function r(e,t){for(;e.length<t.length;)e.push("0");for(;t.length<e.length;)t.push("0")}function a(e,t){for(var n=0;n<e.length;n++){var i=parseInt(e[n],10),r=parseInt(t[n],10);if(i>r)return 1;if(r>i)return-1}return 0}function o(e,t){if(e===t)return 0;var n=e.toString().split("."),o=t.toString().split(".");return i(n.concat(o))?(r(n,o),a(n,o)):NaN}function s(e){return e===Object(e)&&0===Object.keys(e).length}function l(e){return"function"==typeof e||e instanceof Array&&e.length}function c(){var e=arguments.length>0&&void 0!==arguments[0]?arguments[0]:{},t=e.isEnabled,n=e.cookieName,i=arguments.length>1&&void 0!==arguments[1]?arguments[1]:{},r=i.cookies;return t&&n&&r?{remove:function(){r.remove(n)},get:function(){var e=r.get(n),t={};try{t=JSON.parse(e)}catch(e){t={}}return t},set:function(e,t){t=t||{},r.set(n,JSON.stringify(e),{domain:t.optInCookieDomain||"",cookieLifetime:t.optInStorageExpiry||3419e4,expires:!0})}}:{get:be,set:be,remove:be}}function u(e){this.name=this.constructor.name,this.message=e,"function"==typeof Error.captureStackTrace?Error.captureStackTrace(this,this.constructor):this.stack=new Error(e).stack}function d(){function e(e,t){var n=ge(e);return n.length?n.every(function(e){return!!t[e]}):pe(t)}function t(){M(y),O(oe.COMPLETE),_(h.status,h.permissions),m.set(h.permissions,{optInCookieDomain:l,optInStorageExpiry:u}),C.execute(Ee)}function n(e){return function(n,i){if(!me(n))throw new Error("[OptIn] Invalid category(-ies). Please use the `OptIn.Categories` enum.");return O(oe.CHANGED),Object.assign(y,he(ge(n),e)),i||t(),h}}var i=arguments.length>0&&void 0!==arguments[0]?arguments[0]:{},r=i.doesOptInApply,a=i.previousPermissions,o=i.preOptInApprovals,s=i.isOptInStorageEnabled,l=i.optInCookieDomain,u=i.optInStorageExpiry,d=i.isIabContext,f=arguments.length>1&&void 0!==arguments[1]?arguments[1]:{},g=f.cookies,p=Ae(a);ye(p,"Invalid `previousPermissions`!"),ye(o,"Invalid `preOptInApprovals`!");var m=c({isEnabled:!!s,cookieName:"adobeujs-optin"},{cookies:g}),h=this,_=ae(h),C=de(),I=Ie(p),v=Ie(o),D=m.get(),S={},b=function(e,t){return ve(e)||t&&ve(t)?oe.COMPLETE:oe.PENDING}(I,D),A=function(e,t,n){var i=he(ue,!r);return r?Object.assign({},i,e,t,n):i}(v,I,D),y=_e(A),O=function(e){return b=e},M=function(e){return A=e};h.deny=n(!1),h.approve=n(!0),h.denyAll=h.deny.bind(h,ue),h.approveAll=h.approve.bind(h,ue),h.isApproved=function(t){return e(t,h.permissions)},h.isPreApproved=function(t){return e(t,v)},h.fetchPermissions=function(e){var t=arguments.length>1&&void 0!==arguments[1]&&arguments[1],n=t?h.on(oe.COMPLETE,e):be;return!r||r&&h.isComplete||!!o?e(h.permissions):t||C.add(Ee,function(){return e(h.permissions)}),n},h.complete=function(){h.status===oe.CHANGED&&t()},h.registerPlugin=function(e){if(!e||!e.name||"function"!=typeof e.onRegister)throw new Error(Te);S[e.name]||(S[e.name]=e,e.onRegister.call(e,h))},h.execute=ke(S),Object.defineProperties(h,{permissions:{get:function(){return A}},status:{get:function(){return b}},Categories:{get:function(){return se}},doesOptInApply:{get:function(){return!!r}},isPending:{get:function(){return h.status===oe.PENDING}},isComplete:{get:function(){return h.status===oe.COMPLETE}},__plugins:{get:function(){return Object.keys(S)}},isIabContext:{get:function(){return d}}})}function f(e,t){function n(){r=null,e.call(e,new u("The call took longer than you wanted!"))}function i(){r&&(clearTimeout(r),e.apply(e,arguments))}if(void 0===t)return e;var r=setTimeout(n,t);return i}function g(){var e=arguments.length>0&&void 0!==arguments[0]?arguments[0]:Le(),t=this;t.name="iabPlugin",t.version="0.0.1";var n=de(),i={allConsentData:null},r=function(e){var t=arguments.length>1&&void 0!==arguments[1]?arguments[1]:{};return i[e]=t};t.fetchConsentData=function(e){var t=e.callback,n=e.timeout,i=f(t,n);a({callback:i})},t.isApproved=function(e){var t=e.callback,n=e.category,r=e.timeout;if(i.allConsentData)return t(null,l(n,i.allConsentData.vendorConsents,i.allConsentData.purposeConsents));var o=f(function(e){var i=arguments.length>1&&void 0!==arguments[1]?arguments[1]:{},r=i.vendorConsents,a=i.purposeConsents;t(e,l(n,r,a))},r);a({category:n,callback:o})},t.onRegister=function(e){var n=Object.keys(le),i=function(t){var i=arguments.length>1&&void 0!==arguments[1]?arguments[1]:{},r=i.purposeConsents,a=i.gdprApplies,o=i.vendorConsents;!t&&a&&o&&r&&(n.forEach(function(t){var n=l(t,o,r);e[n?"approve":"deny"](t,!0)}),e.complete())};t.fetchConsentData({callback:i})};var a=function(e){var t=e.callback;if(i.allConsentData)return t(null,i.allConsentData);n.add("FETCH_CONSENT_DATA",t);var a={};s(function(){var e=arguments.length>0&&void 0!==arguments[0]?arguments[0]:{},t=e.purposeConsents,s=e.gdprApplies,l=e.vendorConsents;(arguments.length>1?arguments[1]:void 0)&&(a={purposeConsents:t,gdprApplies:s,vendorConsents:l},r("allConsentData",a)),o(function(){var e=arguments.length>0&&void 0!==arguments[0]?arguments[0]:{};(arguments.length>1?arguments[1]:void 0)&&(a.consentString=e.consentData,r("allConsentData",a)),n.execute("FETCH_CONSENT_DATA",[null,i.allConsentData])})})},o=function(t){e("getConsentData",null,t)},s=function(t){var n=Me(le);e("getVendorConsents",n,t)},l=function(e){var t=arguments.length>1&&void 0!==arguments[1]?arguments[1]:{},n=arguments.length>2&&void 0!==arguments[2]?arguments[2]:{},i=!!t[le[e]];return i&&function(){return ce[e].every(function(e){return n[e]})}()}}function p(e,t,n){var i=null==e?void 0:e[t];return void 0===i?n:i}var m="undefined"!=typeof window?window:"undefined"!=typeof global?global:"undefined"!=typeof self?self:{};Object.assign=Object.assign||function(e){for(var t,n,i=1;i<arguments.length;++i){n=arguments[i];for(t in n)Object.prototype.hasOwnProperty.call(n,t)&&(e[t]=n[t])}return e};var h,_,C={HANDSHAKE:"HANDSHAKE",GETSTATE:"GETSTATE",PARENTSTATE:"PARENTSTATE"},I={MCMID:"MCMID",MCAID:"MCAID",MCAAMB:"MCAAMB",MCAAMLH:"MCAAMLH",MCOPTOUT:"MCOPTOUT",CUSTOMERIDS:"CUSTOMERIDS"},v={MCMID:"getMarketingCloudVisitorID",MCAID:"getAnalyticsVisitorID",MCAAMB:"getAudienceManagerBlob",MCAAMLH:"getAudienceManagerLocationHint",MCOPTOUT:"getOptOut",ALLFIELDS:"getVisitorValues"},D={CUSTOMERIDS:"getCustomerIDs"},S={MCMID:"getMarketingCloudVisitorID",MCAAMB:"getAudienceManagerBlob",MCAAMLH:"getAudienceManagerLocationHint",MCOPTOUT:"getOptOut",MCAID:"getAnalyticsVisitorID",CUSTOMERIDS:"getCustomerIDs",ALLFIELDS:"getVisitorValues"},b={MC:"MCMID",A:"MCAID",AAM:"MCAAMB"},A={MCMID:"MCMID",MCOPTOUT:"MCOPTOUT",MCAID:"MCAID",MCAAMLH:"MCAAMLH",MCAAMB:"MCAAMB"},y={UNKNOWN:0,AUTHENTICATED:1,LOGGED_OUT:2},O={GLOBAL:"global"},M={MESSAGES:C,STATE_KEYS_MAP:I,ASYNC_API_MAP:v,SYNC_API_MAP:D,ALL_APIS:S,FIELDGROUP_TO_FIELD:b,FIELDS:A,AUTH_STATE:y,OPT_OUT:O},k=M.STATE_KEYS_MAP,E=function(e){function t(){}function n(t,n){var i=this;return function(){var r=e(0,t),a={};return a[t]=r,i.setStateAndPublish(a),n(r),r}}var i=this;this.getMarketingCloudVisitorID=function(e){e=e||t;var i=this.findField(k.MCMID,e),r=n.call(this,k.MCMID,e);return void 0!==i?i:r()},this.getVisitorValues=function(e){i.getMarketingCloudVisitorID(function(t){e({MCMID:t})})}},T=M.MESSAGES,L=M.ASYNC_API_MAP,P=M.SYNC_API_MAP,R=function(){function e(){}function t(e,t){var n=this;return function(){return n.callbackRegistry.add(e,t),n.messageParent(T.GETSTATE),""}}function n(n){this[L[n]]=function(i){i=i||e;var r=this.findField(n,i),a=t.call(this,n,i);return void 0!==r?r:a()}}function i(t){this[P[t]]=function(){return this.findField(t,e)||{}}}Object.keys(L).forEach(n,this),Object.keys(P).forEach(i,this)},w=M.ASYNC_API_MAP,F=function(){Object.keys(w).forEach(function(e){this[w[e]]=function(t){this.callbackRegistry.add(e,t)}},this)},x=function(e,t){return t={exports:{}},e(t,t.exports),t.exports}(function(t,n){n.isObjectEmpty=function(e){return e===Object(e)&&0===Object.keys(e).length},n.isValueEmpty=function(e){return""===e||n.isObjectEmpty(e)},n.getIeVersion=function(){if(document.documentMode)return document.documentMode;for(var e=7;e>4;e--){var t=document.createElement("div");if(t.innerHTML="\x3c!--[if IE "+e+"]><span></span><![endif]--\x3e",t.getElementsByTagName("span").length)return t=null,e;t=null}return null},n.encodeAndBuildRequest=function(e,t){return e.map(encodeURIComponent).join(t)},n.isObject=function(t){return null!==t&&"object"===e(t)&&!1===Array.isArray(t)},n.defineGlobalNamespace=function(){return window.adobe=n.isObject(window.adobe)?window.adobe:{},window.adobe},n.pluck=function(e,t){return t.reduce(function(t,n){return e[n]&&(t[n]=e[n]),t},Object.create(null))},n.parseOptOut=function(e,t,n){t||(t=n,e.d_optout&&e.d_optout instanceof Array&&(t=e.d_optout.join(",")));var i=parseInt(e.d_ottl,10);return isNaN(i)&&(i=7200),{optOut:t,d_ottl:i}},n.normalizeBoolean=function(e){var t=e;return"true"===e?t=!0:"false"===e&&(t=!1),t}}),N=(x.isObjectEmpty,x.isValueEmpty,x.getIeVersion,x.encodeAndBuildRequest,x.isObject,x.defineGlobalNamespace,x.pluck,x.parseOptOut,x.normalizeBoolean,n),j=M.MESSAGES,V={0:"prefix",1:"orgID",2:"state"},U=function(e,t){this.parse=function(e){try{var t={};return e.data.split("|").forEach(function(e,n){if(void 0!==e){t[V[n]]=2!==n?e:JSON.parse(e)}}),t}catch(e){}},this.isInvalid=function(n){var i=this.parse(n);if(!i||Object.keys(i).length<2)return!0;var r=e!==i.orgID,a=!t||n.origin!==t,o=-1===Object.keys(j).indexOf(i.prefix);return r||a||o},this.send=function(n,i,r){var a=i+"|"+e;r&&r===Object(r)&&(a+="|"+JSON.stringify(r));try{n.postMessage(a,t)}catch(e){}}},H=M.MESSAGES,B=function(e,t,n,i){function r(e){Object.assign(g,e)}function a(e){Object.assign(g.state,e),Object.assign(g.state.ALLFIELDS,e),g.callbackRegistry.executeAll(g.state)}function o(e){if(!_.isInvalid(e)){h=!1;var t=_.parse(e);g.setStateAndPublish(t.state)}}function s(e){!h&&p&&(h=!0,_.send(i,e))}function l(){r(new E(n._generateID)),g.getMarketingCloudVisitorID(),g.callbackRegistry.executeAll(g.state,!0),m.removeEventListener("message",c)}function c(e){if(!_.isInvalid(e)){var t=_.parse(e);h=!1,m.clearTimeout(g._handshakeTimeout),m.removeEventListener("message",c),r(new R(g)),m.addEventListener("message",o),g.setStateAndPublish(t.state),g.callbackRegistry.hasCallbacks()&&s(H.GETSTATE)}}function u(){p&&postMessage?(m.addEventListener("message",c),s(H.HANDSHAKE),g._handshakeTimeout=setTimeout(l,250)):l()}function d(){m.s_c_in||(m.s_c_il=[],m.s_c_in=0),g._c="Visitor",g._il=m.s_c_il,g._in=m.s_c_in,g._il[g._in]=g,m.s_c_in++}function f(){function e(e){0!==e.indexOf("_")&&"function"==typeof n[e]&&(g[e]=function(){})}Object.keys(n).forEach(e),g.getSupplementalDataID=n.getSupplementalDataID,g.isAllowed=function(){return!0}}var g=this,p=t.whitelistParentDomain;g.state={ALLFIELDS:{}},g.version=n.version,g.marketingCloudOrgID=e,g.cookieDomain=n.cookieDomain||"",g._instanceType="child";var h=!1,_=new U(e,p);g.callbackRegistry=N(),g.init=function(){d(),f(),r(new F(g)),u()},g.findField=function(e,t){if(g.state[e])return t(g.state[e]),g.state[e]},g.messageParent=s,g.setStateAndPublish=a},G=M.MESSAGES,q=M.ALL_APIS,Y=M.ASYNC_API_MAP,X=M.FIELDGROUP_TO_FIELD,z=function(e,t){function n(){var t={};return Object.keys(q).forEach(function(n){var i=q[n],r=e[i]();x.isValueEmpty(r)||(t[n]=r)}),t}function i(){var t=[];return e._loading&&Object.keys(e._loading).forEach(function(n){if(e._loading[n]){var i=X[n];t.push(i)}}),t.length?t:null}function r(t){return function n(r){var a=i();if(a){var o=Y[a[0]];e[o](n,!0)}else t()}}function a(e,i){var r=n();t.send(e,i,r)}function o(e){l(e),a(e,G.HANDSHAKE)}function s(e){r(function(){a(e,G.PARENTSTATE)})()}function l(n){function i(i){r.call(e,i),t.send(n,G.PARENTSTATE,{CUSTOMERIDS:e.getCustomerIDs()})}var r=e.setCustomerIDs;e.setCustomerIDs=i}return function(e){if(!t.isInvalid(e)){(t.parse(e).prefix===G.HANDSHAKE?o:s)(e.source)}}},W=function(e,t){function n(e){return function(n){i[e]=n,r++,r===a&&t(i)}}var i={},r=0,a=Object.keys(e).length;Object.keys(e).forEach(function(t){var i=e[t];if(i.fn){var r=i.args||[];r.unshift(n(t)),i.fn.apply(i.context||null,r)}})},J=function(e){var t;if(!e&&m.location&&(e=m.location.hostname),t=e)if(/^[0-9.]+$/.test(t))t="";else{var n=",ac,ad,ae,af,ag,ai,al,am,an,ao,aq,ar,as,at,au,aw,ax,az,ba,bb,be,bf,bg,bh,bi,bj,bm,bo,br,bs,bt,bv,bw,by,bz,ca,cc,cd,cf,cg,ch,ci,cl,cm,cn,co,cr,cu,cv,cw,cx,cz,de,dj,dk,dm,do,dz,ec,ee,eg,es,et,eu,fi,fm,fo,fr,ga,gb,gd,ge,gf,gg,gh,gi,gl,gm,gn,gp,gq,gr,gs,gt,gw,gy,hk,hm,hn,hr,ht,hu,id,ie,im,in,io,iq,ir,is,it,je,jo,jp,kg,ki,km,kn,kp,kr,ky,kz,la,lb,lc,li,lk,lr,ls,lt,lu,lv,ly,ma,mc,md,me,mg,mh,mk,ml,mn,mo,mp,mq,mr,ms,mt,mu,mv,mw,mx,my,na,nc,ne,nf,ng,nl,no,nr,nu,nz,om,pa,pe,pf,ph,pk,pl,pm,pn,pr,ps,pt,pw,py,qa,re,ro,rs,ru,rw,sa,sb,sc,sd,se,sg,sh,si,sj,sk,sl,sm,sn,so,sr,st,su,sv,sx,sy,sz,tc,td,tf,tg,th,tj,tk,tl,tm,tn,to,tp,tr,tt,tv,tw,tz,ua,ug,uk,us,uy,uz,va,vc,ve,vg,vi,vn,vu,wf,ws,yt,",i=t.split("."),r=i.length-1,a=r-1;if(r>1&&i[r].length<=2&&(2===i[r-1].length||n.indexOf(","+i[r]+",")<0)&&a--,a>0)for(t="";r>=a;)t=i[r]+(t?".":"")+t,r--}return t},K={compare:o,isLessThan:function(e,t){return o(e,t)<0},areVersionsDifferent:function(e,t){return 0!==o(e,t)},isGreaterThan:function(e,t){return o(e,t)>0},isEqual:function(e,t){return 0===o(e,t)}},Q=!!m.postMessage,$={postMessage:function(e,t,n){var i=1;t&&(Q?n.postMessage(e,t.replace(/([^:]+:\/\/[^\/]+).*/,"$1")):t&&(n.location=t.replace(/#.*$/,"")+"#"+ +new Date+i+++"&"+e))},receiveMessage:function(e,t){var n;try{Q&&(e&&(n=function(n){if("string"==typeof t&&n.origin!==t||"[object Function]"===Object.prototype.toString.call(t)&&!1===t(n.origin))return!1;e(n)}),m.addEventListener?m[e?"addEventListener":"removeEventListener"]("message",n):m[e?"attachEvent":"detachEvent"]("onmessage",n))}catch(e){}}},Z=function(e){var t,n,i="0123456789",r="",a="",o=8,s=10,l=10;if(1==e){for(i+="ABCDEF",t=0;16>t;t++)n=Math.floor(Math.random()*o),r+=i.substring(n,n+1),n=Math.floor(Math.random()*o),a+=i.substring(n,n+1),o=16;return r+"-"+a}for(t=0;19>t;t++)n=Math.floor(Math.random()*s),r+=i.substring(n,n+1),0===t&&9==n?s=3:(1==t||2==t)&&10!=s&&2>n?s=10:2<t&&(s=10),n=Math.floor(Math.random()*l),a+=i.substring(n,n+1),0===t&&9==n?l=3:(1==t||2==t)&&10!=l&&2>n?l=10:2<t&&(l=10);return r+a},ee=function(e,t){return{corsMetadata:function(){var e="none",t=!0;return"undefined"!=typeof XMLHttpRequest&&XMLHttpRequest===Object(XMLHttpRequest)&&("withCredentials"in new XMLHttpRequest?e="XMLHttpRequest":"undefined"!=typeof XDomainRequest&&XDomainRequest===Object(XDomainRequest)&&(t=!1),Object.prototype.toString.call(m.HTMLElement).indexOf("Constructor")>0&&(t=!1)),{corsType:e,corsCookiesEnabled:t}}(),getCORSInstance:function(){return"none"===this.corsMetadata.corsType?null:new m[this.corsMetadata.corsType]},fireCORS:function(t,n,i){function r(e){var n;try{if((n=JSON.parse(e))!==Object(n))return void a.handleCORSError(t,null,"Response is not JSON")}catch(e){return void a.handleCORSError(t,e,"Error parsing response as JSON")}try{for(var i=t.callback,r=m,o=0;o<i.length;o++)r=r[i[o]];r(n)}catch(e){a.handleCORSError(t,e,"Error forming callback function")}}var a=this;n&&(t.loadErrorHandler=n);try{var o=this.getCORSInstance();o.open("get",t.corsUrl+"&ts="+(new Date).getTime(),!0),"XMLHttpRequest"===this.corsMetadata.corsType&&(o.withCredentials=!0,o.timeout=e.loadTimeout,o.setRequestHeader("Content-Type","application/x-www-form-urlencoded"),o.onreadystatechange=function(){4===this.readyState&&200===this.status&&r(this.responseText)}),o.onerror=function(e){a.handleCORSError(t,e,"onerror")},o.ontimeout=function(e){a.handleCORSError(t,e,"ontimeout")},o.send(),e._log.requests.push(t.corsUrl)}catch(e){this.handleCORSError(t,e,"try-catch")}},handleCORSError:function(t,n,i){e.CORSErrors.push({corsData:t,error:n,description:i}),t.loadErrorHandler&&("ontimeout"===i?t.loadErrorHandler(!0):t.loadErrorHandler(!1))}}},te={POST_MESSAGE_ENABLED:!!m.postMessage,DAYS_BETWEEN_SYNC_ID_CALLS:1,MILLIS_PER_DAY:864e5,ADOBE_MC:"adobe_mc",ADOBE_MC_SDID:"adobe_mc_sdid",VALID_VISITOR_ID_REGEX:/^[0-9a-fA-F\-]+$/,ADOBE_MC_TTL_IN_MIN:5,VERSION_REGEX:/vVersion\|((\d+\.)?(\d+\.)?(\*|\d+))(?=$|\|)/},ne=function(e,t){var n=m.document;return{THROTTLE_START:3e4,MAX_SYNCS_LENGTH:649,throttleTimerSet:!1,id:null,onPagePixels:[],iframeHost:null,getIframeHost:function(e){if("string"==typeof e){var t=e.split("/");return t[0]+"//"+t[2]}},subdomain:null,url:null,getUrl:function(){var t,i="http://fast.",r="?d_nsid="+e.idSyncContainerID+"#"+encodeURIComponent(n.location.origin);return this.subdomain||(this.subdomain="nosubdomainreturned"),e.loadSSL&&(i=e.idSyncSSLUseAkamai?"https://fast.":"https://"),t=i+this.subdomain+".demdex.net/dest5.html"+r,this.iframeHost=this.getIframeHost(t),this.id="destination_publishing_iframe_"+this.subdomain+"_"+e.idSyncContainerID,t},checkDPIframeSrc:function(){var t="?d_nsid="+e.idSyncContainerID+"#"+encodeURIComponent(n.location.href);"string"==typeof e.dpIframeSrc&&e.dpIframeSrc.length&&(this.id="destination_publishing_iframe_"+(e._subdomain||this.subdomain||(new Date).getTime())+"_"+e.idSyncContainerID,this.iframeHost=this.getIframeHost(e.dpIframeSrc),this.url=e.dpIframeSrc+t)},idCallNotProcesssed:null,doAttachIframe:!1,startedAttachingIframe:!1,iframeHasLoaded:null,iframeIdChanged:null,newIframeCreated:null,originalIframeHasLoadedAlready:null,iframeLoadedCallbacks:[],regionChanged:!1,timesRegionChanged:0,sendingMessages:!1,messages:[],messagesPosted:[],messagesReceived:[],messageSendingInterval:te.POST_MESSAGE_ENABLED?null:100,onPageDestinationsFired:[],jsonForComparison:[],jsonDuplicates:[],jsonWaiting:[],jsonProcessed:[],canSetThirdPartyCookies:!0,receivedThirdPartyCookiesNotification:!1,readyToAttachIframePreliminary:function(){return!(e.idSyncDisableSyncs||e.disableIdSyncs||e.idSyncDisable3rdPartySyncing||e.disableThirdPartyCookies||e.disableThirdPartyCalls)},readyToAttachIframe:function(){return this.readyToAttachIframePreliminary()&&(this.doAttachIframe||e._doAttachIframe)&&(this.subdomain&&"nosubdomainreturned"!==this.subdomain||e._subdomain)&&this.url&&!this.startedAttachingIframe},attachIframe:function(){function e(){r=n.createElement("iframe"),r.sandbox="allow-scripts allow-same-origin",r.title="Adobe ID Syncing iFrame",r.id=i.id,r.name=i.id+"_name",r.style.cssText="display: none; width: 0; height: 0;",r.src=i.url,i.newIframeCreated=!0,t(),n.body.appendChild(r)}function t(e){r.addEventListener("load",function(){r.className="aamIframeLoaded",i.iframeHasLoaded=!0,i.fireIframeLoadedCallbacks(e),i.requestToProcess()})}this.startedAttachingIframe=!0;var i=this,r=n.getElementById(this.id);r?"IFRAME"!==r.nodeName?(this.id+="_2",this.iframeIdChanged=!0,e()):(this.newIframeCreated=!1,"aamIframeLoaded"!==r.className?(this.originalIframeHasLoadedAlready=!1,t("The destination publishing iframe already exists from a different library, but hadn't loaded yet.")):(this.originalIframeHasLoadedAlready=!0,this.iframeHasLoaded=!0,this.iframe=r,this.fireIframeLoadedCallbacks("The destination publishing iframe already exists from a different library, and had loaded alresady."),this.requestToProcess())):e(),this.iframe=r},fireIframeLoadedCallbacks:function(e){this.iframeLoadedCallbacks.forEach(function(t){"function"==typeof t&&t({message:e||"The destination publishing iframe was attached and loaded successfully."})}),this.iframeLoadedCallbacks=[]},requestToProcess:function(t){function n(){r.jsonForComparison.push(t),r.jsonWaiting.push(t),r.processSyncOnPage(t)}var i,r=this;if(t===Object(t)&&t.ibs)if(i=JSON.stringify(t.ibs||[]),this.jsonForComparison.length){var a,o,s,l=!1;for(a=0,o=this.jsonForComparison.length;a<o;a++)if(s=this.jsonForComparison[a],i===JSON.stringify(s.ibs||[])){l=!0;break}l?this.jsonDuplicates.push(t):n()}else n();if((this.receivedThirdPartyCookiesNotification||!te.POST_MESSAGE_ENABLED||this.iframeHasLoaded)&&this.jsonWaiting.length){var c=this.jsonWaiting.shift();this.process(c),this.requestToProcess()}e.idSyncDisableSyncs||e.disableIdSyncs||!this.iframeHasLoaded||!this.messages.length||this.sendingMessages||(this.throttleTimerSet||(this.throttleTimerSet=!0,setTimeout(function(){r.messageSendingInterval=te.POST_MESSAGE_ENABLED?null:150},this.THROTTLE_START)),this.sendingMessages=!0,this.sendMessages())},getRegionAndCheckIfChanged:function(t,n){var i=e._getField("MCAAMLH"),r=t.d_region||t.dcs_region;return i?r&&(e._setFieldExpire("MCAAMLH",n),e._setField("MCAAMLH",r),parseInt(i,10)!==r&&(this.regionChanged=!0,this.timesRegionChanged++,e._setField("MCSYNCSOP",""),e._setField("MCSYNCS",""),i=r)):(i=r)&&(e._setFieldExpire("MCAAMLH",n),e._setField("MCAAMLH",i)),i||(i=""),i},processSyncOnPage:function(e){var t,n,i,r;if((t=e.ibs)&&t instanceof Array&&(n=t.length))for(i=0;i<n;i++)r=t[i],r.syncOnPage&&this.checkFirstPartyCookie(r,"","syncOnPage")},process:function(e){var t,n,i,r,a,o=encodeURIComponent,s=!1;if((t=e.ibs)&&t instanceof Array&&(n=t.length))for(s=!0,i=0;i<n;i++)r=t[i],a=[o("ibs"),o(r.id||""),o(r.tag||""),x.encodeAndBuildRequest(r.url||[],","),o(r.ttl||""),"","",r.fireURLSync?"true":"false"],r.syncOnPage||(this.canSetThirdPartyCookies?this.addMessage(a.join("|")):r.fireURLSync&&this.checkFirstPartyCookie(r,a.join("|")));s&&this.jsonProcessed.push(e)},checkFirstPartyCookie:function(t,n,i){var r="syncOnPage"===i,a=r?"MCSYNCSOP":"MCSYNCS";e._readVisitor();var o,s,l=e._getField(a),c=!1,u=!1,d=Math.ceil((new Date).getTime()/te.MILLIS_PER_DAY);l?(o=l.split("*"),s=this.pruneSyncData(o,t.id,d),c=s.dataPresent,u=s.dataValid,c&&u||this.fireSync(r,t,n,o,a,d)):(o=[],this.fireSync(r,t,n,o,a,d))},pruneSyncData:function(e,t,n){var i,r,a,o=!1,s=!1;for(r=0;r<e.length;r++)i=e[r],a=parseInt(i.split("-")[1],10),i.match("^"+t+"-")?(o=!0,n<a?s=!0:(e.splice(r,1),r--)):n>=a&&(e.splice(r,1),r--);return{dataPresent:o,dataValid:s}},manageSyncsSize:function(e){if(e.join("*").length>this.MAX_SYNCS_LENGTH)for(e.sort(function(e,t){return parseInt(e.split("-")[1],10)-parseInt(t.split("-")[1],10)});e.join("*").length>this.MAX_SYNCS_LENGTH;)e.shift()},fireSync:function(t,n,i,r,a,o){var s=this;if(t){if("img"===n.tag){var l,c,u,d,f=n.url,g=e.loadSSL?"https:":"http:";for(l=0,c=f.length;l<c;l++){u=f[l],d=/^\/\//.test(u);var p=new Image;p.addEventListener("load",function(t,n,i,r){return function(){s.onPagePixels[t]=null,e._readVisitor();var o,l=e._getField(a),c=[];if(l){o=l.split("*");var u,d,f;for(u=0,d=o.length;u<d;u++)f=o[u],f.match("^"+n.id+"-")||c.push(f)}s.setSyncTrackingData(c,n,i,r)}}(this.onPagePixels.length,n,a,o)),p.src=(d?g:"")+u,this.onPagePixels.push(p)}}}else this.addMessage(i),this.setSyncTrackingData(r,n,a,o)},addMessage:function(t){var n=encodeURIComponent,i=n(e._enableErrorReporting?"---destpub-debug---":"---destpub---");this.messages.push((te.POST_MESSAGE_ENABLED?"":i)+t)},setSyncTrackingData:function(t,n,i,r){t.push(n.id+"-"+(r+Math.ceil(n.ttl/60/24))),this.manageSyncsSize(t),e._setField(i,t.join("*"))},sendMessages:function(){var e,t=this,n="",i=encodeURIComponent;this.regionChanged&&(n=i("---destpub-clear-dextp---"),this.regionChanged=!1),this.messages.length?te.POST_MESSAGE_ENABLED?(e=n+i("---destpub-combined---")+this.messages.join("%01"),this.postMessage(e),this.messages=[],this.sendingMessages=!1):(e=this.messages.shift(),this.postMessage(n+e),setTimeout(function(){t.sendMessages()},this.messageSendingInterval)):this.sendingMessages=!1},postMessage:function(e){$.postMessage(e,this.url,this.iframe.contentWindow),this.messagesPosted.push(e)},receiveMessage:function(e){var t,n=/^---destpub-to-parent---/;"string"==typeof e&&n.test(e)&&(t=e.replace(n,"").split("|"),"canSetThirdPartyCookies"===t[0]&&(this.canSetThirdPartyCookies="true"===t[1],this.receivedThirdPartyCookiesNotification=!0,this.requestToProcess()),this.messagesReceived.push(e))},processIDCallData:function(i){(null==this.url||i.subdomain&&"nosubdomainreturned"===this.subdomain)&&("string"==typeof e._subdomain&&e._subdomain.length?this.subdomain=e._subdomain:this.subdomain=i.subdomain||"",this.url=this.getUrl()),i.ibs instanceof Array&&i.ibs.length&&(this.doAttachIframe=!0),this.readyToAttachIframe()&&(e.idSyncAttachIframeOnWindowLoad?(t.windowLoaded||"complete"===n.readyState||"loaded"===n.readyState)&&this.attachIframe():this.attachIframeASAP()),"function"==typeof e.idSyncIDCallResult?e.idSyncIDCallResult(i):this.requestToProcess(i),"function"==typeof e.idSyncAfterIDCallResult&&e.idSyncAfterIDCallResult(i)},canMakeSyncIDCall:function(t,n){return e._forceSyncIDCall||!t||n-t>te.DAYS_BETWEEN_SYNC_ID_CALLS},attachIframeASAP:function(){function e(){t.startedAttachingIframe||(n.body?t.attachIframe():setTimeout(e,30))}var t=this;e()}}},ie={audienceManagerServer:{},audienceManagerServerSecure:{},cookieDomain:{},cookieLifetime:{},cookieName:{},doesOptInApply:{},disableThirdPartyCalls:{},idSyncAfterIDCallResult:{},idSyncAttachIframeOnWindowLoad:{},idSyncContainerID:{},idSyncDisable3rdPartySyncing:{},disableThirdPartyCookies:{},idSyncDisableSyncs:{},disableIdSyncs:{},idSyncIDCallResult:{},idSyncSSLUseAkamai:{},isCoopSafe:{},isIabContext:{},isOptInStorageEnabled:{},loadSSL:{},loadTimeout:{},marketingCloudServer:{},marketingCloudServerSecure:{},optInCookieDomain:{},optInStorageExpiry:{},overwriteCrossDomainMCIDAndAID:{},preOptInApprovals:{},previousPermissions:{},resetBeforeVersion:{},sdidParamExpiry:{},serverState:{},sessionCookieName:{},secureCookie:{},takeTimeoutMetrics:{},trackingServer:{},trackingServerSecure:{},whitelistIframeDomains:{},whitelistParentDomain:{}},re={getConfigNames:function(){return Object.keys(ie)},getConfigs:function(){return ie},normalizeConfig:function(e){return"function"!=typeof e?e:e()}},ae=function(e){var t={};return e.on=function(e,n,i){if(!n||"function"!=typeof n)throw new Error("[ON] Callback should be a function.");t.hasOwnProperty(e)||(t[e]=[]);var r=t[e].push({callback:n,context:i})-1;return function(){t[e].splice(r,1),t[e].length||delete t[e]}},e.publish=function(e){if(t.hasOwnProperty(e)){var n=[].slice.call(arguments,1);t[e].slice(0).forEach(function(e){e.callback.apply(e.context,n)})}},e.publish},oe={PENDING:"pending",CHANGED:"changed",COMPLETE:"complete"},se={AAM:"aam",ADCLOUD:"adcloud",ANALYTICS:"aa",CAMPAIGN:"campaign",ECID:"ecid",LIVEFYRE:"livefyre",TARGET:"target",VIDEO_ANALYTICS:"videoaa"},le=(h={},t(h,se.AAM,565),t(h,se.ECID,565),h),ce=(_={},t(_,se.AAM,[1,2,5]),t(_,se.ECID,[1,2,5]),_),ue=function(e){return Object.keys(e).map(function(t){return e[t]})}(se),de=function(){var e={};return e.callbacks=Object.create(null),e.add=function(t,n){if(!l(n))throw new Error("[callbackRegistryFactory] Make sure callback is a function or an array of functions.");e.callbacks[t]=e.callbacks[t]||[];var i=e.callbacks[t].push(n)-1;return function(){e.callbacks[t].splice(i,1)}},e.execute=function(t,n){if(e.callbacks[t]){n=void 0===n?[]:n,n=n instanceof Array?n:[n];try{for(;e.callbacks[t].length;){var i=e.callbacks[t].shift();"function"==typeof i?i.apply(null,n):i instanceof Array&&i[1].apply(i[0],n)}delete e.callbacks[t]}catch(e){}}},e.executeAll=function(t,n){(n||t&&!s(t))&&Object.keys(e.callbacks).forEach(function(n){var i=void 0!==t[n]?t[n]:"";e.execute(n,i)},e)},e.hasCallbacks=function(){return Boolean(Object.keys(e.callbacks).length)},e},fe=function(t,n){return e(t)===n},ge=function(e,t){return e instanceof Array?e:fe(e,"string")?[e]:t||[]},pe=function(e){var t=Object.keys(e);return!!t.length&&t.every(function(t){return!0===e[t]})},me=function(e){return!(!e||Ce(e))&&ge(e).every(function(e){return ue.indexOf(e)>-1})},he=function(e,t){return e.reduce(function(e,n){return e[n]=t,e},{})},_e=function(e){return JSON.parse(JSON.stringify(e))},Ce=function(e){return"[object Array]"===Object.prototype.toString.call(e)&&!e.length},Ie=function(e){if(Se(e))return e;try{return JSON.parse(e)}catch(e){return{}}},ve=function(e){return void 0===e||(Se(e)?me(Object.keys(e)):De(e))},De=function(e){try{var t=JSON.parse(e);return!!e&&fe(e,"string")&&me(Object.keys(t))}catch(e){return!1}},Se=function(e){return null!==e&&fe(e,"object")&&!1===Array.isArray(e)},be=function(){},Ae=function(e){return fe(e,"function")?e():e},ye=function(e,t){if(!ve(e))throw new Error("[OptIn] ".concat(t))},Oe=function(e){return Object.keys(e).map(function(t){return e[t]})},Me=function(e){return Oe(e).filter(function(e,t,n){return n.indexOf(e)===t})},ke=function(e){return function(){var t=arguments.length>0&&void 0!==arguments[0]?arguments[0]:{},n=t.command,i=t.params,r=void 0===i?{}:i,a=t.callback,o=void 0===a?be:a;if(!n||-1===n.indexOf("."))throw new Error("[OptIn.execute] Please provide a valid command.");try{var s=n.split("."),l=e[s[0]],c=s[1];if(!l||"function"!=typeof l[c])throw new Error("Make sure the plugin and API name exist.");var u=Object.assign(r,{callback:o});l[c].call(l,u)}catch(e){throw new Error("[OptIn.execute] Something went wrong: "+e.message)}}};u.prototype=Object.create(Error.prototype),u.prototype.constructor=u;var Ee="fetchPermissions",Te="[OptIn#registerPlugin] Plugin is invalid.";d.Categories=se,d.TimeoutError=u;var Le=function(){throw new Error("[IAB Plugin] A __cmp is required.")},Pe=Object.freeze({OptIn:d,IabPlugin:g}),Re={get:function(e){e=encodeURIComponent(e);var t=(";"+document.cookie).split(" ").join(";"),n=t.indexOf(";"+e+"="),i=n<0?n:t.indexOf(";",n+1);return n<0?"":decodeURIComponent(t.substring(n+2+e.length,i<0?t.length:i))},set:function(e,t,n){var i=p(n,"cookieLifetime"),r=p(n,"expires"),a=p(n,"domain");if(r&&"SESSION"!==i&&"NONE"!==i){var o=""!==t?parseInt(i||0,10):-60;if(o)r=new Date,r.setTime(r.getTime()+1e3*o);else if(1===r){r=new Date;var s=r.getYear();r.setYear(s+2+(s<1900?1900:0))}}else r=0;return e&&"NONE"!==i?(document.cookie=encodeURIComponent(e)+"="+encodeURIComponent(t)+"; path=/;"+(r?" expires="+r.toGMTString()+";":"")+(a?" domain="+a+";":""),this.get(e)===t):0},remove:function(e,t){var n=p(t,"domain");n=n?" domain="+n+";":"",document.cookie=encodeURIComponent(e)+"=; Path=/; Expires=Thu, 01 Jan 1970 00:00:01 GMT;"+n}},we=function(e,t){e.publishDestinations=function(n){var i=arguments[1],r=arguments[2];try{r="function"==typeof r?r:n.callback}catch(e){r=function(){}}var a=t;if(!a.readyToAttachIframePreliminary())return void r({error:"The destination publishing iframe is disabled in the Visitor library."});if("string"==typeof n){if(!n.length)return void r({error:"subdomain is not a populated string."});if(!(i instanceof Array&&i.length))return void r({error:"messages is not a populated array."});var o=!1;if(i.forEach(function(e){"string"==typeof e&&e.length&&(a.addMessage(e),o=!0)}),!o)return void r({error:"None of the messages are populated strings."})}else{if(!x.isObject(n))return void r({error:"Invalid parameters passed."});var s=n;if("string"!=typeof(n=s.subdomain)||!n.length)return void r({error:"config.subdomain is not a populated string."});var l=s.urlDestinations;if(!(l instanceof Array&&l.length))return void r({error:"config.urlDestinations is not a populated array."});var c=[];l.forEach(function(e){
x.isObject(e)&&(e.hideReferrer?e.message&&a.addMessage(e.message):c.push(e))});!function e(){c.length&&setTimeout(function(){var t=new Image,n=c.shift();t.src=n.url,a.onPageDestinationsFired.push(n),e()},100)}()}a.iframe?(r({message:"The destination publishing iframe is already attached and loaded."}),a.requestToProcess()):!e.subdomain&&e._getField("MCMID")?(a.subdomain=n,a.doAttachIframe=!0,a.url=a.getUrl(),a.readyToAttachIframe()?(a.iframeLoadedCallbacks.push(function(e){r({message:"Attempted to attach and load the destination publishing iframe through this API call. Result: "+(e.message||"no result")})}),a.attachIframe()):r({error:"Encountered a problem in attempting to attach and load the destination publishing iframe through this API call."})):a.iframeLoadedCallbacks.push(function(e){r({message:"Attempted to attach and load the destination publishing iframe through normal Visitor API processing. Result: "+(e.message||"no result")})})}},Fe=Pe.OptIn;x.defineGlobalNamespace(),window.adobe.OptInCategories=Fe.Categories;var xe=function(t,n,i){function r(e){var t=e;return function(e){var n=e||h.location.href;try{var i=d._extractParamFromUri(n,t);if(i)return T.parsePipeDelimetedKeyValues(i)}catch(e){}}}function a(e){function t(e,t){e&&e.match(te.VALID_VISITOR_ID_REGEX)&&t(e)}t(e[I],d.setMarketingCloudVisitorID),d._setFieldExpire(A,-1),t(e[S],d.setAnalyticsVisitorID)}function o(e){e=e||{},d._supplementalDataIDCurrent=e.supplementalDataIDCurrent||"",d._supplementalDataIDCurrentConsumed=e.supplementalDataIDCurrentConsumed||{},d._supplementalDataIDLast=e.supplementalDataIDLast||"",d._supplementalDataIDLastConsumed=e.supplementalDataIDLastConsumed||{}}function s(e){function t(e,t,n){return n=n?n+="|":n,n+=e+"="+encodeURIComponent(t)}function n(e,n){var i=n[0],r=n[1];return null!=r&&r!==y&&(e=t(i,r,e)),e}var i=e.reduce(n,"");return function(e){var t=T.getTimestampInSeconds();return e=e?e+="|":e,e+="TS="+t}(i)}function l(e){var t=e.minutesToLive,n="";return(d.idSyncDisableSyncs||d.disableIdSyncs)&&(n=n||"Error: id syncs have been disabled"),"string"==typeof e.dpid&&e.dpid.length||(n=n||"Error: config.dpid is empty"),"string"==typeof e.url&&e.url.length||(n=n||"Error: config.url is empty"),void 0===t?t=20160:(t=parseInt(t,10),(isNaN(t)||t<=0)&&(n=n||"Error: config.minutesToLive needs to be a positive number")),{error:n,ttl:t}}function c(){return!(!d.configs.doesOptInApply||f.optIn.isComplete||u())}function u(){return d.configs.isIabContext?f.optIn.isApproved(f.optIn.Categories.ECID)&&p:f.optIn.isApproved(f.optIn.Categories.ECID)}if(!i||i.split("").reverse().join("")!==t)throw new Error("Please use `Visitor.getInstance` to instantiate Visitor.");var d=this,f=window.adobe,g="",p=!1;d.version="4.1.0";var h=m,_=h.Visitor;_.version=d.version,_.AuthState=M.AUTH_STATE,_.OptOut=M.OPT_OUT,h.s_c_in||(h.s_c_il=[],h.s_c_in=0),d._c="Visitor",d._il=h.s_c_il,d._in=h.s_c_in,d._il[d._in]=d,h.s_c_in++,d._instanceType="regular",d._log={requests:[]},d.marketingCloudOrgID=t,d.cookieName="AMCV_"+t,d.sessionCookieName="AMCVS_"+t,d.cookieDomain=J(),d.cookieDomain===h.location.hostname&&(d.cookieDomain=""),d.loadSSL=h.location.protocol.toLowerCase().indexOf("https")>=0,d.loadTimeout=3e4,d.CORSErrors=[],d.marketingCloudServer=d.audienceManagerServer="dpm.demdex.net",d.sdidParamExpiry=30;var C=null,I="MCMID",v="MCIDTS",D="A",S="MCAID",b="AAM",A="MCAAMB",y="NONE",O=function(e){return!Object.prototype[e]},k=ee(d);d.FIELDS=M.FIELDS,d.cookieRead=function(e){return Re.get(e)},d.cookieWrite=function(e,t,n){var i=d.cookieLifetime?(""+d.cookieLifetime).toUpperCase():"";return Re.set(e,""+t,{expires:n,domain:d.cookieDomain,cookieLifetime:i})},d.resetState=function(e){e?d._mergeServerState(e):o()},d._isAllowedDone=!1,d._isAllowedFlag=!1,d.isAllowed=function(){return d._isAllowedDone||(d._isAllowedDone=!0,(d.cookieRead(d.cookieName)||d.cookieWrite(d.cookieName,"T",1))&&(d._isAllowedFlag=!0)),"T"===d.cookieRead(d.cookieName)&&d._helpers.removeCookie(d.cookieName),d._isAllowedFlag},d.setMarketingCloudVisitorID=function(e){d._setMarketingCloudFields(e)},d._use1stPartyMarketingCloudServer=!1,d.getMarketingCloudVisitorID=function(e,t){d.marketingCloudServer&&d.marketingCloudServer.indexOf(".demdex.net")<0&&(d._use1stPartyMarketingCloudServer=!0);var n=d._getAudienceManagerURLData("_setMarketingCloudFields"),i=n.url;return d._getRemoteField(I,i,e,t,n)},d.getVisitorValues=function(e,t){var n={MCMID:{fn:d.getMarketingCloudVisitorID,args:[!0],context:d},MCOPTOUT:{fn:d.isOptedOut,args:[void 0,!0],context:d},MCAID:{fn:d.getAnalyticsVisitorID,args:[!0],context:d},MCAAMLH:{fn:d.getAudienceManagerLocationHint,args:[!0],context:d},MCAAMB:{fn:d.getAudienceManagerBlob,args:[!0],context:d}},i=t&&t.length?x.pluck(n,t):n;W(i,e)},d._currentCustomerIDs={},d._customerIDsHashChanged=!1,d._newCustomerIDsHash="",d.setCustomerIDs=function(t){function n(){d._customerIDsHashChanged=!1}if(t){if(!x.isObject(t)||x.isObjectEmpty(t))return!1;d._readVisitor();var i,r;for(i in t)if(O(i)&&(r=t[i]))if("object"===e(r)){var a={};r.id&&(a.id=r.id),void 0!=r.authState&&(a.authState=r.authState),d._currentCustomerIDs[i]=a}else d._currentCustomerIDs[i]={id:r};var o=d.getCustomerIDs(),s=d._getField("MCCIDH"),l="";s||(s=0);for(i in o)O(i)&&(r=o[i],l+=(l?"|":"")+i+"|"+(r.id?r.id:"")+(r.authState?r.authState:""));d._newCustomerIDsHash=String(d._hash(l)),d._newCustomerIDsHash!==s&&(d._customerIDsHashChanged=!0,d._mapCustomerIDs(n))}},d.getCustomerIDs=function(){d._readVisitor();var e,t,n={};for(e in d._currentCustomerIDs)O(e)&&(t=d._currentCustomerIDs[e],n[e]||(n[e]={}),t.id&&(n[e].id=t.id),void 0!=t.authState?n[e].authState=t.authState:n[e].authState=_.AuthState.UNKNOWN);return n},d.setAnalyticsVisitorID=function(e){d._setAnalyticsFields(e)},d.getAnalyticsVisitorID=function(e,t,n){if(!T.isTrackingServerPopulated()&&!n)return d._callCallback(e,[""]),"";var i="";if(n||(i=d.getMarketingCloudVisitorID(function(t){d.getAnalyticsVisitorID(e,!0)})),i||n){var r=n?d.marketingCloudServer:d.trackingServer,a="";d.loadSSL&&(n?d.marketingCloudServerSecure&&(r=d.marketingCloudServerSecure):d.trackingServerSecure&&(r=d.trackingServerSecure));var o={};if(r){var s="http"+(d.loadSSL?"s":"")+"://"+r+"/id",l="d_visid_ver="+d.version+"&mcorgid="+encodeURIComponent(d.marketingCloudOrgID)+(i?"&mid="+encodeURIComponent(i):"")+(d.idSyncDisable3rdPartySyncing||d.disableThirdPartyCookies?"&d_coppa=true":""),c=["s_c_il",d._in,"_set"+(n?"MarketingCloud":"Analytics")+"Fields"];a=s+"?"+l+"&callback=s_c_il%5B"+d._in+"%5D._set"+(n?"MarketingCloud":"Analytics")+"Fields",o.corsUrl=s+"?"+l,o.callback=c}return o.url=a,d._getRemoteField(n?I:S,a,e,t,o)}return""},d.getAudienceManagerLocationHint=function(e,t){if(d.getMarketingCloudVisitorID(function(t){d.getAudienceManagerLocationHint(e,!0)})){var n=d._getField(S);if(!n&&T.isTrackingServerPopulated()&&(n=d.getAnalyticsVisitorID(function(t){d.getAudienceManagerLocationHint(e,!0)})),n||!T.isTrackingServerPopulated()){var i=d._getAudienceManagerURLData(),r=i.url;return d._getRemoteField("MCAAMLH",r,e,t,i)}}return""},d.getLocationHint=d.getAudienceManagerLocationHint,d.getAudienceManagerBlob=function(e,t){if(d.getMarketingCloudVisitorID(function(t){d.getAudienceManagerBlob(e,!0)})){var n=d._getField(S);if(!n&&T.isTrackingServerPopulated()&&(n=d.getAnalyticsVisitorID(function(t){d.getAudienceManagerBlob(e,!0)})),n||!T.isTrackingServerPopulated()){var i=d._getAudienceManagerURLData(),r=i.url;return d._customerIDsHashChanged&&d._setFieldExpire(A,-1),d._getRemoteField(A,r,e,t,i)}}return""},d._supplementalDataIDCurrent="",d._supplementalDataIDCurrentConsumed={},d._supplementalDataIDLast="",d._supplementalDataIDLastConsumed={},d.getSupplementalDataID=function(e,t){d._supplementalDataIDCurrent||t||(d._supplementalDataIDCurrent=d._generateID(1));var n=d._supplementalDataIDCurrent;return d._supplementalDataIDLast&&!d._supplementalDataIDLastConsumed[e]?(n=d._supplementalDataIDLast,d._supplementalDataIDLastConsumed[e]=!0):n&&(d._supplementalDataIDCurrentConsumed[e]&&(d._supplementalDataIDLast=d._supplementalDataIDCurrent,d._supplementalDataIDLastConsumed=d._supplementalDataIDCurrentConsumed,d._supplementalDataIDCurrent=n=t?"":d._generateID(1),d._supplementalDataIDCurrentConsumed={}),n&&(d._supplementalDataIDCurrentConsumed[e]=!0)),n};var E=!1;d._liberatedOptOut=null,d.getOptOut=function(e,t){var n=d._getAudienceManagerURLData("_setMarketingCloudFields"),i=n.url;if(u())return d._getRemoteField("MCOPTOUT",i,e,t,n);if(d._registerCallback("liberatedOptOut",e),null!==d._liberatedOptOut)return d._callAllCallbacks("liberatedOptOut",[d._liberatedOptOut]),E=!1,d._liberatedOptOut;if(E)return null;E=!0;var r="liberatedGetOptOut";return n.corsUrl=n.corsUrl.replace(/dpm\.demdex\.net\/id\?/,"dpm.demdex.net/optOutStatus?"),n.callback=[r],m[r]=function(e){if(e===Object(e)){var t,n,i=x.parseOptOut(e,t,y);t=i.optOut,n=1e3*i.d_ottl,d._liberatedOptOut=t,setTimeout(function(){d._liberatedOptOut=null},n)}d._callAllCallbacks("liberatedOptOut",[t]),E=!1},k.fireCORS(n),null},d.isOptedOut=function(e,t,n){t||(t=_.OptOut.GLOBAL);var i=d.getOptOut(function(n){var i=n===_.OptOut.GLOBAL||n.indexOf(t)>=0;d._callCallback(e,[i])},n);return i?i===_.OptOut.GLOBAL||i.indexOf(t)>=0:null},d._fields=null,d._fieldsExpired=null,d._hash=function(e){var t,n,i=0;if(e)for(t=0;t<e.length;t++)n=e.charCodeAt(t),i=(i<<5)-i+n,i&=i;return i},d._generateID=Z,d._generateLocalMID=function(){var e=d._generateID(0);return P.isClientSideMarketingCloudVisitorID=!0,e},d._callbackList=null,d._callCallback=function(e,t){try{"function"==typeof e?e.apply(h,t):e[1].apply(e[0],t)}catch(e){}},d._registerCallback=function(e,t){t&&(null==d._callbackList&&(d._callbackList={}),void 0==d._callbackList[e]&&(d._callbackList[e]=[]),d._callbackList[e].push(t))},d._callAllCallbacks=function(e,t){if(null!=d._callbackList){var n=d._callbackList[e];if(n)for(;n.length>0;)d._callCallback(n.shift(),t)}},d._addQuerystringParam=function(e,t,n,i){var r=encodeURIComponent(t)+"="+encodeURIComponent(n),a=T.parseHash(e),o=T.hashlessUrl(e);if(-1===o.indexOf("?"))return o+"?"+r+a;var s=o.split("?"),l=s[0]+"?",c=s[1];return l+T.addQueryParamAtLocation(c,r,i)+a},d._extractParamFromUri=function(e,t){var n=new RegExp("[\\?&#]"+t+"=([^&#]*)"),i=n.exec(e);if(i&&i.length)return decodeURIComponent(i[1])},d._parseAdobeMcFromUrl=r(te.ADOBE_MC),d._parseAdobeMcSdidFromUrl=r(te.ADOBE_MC_SDID),d._attemptToPopulateSdidFromUrl=function(e){var n=d._parseAdobeMcSdidFromUrl(e),i=1e9;n&&n.TS&&(i=T.getTimestampInSeconds()-n.TS),n&&n.SDID&&n.MCORGID===t&&i<d.sdidParamExpiry&&(d._supplementalDataIDCurrent=n.SDID,d._supplementalDataIDCurrentConsumed.SDID_URL_PARAM=!0)},d._attemptToPopulateIdsFromUrl=function(){var e=d._parseAdobeMcFromUrl();if(e&&e.TS){var n=T.getTimestampInSeconds(),i=n-e.TS;if(Math.floor(i/60)>te.ADOBE_MC_TTL_IN_MIN||e.MCORGID!==t)return;a(e)}},d._mergeServerState=function(e){if(e)try{if(e=function(e){return T.isObject(e)?e:JSON.parse(e)}(e),e[d.marketingCloudOrgID]){var t=e[d.marketingCloudOrgID];!function(e){T.isObject(e)&&d.setCustomerIDs(e)}(t.customerIDs),o(t.sdid)}}catch(e){throw new Error("`serverState` has an invalid format.")}},d._timeout=null,d._loadData=function(e,t,n,i){t=d._addQuerystringParam(t,"d_fieldgroup",e,1),i.url=d._addQuerystringParam(i.url,"d_fieldgroup",e,1),i.corsUrl=d._addQuerystringParam(i.corsUrl,"d_fieldgroup",e,1),P.fieldGroupObj[e]=!0,i===Object(i)&&i.corsUrl&&"XMLHttpRequest"===k.corsMetadata.corsType&&k.fireCORS(i,n,e)},d._clearTimeout=function(e){null!=d._timeout&&d._timeout[e]&&(clearTimeout(d._timeout[e]),d._timeout[e]=0)},d._settingsDigest=0,d._getSettingsDigest=function(){if(!d._settingsDigest){var e=d.version;d.audienceManagerServer&&(e+="|"+d.audienceManagerServer),d.audienceManagerServerSecure&&(e+="|"+d.audienceManagerServerSecure),d._settingsDigest=d._hash(e)}return d._settingsDigest},d._readVisitorDone=!1,d._readVisitor=function(){if(!d._readVisitorDone){d._readVisitorDone=!0;var e,t,n,i,r,a,o=d._getSettingsDigest(),s=!1,l=d.cookieRead(d.cookieName),c=new Date;if(null==d._fields&&(d._fields={}),l&&"T"!==l)for(l=l.split("|"),l[0].match(/^[\-0-9]+$/)&&(parseInt(l[0],10)!==o&&(s=!0),l.shift()),l.length%2==1&&l.pop(),e=0;e<l.length;e+=2)t=l[e].split("-"),n=t[0],i=l[e+1],t.length>1?(r=parseInt(t[1],10),a=t[1].indexOf("s")>0):(r=0,a=!1),s&&("MCCIDH"===n&&(i=""),r>0&&(r=c.getTime()/1e3-60)),n&&i&&(d._setField(n,i,1),r>0&&(d._fields["expire"+n]=r+(a?"s":""),(c.getTime()>=1e3*r||a&&!d.cookieRead(d.sessionCookieName))&&(d._fieldsExpired||(d._fieldsExpired={}),d._fieldsExpired[n]=!0)));!d._getField(S)&&T.isTrackingServerPopulated()&&(l=d.cookieRead("s_vi"))&&(l=l.split("|"),l.length>1&&l[0].indexOf("v1")>=0&&(i=l[1],e=i.indexOf("["),e>=0&&(i=i.substring(0,e)),i&&i.match(te.VALID_VISITOR_ID_REGEX)&&d._setField(S,i)))}},d._appendVersionTo=function(e){var t="vVersion|"+d.version,n=e?d._getCookieVersion(e):null;return n?K.areVersionsDifferent(n,d.version)&&(e=e.replace(te.VERSION_REGEX,t)):e+=(e?"|":"")+t,e},d._writeVisitor=function(){var e,t,n=d._getSettingsDigest();for(e in d._fields)O(e)&&d._fields[e]&&"expire"!==e.substring(0,6)&&(t=d._fields[e],n+=(n?"|":"")+e+(d._fields["expire"+e]?"-"+d._fields["expire"+e]:"")+"|"+t);n=d._appendVersionTo(n),d.cookieWrite(d.cookieName,n,1)},d._getField=function(e,t){return null==d._fields||!t&&d._fieldsExpired&&d._fieldsExpired[e]?null:d._fields[e]},d._setField=function(e,t,n){null==d._fields&&(d._fields={}),d._fields[e]=t,n||d._writeVisitor()},d._getFieldList=function(e,t){var n=d._getField(e,t);return n?n.split("*"):null},d._setFieldList=function(e,t,n){d._setField(e,t?t.join("*"):"",n)},d._getFieldMap=function(e,t){var n=d._getFieldList(e,t);if(n){var i,r={};for(i=0;i<n.length;i+=2)r[n[i]]=n[i+1];return r}return null},d._setFieldMap=function(e,t,n){var i,r=null;if(t){r=[];for(i in t)O(i)&&(r.push(i),r.push(t[i]))}d._setFieldList(e,r,n)},d._setFieldExpire=function(e,t,n){var i=new Date;i.setTime(i.getTime()+1e3*t),null==d._fields&&(d._fields={}),d._fields["expire"+e]=Math.floor(i.getTime()/1e3)+(n?"s":""),t<0?(d._fieldsExpired||(d._fieldsExpired={}),d._fieldsExpired[e]=!0):d._fieldsExpired&&(d._fieldsExpired[e]=!1),n&&(d.cookieRead(d.sessionCookieName)||d.cookieWrite(d.sessionCookieName,"1"))},d._findVisitorID=function(t){return t&&("object"===e(t)&&(t=t.d_mid?t.d_mid:t.visitorID?t.visitorID:t.id?t.id:t.uuid?t.uuid:""+t),t&&"NOTARGET"===(t=t.toUpperCase())&&(t=y),t&&(t===y||t.match(te.VALID_VISITOR_ID_REGEX))||(t="")),t},d._setFields=function(t,n){if(d._clearTimeout(t),null!=d._loading&&(d._loading[t]=!1),P.fieldGroupObj[t]&&P.setState(t,!1),"MC"===t){!0!==P.isClientSideMarketingCloudVisitorID&&(P.isClientSideMarketingCloudVisitorID=!1);var i=d._getField(I);if(!i||d.overwriteCrossDomainMCIDAndAID){if(!(i="object"===e(n)&&n.mid?n.mid:d._findVisitorID(n))){if(d._use1stPartyMarketingCloudServer&&!d.tried1stPartyMarketingCloudServer)return d.tried1stPartyMarketingCloudServer=!0,void d.getAnalyticsVisitorID(null,!1,!0);i=d._generateLocalMID()}d._setField(I,i)}i&&i!==y||(i=""),"object"===e(n)&&((n.d_region||n.dcs_region||n.d_blob||n.blob)&&d._setFields(b,n),d._use1stPartyMarketingCloudServer&&n.mid&&d._setFields(D,{id:n.id})),d._callAllCallbacks(I,[i])}if(t===b&&"object"===e(n)){var r=604800;void 0!=n.id_sync_ttl&&n.id_sync_ttl&&(r=parseInt(n.id_sync_ttl,10));var a=L.getRegionAndCheckIfChanged(n,r);d._callAllCallbacks("MCAAMLH",[a]);var o=d._getField(A);(n.d_blob||n.blob)&&(o=n.d_blob,o||(o=n.blob),d._setFieldExpire(A,r),d._setField(A,o)),o||(o=""),d._callAllCallbacks(A,[o]),!n.error_msg&&d._newCustomerIDsHash&&d._setField("MCCIDH",d._newCustomerIDsHash)}if(t===D){var s=d._getField(S);s&&!d.overwriteCrossDomainMCIDAndAID||(s=d._findVisitorID(n),s?s!==y&&d._setFieldExpire(A,-1):s=y,d._setField(S,s)),s&&s!==y||(s=""),d._callAllCallbacks(S,[s])}if(d.idSyncDisableSyncs||d.disableIdSyncs)L.idCallNotProcesssed=!0;else{L.idCallNotProcesssed=!1;var l={};l.ibs=n.ibs,l.subdomain=n.subdomain,L.processIDCallData(l)}if(n===Object(n)){var c,f;u()&&d.isAllowed()&&(c=d._getField("MCOPTOUT"));var g=x.parseOptOut(n,c,y);c=g.optOut,f=g.d_ottl,d._setFieldExpire("MCOPTOUT",f,!0),d._setField("MCOPTOUT",c),d._callAllCallbacks("MCOPTOUT",[c])}},d._loading=null,d._getRemoteField=function(e,t,n,i,r){var a,o="",s=T.isFirstPartyAnalyticsVisitorIDCall(e),l={MCAAMLH:!0,MCAAMB:!0};if(u()&&d.isAllowed()){d._readVisitor(),o=d._getField(e,!0===l[e]);if(function(){return(!o||d._fieldsExpired&&d._fieldsExpired[e])&&(!d.disableThirdPartyCalls||s)}()){if(e===I||"MCOPTOUT"===e?a="MC":"MCAAMLH"===e||e===A?a=b:e===S&&(a=D),a)return!t||null!=d._loading&&d._loading[a]||(null==d._loading&&(d._loading={}),d._loading[a]=!0,d._loadData(a,t,function(t){if(!d._getField(e)){t&&P.setState(a,!0);var n="";e===I?n=d._generateLocalMID():a===b&&(n={error_msg:"timeout"}),d._setFields(a,n)}},r)),d._registerCallback(e,n),o||(t||d._setFields(a,{id:y}),"")}else o||(e===I?(d._registerCallback(e,n),o=d._generateLocalMID(),d.setMarketingCloudVisitorID(o)):e===S?(d._registerCallback(e,n),o="",d.setAnalyticsVisitorID(o)):(o="",i=!0))}return e!==I&&e!==S||o!==y||(o="",i=!0),n&&i&&d._callCallback(n,[o]),o},d._setMarketingCloudFields=function(e){d._readVisitor(),d._setFields("MC",e)},d._mapCustomerIDs=function(e){d.getAudienceManagerBlob(e,!0)},d._setAnalyticsFields=function(e){d._readVisitor(),d._setFields(D,e)},d._setAudienceManagerFields=function(e){d._readVisitor(),d._setFields(b,e)},d._getAudienceManagerURLData=function(e){var t=d.audienceManagerServer,n="",i=d._getField(I),r=d._getField(A,!0),a=d._getField(S),o=a&&a!==y?"&d_cid_ic=AVID%01"+encodeURIComponent(a):"";if(d.loadSSL&&d.audienceManagerServerSecure&&(t=d.audienceManagerServerSecure),t){var s,l,c=d.getCustomerIDs();if(c)for(s in c)O(s)&&(l=c[s],o+="&d_cid_ic="+encodeURIComponent(s)+"%01"+encodeURIComponent(l.id?l.id:"")+(l.authState?"%01"+l.authState:""));e||(e="_setAudienceManagerFields");var u="http"+(d.loadSSL?"s":"")+"://"+t+"/id",f="d_visid_ver="+d.version+(g&&-1!==u.indexOf("demdex.net")?"&gdpr=1&gdpr_force=1&gdpr_consent="+g:"")+"&d_rtbd=json&d_ver=2"+(!i&&d._use1stPartyMarketingCloudServer?"&d_verify=1":"")+"&d_orgid="+encodeURIComponent(d.marketingCloudOrgID)+"&d_nsid="+(d.idSyncContainerID||0)+(i?"&d_mid="+encodeURIComponent(i):"")+(d.idSyncDisable3rdPartySyncing||d.disableThirdPartyCookies?"&d_coppa=true":"")+(!0===C?"&d_coop_safe=1":!1===C?"&d_coop_unsafe=1":"")+(r?"&d_blob="+encodeURIComponent(r):"")+o,p=["s_c_il",d._in,e];return n=u+"?"+f+"&d_cb=s_c_il%5B"+d._in+"%5D."+e,{url:n,corsUrl:u+"?"+f,callback:p}}return{url:n}},d.appendVisitorIDsTo=function(e){try{var t=[[I,d._getField(I)],[S,d._getField(S)],["MCORGID",d.marketingCloudOrgID]];return d._addQuerystringParam(e,te.ADOBE_MC,s(t))}catch(t){return e}},d.appendSupplementalDataIDTo=function(e,t){if(!(t=t||d.getSupplementalDataID(T.generateRandomString(),!0)))return e;try{var n=s([["SDID",t],["MCORGID",d.marketingCloudOrgID]]);return d._addQuerystringParam(e,te.ADOBE_MC_SDID,n)}catch(t){return e}};var T={parseHash:function(e){var t=e.indexOf("#");return t>0?e.substr(t):""},hashlessUrl:function(e){var t=e.indexOf("#");return t>0?e.substr(0,t):e},addQueryParamAtLocation:function(e,t,n){var i=e.split("&");return n=null!=n?n:i.length,i.splice(n,0,t),i.join("&")},isFirstPartyAnalyticsVisitorIDCall:function(e,t,n){if(e!==S)return!1;var i;return t||(t=d.trackingServer),n||(n=d.trackingServerSecure),!("string"!=typeof(i=d.loadSSL?n:t)||!i.length)&&(i.indexOf("2o7.net")<0&&i.indexOf("omtrdc.net")<0)},isObject:function(e){return Boolean(e&&e===Object(e))},removeCookie:function(e){Re.remove(e,{domain:d.cookieDomain})},isTrackingServerPopulated:function(){return!!d.trackingServer||!!d.trackingServerSecure},getTimestampInSeconds:function(){return Math.round((new Date).getTime()/1e3)},parsePipeDelimetedKeyValues:function(e){return e.split("|").reduce(function(e,t){var n=t.split("=");return e[n[0]]=decodeURIComponent(n[1]),e},{})},generateRandomString:function(e){e=e||5;for(var t="",n="abcdefghijklmnopqrstuvwxyz0123456789";e--;)t+=n[Math.floor(Math.random()*n.length)];return t},normalizeBoolean:function(e){return"true"===e||"false"!==e&&e},parseBoolean:function(e){return"true"===e||"false"!==e&&null},replaceMethodsWithFunction:function(e,t){for(var n in e)e.hasOwnProperty(n)&&"function"==typeof e[n]&&(e[n]=t);return e}};d._helpers=T;var L=ne(d,_);d._destinationPublishing=L,d.timeoutMetricsLog=[];var P={isClientSideMarketingCloudVisitorID:null,MCIDCallTimedOut:null,AnalyticsIDCallTimedOut:null,AAMIDCallTimedOut:null,fieldGroupObj:{},setState:function(e,t){switch(e){case"MC":!1===t?!0!==this.MCIDCallTimedOut&&(this.MCIDCallTimedOut=!1):this.MCIDCallTimedOut=t;break;case D:!1===t?!0!==this.AnalyticsIDCallTimedOut&&(this.AnalyticsIDCallTimedOut=!1):this.AnalyticsIDCallTimedOut=t;break;case b:!1===t?!0!==this.AAMIDCallTimedOut&&(this.AAMIDCallTimedOut=!1):this.AAMIDCallTimedOut=t}}};d.isClientSideMarketingCloudVisitorID=function(){return P.isClientSideMarketingCloudVisitorID},d.MCIDCallTimedOut=function(){return P.MCIDCallTimedOut},d.AnalyticsIDCallTimedOut=function(){return P.AnalyticsIDCallTimedOut},d.AAMIDCallTimedOut=function(){return P.AAMIDCallTimedOut},d.idSyncGetOnPageSyncInfo=function(){return d._readVisitor(),d._getField("MCSYNCSOP")},d.idSyncByURL=function(e){var t=l(e||{});if(t.error)return t.error;var n,i,r=e.url,a=encodeURIComponent,o=L;return r=r.replace(/^https:/,"").replace(/^http:/,""),n=x.encodeAndBuildRequest(["",e.dpid,e.dpuuid||""],","),i=["ibs",a(e.dpid),"img",a(r),t.ttl,"",n],o.addMessage(i.join("|")),o.requestToProcess(),"Successfully queued"},d.idSyncByDataSource=function(e){return e===Object(e)&&"string"==typeof e.dpuuid&&e.dpuuid.length?(e.url="//dpm.demdex.net/ibs:dpid="+e.dpid+"&dpuuid="+e.dpuuid,d.idSyncByURL(e)):"Error: config or config.dpuuid is empty"},we(d,L),d._getCookieVersion=function(e){e=e||d.cookieRead(d.cookieName);var t=te.VERSION_REGEX.exec(e);return t&&t.length>1?t[1]:null},d._resetAmcvCookie=function(e){var t=d._getCookieVersion();t&&!K.isLessThan(t,e)||T.removeCookie(d.cookieName)},d.setAsCoopSafe=function(){C=!0},d.setAsCoopUnsafe=function(){C=!1},function(){if(d.configs=Object.create(null),T.isObject(n))for(var e in n)O(e)&&(d[e]=n[e],d.configs[e]=n[e])}(),function(){[["getMarketingCloudVisitorID"],["setCustomerIDs",void 0],["getAnalyticsVisitorID"],["getAudienceManagerLocationHint"],["getLocationHint"],["getAudienceManagerBlob"]].forEach(function(e){var t=e[0],n=2===e.length?e[1]:"",i=d[t];d[t]=function(e){return u()&&d.isAllowed()?i.apply(d,arguments):("function"==typeof e&&d._callCallback(e,[n]),n)}})}(),d.init=function(){if(c())var e=f.optIn.fetchPermissions(function(){f.optIn.isApproved(f.optIn.Categories.ECID)&&(d.configs.isIabContext?f.optIn.execute({command:"iabPlugin.fetchConsentData",callback:function(t,n){if(p=!0,t)throw new Error("[IAB plugin] : "+t);n.gdprApplies&&(g=n.consentString),d.init(),e()}}):(d.init(),e()))},!0);else!function(){if(T.isObject(n)){d.idSyncContainerID=d.idSyncContainerID||0,C="boolean"==typeof d.isCoopSafe?d.isCoopSafe:T.parseBoolean(d.isCoopSafe),d.resetBeforeVersion&&d._resetAmcvCookie(d.resetBeforeVersion),d._attemptToPopulateIdsFromUrl(),d._attemptToPopulateSdidFromUrl(),d._readVisitor();var e=d._getField(v),t=Math.ceil((new Date).getTime()/te.MILLIS_PER_DAY);d.idSyncDisableSyncs||d.disableIdSyncs||!L.canMakeSyncIDCall(e,t)||(d._setFieldExpire(A,-1),d._setField(v,t)),d.getMarketingCloudVisitorID(),d.getAudienceManagerLocationHint(),d.getAudienceManagerBlob(),d._mergeServerState(d.serverState)}else d._attemptToPopulateIdsFromUrl(),d._attemptToPopulateSdidFromUrl()}(),function(){if(!d.idSyncDisableSyncs&&!d.disableIdSyncs){L.checkDPIframeSrc();var e=function(){var e=L;e.readyToAttachIframe()&&e.attachIframe()};h.addEventListener("load",function(){_.windowLoaded=!0,e()});try{$.receiveMessage(function(e){L.receiveMessage(e.data)},L.iframeHost)}catch(e){}}}(),function(){d.whitelistIframeDomains&&te.POST_MESSAGE_ENABLED&&(d.whitelistIframeDomains=d.whitelistIframeDomains instanceof Array?d.whitelistIframeDomains:[d.whitelistIframeDomains],d.whitelistIframeDomains.forEach(function(e){var n=new U(t,e),i=z(d,n);$.receiveMessage(i,e)}))}()}};xe.config=re,m.Visitor=xe;var Ne=xe,je=Pe.OptIn,Ve=Pe.IabPlugin;return Ne.getInstance=function(e,t){if(!e)throw new Error("Visitor requires Adobe Marketing Cloud Org ID.");e.indexOf("@")<0&&(e+="@AdobeOrg");var n=function(){var t=m.s_c_il;if(t)for(var n=0;n<t.length;n++){var i=t[n];if(i&&"Visitor"===i._c&&i.marketingCloudOrgID===e)return i}}();if(n)return n;var i=function(){if(x.isObject(t))return Object.keys(t).reduce(function(e,n){var i="doesOptInApply"!==n?t[n]:!!re.normalizeConfig(t[n]),r=x.normalizeBoolean(i);return e[n]=r,e},Object.create(null))}();!function(e){m.adobe.optIn=m.adobe.optIn||function(){var t=x.pluck(e,["doesOptInApply","previousPermissions","preOptInApprovals","isOptInStorageEnabled","optInStorageExpiry","isIabContext"]),n=e.optInCookieDomain||e.cookieDomain;n=n||J(),n=n===window.location.hostname?"":n,t.optInCookieDomain=n;var i=new je(t,{cookies:Re});if(t.isIabContext){var r=new Ve(window.__cmp);i.registerPlugin(r)}return i}()}(i||{});var r=e,a=r.split("").reverse().join(""),o=new Ne(e,null,a);x.isObject(i)&&i.cookieDomain&&(o.cookieDomain=i.cookieDomain),function(){m.s_c_il.splice(--m.s_c_in,1)}();var s=x.getIeVersion();if("number"==typeof s&&s<10)return o._helpers.replaceMethodsWithFunction(o,function(){});var l=function(){try{return m.self!==m.parent}catch(e){return!0}}()&&!function(e){return e.cookieWrite("TEST_AMCV_COOKIE","T",1),"T"===e.cookieRead("TEST_AMCV_COOKIE")&&(e._helpers.removeCookie("TEST_AMCV_COOKIE"),!0)}(o)&&m.parent?new B(e,i,o,m.parent):new Ne(e,i,a);return o=null,l.init(),l},function(){function e(){Ne.windowLoaded=!0}m.addEventListener?m.addEventListener("load",e):m.attachEvent&&m.attachEvent("onload",e),Ne.codeLoadEnd=(new Date).getTime()}(),Ne}();

//tealium universal tag - utag.sender.1191 ut4.0.201910021213, Copyright 2019 Tealium.com Inc. All Rights Reserved.
try {
  (function (id, loader) {

    /* Tealium VisitorAPIWrapper v1.0 */
    window.utag.tagsettings = window.utag.tagsettings || {};
    window.utag.tagsettings.adobe = window.utag.tagsettings.adobe || {};
    var vAPI = window.utag.tagsettings.adobe.visitorAPI = window.utag.tagsettings.adobe.visitorAPI || (function () {
      function logger (msg) {
        utag.DB('[' + id + '] : ' + msg);
      }

      function Observer (orgId, config) {
        var observers = [],
          visitor = {},
          demdex = null,
          instance = null,
          /* gotcha: http://stackoverflow.com/questions/6891545/javascript-regexp-test-returns-false-even-though-it-should-return-true */
          regex = new RegExp('AMCV_' + window.encodeURIComponent(orgId) + '=(.*?)(;|$)'),
          active = false,
          util = {
            'hasOwn': function (o, a) {
              return o !== null && Object.prototype.hasOwnProperty.call(o, a);
            }
          },
          /* register all configured marketing cloud tags */
          mTags = (function () {
            var tags = [],
              tag,
              cfg = utag.loader.cfg,
              loadcond = {
                1: 1,
                4: 1
              };
            for (tag in cfg) {
              if (!util.hasOwn(cfg, tag)) {
                continue;
              }
              if (cfg[tag].tid === 1191 && loadcond[cfg[tag].load]) {
                tags.push(tag);
              }
            }
            return tags;
          }());

          function mTagsLoaded () {
            var loaded = true, id;
            for (var i = 0, len = mTags.length; i < len; i++) {
              id = mTags[i];
              if (!utag.loader.f[id]) {
                loaded = false;
                break;
              }
            }
            return loaded;
          }

          function notify (result) {
            instance = result;
            /* iterate object and reverse lookup auth flags */
            if (instance && instance.setCustomerIDs) {
              var aliases, alias;
              for (aliases in visitor) {
                if (util.hasOwn(visitor, aliases)) {
                  alias = visitor[aliases];
                  if (alias.authState && Visitor.AuthState[alias.authState] !== undefined) {
                    alias.authState = Visitor.AuthState[alias.authState];
                  }
                }
              }
              instance.setCustomerIDs(visitor);
            }
            while(observers.length !==0) {
              var nextCallback = observers.shift();
              nextCallback(instance);
            }
            return true;
          }

          this.sync = function (ids) {
            var alias;
            for (alias in ids) {
              if (util.hasOwn(ids, alias)) {
                if (!visitor[alias]) {
                  visitor[alias] = ids[alias];
                }
              }
            }
            return true;
          };
          this.subscribe = function (callback) {
            var self = this;
            if (instance !== null) {
              return callback(instance);
            } else {
              observers.push(callback);
              if (!active) {
                logger('demdex org id [' + orgId + '] sync requested');
                (function retry(retries) {
                  if (retries === 0) {
                    logger('demdex org id [' + orgId + '] sync timed out!');
                    active = false;
                    return notify(undefined);
                  } else {
                    active = true;
                    /* demdex org id cookie is set and all 1..n marketing cloud tags fired */
                    if (regex.test(document.cookie) && /\|mcmid\|/i.test(window.decodeURIComponent(RegExp.$1)) && mTagsLoaded()) {
                      logger('demdex org id [' + orgId + '] sync completed');
                      return config ? notify(window.Visitor.getInstance(orgId, config)) : notify(window.Visitor.getInstance(orgId));
                    } else {
                      if (window.Visitor && window.Visitor.getInstance) {
                        if (config && !demdex) {
                          demdex = window.Visitor.getInstance(orgId, config);
                        }
                      }
                      window.setTimeout(function () {
                        logger('demdex org id [' + orgId + '] sync, waiting...');
                        retry(--retries);
                      }, 25);
                    }
                  }
                }(80));
              }
            }
            return true;
          };
        }

        function VisitorAPIWrapper () {
          var observers = {};
          this._version = '1.0';
          this.getInstance = function (orgId, callback, config, customerIds) {
            if (!orgId) {
              return callback(undefined);
            }

            orgId = !/@AdobeOrg$/.test(orgId) ? orgId + '@AdobeOrg' : orgId;
            if (!observers[orgId]) {
              if (!config) {
                logger('demdex org id [' + orgId + '] sync error. marketing cloud tag missing demdex config');
                return callback(undefined);
              }
              observers[orgId] = new Observer(orgId, config);
            }
            if (customerIds) {
              observers[orgId].sync(customerIds);
            }
            observers[orgId].subscribe(callback);
            return true;
          };
        }

        return new VisitorAPIWrapper();
    }());

    var u = {"id" : id};
    utag.o[loader].sender[id] = u;
    // Please do not modify
    if (utag.ut === undefined) { utag.ut = {}; }
    // Start Tealium loader 4.41
    /* utag.js version 4.26 or above is required to avoid errors with this loader function */
    var match = /ut\d\.(\d*)\..*/.exec(utag.cfg.v);
    if (utag.ut.loader === undefined || !match || parseInt(match[1]) < 41) { u.loader = function(o, a, b, c, l, m) { utag.DB(o); a = document; if (o.type == "iframe") { m = a.getElementById(o.id); if (m && m.tagName == "IFRAME") { b = m; } else { b = a.createElement("iframe"); } o.attrs = o.attrs || {}; utag.ut.merge(o.attrs, { "height": "1", "width": "1", "style": "display:none" }, 0); } else if (o.type == "img") { utag.DB("Attach img: " + o.src); b = new Image(); } else { b = a.createElement("script"); b.language = "javascript"; b.type = "text/javascript"; b.async = 1; b.charset = "utf-8"; } if (o.id) { b.id = o.id; } for (l in utag.loader.GV(o.attrs)) { b.setAttribute(l, o.attrs[l]); } b.setAttribute("src", o.src); if (typeof o.cb == "function") { if (b.addEventListener) { b.addEventListener("load", function() { o.cb(); }, false); } else { b.onreadystatechange = function() { if (this.readyState == "complete" || this.readyState == "loaded") { this.onreadystatechange = null; o.cb(); } }; } } if (o.type != "img" && !m) { l = o.loc || "head"; c = a.getElementsByTagName(l)[0]; if (c) { utag.DB("Attach to " + l + ": " + o.src); if (l == "script") { c.parentNode.insertBefore(b, c); } else { c.appendChild(b); } } } }; } else { u.loader = utag.ut.loader; }
    // End Tealium loader
    // Start Tealium typeOf 4.35
    if (utag.ut.typeOf === undefined) { u.typeOf = function(e) {return ({}).toString.call(e).match(/\s([a-zA-Z]+)/)[1].toLowerCase();};} else { u.typeOf = utag.ut.typeOf; }
    // End Tealium typeOf

    u.hasOwn = function(o, a) { return o != null && Object.prototype.hasOwnProperty.call(o, a); };
    u.isEmptyObject = function(o, a) { for (a in o) { if (u.hasOwn(o, a)) return false; } return true; };

    u.ev = {"view" : 1};
    u.initialized = false;

    u.map_func = function (arr, obj, item) {
      var i = arr.shift();
      obj[i] = obj[i] || {};
      if (arr.length > 0) {
        u.map_func(arr,obj[i], item);
      } else {
        obj[i] = item;
      }
    };

    u.clearEmptyKeys = function (object) {
      for (var key in object) {
        if (object[key] === "" || object[key] === undefined) {
          delete object[key];
        }
      }
      return object;
    };

      u.map={};
  u.extend=[];


    u.send = function (a, b) {
      if (u.ev[a] || u.ev.all !== undefined) {
        utag.DB("send:124");
        utag.DB(b);

        var c, d, e, f;
        /* https://marketing.adobe.com/resources/help/en_US/mcvid/mcvid-cookiedomain.html */
        u.data = {
          "adobe_org_id": "0861467352782C5E0A490D45",
          "config" : {
            "trackingServer" : "abnamro.sc.omtrdc.net",
            "trackingServerSecure" : "abnamro.sc.omtrdc.net", /* for clients with c-name setup (first party cookie alias) */
            "marketingCloudServer" : "abnamro.sc.omtrdc.net",
            "marketingCloudServerSecure" : "abnamro.sc.omtrdc.net", /* set adobe visitor api cookieDomain explicitly http://rossscrivener.co.uk/blog/javascript-get-domain-exclude-subdomain */
            "cookieDomain" : (function () {
              return utag.loader.RC('utag_main').vapi_domain || (function () {
                var i = 0, d = document.domain, p = d.split('.'), s = '_vapi' + new Date().getTime();
                while (i < (p.length - 1) && document.cookie.indexOf(s + '=' + s) === -1) {
                  d = p.slice(-1 - (++i)).join('.');
                  document.cookie = s + '=' + s + ';domain=' + d + ';';
                }
                document.cookie = s + '=;expires=Thu, 01 Jan 1970 00:00:01 GMT;domain=' + d + ';';
                utag.loader.SC('utag_main', {'vapi_domain': d});
                return d;
              }());
            }())
          }, /* visitor id sync format 'customer_ids' : { // predefined alias 1 'system1_cid' : { 'id' : [VID1], 'authState' : 'AUTHENTICATED' }, // predefined alias 2 'system2_cid' : { 'id' : [VID2], 'authState' : 'AUTHENTICATED' } } */
          'customer_ids' : {}
        };

        // Start tag-scoped extensions
        
        utag.DB("send:124:EXTENSIONS");
        utag.DB(b);
        // End tag-scoped extensions

        c = [];

        // Start Mapping
        for (d in utag.loader.GV(u.map)) {
          if (b[d] !== undefined && b[d] !== "") {
            e = u.map[d].split(",");
            for (f = 0; f < e.length; f++) {
              u.map_func(e[f].split("."), u.data, b[d]);
            }
          }
        }
        utag.DB("send:124:MAPPINGS");
        utag.DB(u.data);
        // End Mapping

        // Report required config is missing, and stop tag from firing.
        if (!u.data.adobe_org_id) {
          utag.DB(u.id + ": Tag not fired: Required attribute not populated [adobe_org_id]");
          return;
        }

        if (!u.initialized) {
          u.initialized = !0;
          vAPI.getInstance(u.data.adobe_org_id,
            function (instance) {
              /* do something after? */
            },
            u.clearEmptyKeys(u.data.config), u.data.customer_ids);
        }
        utag.DB("send:124:COMPLETE");
      }
    };
    utag.o[loader].loader.LOAD(id);
  }("124", "abn-amro.retail"));
} catch (error) {
  utag.DB(error);
}
//end tealium universal tag
(function(){ if(typeof utag!='undefined'){utag.initcatch=true;for(var i in utag.loader.GV(utag.loader.cfg)){var b=utag.loader.cfg[i];if(b.load!=4){utag.initcatch=false;break};if(b.wait==1){utag.initcatch=false;break}};if(utag.initcatch)utag.handler.INIT();} })();