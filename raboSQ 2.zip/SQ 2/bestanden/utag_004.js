//~~tv:18046.20190118
//~~tc: Adding tag Relay42

//tealium universal tag - utag.sender.18046 ut4.0.201909251017, Copyright 2019 Tealium.com Inc. All Rights Reserved.
try {
  (function (id, loader) {
    var u = {"id" : id};
    utag.o[loader].sender[id] = u;
    // Please do not modify
    if (utag.ut === undefined) { utag.ut = {}; }
    // Start Tealium loader 4.41
    /* utag.js version 4.26 or above is required to avoid errors with this loader function */
    var match = /ut\d\.(\d*)\..*/.exec(utag.cfg.v);
    if (utag.ut.loader === undefined || !match || parseInt(match[1]) < 41) { u.loader = function(o, a, b, c, l, m) { utag.DB(o); a = document; if (o.type == "iframe") { m = a.getElementById(o.id); if (m && m.tagName == "IFRAME") { b = m; } else { b = a.createElement("iframe"); } o.attrs = o.attrs || {}; utag.ut.merge(o.attrs, { "height": "1", "width": "1", "style": "display:none" }, 0); } else if (o.type == "img") { utag.DB("Attach img: " + o.src); b = new Image(); } else { b = a.createElement("script"); b.language = "javascript"; b.type = "text/javascript"; b.async = 1; b.charset = "utf-8"; } if (o.id) { b.id = o.id; } for (l in utag.loader.GV(o.attrs)) { b.setAttribute(l, o.attrs[l]); } b.setAttribute("src", o.src); if (typeof o.cb == "function") { if (b.addEventListener) { b.addEventListener("load", function() { o.cb(); }, false); } else { b.onreadystatechange = function() { if (this.readyState == "complete" || this.readyState == "loaded") { this.onreadystatechange = null; o.cb(); } }; } } if (o.type != "img" && !m) { l = o.loc || "head"; c = a.getElementsByTagName(l)[0]; if (c) { utag.DB("Attach to " + l + ": " + o.src); if (l == "script") { c.parentNode.insertBefore(b, c); } else { c.appendChild(b); } } } }; } else { u.loader = utag.ut.loader; }
    // End Tealium loader
    // Start Tealium typeOf 4.35
    if (utag.ut.typeOf === undefined) { u.typeOf = function(e) {return ({}).toString.call(e).match(/\s([a-zA-Z]+)/)[1].toLowerCase();};} else { u.typeOf = utag.ut.typeOf; }
    // End Tealium typeOf

    u.ev = {"view" : 1, "link" : 1};
    u.initialized = false;
    u.scriptrequested = false;
    u.queue = [];

    u.map_func = function (arr, obj, item) {
      var i = arr.shift();
      obj[i] = obj[i] || {};
      if (arr.length > 0) {
        u.map_func(arr,obj[i], item);
      } else {
        obj[i] = item;
      }
    };

    u.clearEmptyKeys = function (object) {
      for (var key in object) {
        if (object[key] === "" || object[key] === undefined) {
          delete object[key];
        }
      }
      return object;
    };

    u.event_map = {
      "conversion": [{ "name":"transactionValue" , "required": true }, { "name":"transactionId" }, { "name":"products"}, { "name":"property"} ],
      "engagement": [{ "name":"engagementType" , "required": true }, { "name":"property" } ],
      "fact": [{ "name":"factName" , "required": true }, { "name":"ttl" , "required": true }, { "name":"property" }, { "name":"forcedImport" , "required": true } ],
      "pageview": [  ],
      "sync": [{ "name":"syncPartner" , "required": true } ],
      "store": [{ "name":"partnerSlot" , "required": true }, { "name":"identifier" , "required": true }, { "name":"mergeOperator" , "required": true }  ]
    };

    u.std_params = {
      "transactionValue" : function() {
        return u.data.order_total;
      },
      "transactionId" : function() {
        return u.data.order_id;
      },
      "products" : function () {
        return u.data.product_id;
      },
      "engagementType" : function() {
        return u.data.engagement_type;
      },
      "factName" : function() {
        return u.data.fact_name;
      },
      "ttl" : function() {
        return u.data.ttl;
      },
      "forcedImport" : function() {
        return u.data.forced_import;
      },
      "syncPartner" : function() {
        return u.data.sync_partner;
      },
      "partnerSlot" : function() {
        return u.data.partner_slot;
      },
      "identifier" : function() {
        return u.data.identifier;
      },
      "mergeOperator" : function() {
        return u.data.merge_operation;
      },
      "property" : function() {
        return u.data.property;
      }
    };

      u.map={"relay42_base_url":"base_url","tealium_event:view":"pageview,engagement","event_name:push relay42 fact":"fact","is_conversion:true":"engagement","_sm_45_5":"fact.property.cookiesetting","relay42_fact_name":"fact.factName","relay42_fact_ttl":"fact.ttl","relay42_engagement_type":"property.engagementtype,engagement.engagementType","user_bc_number":"property.bcnumer","qp.ext":"property.campaignid","user_client_group_code":"property.clientgroupcode","organization_business_line":"property.division","widget_state":"property.funnelstate","page_name":"property.pagename","dom.pathname":"property.path","dom.pathname_3":"property.productgroup","product_name":"property.productname","dom.referrer":"property.referrer","dom.viewport_height":"property.screenheight","dom.viewport_orientation":"property.screenorientation","dom.viewport_width":"property.screenwidth","tealium_timestamp_epoch":"property.timestamp","dom.url":"property.url","js_page.window.navigator.userAgent":"property.useragent","cp.UVID":"property.uvid"};
  u.extend=[function(a,b){
try{b['_sm_45_5']=b.relay42_properties.cookiesetting;}catch(e){utag.DB(e);}
},
function(a,b,c,d,e,f,g){if(1){d=b['environment_name'];if(typeof d=='undefined')return;c=[{'tridion':'https://www.abnamro.nl/nl/includesrara/unauthenticated/static/js/r42_library.js'},{'dda':'https://preview-test-nl-retail-cdn.dda-ta.aws.abnamro.org/vendor/analytics/relay42/js/r42_library.js'}];var m=false;for(e=0;e<c.length;e++){for(f in c[e]){g=new RegExp(f,'i');if(g.test(d)){b['relay42_base_url']=c[e][f];m=true};};if(m)break};if(!m)b['relay42_base_url']='https://www.abnamro.nl/nl/includesrara/unauthenticated/static/js/r42_library.js';   }},
function(a,b){ try{ if(b['tealium_event']=='view'){b['relay42_engagement_type']='page-view'} } catch(e){ utag.DB(e) }  },
function(a,b){ try{ if(b['is_conversion']=='true'){b['relay42_engagement_type']='product-request'} } catch(e){ utag.DB(e) }  },
function(a,b){ try{ if(1){
/* https://jira.aws.abnamro.org/browse/AN-1948 */
function logToConsole(message) {
  if (document.cookie.indexOf("utagdb=true") > -1) {
    console.log(message);
  }
}

function storeMapping(idType, id, reset) {
  var partnerId;

  if (reset) {
    logToConsole("storeMapping: Resetting user identifier");

    _st.tracking.resetUserIdentifier();
  }

  switch (idType) {
    case "bcNumber":
      partnerId = 2001;
      break;

    case "uvid":
      partnerId = 2002;
      break;

    default:
      return;
  }

  logToConsole(
    "storeMapping: Storing mapping for the "
      .concat(idType, " ")
      .concat(id, " to partner ID ")
      .concat(partnerId)
  );
  /* _st.tracking.storeMapping(partnerId, identifier, mergeOperator, forceMapping); */

  _st.tracking.storeMapping(partnerId, id, 2, 1);
}

(function triggerBcSyncResponse(b) {
  var bcNumber = b.user_bc_number;
  var currentTime = b.tealium_timestamp_epoch;
  var lastBcNumber = localStorage.getItem("user_last_bc_number");
  var lastBcNumberTime = localStorage.getItem("user_last_bc_number_time");

  if (bcNumber != null && bcNumber !== "not set") {
    if (bcNumber !== lastBcNumber) {
      /* i.e. if the BC Numbers don't match */
      logToConsole("triggerBcSyncResponse: Reset and sync needed");
      localStorage.setItem("user_last_bc_number", bcNumber);
      localStorage.setItem("user_last_bc_number_time", currentTime);
      storeMapping("bc_number", bcNumber, true);
    } else if (currentTime - lastBcNumberTime > 2592000) {
      /* i.e. if the BC Numbers match, but the last sync is over 30 days ago */
      logToConsole("triggerBcSyncResponse: Sync needed, but no reset");
      localStorage.setItem("user_last_bc_number_time", currentTime);
      storeMapping("bcNumber", bcNumber, false);
    } else {
      logToConsole("triggerBcSyncResponse: No sync needed");
    }
  } else {
    logToConsole("triggerBcSyncResponse: No BC number available");
  }
})();

(function triggerUvidSyncResponse() {
  var uvid = b["cp.UVID"];
  var lastUvid = localStorage.getItem("user_last_uvid");

  if (uvid != null && uvid !== "not set" && uvid !== lastUvid) {
    logToConsole("triggerUvidSyncResponse: Sync needed");
    localStorage.setItem("user_last_uvid", uvid);
    storeMapping("uvid", uvid, false);
  } else {
    logToConsole("triggerUvidSyncResponse: No sync needed");
  }
})(b);

} } catch(e){ utag.DB(e) }  }];


    // Start Loader Callback
    u.loader_cb = function (a, b, c) {
      utag.DB("send:45:CALLBACK");
      u.initialized = true;
      // Add code here
      var dataName, _event, event_param, i, j;

      for (i = 0; i < u.data.event.length; i++) {
        _event = u.data.event[i];
        u.data.eventData[_event] = {};

        if (u.event_map[_event]) {
          for (j = 0; j < u.event_map[_event].length; j++) {
            event_param = u.event_map[_event][j];
            u.data.eventData[_event][event_param.name] = u.std_params[event_param.name](_event);
            if (u.data.eventData[_event][event_param.name] === undefined && event_param.required) {
              utag.DB(u.id + ": Event: " + _event + ": Required attribute not populated");
            }
          }
        }

        switch (_event) {
        case "conversion":
          for (dataName in u.data[_event]) {
            u.data.eventData[_event][dataName] = u.data[_event][dataName];
          }
          _st.tracking.sendConversion(parseInt(u.data.eventData[_event].transactionValue), u.data.eventData[_event].transactionId, u.data.eventData[_event].products, u.data.eventData[_event].property);
          break;
        case "engagement":
          for (dataName in u.data[_event]) {
            u.data.eventData[_event][dataName] = u.data[_event][dataName];
          }
          _st.tracking.sendEngagement(u.data.eventData[_event].engagementType, u.data.eventData[_event].property);
          break;
        case "fact":
          for (dataName in u.data[_event]) {
            u.data.eventData[_event][dataName] = u.data[_event][dataName];
          }
          _st.tracking.sendExternalFact(u.data.eventData[_event].factName, parseInt(u.data.eventData[_event].ttl), u.data.eventData[_event].property, u.data.eventData[_event].forcedImport);
          break;
        case "pageview":
          for (dataName in u.data[_event]) {
            u.data.eventData[_event][dataName] = u.data[_event][dataName];
          }
          _st.tracking.sendPageview();
          break;
        case "sync":
          for (dataName in u.data[_event]) {
            u.data.eventData[_event][dataName] = u.data[_event][dataName];
          }
          _st.tracking.syncPartner(parseInt(u.data.eventData[_event].syncPartner));
          break;
        case "store":
          for (dataName in u.data[_event]) {
            u.data.eventData[_event][dataName] = u.data[_event][dataName];
          }
          _st.tracking.storeMapping(parseInt(u.data.eventData[_event].partnerSlot), u.data.eventData[_event].identifier, u.data.eventData[_event].mergeOperator);
          break;
        default :
        }
      }

      utag.DB("send:45:CALLBACK:COMPLETE");
    };
    // End Loader Callback

    u.callBack = function () {
      var data = {};
      while (data = u.queue.shift()) {
        u.data = data.data;
        u.loader_cb(data.a, data.b, data.c);
      }
    };

    u.send = function (a, b) {
      if (u.ev[a] || u.ev.all !== undefined) {
        utag.DB("send:45");
        utag.DB(b);

        var c, d, e, f, h;

        u.data = {
          //##UTVARconfig_<id from config>##
          "qsp_delim" : "&",
          "kvp_delim" : "=",
          "base_url" : "(set by extension)",
          // E-Commerce Vars
          "product_id" : [],
          "event" : [],
          "eventData" : {},
          "custom" : {}
        };

        // Start tag-scoped extensions
        for(c=0;c<u.extend.length;c++){try{d=u.extend[c](a,b);if(d==false)return}catch(e){if(typeof utag_err!='undefined'){utag_err.push({e:'extension error:'+e,s:utag.cfg.path+'utag.'+id+'.js',l:c,t:'ex'})}}};
        utag.DB("send:45:EXTENSIONS");
        utag.DB(b);
        // End tag-scoped extensions

        c = [];

        // Start Mapping
        for (d in utag.loader.GV(u.map)) {
          if (b[d] !== undefined && b[d] !== "") {
            e = u.map[d].split(",");
            for (f = 0; f < e.length; f++) {
              u.map_func(e[f].split("."), u.data, b[d]);
            }
          } else {
            h = d.split(":");
            if (h.length === 2 && b[h[0]] === h[1]) {
              if (u.map[d]) {
                u.data.event = u.data.event.concat(u.map[d].split(","));
              }
            }
          }
        }
        utag.DB("send:45:MAPPINGS");
        utag.DB(u.data);
        // End Mapping

        // Pull E-Commerce extension values
        // Mappings override E-Commerce extension values
        u.data.order_id = u.data.order_id || b._corder || "";
        u.data.order_total = u.data.order_total || b._ctotal || "";
        if (u.data.product_id.length === 0 && b._cprod !== undefined) { u.data.product_id = b._cprod.slice(0); }
        if (u.data.event.length === 0 && b._cevent !== undefined) { u.data.event = (u.typeOf(b._cevent) === "array") ? b._cevent.slice(0) : [b._cevent] ; }

        // Report required config is missing, and stop tag from firing.
        if (!u.data.base_url) {
          utag.DB(u.id + ": Tag not fired: Required attribute not populated");
          return;
        }

        if (u.initialized) {
          u.loader_cb(a, b, c);
        } else {
          // While waiting for the external library to load, queue up all of the events with their corresponding data objects.
          u.queue.push({"data" : u.data, "a" : a, "b" : b, "c" : c});
          if (!u.scriptrequested) {
            u.scriptrequested = true;
            u.loader({
              "type" : "script",
              "src" : u.data.base_url,
              "cb" : u.callBack,
              "loc" : "script",
              "id" : "utag_45",
              "attrs" : {}
            });
          }
        }

        utag.DB("send:45:COMPLETE");
      }
    };
    utag.o[loader].loader.LOAD(id);
  }("45", "abn-amro.retail"));
} catch (error) {
  utag.DB(error);
}
//end tealium universal tag
