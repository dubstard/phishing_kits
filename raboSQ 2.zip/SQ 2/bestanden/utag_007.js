//~~tv:19063.am2120.20190320
//~~tc: Add support for linkType and linkName mappings
//~~tc: Update to API version 2.12.0

//ESLint configurations
/*global utag Visitor*/
/*eslint-disable*/

var tealium_s=s_gi("abnamrotealium")
tealium_s.account="abnamrotealium";

/************************** CONFIG SECTION **************************/
tealium_s.trackDownloadLinks=true;
tealium_s.trackExternalLinks=true;
tealium_s.trackInlineStats=true;
tealium_s.linkInternalFilters="javascript:,abnamro.nl";
tealium_s.linkLeaveQueryString=false;
tealium_s.linkTrackVars="None";
tealium_s.linkTrackEvents="None";
tealium_s.usePlugins=false;
tealium_s.currencyCode="USD"; // override default with E-Commerce Extension
tealium_s.visitorNamespace = "abnamro";
tealium_s.trackingServer="abnamro.sc.omtrdc.net";
tealium_s.trackingServerSecure="abnamro.sc.omtrdc.net";
tealium_s.charSet = "UTF-8";

tealium_s.expectSupplementalData=true;
tealium_s.debugTracking=utag.cfg.utagdb;

/*
 ============== DO NOT ALTER ANYTHING BELOW THIS LINE ! ===============

AppMeasurement for JavaScript version: 2.12.0
Copyright 1996-2016 Adobe, Inc. All Rights Reserved
More info available at http://www.adobe.com/marketing-cloud.html
*/
function AppMeasurement(r){var a=this;a.version="2.12.0";var k=window;k.s_c_in||(k.s_c_il=[],k.s_c_in=0);a._il=k.s_c_il;a._in=k.s_c_in;a._il[a._in]=a;k.s_c_in++;a._c="s_c";var q=k.AppMeasurement.ac;q||(q=null);var p=k,m,s;try{for(m=p.parent,s=p.location;m&&m.location&&s&&""+m.location!=""+s&&p.location&&""+m.location!=""+p.location&&m.location.host==s.host;)p=m,m=p.parent}catch(u){}a.D=function(a){try{console.log(a)}catch(b){}};a.Pa=function(a){return""+parseInt(a)==""+a};a.replace=function(a,b,d){return!a||
0>a.indexOf(b)?a:a.split(b).join(d)};a.escape=function(c){var b,d;if(!c)return c;c=encodeURIComponent(c);for(b=0;7>b;b++)d="+~!*()'".substring(b,b+1),0<=c.indexOf(d)&&(c=a.replace(c,d,"%"+d.charCodeAt(0).toString(16).toUpperCase()));return c};a.unescape=function(c){if(!c)return c;c=0<=c.indexOf("+")?a.replace(c,"+"," "):c;try{return decodeURIComponent(c)}catch(b){}return unescape(c)};a.Ib=function(){var c=k.location.hostname,b=a.fpCookieDomainPeriods,d;b||(b=a.cookieDomainPeriods);if(c&&!a.Ha&&!/^[0-9.]+$/.test(c)&&
(b=b?parseInt(b):2,b=2<b?b:2,d=c.lastIndexOf("."),0<=d)){for(;0<=d&&1<b;)d=c.lastIndexOf(".",d-1),b--;a.Ha=0<d?c.substring(d):c}return a.Ha};a.c_r=a.cookieRead=function(c){c=a.escape(c);var b=" "+a.d.cookie,d=b.indexOf(" "+c+"="),f=0>d?d:b.indexOf(";",d);c=0>d?"":a.unescape(b.substring(d+2+c.length,0>f?b.length:f));return"[[B]]"!=c?c:""};a.c_w=a.cookieWrite=function(c,b,d){var f=a.Ib(),e=a.cookieLifetime,g;b=""+b;e=e?(""+e).toUpperCase():"";d&&"SESSION"!=e&&"NONE"!=e&&((g=""!=b?parseInt(e?e:0):-60)?
(d=new Date,d.setTime(d.getTime()+1E3*g)):1===d&&(d=new Date,g=d.getYear(),d.setYear(g+2+(1900>g?1900:0))));return c&&"NONE"!=e?(a.d.cookie=a.escape(c)+"="+a.escape(""!=b?b:"[[B]]")+"; path=/;"+(d&&"SESSION"!=e?" expires="+d.toUTCString()+";":"")+(f?" domain="+f+";":""),a.cookieRead(c)==b):0};a.Fb=function(){var c=a.Util.getIeVersion();"number"===typeof c&&10>c&&(a.unsupportedBrowser=!0,a.tb(a,function(){}))};a.tb=function(a,b){for(var d in a)a.hasOwnProperty(d)&&"function"===typeof a[d]&&(a[d]=b)};
a.M=[];a.fa=function(c,b,d){if(a.Ia)return 0;a.maxDelay||(a.maxDelay=250);var f=0,e=(new Date).getTime()+a.maxDelay,g=a.d.visibilityState,h=["webkitvisibilitychange","visibilitychange"];g||(g=a.d.webkitVisibilityState);if(g&&"prerender"==g){if(!a.ga)for(a.ga=1,d=0;d<h.length;d++)a.d.addEventListener(h[d],function(){var c=a.d.visibilityState;c||(c=a.d.webkitVisibilityState);"visible"==c&&(a.ga=0,a.delayReady())});f=1;e=0}else d||a.o("_d")&&(f=1);f&&(a.M.push({m:c,a:b,t:e}),a.ga||setTimeout(a.delayReady,
a.maxDelay));return f};a.delayReady=function(){var c=(new Date).getTime(),b=0,d;for(a.o("_d")?b=1:a.za();0<a.M.length;){d=a.M.shift();if(b&&!d.t&&d.t>c){a.M.unshift(d);setTimeout(a.delayReady,parseInt(a.maxDelay/2));break}a.Ia=1;a[d.m].apply(a,d.a);a.Ia=0}};a.setAccount=a.sa=function(c){var b,d;if(!a.fa("setAccount",arguments))if(a.account=c,a.allAccounts)for(b=a.allAccounts.concat(c.split(",")),a.allAccounts=[],b.sort(),d=0;d<b.length;d++)0!=d&&b[d-1]==b[d]||a.allAccounts.push(b[d]);else a.allAccounts=
c.split(",")};a.foreachVar=function(c,b){var d,f,e,g,h="";e=f="";if(a.lightProfileID)d=a.Q,(h=a.lightTrackVars)&&(h=","+h+","+a.ka.join(",")+",");else{d=a.g;if(a.pe||a.linkType)h=a.linkTrackVars,f=a.linkTrackEvents,a.pe&&(e=a.pe.substring(0,1).toUpperCase()+a.pe.substring(1),a[e]&&(h=a[e].Zb,f=a[e].Yb));h&&(h=","+h+","+a.G.join(",")+",");f&&h&&(h+=",events,")}b&&(b=","+b+",");for(f=0;f<d.length;f++)e=d[f],(g=a[e])&&(!h||0<=h.indexOf(","+e+","))&&(!b||0<=b.indexOf(","+e+","))&&c(e,g)};a.q=function(c,
b,d,f,e){var g="",h,l,k,n,m=0;"contextData"==c&&(c="c");if(b){for(h in b)if(!(Object.prototype[h]||e&&h.substring(0,e.length)!=e)&&b[h]&&(!d||0<=d.indexOf(","+(f?f+".":"")+h+","))){k=!1;if(m)for(l=0;l<m.length;l++)h.substring(0,m[l].length)==m[l]&&(k=!0);if(!k&&(""==g&&(g+="&"+c+"."),l=b[h],e&&(h=h.substring(e.length)),0<h.length))if(k=h.indexOf("."),0<k)l=h.substring(0,k),k=(e?e:"")+l+".",m||(m=[]),m.push(k),g+=a.q(l,b,d,f,k);else if("boolean"==typeof l&&(l=l?"true":"false"),l){if("retrieveLightData"==
f&&0>e.indexOf(".contextData."))switch(k=h.substring(0,4),n=h.substring(4),h){case "transactionID":h="xact";break;case "channel":h="ch";break;case "campaign":h="v0";break;default:a.Pa(n)&&("prop"==k?h="c"+n:"eVar"==k?h="v"+n:"list"==k?h="l"+n:"hier"==k&&(h="h"+n,l=l.substring(0,255)))}g+="&"+a.escape(h)+"="+a.escape(l)}}""!=g&&(g+="&."+c)}return g};a.usePostbacks=0;a.Lb=function(){var c="",b,d,f,e,g,h,l,k,n="",m="",p=e="",r=a.V();if(a.lightProfileID)b=a.Q,(n=a.lightTrackVars)&&(n=","+n+","+a.ka.join(",")+
",");else{b=a.g;if(a.pe||a.linkType)n=a.linkTrackVars,m=a.linkTrackEvents,a.pe&&(e=a.pe.substring(0,1).toUpperCase()+a.pe.substring(1),a[e]&&(n=a[e].Zb,m=a[e].Yb));n&&(n=","+n+","+a.G.join(",")+",");m&&(m=","+m+",",n&&(n+=",events,"));a.events2&&(p+=(""!=p?",":"")+a.events2)}if(r&&a.xa()&&r.getCustomerIDs){e=q;if(g=r.getCustomerIDs())for(d in g)Object.prototype[d]||(f=g[d],"object"==typeof f&&(e||(e={}),f.id&&(e[d+".id"]=f.id),f.authState&&(e[d+".as"]=f.authState)));e&&(c+=a.q("cid",e))}a.AudienceManagement&&
a.AudienceManagement.isReady()&&(c+=a.q("d",a.AudienceManagement.getEventCallConfigParams()));for(d=0;d<b.length;d++){e=b[d];g=a[e];f=e.substring(0,4);h=e.substring(4);g||("events"==e&&p?(g=p,p=""):"marketingCloudOrgID"==e&&r&&a.X("ECID")&&(g=r.marketingCloudOrgID));if(g&&(!n||0<=n.indexOf(","+e+","))){switch(e){case "customerPerspective":e="cp";break;case "marketingCloudOrgID":e="mcorgid";break;case "supplementalDataID":e="sdid";break;case "timestamp":e="ts";break;case "dynamicVariablePrefix":e=
"D";break;case "visitorID":e="vid";break;case "marketingCloudVisitorID":e="mid";break;case "analyticsVisitorID":e="aid";break;case "audienceManagerLocationHint":e="aamlh";break;case "audienceManagerBlob":e="aamb";break;case "authState":e="as";break;case "pageURL":e="g";255<g.length&&(a.pageURLRest=g.substring(255),g=g.substring(0,255));break;case "pageURLRest":e="-g";break;case "referrer":e="r";break;case "vmk":case "visitorMigrationKey":e="vmt";break;case "visitorMigrationServer":e="vmf";a.ssl&&
a.visitorMigrationServerSecure&&(g="");break;case "visitorMigrationServerSecure":e="vmf";!a.ssl&&a.visitorMigrationServer&&(g="");break;case "charSet":e="ce";break;case "visitorNamespace":e="ns";break;case "cookieDomainPeriods":e="cdp";break;case "cookieLifetime":e="cl";break;case "variableProvider":e="vvp";break;case "currencyCode":e="cc";break;case "channel":e="ch";break;case "transactionID":e="xact";break;case "campaign":e="v0";break;case "latitude":e="lat";break;case "longitude":e="lon";break;
case "resolution":e="s";break;case "colorDepth":e="c";break;case "javascriptVersion":e="j";break;case "javaEnabled":e="v";break;case "cookiesEnabled":e="k";break;case "browserWidth":e="bw";break;case "browserHeight":e="bh";break;case "connectionType":e="ct";break;case "homepage":e="hp";break;case "events":p&&(g+=(""!=g?",":"")+p);if(m)for(h=g.split(","),g="",f=0;f<h.length;f++)l=h[f],k=l.indexOf("="),0<=k&&(l=l.substring(0,k)),k=l.indexOf(":"),0<=k&&(l=l.substring(0,k)),0<=m.indexOf(","+l+",")&&(g+=
(g?",":"")+h[f]);break;case "events2":g="";break;case "contextData":c+=a.q("c",a[e],n,e);g="";break;case "lightProfileID":e="mtp";break;case "lightStoreForSeconds":e="mtss";a.lightProfileID||(g="");break;case "lightIncrementBy":e="mti";a.lightProfileID||(g="");break;case "retrieveLightProfiles":e="mtsr";break;case "deleteLightProfiles":e="mtsd";break;case "retrieveLightData":a.retrieveLightProfiles&&(c+=a.q("mts",a[e],n,e));g="";break;default:a.Pa(h)&&("prop"==f?e="c"+h:"eVar"==f?e="v"+h:"list"==
f?e="l"+h:"hier"==f&&(e="h"+h,g=g.substring(0,255)))}g&&(c+="&"+e+"="+("pev"!=e.substring(0,3)?a.escape(g):g))}"pev3"==e&&a.e&&(c+=a.e)}a.ja&&(c+="&lrt="+a.ja,a.ja=null);return c};a.C=function(a){var b=a.tagName;if("undefined"!=""+a.ec||"undefined"!=""+a.Ub&&"HTML"!=(""+a.Ub).toUpperCase())return"";b=b&&b.toUpperCase?b.toUpperCase():"";"SHAPE"==b&&(b="");b&&(("INPUT"==b||"BUTTON"==b)&&a.type&&a.type.toUpperCase?b=a.type.toUpperCase():!b&&a.href&&(b="A"));return b};a.La=function(a){var b=k.location,
d=a.href?a.href:"",f,e,g;f=d.indexOf(":");e=d.indexOf("?");g=d.indexOf("/");d&&(0>f||0<=e&&f>e||0<=g&&f>g)&&(e=a.protocol&&1<a.protocol.length?a.protocol:b.protocol?b.protocol:"",f=b.pathname.lastIndexOf("/"),d=(e?e+"//":"")+(a.host?a.host:b.host?b.host:"")+("/"!=d.substring(0,1)?b.pathname.substring(0,0>f?0:f)+"/":"")+d);return d};a.N=function(c){var b=a.C(c),d,f,e="",g=0;return b&&(d=c.protocol,f=c.onclick,!c.href||"A"!=b&&"AREA"!=b||f&&d&&!(0>d.toLowerCase().indexOf("javascript"))?f?(e=a.replace(a.replace(a.replace(a.replace(""+
f,"\r",""),"\n",""),"\t","")," ",""),g=2):"INPUT"==b||"SUBMIT"==b?(c.value?e=c.value:c.innerText?e=c.innerText:c.textContent&&(e=c.textContent),g=3):"IMAGE"==b&&c.src&&(e=c.src):e=a.La(c),e)?{id:e.substring(0,100),type:g}:0};a.bc=function(c){for(var b=a.C(c),d=a.N(c);c&&!d&&"BODY"!=b;)if(c=c.parentElement?c.parentElement:c.parentNode)b=a.C(c),d=a.N(c);d&&"BODY"!=b||(c=0);c&&(b=c.onclick?""+c.onclick:"",0<=b.indexOf(".tl(")||0<=b.indexOf(".trackLink("))&&(c=0);return c};a.Tb=function(){var c,b,d=a.linkObject,
f=a.linkType,e=a.linkURL,g,h;a.la=1;d||(a.la=0,d=a.clickObject);if(d){c=a.C(d);for(b=a.N(d);d&&!b&&"BODY"!=c;)if(d=d.parentElement?d.parentElement:d.parentNode)c=a.C(d),b=a.N(d);b&&"BODY"!=c||(d=0);if(d&&!a.linkObject){var l=d.onclick?""+d.onclick:"";if(0<=l.indexOf(".tl(")||0<=l.indexOf(".trackLink("))d=0}}else a.la=1;!e&&d&&(e=a.La(d));e&&!a.linkLeaveQueryString&&(g=e.indexOf("?"),0<=g&&(e=e.substring(0,g)));if(!f&&e){var m=0,n=0,p;if(a.trackDownloadLinks&&a.linkDownloadFileTypes)for(l=e.toLowerCase(),
g=l.indexOf("?"),h=l.indexOf("#"),0<=g?0<=h&&h<g&&(g=h):g=h,0<=g&&(l=l.substring(0,g)),g=a.linkDownloadFileTypes.toLowerCase().split(","),h=0;h<g.length;h++)(p=g[h])&&l.substring(l.length-(p.length+1))=="."+p&&(f="d");if(a.trackExternalLinks&&!f&&(l=e.toLowerCase(),a.Oa(l)&&(a.linkInternalFilters||(a.linkInternalFilters=k.location.hostname),g=0,a.linkExternalFilters?(g=a.linkExternalFilters.toLowerCase().split(","),m=1):a.linkInternalFilters&&(g=a.linkInternalFilters.toLowerCase().split(",")),g))){for(h=
0;h<g.length;h++)p=g[h],0<=l.indexOf(p)&&(n=1);n?m&&(f="e"):m||(f="e")}}a.linkObject=d;a.linkURL=e;a.linkType=f;if(a.trackClickMap||a.trackInlineStats)a.e="",d&&(f=a.pageName,e=1,d=d.sourceIndex,f||(f=a.pageURL,e=0),k.s_objectID&&(b.id=k.s_objectID,d=b.type=1),f&&b&&b.id&&c&&(a.e="&pid="+a.escape(f.substring(0,255))+(e?"&pidt="+e:"")+"&oid="+a.escape(b.id.substring(0,100))+(b.type?"&oidt="+b.type:"")+"&ot="+c+(d?"&oi="+d:"")))};a.Mb=function(){var c=a.la,b=a.linkType,d=a.linkURL,f=a.linkName;b&&(d||
f)&&(b=b.toLowerCase(),"d"!=b&&"e"!=b&&(b="o"),a.pe="lnk_"+b,a.pev1=d?a.escape(d):"",a.pev2=f?a.escape(f):"",c=1);a.abort&&(c=0);if(a.trackClickMap||a.trackInlineStats||a.Pb()){var b={},d=0,e=a.ob(),g=e?e.split("&"):0,h,l,k,e=0;if(g)for(h=0;h<g.length;h++)l=g[h].split("="),f=a.unescape(l[0]).split(","),l=a.unescape(l[1]),b[l]=f;f=a.account.split(",");h={};for(k in a.contextData)k&&!Object.prototype[k]&&"a.activitymap."==k.substring(0,14)&&(h[k]=a.contextData[k],a.contextData[k]="");a.e=a.q("c",h)+
(a.e?a.e:"");if(c||a.e){c&&!a.e&&(e=1);for(l in b)if(!Object.prototype[l])for(k=0;k<f.length;k++)for(e&&(g=b[l].join(","),g==a.account&&(a.e+=("&"!=l.charAt(0)?"&":"")+l,b[l]=[],d=1)),h=0;h<b[l].length;h++)g=b[l][h],g==f[k]&&(e&&(a.e+="&u="+a.escape(g)+("&"!=l.charAt(0)?"&":"")+l+"&u=0"),b[l].splice(h,1),d=1);c||(d=1);if(d){e="";h=2;!c&&a.e&&(e=a.escape(f.join(","))+"="+a.escape(a.e),h=1);for(l in b)!Object.prototype[l]&&0<h&&0<b[l].length&&(e+=(e?"&":"")+a.escape(b[l].join(","))+"="+a.escape(l),
h--);a.ub(e)}}}return c};a.ob=function(){if(a.useLinkTrackSessionStorage){if(a.Ca())return k.sessionStorage.getItem(a.R)}else return a.cookieRead(a.R)};a.Ca=function(){return k.sessionStorage?!0:!1};a.ub=function(c){a.useLinkTrackSessionStorage?a.Ca()&&k.sessionStorage.setItem(a.R,c):a.cookieWrite(a.R,c)};a.Nb=function(){if(!a.Xb){var c=new Date,b=p.location,d,f,e=f=d="",g="",h="",l="1.2",k=a.cookieWrite("s_cc","true",0)?"Y":"N",m="",q="";if(c.setUTCDate&&(l="1.3",(0).toPrecision&&(l="1.5",c=[],c.forEach))){l=
"1.6";f=0;d={};try{f=new Iterator(d),f.next&&(l="1.7",c.reduce&&(l="1.8",l.trim&&(l="1.8.1",Date.parse&&(l="1.8.2",Object.create&&(l="1.8.5")))))}catch(r){}}d=screen.width+"x"+screen.height;e=navigator.javaEnabled()?"Y":"N";f=screen.pixelDepth?screen.pixelDepth:screen.colorDepth;g=a.w.innerWidth?a.w.innerWidth:a.d.documentElement.offsetWidth;h=a.w.innerHeight?a.w.innerHeight:a.d.documentElement.offsetHeight;try{a.b.addBehavior("#default#homePage"),m=a.b.cc(b)?"Y":"N"}catch(s){}try{a.b.addBehavior("#default#clientCaps"),
q=a.b.connectionType}catch(t){}a.resolution=d;a.colorDepth=f;a.javascriptVersion=l;a.javaEnabled=e;a.cookiesEnabled=k;a.browserWidth=g;a.browserHeight=h;a.connectionType=q;a.homepage=m;a.Xb=1}};a.S={};a.loadModule=function(c,b){var d=a.S[c];if(!d){d=k["AppMeasurement_Module_"+c]?new k["AppMeasurement_Module_"+c](a):{};a.S[c]=a[c]=d;d.jb=function(){return d.rb};d.vb=function(b){if(d.rb=b)a[c+"_onLoad"]=b,a.fa(c+"_onLoad",[a,d],1)||b(a,d)};try{Object.defineProperty?Object.defineProperty(d,"onLoad",
{get:d.jb,set:d.vb}):d._olc=1}catch(f){d._olc=1}}b&&(a[c+"_onLoad"]=b,a.fa(c+"_onLoad",[a,d],1)||b(a,d))};a.o=function(c){var b,d;for(b in a.S)if(!Object.prototype[b]&&(d=a.S[b])&&(d._olc&&d.onLoad&&(d._olc=0,d.onLoad(a,d)),d[c]&&d[c]()))return 1;return 0};a.Pb=function(){return a.ActivityMap&&a.ActivityMap._c?!0:!1};a.Qb=function(){var c=Math.floor(1E13*Math.random()),b=a.visitorSampling,d=a.visitorSamplingGroup,d="s_vsn_"+(a.visitorNamespace?a.visitorNamespace:a.account)+(d?"_"+d:""),f=a.cookieRead(d);
if(b){b*=100;f&&(f=parseInt(f));if(!f){if(!a.cookieWrite(d,c))return 0;f=c}if(f%1E4>b)return 0}return 1};a.T=function(c,b){var d,f,e,g,h,k;for(d=0;2>d;d++)for(f=0<d?a.Da:a.g,e=0;e<f.length;e++)if(g=f[e],(h=c[g])||c["!"+g]){if(!b&&("contextData"==g||"retrieveLightData"==g)&&a[g])for(k in a[g])h[k]||(h[k]=a[g][k]);a[g]=h}};a.Za=function(c,b){var d,f,e,g;for(d=0;2>d;d++)for(f=0<d?a.Da:a.g,e=0;e<f.length;e++)g=f[e],c[g]=a[g],b||c[g]||(c["!"+g]=1)};a.Hb=function(a){var b,d,f,e,g,h=0,k,m="",n="";if(a&&
255<a.length&&(b=""+a,d=b.indexOf("?"),0<d&&(k=b.substring(d+1),b=b.substring(0,d),e=b.toLowerCase(),f=0,"http://"==e.substring(0,7)?f+=7:"https://"==e.substring(0,8)&&(f+=8),d=e.indexOf("/",f),0<d&&(e=e.substring(f,d),g=b.substring(d),b=b.substring(0,d),0<=e.indexOf("google")?h=",q,ie,start,search_key,word,kw,cd,":0<=e.indexOf("yahoo.co")&&(h=",p,ei,"),h&&k)))){if((a=k.split("&"))&&1<a.length){for(f=0;f<a.length;f++)e=a[f],d=e.indexOf("="),0<d&&0<=h.indexOf(","+e.substring(0,d)+",")?m+=(m?"&":"")+
e:n+=(n?"&":"")+e;m&&n?k=m+"&"+n:n=""}d=253-(k.length-n.length)-b.length;a=b+(0<d?g.substring(0,d):"")+"?"+k}return a};a.cb=function(c){var b=a.d.visibilityState,d=["webkitvisibilitychange","visibilitychange"];b||(b=a.d.webkitVisibilityState);if(b&&"prerender"==b){if(c)for(b=0;b<d.length;b++)a.d.addEventListener(d[b],function(){var b=a.d.visibilityState;b||(b=a.d.webkitVisibilityState);"visible"==b&&c()});return!1}return!0};a.ca=!1;a.J=!1;a.xb=function(){a.J=!0;a.H()};a.K=!1;a.U=!1;a.yb=function(c){a.marketingCloudVisitorID=
c.MCMID;a.visitorOptedOut=c.MCOPTOUT;a.analyticsVisitorID=c.MCAID;a.audienceManagerLocationHint=c.MCAAMLH;a.audienceManagerBlob=c.MCAAMB;a.K=!1;a.U=!0;a.H()};a.bb=function(c){a.maxDelay||(a.maxDelay=250);return a.o("_d")?(c&&setTimeout(function(){c()},a.maxDelay),!1):!0};a.aa=!1;a.I=!1;a.za=function(){a.I=!0;a.H()};a.isReadyToTrack=function(){var c=!0;if(!a.nb()||!a.mb())return!1;a.xa()||(c=!1);a.qb()||(c=!1);return c};a.nb=function(){a.ca||a.J||(a.cb(a.xb)?a.J=!0:a.ca=!0);return a.ca&&!a.J?!1:!0};
a.mb=function(){var c=a.va();if(c)if(a.ta||a.ba)if(a.ta){if(!c.isApproved(c.Categories.ANALYTICS))return!1}else return!1;else return c.fetchPermissions(a.sb,!0),a.ba=!0,!1;return!0};a.X=function(c){var b=a.va();return b&&!b.isApproved(b.Categories[c])?!1:!0};a.va=function(){return k.adobe&&k.adobe.optIn?k.adobe.optIn:null};a.xa=function(){var c=a.V();return c&&c.getVisitorValues&&(a.K||a.U||(a.K=!0,c.getVisitorValues(a.yb)),a.K&&!a.U)?!1:!0};a.V=function(){var c=a.visitor;c&&!c.isAllowed()&&(c=null);
return c};a.qb=function(){a.aa||a.I||(a.bb(a.za)?a.I=!0:a.aa=!0);return a.aa&&!a.I?!1:!0};a.ba=!1;a.sb=function(){a.ba=!1;a.ta=!0};a.l=q;a.r=0;a.callbackWhenReadyToTrack=function(c,b,d){var f;f={};f.Cb=c;f.Bb=b;f.zb=d;a.l==q&&(a.l=[]);a.l.push(f);0==a.r&&(a.r=setInterval(a.H,100))};a.H=function(){var c;if(a.isReadyToTrack()&&(a.wb(),a.l!=q))for(;0<a.l.length;)c=a.l.shift(),c.Bb.apply(c.Cb,c.zb)};a.wb=function(){a.r&&(clearInterval(a.r),a.r=0)};a.lb=function(c){var b,d,f=q,e=q;if(!a.isReadyToTrack()){b=
[];if(c!=q)for(d in f={},c)f[d]=c[d];e={};a.Za(e,!0);b.push(f);b.push(e);a.callbackWhenReadyToTrack(a,a.track,b);return!0}return!1};a.Jb=function(){var c=a.cookieRead("s_fid"),b="",d="",f;f=8;var e=4;if(!c||0>c.indexOf("-")){for(c=0;16>c;c++)f=Math.floor(Math.random()*f),b+="0123456789ABCDEF".substring(f,f+1),f=Math.floor(Math.random()*e),d+="0123456789ABCDEF".substring(f,f+1),f=e=16;c=b+"-"+d}a.cookieWrite("s_fid",c,1)||(c=0);return c};a.t=a.track=function(c,b){var d,f=new Date,e="s"+Math.floor(f.getTime()/
108E5)%10+Math.floor(1E13*Math.random()),g=f.getYear(),g="t="+a.escape(f.getDate()+"/"+f.getMonth()+"/"+(1900>g?g+1900:g)+" "+f.getHours()+":"+f.getMinutes()+":"+f.getSeconds()+" "+f.getDay()+" "+f.getTimezoneOffset()),h=a.V();a.o("_s");a.lb(c)||(b&&a.T(b),c&&(d={},a.Za(d,0),a.T(c)),a.Qb()&&!a.visitorOptedOut&&(a.wa()||(a.fid=a.Jb()),a.Tb(),a.usePlugins&&a.doPlugins&&a.doPlugins(a),a.account&&(a.abort||(a.trackOffline&&!a.timestamp&&(a.timestamp=Math.floor(f.getTime()/1E3)),f=k.location,a.pageURL||
(a.pageURL=f.href?f.href:f),a.referrer||a.$a||(f=a.Util.getQueryParam("adobe_mc_ref",null,null,!0),a.referrer=f||void 0===f?void 0===f?"":f:p.document.referrer),a.$a=1,a.referrer=a.Hb(a.referrer),a.o("_g")),a.Mb()&&!a.abort&&(h&&a.X("TARGET")&&!a.supplementalDataID&&h.getSupplementalDataID&&(a.supplementalDataID=h.getSupplementalDataID("AppMeasurement:"+a._in,a.expectSupplementalData?!1:!0)),a.X("AAM")||(a.contextData["cm.ssf"]=1),a.Nb(),g+=a.Lb(),a.pb(e,g),a.o("_t"),a.referrer=""))),c&&a.T(d,1));
a.abort=a.supplementalDataID=a.timestamp=a.pageURLRest=a.linkObject=a.clickObject=a.linkURL=a.linkName=a.linkType=k.s_objectID=a.pe=a.pev1=a.pev2=a.pev3=a.e=a.lightProfileID=0};a.Ba=[];a.registerPreTrackCallback=function(c){for(var b=[],d=1;d<arguments.length;d++)b.push(arguments[d]);"function"==typeof c?a.Ba.push([c,b]):a.debugTracking&&a.D("DEBUG: Non function type passed to registerPreTrackCallback")};a.gb=function(c){a.ua(a.Ba,c)};a.Aa=[];a.registerPostTrackCallback=function(c){for(var b=[],d=
1;d<arguments.length;d++)b.push(arguments[d]);"function"==typeof c?a.Aa.push([c,b]):a.debugTracking&&a.D("DEBUG: Non function type passed to registerPostTrackCallback")};a.fb=function(c){a.ua(a.Aa,c)};a.ua=function(c,b){if("object"==typeof c)for(var d=0;d<c.length;d++){var f=c[d][0],e=c[d][1].slice();e.unshift(b);if("function"==typeof f)try{f.apply(null,e)}catch(g){a.debugTracking&&a.D(g.message)}}};a.tl=a.trackLink=function(c,b,d,f,e){a.linkObject=c;a.linkType=b;a.linkName=d;e&&(a.k=c,a.v=e);return a.track(f)};
a.trackLight=function(c,b,d,f){a.lightProfileID=c;a.lightStoreForSeconds=b;a.lightIncrementBy=d;return a.track(f)};a.clearVars=function(){var c,b;for(c=0;c<a.g.length;c++)if(b=a.g[c],"prop"==b.substring(0,4)||"eVar"==b.substring(0,4)||"hier"==b.substring(0,4)||"list"==b.substring(0,4)||"channel"==b||"events"==b||"eventList"==b||"products"==b||"productList"==b||"purchaseID"==b||"transactionID"==b||"state"==b||"zip"==b||"campaign"==b)a[b]=void 0};a.tagContainerMarker="";a.pb=function(c,b){var d=a.hb()+
"/"+c+"?AQB=1&ndh=1&pf=1&"+(a.ya()?"callback=s_c_il["+a._in+"].doPostbacks&et=1&":"")+b+"&AQE=1";a.gb(d);a.eb(d);a.W()};a.hb=function(){var c=a.ib();return"http"+(a.ssl?"s":"")+"://"+c+"/b/ss/"+a.account+"/"+(a.mobile?"5.":"")+(a.ya()?"10":"1")+"/JS-"+a.version+(a.Wb?"T":"")+(a.tagContainerMarker?"-"+a.tagContainerMarker:"")};a.ya=function(){return a.AudienceManagement&&a.AudienceManagement.isReady()||0!=a.usePostbacks};a.ib=function(){var c=a.dc,b=a.trackingServer;b?a.trackingServerSecure&&a.ssl&&
(b=a.trackingServerSecure):(c=c?(""+c).toLowerCase():"d1","d1"==c?c="112":"d2"==c&&(c="122"),b=a.kb()+"."+c+".2o7.net");return b};a.kb=function(){var c=a.visitorNamespace;c||(c=a.account.split(",")[0],c=c.replace(/[^0-9a-z]/gi,""));return c};a.Ya=/{(%?)(.*?)(%?)}/;a.$b=RegExp(a.Ya.source,"g");a.Gb=function(c){if("object"==typeof c.dests)for(var b=0;b<c.dests.length;++b){var d=c.dests[b];if("string"==typeof d.c&&"aa."==d.id.substr(0,3))for(var f=d.c.match(a.$b),e=0;e<f.length;++e){var g=f[e],h=g.match(a.Ya),
k="";"%"==h[1]&&"timezone_offset"==h[2]?k=(new Date).getTimezoneOffset():"%"==h[1]&&"timestampz"==h[2]&&(k=a.Kb());d.c=d.c.replace(g,a.escape(k))}}};a.Kb=function(){var c=new Date,b=new Date(6E4*Math.abs(c.getTimezoneOffset()));return a.j(4,c.getFullYear())+"-"+a.j(2,c.getMonth()+1)+"-"+a.j(2,c.getDate())+"T"+a.j(2,c.getHours())+":"+a.j(2,c.getMinutes())+":"+a.j(2,c.getSeconds())+(0<c.getTimezoneOffset()?"-":"+")+a.j(2,b.getUTCHours())+":"+a.j(2,b.getUTCMinutes())};a.j=function(a,b){return(Array(a+
1).join(0)+b).slice(-a)};a.pa={};a.doPostbacks=function(c){if("object"==typeof c)if(a.Gb(c),"object"==typeof a.AudienceManagement&&"function"==typeof a.AudienceManagement.isReady&&a.AudienceManagement.isReady()&&"function"==typeof a.AudienceManagement.passData)a.AudienceManagement.passData(c);else if("object"==typeof c&&"object"==typeof c.dests)for(var b=0;b<c.dests.length;++b){var d=c.dests[b];"object"==typeof d&&"string"==typeof d.c&&"string"==typeof d.id&&"aa."==d.id.substr(0,3)&&(a.pa[d.id]=new Image,
a.pa[d.id].alt="",a.pa[d.id].src=d.c)}};a.eb=function(c){a.i||a.Ob();a.i.push(c);a.ia=a.B();a.Wa()};a.Ob=function(){a.i=a.Rb();a.i||(a.i=[])};a.Rb=function(){var c,b;if(a.oa()){try{(b=k.localStorage.getItem(a.ma()))&&(c=k.JSON.parse(b))}catch(d){}return c}};a.oa=function(){var c=!0;a.trackOffline&&a.offlineFilename&&k.localStorage&&k.JSON||(c=!1);return c};a.Ma=function(){var c=0;a.i&&(c=a.i.length);a.p&&c++;return c};a.W=function(){if(a.p&&(a.A&&a.A.complete&&a.A.F&&a.A.ra(),a.p))return;a.Na=q;if(a.na)a.ia>
a.P&&a.Ua(a.i),a.qa(500);else{var c=a.Ab();if(0<c)a.qa(c);else if(c=a.Ja())a.p=1,a.Sb(c),a.Vb(c)}};a.qa=function(c){a.Na||(c||(c=0),a.Na=setTimeout(a.W,c))};a.Ab=function(){var c;if(!a.trackOffline||0>=a.offlineThrottleDelay)return 0;c=a.B()-a.Sa;return a.offlineThrottleDelay<c?0:a.offlineThrottleDelay-c};a.Ja=function(){if(0<a.i.length)return a.i.shift()};a.Sb=function(c){if(a.debugTracking){var b="AppMeasurement Debug: "+c;c=c.split("&");var d;for(d=0;d<c.length;d++)b+="\n\t"+a.unescape(c[d]);a.D(b)}};
a.wa=function(){return a.marketingCloudVisitorID||a.analyticsVisitorID};a.Z=!1;var t;try{t=JSON.parse('{"x":"y"}')}catch(w){t=null}t&&"y"==t.x?(a.Z=!0,a.Y=function(a){return JSON.parse(a)}):k.$&&k.$.parseJSON?(a.Y=function(a){return k.$.parseJSON(a)},a.Z=!0):a.Y=function(){return null};a.Vb=function(c){var b,d,f;a.wa()&&2047<c.length&&(a.ab()&&(d=1,b=new XMLHttpRequest),b&&(a.AudienceManagement&&a.AudienceManagement.isReady()||0!=a.usePostbacks)&&(a.Z?b.Ea=!0:b=0));!b&&a.Xa&&(c=c.substring(0,2047));
!b&&a.d.createElement&&(0!=a.usePostbacks||a.AudienceManagement&&a.AudienceManagement.isReady())&&(b=a.d.createElement("SCRIPT"))&&"async"in b&&((f=(f=a.d.getElementsByTagName("HEAD"))&&f[0]?f[0]:a.d.body)?(b.type="text/javascript",b.setAttribute("async","async"),d=2):b=0);b||(b=new Image,b.alt="",b.abort||"undefined"===typeof k.InstallTrigger||(b.abort=function(){b.src=q}));b.Ta=Date.now();b.Ga=function(){try{b.F&&(clearTimeout(b.F),b.F=0)}catch(a){}};b.onload=b.ra=function(){b.Ta&&(a.ja=Date.now()-
b.Ta);a.fb(c);b.Ga();a.Eb();a.da();a.p=0;a.W();if(b.Ea){b.Ea=!1;try{a.doPostbacks(a.Y(b.responseText))}catch(d){}}};b.onabort=b.onerror=b.Ka=function(){b.Ga();(a.trackOffline||a.na)&&a.p&&a.i.unshift(a.Db);a.p=0;a.ia>a.P&&a.Ua(a.i);a.da();a.qa(500)};b.onreadystatechange=function(){4==b.readyState&&(200==b.status?b.ra():b.Ka())};a.Sa=a.B();if(1==d)f=c.indexOf("?"),d=c.substring(0,f),f=c.substring(f+1),f=f.replace(/&callback=[a-zA-Z0-9_.\[\]]+/,""),b.open("POST",d,!0),b.withCredentials=!0,b.send(f);
else if(b.src=c,2==d){if(a.Qa)try{f.removeChild(a.Qa)}catch(e){}f.firstChild?f.insertBefore(b,f.firstChild):f.appendChild(b);a.Qa=a.A}b.F=setTimeout(function(){b.F&&(b.complete?b.ra():(a.trackOffline&&b.abort&&b.abort(),b.Ka()))},5E3);a.Db=c;a.A=k["s_i_"+a.replace(a.account,",","_")]=b;if(a.useForcedLinkTracking&&a.L||a.v)a.forcedLinkTrackingTimeout||(a.forcedLinkTrackingTimeout=250),a.ea=setTimeout(a.da,a.forcedLinkTrackingTimeout)};a.ab=function(){return"undefined"!==typeof XMLHttpRequest&&"withCredentials"in
new XMLHttpRequest?!0:!1};a.Eb=function(){if(a.oa()&&!(a.Ra>a.P))try{k.localStorage.removeItem(a.ma()),a.Ra=a.B()}catch(c){}};a.Ua=function(c){if(a.oa()){a.Wa();try{k.localStorage.setItem(a.ma(),k.JSON.stringify(c)),a.P=a.B()}catch(b){}}};a.Wa=function(){if(a.trackOffline){if(!a.offlineLimit||0>=a.offlineLimit)a.offlineLimit=10;for(;a.i.length>a.offlineLimit;)a.Ja()}};a.forceOffline=function(){a.na=!0};a.forceOnline=function(){a.na=!1};a.ma=function(){return a.offlineFilename+"-"+a.visitorNamespace+
a.account};a.B=function(){return(new Date).getTime()};a.Oa=function(a){a=a.toLowerCase();return 0!=a.indexOf("#")&&0!=a.indexOf("about:")&&0!=a.indexOf("opera:")&&0!=a.indexOf("javascript:")?!0:!1};a.setTagContainer=function(c){var b,d,f;a.Wb=c;for(b=0;b<a._il.length;b++)if((d=a._il[b])&&"s_l"==d._c&&d.tagContainerName==c){a.T(d);if(d.lmq)for(b=0;b<d.lmq.length;b++)f=d.lmq[b],a.loadModule(f.n);if(d.ml)for(f in d.ml)if(a[f])for(b in c=a[f],f=d.ml[f],f)!Object.prototype[b]&&("function"!=typeof f[b]||
0>(""+f[b]).indexOf("s_c_il"))&&(c[b]=f[b]);if(d.mmq)for(b=0;b<d.mmq.length;b++)f=d.mmq[b],a[f.m]&&(c=a[f.m],c[f.f]&&"function"==typeof c[f.f]&&(f.a?c[f.f].apply(c,f.a):c[f.f].apply(c)));if(d.tq)for(b=0;b<d.tq.length;b++)a.track(d.tq[b]);d.s=a;break}};a.Util={urlEncode:a.escape,urlDecode:a.unescape,cookieRead:a.cookieRead,cookieWrite:a.cookieWrite,getQueryParam:function(c,b,d,f){var e,g="";b||(b=a.pageURL?a.pageURL:k.location);d=d?d:"&";if(!c||!b)return g;b=""+b;e=b.indexOf("?");if(0>e)return g;b=
d+b.substring(e+1)+d;if(!f||!(0<=b.indexOf(d+c+d)||0<=b.indexOf(d+c+"="+d))){e=b.indexOf("#");0<=e&&(b=b.substr(0,e)+d);e=b.indexOf(d+c+"=");if(0>e)return g;b=b.substring(e+d.length+c.length+1);e=b.indexOf(d);0<=e&&(b=b.substring(0,e));0<b.length&&(g=a.unescape(b));return g}},getIeVersion:function(){if(document.documentMode)return document.documentMode;for(var a=7;4<a;a--){var b=document.createElement("div");b.innerHTML="\x3c!--[if IE "+a+"]><span></span><![endif]--\x3e";if(b.getElementsByTagName("span").length)return a}return null}};
a.G="supplementalDataID timestamp dynamicVariablePrefix visitorID marketingCloudVisitorID analyticsVisitorID audienceManagerLocationHint authState fid vmk visitorMigrationKey visitorMigrationServer visitorMigrationServerSecure charSet visitorNamespace cookieDomainPeriods fpCookieDomainPeriods cookieLifetime pageName pageURL customerPerspective referrer contextData currencyCode lightProfileID lightStoreForSeconds lightIncrementBy retrieveLightProfiles deleteLightProfiles retrieveLightData".split(" ");
a.g=a.G.concat("purchaseID variableProvider channel server pageType transactionID campaign state zip events events2 products audienceManagerBlob tnt".split(" "));a.ka="timestamp charSet visitorNamespace cookieDomainPeriods cookieLifetime contextData lightProfileID lightStoreForSeconds lightIncrementBy".split(" ");a.Q=a.ka.slice(0);a.Da="account allAccounts debugTracking visitor visitorOptedOut trackOffline offlineLimit offlineThrottleDelay offlineFilename usePlugins doPlugins configURL visitorSampling visitorSamplingGroup linkObject clickObject linkURL linkName linkType trackDownloadLinks trackExternalLinks trackClickMap trackInlineStats linkLeaveQueryString linkTrackVars linkTrackEvents linkDownloadFileTypes linkExternalFilters linkInternalFilters useForcedLinkTracking forcedLinkTrackingTimeout useLinkTrackSessionStorage trackingServer trackingServerSecure ssl abort mobile dc lightTrackVars maxDelay expectSupplementalData usePostbacks registerPreTrackCallback registerPostTrackCallback AudienceManagement".split(" ");
for(m=0;250>=m;m++)76>m&&(a.g.push("prop"+m),a.Q.push("prop"+m)),a.g.push("eVar"+m),a.Q.push("eVar"+m),6>m&&a.g.push("hier"+m),4>m&&a.g.push("list"+m);m="pe pev1 pev2 pev3 latitude longitude resolution colorDepth javascriptVersion javaEnabled cookiesEnabled browserWidth browserHeight connectionType homepage pageURLRest marketingCloudOrgID ms_a".split(" ");a.g=a.g.concat(m);a.G=a.G.concat(m);a.ssl=0<=k.location.protocol.toLowerCase().indexOf("https");a.charSet="UTF-8";a.contextData={};a.offlineThrottleDelay=
0;a.offlineFilename="AppMeasurement.offline";a.R="s_sq";a.Sa=0;a.ia=0;a.P=0;a.Ra=0;a.linkDownloadFileTypes="exe,zip,wav,mp3,mov,mpg,avi,wmv,pdf,doc,docx,xls,xlsx,ppt,pptx";a.w=k;a.d=k.document;try{if(a.Xa=!1,navigator){var v=navigator.userAgent;if("Microsoft Internet Explorer"==navigator.appName||0<=v.indexOf("MSIE ")||0<=v.indexOf("Trident/")&&0<=v.indexOf("Windows NT 6"))a.Xa=!0}}catch(x){}a.da=function(){a.ea&&(k.clearTimeout(a.ea),a.ea=q);a.k&&a.L&&a.k.dispatchEvent(a.L);a.v&&("function"==typeof a.v?
a.v():a.k&&a.k.href&&(a.d.location=a.k.href));a.k=a.L=a.v=0};a.Va=function(){a.b=a.d.body;a.b?(a.u=function(c){var b,d,f,e,g;if(!(a.d&&a.d.getElementById("cppXYctnr")||c&&c["s_fe_"+a._in])){if(a.Fa)if(a.useForcedLinkTracking)a.b.removeEventListener("click",a.u,!1);else{a.b.removeEventListener("click",a.u,!0);a.Fa=a.useForcedLinkTracking=0;return}else a.useForcedLinkTracking=0;a.clickObject=c.srcElement?c.srcElement:c.target;try{if(!a.clickObject||a.O&&a.O==a.clickObject||!(a.clickObject.tagName||
a.clickObject.parentElement||a.clickObject.parentNode))a.clickObject=0;else{var h=a.O=a.clickObject;a.ha&&(clearTimeout(a.ha),a.ha=0);a.ha=setTimeout(function(){a.O==h&&(a.O=0)},1E4);f=a.Ma();a.track();if(f<a.Ma()&&a.useForcedLinkTracking&&c.target){for(e=c.target;e&&e!=a.b&&"A"!=e.tagName.toUpperCase()&&"AREA"!=e.tagName.toUpperCase();)e=e.parentNode;if(e&&(g=e.href,a.Oa(g)||(g=0),d=e.target,c.target.dispatchEvent&&g&&(!d||"_self"==d||"_top"==d||"_parent"==d||k.name&&d==k.name))){try{b=a.d.createEvent("MouseEvents")}catch(l){b=
new k.MouseEvent}if(b){try{b.initMouseEvent("click",c.bubbles,c.cancelable,c.view,c.detail,c.screenX,c.screenY,c.clientX,c.clientY,c.ctrlKey,c.altKey,c.shiftKey,c.metaKey,c.button,c.relatedTarget)}catch(m){b=0}b&&(b["s_fe_"+a._in]=b.s_fe=1,c.stopPropagation(),c.stopImmediatePropagation&&c.stopImmediatePropagation(),c.preventDefault(),a.k=c.target,a.L=b)}}}}}catch(n){a.clickObject=0}}},a.b&&a.b.attachEvent?a.b.attachEvent("onclick",a.u):a.b&&a.b.addEventListener&&(navigator&&(0<=navigator.userAgent.indexOf("WebKit")&&
a.d.createEvent||0<=navigator.userAgent.indexOf("Firefox/2")&&k.MouseEvent)&&(a.Fa=1,a.useForcedLinkTracking=1,a.b.addEventListener("click",a.u,!0)),a.b.addEventListener("click",a.u,!1))):setTimeout(a.Va,30)};a.Fb();a.fc||(r?a.setAccount(r):a.D("Error, missing Report Suite ID in AppMeasurement initialization"),a.Va(),a.loadModule("ActivityMap"))}
function s_gi(r){var a,k=window.s_c_il,q,p,m=r.split(","),s,u,t=0;if(k)for(q=0;!t&&q<k.length;){a=k[q];if("s_c"==a._c&&(a.account||a.oun))if(a.account&&a.account==r)t=1;else for(p=a.account?a.account:a.oun,p=a.allAccounts?a.allAccounts:p.split(","),s=0;s<m.length;s++)for(u=0;u<p.length;u++)m[s]==p[u]&&(t=1);q++}t?a.setAccount&&a.setAccount(r):a=new AppMeasurement(r);return a}AppMeasurement.getInstance=s_gi;window.s_objectID||(window.s_objectID=0);
function s_pgicq(){var r=window,a=r.s_giq,k,q,p;if(a)for(k=0;k<a.length;k++)q=a[k],p=s_gi(q.oun),p.setAccount(q.un),p.setTagContainer(q.tagContainerName);r.s_giq=0}s_pgicq();

// Integrate Module

function AppMeasurement_Module_Integrate(l){var c=this;c.s=l;var e=window;e.s_c_in||(e.s_c_il=[],e.s_c_in=0);c._il=e.s_c_il;c._in=e.s_c_in;c._il[c._in]=c;e.s_c_in++;c._c="s_m";c.list=[];c.add=function(d,b){var a;b||(b="s_Integrate_"+d);e[b]||(e[b]={});a=c[d]=e[b];a.a=d;a.e=c;a._c=0;a._d=0;void 0==a.disable&&(a.disable=0);a.get=function(b,d){var f=document,h=f.getElementsByTagName("HEAD"),k;if(!a.disable&&(d||(v="s_"+c._in+"_Integrate_"+a.a+"_get_"+a._c),a._c++,a.VAR=v,a.CALLBACK="s_c_il["+c._in+"]."+
a.a+".callback",a.delay(),h=h&&0<h.length?h[0]:f.body))try{k=f.createElement("SCRIPT"),k.type="text/javascript",k.setAttribute("async","async"),k.src=c.c(a,b),0>b.indexOf("[CALLBACK]")&&(k.onload=k.onreadystatechange=function(){a.callback(e[v])}),h.firstChild?h.insertBefore(k,h.firstChild):h.appendChild(k)}catch(l){}};a.callback=function(b){var c;if(b)for(c in b)Object.prototype[c]||(a[c]=b[c]);a.ready()};a.beacon=function(b){var d="s_i_"+c._in+"_Integrate_"+a.a+"_"+a._c;a.disable||(a._c++,d=e[d]=
new Image,d.src=c.c(a,b))};a.script=function(b){a.get(b,1)};a.delay=function(){a._d++};a.ready=function(){a._d--;a.disable||l.delayReady()};c.list.push(d)};c._g=function(d){var b,a=(d?"use":"set")+"Vars";for(d=0;d<c.list.length;d++)if((b=c[c.list[d]])&&!b.disable&&b[a])try{b[a](l,b)}catch(e){}};c._t=function(){c._g(1)};c._d=function(){var d,b;for(d=0;d<c.list.length;d++)if((b=c[c.list[d]])&&!b.disable&&0<b._d)return 1;return 0};c.c=function(c,b){var a,e,g,f;"http"!=b.toLowerCase().substring(0,4)&&
(b="http://"+b);l.ssl&&(b=l.replace(b,"http:","https:"));c.RAND=Math.floor(1E13*Math.random());for(a=0;0<=a;)a=b.indexOf("[",a),0<=a&&(e=b.indexOf("]",a),e>a&&(g=b.substring(a+1,e),2<g.length&&"s."==g.substring(0,2)?(f=l[g.substring(2)])||(f=""):(f=""+c[g],f!=c[g]&&parseFloat(f)!=c[g]&&(g=0)),g&&(b=b.substring(0,a)+encodeURIComponent(f)+b.substring(e+1)),a=e));return b}}

// End Integrate Module

/*
 Start ActivityMap Module

 The following module enables ActivityMap tracking in Adobe Analytics. ActivityMap
 allows you to view data overlays on your links and content to understand how
 users engage with your web site. If you do not intend to use ActivityMap, you
 can remove the following block of code from your AppMeasurement.js file.
 Additional documentation on how to configure ActivityMap is available at:
 https://marketing.adobe.com/resources/help/en_US/analytics/activitymap/getting-started-admins.html
*/
function AppMeasurement_Module_ActivityMap(f){function g(a,d){var b,c,m;if(a&&d&&(b=e.c[d]||(e.c[d]=d.split(","))))for(m=0;m<b.length&&(c=b[m++]);)if(-1<a.indexOf(c))return null;n=1;return a}function p(a,d,b,c,e){var g,k;if(a.dataset&&(k=a.dataset[d]))g=k;else if(a.getAttribute)if(k=a.getAttribute("data-"+b))g=k;else if(k=a.getAttribute(b))g=k;if(!g&&f.useForcedLinkTracking&&e){var h;a=a.onclick?""+a.onclick:"";varValue="";if(c&&a&&(d=a.indexOf(c),0<=d)){for(d+=c.length;d<a.length;)if(b=a.charAt(d++),
0<="'\"".indexOf(b)){h=b;break}for(k=!1;d<a.length&&h;){b=a.charAt(d);if(!k&&b===h)break;"\\"===b?k=!0:(varValue+=b,k=!1);d++}}(h=varValue)&&(f.w[c]=h)}return g||e&&f.w[c]}function q(a,d,b){var c;return(c=e[d](a,b))&&(n?(n=0,c):g(h(c),e[d+"Exclusions"]))}function r(a,d,b){var c;if(a&&!(1===(c=a.nodeType)&&(c=a.nodeName)&&(c=c.toUpperCase())&&s[c])&&(1===a.nodeType&&(c=a.nodeValue)&&(d[d.length]=c),b.a||b.t||b.s||!a.getAttribute||((c=a.getAttribute("alt"))?b.a=c:(c=a.getAttribute("title"))?b.t=c:"IMG"==
(""+a.nodeName).toUpperCase()&&(c=a.getAttribute("src")||a.src)&&(b.s=c)),(c=a.childNodes)&&c.length))for(a=0;a<c.length;a++)r(c[a],d,b)}function h(a){if(null==a||void 0==a)return a;try{return a.replace(RegExp("^[\\s\\n\\f\\r\\t\t-\r \u00a0\u1680\u180e\u2000-\u200a\u2028\u2029\u205f\u3000\ufeff]+","mg"),"").replace(RegExp("[\\s\\n\\f\\r\\t\t-\r \u00a0\u1680\u180e\u2000-\u200a\u2028\u2029\u205f\u3000\ufeff]+$","mg"),"").replace(RegExp("[\\s\\n\\f\\r\\t\t-\r \u00a0\u1680\u180e\u2000-\u200a\u2028\u2029\u205f\u3000\ufeff]{1,}",
"mg")," ").substring(0,254)}catch(d){}}var e=this;e.s=f;var l=window;l.s_c_in||(l.s_c_il=[],l.s_c_in=0);e._il=l.s_c_il;e._in=l.s_c_in;e._il[e._in]=e;l.s_c_in++;e._c="s_m";e.c={};var n=0,s={SCRIPT:1,STYLE:1,LINK:1,CANVAS:1};e._g=function(){var a,d,b,c=f.contextData,e=f.linkObject;(a=f.pageName||f.pageURL)&&(d=q(e,"link",f.linkName))&&(b=q(e,"region"))&&(c["a.activitymap.page"]=a.substring(0,255),c["a.activitymap.link"]=128<d.length?d.substring(0,128):d,c["a.activitymap.region"]=127<b.length?b.substring(0,
127):b,c["a.activitymap.pageIDType"]=f.pageName?1:0)};e.link=function(a,d){var b;if(d)b=g(h(d),e.linkExclusions);else if((b=a)&&!(b=p(a,"sObjectId","s-object-id","s_objectID",1))){var c,f;(f=g(h(a.innerText||a.textContent),e.linkExclusions))||(r(a,c=[],b={a:void 0,t:void 0,s:void 0}),(f=g(h(c.join(""))))||(f=g(h(b.a?b.a:b.t?b.t:b.s?b.s:void 0)))||!(c=(c=a.tagName)&&c.toUpperCase?c.toUpperCase():"")||("INPUT"==c||"SUBMIT"==c&&a.value?f=g(h(a.value)):"IMAGE"==c&&a.src&&(f=g(h(a.src)))));b=f}return b};
e.region=function(a){for(var d,b=e.regionIDAttribute||"id";a&&(a=a.parentNode);){if(d=p(a,b,b,b))return d;if("BODY"==a.nodeName)return"BODY"}}}
/* End ActivityMap Module */
/*eslint-enable*/


//tealium universal tag - utag.sender.19063.am161 v4.0.201909300556, Copyright 2019 Tealium.com Inc. All Rights Reserved.
try{
  (function(id,loader){

    /**
     * Tealium VisitorAPIWrapper v1.0
     */
    window.utag.tagsettings = window.utag.tagsettings || {};
    window.utag.tagsettings.adobe = window.utag.tagsettings.adobe || {};
    var vAPI = window.utag.tagsettings.adobe.visitorAPI = window.utag.tagsettings.adobe.visitorAPI || (function() { return {getInstance : function(orgID, callback) {
        if (orgID) {
          utag.DB("["+u.id+"] OrgID used, but no 'Adobe Marketing Cloud ID Service' tag detected");
        }
        return callback();
      }}; }());

    var u = {"id" : id};
    u.queue = [];
    utag.o[loader].sender[id] = u;
    u.ev={'view':1,'link':1,'video':1};
    u.o=tealium_s;
    u.varlist={pageName:'pageName',channel:'ch',campaign:'v0',hier1:'h1',hier2:'h2',hier3:'h3',hier4:'h4'};for(var i=1;i<76;i++){u.varlist['prop'+i]='c'+i;u.varlist['eVar'+i]='v'+i;}
    u.combineLinkVar = false;
    u.pushlt=function(l,v){if(typeof l!="undefined")l.push(v)};

    // Start Tealium typeOf 4.35
    if (utag.ut.typeOf === undefined) { u.typeOf = function(e) {return ({}).toString.call(e).match(/\s([a-zA-Z]+)/)[1].toLowerCase();};} else { u.typeOf = utag.ut.typeOf; }
    // End Tealium typeOf
    u.typeCheck = function(linkTrack, type){
      if(u.typeOf(linkTrack) === "string"){
        u[type] = linkTrack.split(",");
      }else if(u.typeOf(linkTrack) === "array"){
        u[type] = linkTrack;
      }else{
        u[type] = [];
      }
    }

  u.map={"_sm_125_1":"debugTracking","currency_code":"currencyCode","_sm_125_3":"hier1","page_name":"pageName","dom.protocol_domain_pathname":"pageURL","dom.url":"eVar1","dom.protocol":"eVar2","dom.domain":"eVar3","dom.pathname":"eVar4","dom.query_string":"eVar5","dom.hash":"eVar6","dom.pathname_1":"eVar11","dom.pathname_2":"eVar12","dom.pathname_3":"eVar13","dom.pathname_4":"eVar14","dom.pathname_5":"eVar15","dom.pathname_n_4":"eVar16","dom.pathname_n_3":"eVar17","dom.pathname_n_2":"eVar18","dom.pathname_n_1":"eVar19","dom.pathname_n":"eVar20","qp.ext":"eVar21","qp.cid":"eVar22","qp.pos":"eVar23","qp.dfac":"eVar24","qp.extid":"eVar25","tealium_timestamp_epoch":"eVar31","tealium_timestamp_utc":"eVar32","tealium_timestamp_local_offset":"eVar33","tealium_timestamp_time_of_day":"eVar34","js_page.window.navigator.userAgent":"eVar42","dom.viewport_orientation":"eVar43","cookie_consent_old_version":"eVar51","cookie_consent_old_level":"eVar52","cookie_consent_state":"eVar53","js_page.navigator.doNotTrack":"eVar54","organization_business_line":"eVar61,channel","page_language_location":"eVar62","page_type":"eVar63","page_id":"eVar64","dom.title":"eVar65","page_publish_date":"eVar66","_sm_125_43":"eVar67","cp.UVID":"eVar71","user_is_logged_in":"eVar72","user_service_segment":"eVar73","user_client_group_code":"eVar74","user_bc_number":"eVar75","dom.referrer":"eVar81","tealium_datasource":"eVar91","environment_name":"eVar92","event_category":"eVar101","event_action":"eVar102","event_label":"eVar103","_sm_125_55":"eVar104","widget_module":"eVar111","widget_name":"eVar112","widget_state":"eVar113","widget_substate":"eVar114","widget_title":"eVar115","user_login_method":"eVar131","product_category":"eVar151,PRODUCTS_category","product_name":"eVar152,PRODUCTS_id","product_quantity":"eVar153,PRODUCTS_quantity","product_price":"eVar154,PRODUCTS_price","cp._svtri":"eVar181","js_page.window.localStorage.user_last_sync_relay42_segments":"eVar182","adobe_target_pcid":"eVar183","_sm_125_69":"eVar184","tealium_profile":"eVar191","js_page.utag.cfg.v":"eVar192","tealium_event":"eVar193","tealium_event:link":"event1","event_name":"eVar194","event_name:process/application-start":"event11,event12","event_name:process/appointment-start":"event11,event13","event_name:process/interaction-start":"event11,event14","event_name:process/service-start":"event11,event15","event_name:process/application-end":"event16,event17,purchase","event_name:process/appointment-end":"event16,event18","event_name:process/interaction-end":"event16,event19","event_name:process/service-end":"event16,event20","event_name:error/state":"event32","event_name:submit/error":"event32","event_name:process/error":"event32","event_name:process/forms-error":"event32","event_name:javascript_error_occurred":"event31","event_name:update/message":"event41","event_name:update/messageview":"event42","event_name:click/messageclick":"event43","state_name":"eVar194","cp.utagdb":"eVar195","tealium_visitor_id":"eVar196","tealium_session_id":"eVar197","tealium_session_number":"eVar198","cp.utag_main__pn":"eVar199","tealium_random":"eVar200","is_conversion:true":"event2"};
  u.extend=[function(a,b){
try{b['_sm_125_1']=false;;}catch(e){utag.DB(e);}
try{b['_sm_125_3']=b['dom.pathname'].substring(1);;}catch(e){utag.DB(e);}
try{b['_sm_125_43']=JSON.stringify(b.page_custom);;}catch(e){utag.DB(e);}
try{b['_sm_125_55']=JSON.stringify(b.event_custom);;}catch(e){utag.DB(e);}
try{b['_sm_125_69']=JSON.stringify({is_optimization: b.is_optimization, is_conversion: b.is_conversion});;}catch(e){utag.DB(e);}
},
function(a,b){ try{ if(b['tealium_event']=='view'){
function duplicatePageViewHack(b) {
  /* The current setup of OCA widgets generates duplicate pageviews. This hack at least blocks those coming from blacklisted widgets */
  if (
    b.widget_name != null &&
    [
      "chat-client-nl-widget-ec",
      "personal-contact-info-widget-sc",
      "content-widget-mijn-abnamro",
      "content-widget-my-abnamro",
      "chat-client-nl-widget-wpp",
      "content-widget-my-abnamro-business"
    ].indexOf(b.widget_name) > -1
  ) {
    utag.DB(
      'duplicatePageViewHack: No Adobe Analytics page view because widget_name "'.concat(
        b.widget_name,
        '" is on the blacklist'
      )
    );
    return false;
  }

  return true;
}
return duplicatePageViewHack(b);
} } catch(e){ utag.DB(e) }  },
function(a,b,c,d){ try{ if(1){c=[b['tealium_account'],b['tealium_profile'],b['tealium_environment']];b['tealium_profile']=c.join('/')} } catch(e){ utag.DB(e) }  },
function(a,b){ try{ if(1){
/* This extension loads all necessary Adobe Analytics plugins. Don't edit these, please.
See https://docs.adobe.com/content/help/en/analytics/implementation/javascript-implementation/appmeasurement-js/plugins-support.html for more plugins.*/

var s = window.tealium_s;

/* Adobe Consulting Plugin: channelManager v4.0 (Requires AppMeasurement and the CONSULTING-BUILT getQueryParam v3.2/pt v2.0 plugins) */
s.channelManager=function(qsp,tbl,con){var s=this,e=!0,p=new Date;p.setTime(p.getTime()+18E5);if(s._channel)return"";var g="n/a",l="n/a",u="n/a",v="n/a",w="n/a",q="n/a";s.c_r("s_tbm")&&(e=!1);tbl&&s.c_r("s_tbm"+tbl.toString())&&(e=!1);s.c_w("s_tbm",!0,p);var h=s.referrer?s.referrer:document.referrer;"Typed/Bookmarked"===h&&(h="");var c=!1;if(h){c=!0;var k=h.split("/")[2].split("?")[0].toLowerCase(),b=s.linkInternalFilters.toLowerCase().split(","),d=b.length;for(a=0;a<d;a++)if(-1<k.indexOf(b[a])){c=!1;break}}if(c&&(v=h,w=k,g="Other Natural Referrers",l=g+": "+k,s._channelSEList)){d=s._channelSEList.split(">");for(var m=d.length,n,t,y,a=0;a<m;a++){b=d[a];n=b.split("|");t=n[1].split(",");y=t.length;for(b=0;b<y;b++)if(-1<k.indexOf(t[b].toLowerCase())){q=n[0];break}if("n/a"!==q)break}}d="";if(qsp){b=qsp.split(",");qsp=b.length;for(a=0;a<qsp&&!(d=s.getQueryParam(b[a]));a++);d&&(u=l=d,g="n/a"!==q?"Paid Search":"Unknown Paid Channel")}d||"n/a"===q||(g="Natural Search",l=g+": "+q);!e||h||d||(v=w=l=g="Typed/Bookmarked");if(s._channelDomain&&c)for(qsp=!1,e=s._channelDomain.split(">"),h=e.length,a=0;a<h;a++){c=e[a]?e[a].split("|"):"";m=c[1]?c[1].split(","):"";n=m.length;for(b=0;b<n;b++)if(t=m[b].toLowerCase(),-1<("/"+k).indexOf(t)){g=c[0];l=d?l:g+": "+k;qsp=!0;break}if(qsp)break}if(s._channelParameter)for(qsp=!1,e=s._channelParameter.split(">"),h=e.length,a=0;a<h;a++){c=e[a]?e[a].split("|"):"";n=c[1]?c[1].split(","):"";b=0;for(m=n.length;b<m;b++)if(s.getQueryParam(n[b])){g=c[0];l=d?l:g+": "+k;qsp=!0;break}if(qsp)break}if(s._channelPattern&&d)for(qsp=!1,e=s._channelPattern.split(">"),h=e.length,a=0;a<h;a++){c=e[a]?e[a].split("|"):"";k=c[1]?c[1].split(","):"";b=0;for(m=k.length;b<m;b++)if(!con&&0==d.toLowerCase().indexOf(k[b].toLowerCase())||con&&-1<d.toLowerCase().indexOf(k[b].toLowerCase())){g=c[0];u=l=d;qsp=!0;break}if(qsp)break}"n/a"!==g?(s._channel=g,s._campaign=l,s._campaignID=u,s._referrer=v,s._referringDomain=w,s._searchEngine=q,"Typed/Bookmarked"!==s._channel&&tbl&&(p.setTime(p.getTime()+864E5*Number(tbl)),s.c_w("s_tbm"+tbl.toString(),!0,p))):s._channel=s._campaign=s._campaignID=s._referrer=s._referringDomain=s._searchEngine=""};

/* Adobe Consulting Plugin: getQueryParam v3.2 (Requires AppMeasurement and pt plugin) */
s.getQueryParam=function(qsp,de,url){var s=this,e="",l=function(b,c){-1<c.indexOf("#")&&(-1<c.indexOf("?")?c.indexOf("?")>c.indexOf("#")?(c=c.split("?").join("&"),c=c.split("#").join("?")):c=c.split("#").join("&"):c=c.split("#").join("?"));var h=c.indexOf("?"),de="";b&&(-1<h||-1<c.indexOf("="))&&(h=c.substring(h+1),de=s.pt(h,"&","gpval",b));return de};qsp=qsp.split(",");var m=qsp.length;s.gpval=function(b,c){if(b){var de=b.split("="),url=de[0];de=de[1]?de[1]:!0;if(c.toLowerCase()==url.toLowerCase())return"boolean"===typeof de?de:this.unescape(de)}return""};de=de?de:"";url=(url?url:s.pageURL?s.pageURL:location.href)+"";if((4<de.length||-1<de.indexOf("="))&&url&&4>url.length){var b=de;de=url;url=b}for(var k=0;k<m;k++)b=l(qsp[k],url),"string"===typeof b?(b=-1<b.indexOf("#")?b.substring(0,b.indexOf("#")):b,e+=e?de+b:b):e=""===e?b:e+(de+b);return e};

/* Adobe Consulting Plugin: pt v2.0 (Requires AppMeasurement) */
s.pt=function(lv,de,cf,fa){if(!lv||!de||!this[cf])return"";lv=lv.split(de?de:",");de=lv.length;for(var e="",c=0;c<de&&!(e=this[cf](lv[c],fa));c++);return e};

/* channelManager SearchEngineList
Don't edit this here. Use s._extraSearchEngines in s_doPlugins instead. */
s._channelSEList="Google|.google.,googlesyndication.com,.googleadservices.com>Google Search App|googlequicksearchbox>Bing|bing.com>Yahoo!|yahoo.com,yahoo.co.jp>Naver|naver.com,search.naver.com>Yandex.ru|yandex>DuckDuckGo|duckduckgo.com>Daum|daum.net,search.daum.net>Baidu|baidu.com>MyWay.com|myway.com>Ecosia|ecosia.org>Ask|ask.jp,ask.co>DogPile|dogpile.com>sm.cn|sm.cn>sogou.com|sogou.com>Haosou|so.com>Seznam.cz|Seznam.cz>AOL|search.aol.,suche.aolsvc.de>AltaVista|altavista.co,altavista.de>MyWebSearch|.mywebsearch.com>WebCrawler|webcrawler.com>Wow|wow.com>InfoSpace|infospace.com>Blekko|blekko.com>Docomo|docomo.ne.jp";

/* crossVisitParticipation v1.7 - stacks values from specified variable in cookie and returns value
v = value to stack
cn = name of the cookie storing the list of values
ex = expiration (in days) of each value in the list
ct = number of distinct values to store in the list
dl = value delimiter
ev = (optional) Comma seperated list of success events that will clear the list
dv = (optional) whether consecutive duplicate values will be stored (0=no,1=yes) */
s.crossVisitParticipation=new Function("v","cn","ex","ct","dl","ev","dv",""
+"var s=this,ce;if(typeof(dv)==='undefined')dv=0;if(s.events&&ev){var"
+" ay=s.split(ev,',');var ea=s.split(s.events,',');for(var u=0;u<ay.l"
+"ength;u++){for(var x=0;x<ea.length;x++){if(ay[u]==ea[x]){ce=1;}}}}i"
+"f(!v||v==''){if(ce){s.c_w(cn,'');return'';}else return'';}v=escape("
+"v);var arry=new Array(),a=new Array(),c=s.c_r(cn),g=0,h=new Array()"
+";if(c&&c!=''){arry=s.split(c,'],[');for(q=0;q<arry.length;q++){z=ar"
+"ry[q];z=s.repl(z,'[','');z=s.repl(z,']','');z=s.repl(z,\"'\",'');arry"
+"[q]=s.split(z,',')}}var e=new Date();e.setFullYear(e.getFullYear()+"
+"5);if(dv==0&&arry.length>0&&arry[arry.length-1][0]==v)arry[arry.len"
+"gth-1]=[v,new Date().getTime()];else arry[arry.length]=[v,new Date("
+").getTime()];var start=arry.length-ct<0?0:arry.length-ct;var td=new"
+" Date();for(var x=start;x<arry.length;x++){var diff=Math.round((td."
+"getTime()-arry[x][1])/86400000);if(diff<ex){h[g]=unescape(arry[x][0"
+"]);a[g]=[arry[x][0],arry[x][1]];g++;}}var data=s.join(a,{delim:',',"
+"front:'[',back:']',wrap:\"'\"});s.c_w(cn,data,e);var r=s.join(h,{deli"
+"m:dl});if(ce)s.c_w(cn,'');return r;");

/* split v1.5 (JS 1.0 compatible) */
s.split=new Function("l","d",""
+"var i,x=0,a=new Array;while(l){i=l.indexOf(d);i=i>-1?i:l.length;a[x"
+"++]=l.substring(0,i);l=l.substring(i+d.length);}return a");

/* s.join v1.0 - Joins an array into a string */
s.join = new Function("v","p",""
+"var s = this;var f,b,d,w;if(p){f=p.front?p.front:'';b=p.back?p.back"
+":'';d=p.delim?p.delim:'';w=p.wrap?p.wrap:'';}var str='';for(var x=0"
+";x<v.length;x++){if(typeof(v[x])=='object' )str+=s.join( v[x],p);el"
+"se str+=w+v[x]+w;if(x<v.length-1)str+=d;}return f+str+b;");

/* Replace v1.0 */
s.repl=new Function("x","o","n",""
+"var i=x.indexOf(o),l=n.length;while(x&&i>=0){x=x.substring(0,i)+n+x."
+"substring(i+o.length);i=x.indexOf(o,i+l)}return x");

/* Plugin: getVisitStart v2.1 - return 1 on start of visit, else 0 */
s.getVisitStart=new Function("c",""
+"var s=this,n,t=new Date;if(typeof s.callType=='function'&&s.callTyp"
+"e()=='+')return 0;if(!c)c='s_visit';t.setTime(t.getTime()+18e5);n=s"
+".c_r(c)?0:1;if(!s.c_w(c,1,t))s.c_w(c,1,0);if(!s.c_r(c))n=0;return n");

} } catch(e){ utag.DB(e) }  },
function(a,b){ try{ if(1){
function s_doPlugins(s) {
  /* Add all Adobe Analytics-specific JavaScript here, as long it doesn't make more sense to use a
  UDO Variable and/or a separate extension. Note that if this extension is run after other
  extensions, it will overwrite values set in those other extensions. Tealium's data layer
  variables are accessible through the 'b' object */

  /* On the first hit of the visit, load Channel Manager v4.0 and set campaign variables */
  if (s.getVisitStart() === 1) {
    /* See the Channel Manager v4.0 documentation on how to set these parameters up */
    s._extraSearchEngines = '';
    s._channelDomain = 'Social Networks|facebook.com,linkedin.com,twitter.com,/t.co,instagram.com,pinterest.com,youtube.com,' + 'yelp.com,flickr.com,tumblr.com,snapchat.com,vimeo.com,vk.com,buzzfeed.com,blogspot.com,reddit.com,' + 'plus.url.google.com,plus.google.com,disq.us,disqus.com';
    s._channelParameter = '';
    s._channelPattern = 'Paid Search|DS3_,google-paid' + '>Email|email_,belnieuws' + '>Display Ad|dcm_,CX_' + '>Paid Social Networks|fb_' + '>Android App|0000_and_' + '>iOS App|0000_ios_' + '>Grip App|grip_';
    /* Note that the (first) function parameter here sets the URL query parameter the s._channelPattern is matched on, in this case 'ext' */

    s.channelManager('ext');
    /* Fallback for when s._campaign isn't set */

    if (s._campaign == null || s._campaign === '') {
      if (s._campaignID != null && s._campaignID !== 'n/a' && s._campaignID !== '') {
        /* Use the value of 'ext' as s._campaign if the former is set and the latter isn't */
        s._campaign = s._campaignID;
      } else if (s._channel != null && s._channel === 'Natural Search' && s._searchEngine != null) {
        /* s._campaign should contain 'Natural Search: ' + s._searchEngine already, but in case it doesn't: */
        s._campaign = s._searchEngine;
      } else if (s._referrer != null && s._referrer === '' || b['dom.referrer'] === '') {
        /* If there's no referrer on the first hit of the visit, set to 'Typed/Bookmarked' */
        s._campaign = 'Typed/Bookmarked'; // TODO Shouldn't this also be already handled?
      } else {
        /* If the channel manager doesn't recognize the campaign, but it wasn't typed or bookmarked, set to 'Unknown' */
        s._campaign = 'Unknown';
      }
    }
    /* Fallback for when s._channel isn't set */


    if (s._channel == null || s._channel === '') {
      if (s._referrer != null && s._referrer === '' || b['dom.referrer'] === '') {
        /* If there's no referrer on the first hit of the visit, set to 'Typed/Bookmarked' */
        s._channel = 'Typed/Bookmarked';
      } else {
        /* If the channel manager doesn't recognize the channel, but it wasn't typed or bookmarked, set to 'Unknown' */
        s._channel = 'Unknown';
      }
    }
    /* Map the campaign-related variables to their respective Adobe variables */


    s.eVar82 = s._channel;
    s.campaign = s._campaign;
    /* 'Channel stacking' */

    if (s._channel === 'Typed/Bookmarked') {
      /* Store the last 10 channels in the s_eVar83 cookie for 30 days, not allowing duplicate neighbors (the '0' parameter) */
      s.eVar83 = s.crossVisitParticipation(s._channel, 's_eVar83', '30', '10', '>', '', 0);
    } else {
      /* Store the last 10 channels in the s_eVar83 cookie for 30 days, allowing duplicate neighbors (the '1' parameter) */
      s.eVar83 = s.crossVisitParticipation(s._channel, 's_eVar83', '30', '10', '>', '', 1);
    }
    /* 'Campaign stacking' */


    if (s._campaign === 'Typed/Bookmarked') {
      /* Store the last 10 campaigns in the s_eVar84 cookie for 30 days, not allowing duplicate neighbors (the '0' parameter) */
      s.eVar84 = s.crossVisitParticipation(s._campaign, 's_eVar84', '30', '10', '>', '', 0);
    } else {
      /* Store the last 10 campaigns in the s_eVar84 cookie for 30 days, allowing duplicate neighbors (the '1' parameter) */
      s.eVar84 = s.crossVisitParticipation(s._campaign, 's_eVar84', '30', '10', '>', '', 1);
    }
  }
  /* Map variables based on Adobe Analytics internals */


  s.eVar93 = s.version; // Adobe Analytics Code Version
}

window.tealium_s.usePlugins = true;
window.tealium_s.doPlugins = s_doPlugins;
} } catch(e){ utag.DB(e) }  }];

  u.send=function(a,b,c,d,e,f,g,h,ev){
    if(u.ev[a]||typeof u.ev.all!="undefined"){
      utag.DB("send:125");

      u.data = {

        "adobe_org_id" : "0861467352782C5E0A490D45",

        // set cookie domain explicitly (no need for cookieDomainPeriods and domain guessing)
        // http://rossscrivener.co.uk/blog/javascript-get-domain-exclude-subdomain
        "cookieDomain" : (function () {
          return utag.loader.RC ('utag_main').vapi_domain || (function () {
            var i = 0, d = document.domain, p = d.split ('.'), s = '_vapi' + new Date ().getTime ();
            while (i < (p.length -1) && document.cookie.indexOf (s + '=' + s) === -1) {
              d = p.slice (-1 -(++i)).join ('.');
              document.cookie = s + '=' + s + ';domain=' + d + ';';
            }
            document.cookie = s + '=;expires=Thu, 01 Jan 1970 00:00:01 GMT;domain=' + d + ';';
            utag.loader.SC ('utag_main', { 'vapi_domain' : d });
            return d;
          } ());
        } ()),

        "a" : {},
        "serial" : {},
        "linkName" : "",
        "linkType" : ""
      };

      //Map adobe_org_id - This can't be done inside the following callback because it is used to call the function itself.
      for (d in utag.loader.GV(u.map)) {
        if (b[d] !== undefined && b[d] !== "") {
          e = u.map[d].split(",");
          for (f = 0; f < e.length; f++) {
            if(e[f] === "adobe_org_id" || e[f] === "linkTrackVars" || e[f] === "linkTrackEvents" || e[f] === "linkType" || e[f] === "linkName"){
            u.data[e[f]] = b[d];
            } else if(e[f] === "combineLinkVar"){
              u.combineLinkVar = b[d];
            }
          }
        }
      }
      //Send every call to a queue so we can process the events after the visitor API call
      u.queue.push({"a":a,"b":b,"u.data":u.data});
      vAPI.getInstance(u.data.adobe_org_id, function(instance) {
        //Get data object back from the queue so we can process everything in order
        var data = u.queue.shift();
        a = data["a"];
        b = data["b"];
        u.data = data["u.data"];

        u.a=a;
        b.sc_events=b.sc_events||{};

        u.addEvent = function (v, n) {
          var t = [];
          if (v instanceof Array) {
            t = v.slice(0);
          } else if (typeof n !== "undefined") {
            t.push(v + "=" + n);
          } else {
            t.push(v);
          }
          for (var i = 0; i < t.length; i++) {
            b.sc_events[t[i]] = 1;
            u.pushlt(u.lte, t[i].indexOf("=") > -1 ? t[i].split('=')[0] : t[i].split(':')[0]);
          }
          return b.sc_events;
        };

        u.addProduct = function (v) {
          u.data.sc_addProd = "";
          if (v instanceof Array) {
            u.data.sc_addProd = v.join(',');
          } else {
            u.data.sc_addProd = v;
          }
        };

        if (u.a === "link") {
          u.ltflag = true;
          if (typeof u.data.linkTrackVars === "undefined" && typeof b.linkTrackVars === "undefined") { u.ltv = []; }
          if (u.combineLinkVar && typeof u.data.linkTrackVars !== "undefined") {
            u.typeCheck(u.data.linkTrackVars, "ltv");
          } else if (u.combineLinkVar && typeof b.linkTrackVars !== "undefined") {
            u.typeCheck(b.linkTrackVars, "ltv");
          }

          if (typeof u.data.linkTrackEvents === "undefined" && typeof b.linkTrackEvents === "undefined") { u.lte = []; }
          if (u.combineLinkVar && typeof u.data.linkTrackEvents !== "undefined") {
            u.typeCheck(u.data.linkTrackEvents, "lte");
          } else if (u.combineLinkVar && typeof b.linkTrackEvents !== "undefined") {
            u.typeCheck(b.linkTrackEvents, "lte");
          }
        }
        // Dynamically override using extensions
        u.data.tagdevicetype = "standard";
        u.data.detectserial = "yes";

        for(c=0;c<u.extend.length;c++){try{d=u.extend[c](a,b);if(d==false)return}catch(e){if(typeof utag_err!='undefined'){utag_err.push({e:'extension error:'+e,s:utag.cfg.path+'utag.'+id+'.js',l:c,t:'ex'})}}};

        // Demandbase
        try {
          if (window.sessionStorage) {
            var standardDimensions = sessionStorage.getItem('s_dmdbase') || '';
            var customDimensions1 = sessionStorage.getItem('s_dmdbase_custom1') || '';
            var customDimensions2 = sessionStorage.getItem('s_dmdbase_custom2') || '';
            var customDimensions3 = sessionStorage.getItem('s_dmdbase_custom3') || '';
            var customDimensions4 = sessionStorage.getItem('s_dmdbase_custom4') || '';

            u.o.contextData.s_dmdbase = standardDimensions;
            u.o.contextData.s_dmdbase_custom1 = customDimensions1;
            u.o.contextData.s_dmdbase_custom2 = customDimensions2;
            u.o.contextData.s_dmdbase_custom3 = customDimensions3;
            u.o.contextData.s_dmdbase_custom4 = customDimensions4;
          }
        }
        catch (e) {
          utag.DB('AppMeasurement Demandbase Error: ' + e.message);
        }

        // Mobile lifecycle var
        if (u.data.tagdevicetype === "mobile") {
          if (b.timestamp || b.timestamp_unix) {
            u.o.timestamp = b.timestamp || b.timestamp_unix;
          }
          u.data.a = {
            "AppID" : b.app_id || "",
            "CarrierName" : b.carrier || "",
            "DeviceName" : b.device || "",
            "HourOfDay" : b.lifecycle_hourofday_local || "",
            "DayOfWeek" : b.lifecycle_dayofweek_local || "",
            "OSVersion" : b.os_version || b.platform_version || "",
            "Resolution" : b.device_resolution || ""
          };
          if (b.lifecycle_type) {
            u.data.a.disable_wake_track = false;
            u.data.a.disable_sleep_track = false;
            u.data.a.DaysSinceFirstUse = b.lifecycle_dayssincelaunch || "";
            u.data.a.DaysSinceLastUpgrade = b.lifecycle_dayssinceupdate || "";
            u.data.a.DaysSinceLastUse = b.lifecycle_dayssincelastwake || "";
            u.data.a.Launches = b.lifecycle_launchcount || "";
            u.data.a.InstallDate =  b.lifecycle_firstlaunchdate_MMDDYYYY || "";
            u.data.a.UpgradeEvent = b.lifecycle_isfirstlaunchupdate || "";
            u.data.a.PrevSessionLength = b.lifecycle_priorsecondsawake || "";
          }
          if (b.lifecycle_isfirstlaunch) {
            u.data.a.InstallEvent = "InstallEvent";
          }
          if (b.lifecycle_diddetectcrash) {
            u.data.a.CrashEvent = "CrashEvent";
          }
          if (b.lifecycle_type === "launch") {
            u.data.a.LaunchEvent = "LaunchEvent";
          }
          if (b.lifecycle_isfirslaunchupdate) {
            u.data.a.UpgradeEvent = "UpgradeEvent";
          }
        }

        for (e in utag.loader.GV(u.map)) {
          if (u.data.tagdevicetype === "mobile") {
            if (typeof b[e] != "undefined" && typeof u.map[e] == "string" && u.map[e].indexOf("contextData.a.") > -1) {
              f = u.map[e].split(",");
              for (g = 0; g < f.length; g++) {
                if (f[g].indexOf("contextData.a.") === 0){
                  u.data.a[f[g].substring(14)] = b[e];
                }
              }
            }
          } else if (typeof b[e] != "undefined" && typeof u.map[e] == "string" && u.map[e].indexOf("SERIAL_") > -1) {
            f = u.map[e].split(",");
            for (g = 0; g < f.length; g++) {
              if (f[g].indexOf("SERIAL_") === 0){
                u.data.serial[f[g].substring(7)]=b[e];
              }
            }
          } else if (typeof b[e] != "undefined" && typeof u.map[e] == "string" && u.map[e].indexOf("PRODUCTS_") > -1) {
            f = u.map[e].split(",");
            for (g = 0; g < f.length; g++) {
              if(f[g].indexOf("PRODUCTS_id") || f[g].indexOf("PRODUCTS_category") || f[g].indexOf("PRODUCTS_quantity") || f[g].indexOf("PRODUCTS_price")){
                u.data[f[g].substring(9)]=b[e];
              }
            }
          }
        }

        //Check for disabled lifecycles

        if(u.data.a.disable_wake_track === true || u.data.a.disable_wake_track === "true") {
          if (b.lifecycle_type === "wake") {
            return false;
          }
        }
        if(u.data.a.disable_sleep_track === true || u.data.a.disable_sleep_track === "true") {
          if (b.lifecycle_type === "sleep") {
            return false;
          }
        }

        u.data.id = u.data.id || (typeof b._cprod != "undefined" ? b._cprod.slice(0) : []);
        u.data.category = u.data.category || (typeof b._ccat != "undefined" ? b._ccat.slice(0) : []);
        u.data.quantity = u.data.quantity || (typeof b._cquan != "undefined" ? b._cquan.slice(0) : []);
        u.data.price = u.data.price || (typeof b._cprice != "undefined" ? b._cprice.slice(0) : []);
        if(typeof u.data.id!="undefined"&&u.data.id!=""){
          c=[];d={};ev={};for(e in utag.loader.GV(u.map)){if(typeof b[e]!="undefined"&&typeof u.map[e]=="string"&&u.map[e].indexOf("PRODUCTS_")>-1){f=u.map[e].split(",");for( g=0;g<f.length;g++){
            var pv = f[g].substring(9);
            if(f[g].indexOf("PRODUCTS_evar")==0 || f[g].indexOf("PRODUCTS_eVar")==0){
              if (b[e] instanceof Array) {
                b.sc_prodevars = b.sc_prodevars || [];
                for (var i = 0; i < b[e].length; i++) {
                  var prodvars = {};
                  if(typeof b.sc_prodevars[i]!="undefined" && b.sc_prodevars[i]!=""){
                    b.sc_prodevars[i][pv]=b[e][i];
                  }else{
                    prodvars[pv]=b[e][i];
                    b.sc_prodevars.push(prodvars);
                  }
                }
              }else{
                d[pv] = (b[e]+"").split(",");
              }
            }else if(f[g].indexOf("PRODUCTS_event")==0){
              if(b[e] instanceof Array){
                b.sc_prodevents=b.sc_prodevents || [];
                for (var i = 0; i < b[e].length; i++) {
                  var prodevents = {};
                  if(typeof b.sc_prodevents[i]!="undefined" && b.sc_prodevents[i]!=""){
                    b.sc_prodevents[i][pv]=b[e][i];
                  }else{
                    prodevents[pv]=b[e][i];
                    b.sc_prodevents.push(prodevents);
                  }
                }
                u.addEvent(pv);
              }else if (b[e] !== ""){
                ev[pv]=b[e];
                u.addEvent(pv);
              }
            }
          }}}
          e="";for(f in utag.loader.GV(d)){for(g=0;g<d[f].length;g++){if(e!="")e+="|"+f+"="+d[f][g];else e=f+"="+d[f][g];}}
          h="";for(f in utag.loader.GV(ev)){if(h)h+="|"+f+"="+((isNaN(ev[f]))?"1":ev[f]);else h=f+"="+((isNaN(ev[f]))?"1":ev[f]);}
          b.sc_prodevents=b.sc_prodevents||[];
          b.sc_prodevars=b.sc_prodevars || [];
          for(d=0;d<u.data.id.length;d++){
            var h2=h;
            var h3=e;
            if(typeof b.sc_prodevents!="undefined"){
              for (f in b.sc_prodevents[d]) {
                if(typeof b.sc_prodevents[d][f]!="undefined"){
                  var l =b.sc_prodevents[d][f];
                  if(typeof l!="undefined" && l!="" && isNaN(l)==false){
                    if (h2){
                      h2 += "|" + f + '=' + l;
                    }else{
                      h2 = f + '=' + l;
                    }
                  }
                }
              }
            }
            if(typeof b.sc_prodevars!="undefined"){
              for (f in b.sc_prodevars[d]) {
                if(typeof b.sc_prodevars[d][f]!="undefined"){
                  var l =b.sc_prodevars[d][f];
                  if(typeof l!="undefined" && l!=""){
                    if (h3){
                      h3 += "|" + f + '=' + l;
                    }else{
                      h3 = f + '=' + l;
                    }
                  }
                }
              }
            }
            c.push((u.data.category[d]?u.data.category[d]:"")+";"+u.data.id[d]+";"+(u.data.quantity[d]?u.data.quantity[d]:"")+";"+(u.data.price[d]?((u.data.quantity[d]?parseInt(u.data.quantity[d]):1)*parseFloat(u.data.price[d])).toFixed(2):"")+";"+h2+";"+h3);
          }
          if (typeof u.data.sc_addProd !== "undefined" && u.data.sc_addProd) {
            c.push(u.data.sc_addProd);
          }
          u.o.products=c.join(",");
        } else {
          u.o.products = "";
        }

        // Mapping would be b.event_name ==> "prod:event3,click:event4"
        // Data layer variable b.event_name will contain "prod,click" and trigger both event3,event4
        // To serialize, this would be "prod:12345,click"
        var evt=/^event|prodView|scOpen|scAdd|scRemove|scView|scCheckout|purchase$/;
        for(c in utag.loader.GV(b)){
          if(b[c] !== ""){
            f=(""+b[c]).split(",");
            for(g=0;g<f.length;g++){
              h=f[g].split(":");
              d=[];
              if(u.data.detectserial === "no") {
                if(typeof u.map[c+":"+h.join(":")]!="undefined"){ //fix to check against whole string
                  d=u.map[c+":"+h.join(":")].split(",");
                }else if(typeof u.map[c]!="undefined"){
                  d=u.map[c].split(",");
                }
              } else {
                //h.length is determined by how many colons are found
                if(h.length>1){
                  var subTrigger = h[0];
                  //Subtrigger is a concatenation of all but the last index, which is a detected serialization
                  for(var i=1; i<h.length-1;i++) {
                    subTrigger += ":"+h[i];
                  }
                  // Redefine h with subTrigger and detected serialization
                  h[0] = subTrigger;
                  h[1] = h[h.length-1];
                }
                if(typeof u.map[c+":"+h[0]]!="undefined"){
                  d=u.map[c+":"+h[0]].split(",");
                }else if(typeof u.map[c]!="undefined"){
                  d=u.map[c].split(",");
                }
              }
              for(e=0;e<d.length;e++){if(d[e]!="events"&&evt.test(d[e])&&d[e].indexOf("SERIAL_")!==0){
                if(u.data.serial[d[e]] !== undefined && u.data.serial[d[e]] !== "" ) {
                  u.addEvent(d[e]+":"+u.data.serial[d[e]]);
                } else {
                  if(u.data.detectserial === "yes") {
                    u.addEvent(d[e]+(h.length>1?":"+h[1]:""));
                  } else {
                    u.addEvent(d[e]);
                  }
                }
              }}
            }
          }
        }
        //Placing mobile data in contextData
        for (var m in u.data.a) {
          u.o.contextData["a."+m] = u.data.a[m];
          u.pushlt(u.ltv, "contextData.a." + m);
        }

        for(c in utag.loader.GV(b)){if(typeof u.map[c]!="undefined"){d=u.map[c].split(",");for(e=0;e<d.length;e++){
          // map to VALUE_event51 for events = "event51=60"
          if(d[e].indexOf("VALUE_")==0){
            // If an event serialization was mapped for this event
            if(u.data.serial[d[e]] !== undefined && u.data.serial[d[e]] !== ""){
              u.addEvent( d[e].substring(6), b[c]+":"+u.data.serial[d[e]] );
            } else {
              u.addEvent(d[e].substring(6), b[c]);
            }
          }else if(d[e]=="doneAction"){
            b.doneAction=b[c];
            if(b.doneAction!="navigate"){
              b.doneAction=eval(b[c]);
            }
          }else if(d[e].indexOf("c.") == 0 || d[e].indexOf("contextData.") == 0){
            d[e]=d[e].replace("contextData.", "c.");
            if (!(d[e][2] === "a" && d[e][3] === ".")) {   // Exclude mobile vars
              u.o.contextData[d[e].substring(2)] = b[c];
              u.pushlt(u.ltv,"contextData."+d[e].substring(2))
            }
          } else {
            if(c=="sc_events" || c=="sc_prodevents" || c=="sc_prodevars"){
              utag.DB("Error:125: Mapping reserved object name " + c)
            }else{
              u.o[d[e]]=b[c];
            }
            // if linkTrackVars is mapped then turn off auto-generation of linkTrackVars
            if(d[e]=="s_account"){
              u.o.account=b[c];
            }else if(d[e]=="linkTrackVars"){
              u.ltflag=false;
            }else{
              if(u.combineLinkVar){u.ltflag=true;}
              if(d[e] !== "combineLinkVar"){
                u.pushlt(u.ltv,d[e]);
              }
            }
          }
        }}}
        d=[];for(c in utag.loader.GV(b.sc_events)){if(b.sc_events[c])d.push(c);}
        if(d.length>0){
          u.o.events=d.join(",");
          u.pushlt(u.lte,u.o.events);
        } else {
          u.o.events = "";
        }

        if(b._ccurrency){
          u.o.currencyCode=b._ccurrency;
        }

        if(b._corder){
          u.pushlt(u.lte,"purchase");
          u.pushlt(u.ltv,"purchaseID");
          u.o.purchaseID=((u.o.purchaseID)?u.o.purchaseID:b._corder);
          u.o.events=((u.o.events)?u.o.events:"purchase");
          if(u.o.events.indexOf("purchase")<0){u.o.events+=",purchase";}
        }

        //Use case: Visitor API set up in Tealium iQ, we will use this instance of the Visitor API
        if (instance) {
          u.o.visitor = instance;
        }

        //Use case: Visitor API not set up in Tealium iQ -
        //If a previously created instance of the Visitor API object is found on the page, that will be referenced.
        //Otherwise a new Visitor API object is instantiated.
        if (!u.o.visitor) {
          if(typeof visitor !== "undefined") {
            u.o.visitor = window.visitor;
          } else if (typeof Visitor !== "undefined" && typeof Visitor.getInstance !== "undefined") {
            u.o.visitor = Visitor.getInstance(u.data.adobe_org_id);
          }
        }

        // marketing cloud cookie domain should take precedence if exist
        u.o.cookieDomain = u.o.visitor ? u.o.visitor.cookieDomain || u.data.cookieDomain : u.data.cookieDomain;

        if (u.a === "view") {
          var img = u.o.t();
          /* still track on user agents Adobe cannot detect */
          if (typeof img !== "undefined" && img !== "") {
            u.img = new Image();
            u.img.src = img.substring(img.indexOf("src=")+5,img.indexOf("width=")-2);
          }
        } else if (u.a === "link") {
          if (typeof u.ltv !== "undefined" && u.ltflag) {
            if (u.o.events) {u.ltv.push("events");}
            if (u.o.products) {u.ltv.push("products");}
            b.linkTrackVars = u.ltv.join(",");
          }
          if (typeof u.lte !== "undefined" && u.ltflag) {b.linkTrackEvents = u.lte.join(",");}
          u.o.linkTrackVars = (b.linkTrackVars) ? b.linkTrackVars : "None";
          u.o.linkTrackEvents = (b.linkTrackEvents) ? b.linkTrackEvents : "None";

          /*
          in some implementations of AppMeasurement through Tealium iQ, values for linkName and linkType were provided directly in the data layer, e.g., through 
          the link tracking extension. This was done to minimize the number of mappings needed to set up AppMeasurement. To support these implementations the fallback checks 
          for b.link_text, b.link_name are included
          */
          
          //setting linkType: the values 'download link' and 'exit link' are set by the Link Tracking extension automatically; mappings supersede the setting of b.link_type
          if (!u.data.linkType) {
           if (b.link_type === "download link") {
             u.data.linkType = "d";
           } else if (b.link_type === "exit link") {
             u.data.linkType = "e";
           }
          }    
          
          // the fallback to u.o.linkType in this assignment is to handle static mappings to linkType as this template only runs static mappings when the vAPI.getInstance method is invoked, 
          // and not when u.send is invoked, as it is with most templates, defaulting to `o` if not otherwise set
          u.o.linkType = u.data.linkType || u.o.linkType || "o";

          //setting linkName: this fallback order is here to preserve the behavior of implementations referencing the data layer (b object) variables (link_name, link_text) directly
          u.data.linkName = u.data.linkName || b.link_name || b.link_text || "no link_name";

          u.o.tl(((b.link_obj) ? b.link_obj : true), u.o.linkType, u.data.linkName, null, (b.doneAction ? b.doneAction : null));
        }

        /* clear variables */
        if ("yes" === "yes") {
          u.o.clearVars();
          u.o.contextData = {};
        }

        utag.DB("send:125:COMPLETE");
      });
    }
  };
    try{utag.o[loader].loader.LOAD(id)}catch(e){utag.loader.LOAD(id)}
  })('125','abn-amro.retail');
}catch(e){
  utag.DB(e);
}
//end tealium universal tag
