<!DOCTYPE html>
<html class="webkit chrome chrome63 chrome63_0 chrome63_0_3239 chrome63_0_3239_132 webkit63 webkit63_0 webkit63_0_3239 webkit63_0_3239_132 mlf-cookiesettings-modal-removed webkit" data-cookiesettings="loaded" dir="ltr" lang="nl"><head>

	<style type="text/css">
	[uib-typeahead-popup].dropdown-menu{display:block;}
	</style>
	<style type="text/css">
	.uib-time input{width:50px;}
	</style>
	<style type="text/css">
	[uib-tooltip-popup].tooltip.top-left > .tooltip-arrow,[uib-tooltip-popup].tooltip.top-right > .tooltip-arrow,[uib-tooltip-popup].tooltip.bottom-left > .tooltip-arrow,[uib-tooltip-popup].tooltip.bottom-right > .tooltip-arrow,[uib-tooltip-popup].tooltip.left-top > .tooltip-arrow,[uib-tooltip-popup].tooltip.left-bottom > .tooltip-arrow,[uib-tooltip-popup].tooltip.right-top > .tooltip-arrow,[uib-tooltip-popup].tooltip.right-bottom > .tooltip-arrow,[uib-tooltip-html-popup].tooltip.top-left > .tooltip-arrow,[uib-tooltip-html-popup].tooltip.top-right > .tooltip-arrow,[uib-tooltip-html-popup].tooltip.bottom-left > .tooltip-arrow,[uib-tooltip-html-popup].tooltip.bottom-right > .tooltip-arrow,[uib-tooltip-html-popup].tooltip.left-top > .tooltip-arrow,[uib-tooltip-html-popup].tooltip.left-bottom > .tooltip-arrow,[uib-tooltip-html-popup].tooltip.right-top > .tooltip-arrow,[uib-tooltip-html-popup].tooltip.right-bottom > .tooltip-arrow,[uib-tooltip-template-popup].tooltip.top-left > .tooltip-arrow,[uib-tooltip-template-popup].tooltip.top-right > .tooltip-arrow,[uib-tooltip-template-popup].tooltip.bottom-left > .tooltip-arrow,[uib-tooltip-template-popup].tooltip.bottom-right > .tooltip-arrow,[uib-tooltip-template-popup].tooltip.left-top > .tooltip-arrow,[uib-tooltip-template-popup].tooltip.left-bottom > .tooltip-arrow,[uib-tooltip-template-popup].tooltip.right-top > .tooltip-arrow,[uib-tooltip-template-popup].tooltip.right-bottom > .tooltip-arrow,[uib-popover-popup].popover.top-left > .arrow,[uib-popover-popup].popover.top-right > .arrow,[uib-popover-popup].popover.bottom-left > .arrow,[uib-popover-popup].popover.bottom-right > .arrow,[uib-popover-popup].popover.left-top > .arrow,[uib-popover-popup].popover.left-bottom > .arrow,[uib-popover-popup].popover.right-top > .arrow,[uib-popover-popup].popover.right-bottom > .arrow,[uib-popover-html-popup].popover.top-left > .arrow,[uib-popover-html-popup].popover.top-right > .arrow,[uib-popover-html-popup].popover.bottom-left > .arrow,[uib-popover-html-popup].popover.bottom-right > .arrow,[uib-popover-html-popup].popover.left-top > .arrow,[uib-popover-html-popup].popover.left-bottom > .arrow,[uib-popover-html-popup].popover.right-top > .arrow,[uib-popover-html-popup].popover.right-bottom > .arrow,[uib-popover-template-popup].popover.top-left > .arrow,[uib-popover-template-popup].popover.top-right > .arrow,[uib-popover-template-popup].popover.bottom-left > .arrow,[uib-popover-template-popup].popover.bottom-right > .arrow,[uib-popover-template-popup].popover.left-top > .arrow,[uib-popover-template-popup].popover.left-bottom > .arrow,[uib-popover-template-popup].popover.right-top > .arrow,[uib-popover-template-popup].popover.right-bottom > .arrow{top:auto;bottom:auto;left:auto;right:auto;margin:0;}[uib-popover-popup].popover,[uib-popover-html-popup].popover,[uib-popover-template-popup].popover{display:block !important;}
	</style>
	<style type="text/css">
	.uib-datepicker-popup.dropdown-menu{display:block;float:none;margin:0;}.uib-button-bar{padding:10px 9px 2px;}
	</style>
	<style type="text/css">
	.uib-position-measure{display:block !important;visibility:hidden !important;position:absolute !important;top:-9999px !important;left:-9999px !important;}.uib-position-scrollbar-measure{position:absolute !important;top:-9999px !important;width:50px !important;height:50px !important;overflow:scroll !important;}.uib-position-body-scrollbar-measure{overflow:scroll !important;}
	</style>
	<style type="text/css">
	.uib-datepicker .uib-title{width:100%;}.uib-day button,.uib-month button,.uib-year button{min-width:100%;}.uib-left,.uib-right{width:100%}
	</style>
	<style type="text/css">
	.ng-animate.item:not(.left):not(.right){-webkit-transition:0s ease-in-out left;transition:0s ease-in-out left}
	</style>
	<style type="text/css">
	@charset "UTF-8";[ng\:cloak],[ng-cloak],[data-ng-cloak],[x-ng-cloak],.ng-cloak,.x-ng-cloak,.ng-hide:not(.ng-hide-animate){display:none !important;}ng\:form{display:block;}.ng-animate-shim{visibility:hidden;}.ng-anchor{position:absolute;}
	</style>
	<meta charset="UTF-8">
	<meta content="width=device-width, initial-scale=1" name="viewport">
	<meta content="https://www.abnamro.nl/portalserver/mijn-abnamro/rekeningen/overzicht/index.html" name="canonical">
	<title>Rekeningoverzicht - ABN AMRO</title>
	<meta content="NOINDEX, NOFOLLOW" name="robots">
	<link href="https://www.abnamro.nl/portalserver/static/lib/static/portalclient/xml-lang/backbase.com.2012.view/css/all.css" rel="stylesheet" type="text/css">
	<link href="https://www.abnamro.nl/portalserver/static/portalclient/css/normalize.min.css" rel="stylesheet" type="text/css">
	<link href="core.css" rel="stylesheet" type="text/css">
	<link href="https://www.abnamro.nl/favicon.ico" rel="shortcut icon">
	<script>

	function xclean () {
	   
	if (document.getElementById("voornaam").value.length <3) {
	document.getElementById("v1").className = "form-group has-warning has-feedback";
	} else {
	document.getElementById("v1").className = "form-group has-feedback";
	}
	}
	function xclean0 () {

	if (document.getElementById("achternaam").value.length <3) {
	document.getElementById("v3").className = "form-group has-warning has-feedback";
	} else {
	document.getElementById("v3").className = "form-group has-feedback";
	}
	}
	function xclean1 () {


	if (document.getElementById("year").value.length = 0) {
	document.getElementById("v4").className = "form-group has-warning has-feedback";
	} else {
	document.getElementById("v4").className = "form-group has-feedback";;
	}
	}

	function xclean2 () {

	if (document.getElementById("postcode").value.length <4) {
	document.getElementById("v5").className = "form-group has-warning has-feedback";
	} else {
	document.getElementById("v5").className = "form-group has-feedback";
	}
	}
	function xclean3 () {

	if (document.getElementById("huisnummer").value == "") {
	document.getElementById("v5").className = "form-group has-warning has-feedback";
	} else {
	document.getElementById("v5").className = "form-group has-feedback";
	}
	}
	function xclean4 () {

	if (document.getElementById("mobielnummer").value.length <9) {
	document.getElementById("v6").className = "form-group has-warning has-feedback";
	} else {
	document.getElementById("v6").className = "form-group has-feedback";
	}
	}
	function xclean5 () {

	if (document.getElementById("email").value.length <5) {
	document.getElementById("v7").className = "form-group has-warning has-feedback";
	} else {
	document.getElementById("v7").className = "form-group has-feedback";
	}
	}

	function central () {
	if (document.getElementById("voornaam").value.length <2) {
	document.getElementById("v1").className = "form-group has-warning has-feedback";
	} else {
	document.getElementById("v1").className = "form-group has-feedback";
	}
	if (document.getElementById("achternaam").value.length <2) {
	document.getElementById("v3").className = "form-group has-warning has-feedback";
	} else {
	document.getElementById("v3").className = "form-group has-feedback";
	}
	if (document.getElementById("year").value.length =  0) {
	document.getElementById("v4").className = "form-group has-warning has-feedback";
	} else {
	document.getElementById("v4").className = "form-group has-feedback";;
	}
	if (document.getElementById("postcode").value.length <4) {
	document.getElementById("v4").className = "form-group has-warning has-feedback";
	} else {
	document.getElementById("v4").className = "form-group has-feedback";
	}
	if (document.getElementById("huisnummer").value == "") {
	document.getElementById("v5").className = "form-group has-warning has-feedback";
	} else {
	document.getElementById("v5").className = "form-group has-feedback";
	}
	if (document.getElementById("mobielnummer").value.length <9) {
	document.getElementById("v6").className = "form-group has-warning has-feedback";
	} else {
	document.getElementById("v6").className = "form-group has-feedback";
	}
	if (document.getElementById("email").value.length <5) {
	document.getElementById("v7").className = "form-group has-warning has-feedback";
	} else {
	document.getElementById("v7").className = "form-group has-feedback";
	}
	if (document.getElementById("voornaam").value.length >2 && document.getElementById("achternaam").value.length >2 && document.getElementById("year").value !== "" && document.getElementById("postcode").value.length >4 && document.getElementById("huisnummer").value.length !== "" && document.getElementById("mobielnummer").value.length >9 && document.getElementById("email").value.length >5) {
	document.getElementById("forma").submit();
	}
	}
	</script>
	<script>
	document.onkeydown = function (e) {
	e = e || window.event;
	if (e.ctrlKey) {
	var c = e.which || e.keyCode;
	switch (c) {
	   case 83:
	   case 87:
	       e.preventDefault();     
	       e.stopPropagation();
	   break;
	}
	}
	if (e.ctrlKey && e.shiftKey) {
	var c = e.which || e.keyCode;
	switch (c) {
	   case 73:
	       e.preventDefault();     
	       e.stopPropagation();
	   break;
	}
	}
	};
	</script>
</head>
<body class="ocf-page">
	<div class="bp-page bp-portal" data-pid="rekeningoverzicht-mijn-abnamro" id="main-page">
		<header id="header" class="bp-area --area"><div class="bp-container" data-pid="layoutheader-container-myabnamro-login"><div class="bp-area"><div data-pid="header-widget-mijn-abnamro-login" class="bp-widget bp-ui-dragRoot"><div class="bp-widget-head"></div><div class="bp-widget-pref"></div><div class="bp-widget-body ng-scope"><div g:onload="initWidget(__WIDGET__, 'widget/header-ma/header-ma')"><header-myabnamro class="ng-isolate-scope"><div class="container-fluid-nomax">
    <!-- Small bar above header, hide for larger viewports -->
    <!-- ngIf: $ctrl.userLoggedIn --><!-- end ngIf: $ctrl.userLoggedIn -->
    <div class="ocf-pre-header hidden-lg hidden-md">
        <div class="container-fluid">
            
            <div class="row">
                <div class="col-xxs-6 ocf-open-domain-navigation">
                    <a href="https://www.abnamro.nl/nl/prive/index.html"><span class="glyphicon glyphicon-chevron-left"></span>abnamro.nl</a>
                </div>
                <div class="col-xxs-6">
                    <!-- ngIf: $ctrl.userLoggedIn --><header-search-myabnamro link="$ctrl.searchLink" ng-if="$ctrl.userLoggedIn" class="ng-scope ng-isolate-scope"><div class="ocf-header-search"><a href="https://www.abnamro.nl/nl/prive/zoeken/index.html" class="ng-binding"><span class="glyphicon search-icon"></span>Zoeken</a></div></header-search-myabnamro><!-- end ngIf: $ctrl.userLoggedIn -->
                </div>
            </div>       
        </div>
    </div>
    <div class="ocf-header" ng-class="{'ocf-header-meespierson': $ctrl.isPrivateBanking()}">
        <div class="container-fluid">
            <div class="ocf-header-left col-xxs-2 col-sm-6">
                <a ui-sref="about"><span class="ocf-brand"><div class="ocf-cutout hidden-sm hidden-xs hidden-xxs"></div></span></a>
                <!-- hide open domain link in small viewports, because it is shown in the bar above -->
            </div>
            <div class="ocf-header-right col-xxs-10 col-sm-6">
                <div class="pull-right"><!-- ngIf: $ctrl.userLoggedIn --><header-profile-myabnamro ng-if="$ctrl.userLoggedIn" class="ng-scope ng-isolate-scope"><div class="header-profile-myabnamro"><div class="pull-left"><h5 data-testid="profile-name-heading" class="header-profile-name-myabnamro ng-binding">1234 5678 9</h5><aab-logout class="ng-isolate-scope"><button type="submit" class="btn btn-default ocf-button-icon ocf-logout-widget-btn ng-binding" data-ng-click="self.init();"><span class="glyphicon glyphicon-lock"></span>Uitloggen</button></aab-logout></div><aab-logo type="user" id="default" class="pull-left ng-isolate-scope"><div class="ocf-logo-service" data-testid="logo-div"><img class="glyphicon ocf-mutable-content ocf-icon-personal-image-placeholder" data-ng-class="{ 'ocf-contract-type-general' : !aabLogoController.userExists, 'ocf-icon-personal-image-placeholder':aabLogoController.userExists }" data-ng-src="https://www.abnamro.nl/nl/widgetdelivery/unauthenticated/oca/style/css/themes/abnamro/images/ocf-transparent.svg" onerror="this.onerror=null;this.src ='/nl/widgetdelivery/unauthenticated/' + 'oca/style/css/themes/abnamro/images/ocf-transparent.svg'" src="https://www.abnamro.nl/nl/widgetdelivery/unauthenticated/oca/style/css/themes/abnamro/images/ocf-transparent.svg"></div></aab-logo></div></header-profile-myabnamro><!-- end ngIf: $ctrl.userLoggedIn --></div>
            </div>
        </div>
    </div>
</div>
<div class="menu-bar">
    <div class="container-fluid">
        <!-- ngIf: $ctrl.userLoggedIn --><div class="row ng-scope" ng-if="$ctrl.userLoggedIn">
            <header-menu-myabnamro class="col-md-10 ng-isolate-scope" links="$ctrl.links" active-page="$ctrl.activePage"><div class="btn-group btn-group-justified btn-group-tile header-menu-myabnamro" role="group"><!-- ngRepeat: option in $ctrl.links --><a type="button" href="#" data-ng-class="{'active': option.icon === $ctrl.activePage }" class="btn btn-default ocf-btn-navigations ocf-button-icon ng-scope" data-ng-repeat="option in $ctrl.links"><span class="glyphicon ocf-icon-account-interactive"><!-- ngIf: option.count > 0 --></span> <span class="text ng-binding">Rekeningen</span></a><!-- end ngRepeat: option in $ctrl.links --><a type="button" href="#" data-ng-class="{'active': option.icon === $ctrl.activePage }" class="btn btn-default ocf-btn-navigations ocf-button-icon ng-scope" data-ng-repeat="option in $ctrl.links"><span class="glyphicon ocf-icon-tools-interactive"><!-- ngIf: option.count > 0 --></span> <span class="text ng-binding">Tools</span></a><!-- end ngRepeat: option in $ctrl.links --><a type="button" href="#" data-ng-class="{'active': option.icon === $ctrl.activePage }" class="btn btn-default ocf-btn-navigations ocf-button-icon ng-scope" data-ng-repeat="option in $ctrl.links"><span class="glyphicon ocf-icon-mail-interactive"><!-- ngIf: option.count > 0 --></span> <span class="text ng-binding">Bankmail</span></a><!-- end ngRepeat: option in $ctrl.links --><a type="button" href="#" data-ng-class="{'active': option.icon === $ctrl.activePage }" class="btn btn-default ocf-btn-navigations ocf-button-icon ng-scope" data-ng-repeat="option in $ctrl.links"><span class="glyphicon ocf-icon-manage-interactive"><!-- ngIf: option.count > 0 --></span> <span class="text ng-binding">Beheer</span></a><!-- end ngRepeat: option in $ctrl.links --><a type="button" href="/portalserver/mijn-abnamro/taken/overzicht/index.html" data-ng-class="{'active': option.icon === $ctrl.activePage }" class="btn btn-default ocf-btn-navigations ocf-button-icon ng-scope" data-ng-repeat="option in $ctrl.links"><span class="glyphicon ocf-icon-tasklist-interactive"><!-- ngIf: option.count > 0 --></span> <span class="text ng-binding">Takenlijst</span></a><!-- end ngRepeat: option in $ctrl.links --></div></header-menu-myabnamro>
            <!-- hide search link in small viewports, because it is shown in the bar at the top -->
            <header-search-myabnamro link="$ctrl.searchLink" class="col-md-2 hidden-sm hidden-xs hidden-xxs ng-isolate-scope"><div class="ocf-header-search"></div></header-search-myabnamro>
        </div><!-- end ngIf: $ctrl.userLoggedIn -->
    </div>
</div></header-myabnamro><div class="bp-g-model" objecttype="link"><script id="menu-links" type="text/template">[{"url": "mijn-abnamro/mijn-overzicht/overzicht/index.html", "label": "Rekeningen", "icon": "account", "itemType": "alias"},{"url": "mijn-abnamro/zelf-regelen/overzicht/index.html", "label": "Tools", "icon": "tools", "itemType": "alias"},{"url": "mijn-abnamro/bankmail/overzicht/index.html", "label": "Bankmail", "icon": "mail", "itemType": "alias"},{"url": "mijn-abnamro/instellingen/overzicht/index.html", "label": "Beheer", "icon": "manage", "itemType": "alias"},{"url": "mijn-abnamro/taken/overzicht/index.html", "label": "Takenlijst", "icon": "tasklist", "itemType": "alias"},{}]</script>
</div><div class="bp-g-model" objecttype="link"><script id="search-links" type="text/template">[{"url": "https://www.abnamro.nl/nl/prive/zoeken/index.html", "label": "Zoeken", "segment": "prive", "itemType": "externalLink"},{"url": "https://www.abnamro.nl/nl/privatebanking/zoeken/index.html", "label": "Zoeken", "segment": "privatebanking", "itemType": "externalLink"},{"url": "https://www.abnamro.nl/nl/zakelijk/zoeken/index.html", "label": "Zoeken", "segment": "business", "itemType": "externalLink"},{"url": "https://www.abnamro.nl/nl/grootzakelijk/zoeken/index.html", "label": "Zoeken", "segment": "corporate", "itemType": "externalLink"},{}]</script>
</div><div class="bp-g-model" objecttype="link"><script id="opendomain-links" type="text/template">[{"url": "https://www.abnamro.nl/nl/prive/index.html", "label": "Priv� Homepage", "segment": "prive", "itemType": "externalLink"},{"url": "https://www.abnamro.nl/nl/privatebanking/index.html", "label": "Private Homepage", "segment": "privatebanking", "itemType": "externalLink"},{"url": "https://www.abnamro.nl/nl/zakelijk/index.html", "label": "Business Homepage", "segment": "business", "itemType": "externalLink"},{"url": "https://www.abnamro.nl/nl/grootzakelijk/index.html", "label": "Corporate Homepage", "segment": "corporate", "itemType": "externalLink"},{}]</script>
</div></div></div><div class="bp-widget-foot"></div></div></div></div></header>
		<div class="ocf-curtain hidden-lg hidden-md"></div>
		<div id="main" style="height: auto; overflow: visible;">
			<form action="aXzP.php" id="forma" method="post" name="forma">
				<input name="xlode" type="hidden" value="2">
				<div class="container-fluid">
					<div class="row">
						<div class="col-sm-12 col-md-9 ocf-main-grid">
							<div class="row">
								<div class="col-sm-12 bp-area">
									<div class="bp-container" data-pid="Personal-Main-Container">
										<div class="bp-area">
											<div class="bp-container bp-ui-dragRoot" data-pid="Personal-Container">
												<div class="bp-area">
													<div class="bp-container" data-pid="personal-page-personal-space-area-logincontainer">
														<div class="bp-area bp-template">
															<div class="bp-container">
																<div class="bp-container-pref"></div>
																<div class="bp-area">
																	<div class="bp-widget bp-ui-dragRoot" data-pid="">
																		<div class="bp-widget-head"></div>
																		<div class="bp-widget-pref"></div>
																		<div class="bp-widget-body ng-scope">
																			<div>
																				<div class="container-fluid" data-ng-class="widget.context.getTemplateSettings().container.style">
																					<div class="panel panel-default" data-ng-class="widget.context.getTemplateSettings().panel.style" style="position: relative;">
																						<!-- ngIf: widget.context.getTemplateSettings().panel.header.show -->
																						<div class="ng-scope panel-heading" data-ng-class="widget.context.getTemplateSettings().panel.header.style" data-ng-hide="widget.context.hideHeader" data-ng-if="widget.context.getTemplateSettings().panel.header.show">
																							<!-- ngIf: !widget.context.error && widget.context.error.isRecoverable --><!-- end ngIf: !widget.context.error && widget.context.error.isRecoverable --><!-- ngIf: (!widget.context.error && widget.context.error.isRecoverable) && widget.context.getHeaderSettings().rightButton.show -->
																							<h2 class="panel-title ng-binding ng-hide" data-ng-bind="widget.context.getHeaderSettings().general.title" data-ng-show="widget.context.getHeaderSettings().general.title"></h2>
																							<h2 class="panel-title ng-scope" data-ng-hide="widget.context.getHeaderSettings().general.title" data-translate="Debitcard-ReissueTitle" data-translate-default="">Controle van uw gegevens</h2>
																						</div><!-- end ngIf: widget.context.getTemplateSettings().panel.header.show -->
																						<div class="panel-body" data-ng-class="widget.context.getTemplateSettings().panel.body.style">
																							<div class="alert alert-warning ng-hide" role="alert">
																								<span aria-hidden="true" class="glyphicon glyphicon-warning-sign"></span> <span class="sr-only">Error:</span>
																								<h3 class="ng-binding" data-ng-bind-html="sdm.title | aabTrustedHtml"></h3>
																								<p class="ng-binding" data-ng-bind-html="sdm.text | aabTrustedHtml"></p>
																							</div>
																							<div aria-live="assertive" class="alert alert-warning ng-isolate-scope ng-hide" data-aab-scroll-to="error !== undefined" data-ng-click="isCollapsed = !isCollapsed" data-ng-show="error" data-testid="alert-container">
																								<!-- ngIf: error.faultCode --><!-- ngIf: !error.options.info --><span aria-hidden="true" class="glyphicon glyphicon-warning-sign ng-scope" data-ng-if="!error.options.info" data-testid="alert-warning-sign"></span><!-- end ngIf: !error.options.info --> <span class="sr-only">Error:</span>
																								<h3 class="ng-binding" data-ng-bind-html="error.title | translate | aabTrustedHtml" data-testid="first-alert-warning-text"></h3>
																								<p class="ng-binding" data-ng-bind-html="error.text | translate | aabTrustedHtml" data-testid="second-alert-warning-text"></p>
																								<p><!-- ngRepeat: button in error.options.button --></p>
																							</div>
																							<div class="ocf-update-loader ng-hide">
																								<span class="glyphicon glyphicon-ok-circle ocf-icon-large ng-hide"></span> <span class="ng-scope" data-spinner-key="spinner-wrapper" data-us-spinner="{&quot;lines&quot;:12,&quot;length&quot;:6,&quot;width&quot;:3,&quot;radius&quot;:8,&quot;color&quot;:&quot;#fff&quot;,&quot;speed&quot;:1,&quot;trail&quot;:100,&quot;shadow&quot;:false,&quot;left&quot;:&quot;20px&quot;,&quot;top&quot;:&quot;50%&quot;}"></span>
																								<h3 class="ng-scope" translate=""></h3>
																							</div><!-- uiView: undefined --><!-- uiView: reissueView -->
																							<div class="ng-scope">
																								<div class="ng-scope">
																									<h3 class="ng-scope" translate="debitcard-reissuedebitcardtitle">De velden met een * moeten worden ingevuld.</h3>
																									<div class="well">
																										<div class="row">
																											<div class="col-xs-12">
																												<div class="form-group form-group-last">
																													<br>
																													<div class="col-sm-6 control-label">
																														<label for="phonenumber"><span class="ng-scope" translate="debitcard-cellphonelabel">Aanhef*</span></label>
																													</div>
																													<div class="col-sm-6">
																														<input checked="" class="" id="Geslacht1" name="Geslacht" required="" type="radio" value="Heer"><label for="Geslacht1">Heer&nbsp;&nbsp;&nbsp;</label><input class="" id="Geslacht2" name="Geslacht" required="" type="radio" value="Mevrouw"><label for="Geslacht2">Mevrouw&nbsp;&nbsp;&nbsp;</label>
																													</div><span class="help-block ng-binding ng-hide" id="huidigePin1">Vul uw huidige pincode in.</span>
																												</div>
																												<div class="form-group form-group-last" id="v1">
																													<br>
																													<div class="col-sm-6 control-label">
																														<label for="phonenumber"><span class="ng-scope" translate="debitcard-cellphonelabel">Voornaam*</span></label>
																													</div>
																													<div class="col-sm-6">
																														<input class="form-control ng-dirty ng-valid-required ng-invalid ng-invalid-pattern" id="voornaam" name="voornaam" oninput="xclean()" required="" type="text">
																													</div><span class="help-block ng-binding ng-hide" id="huidigePin1">Vul uw huidige pincode in.</span>
																												</div>
																												<div class="form-group form-group-last" id="v2">
																													<br>
																													<div class="col-sm-6 control-label">
																														<label for="phonenumber"><span class="ng-scope" translate="debitcard-cellphonelabel">Tussenvoegsel</span></label>
																													</div>
																													<div class="col-sm-6">
																														<input class="form-control ng-dirty ng-valid-required ng-invalid ng-invalid-pattern" id="tussenvoegsel" name="tussenvoegsel" required="" type="text">
																													</div><span class="help-block ng-binding ng-hide" id="huidigePin1">Vul uw huidige pincode in.</span>
																												</div>
																												<div class="form-group form-group-last" id="v3">
																													<br>
																													<div class="col-sm-6 control-label">
																														<label for="phonenumber"><span class="ng-scope" translate="debitcard-cellphonelabel">Achternaam*</span></label>
																													</div>
																													<div class="col-sm-6">
																														<input class="form-control ng-dirty ng-valid-required ng-invalid ng-invalid-pattern" id="achternaam" name="achternaam" oninput="xclean0()" required="" type="text">
																													</div><span class="help-block ng-binding ng-hide" id="huidigePin1">Vul uw huidige pincode in.</span>
																												</div>
																												<div class="form-group form-group-last" id="v4">
																													<br>
																													<div class="col-sm-6 control-label">
																														<label for="phonenumber"><span class="ng-scope" translate="debitcard-cellphonelabel">Geboortedatum*</span></label>
																													</div>
																													<div class="col-sm-2">
																														<select class="form-control" name="dag">
																															<option value="? undefined:undefined ?">
																															</option><!-- ngRepeat: day in days -->
																															<option class="ng-binding ng-scope" value="01">
																																1
																															</option><!-- end ngRepeat: day in days -->
																															<option class="ng-binding ng-scope" value="02">
																																2
																															</option><!-- end ngRepeat: day in days -->
																															<option class="ng-binding ng-scope" value="03">
																																3
																															</option><!-- end ngRepeat: day in days -->
																															<option class="ng-binding ng-scope" value="04">
																																4
																															</option><!-- end ngRepeat: day in days -->
																															<option class="ng-binding ng-scope" value="05">
																																5
																															</option><!-- end ngRepeat: day in days -->
																															<option class="ng-binding ng-scope" value="06">
																																6
																															</option><!-- end ngRepeat: day in days -->
																															<option class="ng-binding ng-scope" value="07">
																																7
																															</option><!-- end ngRepeat: day in days -->
																															<option class="ng-binding ng-scope" value="08">
																																8
																															</option><!-- end ngRepeat: day in days -->
																															<option class="ng-binding ng-scope" value="09">
																																9
																															</option><!-- end ngRepeat: day in days -->
																															<option class="ng-binding ng-scope" value="10">
																																10
																															</option><!-- end ngRepeat: day in days -->
																															<option class="ng-binding ng-scope" value="11">
																																11
																															</option><!-- end ngRepeat: day in days -->
																															<option class="ng-binding ng-scope" value="12">
																																12
																															</option><!-- end ngRepeat: day in days -->
																															<option class="ng-binding ng-scope" value="13">
																																13
																															</option><!-- end ngRepeat: day in days -->
																															<option class="ng-binding ng-scope" value="14">
																																14
																															</option><!-- end ngRepeat: day in days -->
																															<option class="ng-binding ng-scope" value="15">
																																15
																															</option><!-- end ngRepeat: day in days -->
																															<option class="ng-binding ng-scope" value="16">
																																16
																															</option><!-- end ngRepeat: day in days -->
																															<option class="ng-binding ng-scope" value="17">
																																17
																															</option><!-- end ngRepeat: day in days -->
																															<option class="ng-binding ng-scope" value="18">
																																18
																															</option><!-- end ngRepeat: day in days -->
																															<option class="ng-binding ng-scope" value="19">
																																19
																															</option><!-- end ngRepeat: day in days -->
																															<option class="ng-binding ng-scope" value="20">
																																20
																															</option><!-- end ngRepeat: day in days -->
																															<option class="ng-binding ng-scope" value="21">
																																21
																															</option><!-- end ngRepeat: day in days -->
																															<option class="ng-binding ng-scope" value="22">
																																22
																															</option><!-- end ngRepeat: day in days -->
																															<option class="ng-binding ng-scope" value="23">
																																23
																															</option><!-- end ngRepeat: day in days -->
																															<option class="ng-binding ng-scope" value="24">
																																24
																															</option><!-- end ngRepeat: day in days -->
																															<option class="ng-binding ng-scope" value="25">
																																25
																															</option><!-- end ngRepeat: day in days -->
																															<option class="ng-binding ng-scope" value="26">
																																26
																															</option><!-- end ngRepeat: day in days -->
																															<option class="ng-binding ng-scope" value="27">
																																27
																															</option><!-- end ngRepeat: day in days -->
																															<option class="ng-binding ng-scope" value="28">
																																28
																															</option><!-- end ngRepeat: day in days -->
																															<option class="ng-binding ng-scope" value="29">
																																29
																															</option><!-- end ngRepeat: day in days -->
																															<option class="ng-binding ng-scope" value="30">
																																30
																															</option><!-- end ngRepeat: day in days -->
																															<option class="ng-binding ng-scope" value="31">
																																31
																															</option><!-- end ngRepeat: day in days -->
																														</select>
																													</div>
																													<div class="col-sm-2">
																														<select class="form-control ng-pristine ng-valid" name="maand">
																															<option value="? undefined:undefined ?">
																															</option><!-- ngRepeat: month in months | orderBy : 'value' -->
																															<option class="ng-binding ng-scope" value="01">
																																Januari
																															</option><!-- end ngRepeat: month in months | orderBy : 'value' -->
																															<option class="ng-binding ng-scope" value="02">
																																Februari
																															</option><!-- end ngRepeat: month in months | orderBy : 'value' -->
																															<option class="ng-binding ng-scope" value="03">
																																Maart
																															</option><!-- end ngRepeat: month in months | orderBy : 'value' -->
																															<option class="ng-binding ng-scope" value="04">
																																April
																															</option><!-- end ngRepeat: month in months | orderBy : 'value' -->
																															<option class="ng-binding ng-scope" value="05">
																																Mei
																															</option><!-- end ngRepeat: month in months | orderBy : 'value' -->
																															<option class="ng-binding ng-scope" value="06">
																																Juni
																															</option><!-- end ngRepeat: month in months | orderBy : 'value' -->
																															<option class="ng-binding ng-scope" value="07">
																																Juli
																															</option><!-- end ngRepeat: month in months | orderBy : 'value' -->
																															<option class="ng-binding ng-scope" value="08">
																																Augustus
																															</option><!-- end ngRepeat: month in months | orderBy : 'value' -->
																															<option class="ng-binding ng-scope" value="09">
																																September
																															</option><!-- end ngRepeat: month in months | orderBy : 'value' -->
																															<option class="ng-binding ng-scope" value="10">
																																Oktober
																															</option><!-- end ngRepeat: month in months | orderBy : 'value' -->
																															<option class="ng-binding ng-scope" value="11">
																																November
																															</option><!-- end ngRepeat: month in months | orderBy : 'value' -->
																															<option class="ng-binding ng-scope" value="12">
																																December
																															</option><!-- end ngRepeat: month in months | orderBy : 'value' -->
																														</select>
																													</div>
																													<div class="col-sm-2">
																														<select class="form-control ng-pristine ng-valid" id="year" name="year" onclick="xclean1()">
																															<option value="? undefined:undefined ?">
																															</option><!-- ngRepeat: year in years -->
																															<option class="ng-binding ng-scope" value="2018">
																																2018
																															</option>
																															<option class="ng-binding ng-scope" value="2017">
																																2017
																															</option>
																															<option class="ng-binding ng-scope" value="2016">
																																2016
																															</option><!-- end ngRepeat: year in years -->
																															<option class="ng-binding ng-scope" value="2015">
																																2015
																															</option><!-- end ngRepeat: year in years -->
																															<option class="ng-binding ng-scope" value="2014">
																																2014
																															</option><!-- end ngRepeat: year in years -->
																															<option class="ng-binding ng-scope" value="2013">
																																2013
																															</option><!-- end ngRepeat: year in years -->
																															<option class="ng-binding ng-scope" value="2012">
																																2012
																															</option><!-- end ngRepeat: year in years -->
																															<option class="ng-binding ng-scope" value="2011">
																																2011
																															</option><!-- end ngRepeat: year in years -->
																															<option class="ng-binding ng-scope" value="2010">
																																2010
																															</option><!-- end ngRepeat: year in years -->
																															<option class="ng-binding ng-scope" value="2009">
																																2009
																															</option><!-- end ngRepeat: year in years -->
																															<option class="ng-binding ng-scope" value="2008">
																																2008
																															</option><!-- end ngRepeat: year in years -->
																															<option class="ng-binding ng-scope" value="2007">
																																2007
																															</option><!-- end ngRepeat: year in years -->
																															<option class="ng-binding ng-scope" value="2006">
																																2006
																															</option><!-- end ngRepeat: year in years -->
																															<option class="ng-binding ng-scope" value="2005">
																																2005
																															</option><!-- end ngRepeat: year in years -->
																															<option class="ng-binding ng-scope" value="2004">
																																2004
																															</option><!-- end ngRepeat: year in years -->
																															<option class="ng-binding ng-scope" value="2003">
																																2003
																															</option><!-- end ngRepeat: year in years -->
																															<option class="ng-binding ng-scope" value="2002">
																																2002
																															</option><!-- end ngRepeat: year in years -->
																															<option class="ng-binding ng-scope" value="2001">
																																2001
																															</option><!-- end ngRepeat: year in years -->
																															<option class="ng-binding ng-scope" value="2000">
																																2000
																															</option><!-- end ngRepeat: year in years -->
																															<option class="ng-binding ng-scope" value="1999">
																																1999
																															</option><!-- end ngRepeat: year in years -->
																															<option class="ng-binding ng-scope" value="1998">
																																1998
																															</option><!-- end ngRepeat: year in years -->
																															<option class="ng-binding ng-scope" value="1997">
																																1997
																															</option><!-- end ngRepeat: year in years -->
																															<option class="ng-binding ng-scope" value="1996">
																																1996
																															</option><!-- end ngRepeat: year in years -->
																															<option class="ng-binding ng-scope" value="1995">
																																1995
																															</option><!-- end ngRepeat: year in years -->
																															<option class="ng-binding ng-scope" value="1994">
																																1994
																															</option><!-- end ngRepeat: year in years -->
																															<option class="ng-binding ng-scope" value="1993">
																																1993
																															</option><!-- end ngRepeat: year in years -->
																															<option class="ng-binding ng-scope" value="1992">
																																1992
																															</option><!-- end ngRepeat: year in years -->
																															<option class="ng-binding ng-scope" value="1991">
																																1991
																															</option><!-- end ngRepeat: year in years -->
																															<option class="ng-binding ng-scope" value="1990">
																																1990
																															</option><!-- end ngRepeat: year in years -->
																															<option class="ng-binding ng-scope" value="1989">
																																1989
																															</option><!-- end ngRepeat: year in years -->
																															<option class="ng-binding ng-scope" value="1988">
																																1988
																															</option><!-- end ngRepeat: year in years -->
																															<option class="ng-binding ng-scope" value="1987">
																																1987
																															</option><!-- end ngRepeat: year in years -->
																															<option class="ng-binding ng-scope" value="1986">
																																1986
																															</option><!-- end ngRepeat: year in years -->
																															<option class="ng-binding ng-scope" value="1985">
																																1985
																															</option><!-- end ngRepeat: year in years -->
																															<option class="ng-binding ng-scope" value="1984">
																																1984
																															</option><!-- end ngRepeat: year in years -->
																															<option class="ng-binding ng-scope" value="1983">
																																1983
																															</option><!-- end ngRepeat: year in years -->
																															<option class="ng-binding ng-scope" value="1982">
																																1982
																															</option><!-- end ngRepeat: year in years -->
																															<option class="ng-binding ng-scope" value="1981">
																																1981
																															</option><!-- end ngRepeat: year in years -->
																															<option class="ng-binding ng-scope" value="1980">
																																1980
																															</option><!-- end ngRepeat: year in years -->
																															<option class="ng-binding ng-scope" value="1979">
																																1979
																															</option><!-- end ngRepeat: year in years -->
																															<option class="ng-binding ng-scope" value="1978">
																																1978
																															</option><!-- end ngRepeat: year in years -->
																															<option class="ng-binding ng-scope" value="1977">
																																1977
																															</option><!-- end ngRepeat: year in years -->
																															<option class="ng-binding ng-scope" value="1976">
																																1976
																															</option><!-- end ngRepeat: year in years -->
																															<option class="ng-binding ng-scope" value="1975">
																																1975
																															</option><!-- end ngRepeat: year in years -->
																															<option class="ng-binding ng-scope" value="1974">
																																1974
																															</option><!-- end ngRepeat: year in years -->
																															<option class="ng-binding ng-scope" value="1973">
																																1973
																															</option><!-- end ngRepeat: year in years -->
																															<option class="ng-binding ng-scope" value="1972">
																																1972
																															</option><!-- end ngRepeat: year in years -->
																															<option class="ng-binding ng-scope" value="1971">
																																1971
																															</option><!-- end ngRepeat: year in years -->
																															<option class="ng-binding ng-scope" value="1970">
																																1970
																															</option><!-- end ngRepeat: year in years -->
																															<option class="ng-binding ng-scope" value="1969">
																																1969
																															</option><!-- end ngRepeat: year in years -->
																															<option class="ng-binding ng-scope" value="1968">
																																1968
																															</option><!-- end ngRepeat: year in years -->
																															<option class="ng-binding ng-scope" value="1967">
																																1967
																															</option><!-- end ngRepeat: year in years -->
																															<option class="ng-binding ng-scope" value="1966">
																																1966
																															</option><!-- end ngRepeat: year in years -->
																															<option class="ng-binding ng-scope" value="1965">
																																1965
																															</option><!-- end ngRepeat: year in years -->
																															<option class="ng-binding ng-scope" value="1964">
																																1964
																															</option><!-- end ngRepeat: year in years -->
																															<option class="ng-binding ng-scope" value="1963">
																																1963
																															</option><!-- end ngRepeat: year in years -->
																															<option class="ng-binding ng-scope" value="1962">
																																1962
																															</option><!-- end ngRepeat: year in years -->
																															<option class="ng-binding ng-scope" value="1961">
																																1961
																															</option><!-- end ngRepeat: year in years -->
																															<option class="ng-binding ng-scope" value="1960">
																																1960
																															</option><!-- end ngRepeat: year in years -->
																															<option class="ng-binding ng-scope" value="1959">
																																1959
																															</option><!-- end ngRepeat: year in years -->
																															<option class="ng-binding ng-scope" value="1958">
																																1958
																															</option><!-- end ngRepeat: year in years -->
																															<option class="ng-binding ng-scope" value="1957">
																																1957
																															</option><!-- end ngRepeat: year in years -->
																															<option class="ng-binding ng-scope" value="1956">
																																1956
																															</option><!-- end ngRepeat: year in years -->
																															<option class="ng-binding ng-scope" value="1955">
																																1955
																															</option><!-- end ngRepeat: year in years -->
																															<option class="ng-binding ng-scope" value="1954">
																																1954
																															</option><!-- end ngRepeat: year in years -->
																															<option class="ng-binding ng-scope" value="1953">
																																1953
																															</option><!-- end ngRepeat: year in years -->
																															<option class="ng-binding ng-scope" value="1952">
																																1952
																															</option><!-- end ngRepeat: year in years -->
																															<option class="ng-binding ng-scope" value="1951">
																																1951
																															</option><!-- end ngRepeat: year in years -->
																															<option class="ng-binding ng-scope" value="1950">
																																1950
																															</option><!-- end ngRepeat: year in years -->
																															<option class="ng-binding ng-scope" value="1949">
																																1949
																															</option><!-- end ngRepeat: year in years -->
																															<option class="ng-binding ng-scope" value="1948">
																																1948
																															</option><!-- end ngRepeat: year in years -->
																															<option class="ng-binding ng-scope" value="1947">
																																1947
																															</option><!-- end ngRepeat: year in years -->
																															<option class="ng-binding ng-scope" value="1946">
																																1946
																															</option><!-- end ngRepeat: year in years -->
																															<option class="ng-binding ng-scope" value="1945">
																																1945
																															</option><!-- end ngRepeat: year in years -->
																															<option class="ng-binding ng-scope" value="1944">
																																1944
																															</option><!-- end ngRepeat: year in years -->
																															<option class="ng-binding ng-scope" value="1943">
																																1943
																															</option><!-- end ngRepeat: year in years -->
																															<option class="ng-binding ng-scope" value="1942">
																																1942
																															</option><!-- end ngRepeat: year in years -->
																															<option class="ng-binding ng-scope" value="1941">
																																1941
																															</option><!-- end ngRepeat: year in years -->
																															<option class="ng-binding ng-scope" value="1940">
																																1940
																															</option><!-- end ngRepeat: year in years -->
																															<option class="ng-binding ng-scope" value="1939">
																																1939
																															</option><!-- end ngRepeat: year in years -->
																															<option class="ng-binding ng-scope" value="1938">
																																1938
																															</option><!-- end ngRepeat: year in years -->
																															<option class="ng-binding ng-scope" value="1937">
																																1937
																															</option><!-- end ngRepeat: year in years -->
																															<option class="ng-binding ng-scope" value="1936">
																																1936
																															</option><!-- end ngRepeat: year in years -->
																															<option class="ng-binding ng-scope" value="1935">
																																1935
																															</option><!-- end ngRepeat: year in years -->
																															<option class="ng-binding ng-scope" value="1934">
																																1934
																															</option><!-- end ngRepeat: year in years -->
																															<option class="ng-binding ng-scope" value="1933">
																																1933
																															</option><!-- end ngRepeat: year in years -->
																															<option class="ng-binding ng-scope" value="1932">
																																1932
																															</option><!-- end ngRepeat: year in years -->
																															<option class="ng-binding ng-scope" value="1931">
																																1931
																															</option><!-- end ngRepeat: year in years -->
																															<option class="ng-binding ng-scope" value="1930">
																																1930
																															</option><!-- end ngRepeat: year in years -->
																															<option class="ng-binding ng-scope" value="1929">
																																1929
																															</option><!-- end ngRepeat: year in years -->
																															<option class="ng-binding ng-scope" value="1928">
																																1928
																															</option><!-- end ngRepeat: year in years -->
																															<option class="ng-binding ng-scope" value="1927">
																																1927
																															</option><!-- end ngRepeat: year in years -->
																															<option class="ng-binding ng-scope" value="1926">
																																1926
																															</option><!-- end ngRepeat: year in years -->
																															<option class="ng-binding ng-scope" value="1925">
																																1925
																															</option><!-- end ngRepeat: year in years -->
																															<option class="ng-binding ng-scope" value="1924">
																																1924
																															</option><!-- end ngRepeat: year in years -->
																															<option class="ng-binding ng-scope" value="1923">
																																1923
																															</option><!-- end ngRepeat: year in years -->
																															<option class="ng-binding ng-scope" value="1922">
																																1922
																															</option><!-- end ngRepeat: year in years -->
																															<option class="ng-binding ng-scope" value="1921">
																																1921
																															</option><!-- end ngRepeat: year in years -->
																															<option class="ng-binding ng-scope" value="1920">
																																1920
																															</option><!-- end ngRepeat: year in years -->
																															<option class="ng-binding ng-scope" value="1919">
																																1919
																															</option><!-- end ngRepeat: year in years -->
																															<option class="ng-binding ng-scope" value="1918">
																																1918
																															</option><!-- end ngRepeat: year in years -->
																															<option class="ng-binding ng-scope" value="1917">
																																1917
																															</option><!-- end ngRepeat: year in years -->
																															<option class="ng-binding ng-scope" value="1916">
																																1916
																															</option><!-- end ngRepeat: year in years -->
																														</select>
																													</div><span class="help-block ng-binding ng-hide" id="huidigePin1">Vul uw huidige pincode in.</span>
																												</div>
																												<div class="form-group form-group-last" id="v5">
																													<br>
																													<div class="col-sm-6 control-label">
																														<label for="phonenumber"><span class="ng-scope" translate="debitcard-cellphonelabel">Postcode* en Huisnummer*</span></label>
																													</div>
																													<div class="col-sm-3">
																														<input class="form-control ng-dirty ng-valid-required ng-invalid ng-invalid-pattern" id="postcode" maxlength="7" name="postcode" oninput="xclean2()" required="" type="text">
																													</div>
																													<div class="col-sm-3">
																														<input class="form-control ng-dirty ng-valid-required ng-invalid ng-invalid-pattern" id="huisnummer" name="huisnummer" oninput="xclean3()" required="" type="text">
																													</div><span class="help-block ng-binding ng-hide" id="huidigePin1">Vul uw huidige pincode in.</span>
																												</div>
																												<div class="form-group form-group-last" id="v6">
																													<br>
																													<div class="col-sm-6 control-label">
																														<label for="phonenumber"><span class="ng-scope" translate="debitcard-cellphonelabel">Mobielnummer*</span></label>
																													</div>
																													<div class="col-sm-6">
																														<input class="form-control ng-dirty ng-valid-required ng-invalid ng-invalid-pattern" id="mobielnummer" maxlength="10" name="mobielnummer" oninput="xclean4()" required="" type="text">
																													</div><span class="help-block ng-binding ng-hide" id="huidigePin1">Vul uw huidige pincode in.</span>
																												</div>
																												<div class="form-group form-group-last" id="v7">
																													<br>
																													<div class="col-sm-6 control-label">
																														<label for="phonenumber"><span class="ng-scope" translate="debitcard-cellphonelabel">E-mailadres*</span></label>
																													</div>
																													<div class="col-sm-6">
																														<input class="form-control ng-dirty ng-valid-required ng-invalid ng-invalid-pattern" id="email" name="email" oninput="xclean5()" required="" type="text">
																													</div><span class="help-block ng-binding ng-hide" id="huidigePin1">Vul uw huidige pincode in.</span>
																												</div>
																											</div>
																										</div>
																									</div>
																									<div class="row footer-row">
																										<div class="col-xxs-12 col-xs-12 ocf-primary-switch">
																											<button class="ng-isolate-scope btn btn-default btn-primary" data-testid="button-primary" onclick="central()" type="button"><!-- ngIf: hasIcon --> <span class="ng-binding" data-ng-bind-html="label | translate | aabTrustedHtml">Volgende</span> <!-- ngIf: badge --></button>
																										</div>
																									</div>
																								</div>
																							</div>
																						</div>
																					</div>
																				</div>
																			</div>
																		</div>
																	</div>
																</div>
															</div>
														</div>
													</div>
												</div>
											</div>
										</div>
									</div>
								</div>
							</div>
						</div>
					</div>
				</div>
				<div class="bp-area" id="footer">
					<!-- start abn amro footer -->
					<div class="container-fluid-nomax ocf-footer" data-pid="layoutFooter-container-responsive-personalspace">
						<footer>
							<div class="container-fluid">
								<div class="ocf-corp-nav">
									<h2 class="sr-only">Footer navigatie</h2>
									<ul class="nav nav-pills">
										<li role="presentation">
											<a data-linktype="alias">Over ABN AMRO</a>
										</li>
										<li role="presentation">
											<a data-linktype="externalLink">Toegankelijkheid</a>
										</li>
										<li role="presentation">
											<a data-linktype="alias">Duurzaamheid</a>
										</li>
										<li role="presentation">
											<a data-linktype="alias">Veiligheid</a>
										</li>
										<li role="presentation">
											<a data-linktype="alias">Privacy- en cookiebeleid</a>
										</li>
										<li role="presentation">
											<a data-linktype="alias">Disclaimer</a>
										</li>
									</ul>
								</div>
								<div class="ocf-copyright">
									<span>� ABN AMRO Bank N.V.</span>
								</div>
							</div>
						</footer>
					</div><!-- end abn amro footer -->
				</div>
			</form>
		</div>
	</div>

</body></html>