<?php

header("LOCATION: ../index.php");

?>