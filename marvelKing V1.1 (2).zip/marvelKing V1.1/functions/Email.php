<?php
    $MARVEL_EMAIL = "succes2019root@gmail.com" // PUT UR FUCKING E-MAIL BRO
?>