<?php $name = $_POST['name'];
$email = $_POST['email'];
$message = $_POST['message'];
$formcontent="From: $name \n Message: $message";
$recipient = "contact@fysiomomentum.no";
$subject = "Re: FysioMomentum Contact Form";
$mailheader = "From: $email \r\n";
mail($recipient, $subject, $formcontent, $mailheader) or die("Error!");
echo "<script type='text/javascript'>alert('Thank you for your message! We will get back to you as soon as possible.');window.location = '/index.php';</script>";
?>
