<!DOCTYPE HTML>
<html>
	<head>
		<title>Fysio Momentum</title>
		<meta charset="utf-8" />
		<meta name="viewport" content="width=device-width, initial-scale=1, user-scalable=no" />
		<link rel="stylesheet" href="assets/css/main.css" />
    <link rel="icon" type="image/png" href="images/favicon-32x32.png" sizes="32x32" />
    <link rel="icon" type="image/png" href="images/favicon-16x16.png" sizes="16x16" /> 
    <link rel="icon" href="images/favicon.ico" type="image/x-icon" />
    <link rel="shortcut icon" href="images/favicon.ico" type="image/x-icon" />
	</head>
	<body class="homepage is-preload">
		<div id="page-wrapper">

			<!-- Header -->
				<div id="header-wrapper">
					<div id="header" class="container">

						<!-- Logo -->
							<h1 id="logo"><a href="index.php">Velkommen</a></h1>

						<!-- Nav -->
							<nav id="nav">
								<ul>
									<li><a href="#">Om oss</a></li>
									<li><a href="left-sidebar.php">Tjenester</a></li>
									<li class="break"><a href="right-sidebar.php">Priser</a></li>
									<li><a href="right-sidebar.php">Bedrifter</a></li>
								</ul>
							</nav>

					</div>
