			<!-- Footer -->
				<div id="footer-wrapper">
					<div id="footer" class="container">
						<header class="major">
							<h2>Kontakt</h2>
							<p>Feel free to send us an SMS if you have any questions or if you would like to make an appointment.<br> 
              You can also use the contact form below to send us a message.</p>
						</header>
						<div class="row">
							<section class="col-6 col-12-narrower">
								<form method="post" action="assets/contactform.php">
									<div class="row gtr-50">
										<div class="col-6 col-12-mobile">
											<input name="name" placeholder="Name" type="text" />
										</div>
										<div class="col-6 col-12-mobile">
											<input name="email" placeholder="Email" type="text" />
										</div>
										<div class="col-12">
											<textarea name="message" placeholder="Message"></textarea>
										</div>
										<div class="col-12">
											<ul class="actions">
												<li><input type="submit" value="Send Message" /></li>
												<li><input type="reset" value="Clear form" /></li>
											</ul>
										</div>
									</div>
								</form>
							</section>
							<section class="col-6 col-12-narrower">
								<div class="row gtr-0">
									<ul class="divided icons col-6 col-12-mobile">
										<li class="icon fa-facebook"><a href="https://www.facebook.com/Fysio-Momentum-711881789176718" target="_blank"><span class="extra">Facebook</span></a></li>
										<li class="icon fa-twitter"><a href="#" target="_blank"><span class="extra">Twitter</span></a></li>
									</ul>
									<ul class="divided icons col-6 col-12-mobile">
										<li class="icon fa-linkedin"><a href="#" target="_blank"><span class="extra">LinkedIn</span></a></li>
										<li class="icon fa-instagram"><a href="#" target="_blank"><span class="extra">Instagram</span></a></li>
									</ul>
								</div>
							</section>
						</div>
					</div>
					<div id="copyright" class="container">
						<ul class="menu">
							<li>&copy; Fysio Momentum. All rights reserved.</li><li><a href="disclaimer.php">Disclaimer</a></li><li>Design: <a href="http://esli.online" target="_blank">esli.online</a></li>
						</ul>
					</div>
				</div>

		</div>

		<!-- Scripts -->
			<script src="assets/js/jquery.min.js"></script>
			<script src="assets/js/jquery.dropotron.min.js"></script>
			<script src="assets/js/browser.min.js"></script>
			<script src="assets/js/breakpoints.min.js"></script>
			<script src="assets/js/util.js"></script>
			<script src="assets/js/main.js"></script>
			<script src="assets/js/scrollfunction.js"></script>

	</body>
</html>