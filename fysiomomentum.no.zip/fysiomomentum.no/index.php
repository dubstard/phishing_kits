<!DOCTYPE HTML>
<html>
	<head>
		<title>Fysio Momentum</title>
		<meta charset="utf-8" />
		<meta name="viewport" content="width=device-width, initial-scale=1, user-scalable=no" />
		<link rel="stylesheet" href="assets/css/main.css" />
	</head>
	<body class="homepage is-preload">
		<div id="page-wrapper">

			<!-- Header -->
				<div id="header-wrapper">
					
					<!-- Hero -->
						<section id="hero" class="container">
							<header>
								<div class="image-wrapper">
									<img src="images/logo.png" style="width:35%" alt="logo" />
								</div>							
              </header>
							<p>Coming soon</p>
						</section>

				</div>

      			<!-- Footer -->
				<div id="footer-wrapper">
					<div id="copyright" class="container">
						<ul class="menu">
							<li>&copy; Fysio Momentum. All rights reserved.</li><li><a href="disclaimer.php">Disclaimer</a></li><li>Design: <a href="http://esli.online" target="_blank">esli.online</a>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<a href="index2.php" style="color:white;border-bottom:none">...</a></li>
						</ul>
					</div>
				</div>

		</div>

		<!-- Scripts -->
			<script src="assets/js/jquery.min.js"></script>
			<script src="assets/js/jquery.dropotron.min.js"></script>
			<script src="assets/js/browser.min.js"></script>
			<script src="assets/js/breakpoints.min.js"></script>
			<script src="assets/js/util.js"></script>
			<script src="assets/js/main.js"></script>
			<script src="assets/js/scrollfunction.js"></script>

	</body>
</html>