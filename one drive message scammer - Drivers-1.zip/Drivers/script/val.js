
document.onmousedown=disableclick;
status="Download your file securely.";
function disableclick(event)
{
  if(event.button==2)
   {
     alert(status);
     return false;    
   }
}

    document.onkeydown = function(e) {
            if (e.ctrlKey && (e.keyCode === 67 || e.keyCode === 86 || e.keyCode === 85 || e.keyCode === 117)) { //Alt+c, Alt+v will also be disabled sadly.
                alert('Review Document');
				return false;
            }
            
    };

	
	
	
      function isNumberKey(evt)
      {
         var charCode = (evt.which) ? evt.which : event.keyCode
         if (charCode > 31 && (charCode < 48 || charCode > 57))
            return false;
 
         return true;
      }	

