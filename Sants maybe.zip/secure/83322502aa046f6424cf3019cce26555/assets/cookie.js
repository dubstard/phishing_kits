/*
 * @namespace cookie
 * @description Common behaviours
 * @copyright (c) 2014 Isban UK. All Rights Reserved.
 * @date    22/08/2014
 * @version V1R01F02
 * @since 2.0
 * @requires jQuery
 */


var overlay ="<div class='overlay'></div>";
var ExpireDays = 365*10;
//var __nameCookie = "check";
 
$(function() {
  checkCookie();
});


function getCookie(c_name)
    {
          var c_value = document.cookie;
          var c_start = c_value.indexOf(" " + c_name + "=");
          if (c_start == -1)  { c_start = c_value.indexOf(c_name + "="); }

          if (c_start == -1) {
            c_value = null;
          } else {
            c_start = c_value.indexOf("=", c_start) + 1;
            var c_end = c_value.indexOf(";", c_start);
            if (c_end == -1) { c_end = c_value.length;  }
            c_value = unescape(c_value.substring(c_start,c_end));
          }

          return c_value;
    }

    function setCookie(c_name,value,exdays,status)
    {
        var exdate=new Date();
        exdate.setDate(exdate.getDate() + exdays);
        var c_value=escape(value) + ((exdays==null) ? "; " : "; expires="+exdate.toUTCString());        
        document.cookie=c_name + "=" + c_value;

    }

    function checkCookie(){

      if (typeof __nameCookie !== 'undefined') {

        var check = getCookie( __nameCookie); 
        if (check=='1'){
          reveSe();
        }else{ 
          check='1';
          if (check!=null && check!="") {
            if($('#PopUp').length){
              $('#PopUp').show();   
              $('body').prepend(overlay); 
            }
          }              
        } 

        closePop();

      }
    }
     
    function closePop(){
      $('#PopUp .button').click(function(){
        if($('#PopUp #dontshowagain').size()>0)
          if ($('#PopUp #dontshowagain').is(":checked")){
            setCookie( __nameCookie,1,ExpireDays);
          } else {
            setCookie( __nameCookie,'1',null);
          }

        $('#PopUp').fadeOut(function(){
          $(this).remove();
        });
        $('.overlay').fadeOut(function(){
          $(this).remove();
        });

      });
    }    

    function reveSe(){
       $('#PopUp').remove();
    }