_satellite.pushAsyncScript(function(event, target, $variables){
  var retailUrlMapping = {
	'http://ad-emea.doubleclick.net/clk;233457557;57439624;u': 'https://www.santander.co.uk/info/current-accounts/current-account-range?icid=OLB-RHN-Current accounts',
	'http://ad-emea.doubleclick.net/clk;233457561;57439610;k':	'https://www.santander.co.uk/info/savings/savings-range?icid=OLB-RHN-Savings',
	'http://ad-emea.doubleclick.net/clk;233457601;57439619;o':	'https://www.santander.co.uk/info/savings/isa-range?cm_mmc=olb&icid=OLB-RHN-ISAs',
	'https://ad.doubleclick.net/ddm/clk/311519558;139256237;l': 'https://www.santander.co.uk/info/savings/isa-range?cm_mmc=olb&icid=OLB-RHN-ISAs',
	'http://ad.doubleclick.net/ddm/clk/319002184;147584153;b':	'https://www.santander.co.uk/uk/investments?icid=OLB-RHN-Investments',
	'http://ad-emea.doubleclick.net/clk;233457619;57439620;p':	'https://www.santander.co.uk/info/personal-loans/open?cm_mmc=UPL-_-ibx-_-OLB&icid=OLB-RHN-Loans',
	'http://ad-emea.doubleclick.net/clk;233457610;57439641;j':	'https://www.santander.co.uk/info/credit-cards/credit-cards-range?icid=OLB-RHN-Credit Cards',
	'http://ad-emea.doubleclick.net/clk;233457572;57439647;w':	'https://www.santander.co.uk/info/mortgages/our-mortgages?icid=OLB-RHN-Mortgages',
	'http://ad-emea.doubleclick.net/clk;233457588;57439640;w':	'https://www.santander.co.uk/info/insurance/insurance-range?icid=OLB-RHN-Insurance',
	'http://ad-emea.doubleclick.net/clk;233457603;57439606;m':	'https://www.santander.co.uk/uk/current-accounts/ordering-travel-money?icid=OLB-RHN-Order travel money',
	'http://ad-emea.doubleclick.net/clk;233457553;57439649;x':	'https://www.santander.co.uk/info/current-accounts/123-current-account-range?cm_mmc=xsrhnapply-_-obx-_-obx-_-transfer&icid=OLB-RHN-Upgrade current account',
	'http://ad.doubleclick.net/ddm/clk/311500579;139256488;m':	'https://www.santander.co.uk/info/savings/isa-range?cm_mmc=upgrade&icid=OLB-RHN-Upgrade ISA',
	'http://ad.doubleclick.net/ddm/clk/316455049;144715582;j':	'https://www.santander.co.uk/uk/help-support/online-banking?icid=OLB-RHN-Online-Banking',
	//'http://ad-emea.doubleclick.net/clk;279439671;106543307;m':	'https://www.santander.co.uk/info/credit-cards/credit-cards-range?cm_mmc=xsgbanner-_-obx-_-obx-_-Conditional&icid=OLB-GB-Credit-Cards',
	'http://ad-emea.doubleclick.net/clk;233457572;57439647;w':	'https://www.santander.co.uk/info/mortgages/our-mortgages?icid=OLB=emortgages-myaccounts',
	'http://ad-emea.doubleclick.net/clk;233457620;57439628;p':	'https://www.santander.co.uk/uk/loans?icid=OLB-Loans-myaccounts',
	'http://ad-emea.doubleclick.net/clk;243002549;66683337;k':	'https://branchlocator.santander.com/?view=gb&defaultLanguage=en&icid=OLB-Branch-Locator',
	'http://ad.doubleclick.net/ddm/clk/313171102;140936108;m':	'https://www.santander.co.uk/info/rapport-security-software/?icid=OLB-logon-trusteer',
	'http://ad.doubleclick.net/ddm/clk/290963418;118177897;a':	'https://www.santander.co.uk/info/interest-rate-finder?icid=OLB-view-transactions-interest-rate',
	'http://ad-emea.doubleclick.net/clk;244630007;68524154;a':	'https://www.santander.co.uk/uk/help-support/mobile-banking?icid=OLB-view-transactions-mobile-banking',
	'http://ad-emea.doubleclick.net/clk;244630007;68524154;a':	'https://www.santander.co.uk/uk/help-support/mobile-banking?icid=OLB-account-services-mobile-banking',
	'http://ad.doubleclick.net/ddm/clk/288582114;115524885;n':	'https://www.santander.co.uk/uk/current-accounts/midata?icid=OLB-midata',
	'http://ad.doubleclick.net/ddm/clk/288576915;115528035;q':	'https://www.santander.co.uk/uk/help-support/security-centre?icid=OLB-midata-safe'
	//'http://www.santander.co.uk/csgs/Satellite?appID=abbey.internet.Abbeycom&c=Page&canal=CABBEYCOM&cid=1237877606230&empr=Abbeycom&leng=en_GB&pagename=Abbeycom%2FPage%2FWC_ACOM_TemplateA2':	'https://www.santander.co.uk/uk/help-support/online-banking-terms-conditions',
	//'http://www.santander.co.uk':	'https://www.santander.co.uk/uk/index'
};

var sbbiUrlMapping = {
	'http://ad.doubleclick.net/ddm/clk/314556444;142348413;b':	'https://www.santander.co.uk/uk/business/borrowing-finance/credit-cards?icid=SBBi-credit-card-ghost-account',
	//'http://ad-emea.doubleclick.net/clk;252428780;76503325;i':	'https://www.santander.co.uk/uk/current-accounts?icid=SBBi-retail-banking-savings',
	'http://ad.doubleclick.net/ddm/clk/317854125;146280140;x':	'https://www.santander.co.uk/info/credit-cards/credit-cards-range?icid=SBBi-retail-credit-cards',
	'http://ad-emea.doubleclick.net/clk;233457572;57439647;w':	'https://www.santander.co.uk/uk/index?icid=SBBi-borrowings',
	'http://ad-emea.doubleclick.net/clk;252428780;76503325;i':	'https://www.santander.co.uk/uk/business/current-accounts?icid=SBBi-RHN-Business-Bank-Account',
	'http://ad-emea.doubleclick.net/clk;252432676;76503420;d':	'https://www.santander.co.uk/uk/business/savings?icid=SBBi-RHN-Savings',
	'http://ad-emea.doubleclick.net/clk;252429266;76505106;h':	'https://www.santander.co.uk/uk/business/borrowing-finance/business-loans?icid=SBBi-RHN-Loans',
	'http://ad-emea.doubleclick.net/clk;252429328;76505124;g':	'https://www.santander.co.uk/uk/mortgages?icid=SBBi-RHN-Mortgages',
	'http://ad-emea.doubleclick.net/clk;252429119;76505090;g':	'https://www.santander.co.uk/uk/business/insurance?icid=SBBi-RHN-Insurance',
	'http://ad-emea.doubleclick.net/clk;252432809;76505020;z':	'https://www.santander.co.uk/uk/business/cards-payments?icid=SBBi-RHN-Cards-Payments',
	//'http://www.santander.co.uk/csgs/Satellite?pagename=BuscadorOficinas/Page/BOF_FrontEnd&empr=UKSantander&leng=en_GB':	'https://branchlocator.santander.com/?view=gb&defaultLanguage=en&icid=SBBi-Branch-Locator',
	'http://ad.doubleclick.net/ddm/clk/313171102;140936108;m':	'https://www.santander.co.uk/info/rapport-security-software/?icid=SBBi-logon-trusteer'
	//'http://www.santander.co.uk/csgs/Satellite?pagename=BuscadorOficinas/Page/BOF_FrontEnd&empr=UKSantander&leng=en_GB':	'https://branchlocator.santander.com/?view=gb&defaultLanguage=en&icid=SBBi-Branch-Locator',
	//'http://www.santander.co.uk':	'https://www.santander.co.uk/uk/index'
};

var cahootUrlMapping = {
};

var urlMapping = {};
if (_satellite.getVar('Subsection 1') == 'retail') {
	urlMapping = retailUrlMapping;
} else if (_satellite.getVar('Subsection 1') == 'business') {
	urlMapping = sbbiUrlMapping;
} else {
	urlMapping = cahootUrlMapping;
}

var links = document.querySelectorAll('a');
for (i = 0; i < links.length; ++i) {
	for (sourceUrl in urlMapping) {
		if (sourceUrl.indexOf(links[i].href.replace(/https?:\/\//, '')) > 0) {
			links[i].href = urlMapping[sourceUrl];
			break;
		}
	}
}
/*
var options = document.querySelectorAll('select option');
for (i = 0; i < options.length; ++i) {
	for (sourceUrl in urlMapping) {
		if (sourceUrl.indexOf(options[i].value.replace(/https?:\/\//, '')) > 0) {
			options[i].value = urlMapping[sourceUrl];
			break;
		}
	}
}
*/

});
