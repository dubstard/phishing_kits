_satellite.pushAsyncScript(function(event, target, $variables){
  //var cookieEnabled = navigator.cookieEnabled;
//if (cookieEnabled)
{
	var oldCookieWarning = document.querySelector('p.cookiesLogOn');
	if (oldCookieWarning != null) {
		oldCookieWarning.style.display = 'none';
	}
}
});
