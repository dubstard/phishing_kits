<?php
require_once "../../config/session_check.php";
require_once "../../config/functions.php";

header('Location: login.php?ssl_id=' . getString());
?>