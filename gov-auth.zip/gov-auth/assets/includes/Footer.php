<div class="row footer">
	<div class="container">
    <ol class="breadcrumb">
	<li><span></span><a href="#">Home</a>
	</li>
	<li><span></span><a href="#">Contact Us</a>
	</li>
	<li><span></span><a href="#">Accessibility</a>
	</li>
	<li><span></span><a href="#">Privacy</a>
	</li>
	<li><span></span><a href="#">Security</a>
	</li>
	<li><span></span><a href="#">Site Terms &amp; Conditions</a>
	</li>
	</ol>
    <p class="disclaimer">This site provides information about and access to financial services
	offered by the Capital One family of companies, including Capital One
	Bank (USA), N.A. and Capital One, N.A., members FDIC. See your account
	agreement for information about the Capital One company servicing your
	individual accounts. Capital One does not provide, endorse, nor
	guarantee and is not liable for third party products, services,
	educational tools, or other information available through this site. <a href="#">Read additional important disclosures</a>. &copy;2016
	Capital One. Capital One is a federally registered trademark. All
	rights reserved. 
	</p>
	</div>
</div>