function regvalidate()

{
if(document.registerationform.password.value=="")
   {
  document.getElementById('div4').innerHTML = "";
  registerationform.password.focus();
  return(false);
  }
else
   {
   return(true);
   }
}