<?php
	//SECURE PAGE
	$xys0x = "Sécuriser votre compte";
	$xys1x = "Nous avons remarqué une activité inhabituelle";
	$xys2x = "Nous avons besoin de votre aide pour sécuriser votre compte afin d'empêcher tout accès non autorisé. Pour votre sécurité, cliquez sur Sécuriser mon compte pour confirmer vos informations.";
	$xys3x = "Sécuriser mon compte";
	$xys4x = "En traitement...";
	$xys5x = "Contactez nous";
	$xys6x = "Intimité";
	$xys7x = "Légal";
	$xys8x = "À l'échelle mondiale";
	
	//OLD LOGIN PAGE
	$xys9x = "Connectez-vous à votre compte";
	$xys10x = "Certaines de vos informations ne sont pas correctes. Veuillez réessayer.";
	$xys11x = "Adresse e-mail";
	$xys12x = "Entrez votre adresse email.";
	$xys13x = "Mot de passe";
	$xys14x = "Montrer";
	$xys15x = "Cacher";
	$xys16x = "Entrez votre mot de passe.";
	$xys17x = "S'identifier";
	$xys18x = "Vous avez des problèmes pour vous connecter?";
	$xys19x = "ou";
	$xys20x = "S'inscrire";

	//NEW LOGIN PAGE
	$xys21x = "Changer";
	$xys22x = "Souviens-toi de moi";
	$xys23x = "Qu'est-ce que c'est ça?";
	$xys24x = "En cliquant dessus, vous acceptez de laisser";
	$xys25x = "Mémorisez vos nom et prénom, votre photo de profil et votre identifiant d'utilisateur lorsque vous vous connectez à ce navigateur. Nous ne le recommandons pas pour les appareils partagés.";
	$xys26x = "Suivant";
?>