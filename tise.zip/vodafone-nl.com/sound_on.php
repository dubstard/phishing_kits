<?php

$id = '1';
$sobj['value'] = '1';
$q = db::prepUpdateQuery($sobj, "sound", "id", $id); //(Associative array, table name, record id
db::updateRecord($q);
