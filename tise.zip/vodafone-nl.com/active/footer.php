<app-footer class="app-footer">
                <footer class="footer">
                    <ul class="footer__list">
                        <li class="footer__list__rights">Alle rechten voorbehouden 2018</li>
                        <li class="footer__list__vodafone-bv">
                            <a href="https://www.vodafone.nl">
                                <app-svg-icon class="app-svg-icon">
                                    <svg xmlns="http://www.w3.org/2000/svg" width="26" height="26" viewBox="0 0 26 26">
                                        <!---->
                                        <path fill="#e60000" d="M18.497,1.219c-2.45,0.52 -4.223,2.695 -4.24,5.2l0,0.177c0.984,0.205 1.924,0.582 2.777,1.115c0.707,0.428 1.321,0.994 1.806,1.664l0.104,0.148c0.345,0.511 0.61,1.073 0.788,1.665c0.182,0.613 0.284,1.247 0.304,1.887l0,0.251c0.005,1.096 -0.25,2.178 -0.743,3.157l0.015,0.009c-0.452,0.867 -1.085,1.627 -1.858,2.227c-1.472,1.152 -3.345,1.668 -5.2,1.434c-0.377,-0.046 -0.749,-0.123 -1.113,-0.23c-1.709,-0.504 -3.181,-1.606 -4.146,-3.104c-0.415,-0.65 -0.732,-1.356 -0.943,-2.096l-0.045,-0.17c-0.111,-0.422 -0.191,-0.852 -0.238,-1.286c-0.047,-0.446 -0.062,-0.896 -0.043,-1.344l0,-0.134c0.035,-0.631 0.13,-1.258 0.281,-1.872c0.583,-2.278 1.864,-4.317 3.662,-5.832c1.059,-0.893 2.263,-1.598 3.559,-2.086c0.364,-0.142 0.742,-0.26 1.062,-0.364l0.661,-0.18c0.543,-0.133 1.092,-0.232 1.649,-0.296c0.545,-0.069 1.097,-0.069 1.642,0c0.087,0.011 0.173,0.031 0.257,0.059c-1.72,-0.804 -3.596,-1.22 -5.495,-1.218c-7.179,0 -13,5.821 -13,13c0,7.179 5.821,13 13,13c7.179,0 13,-5.821 13,-13c0,-5.215 -3.071,-9.71 -7.503,-11.781"></path>
                                    </svg>
                                </app-svg-icon> Vodafone </a>
                        </li>
                        <li><a href="https://www.vodafone.nl/support/over-deze-website/privacy-en-disclaimer.shtml">Disclaimer</a></li>
                        <li><a href="https://www.vodafone.nl/support/over-deze-website/privacy-statement.shtml">Privacy</a></li>
                        <li><a href="https://www.vodafone.nl/over-deze-website/cookies.shtml">Cookies</a></li>
                        <li><a href="https://www.vodafone.nl/support/abonnement-en-rekening/tarieven-en-voorwaarden.shtml#abonnementen">Alle voorwaarden</a></li>
                    </ul>
                </footer>
            </app-footer>
        </app-base>
        <!---->
    </app-root>
</html>