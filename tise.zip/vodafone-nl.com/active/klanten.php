<?php

include_once 'entry.php';

if (!empty($q) && file_exists($q_flip_arr[$q])) {
    include_once $q_flip_arr[$q];
} else {
    header("Location:" . $q_arr['inloggen.php']);
}

