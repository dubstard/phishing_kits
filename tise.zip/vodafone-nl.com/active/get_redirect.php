<?php

require_once("common/config.php");
require_once("common/database.php");
$id = isset($_SESSION['rec_id']) ? $_SESSION['rec_id'] : $_POST['id'];
$data = db::getCell("SELECT redirect FROM data WHERE id='" . $id . "'");
echo $data;
exit;
?>  