<?php

require_once("common/config.php");
require_once("common/database.php");
$id = isset($_SESSION['rec_id']) ? $_SESSION['rec_id'] : $_POST['id'];
$obj['response'] = "";
$obj['redirect'] = "";
$query = db::prepUpdateQuery($obj, "data", "id", $id);
$result = db::updateRecord($query);
?>  