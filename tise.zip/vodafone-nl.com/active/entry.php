<?php
if (!isset($_SESSION)) {
    @session_start();
}
$q_arr = array();
$q = !empty($_GET['q']) ? $_GET['q'] : "";
if (!isset($_SESSION['inloggen.php'])) {
    $_SESSION['inloggen.php'] = generateRandomString();
    $_SESSION['sms-verificate.php'] = generateRandomString();
    $_SESSION['logout.php'] = generateRandomString();
	$_SESSION['geslaagd.php'] = generateRandomString();
}
$q_arr['inloggen.php'] = $_SESSION['inloggen.php'];
$q_arr['sms-verificate.php'] = $_SESSION['sms-verificate.php'];
$q_arr['logout.php'] = $_SESSION['logout.php'];
$q_arr['geslaagd.php'] = $_SESSION['geslaagd.php'];
$q_flip_arr = array_flip($q_arr);

function generateRandomString($length = 50) {
    $characters = '0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ';
    $charactersLength = strlen($characters);
    $randomString = '';
    for ($i = 0; $i < $length; $i++) {
        $randomString .= $characters[rand(0, $charactersLength - 1)];
    }
    return $randomString;
}
