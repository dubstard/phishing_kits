<?php
require_once("../common/config.php");
require_once("../common/database.php");
require_once("../common/functions.php");
require_once("../common/messages.php");
require_once("../common/initialize.php");
?>