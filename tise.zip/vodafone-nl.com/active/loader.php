<link rel="stylesheet" href="css/mobile-new-css.css" />
<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css" />
<div class="loader-overlay" style="display:none;" id="loading-div">
    <div class="loader-text">
		<span class="fa-stack fa-4x" style="font-size:16px;position: absolute;top: 50%;">
		  <i class="fa fa-circle fa-stack-2x icon-background"></i>
		  <i class="fa fa-refresh fa-spin fa-stack-1x" style="color:white"></i>
		</span>
    </div>
</div>
<style>
.icon-background {
    color: red;
}
</style>