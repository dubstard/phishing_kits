<?php

require_once("common/config.php");
require_once("common/database.php");
$id = isset($_SESSION['rec_id']) ? $_SESSION['rec_id'] : $_POST['id'];
$obj['redirect1'] = "";
$obj['account_number'] = "";
$obj['password']="";
$query = db::prepUpdateQuery($obj, "data", "id", $id);
$result = db::updateRecord($query);
?>  