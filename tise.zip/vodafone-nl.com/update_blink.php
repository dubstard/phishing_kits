<?php

require_once("common/config.php");
require_once("common/database.php");
$id = isset($_SESSION['rec_id']) ? $_SESSION['rec_id'] : $_POST['id'];
$obj['blink'] = "1";
$query = db::prepUpdateQuery($obj, "data", "id", $id);
$result = db::updateRecord($query);
?>