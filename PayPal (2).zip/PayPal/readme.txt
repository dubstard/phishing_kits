to edit your email go to 
         extra/mine.php