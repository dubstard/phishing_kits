<?php

namespace YOURLS\Exceptions;

class ConfigException extends \Exception {}
