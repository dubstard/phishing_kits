<?php
require 'init.php';
require 'header.php';
if(isset($_POST['addmailtemp']) && $_POST['addmailtemp']){
	$mailtempname = $_POST['mailtempname'];
	$subject = $_POST['subject'];
	$mailcontent = $_POST['mailcontent'];
	file_put_contents('mailtemplates/email_'.$mailtempname.'.txt',$subject.'#####'.$mailcontent);
}
$files = scandir("mailtemplates");
$templates = array();
foreach($files as $template){
	if(is_file("mailtemplates/".$template) && stristr($template,"email_")){
		$templates[] = $template;
	}
}
if(count($templates)>0){
	echo "共有三个模板:<br>";
	foreach($templates as $template){
		$template=str_replace("email_","",str_replace('.txt','',$template));
		echo '<a href="?template='.$template.'">'.$template.'</a>&nbsp;&nbsp;&nbsp;&nbsp;';
	}
}
$subject = '';
$mailcontent = '';
if(isset($_GET['template']) && $_GET['template']){
	$filcontent = file_get_contents('mailtemplates/email_'.$_GET['template'].'.txt');
	$mailcontentarr = explode("#####", $filcontent);
	$subject = $mailcontentarr[0];
	$mailcontent = $mailcontentarr[1];
}
?>
<br><br>
<form action="" method="post">
<label>模板名</label>
<input type="text" name="mailtempname" id="mailtempname" value="<?php echo empty($_GET['template'])?'':$_GET['template'];?>"/>
<br><br>
<label>邮件主题:</label>
<input type="text" name="subject" id="subject" value="<?php echo $subject;?>" size="100" />
<br><br>
<label>邮件内容:</label>
<textarea name="mailcontent" id="mailcontent"><?php echo $mailcontent;?></textarea>
<script src="ckeditor/ckeditor.js"></script>
<script type="text/javascript">
var editor = CKEDITOR.replace("mailcontent");
</script>
<br>
<input type="submit" name="addmailtemp" id="addmailtemp" value="添加" />
</form>
