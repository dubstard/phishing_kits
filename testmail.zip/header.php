


<?php
/*
 * Created on 2020-1-31
 *
 * To change the template for this generated file go to
 * Window - Preferences - PHPeclipse - PHP - Code Templates
 */
?>
<div id="nav">
<a href="send.php">发送邮件</a>&nbsp;&nbsp;|&nbsp;&nbsp;<a href="add_template.php">邮件模板</a>|&nbsp;&nbsp;<a href="emailaccounts.php">邮箱管理</a>
</div>
<hr>