<?php
require 'init.php';
require "header.php";
//header("Content-type:text/html; charset=utf-8");

function sendmail($mailaddress, $subject, $mailcontents, $mailtemplate=''){
	set_time_limit(0);  //在有关数据库的大量数据的时候，可以将其设置为0，表示无限制。
	ob_end_clean();     //在循环输出前，要关闭输出缓冲区
	// 引入PHPMailer的核心文件
	require_once("classes/class.phpmailer.php");
	require_once("classes/class.smtp.php");

	// 实例化PHPMailer核心类
	$mail = new PHPMailer();
	// 是否启用smtp的debug进行调试 开发环境建议开启 生产环境注释掉即可 默认关闭debug调试模式
	$mail->SMTPDebug = 0;
	// 使用smtp鉴权方式发送邮件
	$mail->isSMTP();
	// smtp需要鉴权 这个必须是true
	$mail->SMTPAuth = true;
	// 链接qq域名邮箱的服务器地址
	//$mail->Host = 'mail.udkk.com';
	$mail->Host = 'mail.udkk.com';
	// 设置使用ssl加密方式登录鉴权
	//$mail->SMTPSecure = 'ssl';

	$mail->SMTPAutoTLS = false;
	$mail->SMTPSecure = false;
	// 设置ssl连接smtp服务器的远程服务器端口号
	$mail->Port = 25;
	// 设置发送的邮件的编码
	$mail->CharSet = 'UTF-8';
	// 设置发件人昵称 显示在收件人邮件的发件人邮箱地址前的发件人姓名
	$mail->FromName = 'admin@udkk.com';
	// smtp登录的账号 QQ邮箱即可
	$mail->Username = 'admin@udkk.com';
	// smtp登录的密码 使用生成的授权码
	$mail->Password = 'jifang+15';
	// 设置发件人邮箱地址 同登录账号
	$mail->From = 'admin@udkk.com';
	// 邮件正文是否为html编码 注意此处是一个方法
	$mail->isHTML(true);
	// 设置收件人邮箱地址
	$mail->addAddress($mailaddress);
	// 添加多个收件人 则多次调用方法即可
	//$mail->addAddress('87654321@163.com');
	// 添加该邮件的主题
	$mail->Subject = $subject;
	// 添加邮件正文
	$mail->Body = $mailcontents;
	//如果邮件客户端不支持HTML则显示此内容
	$mail->AltBody = $subject;
	// 为该邮件添加附件
	//$mail->addAttachment('./example.pdf');
	// 发送邮件 返回状态
	//$fromemail = 'admin@udkk.com';

	if($mail->send()){
		echo $mailaddress.' sent '.$mailtemplate.' successfully'."<br>";
		/*$maincontentsql = "select * from emailcontent where subject = '".trim($subject)."' and emailbody='".$mailcontents."'";
		$maincontentquery = mysql_query($maincontentsql);
		if(mysql_num_rows($maincontentquery)>0){
			$emailcontentinfo = mysql_fetch_row($maincontentquery);
			$emailcontentid = $emailcontentinfo['id'];
		}else{
			$addcontentsql = "insert into emailcontent (subject, emailbody) values ('".trim($subject)."', '".trim($mailcontents)."')";
			mysql_query($addcontentsql);
			$emailcontentid = mysql_insert_id();
		}
		$addsql= "insert into sendrecord (femail, toemail, emailcontentid, sentdate, status) values ('".$fromemail."', '".$mailaddress."', ".$emailcontentid.", now(),1)";
		mysql_query($addcontentsql);*/
	}else{
		echo $mailaddress.' fail';
		/*$maincontentsql = "select * from emailcontent where subject = '".trim($subject)."' and emailbody='".$mailcontents."'";
		$maincontentquery = mysql_query($maincontentsql);
		if(mysql_num_rows($maincontentquery)>0){
			$emailcontentinfo = mysql_fetch_row($maincontentquery);
			$emailcontentid = $emailcontentinfo['id'];
		}else{
			$addcontentsql = "insert into emailcontent (subject, emailbody) values ('".trim($subject)."', '".trim($mailcontents)."')";
			mysql_query($addcontentsql);
			$emailcontentid = mysql_insert_id();
		}
		$addsql= "insert into sendrecord (femail, toemail, emailcontentid, sentdate, status) values ('".$fromemail."', '".$mailaddress."', ".$emailcontentid.", now(),0)";
		mysql_query($addcontentsql);*/
	}
}

//$mailist = array("526099409@qq.com", "787838875@qq.com", "longdrake88@gmail.com");
if(isset($_POST["sendbtn"]) && $_POST["sendbtn"]){
	//获取到临时文件
	$emailsfile = $_FILES["file"];
	//获取文件名
	$emailsfilename = $emailsfile["name"];
	//移动文件到当前目录
	move_uploaded_file($emailsfile['tmp_name'], 'upload/'.$emailsfilename);
	$mailfile = file_get_contents('upload/'.$emailsfilename);
	$mailist = explode("\n",trim($mailfile));

	$subject = $_POST['subject'];
	$mailcontent = $_POST['mailcontent'];
	$mailtemplate = $_POST['mailtemplate'];
	$mailist = explode("\n",trim($mailfile));
	foreach($mailist as $mailinfos){
		$mailinfo = explode(",", $mailinfos);
		if(count($mailinfo)>2){

			$mailaddress = $mailinfo[0];
			$toname = $mailinfo[1];
			$site = $mailinfo[2];
			$orderid = $mailinfo[3];
			$selectemail = "select * from `emailto` where toemail='".trim($mailaddress)."'";
			if(mysql_num_rows(mysql_query($selectemail))<1){
				$addtoemail = "insert into `emailto` (toemail, adddate) values ('".trim($mailaddress)."', now())";
				mysql_query($addtoemail);
			}
			$subject = 'Re: Urgent! Your Order Failed/Unpaid! ID: ' . $orderid;
			$mailcontent = file_get_contents("classes/emailfailed.txt");
			$mailcontent = str_replace("{{customername}}",$toname,$mailcontent);
			$mailcontent = str_replace("{{domain}}",$site,$mailcontent);
			$mailcontent = str_replace("{{orderid}}",$orderid,$mailcontent);
		}else{
			$mailaddress = $mailinfo[0];
			$subject = str_replace("{{CUSTOMERS_NAME}}",$mailinfo[1],$subject);
			$mailcontent = str_replace("{{CUSTOMERS_NAME}}",$mailinfo[1],$mailcontent);
		}

		//echo $mailinfo[1]."<br>";
		sendmail($mailaddress, $subject, $mailcontent,$mailtemplate, '');
	}
}
?>
<script src="ckeditor/ckeditor.js"></script>
<script type="text/javascript">
	function gettemplate(){
		tfile = document.getElementById("mailtemplate").value;
		if(tfile==""){
			document.getElementById("subject").value = "";
			editor.setData("");
		}else{
			let text = load("mailtemplates\\"+tfile);
			var contents= new Array(); //定义一数组
			contents = text.split("#####");
			document.getElementById("subject").value = contents[0];
			editor.setData(contents[1]);
		}

	}

	function load(name) {

	    let xhr = new XMLHttpRequest(),
	        okStatus = document.location.protocol === "file:" ? 0 : 200;
	    xhr.open('GET', name, false);
	    xhr.overrideMimeType("text/html;charset=utf-8");//默认为utf-8
	    xhr.send(null);
	    return xhr.status === okStatus ? xhr.responseText : null;
	}
</script>
<form method="post" enctype="multipart/form-data">
<label>导入邮件列表</label><input type="file" name="file" id="name"><br><br>
<label>邮件模板</label>
<?php
	$files = scandir("mailtemplates");
	$templates = array();
	foreach($files as $template){
		if(is_file("mailtemplates/".$template) && stristr($template,"email_")){
			$templates[] = $template;
		}
	}
	//print_r($templates);
?>
<select name="mailtemplate" id="mailtemplate" onchange="gettemplate()">
<option value="">请选择模板</option>
	<?php
		foreach($templates as $template){
			echo '<option value="'.$template.'">'.str_replace('email_','',$template).'</option>';
		}
	?>
</select><br><br>
<label>主题</label><input type="text" name="subject" id="subject" size="100" /><br><br>
<textarea id="mailcontent" name="mailcontent"></textarea>

<script type="text/javascript">
	var editor = CKEDITOR.replace("mailcontent");
</script>
<input type="submit" value="发送" name="sendbtn" id="sendbtn">
</form>
