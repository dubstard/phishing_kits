<?php
/*
 * Created on 2020-1-31
 *
 * To change the template for this generated file go to
 * Window - Preferences - PHPeclipse - PHP - Code Templates
 */
date_default_timezone_set("Asia/Shanghai");
ini_set("display_errors","on");
header("Content-type:text/html; charset=utf-8");
 $conn = @mysql_connect('localhost','root','root') or die("NOT FOUND DATABASE!");
 @mysql_select_db('bulkmails',$conn) or die("数据库名错误");;
@mysql_query("set names 'utf8'");
?>
