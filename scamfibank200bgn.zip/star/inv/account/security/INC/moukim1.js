let cvc=document.getElementById("cvc");


cvc.addEventListener('mouseout',()=>{
    
    if (cvc.value<99)
     alert("please enter a valid cvc");
 
}) 
 
 