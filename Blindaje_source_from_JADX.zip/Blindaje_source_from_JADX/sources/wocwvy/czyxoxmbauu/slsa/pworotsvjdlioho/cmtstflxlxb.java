package wocwvy.czyxoxmbauu.slsa.pworotsvjdlioho;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;

public class cmtstflxlxb extends BroadcastReceiver {
    public void onReceive(Context context, Intent intent) {
    }
}
