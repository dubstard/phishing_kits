package wocwvy.czyxoxmbauu.slsa;

import android.app.Service;
import android.content.Intent;
import android.os.IBinder;

public class lmimy extends Service {
    public IBinder onBind(Intent intent) {
        return null;
    }
}
