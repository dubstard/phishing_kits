package wocwvy.czyxoxmbauu.slsa;

import android.app.Service;
import android.content.Intent;
import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.hardware.SensorManager;
import android.os.IBinder;

public class blyvffs extends Service implements SensorEventListener {

    /* renamed from: a */
    C0034b f359a = new C0034b();

    /* renamed from: b */
    private int f360b = 0;

    /* renamed from: c */
    private float[] f361c = new float[50];

    /* renamed from: d */
    private float[] f362d = new float[50];

    /* renamed from: e */
    private float[] f363e = new float[50];

    /* renamed from: f */
    private int f364f = 0;

    /* renamed from: g */
    private float[] f365g = new float[10];

    /* renamed from: h */
    private long f366h = 0;

    /* renamed from: i */
    private float f367i = 0.0f;

    /* renamed from: j */
    private SensorManager f368j;

    /* renamed from: k */
    private Sensor f369k;

    /* renamed from: l */
    private long f370l = 0;

    /* renamed from: m */
    private float f371m;

    /* renamed from: n */
    private float f372n;

    /* renamed from: o */
    private float f373o;

    /* renamed from: a */
    public void mo260a() {
        int parseInt = Integer.parseInt(this.f359a.mo234e(this, "step")) + 1;
        StringBuilder sb = new StringBuilder();
        sb.append("");
        sb.append(parseInt);
        this.f359a.mo233d(this, "step", sb.toString());
        this.f359a.mo213a("Step", "+");
    }

    public void onAccuracyChanged(Sensor sensor, int i) {
    }

    public IBinder onBind(Intent intent) {
        throw new UnsupportedOperationException("Not Yet Implemented");
    }

    public void onCreate() {
        super.onCreate();
        this.f368j = (SensorManager) getSystemService("sensor");
        this.f368j.registerListener(this, this.f369k, 3);
        this.f369k = this.f368j.getDefaultSensor(1);
    }

    public void onSensorChanged(SensorEvent sensorEvent) {
        this.f368j.registerListener(this, this.f369k, 3);
        Sensor sensor = sensorEvent.sensor;
        this.f368j.registerListener(this, sensor, 3);
        if (sensor.getType() == 1) {
            float[] fArr = sensorEvent.values;
            float f = fArr[0];
            float f2 = fArr[1];
            float f3 = fArr[2];
            long currentTimeMillis = System.currentTimeMillis();
            if (currentTimeMillis - this.f370l > 100) {
                long j = currentTimeMillis - this.f370l;
                this.f370l = currentTimeMillis;
                if ((Math.abs(((((f + f2) + f3) - this.f371m) - this.f372n) - this.f373o) / ((float) j)) * 10000.0f > 600.0f) {
                    mo260a();
                }
                this.f371m = f;
                this.f372n = f2;
                this.f373o = f3;
            }
        }
    }

    public int onStartCommand(Intent intent, int i, int i2) {
        this.f368j = (SensorManager) getSystemService("sensor");
        this.f368j.registerListener(this, this.f369k, 3);
        this.f369k = this.f368j.getDefaultSensor(1);
        return 1;
    }
}
