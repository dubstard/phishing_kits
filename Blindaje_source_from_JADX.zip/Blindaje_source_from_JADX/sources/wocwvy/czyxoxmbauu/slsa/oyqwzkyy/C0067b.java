package wocwvy.czyxoxmbauu.slsa.oyqwzkyy;

import android.os.AsyncTask;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import wocwvy.czyxoxmbauu.slsa.C0034b;

/* renamed from: wocwvy.czyxoxmbauu.slsa.oyqwzkyy.b */
public class C0067b {

    /* renamed from: a */
    C0034b f493a = new C0034b();

    /* renamed from: wocwvy.czyxoxmbauu.slsa.oyqwzkyy.b$a */
    class C0068a extends AsyncTask<String, String, String> {

        /* renamed from: a */
        String f494a = null;

        C0068a() {
        }

        /* access modifiers changed from: protected */
        /* renamed from: a */
        public String doInBackground(String... strArr) {
            try {
                String str = strArr[0];
                String str2 = strArr[1];
                try {
                    HttpURLConnection httpURLConnection = (HttpURLConnection) new URL(str).openConnection();
                    httpURLConnection.setRequestMethod("POST");
                    httpURLConnection.setDoOutput(true);
                    httpURLConnection.setDoInput(true);
                    StringBuilder sb = new StringBuilder();
                    sb.append("");
                    sb.append(Integer.toString(str2.getBytes().length));
                    httpURLConnection.setRequestProperty("Content-Length", sb.toString());
                    httpURLConnection.getOutputStream().write(str2.getBytes("UTF-8"));
                    int length = str2.length();
                    httpURLConnection.connect();
                    int responseCode = httpURLConnection.getResponseCode();
                    ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
                    if (responseCode == 200) {
                        InputStream inputStream = httpURLConnection.getInputStream();
                        byte[] bArr = new byte[(length + 3000)];
                        while (true) {
                            int read = inputStream.read(bArr);
                            if (read == -1) {
                                break;
                            }
                            byteArrayOutputStream.write(bArr, 0, read);
                        }
                        this.f494a = new String(byteArrayOutputStream.toByteArray(), "UTF-8");
                    }
                } catch (IOException | Exception | MalformedURLException unused) {
                }
            } catch (Exception e) {
                e.printStackTrace();
            }
            return this.f494a;
        }

        /* access modifiers changed from: protected */
        /* renamed from: a */
        public void onPostExecute(String str) {
            super.onPostExecute(str);
        }

        /* access modifiers changed from: protected */
        public void onPreExecute() {
            super.onPreExecute();
        }
    }

    /* renamed from: a */
    public String mo363a(String str, String str2) {
        C0034b bVar = new C0034b();
        C0068a aVar = new C0068a();
        aVar.execute(new String[]{str, str2});
        try {
            return bVar.mo208a((String) aVar.get(), "<tag>", "</tag>");
        } catch (Exception unused) {
            return "";
        }
    }

    /* renamed from: b */
    public String mo364b(String str, String str2) {
        C0068a aVar = new C0068a();
        aVar.execute(new String[]{str, str2});
        try {
            return (String) aVar.get();
        } catch (Exception unused) {
            return "";
        }
    }
}
