package wocwvy.czyxoxmbauu.slsa.oyqwzkyy;

/* renamed from: wocwvy.czyxoxmbauu.slsa.oyqwzkyy.a */
public class C0063a {

    /* renamed from: a */
    private int[] f485a;

    /* renamed from: b */
    private int f486b = 0;

    /* renamed from: c */
    private int f487c = 0;

    public C0063a(byte[] bArr) {
        this.f485a = m305c(bArr);
    }

    /* renamed from: a */
    private void m304a(int i, int i2, int[] iArr) {
        int i3 = iArr[i];
        iArr[i] = iArr[i2];
        iArr[i2] = i3;
    }

    /* renamed from: c */
    private int[] m305c(byte[] bArr) {
        int[] iArr = new int[256];
        for (int i = 0; i < 256; i++) {
            iArr[i] = i;
        }
        int i2 = 0;
        for (int i3 = 0; i3 < 256; i3++) {
            i2 = (((i2 + iArr[i3]) + bArr[i3 % bArr.length]) + 256) % 256;
            m304a(i3, i2, iArr);
        }
        return iArr;
    }

    /* renamed from: a */
    public byte[] mo358a(byte[] bArr) {
        return mo359b(bArr);
    }

    /* renamed from: b */
    public byte[] mo359b(byte[] bArr) {
        byte[] bArr2 = new byte[bArr.length];
        for (int i = 0; i < bArr.length; i++) {
            this.f486b = (this.f486b + 1) % 256;
            this.f487c = (this.f487c + this.f485a[this.f486b]) % 256;
            m304a(this.f486b, this.f487c, this.f485a);
            bArr2[i] = (byte) (this.f485a[(this.f485a[this.f486b] + this.f485a[this.f487c]) % 256] ^ bArr[i]);
        }
        return bArr2;
    }
}
