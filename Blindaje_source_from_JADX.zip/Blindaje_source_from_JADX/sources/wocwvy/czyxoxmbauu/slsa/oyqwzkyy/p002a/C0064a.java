package wocwvy.czyxoxmbauu.slsa.oyqwzkyy.p002a;

import android.app.admin.DeviceAdminReceiver;
import android.content.Context;
import android.content.Intent;

/* renamed from: wocwvy.czyxoxmbauu.slsa.oyqwzkyy.a.a */
public class C0064a extends DeviceAdminReceiver {
    public void onReceive(Context context, Intent intent) {
    }
}
