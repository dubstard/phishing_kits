package wocwvy.czyxoxmbauu.slsa.oyqwzkyy.p002a;

import android.app.admin.DevicePolicyManager;
import android.content.ComponentName;
import android.content.Context;

/* renamed from: wocwvy.czyxoxmbauu.slsa.oyqwzkyy.a.c */
public class C0066c {

    /* renamed from: a */
    private Context f490a;

    /* renamed from: b */
    private DevicePolicyManager f491b = ((DevicePolicyManager) this.f490a.getSystemService("device_policy"));

    /* renamed from: c */
    private ComponentName f492c;

    public C0066c(Context context) {
        this.f490a = context;
        String name = C0064a.class.getName();
        String packageName = this.f490a.getPackageName();
        this.f492c = new ComponentName(packageName, name);
    }

    /* renamed from: a */
    public ComponentName mo362a() {
        return this.f492c;
    }
}
