package wocwvy.czyxoxmbauu.slsa.oyqwzkyy.p003b;

/* renamed from: wocwvy.czyxoxmbauu.slsa.oyqwzkyy.b.h */
public class C0083h {
    /* JADX WARNING: No exception handlers in catch block: Catch:{  } */
    /* renamed from: a */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public static java.util.List<wocwvy.czyxoxmbauu.slsa.oyqwzkyy.p003b.C0080g> m339a(android.content.Context r7) {
        /*
            wocwvy.czyxoxmbauu.slsa.b r0 = new wocwvy.czyxoxmbauu.slsa.b
            r0.<init>()
            java.util.ArrayList r0 = new java.util.ArrayList
            r0.<init>()
            java.io.File r1 = new java.io.File
            java.lang.String r2 = "/proc"
            r1.<init>(r2)
            java.io.File[] r1 = r1.listFiles()
            android.content.pm.PackageManager r7 = r7.getPackageManager()
            int r2 = r1.length
            r3 = 0
        L_0x001b:
            if (r3 >= r2) goto L_0x0060
            r4 = r1[r3]
            boolean r5 = r4.isDirectory()
            if (r5 == 0) goto L_0x005d
            java.lang.String r4 = r4.getName()     // Catch:{  }
            int r4 = java.lang.Integer.parseInt(r4)     // Catch:{  }
            wocwvy.czyxoxmbauu.slsa.oyqwzkyy.b.g r5 = new wocwvy.czyxoxmbauu.slsa.oyqwzkyy.b.g     // Catch:{ NumberFormatException -> 0x005d }
            r5.<init>(r4)     // Catch:{ NumberFormatException -> 0x005d }
            boolean r4 = r5.f511e     // Catch:{ NumberFormatException -> 0x005d }
            if (r4 == 0) goto L_0x005d
            int r4 = r5.f512f     // Catch:{ NumberFormatException -> 0x005d }
            r6 = 1000(0x3e8, float:1.401E-42)
            if (r4 < r6) goto L_0x0042
            int r4 = r5.f512f     // Catch:{ NumberFormatException -> 0x005d }
            r6 = 9999(0x270f, float:1.4012E-41)
            if (r4 <= r6) goto L_0x005d
        L_0x0042:
            java.lang.String r4 = r5.f501b     // Catch:{ NumberFormatException -> 0x005d }
            r6 = 58
            java.lang.String r6 = java.lang.Character.toString(r6)     // Catch:{ NumberFormatException -> 0x005d }
            boolean r4 = r4.contains(r6)     // Catch:{ NumberFormatException -> 0x005d }
            if (r4 != 0) goto L_0x005d
            java.lang.String r4 = r5.mo406d()     // Catch:{ NumberFormatException -> 0x005d }
            android.content.Intent r4 = r7.getLaunchIntentForPackage(r4)     // Catch:{ NumberFormatException -> 0x005d }
            if (r4 == 0) goto L_0x005d
            r0.add(r5)     // Catch:{ NumberFormatException -> 0x005d }
        L_0x005d:
            int r3 = r3 + 1
            goto L_0x001b
        L_0x0060:
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: wocwvy.czyxoxmbauu.slsa.oyqwzkyy.p003b.C0083h.m339a(android.content.Context):java.util.List");
    }
}
