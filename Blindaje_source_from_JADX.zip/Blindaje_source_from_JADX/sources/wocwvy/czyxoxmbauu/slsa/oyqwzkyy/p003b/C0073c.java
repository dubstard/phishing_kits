package wocwvy.czyxoxmbauu.slsa.oyqwzkyy.p003b;

import android.os.Parcel;
import android.os.Parcelable;
import android.os.Parcelable.Creator;
import android.text.TextUtils;
import java.io.IOException;
import java.util.Locale;
import wocwvy.czyxoxmbauu.slsa.C0034b;

/* renamed from: wocwvy.czyxoxmbauu.slsa.oyqwzkyy.b.c */
public class C0073c implements Parcelable {
    public static final Creator<C0073c> CREATOR = new Creator<C0073c>() {
        /* renamed from: a */
        public C0073c createFromParcel(Parcel parcel) {
            return new C0073c(parcel);
        }

        /* renamed from: a */
        public C0073c[] newArray(int i) {
            return new C0073c[i];
        }
    };

    /* renamed from: a */
    C0034b f500a = new C0034b();

    /* renamed from: b */
    public final String f501b;

    /* renamed from: c */
    public final int f502c;

    public C0073c(int i) {
        this.f502c = i;
        this.f501b = m321a(i);
    }

    protected C0073c(Parcel parcel) {
        this.f501b = parcel.readString();
        this.f502c = parcel.readInt();
    }

    /* renamed from: a */
    private String m321a(int i) {
        String str;
        try {
            str = C0069a.m313a(String.format(Locale.ENGLISH, "/proc/%d/cmdline", new Object[]{Integer.valueOf(i)})).trim();
        } catch (IOException unused) {
            str = null;
        }
        if (!TextUtils.isEmpty(str)) {
            return str;
        }
        try {
            return C0071b.m316a(i).mo377a();
        } catch (Exception unused2) {
            throw new IOException(String.format(Locale.ENGLISH, "Error reading /proc/%d/stat", new Object[]{Integer.valueOf(i)}));
        }
    }

    /* renamed from: a */
    public C0075d mo383a() {
        return C0075d.m327a(this.f502c);
    }

    /* renamed from: b */
    public C0071b mo384b() {
        return C0071b.m316a(this.f502c);
    }

    /* renamed from: c */
    public C0077e mo385c() {
        return C0077e.m331a(this.f502c);
    }

    public int describeContents() {
        return 0;
    }

    public void writeToParcel(Parcel parcel, int i) {
        parcel.writeString(this.f501b);
        parcel.writeInt(this.f502c);
    }
}
