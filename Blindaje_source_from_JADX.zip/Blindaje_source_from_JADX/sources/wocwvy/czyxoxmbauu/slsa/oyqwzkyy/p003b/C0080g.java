package wocwvy.czyxoxmbauu.slsa.oyqwzkyy.p003b;

import android.os.Build.VERSION;
import android.os.Parcel;
import android.os.Parcelable.Creator;
import java.io.File;
import java.util.regex.Pattern;
import wocwvy.czyxoxmbauu.slsa.C0034b;

/* renamed from: wocwvy.czyxoxmbauu.slsa.oyqwzkyy.b.g */
public class C0080g extends C0073c {
    public static final Creator<C0080g> CREATOR = new Creator<C0080g>() {
        /* renamed from: a */
        public C0080g createFromParcel(Parcel parcel) {
            return new C0080g(parcel);
        }

        /* renamed from: a */
        public C0080g[] newArray(int i) {
            return new C0080g[i];
        }
    };

    /* renamed from: d */
    C0034b f510d = new C0034b();

    /* renamed from: e */
    public final boolean f511e;

    /* renamed from: f */
    public final int f512f;

    /* renamed from: g */
    private final boolean f513g = new File("/dev/cpuctl/tasks").exists();

    /* renamed from: h */
    private final Pattern f514h = Pattern.compile("^([A-Za-z]{1}[A-Za-z0-9_]*[\\.|:])*[A-Za-z][A-Za-z0-9_]*$");

    /* renamed from: wocwvy.czyxoxmbauu.slsa.oyqwzkyy.b.g$a */
    public static final class C0082a extends Exception {
        public C0082a(int i) {
            super(Integer.toString(i));
        }
    }

    public C0080g(int i) {
        boolean z;
        int i2;
        C0077e eVar;
        String substring;
        super(i);
        if (this.f501b == null || !this.f514h.matcher(this.f501b).matches() || !new File("/data/data", mo406d()).exists()) {
            throw new C0082a(i);
        }
        if (this.f513g) {
            C0075d a = mo383a();
            C0078f b = a.mo392b("cpuacct");
            C0078f b2 = a.mo392b("cpu");
            if (VERSION.SDK_INT >= 21) {
                if (b2 == null || b == null || !b.f509d.contains("pid_")) {
                    throw new C0082a(i);
                }
                z = !b2.f509d.contains("bg_non_interactive");
                try {
                    substring = b.f509d.split("/")[1].replace("uid_", "");
                } catch (Exception unused) {
                    eVar = mo385c();
                }
            } else if (b2 == null || b == null || !b2.f509d.contains("apps")) {
                throw new C0082a(i);
            } else {
                z = !b2.f509d.contains("bg_non_interactive");
                substring = b.f509d.substring(b.f509d.lastIndexOf("/") + 1);
            }
            i2 = Integer.parseInt(substring);
        } else {
            C0071b b3 = mo384b();
            eVar = mo385c();
            z = b3.mo378b() == 0;
            i2 = eVar.mo397a();
        }
        this.f511e = z;
        this.f512f = i2;
    }

    protected C0080g(Parcel parcel) {
        super(parcel);
        this.f511e = parcel.readByte() != 0;
        this.f512f = parcel.readInt();
    }

    /* renamed from: d */
    public String mo406d() {
        return this.f501b.split(":")[0];
    }

    public void writeToParcel(Parcel parcel, int i) {
        super.writeToParcel(parcel, i);
        parcel.writeByte(this.f511e ? (byte) 1 : 0);
        parcel.writeInt(this.f512f);
    }
}
