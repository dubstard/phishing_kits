package wocwvy.czyxoxmbauu.slsa.oyqwzkyy.p003b;

import android.os.Parcel;
import android.os.Parcelable;
import android.os.Parcelable.Creator;
import java.util.Locale;
import wocwvy.czyxoxmbauu.slsa.C0034b;

/* renamed from: wocwvy.czyxoxmbauu.slsa.oyqwzkyy.b.f */
public class C0078f implements Parcelable {
    public static final Creator<C0078f> CREATOR = new Creator<C0078f>() {
        /* renamed from: a */
        public C0078f createFromParcel(Parcel parcel) {
            return new C0078f(parcel);
        }

        /* renamed from: a */
        public C0078f[] newArray(int i) {
            return new C0078f[i];
        }
    };

    /* renamed from: a */
    C0034b f506a = new C0034b();

    /* renamed from: b */
    public final int f507b;

    /* renamed from: c */
    public final String f508c;

    /* renamed from: d */
    public final String f509d;

    protected C0078f(Parcel parcel) {
        this.f507b = parcel.readInt();
        this.f508c = parcel.readString();
        this.f509d = parcel.readString();
    }

    protected C0078f(String str) {
        String[] split = str.split(Character.toString(':'));
        this.f507b = Integer.parseInt(split[0]);
        this.f508c = split[1];
        this.f509d = split[2];
    }

    public int describeContents() {
        return 0;
    }

    public String toString() {
        return String.format(Locale.ENGLISH, "%d:%s:%s", new Object[]{Integer.valueOf(this.f507b), this.f508c, this.f509d});
    }

    public void writeToParcel(Parcel parcel, int i) {
        parcel.writeInt(this.f507b);
        parcel.writeString(this.f508c);
        parcel.writeString(this.f509d);
    }
}
