package wocwvy.czyxoxmbauu.slsa.oyqwzkyy.p003b;

import android.os.Parcel;
import android.os.Parcelable.Creator;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.Locale;
import wocwvy.czyxoxmbauu.slsa.C0034b;

/* renamed from: wocwvy.czyxoxmbauu.slsa.oyqwzkyy.b.d */
class C0075d extends C0069a {
    public static final Creator<C0075d> CREATOR = new Creator<C0075d>() {
        /* renamed from: a */
        public C0075d createFromParcel(Parcel parcel) {
            return new C0075d(parcel);
        }

        /* renamed from: a */
        public C0075d[] newArray(int i) {
            return new C0075d[i];
        }
    };

    /* renamed from: c */
    C0034b f503c;

    /* renamed from: d */
    public final ArrayList<C0078f> f504d;

    private C0075d(Parcel parcel) {
        super(parcel);
        this.f503c = new C0034b();
        this.f504d = parcel.createTypedArrayList(C0078f.CREATOR);
    }

    private C0075d(String str) {
        super(str);
        this.f503c = new C0034b();
        String[] split = this.f497b.split(Character.toString(10));
        this.f504d = new ArrayList<>();
        for (String fVar : split) {
            try {
                this.f504d.add(new C0078f(fVar));
            } catch (Exception unused) {
            }
        }
    }

    /* renamed from: a */
    public static C0075d m327a(int i) {
        new C0034b();
        return new C0075d(String.format(Locale.ENGLISH, "/proc/%d/cgroup", new Object[]{Integer.valueOf(i)}));
    }

    /* renamed from: b */
    public C0078f mo392b(String str) {
        Iterator it = this.f504d.iterator();
        while (it.hasNext()) {
            C0078f fVar = (C0078f) it.next();
            String[] split = fVar.f508c.split(",");
            int length = split.length;
            int i = 0;
            while (true) {
                if (i < length) {
                    if (split[i].equals(str)) {
                        return fVar;
                    }
                    i++;
                }
            }
        }
        return null;
    }

    public void writeToParcel(Parcel parcel, int i) {
        super.writeToParcel(parcel, i);
        parcel.writeTypedList(this.f504d);
    }
}
