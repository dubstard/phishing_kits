package wocwvy.czyxoxmbauu.slsa.oyqwzkyy.p003b;

import java.util.Locale;
import wocwvy.czyxoxmbauu.slsa.C0034b;

/* renamed from: wocwvy.czyxoxmbauu.slsa.oyqwzkyy.b.e */
public class C0077e extends C0069a {

    /* renamed from: c */
    C0034b f505c = new C0034b();

    private C0077e(String str) {
        super(str);
    }

    /* renamed from: a */
    public static C0077e m331a(int i) {
        new C0034b();
        return new C0077e(String.format(Locale.ENGLISH, "/proc/%d/status", new Object[]{Integer.valueOf(i)}));
    }

    /* renamed from: a */
    public int mo397a() {
        new C0034b();
        try {
            return Integer.parseInt(mo398b("Uid").split("\\s+")[0]);
        } catch (Exception unused) {
            return -1;
        }
    }

    /* renamed from: b */
    public String mo398b(String str) {
        String[] split;
        new C0034b();
        for (String str2 : this.f497b.split("\n")) {
            StringBuilder sb = new StringBuilder();
            sb.append(str);
            sb.append(":");
            if (str2.startsWith(sb.toString())) {
                StringBuilder sb2 = new StringBuilder();
                sb2.append(str);
                sb2.append(":");
                return str2.split(sb2.toString())[1].trim();
            }
        }
        return null;
    }
}
