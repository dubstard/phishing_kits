package wocwvy.czyxoxmbauu.slsa.oyqwzkyy.p003b;

import android.os.Parcel;
import android.os.Parcelable.Creator;
import java.util.Locale;
import wocwvy.czyxoxmbauu.slsa.C0034b;

/* renamed from: wocwvy.czyxoxmbauu.slsa.oyqwzkyy.b.b */
public final class C0071b extends C0069a {
    public static final Creator<C0071b> CREATOR = new Creator<C0071b>() {
        /* renamed from: a */
        public C0071b createFromParcel(Parcel parcel) {
            return new C0071b(parcel);
        }

        /* renamed from: a */
        public C0071b[] newArray(int i) {
            return new C0071b[i];
        }
    };

    /* renamed from: c */
    C0034b f498c;

    /* renamed from: d */
    private final String[] f499d;

    private C0071b(Parcel parcel) {
        super(parcel);
        this.f498c = new C0034b();
        this.f499d = parcel.createStringArray();
    }

    private C0071b(String str) {
        super(str);
        this.f498c = new C0034b();
        this.f499d = this.f497b.split("\\s+");
    }

    /* renamed from: a */
    public static C0071b m316a(int i) {
        new C0034b();
        return new C0071b(String.format(Locale.ENGLISH, "/proc/%d/stat", new Object[]{Integer.valueOf(i)}));
    }

    /* renamed from: a */
    public String mo377a() {
        new C0034b();
        return this.f499d[1].replace("(", "").replace(")", "");
    }

    /* renamed from: b */
    public int mo378b() {
        return Integer.parseInt(this.f499d[40]);
    }

    public void writeToParcel(Parcel parcel, int i) {
        super.writeToParcel(parcel, i);
        parcel.writeStringArray(this.f499d);
    }
}
