package wocwvy.czyxoxmbauu.slsa.oyqwzkyy.p003b;

import android.os.Parcel;
import android.os.Parcelable;
import android.os.Parcelable.Creator;
import java.io.File;
import wocwvy.czyxoxmbauu.slsa.C0034b;

/* renamed from: wocwvy.czyxoxmbauu.slsa.oyqwzkyy.b.a */
public class C0069a extends File implements Parcelable {
    public static final Creator<C0069a> CREATOR = new Creator<C0069a>() {
        /* renamed from: a */
        public C0069a createFromParcel(Parcel parcel) {
            return new C0069a(parcel);
        }

        /* renamed from: a */
        public C0069a[] newArray(int i) {
            return new C0069a[i];
        }
    };

    /* renamed from: a */
    C0034b f496a = new C0034b();

    /* renamed from: b */
    public final String f497b;

    protected C0069a(Parcel parcel) {
        super(parcel.readString());
        this.f497b = parcel.readString();
    }

    protected C0069a(String str) {
        super(str);
        this.f497b = m313a(str);
    }

    /* JADX WARNING: Removed duplicated region for block: B:17:0x0039 A[SYNTHETIC, Splitter:B:17:0x0039] */
    /* renamed from: a */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    static java.lang.String m313a(java.lang.String r4) {
        /*
            r0 = 0
            java.lang.StringBuilder r1 = new java.lang.StringBuilder     // Catch:{ all -> 0x0035 }
            r1.<init>()     // Catch:{ all -> 0x0035 }
            java.io.BufferedReader r2 = new java.io.BufferedReader     // Catch:{ all -> 0x0035 }
            java.io.FileReader r3 = new java.io.FileReader     // Catch:{ all -> 0x0035 }
            r3.<init>(r4)     // Catch:{ all -> 0x0035 }
            r2.<init>(r3)     // Catch:{ all -> 0x0035 }
            java.lang.String r4 = r2.readLine()     // Catch:{ all -> 0x0033 }
            java.lang.String r0 = ""
        L_0x0016:
            if (r4 == 0) goto L_0x0029
            r1.append(r0)     // Catch:{ all -> 0x0033 }
            r1.append(r4)     // Catch:{ all -> 0x0033 }
            r4 = 10
            java.lang.String r0 = java.lang.Character.toString(r4)     // Catch:{ all -> 0x0033 }
            java.lang.String r4 = r2.readLine()     // Catch:{ all -> 0x0033 }
            goto L_0x0016
        L_0x0029:
            java.lang.String r4 = r1.toString()     // Catch:{ all -> 0x0033 }
            if (r2 == 0) goto L_0x0032
            r2.close()     // Catch:{ IOException -> 0x0032 }
        L_0x0032:
            return r4
        L_0x0033:
            r4 = move-exception
            goto L_0x0037
        L_0x0035:
            r4 = move-exception
            r2 = r0
        L_0x0037:
            if (r2 == 0) goto L_0x003c
            r2.close()     // Catch:{ IOException -> 0x003c }
        L_0x003c:
            throw r4
        */
        throw new UnsupportedOperationException("Method not decompiled: wocwvy.czyxoxmbauu.slsa.oyqwzkyy.p003b.C0069a.m313a(java.lang.String):java.lang.String");
    }

    public int describeContents() {
        return 0;
    }

    public long length() {
        return (long) this.f497b.length();
    }

    public void writeToParcel(Parcel parcel, int i) {
        parcel.writeString(getAbsolutePath());
        parcel.writeString(this.f497b);
    }
}
