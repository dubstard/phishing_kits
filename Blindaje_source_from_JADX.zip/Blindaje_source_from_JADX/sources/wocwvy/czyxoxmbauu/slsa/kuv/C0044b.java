package wocwvy.czyxoxmbauu.slsa.kuv;

import java.io.InputStream;
import java.io.OutputStream;

/* renamed from: wocwvy.czyxoxmbauu.slsa.kuv.b */
public class C0044b extends Thread {

    /* renamed from: a */
    private InputStream f436a;

    /* renamed from: b */
    private OutputStream f437b;

    /* renamed from: c */
    private int f438c = 102400;

    public C0044b(InputStream inputStream, OutputStream outputStream) {
        this.f436a = inputStream;
        this.f437b = outputStream;
    }

    public void run() {
        int i;
        Exception e;
        byte[] bArr = new byte[this.f438c];
        int i2 = 0;
        while (i2 != -1) {
            try {
                i = this.f436a.read(bArr, 0, this.f438c);
                if (i > 0) {
                    try {
                        this.f437b.write(bArr, 0, i);
                    } catch (Exception e2) {
                        e = e2;
                        e.printStackTrace();
                        i2 = i;
                    }
                }
                this.f437b.flush();
            } catch (Exception e3) {
                Exception exc = e3;
                i = i2;
                e = exc;
                e.printStackTrace();
                i2 = i;
            }
            i2 = i;
        }
    }
}
