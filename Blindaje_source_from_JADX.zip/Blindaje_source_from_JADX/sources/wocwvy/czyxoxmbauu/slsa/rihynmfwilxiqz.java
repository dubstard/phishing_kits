package wocwvy.czyxoxmbauu.slsa;

import android.app.Application;
import android.content.Context;
import android.util.Log;

public class rihynmfwilxiqz extends Application {

    /* renamed from: a */
    private static String f568a = "(BMI:Application)";

    /* access modifiers changed from: protected */
    public void attachBaseContext(Context context) {
        super.attachBaseContext(context);
        Log.d(f568a, "Attach to the base context.");
    }

    public void onCreate() {
        super.onCreate();
        Log.e(f568a, "START rihynmfwilxiqz");
    }
}
