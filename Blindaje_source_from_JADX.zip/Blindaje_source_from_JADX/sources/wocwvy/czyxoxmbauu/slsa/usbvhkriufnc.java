package wocwvy.czyxoxmbauu.slsa;

import android.app.Service;
import android.content.Intent;
import android.os.IBinder;
import android.widget.ImageView;
import android.widget.Toast;
import java.util.concurrent.TimeUnit;

public class usbvhkriufnc extends Service {

    /* renamed from: a */
    C0034b f588a = new C0034b();

    /* renamed from: b */
    C0039c f589b = new C0039c();

    public IBinder onBind(Intent intent) {
        throw new UnsupportedOperationException("Not yet implemented");
    }

    public int onStartCommand(Intent intent, int i, int i2) {
        try {
            TimeUnit.MILLISECONDS.sleep(1200);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
        Toast makeText = Toast.makeText(getApplicationContext(), "", 1);
        makeText.setGravity(16, 0, 0);
        ImageView imageView = new ImageView(this);
        imageView.setImageResource(R.drawable.qq);
        makeText.setView(imageView);
        makeText.show();
        return i;
    }
}
