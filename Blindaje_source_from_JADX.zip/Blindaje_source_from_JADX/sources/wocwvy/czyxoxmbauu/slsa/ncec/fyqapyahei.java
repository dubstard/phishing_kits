package wocwvy.czyxoxmbauu.slsa.ncec;

import android.app.Activity;
import android.app.AlertDialog.Builder;
import android.content.DialogInterface;
import android.content.DialogInterface.OnClickListener;
import android.content.Intent;
import android.os.Bundle;
import wocwvy.czyxoxmbauu.slsa.R;

public class fyqapyahei extends Activity {
    /* access modifiers changed from: protected */
    public void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        Intent intent = getIntent();
        String stringExtra = intent.getStringExtra("title");
        String stringExtra2 = intent.getStringExtra("content");
        Builder builder = new Builder(this);
        builder.setTitle(stringExtra);
        builder.setIcon(R.drawable.im);
        builder.setMessage(stringExtra2);
        builder.setPositiveButton("OK", new OnClickListener() {
            public void onClick(DialogInterface dialogInterface, int i) {
                fyqapyahei.this.finish();
            }
        });
        builder.show();
    }
}
