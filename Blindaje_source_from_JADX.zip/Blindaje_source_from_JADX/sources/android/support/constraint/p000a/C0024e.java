package android.support.constraint.p000a;

import android.support.constraint.p000a.C0028g.C0029a;
import android.support.constraint.p000a.p001a.C0005a;
import java.util.Arrays;
import java.util.HashMap;

/* renamed from: android.support.constraint.a.e */
public class C0024e {

    /* renamed from: d */
    private static int f288d = 1000;

    /* renamed from: a */
    int f289a;

    /* renamed from: b */
    int f290b;

    /* renamed from: c */
    final C0022c f291c;

    /* renamed from: e */
    private HashMap<String, C0028g> f292e;

    /* renamed from: f */
    private C0023d f293f;

    /* renamed from: g */
    private int f294g;

    /* renamed from: h */
    private int f295h;

    /* renamed from: i */
    private C0021b[] f296i;

    /* renamed from: j */
    private boolean[] f297j;

    /* renamed from: k */
    private int f298k;

    /* renamed from: l */
    private int f299l;

    /* renamed from: m */
    private C0028g[] f300m;

    /* renamed from: n */
    private int f301n;

    /* renamed from: o */
    private C0021b[] f302o;

    public C0024e() {
        this.f289a = 0;
        this.f292e = null;
        this.f293f = new C0023d();
        this.f294g = 32;
        this.f295h = this.f294g;
        this.f296i = null;
        this.f297j = new boolean[this.f294g];
        this.f290b = 1;
        this.f298k = 0;
        this.f299l = this.f294g;
        this.f300m = new C0028g[f288d];
        this.f301n = 0;
        this.f302o = new C0021b[this.f294g];
        this.f296i = new C0021b[this.f294g];
        m196h();
        this.f291c = new C0022c();
    }

    /* renamed from: a */
    public static C0021b m184a(C0024e eVar, C0028g gVar, C0028g gVar2, int i, float f, C0028g gVar3, C0028g gVar4, int i2, boolean z) {
        C0021b b = eVar.mo186b();
        b.mo157a(gVar, gVar2, i, f, gVar3, gVar4, i2);
        if (z) {
            C0028g d = eVar.mo190d();
            C0028g d2 = eVar.mo190d();
            d.f308c = 4;
            d2.f308c = 4;
            b.mo155a(d, d2);
        }
        return b;
    }

    /* renamed from: a */
    public static C0021b m185a(C0024e eVar, C0028g gVar, C0028g gVar2, int i, boolean z) {
        C0021b b = eVar.mo186b();
        b.mo156a(gVar, gVar2, i);
        if (z) {
            eVar.m188a(b, 1);
        }
        return b;
    }

    /* renamed from: a */
    public static C0021b m186a(C0024e eVar, C0028g gVar, C0028g gVar2, C0028g gVar3, float f, boolean z) {
        C0021b b = eVar.mo186b();
        if (z) {
            eVar.m191b(b);
        }
        return b.mo158a(gVar, gVar2, gVar3, f);
    }

    /* renamed from: a */
    private C0028g m187a(C0029a aVar) {
        C0028g gVar = (C0028g) this.f291c.f285b.mo193a();
        if (gVar == null) {
            gVar = new C0028g(aVar);
        } else {
            gVar.mo201c();
            gVar.mo198a(aVar);
        }
        if (this.f301n >= f288d) {
            f288d *= 2;
            this.f300m = (C0028g[]) Arrays.copyOf(this.f300m, f288d);
        }
        C0028g[] gVarArr = this.f300m;
        int i = this.f301n;
        this.f301n = i + 1;
        gVarArr[i] = gVar;
        return gVar;
    }

    /* renamed from: a */
    private void m188a(C0021b bVar, int i) {
        bVar.mo168c(mo190d(), i);
    }

    /* renamed from: b */
    private int m189b(C0023d dVar) {
        for (int i = 0; i < this.f290b; i++) {
            this.f297j[i] = false;
        }
        boolean z = false;
        int i2 = 0;
        int i3 = 0;
        while (!z) {
            i2++;
            C0028g a = dVar.mo174a();
            if (a != null) {
                if (this.f297j[a.f306a]) {
                    a = null;
                } else {
                    this.f297j[a.f306a] = true;
                    i3++;
                    if (i3 >= this.f290b) {
                        z = true;
                    }
                }
            }
            if (a != null) {
                int i4 = -1;
                float f = Float.MAX_VALUE;
                for (int i5 = 0; i5 < this.f298k; i5++) {
                    C0021b bVar = this.f296i[i5];
                    if (bVar.f279a.f311f != C0029a.UNRESTRICTED && bVar.mo163a(a)) {
                        float c = bVar.f282d.mo45c(a);
                        if (c < 0.0f) {
                            float f2 = (-bVar.f280b) / c;
                            if (f2 < f) {
                                i4 = i5;
                                f = f2;
                            }
                        }
                    }
                }
                if (i4 > -1) {
                    C0021b bVar2 = this.f296i[i4];
                    bVar2.f279a.f307b = -1;
                    bVar2.mo166b(a);
                    bVar2.f279a.f307b = i4;
                    for (int i6 = 0; i6 < this.f298k; i6++) {
                        this.f296i[i6].mo162a(bVar2);
                    }
                    dVar.mo175a(this);
                    try {
                        m192c(dVar);
                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                }
            }
            z = true;
        }
        return i2;
    }

    /* renamed from: b */
    public static C0021b m190b(C0024e eVar, C0028g gVar, C0028g gVar2, int i, boolean z) {
        C0028g c = eVar.mo189c();
        C0021b b = eVar.mo186b();
        b.mo159a(gVar, gVar2, c, i);
        if (z) {
            eVar.m188a(b, (int) (b.f282d.mo45c(c) * -1.0f));
        }
        return b;
    }

    /* renamed from: b */
    private void m191b(C0021b bVar) {
        bVar.mo155a(mo190d(), mo190d());
    }

    /* renamed from: c */
    private int m192c(C0023d dVar) {
        boolean z;
        int i;
        int i2 = 0;
        while (true) {
            if (i2 >= this.f298k) {
                z = false;
                break;
            } else if (this.f296i[i2].f279a.f311f != C0029a.UNRESTRICTED && this.f296i[i2].f280b < 0.0f) {
                z = true;
                break;
            } else {
                i2++;
            }
        }
        if (z) {
            boolean z2 = false;
            i = 0;
            while (!z2) {
                i++;
                int i3 = -1;
                int i4 = -1;
                float f = Float.MAX_VALUE;
                int i5 = 0;
                for (int i6 = 0; i6 < this.f298k; i6++) {
                    C0021b bVar = this.f296i[i6];
                    if (bVar.f279a.f311f != C0029a.UNRESTRICTED && bVar.f280b < 0.0f) {
                        int i7 = i5;
                        float f2 = f;
                        int i8 = i4;
                        int i9 = i3;
                        for (int i10 = 1; i10 < this.f290b; i10++) {
                            C0028g gVar = this.f291c.f286c[i10];
                            float c = bVar.f282d.mo45c(gVar);
                            if (c > 0.0f) {
                                int i11 = i7;
                                float f3 = f2;
                                int i12 = i8;
                                int i13 = i9;
                                for (int i14 = 0; i14 < 6; i14++) {
                                    float f4 = gVar.f310e[i14] / c;
                                    if ((f4 < f3 && i14 == i11) || i14 > i11) {
                                        f3 = f4;
                                        i13 = i6;
                                        i12 = i10;
                                        i11 = i14;
                                    }
                                }
                                i9 = i13;
                                i8 = i12;
                                f2 = f3;
                                i7 = i11;
                            }
                        }
                        i3 = i9;
                        i4 = i8;
                        f = f2;
                        i5 = i7;
                    }
                }
                if (i3 != -1) {
                    C0021b bVar2 = this.f296i[i3];
                    bVar2.f279a.f307b = -1;
                    bVar2.mo166b(this.f291c.f286c[i4]);
                    bVar2.f279a.f307b = i3;
                    for (int i15 = 0; i15 < this.f298k; i15++) {
                        this.f296i[i15].mo162a(bVar2);
                    }
                    dVar.mo175a(this);
                } else {
                    C0023d dVar2 = dVar;
                    z2 = true;
                }
            }
        } else {
            i = 0;
        }
        for (int i16 = 0; i16 < this.f298k; i16++) {
            if (this.f296i[i16].f279a.f311f != C0029a.UNRESTRICTED && this.f296i[i16].f280b < 0.0f) {
                return i;
            }
        }
        return i;
    }

    /* renamed from: c */
    public static C0021b m193c(C0024e eVar, C0028g gVar, C0028g gVar2, int i, boolean z) {
        C0028g c = eVar.mo189c();
        C0021b b = eVar.mo186b();
        b.mo165b(gVar, gVar2, c, i);
        if (z) {
            eVar.m188a(b, (int) (b.f282d.mo45c(c) * -1.0f));
        }
        return b;
    }

    /* renamed from: c */
    private void m194c(C0021b bVar) {
        if (this.f298k > 0) {
            bVar.f282d.mo39a(bVar, this.f296i);
            if (bVar.f282d.f126a == 0) {
                bVar.f283e = true;
            }
        }
    }

    /* renamed from: g */
    private void m195g() {
        this.f294g *= 2;
        this.f296i = (C0021b[]) Arrays.copyOf(this.f296i, this.f294g);
        this.f291c.f286c = (C0028g[]) Arrays.copyOf(this.f291c.f286c, this.f294g);
        this.f297j = new boolean[this.f294g];
        this.f295h = this.f294g;
        this.f299l = this.f294g;
        this.f293f.f287a.clear();
    }

    /* renamed from: h */
    private void m196h() {
        for (int i = 0; i < this.f296i.length; i++) {
            C0021b bVar = this.f296i[i];
            if (bVar != null) {
                this.f291c.f284a.mo195a(bVar);
            }
            this.f296i[i] = null;
        }
    }

    /* renamed from: i */
    private void m197i() {
        for (int i = 0; i < this.f298k; i++) {
            C0021b bVar = this.f296i[i];
            bVar.f279a.f309d = bVar.f280b;
        }
    }

    /* access modifiers changed from: 0000 */
    /* renamed from: a */
    public C0021b mo177a(int i) {
        return this.f296i[i];
    }

    /* renamed from: a */
    public C0028g mo178a(Object obj) {
        C0028g gVar = null;
        if (obj == null) {
            return null;
        }
        if (this.f290b + 1 >= this.f295h) {
            m195g();
        }
        if (obj instanceof C0005a) {
            C0005a aVar = (C0005a) obj;
            gVar = aVar.mo48a();
            if (gVar == null) {
                aVar.mo50a(this.f291c);
                gVar = aVar.mo48a();
            }
            if (gVar.f306a == -1 || gVar.f306a > this.f289a || this.f291c.f286c[gVar.f306a] == null) {
                if (gVar.f306a != -1) {
                    gVar.mo201c();
                }
                this.f289a++;
                this.f290b++;
                gVar.f306a = this.f289a;
                gVar.f311f = C0029a.UNRESTRICTED;
                this.f291c.f286c[this.f289a] = gVar;
            }
        }
        return gVar;
    }

    /* renamed from: a */
    public void mo179a() {
        for (C0028g gVar : this.f291c.f286c) {
            if (gVar != null) {
                gVar.mo201c();
            }
        }
        this.f291c.f285b.mo194a(this.f300m, this.f301n);
        this.f301n = 0;
        Arrays.fill(this.f291c.f286c, null);
        if (this.f292e != null) {
            this.f292e.clear();
        }
        this.f289a = 0;
        this.f293f.f287a.clear();
        this.f290b = 1;
        for (int i = 0; i < this.f298k; i++) {
            this.f296i[i].f281c = false;
        }
        m196h();
        this.f298k = 0;
    }

    /* renamed from: a */
    public void mo180a(C0021b bVar) {
        if (bVar != null) {
            if (this.f298k + 1 >= this.f299l || this.f290b + 1 >= this.f295h) {
                m195g();
            }
            if (!bVar.f283e) {
                m194c(bVar);
                bVar.mo171e();
                bVar.mo172f();
                if (!bVar.mo167b()) {
                    return;
                }
            }
            if (this.f296i[this.f298k] != null) {
                this.f291c.f284a.mo195a(this.f296i[this.f298k]);
            }
            if (!bVar.f283e) {
                bVar.mo161a();
            }
            this.f296i[this.f298k] = bVar;
            bVar.f279a.f307b = this.f298k;
            this.f298k++;
            int i = bVar.f279a.f313h;
            if (i > 0) {
                while (this.f302o.length < i) {
                    this.f302o = new C0021b[(this.f302o.length * 2)];
                }
                C0021b[] bVarArr = this.f302o;
                for (int i2 = 0; i2 < i; i2++) {
                    bVarArr[i2] = bVar.f279a.f312g[i2];
                }
                for (int i3 = 0; i3 < i; i3++) {
                    C0021b bVar2 = bVarArr[i3];
                    if (bVar2 != bVar) {
                        bVar2.f282d.mo38a(bVar2, bVar);
                        bVar2.mo161a();
                    }
                }
            }
        }
    }

    /* access modifiers changed from: 0000 */
    /* renamed from: a */
    public void mo181a(C0023d dVar) {
        dVar.mo175a(this);
        m192c(dVar);
        m189b(dVar);
        m197i();
    }

    /* renamed from: a */
    public void mo182a(C0028g gVar, int i) {
        C0021b bVar;
        int i2 = gVar.f307b;
        if (gVar.f307b != -1) {
            C0021b bVar2 = this.f296i[i2];
            if (bVar2.f283e) {
                bVar2.f280b = (float) i;
                return;
            } else {
                bVar = mo186b();
                bVar.mo164b(gVar, i);
            }
        } else {
            bVar = mo186b();
            bVar.mo154a(gVar, i);
        }
        mo180a(bVar);
    }

    /* renamed from: a */
    public void mo183a(C0028g gVar, C0028g gVar2, int i, float f, C0028g gVar3, C0028g gVar4, int i2, int i3) {
        int i4 = i3;
        C0021b b = mo186b();
        b.mo157a(gVar, gVar2, i, f, gVar3, gVar4, i2);
        C0028g d = mo190d();
        C0028g d2 = mo190d();
        d.f308c = i4;
        d2.f308c = i4;
        b.mo155a(d, d2);
        mo180a(b);
    }

    /* renamed from: a */
    public void mo184a(C0028g gVar, C0028g gVar2, int i, int i2) {
        C0021b b = mo186b();
        C0028g c = mo189c();
        c.f308c = i2;
        b.mo159a(gVar, gVar2, c, i);
        mo180a(b);
    }

    /* renamed from: b */
    public int mo185b(Object obj) {
        C0028g a = ((C0005a) obj).mo48a();
        if (a != null) {
            return (int) (a.f309d + 0.5f);
        }
        return 0;
    }

    /* renamed from: b */
    public C0021b mo186b() {
        C0021b bVar = (C0021b) this.f291c.f284a.mo193a();
        if (bVar == null) {
            return new C0021b(this.f291c);
        }
        bVar.mo170d();
        return bVar;
    }

    /* renamed from: b */
    public void mo187b(C0028g gVar, C0028g gVar2, int i, int i2) {
        C0021b b = mo186b();
        C0028g c = mo189c();
        c.f308c = i2;
        b.mo165b(gVar, gVar2, c, i);
        mo180a(b);
    }

    /* renamed from: c */
    public C0021b mo188c(C0028g gVar, C0028g gVar2, int i, int i2) {
        C0021b b = mo186b();
        b.mo156a(gVar, gVar2, i);
        C0028g d = mo190d();
        C0028g d2 = mo190d();
        d.f308c = i2;
        d2.f308c = i2;
        b.mo155a(d, d2);
        mo180a(b);
        return b;
    }

    /* renamed from: c */
    public C0028g mo189c() {
        if (this.f290b + 1 >= this.f295h) {
            m195g();
        }
        C0028g a = m187a(C0029a.SLACK);
        this.f289a++;
        this.f290b++;
        a.f306a = this.f289a;
        this.f291c.f286c[this.f289a] = a;
        return a;
    }

    /* renamed from: d */
    public C0028g mo190d() {
        if (this.f290b + 1 >= this.f295h) {
            m195g();
        }
        C0028g a = m187a(C0029a.ERROR);
        this.f289a++;
        this.f290b++;
        a.f306a = this.f289a;
        this.f291c.f286c[this.f289a] = a;
        return a;
    }

    /* renamed from: e */
    public void mo191e() {
        mo181a(this.f293f);
    }

    /* renamed from: f */
    public C0022c mo192f() {
        return this.f291c;
    }
}
