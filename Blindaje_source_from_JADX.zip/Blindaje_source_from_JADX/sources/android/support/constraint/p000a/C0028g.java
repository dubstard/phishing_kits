package android.support.constraint.p000a;

import java.util.Arrays;

/* renamed from: android.support.constraint.a.g */
public class C0028g {

    /* renamed from: i */
    private static int f305i = 1;

    /* renamed from: a */
    public int f306a = -1;

    /* renamed from: b */
    int f307b = -1;

    /* renamed from: c */
    public int f308c = 0;

    /* renamed from: d */
    public float f309d;

    /* renamed from: e */
    float[] f310e = new float[6];

    /* renamed from: f */
    C0029a f311f;

    /* renamed from: g */
    C0021b[] f312g = new C0021b[8];

    /* renamed from: h */
    int f313h = 0;

    /* renamed from: j */
    private String f314j;

    /* renamed from: android.support.constraint.a.g$a */
    public enum C0029a {
        UNRESTRICTED,
        CONSTANT,
        SLACK,
        ERROR,
        UNKNOWN
    }

    public C0028g(C0029a aVar) {
        this.f311f = aVar;
    }

    /* access modifiers changed from: 0000 */
    /* renamed from: a */
    public void mo196a() {
        for (int i = 0; i < 6; i++) {
            this.f310e[i] = 0.0f;
        }
    }

    /* access modifiers changed from: 0000 */
    /* renamed from: a */
    public void mo197a(C0021b bVar) {
        int i = 0;
        while (i < this.f313h) {
            if (this.f312g[i] != bVar) {
                i++;
            } else {
                return;
            }
        }
        if (this.f313h >= this.f312g.length) {
            this.f312g = (C0021b[]) Arrays.copyOf(this.f312g, this.f312g.length * 2);
        }
        this.f312g[this.f313h] = bVar;
        this.f313h++;
    }

    /* renamed from: a */
    public void mo198a(C0029a aVar) {
        this.f311f = aVar;
    }

    /* access modifiers changed from: 0000 */
    /* renamed from: b */
    public String mo199b() {
        StringBuilder sb;
        String str;
        StringBuilder sb2 = new StringBuilder();
        sb2.append(this);
        sb2.append("[");
        String sb3 = sb2.toString();
        for (int i = 0; i < this.f310e.length; i++) {
            StringBuilder sb4 = new StringBuilder();
            sb4.append(sb3);
            sb4.append(this.f310e[i]);
            String sb5 = sb4.toString();
            if (i < this.f310e.length - 1) {
                sb = new StringBuilder();
                sb.append(sb5);
                str = ", ";
            } else {
                sb = new StringBuilder();
                sb.append(sb5);
                str = "] ";
            }
            sb.append(str);
            sb3 = sb.toString();
        }
        return sb3;
    }

    /* access modifiers changed from: 0000 */
    /* renamed from: b */
    public void mo200b(C0021b bVar) {
        for (int i = 0; i < this.f313h; i++) {
            if (this.f312g[i] == bVar) {
                for (int i2 = 0; i2 < (this.f313h - i) - 1; i2++) {
                    int i3 = i + i2;
                    this.f312g[i3] = this.f312g[i3 + 1];
                }
                this.f313h--;
                return;
            }
        }
    }

    /* renamed from: c */
    public void mo201c() {
        this.f314j = null;
        this.f311f = C0029a.UNKNOWN;
        this.f308c = 0;
        this.f306a = -1;
        this.f307b = -1;
        this.f309d = 0.0f;
        this.f313h = 0;
    }

    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append("");
        sb.append(this.f314j);
        return sb.toString();
    }
}
