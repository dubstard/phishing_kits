package android.support.constraint.p000a;

/* renamed from: android.support.constraint.a.c */
public class C0022c {

    /* renamed from: a */
    C0026a<C0021b> f284a = new C0027b(256);

    /* renamed from: b */
    C0026a<C0028g> f285b = new C0027b(256);

    /* renamed from: c */
    C0028g[] f286c = new C0028g[32];
}
