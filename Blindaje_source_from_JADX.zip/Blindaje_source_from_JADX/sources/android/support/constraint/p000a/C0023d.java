package android.support.constraint.p000a;

import android.support.constraint.p000a.C0028g.C0029a;
import java.util.ArrayList;

/* renamed from: android.support.constraint.a.d */
public class C0023d {

    /* renamed from: a */
    ArrayList<C0028g> f287a = new ArrayList<>();

    /* renamed from: b */
    private void m181b(C0024e eVar) {
        this.f287a.clear();
        for (int i = 1; i < eVar.f290b; i++) {
            C0028g gVar = eVar.f291c.f286c[i];
            for (int i2 = 0; i2 < 6; i2++) {
                gVar.f310e[i2] = 0.0f;
            }
            gVar.f310e[gVar.f308c] = 1.0f;
            if (gVar.f311f == C0029a.ERROR) {
                this.f287a.add(gVar);
            }
        }
    }

    /* access modifiers changed from: 0000 */
    /* renamed from: a */
    public C0028g mo174a() {
        int size = this.f287a.size();
        C0028g gVar = null;
        int i = 0;
        for (int i2 = 0; i2 < size; i2++) {
            C0028g gVar2 = (C0028g) this.f287a.get(i2);
            for (int i3 = 5; i3 >= 0; i3--) {
                float f = gVar2.f310e[i3];
                if (gVar == null && f < 0.0f && i3 >= i) {
                    gVar = gVar2;
                    i = i3;
                }
                if (f > 0.0f && i3 > i) {
                    gVar = null;
                    i = i3;
                }
            }
        }
        return gVar;
    }

    /* access modifiers changed from: 0000 */
    /* renamed from: a */
    public void mo175a(C0024e eVar) {
        m181b(eVar);
        int size = this.f287a.size();
        for (int i = 0; i < size; i++) {
            C0028g gVar = (C0028g) this.f287a.get(i);
            if (gVar.f307b != -1) {
                C0004a aVar = eVar.mo177a(gVar.f307b).f282d;
                int i2 = aVar.f126a;
                for (int i3 = 0; i3 < i2; i3++) {
                    C0028g a = aVar.mo34a(i3);
                    if (a != null) {
                        float b = aVar.mo41b(i3);
                        for (int i4 = 0; i4 < 6; i4++) {
                            float[] fArr = a.f310e;
                            fArr[i4] = fArr[i4] + (gVar.f310e[i4] * b);
                        }
                        if (!this.f287a.contains(a)) {
                            this.f287a.add(a);
                        }
                    }
                }
                gVar.mo196a();
            }
        }
    }

    public String toString() {
        String str = "Goal: ";
        int size = this.f287a.size();
        for (int i = 0; i < size; i++) {
            C0028g gVar = (C0028g) this.f287a.get(i);
            StringBuilder sb = new StringBuilder();
            sb.append(str);
            sb.append(gVar.mo199b());
            str = sb.toString();
        }
        return str;
    }
}
