package android.support.constraint.p000a;

import java.util.Arrays;

/* renamed from: android.support.constraint.a.a */
public class C0004a {

    /* renamed from: a */
    int f126a = 0;

    /* renamed from: b */
    private final C0021b f127b;

    /* renamed from: c */
    private final C0022c f128c;

    /* renamed from: d */
    private int f129d = 8;

    /* renamed from: e */
    private C0028g f130e = null;

    /* renamed from: f */
    private int[] f131f = new int[this.f129d];

    /* renamed from: g */
    private int[] f132g = new int[this.f129d];

    /* renamed from: h */
    private float[] f133h = new float[this.f129d];

    /* renamed from: i */
    private int f134i = -1;

    /* renamed from: j */
    private int f135j = -1;

    /* renamed from: k */
    private boolean f136k = false;

    C0004a(C0021b bVar, C0022c cVar) {
        this.f127b = bVar;
        this.f128c = cVar;
    }

    /* renamed from: a */
    public final float mo33a(C0028g gVar) {
        if (this.f130e == gVar) {
            this.f130e = null;
        }
        if (this.f134i == -1) {
            return 0.0f;
        }
        int i = this.f134i;
        int i2 = 0;
        int i3 = -1;
        while (i != -1 && i2 < this.f126a) {
            int i4 = this.f131f[i];
            if (i4 == gVar.f306a) {
                if (i == this.f134i) {
                    this.f134i = this.f132g[i];
                } else {
                    this.f132g[i3] = this.f132g[i];
                }
                this.f128c.f286c[i4].mo200b(this.f127b);
                this.f126a--;
                this.f131f[i] = -1;
                if (this.f136k) {
                    this.f135j = i;
                }
                return this.f133h[i];
            }
            i2++;
            i3 = i;
            i = this.f132g[i];
        }
        return 0.0f;
    }

    /* access modifiers changed from: 0000 */
    /* renamed from: a */
    public final C0028g mo34a(int i) {
        int i2 = this.f134i;
        int i3 = 0;
        while (i2 != -1 && i3 < this.f126a) {
            if (i3 == i) {
                return this.f128c.f286c[this.f131f[i2]];
            }
            i2 = this.f132g[i2];
            i3++;
        }
        return null;
    }

    /* renamed from: a */
    public final void mo35a() {
        this.f134i = -1;
        this.f135j = -1;
        this.f136k = false;
        this.f126a = 0;
    }

    /* access modifiers changed from: 0000 */
    /* renamed from: a */
    public void mo36a(float f) {
        int i = this.f134i;
        int i2 = 0;
        while (i != -1 && i2 < this.f126a) {
            float[] fArr = this.f133h;
            fArr[i] = fArr[i] / f;
            i = this.f132g[i];
            i2++;
        }
    }

    /* access modifiers changed from: 0000 */
    /* renamed from: a */
    public void mo37a(C0021b bVar) {
        int i = this.f134i;
        int i2 = 0;
        while (i != -1 && i2 < this.f126a) {
            this.f128c.f286c[this.f131f[i]].mo197a(bVar);
            i = this.f132g[i];
            i2++;
        }
    }

    /* access modifiers changed from: 0000 */
    /* renamed from: a */
    public void mo38a(C0021b bVar, C0021b bVar2) {
        int i = this.f134i;
        while (true) {
            int i2 = 0;
            while (i != -1 && i2 < this.f126a) {
                if (this.f131f[i] == bVar2.f279a.f306a) {
                    float f = this.f133h[i];
                    mo33a(bVar2.f279a);
                    C0004a aVar = bVar2.f282d;
                    int i3 = aVar.f134i;
                    int i4 = 0;
                    while (i3 != -1 && i4 < aVar.f126a) {
                        mo43b(this.f128c.f286c[aVar.f131f[i3]], aVar.f133h[i3] * f);
                        i3 = aVar.f132g[i3];
                        i4++;
                    }
                    bVar.f280b += bVar2.f280b * f;
                    bVar2.f279a.mo200b(bVar);
                    i = this.f134i;
                } else {
                    i = this.f132g[i];
                    i2++;
                }
            }
            return;
        }
    }

    /* access modifiers changed from: 0000 */
    /* renamed from: a */
    public void mo39a(C0021b bVar, C0021b[] bVarArr) {
        int i = this.f134i;
        while (true) {
            int i2 = 0;
            while (i != -1 && i2 < this.f126a) {
                C0028g gVar = this.f128c.f286c[this.f131f[i]];
                if (gVar.f307b != -1) {
                    float f = this.f133h[i];
                    mo33a(gVar);
                    C0021b bVar2 = bVarArr[gVar.f307b];
                    if (!bVar2.f283e) {
                        C0004a aVar = bVar2.f282d;
                        int i3 = aVar.f134i;
                        int i4 = 0;
                        while (i3 != -1 && i4 < aVar.f126a) {
                            mo43b(this.f128c.f286c[aVar.f131f[i3]], aVar.f133h[i3] * f);
                            i3 = aVar.f132g[i3];
                            i4++;
                        }
                    }
                    bVar.f280b += bVar2.f280b * f;
                    bVar2.f279a.mo200b(bVar);
                    i = this.f134i;
                } else {
                    i = this.f132g[i];
                    i2++;
                }
            }
            return;
        }
    }

    /* renamed from: a */
    public final void mo40a(C0028g gVar, float f) {
        if (f == 0.0f) {
            mo33a(gVar);
        } else if (this.f134i == -1) {
            this.f134i = 0;
            this.f133h[this.f134i] = f;
            this.f131f[this.f134i] = gVar.f306a;
            this.f132g[this.f134i] = -1;
            this.f126a++;
            if (!this.f136k) {
                this.f135j++;
            }
        } else {
            int i = this.f134i;
            int i2 = 0;
            int i3 = -1;
            while (i != -1 && i2 < this.f126a) {
                if (this.f131f[i] == gVar.f306a) {
                    this.f133h[i] = f;
                    return;
                }
                if (this.f131f[i] < gVar.f306a) {
                    i3 = i;
                }
                i = this.f132g[i];
                i2++;
            }
            int i4 = this.f135j + 1;
            if (this.f136k) {
                i4 = this.f131f[this.f135j] == -1 ? this.f135j : this.f131f.length;
            }
            if (i4 >= this.f131f.length && this.f126a < this.f131f.length) {
                int i5 = 0;
                while (true) {
                    if (i5 >= this.f131f.length) {
                        break;
                    } else if (this.f131f[i5] == -1) {
                        i4 = i5;
                        break;
                    } else {
                        i5++;
                    }
                }
            }
            if (i4 >= this.f131f.length) {
                i4 = this.f131f.length;
                this.f129d *= 2;
                this.f136k = false;
                this.f135j = i4 - 1;
                this.f133h = Arrays.copyOf(this.f133h, this.f129d);
                this.f131f = Arrays.copyOf(this.f131f, this.f129d);
                this.f132g = Arrays.copyOf(this.f132g, this.f129d);
            }
            this.f131f[i4] = gVar.f306a;
            this.f133h[i4] = f;
            if (i3 != -1) {
                this.f132g[i4] = this.f132g[i3];
                this.f132g[i3] = i4;
            } else {
                this.f132g[i4] = this.f134i;
                this.f134i = i4;
            }
            this.f126a++;
            if (!this.f136k) {
                this.f135j++;
            }
            if (this.f126a >= this.f131f.length) {
                this.f136k = true;
            }
        }
    }

    /* access modifiers changed from: 0000 */
    /* renamed from: b */
    public final float mo41b(int i) {
        int i2 = this.f134i;
        int i3 = 0;
        while (i2 != -1 && i3 < this.f126a) {
            if (i3 == i) {
                return this.f133h[i2];
            }
            i2 = this.f132g[i2];
            i3++;
        }
        return 0.0f;
    }

    /* access modifiers changed from: 0000 */
    /* renamed from: b */
    public void mo42b() {
        int i = this.f134i;
        int i2 = 0;
        while (i != -1 && i2 < this.f126a) {
            float[] fArr = this.f133h;
            fArr[i] = fArr[i] * -1.0f;
            i = this.f132g[i];
            i2++;
        }
    }

    /* renamed from: b */
    public final void mo43b(C0028g gVar, float f) {
        if (f != 0.0f) {
            if (this.f134i == -1) {
                this.f134i = 0;
                this.f133h[this.f134i] = f;
                this.f131f[this.f134i] = gVar.f306a;
                this.f132g[this.f134i] = -1;
                this.f126a++;
                if (!this.f136k) {
                    this.f135j++;
                }
                return;
            }
            int i = this.f134i;
            int i2 = 0;
            int i3 = -1;
            while (i != -1 && i2 < this.f126a) {
                int i4 = this.f131f[i];
                if (i4 == gVar.f306a) {
                    float[] fArr = this.f133h;
                    fArr[i] = fArr[i] + f;
                    if (this.f133h[i] == 0.0f) {
                        if (i == this.f134i) {
                            this.f134i = this.f132g[i];
                        } else {
                            this.f132g[i3] = this.f132g[i];
                        }
                        this.f128c.f286c[i4].mo200b(this.f127b);
                        if (this.f136k) {
                            this.f135j = i;
                        }
                        this.f126a--;
                    }
                    return;
                }
                if (this.f131f[i] < gVar.f306a) {
                    i3 = i;
                }
                i = this.f132g[i];
                i2++;
            }
            int i5 = this.f135j + 1;
            if (this.f136k) {
                i5 = this.f131f[this.f135j] == -1 ? this.f135j : this.f131f.length;
            }
            if (i5 >= this.f131f.length && this.f126a < this.f131f.length) {
                int i6 = 0;
                while (true) {
                    if (i6 >= this.f131f.length) {
                        break;
                    } else if (this.f131f[i6] == -1) {
                        i5 = i6;
                        break;
                    } else {
                        i6++;
                    }
                }
            }
            if (i5 >= this.f131f.length) {
                i5 = this.f131f.length;
                this.f129d *= 2;
                this.f136k = false;
                this.f135j = i5 - 1;
                this.f133h = Arrays.copyOf(this.f133h, this.f129d);
                this.f131f = Arrays.copyOf(this.f131f, this.f129d);
                this.f132g = Arrays.copyOf(this.f132g, this.f129d);
            }
            this.f131f[i5] = gVar.f306a;
            this.f133h[i5] = f;
            if (i3 != -1) {
                this.f132g[i5] = this.f132g[i3];
                this.f132g[i3] = i5;
            } else {
                this.f132g[i5] = this.f134i;
                this.f134i = i5;
            }
            this.f126a++;
            if (!this.f136k) {
                this.f135j++;
            }
            if (this.f135j >= this.f131f.length) {
                this.f136k = true;
                this.f135j = this.f131f.length - 1;
            }
        }
    }

    /* access modifiers changed from: 0000 */
    /* renamed from: b */
    public final boolean mo44b(C0028g gVar) {
        if (this.f134i == -1) {
            return false;
        }
        int i = this.f134i;
        int i2 = 0;
        while (i != -1 && i2 < this.f126a) {
            if (this.f131f[i] == gVar.f306a) {
                return true;
            }
            i = this.f132g[i];
            i2++;
        }
        return false;
    }

    /* renamed from: c */
    public final float mo45c(C0028g gVar) {
        int i = this.f134i;
        int i2 = 0;
        while (i != -1 && i2 < this.f126a) {
            if (this.f131f[i] == gVar.f306a) {
                return this.f133h[i];
            }
            i = this.f132g[i];
            i2++;
        }
        return 0.0f;
    }

    /* access modifiers changed from: 0000 */
    /* JADX WARNING: Removed duplicated region for block: B:16:0x0032  */
    /* JADX WARNING: Removed duplicated region for block: B:37:0x0058 A[SYNTHETIC] */
    /* renamed from: c */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public android.support.constraint.p000a.C0028g mo46c() {
        /*
            r9 = this;
            int r0 = r9.f134i
            r1 = 0
            r2 = 0
            r3 = r1
        L_0x0005:
            r4 = -1
            if (r0 == r4) goto L_0x005f
            int r4 = r9.f126a
            if (r2 >= r4) goto L_0x005f
            float[] r4 = r9.f133h
            r4 = r4[r0]
            r5 = 981668463(0x3a83126f, float:0.001)
            r6 = 0
            int r7 = (r4 > r6 ? 1 : (r4 == r6 ? 0 : -1))
            if (r7 >= 0) goto L_0x0025
            r5 = -1165815185(0xffffffffba83126f, float:-0.001)
            int r5 = (r4 > r5 ? 1 : (r4 == r5 ? 0 : -1))
            if (r5 <= 0) goto L_0x002e
            float[] r4 = r9.f133h
            r4[r0] = r6
        L_0x0023:
            r4 = 0
            goto L_0x002e
        L_0x0025:
            int r5 = (r4 > r5 ? 1 : (r4 == r5 ? 0 : -1))
            if (r5 >= 0) goto L_0x002e
            float[] r4 = r9.f133h
            r4[r0] = r6
            goto L_0x0023
        L_0x002e:
            int r5 = (r4 > r6 ? 1 : (r4 == r6 ? 0 : -1))
            if (r5 == 0) goto L_0x0058
            android.support.constraint.a.c r5 = r9.f128c
            android.support.constraint.a.g[] r5 = r5.f286c
            int[] r7 = r9.f131f
            r7 = r7[r0]
            r5 = r5[r7]
            android.support.constraint.a.g$a r7 = r5.f311f
            android.support.constraint.a.g$a r8 = android.support.constraint.p000a.C0028g.C0029a.UNRESTRICTED
            if (r7 != r8) goto L_0x004b
            int r4 = (r4 > r6 ? 1 : (r4 == r6 ? 0 : -1))
            if (r4 >= 0) goto L_0x0047
            return r5
        L_0x0047:
            if (r1 != 0) goto L_0x0058
            r1 = r5
            goto L_0x0058
        L_0x004b:
            int r4 = (r4 > r6 ? 1 : (r4 == r6 ? 0 : -1))
            if (r4 >= 0) goto L_0x0058
            if (r3 == 0) goto L_0x0057
            int r4 = r5.f308c
            int r6 = r3.f308c
            if (r4 >= r6) goto L_0x0058
        L_0x0057:
            r3 = r5
        L_0x0058:
            int[] r4 = r9.f132g
            r0 = r4[r0]
            int r2 = r2 + 1
            goto L_0x0005
        L_0x005f:
            if (r1 == 0) goto L_0x0062
            return r1
        L_0x0062:
            return r3
        */
        throw new UnsupportedOperationException("Method not decompiled: android.support.constraint.p000a.C0004a.mo46c():android.support.constraint.a.g");
    }

    public String toString() {
        String str = "";
        int i = this.f134i;
        int i2 = 0;
        while (i != -1 && i2 < this.f126a) {
            StringBuilder sb = new StringBuilder();
            sb.append(str);
            sb.append(" -> ");
            String sb2 = sb.toString();
            StringBuilder sb3 = new StringBuilder();
            sb3.append(sb2);
            sb3.append(this.f133h[i]);
            sb3.append(" : ");
            String sb4 = sb3.toString();
            StringBuilder sb5 = new StringBuilder();
            sb5.append(sb4);
            sb5.append(this.f128c.f286c[this.f131f[i]]);
            str = sb5.toString();
            i = this.f132g[i];
            i2++;
        }
        return str;
    }
}
