package android.support.constraint.p000a;

/* renamed from: android.support.constraint.a.f */
final class C0025f {

    /* renamed from: android.support.constraint.a.f$a */
    interface C0026a<T> {
        /* renamed from: a */
        T mo193a();

        /* renamed from: a */
        void mo194a(T[] tArr, int i);

        /* renamed from: a */
        boolean mo195a(T t);
    }

    /* renamed from: android.support.constraint.a.f$b */
    static class C0027b<T> implements C0026a<T> {

        /* renamed from: a */
        private final Object[] f303a;

        /* renamed from: b */
        private int f304b;

        C0027b(int i) {
            if (i <= 0) {
                throw new IllegalArgumentException("The max pool size must be > 0");
            }
            this.f303a = new Object[i];
        }

        /* renamed from: a */
        public T mo193a() {
            if (this.f304b <= 0) {
                return null;
            }
            int i = this.f304b - 1;
            T t = this.f303a[i];
            this.f303a[i] = null;
            this.f304b--;
            return t;
        }

        /* renamed from: a */
        public void mo194a(T[] tArr, int i) {
            if (i > tArr.length) {
                i = tArr.length;
            }
            for (int i2 = 0; i2 < i; i2++) {
                T t = tArr[i2];
                if (this.f304b < this.f303a.length) {
                    this.f303a[this.f304b] = t;
                    this.f304b++;
                }
            }
        }

        /* renamed from: a */
        public boolean mo195a(T t) {
            if (this.f304b >= this.f303a.length) {
                return false;
            }
            this.f303a[this.f304b] = t;
            this.f304b++;
            return true;
        }
    }
}
