package android.support.constraint.p000a;

import android.support.constraint.p000a.C0028g.C0029a;

/* renamed from: android.support.constraint.a.b */
public class C0021b {

    /* renamed from: a */
    C0028g f279a = null;

    /* renamed from: b */
    float f280b = 0.0f;

    /* renamed from: c */
    boolean f281c = false;

    /* renamed from: d */
    final C0004a f282d;

    /* renamed from: e */
    boolean f283e = false;

    public C0021b(C0022c cVar) {
        this.f282d = new C0004a(this, cVar);
    }

    /* renamed from: a */
    public C0021b mo153a(float f, float f2, float f3, C0028g gVar, int i, C0028g gVar2, int i2, C0028g gVar3, int i3, C0028g gVar4, int i4) {
        if (f2 == 0.0f || f == f3) {
            this.f280b = (float) (((-i) - i2) + i3 + i4);
            this.f282d.mo40a(gVar, 1.0f);
            this.f282d.mo40a(gVar2, -1.0f);
            this.f282d.mo40a(gVar4, 1.0f);
            this.f282d.mo40a(gVar3, -1.0f);
            return this;
        }
        float f4 = (f / f2) / (f3 / f2);
        this.f280b = ((float) ((-i) - i2)) + (((float) i3) * f4) + (((float) i4) * f4);
        this.f282d.mo40a(gVar, 1.0f);
        this.f282d.mo40a(gVar2, -1.0f);
        this.f282d.mo40a(gVar4, f4);
        this.f282d.mo40a(gVar3, -f4);
        return this;
    }

    /* access modifiers changed from: 0000 */
    /* renamed from: a */
    public C0021b mo154a(C0028g gVar, int i) {
        this.f279a = gVar;
        float f = (float) i;
        gVar.f309d = f;
        this.f280b = f;
        this.f283e = true;
        return this;
    }

    /* renamed from: a */
    public C0021b mo155a(C0028g gVar, C0028g gVar2) {
        this.f282d.mo40a(gVar, 1.0f);
        this.f282d.mo40a(gVar2, -1.0f);
        return this;
    }

    /* renamed from: a */
    public C0021b mo156a(C0028g gVar, C0028g gVar2, int i) {
        boolean z = false;
        if (i != 0) {
            if (i < 0) {
                i *= -1;
                z = true;
            }
            this.f280b = (float) i;
        }
        if (!z) {
            this.f282d.mo40a(gVar, -1.0f);
            this.f282d.mo40a(gVar2, 1.0f);
            return this;
        }
        this.f282d.mo40a(gVar, 1.0f);
        this.f282d.mo40a(gVar2, -1.0f);
        return this;
    }

    /* access modifiers changed from: 0000 */
    /* renamed from: a */
    public C0021b mo157a(C0028g gVar, C0028g gVar2, int i, float f, C0028g gVar3, C0028g gVar4, int i2) {
        float f2;
        if (gVar2 == gVar3) {
            this.f282d.mo40a(gVar, 1.0f);
            this.f282d.mo40a(gVar4, 1.0f);
            this.f282d.mo40a(gVar2, -2.0f);
            return this;
        }
        if (f == 0.5f) {
            this.f282d.mo40a(gVar, 1.0f);
            this.f282d.mo40a(gVar2, -1.0f);
            this.f282d.mo40a(gVar3, -1.0f);
            this.f282d.mo40a(gVar4, 1.0f);
            if (i > 0 || i2 > 0) {
                f2 = (float) ((-i) + i2);
            }
            return this;
        } else if (f <= 0.0f) {
            this.f282d.mo40a(gVar, -1.0f);
            this.f282d.mo40a(gVar2, 1.0f);
            f2 = (float) i;
        } else if (f >= 1.0f) {
            this.f282d.mo40a(gVar3, -1.0f);
            this.f282d.mo40a(gVar4, 1.0f);
            f2 = (float) i2;
        } else {
            float f3 = 1.0f - f;
            this.f282d.mo40a(gVar, f3 * 1.0f);
            this.f282d.mo40a(gVar2, f3 * -1.0f);
            this.f282d.mo40a(gVar3, -1.0f * f);
            this.f282d.mo40a(gVar4, 1.0f * f);
            if (i > 0 || i2 > 0) {
                f2 = (((float) (-i)) * f3) + (((float) i2) * f);
            }
            return this;
        }
        this.f280b = f2;
        return this;
    }

    /* access modifiers changed from: 0000 */
    /* renamed from: a */
    public C0021b mo158a(C0028g gVar, C0028g gVar2, C0028g gVar3, float f) {
        this.f282d.mo40a(gVar, -1.0f);
        this.f282d.mo40a(gVar2, 1.0f - f);
        this.f282d.mo40a(gVar3, f);
        return this;
    }

    /* renamed from: a */
    public C0021b mo159a(C0028g gVar, C0028g gVar2, C0028g gVar3, int i) {
        boolean z = false;
        if (i != 0) {
            if (i < 0) {
                i *= -1;
                z = true;
            }
            this.f280b = (float) i;
        }
        if (!z) {
            this.f282d.mo40a(gVar, -1.0f);
            this.f282d.mo40a(gVar2, 1.0f);
            this.f282d.mo40a(gVar3, 1.0f);
            return this;
        }
        this.f282d.mo40a(gVar, 1.0f);
        this.f282d.mo40a(gVar2, -1.0f);
        this.f282d.mo40a(gVar3, -1.0f);
        return this;
    }

    /* renamed from: a */
    public C0021b mo160a(C0028g gVar, C0028g gVar2, C0028g gVar3, C0028g gVar4, float f) {
        this.f282d.mo40a(gVar, -1.0f);
        this.f282d.mo40a(gVar2, 1.0f);
        this.f282d.mo40a(gVar3, f);
        this.f282d.mo40a(gVar4, -f);
        return this;
    }

    /* access modifiers changed from: 0000 */
    /* renamed from: a */
    public void mo161a() {
        this.f282d.mo37a(this);
    }

    /* access modifiers changed from: 0000 */
    /* renamed from: a */
    public boolean mo162a(C0021b bVar) {
        this.f282d.mo38a(this, bVar);
        return true;
    }

    /* access modifiers changed from: 0000 */
    /* renamed from: a */
    public boolean mo163a(C0028g gVar) {
        return this.f282d.mo44b(gVar);
    }

    /* renamed from: b */
    public C0021b mo164b(C0028g gVar, int i) {
        C0004a aVar;
        float f;
        if (i < 0) {
            this.f280b = (float) (i * -1);
            aVar = this.f282d;
            f = 1.0f;
        } else {
            this.f280b = (float) i;
            aVar = this.f282d;
            f = -1.0f;
        }
        aVar.mo40a(gVar, f);
        return this;
    }

    /* renamed from: b */
    public C0021b mo165b(C0028g gVar, C0028g gVar2, C0028g gVar3, int i) {
        boolean z = false;
        if (i != 0) {
            if (i < 0) {
                i *= -1;
                z = true;
            }
            this.f280b = (float) i;
        }
        if (!z) {
            this.f282d.mo40a(gVar, -1.0f);
            this.f282d.mo40a(gVar2, 1.0f);
            this.f282d.mo40a(gVar3, -1.0f);
            return this;
        }
        this.f282d.mo40a(gVar, 1.0f);
        this.f282d.mo40a(gVar2, -1.0f);
        this.f282d.mo40a(gVar3, 1.0f);
        return this;
    }

    /* access modifiers changed from: 0000 */
    /* renamed from: b */
    public void mo166b(C0028g gVar) {
        if (this.f279a != null) {
            this.f282d.mo40a(this.f279a, -1.0f);
            this.f279a = null;
        }
        float a = this.f282d.mo33a(gVar) * -1.0f;
        this.f279a = gVar;
        if (a != 1.0f) {
            this.f280b /= a;
            this.f282d.mo36a(a);
        }
    }

    /* access modifiers changed from: 0000 */
    /* renamed from: b */
    public boolean mo167b() {
        return this.f279a != null && (this.f279a.f311f == C0029a.UNRESTRICTED || this.f280b >= 0.0f);
    }

    /* access modifiers changed from: 0000 */
    /* renamed from: c */
    public C0021b mo168c(C0028g gVar, int i) {
        this.f282d.mo40a(gVar, (float) i);
        return this;
    }

    /* access modifiers changed from: 0000 */
    /* JADX WARNING: Removed duplicated region for block: B:25:0x00b0  */
    /* JADX WARNING: Removed duplicated region for block: B:27:0x00c0  */
    /* renamed from: c */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public java.lang.String mo169c() {
        /*
            r9 = this;
            java.lang.String r0 = ""
            android.support.constraint.a.g r1 = r9.f279a
            if (r1 != 0) goto L_0x0018
            java.lang.StringBuilder r1 = new java.lang.StringBuilder
            r1.<init>()
            r1.append(r0)
            java.lang.String r0 = "0"
            r1.append(r0)
        L_0x0013:
            java.lang.String r0 = r1.toString()
            goto L_0x0026
        L_0x0018:
            java.lang.StringBuilder r1 = new java.lang.StringBuilder
            r1.<init>()
            r1.append(r0)
            android.support.constraint.a.g r0 = r9.f279a
            r1.append(r0)
            goto L_0x0013
        L_0x0026:
            java.lang.StringBuilder r1 = new java.lang.StringBuilder
            r1.<init>()
            r1.append(r0)
            java.lang.String r0 = " = "
            r1.append(r0)
            java.lang.String r0 = r1.toString()
            float r1 = r9.f280b
            r2 = 0
            int r1 = (r1 > r2 ? 1 : (r1 == r2 ? 0 : -1))
            r3 = 0
            r4 = 1
            if (r1 == 0) goto L_0x0053
            java.lang.StringBuilder r1 = new java.lang.StringBuilder
            r1.<init>()
            r1.append(r0)
            float r0 = r9.f280b
            r1.append(r0)
            java.lang.String r0 = r1.toString()
            r1 = 1
            goto L_0x0054
        L_0x0053:
            r1 = 0
        L_0x0054:
            android.support.constraint.a.a r5 = r9.f282d
            int r5 = r5.f126a
        L_0x0058:
            if (r3 >= r5) goto L_0x00d2
            android.support.constraint.a.a r6 = r9.f282d
            android.support.constraint.a.g r6 = r6.mo34a(r3)
            if (r6 != 0) goto L_0x0063
            goto L_0x00cf
        L_0x0063:
            android.support.constraint.a.a r7 = r9.f282d
            float r7 = r7.mo41b(r3)
            java.lang.String r6 = r6.toString()
            r8 = -1082130432(0xffffffffbf800000, float:-1.0)
            if (r1 != 0) goto L_0x0089
            int r1 = (r7 > r2 ? 1 : (r7 == r2 ? 0 : -1))
            if (r1 >= 0) goto L_0x00aa
            java.lang.StringBuilder r1 = new java.lang.StringBuilder
            r1.<init>()
            r1.append(r0)
            java.lang.String r0 = "- "
        L_0x007f:
            r1.append(r0)
            java.lang.String r0 = r1.toString()
            float r7 = r7 * r8
            goto L_0x00aa
        L_0x0089:
            int r1 = (r7 > r2 ? 1 : (r7 == r2 ? 0 : -1))
            if (r1 <= 0) goto L_0x009f
            java.lang.StringBuilder r1 = new java.lang.StringBuilder
            r1.<init>()
            r1.append(r0)
            java.lang.String r0 = " + "
            r1.append(r0)
            java.lang.String r0 = r1.toString()
            goto L_0x00aa
        L_0x009f:
            java.lang.StringBuilder r1 = new java.lang.StringBuilder
            r1.<init>()
            r1.append(r0)
            java.lang.String r0 = " - "
            goto L_0x007f
        L_0x00aa:
            r1 = 1065353216(0x3f800000, float:1.0)
            int r1 = (r7 > r1 ? 1 : (r7 == r1 ? 0 : -1))
            if (r1 != 0) goto L_0x00c0
            java.lang.StringBuilder r1 = new java.lang.StringBuilder
            r1.<init>()
        L_0x00b5:
            r1.append(r0)
            r1.append(r6)
            java.lang.String r0 = r1.toString()
            goto L_0x00ce
        L_0x00c0:
            java.lang.StringBuilder r1 = new java.lang.StringBuilder
            r1.<init>()
            r1.append(r0)
            r1.append(r7)
            java.lang.String r0 = " "
            goto L_0x00b5
        L_0x00ce:
            r1 = 1
        L_0x00cf:
            int r3 = r3 + 1
            goto L_0x0058
        L_0x00d2:
            if (r1 != 0) goto L_0x00e5
            java.lang.StringBuilder r1 = new java.lang.StringBuilder
            r1.<init>()
            r1.append(r0)
            java.lang.String r0 = "0.0"
            r1.append(r0)
            java.lang.String r0 = r1.toString()
        L_0x00e5:
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: android.support.constraint.p000a.C0021b.mo169c():java.lang.String");
    }

    /* renamed from: d */
    public void mo170d() {
        this.f279a = null;
        this.f282d.mo35a();
        this.f280b = 0.0f;
        this.f283e = false;
    }

    /* access modifiers changed from: 0000 */
    /* renamed from: e */
    public void mo171e() {
        if (this.f280b < 0.0f) {
            this.f280b *= -1.0f;
            this.f282d.mo42b();
        }
    }

    /* access modifiers changed from: 0000 */
    /* renamed from: f */
    public void mo172f() {
        C0028g c = this.f282d.mo46c();
        if (c != null) {
            mo166b(c);
        }
        if (this.f282d.f126a == 0) {
            this.f283e = true;
        }
    }

    public String toString() {
        return mo169c();
    }
}
