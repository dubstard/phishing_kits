package android.support.constraint.p000a.p001a;

import android.support.constraint.p000a.C0021b;
import android.support.constraint.p000a.C0024e;
import android.support.constraint.p000a.C0028g;
import android.support.constraint.p000a.p001a.C0005a.C0009c;
import java.util.ArrayList;

/* renamed from: android.support.constraint.a.a.d */
public class C0014d extends C0010b {

    /* renamed from: aa */
    protected float f258aa = -1.0f;

    /* renamed from: ab */
    protected int f259ab = -1;

    /* renamed from: ac */
    protected int f260ac = -1;

    /* renamed from: ad */
    private C0005a f261ad = this.f215j;

    /* renamed from: ae */
    private int f262ae = 0;

    /* renamed from: af */
    private boolean f263af = false;

    /* renamed from: ag */
    private int f264ag = 0;

    /* renamed from: ah */
    private C0017f f265ah = new C0017f();

    /* renamed from: ai */
    private int f266ai = 8;

    public C0014d() {
        this.f222q.clear();
        this.f222q.add(this.f261ad);
    }

    /* renamed from: D */
    public int mo127D() {
        return this.f262ae;
    }

    /* renamed from: E */
    public float mo138E() {
        return this.f258aa;
    }

    /* renamed from: F */
    public int mo139F() {
        return this.f259ab;
    }

    /* renamed from: G */
    public int mo140G() {
        return this.f260ac;
    }

    /* renamed from: a */
    public C0005a mo67a(C0009c cVar) {
        switch (cVar) {
            case LEFT:
            case RIGHT:
                if (this.f262ae == 1) {
                    return this.f261ad;
                }
                break;
            case TOP:
            case BOTTOM:
                if (this.f262ae == 0) {
                    return this.f261ad;
                }
                break;
        }
        return null;
    }

    /* renamed from: a */
    public void mo78a(C0024e eVar, int i) {
        C0021b a;
        C0028g a2;
        C0028g a3;
        int i2;
        C0013c cVar = (C0013c) mo88c();
        if (cVar != null) {
            C0005a a4 = cVar.mo67a(C0009c.LEFT);
            C0005a a5 = cVar.mo67a(C0009c.RIGHT);
            if (this.f262ae == 0) {
                a4 = cVar.mo67a(C0009c.TOP);
                a5 = cVar.mo67a(C0009c.BOTTOM);
            }
            if (this.f259ab != -1) {
                a2 = eVar.mo178a((Object) this.f261ad);
                a3 = eVar.mo178a((Object) a4);
                i2 = this.f259ab;
            } else if (this.f260ac != -1) {
                a2 = eVar.mo178a((Object) this.f261ad);
                a3 = eVar.mo178a((Object) a5);
                i2 = -this.f260ac;
            } else if (this.f258aa != -1.0f) {
                a = C0024e.m186a(eVar, eVar.mo178a((Object) this.f261ad), eVar.mo178a((Object) a4), eVar.mo178a((Object) a5), this.f258aa, this.f263af);
                eVar.mo180a(a);
            } else {
                return;
            }
            a = C0024e.m185a(eVar, a2, a3, i2, false);
            eVar.mo180a(a);
        }
    }

    /* renamed from: b */
    public void mo86b(C0024e eVar, int i) {
        if (mo88c() != null) {
            int b = eVar.mo185b((Object) this.f261ad);
            if (this.f262ae == 1) {
                mo82b(b);
                mo90c(0);
                mo97e(mo88c().mo110l());
                mo94d(0);
                return;
            }
            mo82b(0);
            mo90c(b);
            mo94d(mo88c().mo102h());
            mo97e(0);
        }
    }

    /* renamed from: e */
    public void mo141e(float f) {
        if (f > -1.0f) {
            this.f258aa = f;
            this.f259ab = -1;
            this.f260ac = -1;
        }
    }

    /* renamed from: m */
    public void mo142m(int i) {
        if (this.f262ae != i) {
            this.f262ae = i;
            this.f222q.clear();
            this.f261ad = this.f262ae == 1 ? this.f214i : this.f215j;
            this.f222q.add(this.f261ad);
        }
    }

    /* renamed from: n */
    public void mo143n(int i) {
        if (i > -1) {
            this.f258aa = -1.0f;
            this.f259ab = i;
            this.f260ac = -1;
        }
    }

    /* renamed from: o */
    public void mo144o(int i) {
        if (i > -1) {
            this.f258aa = -1.0f;
            this.f259ab = -1;
            this.f260ac = i;
        }
    }

    /* renamed from: y */
    public ArrayList<C0005a> mo125y() {
        return this.f222q;
    }
}
