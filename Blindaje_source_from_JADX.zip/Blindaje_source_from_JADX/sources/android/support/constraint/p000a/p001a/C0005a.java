package android.support.constraint.p000a.p001a;

import android.support.constraint.p000a.C0022c;
import android.support.constraint.p000a.C0028g;
import android.support.constraint.p000a.C0028g.C0029a;
import java.util.HashSet;

/* renamed from: android.support.constraint.a.a.a */
public class C0005a {

    /* renamed from: a */
    final C0010b f137a;

    /* renamed from: b */
    final C0009c f138b;

    /* renamed from: c */
    C0005a f139c;

    /* renamed from: d */
    public int f140d = 0;

    /* renamed from: e */
    int f141e = -1;

    /* renamed from: f */
    C0028g f142f;

    /* renamed from: g */
    int f143g = Integer.MAX_VALUE;

    /* renamed from: h */
    private C0008b f144h = C0008b.NONE;

    /* renamed from: i */
    private C0007a f145i = C0007a.RELAXED;

    /* renamed from: j */
    private int f146j = 0;

    /* renamed from: android.support.constraint.a.a.a$a */
    public enum C0007a {
        RELAXED,
        STRICT
    }

    /* renamed from: android.support.constraint.a.a.a$b */
    public enum C0008b {
        NONE,
        STRONG,
        WEAK
    }

    /* renamed from: android.support.constraint.a.a.a$c */
    public enum C0009c {
        NONE,
        LEFT,
        TOP,
        RIGHT,
        BOTTOM,
        BASELINE,
        CENTER,
        CENTER_X,
        CENTER_Y
    }

    public C0005a(C0010b bVar, C0009c cVar) {
        this.f137a = bVar;
        this.f138b = cVar;
    }

    /* renamed from: a */
    private String m32a(HashSet<C0005a> hashSet) {
        String str;
        if (!hashSet.add(this)) {
            return "<-";
        }
        StringBuilder sb = new StringBuilder();
        sb.append(this.f137a.mo96e());
        sb.append(":");
        sb.append(this.f138b.toString());
        if (this.f139c != null) {
            StringBuilder sb2 = new StringBuilder();
            sb2.append(" connected to ");
            sb2.append(this.f139c.m32a(hashSet));
            str = sb2.toString();
        } else {
            str = "";
        }
        sb.append(str);
        return sb.toString();
    }

    /* renamed from: a */
    public C0028g mo48a() {
        return this.f142f;
    }

    /* renamed from: a */
    public void mo49a(C0007a aVar) {
        this.f145i = aVar;
    }

    /* renamed from: a */
    public void mo50a(C0022c cVar) {
        if (this.f142f == null) {
            this.f142f = new C0028g(C0029a.UNRESTRICTED);
        } else {
            this.f142f.mo201c();
        }
    }

    /* renamed from: a */
    public boolean mo51a(C0005a aVar) {
        boolean z = false;
        if (aVar == null) {
            return false;
        }
        C0009c c = aVar.mo55c();
        if (c != this.f138b) {
            switch (this.f138b) {
                case CENTER:
                    if (!(c == C0009c.BASELINE || c == C0009c.CENTER_X || c == C0009c.CENTER_Y)) {
                        z = true;
                    }
                    return z;
                case LEFT:
                case RIGHT:
                    boolean z2 = c == C0009c.LEFT || c == C0009c.RIGHT;
                    if (aVar.mo54b() instanceof C0014d) {
                        if (!z2 && c != C0009c.CENTER_X) {
                            return false;
                        }
                        z2 = true;
                    }
                    return z2;
                case TOP:
                case BOTTOM:
                    boolean z3 = c == C0009c.TOP || c == C0009c.BOTTOM;
                    if (aVar.mo54b() instanceof C0014d) {
                        if (!z3 && c != C0009c.CENTER_Y) {
                            return false;
                        }
                        z3 = true;
                    }
                    return z3;
                default:
                    return false;
            }
        } else if (this.f138b == C0009c.CENTER) {
            return false;
        } else {
            return this.f138b != C0009c.BASELINE || (aVar.mo54b().mo122v() && mo54b().mo122v());
        }
    }

    /* renamed from: a */
    public boolean mo52a(C0005a aVar, int i, int i2, C0008b bVar, int i3, boolean z) {
        if (aVar == null) {
            this.f139c = null;
            this.f140d = 0;
            this.f141e = -1;
            this.f144h = C0008b.NONE;
            this.f146j = 2;
            return true;
        } else if (!z && !mo51a(aVar)) {
            return false;
        } else {
            this.f139c = aVar;
            if (i > 0) {
                this.f140d = i;
            } else {
                this.f140d = 0;
            }
            this.f141e = i2;
            this.f144h = bVar;
            this.f146j = i3;
            return true;
        }
    }

    /* renamed from: a */
    public boolean mo53a(C0005a aVar, int i, C0008b bVar, int i2) {
        return mo52a(aVar, i, -1, bVar, i2, false);
    }

    /* renamed from: b */
    public C0010b mo54b() {
        return this.f137a;
    }

    /* renamed from: c */
    public C0009c mo55c() {
        return this.f138b;
    }

    /* renamed from: d */
    public int mo56d() {
        if (this.f137a.mo92d() == 8) {
            return 0;
        }
        return (this.f141e <= -1 || this.f139c == null || this.f139c.f137a.mo92d() != 8) ? this.f140d : this.f141e;
    }

    /* renamed from: e */
    public C0008b mo57e() {
        return this.f144h;
    }

    /* renamed from: f */
    public C0005a mo58f() {
        return this.f139c;
    }

    /* renamed from: g */
    public C0007a mo59g() {
        return this.f145i;
    }

    /* renamed from: h */
    public int mo60h() {
        return this.f146j;
    }

    /* renamed from: i */
    public void mo61i() {
        this.f139c = null;
        this.f140d = 0;
        this.f141e = -1;
        this.f144h = C0008b.STRONG;
        this.f146j = 0;
        this.f145i = C0007a.RELAXED;
    }

    /* renamed from: j */
    public boolean mo62j() {
        return this.f139c != null;
    }

    public String toString() {
        String str;
        HashSet hashSet = new HashSet();
        StringBuilder sb = new StringBuilder();
        sb.append(this.f137a.mo96e());
        sb.append(":");
        sb.append(this.f138b.toString());
        if (this.f139c != null) {
            StringBuilder sb2 = new StringBuilder();
            sb2.append(" connected to ");
            sb2.append(this.f139c.m32a(hashSet));
            str = sb2.toString();
        } else {
            str = "";
        }
        sb.append(str);
        return sb.toString();
    }
}
