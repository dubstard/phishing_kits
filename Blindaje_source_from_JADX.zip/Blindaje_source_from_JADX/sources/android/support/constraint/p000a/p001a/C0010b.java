package android.support.constraint.p000a.p001a;

import android.support.constraint.p000a.C0022c;
import android.support.constraint.p000a.C0024e;
import android.support.constraint.p000a.p001a.C0005a.C0008b;
import android.support.constraint.p000a.p001a.C0005a.C0009c;
import java.util.ArrayList;

/* renamed from: android.support.constraint.a.a.b */
public class C0010b {

    /* renamed from: D */
    public static float f165D = 0.5f;

    /* renamed from: A */
    int f166A = 0;

    /* renamed from: B */
    protected int f167B;

    /* renamed from: C */
    protected int f168C;

    /* renamed from: E */
    float f169E = f165D;

    /* renamed from: F */
    float f170F = f165D;

    /* renamed from: G */
    C0012a f171G = C0012a.FIXED;

    /* renamed from: H */
    C0012a f172H = C0012a.FIXED;

    /* renamed from: I */
    int f173I;

    /* renamed from: J */
    int f174J;

    /* renamed from: K */
    int f175K;

    /* renamed from: L */
    int f176L;

    /* renamed from: M */
    boolean f177M;

    /* renamed from: N */
    boolean f178N;

    /* renamed from: O */
    boolean f179O;

    /* renamed from: P */
    boolean f180P;

    /* renamed from: Q */
    boolean f181Q;

    /* renamed from: R */
    boolean f182R;

    /* renamed from: S */
    int f183S = 0;

    /* renamed from: T */
    int f184T = 0;

    /* renamed from: U */
    boolean f185U;

    /* renamed from: V */
    boolean f186V;

    /* renamed from: W */
    float f187W = 0.0f;

    /* renamed from: X */
    float f188X = 0.0f;

    /* renamed from: Y */
    C0010b f189Y = null;

    /* renamed from: Z */
    C0010b f190Z = null;

    /* renamed from: a */
    public int f191a = -1;

    /* renamed from: aa */
    private int f192aa = 0;

    /* renamed from: ab */
    private int f193ab = 0;

    /* renamed from: ac */
    private int f194ac = 0;

    /* renamed from: ad */
    private int f195ad = 0;

    /* renamed from: ae */
    private int f196ae = 0;

    /* renamed from: af */
    private int f197af = 0;

    /* renamed from: ag */
    private int f198ag = 0;

    /* renamed from: ah */
    private int f199ah = 0;

    /* renamed from: ai */
    private int f200ai;

    /* renamed from: aj */
    private int f201aj;

    /* renamed from: ak */
    private Object f202ak;

    /* renamed from: al */
    private int f203al = 0;

    /* renamed from: am */
    private int f204am = 0;

    /* renamed from: an */
    private String f205an = null;

    /* renamed from: ao */
    private String f206ao = null;

    /* renamed from: b */
    public int f207b = -1;

    /* renamed from: c */
    int f208c = 0;

    /* renamed from: d */
    int f209d = 0;

    /* renamed from: e */
    int f210e = 0;

    /* renamed from: f */
    int f211f = 0;

    /* renamed from: g */
    int f212g = 0;

    /* renamed from: h */
    int f213h = 0;

    /* renamed from: i */
    C0005a f214i = new C0005a(this, C0009c.LEFT);

    /* renamed from: j */
    C0005a f215j = new C0005a(this, C0009c.TOP);

    /* renamed from: k */
    C0005a f216k = new C0005a(this, C0009c.RIGHT);

    /* renamed from: l */
    C0005a f217l = new C0005a(this, C0009c.BOTTOM);

    /* renamed from: m */
    C0005a f218m = new C0005a(this, C0009c.BASELINE);

    /* renamed from: n */
    C0005a f219n = new C0005a(this, C0009c.CENTER_X);

    /* renamed from: o */
    C0005a f220o = new C0005a(this, C0009c.CENTER_Y);

    /* renamed from: p */
    C0005a f221p = new C0005a(this, C0009c.CENTER);

    /* renamed from: q */
    protected ArrayList<C0005a> f222q = new ArrayList<>();

    /* renamed from: r */
    C0010b f223r = null;

    /* renamed from: s */
    int f224s = 0;

    /* renamed from: t */
    int f225t = 0;

    /* renamed from: u */
    protected float f226u = 0.0f;

    /* renamed from: v */
    protected int f227v = -1;

    /* renamed from: w */
    protected int f228w = 0;

    /* renamed from: x */
    protected int f229x = 0;

    /* renamed from: y */
    protected int f230y = 0;

    /* renamed from: z */
    protected int f231z = 0;

    /* renamed from: android.support.constraint.a.a.b$a */
    public enum C0012a {
        FIXED,
        WRAP_CONTENT,
        MATCH_CONSTRAINT,
        MATCH_PARENT
    }

    public C0010b() {
        mo127D();
    }

    /* renamed from: D */
    private void mo127D() {
        this.f222q.add(this.f214i);
        this.f222q.add(this.f215j);
        this.f222q.add(this.f216k);
        this.f222q.add(this.f217l);
        this.f222q.add(this.f219n);
        this.f222q.add(this.f220o);
        this.f222q.add(this.f218m);
    }

    /* JADX WARNING: Code restructure failed: missing block: B:21:0x0082, code lost:
        if (r5 != false) goto L_0x0084;
     */
    /* renamed from: a */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    private void m49a(android.support.constraint.p000a.C0024e r19, boolean r20, boolean r21, android.support.constraint.p000a.p001a.C0005a r22, android.support.constraint.p000a.p001a.C0005a r23, int r24, int r25, int r26, int r27, float r28, boolean r29, boolean r30, int r31, int r32, int r33) {
        /*
            r18 = this;
            r9 = r19
            r1 = r24
            r2 = r25
            r3 = r27
            r6 = r32
            r7 = r22
            r8 = r33
            android.support.constraint.a.g r10 = r9.mo178a(r7)
            r11 = r23
            android.support.constraint.a.g r12 = r9.mo178a(r11)
            android.support.constraint.a.a.a r13 = r22.mo58f()
            android.support.constraint.a.g r13 = r9.mo178a(r13)
            android.support.constraint.a.a.a r14 = r23.mo58f()
            android.support.constraint.a.g r14 = r9.mo178a(r14)
            int r15 = r22.mo56d()
            int r8 = r23.mo56d()
            r6 = r18
            int r5 = r6.f204am
            r6 = 8
            if (r5 != r6) goto L_0x003b
            r5 = 1
            r6 = 0
            goto L_0x003f
        L_0x003b:
            r5 = r21
            r6 = r26
        L_0x003f:
            if (r13 != 0) goto L_0x006c
            if (r14 != 0) goto L_0x006c
            android.support.constraint.a.b r7 = r19.mo186b()
            android.support.constraint.a.b r1 = r7.mo164b(r10, r1)
            r9.mo180a(r1)
            if (r29 != 0) goto L_0x01b5
            if (r20 == 0) goto L_0x005b
        L_0x0052:
            r0 = 1
            android.support.constraint.a.b r0 = android.support.constraint.p000a.C0024e.m185a(r9, r12, r10, r3, r0)
        L_0x0057:
            r9.mo180a(r0)
            return
        L_0x005b:
            if (r5 == 0) goto L_0x0063
            r0 = 0
            android.support.constraint.a.b r0 = android.support.constraint.p000a.C0024e.m185a(r9, r12, r10, r6, r0)
            goto L_0x0057
        L_0x0063:
            android.support.constraint.a.b r0 = r19.mo186b()
            android.support.constraint.a.b r0 = r0.mo164b(r12, r2)
            goto L_0x0057
        L_0x006c:
            r16 = 0
            if (r13 == 0) goto L_0x008d
            if (r14 != 0) goto L_0x008d
            android.support.constraint.a.b r1 = r19.mo186b()
            android.support.constraint.a.b r1 = r1.mo156a(r10, r13, r15)
            r9.mo180a(r1)
            if (r20 == 0) goto L_0x0080
            goto L_0x0052
        L_0x0080:
            if (r29 != 0) goto L_0x01b5
            if (r5 == 0) goto L_0x0063
        L_0x0084:
            android.support.constraint.a.b r0 = r19.mo186b()
            android.support.constraint.a.b r0 = r0.mo156a(r12, r10, r6)
            goto L_0x0057
        L_0x008d:
            if (r13 != 0) goto L_0x00af
            if (r14 == 0) goto L_0x00af
            android.support.constraint.a.b r2 = r19.mo186b()
            int r8 = r8 * -1
            android.support.constraint.a.b r2 = r2.mo156a(r12, r14, r8)
            r9.mo180a(r2)
            if (r20 == 0) goto L_0x00a1
            goto L_0x0052
        L_0x00a1:
            if (r29 != 0) goto L_0x01b5
            if (r5 == 0) goto L_0x00a6
            goto L_0x0084
        L_0x00a6:
            android.support.constraint.a.b r0 = r19.mo186b()
            android.support.constraint.a.b r0 = r0.mo164b(r10, r1)
            goto L_0x0057
        L_0x00af:
            if (r5 == 0) goto L_0x0146
            if (r20 == 0) goto L_0x00bc
            r0 = 1
            android.support.constraint.a.b r1 = android.support.constraint.p000a.C0024e.m185a(r9, r12, r10, r3, r0)
            r9.mo180a(r1)
            goto L_0x00c7
        L_0x00bc:
            android.support.constraint.a.b r0 = r19.mo186b()
            android.support.constraint.a.b r0 = r0.mo156a(r12, r10, r6)
            r9.mo180a(r0)
        L_0x00c7:
            android.support.constraint.a.a.a$b r0 = r22.mo57e()
            android.support.constraint.a.a.a$b r1 = r23.mo57e()
            if (r0 == r1) goto L_0x010f
            android.support.constraint.a.a.a$b r0 = r22.mo57e()
            android.support.constraint.a.a.a$b r1 = android.support.constraint.p000a.p001a.C0005a.C0008b.STRONG
            if (r0 != r1) goto L_0x00f5
            android.support.constraint.a.b r0 = r19.mo186b()
            android.support.constraint.a.b r0 = r0.mo156a(r10, r13, r15)
            r9.mo180a(r0)
            android.support.constraint.a.g r0 = r19.mo189c()
            android.support.constraint.a.b r1 = r19.mo186b()
            int r8 = r8 * -1
            r1.mo165b(r12, r14, r0, r8)
            r9.mo180a(r1)
            return
        L_0x00f5:
            android.support.constraint.a.g r0 = r19.mo189c()
            android.support.constraint.a.b r1 = r19.mo186b()
            r1.mo159a(r10, r13, r0, r15)
            r9.mo180a(r1)
            android.support.constraint.a.b r0 = r19.mo186b()
            int r8 = r8 * -1
        L_0x0109:
            android.support.constraint.a.b r0 = r0.mo156a(r12, r14, r8)
            goto L_0x0057
        L_0x010f:
            if (r13 != r14) goto L_0x011c
            r3 = 0
            r4 = 1056964608(0x3f000000, float:0.5)
            r7 = 0
            r8 = 1
            r0 = r9
            r1 = r10
            r2 = r13
            r5 = r14
            r6 = r12
            goto L_0x015c
        L_0x011c:
            if (r30 != 0) goto L_0x01b5
            android.support.constraint.a.a.a$a r0 = r22.mo59g()
            android.support.constraint.a.a.a$a r1 = android.support.constraint.p000a.p001a.C0005a.C0007a.STRICT
            if (r0 == r1) goto L_0x0128
            r0 = 1
            goto L_0x0129
        L_0x0128:
            r0 = 0
        L_0x0129:
            android.support.constraint.a.b r0 = android.support.constraint.p000a.C0024e.m190b(r9, r10, r13, r15, r0)
            r9.mo180a(r0)
            android.support.constraint.a.a.a$a r0 = r23.mo59g()
            android.support.constraint.a.a.a$a r1 = android.support.constraint.p000a.p001a.C0005a.C0007a.STRICT
            if (r0 == r1) goto L_0x013a
            r0 = 1
            goto L_0x013b
        L_0x013a:
            r0 = 0
        L_0x013b:
            int r1 = r8 * -1
            android.support.constraint.a.b r0 = android.support.constraint.p000a.C0024e.m193c(r9, r12, r14, r1, r0)
            r9.mo180a(r0)
            r11 = 0
            goto L_0x0152
        L_0x0146:
            r1 = 3
            if (r29 == 0) goto L_0x0162
            r9.mo184a(r10, r13, r15, r1)
            int r0 = r8 * -1
            r9.mo187b(r12, r14, r0, r1)
            r11 = 1
        L_0x0152:
            r0 = r9
            r1 = r10
            r2 = r13
            r3 = r15
            r4 = r28
            r5 = r14
            r6 = r12
            r7 = r8
            r8 = r11
        L_0x015c:
            android.support.constraint.a.b r0 = android.support.constraint.p000a.C0024e.m184a(r0, r1, r2, r3, r4, r5, r6, r7, r8)
            goto L_0x0057
        L_0x0162:
            if (r30 != 0) goto L_0x01b5
            r0 = 2
            r2 = r31
            r3 = 1
            if (r2 != r3) goto L_0x0193
            r2 = r32
            if (r2 <= r6) goto L_0x016f
            goto L_0x0170
        L_0x016f:
            r2 = r6
        L_0x0170:
            r7 = r8
            r3 = r33
            if (r3 <= 0) goto L_0x017c
            if (r3 >= r2) goto L_0x0179
            r2 = r3
            goto L_0x017c
        L_0x0179:
            r9.mo187b(r12, r10, r3, r1)
        L_0x017c:
            r9.mo188c(r12, r10, r2, r1)
        L_0x017f:
            r9.mo184a(r10, r13, r15, r0)
            int r1 = -r7
            r9.mo187b(r12, r14, r1, r0)
            r8 = 4
            r0 = r9
            r1 = r10
            r2 = r13
            r3 = r15
            r4 = r28
            r5 = r14
            r6 = r12
            r0.mo183a(r1, r2, r3, r4, r5, r6, r7, r8)
            return
        L_0x0193:
            r7 = r8
            r2 = r32
            r3 = r33
            if (r2 != 0) goto L_0x01af
            if (r3 != 0) goto L_0x01af
            android.support.constraint.a.b r0 = r19.mo186b()
            android.support.constraint.a.b r0 = r0.mo156a(r10, r13, r15)
            r9.mo180a(r0)
            android.support.constraint.a.b r0 = r19.mo186b()
            int r8 = r7 * -1
            goto L_0x0109
        L_0x01af:
            if (r3 <= 0) goto L_0x017f
            r9.mo187b(r12, r10, r3, r1)
            goto L_0x017f
        L_0x01b5:
            return
        */
        throw new UnsupportedOperationException("Method not decompiled: android.support.constraint.p000a.p001a.C0010b.m49a(android.support.constraint.a.e, boolean, boolean, android.support.constraint.a.a.a, android.support.constraint.a.a.a, int, int, int, int, float, boolean, boolean, int, int, int):void");
    }

    /* renamed from: A */
    public void mo64A() {
        C0010b c = mo88c();
        if (c == null || !(c instanceof C0013c) || !((C0013c) mo88c()).mo130G()) {
            int size = this.f222q.size();
            for (int i = 0; i < size; i++) {
                ((C0005a) this.f222q.get(i)).mo61i();
            }
        }
    }

    /* renamed from: B */
    public C0012a mo65B() {
        return this.f171G;
    }

    /* renamed from: C */
    public C0012a mo66C() {
        return this.f172H;
    }

    /* renamed from: a */
    public C0005a mo67a(C0009c cVar) {
        switch (cVar) {
            case LEFT:
                return this.f214i;
            case TOP:
                return this.f215j;
            case RIGHT:
                return this.f216k;
            case BOTTOM:
                return this.f217l;
            case BASELINE:
                return this.f218m;
            case CENTER_X:
                return this.f219n;
            case CENTER_Y:
                return this.f220o;
            case CENTER:
                return this.f221p;
            default:
                return null;
        }
    }

    /* renamed from: a */
    public void mo68a() {
        this.f214i.mo61i();
        this.f215j.mo61i();
        this.f216k.mo61i();
        this.f217l.mo61i();
        this.f218m.mo61i();
        this.f219n.mo61i();
        this.f220o.mo61i();
        this.f221p.mo61i();
        this.f223r = null;
        this.f224s = 0;
        this.f225t = 0;
        this.f226u = 0.0f;
        this.f227v = -1;
        this.f228w = 0;
        this.f229x = 0;
        this.f196ae = 0;
        this.f197af = 0;
        this.f198ag = 0;
        this.f199ah = 0;
        this.f230y = 0;
        this.f231z = 0;
        this.f166A = 0;
        this.f167B = 0;
        this.f168C = 0;
        this.f200ai = 0;
        this.f201aj = 0;
        this.f169E = f165D;
        this.f170F = f165D;
        this.f171G = C0012a.FIXED;
        this.f172H = C0012a.FIXED;
        this.f202ak = null;
        this.f203al = 0;
        this.f204am = 0;
        this.f205an = null;
        this.f206ao = null;
        this.f181Q = false;
        this.f182R = false;
        this.f183S = 0;
        this.f184T = 0;
        this.f185U = false;
        this.f186V = false;
        this.f187W = 0.0f;
        this.f188X = 0.0f;
        this.f191a = -1;
        this.f207b = -1;
    }

    /* renamed from: a */
    public void mo69a(float f) {
        this.f169E = f;
    }

    /* renamed from: a */
    public void mo70a(int i) {
        this.f204am = i;
    }

    /* renamed from: a */
    public void mo71a(int i, int i2) {
        this.f228w = i;
        this.f229x = i2;
    }

    /* renamed from: a */
    public void mo72a(int i, int i2, int i3) {
        this.f208c = i;
        this.f210e = i2;
        this.f211f = i3;
    }

    /* renamed from: a */
    public void mo73a(int i, int i2, int i3, int i4) {
        int i5 = i3 - i;
        int i6 = i4 - i2;
        this.f228w = i;
        this.f229x = i2;
        if (this.f204am == 8) {
            this.f224s = 0;
            this.f225t = 0;
            return;
        }
        if (this.f171G == C0012a.FIXED && i5 < this.f224s) {
            i5 = this.f224s;
        }
        if (this.f172H == C0012a.FIXED && i6 < this.f225t) {
            i6 = this.f225t;
        }
        this.f224s = i5;
        this.f225t = i6;
        if (this.f225t < this.f168C) {
            this.f225t = this.f168C;
        }
        if (this.f224s < this.f167B) {
            this.f224s = this.f167B;
        }
    }

    /* renamed from: a */
    public void mo74a(C0009c cVar, C0010b bVar, C0009c cVar2, int i, int i2) {
        mo67a(cVar).mo52a(bVar.mo67a(cVar2), i, i2, C0008b.STRONG, 0, true);
    }

    /* renamed from: a */
    public void mo75a(C0012a aVar) {
        this.f171G = aVar;
        if (this.f171G == C0012a.WRAP_CONTENT) {
            mo94d(this.f200ai);
        }
    }

    /* renamed from: a */
    public void mo76a(C0010b bVar) {
        this.f223r = bVar;
    }

    /* renamed from: a */
    public void mo77a(C0022c cVar) {
        this.f214i.mo50a(cVar);
        this.f215j.mo50a(cVar);
        this.f216k.mo50a(cVar);
        this.f217l.mo50a(cVar);
        this.f218m.mo50a(cVar);
        this.f221p.mo50a(cVar);
        this.f219n.mo50a(cVar);
        this.f220o.mo50a(cVar);
    }

    /* JADX WARNING: Code restructure failed: missing block: B:213:0x0406, code lost:
        if (r14 == -1) goto L_0x040a;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:254:0x0534, code lost:
        if (r9.f217l.f143g == r12) goto L_0x053f;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:272:0x05eb, code lost:
        if (r8.f216k.f143g == r1) goto L_0x05f0;
     */
    /* JADX WARNING: Removed duplicated region for block: B:170:0x02d8 A[ADDED_TO_REGION] */
    /* JADX WARNING: Removed duplicated region for block: B:176:0x02e7  */
    /* JADX WARNING: Removed duplicated region for block: B:182:0x02f4  */
    /* JADX WARNING: Removed duplicated region for block: B:202:0x03f0 A[RETURN] */
    /* JADX WARNING: Removed duplicated region for block: B:203:0x03f1  */
    /* JADX WARNING: Removed duplicated region for block: B:220:0x0415  */
    /* JADX WARNING: Removed duplicated region for block: B:249:0x0517  */
    /* JADX WARNING: Removed duplicated region for block: B:267:0x05d4  */
    /* JADX WARNING: Removed duplicated region for block: B:291:0x065c  */
    /* renamed from: a */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public void mo78a(android.support.constraint.p000a.C0024e r45, int r46) {
        /*
            r44 = this;
            r15 = r44
            r14 = r45
            r13 = r46
            r0 = 0
            r12 = 2147483647(0x7fffffff, float:NaN)
            if (r13 == r12) goto L_0x0015
            android.support.constraint.a.a.a r1 = r15.f214i
            int r1 = r1.f143g
            if (r1 != r13) goto L_0x0013
            goto L_0x0015
        L_0x0013:
            r11 = r0
            goto L_0x001c
        L_0x0015:
            android.support.constraint.a.a.a r1 = r15.f214i
            android.support.constraint.a.g r1 = r14.mo178a(r1)
            r11 = r1
        L_0x001c:
            if (r13 == r12) goto L_0x0027
            android.support.constraint.a.a.a r1 = r15.f216k
            int r1 = r1.f143g
            if (r1 != r13) goto L_0x0025
            goto L_0x0027
        L_0x0025:
            r10 = r0
            goto L_0x002e
        L_0x0027:
            android.support.constraint.a.a.a r1 = r15.f216k
            android.support.constraint.a.g r1 = r14.mo178a(r1)
            r10 = r1
        L_0x002e:
            if (r13 == r12) goto L_0x0039
            android.support.constraint.a.a.a r1 = r15.f215j
            int r1 = r1.f143g
            if (r1 != r13) goto L_0x0037
            goto L_0x0039
        L_0x0037:
            r9 = r0
            goto L_0x0040
        L_0x0039:
            android.support.constraint.a.a.a r1 = r15.f215j
            android.support.constraint.a.g r1 = r14.mo178a(r1)
            r9 = r1
        L_0x0040:
            if (r13 == r12) goto L_0x004b
            android.support.constraint.a.a.a r1 = r15.f217l
            int r1 = r1.f143g
            if (r1 != r13) goto L_0x0049
            goto L_0x004b
        L_0x0049:
            r8 = r0
            goto L_0x0052
        L_0x004b:
            android.support.constraint.a.a.a r1 = r15.f217l
            android.support.constraint.a.g r1 = r14.mo178a(r1)
            r8 = r1
        L_0x0052:
            if (r13 == r12) goto L_0x005d
            android.support.constraint.a.a.a r1 = r15.f218m
            int r1 = r1.f143g
            if (r1 != r13) goto L_0x005b
            goto L_0x005d
        L_0x005b:
            r7 = r0
            goto L_0x0064
        L_0x005d:
            android.support.constraint.a.a.a r0 = r15.f218m
            android.support.constraint.a.g r0 = r14.mo178a(r0)
            goto L_0x005b
        L_0x0064:
            android.support.constraint.a.a.b r0 = r15.f223r
            r6 = 0
            r5 = 1
            if (r0 == 0) goto L_0x01d7
            android.support.constraint.a.a.a r0 = r15.f214i
            android.support.constraint.a.a.a r0 = r0.f139c
            if (r0 == 0) goto L_0x007a
            android.support.constraint.a.a.a r0 = r15.f214i
            android.support.constraint.a.a.a r0 = r0.f139c
            android.support.constraint.a.a.a r0 = r0.f139c
            android.support.constraint.a.a.a r1 = r15.f214i
            if (r0 == r1) goto L_0x008a
        L_0x007a:
            android.support.constraint.a.a.a r0 = r15.f216k
            android.support.constraint.a.a.a r0 = r0.f139c
            if (r0 == 0) goto L_0x0093
            android.support.constraint.a.a.a r0 = r15.f216k
            android.support.constraint.a.a.a r0 = r0.f139c
            android.support.constraint.a.a.a r0 = r0.f139c
            android.support.constraint.a.a.a r1 = r15.f216k
            if (r0 != r1) goto L_0x0093
        L_0x008a:
            android.support.constraint.a.a.b r0 = r15.f223r
            android.support.constraint.a.a.c r0 = (android.support.constraint.p000a.p001a.C0013c) r0
            r0.mo131a(r15, r6)
            r0 = 1
            goto L_0x0094
        L_0x0093:
            r0 = 0
        L_0x0094:
            android.support.constraint.a.a.a r1 = r15.f215j
            android.support.constraint.a.a.a r1 = r1.f139c
            if (r1 == 0) goto L_0x00a4
            android.support.constraint.a.a.a r1 = r15.f215j
            android.support.constraint.a.a.a r1 = r1.f139c
            android.support.constraint.a.a.a r1 = r1.f139c
            android.support.constraint.a.a.a r2 = r15.f215j
            if (r1 == r2) goto L_0x00b4
        L_0x00a4:
            android.support.constraint.a.a.a r1 = r15.f217l
            android.support.constraint.a.a.a r1 = r1.f139c
            if (r1 == 0) goto L_0x00bd
            android.support.constraint.a.a.a r1 = r15.f217l
            android.support.constraint.a.a.a r1 = r1.f139c
            android.support.constraint.a.a.a r1 = r1.f139c
            android.support.constraint.a.a.a r2 = r15.f217l
            if (r1 != r2) goto L_0x00bd
        L_0x00b4:
            android.support.constraint.a.a.b r1 = r15.f223r
            android.support.constraint.a.a.c r1 = (android.support.constraint.p000a.p001a.C0013c) r1
            r1.mo131a(r15, r5)
            r1 = 1
            goto L_0x00be
        L_0x00bd:
            r1 = 0
        L_0x00be:
            android.support.constraint.a.a.b r2 = r15.f223r
            android.support.constraint.a.a.b$a r2 = r2.mo65B()
            android.support.constraint.a.a.b$a r3 = android.support.constraint.p000a.p001a.C0010b.C0012a.WRAP_CONTENT
            if (r2 != r3) goto L_0x0148
            if (r0 != 0) goto L_0x0148
            android.support.constraint.a.a.a r2 = r15.f214i
            android.support.constraint.a.a.a r2 = r2.f139c
            if (r2 == 0) goto L_0x00f3
            android.support.constraint.a.a.a r2 = r15.f214i
            android.support.constraint.a.a.a r2 = r2.f139c
            android.support.constraint.a.a.b r2 = r2.f137a
            android.support.constraint.a.a.b r3 = r15.f223r
            if (r2 == r3) goto L_0x00db
            goto L_0x00f3
        L_0x00db:
            android.support.constraint.a.a.a r2 = r15.f214i
            android.support.constraint.a.a.a r2 = r2.f139c
            if (r2 == 0) goto L_0x0109
            android.support.constraint.a.a.a r2 = r15.f214i
            android.support.constraint.a.a.a r2 = r2.f139c
            android.support.constraint.a.a.b r2 = r2.f137a
            android.support.constraint.a.a.b r3 = r15.f223r
            if (r2 != r3) goto L_0x0109
            android.support.constraint.a.a.a r2 = r15.f214i
            android.support.constraint.a.a.a$a r3 = android.support.constraint.p000a.p001a.C0005a.C0007a.STRICT
            r2.mo49a(r3)
            goto L_0x0109
        L_0x00f3:
            android.support.constraint.a.a.b r2 = r15.f223r
            android.support.constraint.a.a.a r2 = r2.f214i
            android.support.constraint.a.g r2 = r14.mo178a(r2)
            android.support.constraint.a.b r3 = r45.mo186b()
            android.support.constraint.a.g r4 = r45.mo189c()
            r3.mo159a(r11, r2, r4, r6)
            r14.mo180a(r3)
        L_0x0109:
            android.support.constraint.a.a.a r2 = r15.f216k
            android.support.constraint.a.a.a r2 = r2.f139c
            if (r2 == 0) goto L_0x0132
            android.support.constraint.a.a.a r2 = r15.f216k
            android.support.constraint.a.a.a r2 = r2.f139c
            android.support.constraint.a.a.b r2 = r2.f137a
            android.support.constraint.a.a.b r3 = r15.f223r
            if (r2 == r3) goto L_0x011a
            goto L_0x0132
        L_0x011a:
            android.support.constraint.a.a.a r2 = r15.f216k
            android.support.constraint.a.a.a r2 = r2.f139c
            if (r2 == 0) goto L_0x0148
            android.support.constraint.a.a.a r2 = r15.f216k
            android.support.constraint.a.a.a r2 = r2.f139c
            android.support.constraint.a.a.b r2 = r2.f137a
            android.support.constraint.a.a.b r3 = r15.f223r
            if (r2 != r3) goto L_0x0148
            android.support.constraint.a.a.a r2 = r15.f216k
            android.support.constraint.a.a.a$a r3 = android.support.constraint.p000a.p001a.C0005a.C0007a.STRICT
            r2.mo49a(r3)
            goto L_0x0148
        L_0x0132:
            android.support.constraint.a.a.b r2 = r15.f223r
            android.support.constraint.a.a.a r2 = r2.f216k
            android.support.constraint.a.g r2 = r14.mo178a(r2)
            android.support.constraint.a.b r3 = r45.mo186b()
            android.support.constraint.a.g r4 = r45.mo189c()
            r3.mo159a(r2, r10, r4, r6)
            r14.mo180a(r3)
        L_0x0148:
            android.support.constraint.a.a.b r2 = r15.f223r
            android.support.constraint.a.a.b$a r2 = r2.mo66C()
            android.support.constraint.a.a.b$a r3 = android.support.constraint.p000a.p001a.C0010b.C0012a.WRAP_CONTENT
            if (r2 != r3) goto L_0x01d2
            if (r1 != 0) goto L_0x01d2
            android.support.constraint.a.a.a r2 = r15.f215j
            android.support.constraint.a.a.a r2 = r2.f139c
            if (r2 == 0) goto L_0x017d
            android.support.constraint.a.a.a r2 = r15.f215j
            android.support.constraint.a.a.a r2 = r2.f139c
            android.support.constraint.a.a.b r2 = r2.f137a
            android.support.constraint.a.a.b r3 = r15.f223r
            if (r2 == r3) goto L_0x0165
            goto L_0x017d
        L_0x0165:
            android.support.constraint.a.a.a r2 = r15.f215j
            android.support.constraint.a.a.a r2 = r2.f139c
            if (r2 == 0) goto L_0x0193
            android.support.constraint.a.a.a r2 = r15.f215j
            android.support.constraint.a.a.a r2 = r2.f139c
            android.support.constraint.a.a.b r2 = r2.f137a
            android.support.constraint.a.a.b r3 = r15.f223r
            if (r2 != r3) goto L_0x0193
            android.support.constraint.a.a.a r2 = r15.f215j
            android.support.constraint.a.a.a$a r3 = android.support.constraint.p000a.p001a.C0005a.C0007a.STRICT
            r2.mo49a(r3)
            goto L_0x0193
        L_0x017d:
            android.support.constraint.a.a.b r2 = r15.f223r
            android.support.constraint.a.a.a r2 = r2.f215j
            android.support.constraint.a.g r2 = r14.mo178a(r2)
            android.support.constraint.a.b r3 = r45.mo186b()
            android.support.constraint.a.g r4 = r45.mo189c()
            r3.mo159a(r9, r2, r4, r6)
            r14.mo180a(r3)
        L_0x0193:
            android.support.constraint.a.a.a r2 = r15.f217l
            android.support.constraint.a.a.a r2 = r2.f139c
            if (r2 == 0) goto L_0x01bc
            android.support.constraint.a.a.a r2 = r15.f217l
            android.support.constraint.a.a.a r2 = r2.f139c
            android.support.constraint.a.a.b r2 = r2.f137a
            android.support.constraint.a.a.b r3 = r15.f223r
            if (r2 == r3) goto L_0x01a4
            goto L_0x01bc
        L_0x01a4:
            android.support.constraint.a.a.a r2 = r15.f217l
            android.support.constraint.a.a.a r2 = r2.f139c
            if (r2 == 0) goto L_0x01d2
            android.support.constraint.a.a.a r2 = r15.f217l
            android.support.constraint.a.a.a r2 = r2.f139c
            android.support.constraint.a.a.b r2 = r2.f137a
            android.support.constraint.a.a.b r3 = r15.f223r
            if (r2 != r3) goto L_0x01d2
            android.support.constraint.a.a.a r2 = r15.f217l
            android.support.constraint.a.a.a$a r3 = android.support.constraint.p000a.p001a.C0005a.C0007a.STRICT
            r2.mo49a(r3)
            goto L_0x01d2
        L_0x01bc:
            android.support.constraint.a.a.b r2 = r15.f223r
            android.support.constraint.a.a.a r2 = r2.f217l
            android.support.constraint.a.g r2 = r14.mo178a(r2)
            android.support.constraint.a.b r3 = r45.mo186b()
            android.support.constraint.a.g r4 = r45.mo189c()
            r3.mo159a(r2, r8, r4, r6)
            r14.mo180a(r3)
        L_0x01d2:
            r16 = r0
            r17 = r1
            goto L_0x01db
        L_0x01d7:
            r16 = 0
            r17 = 0
        L_0x01db:
            int r0 = r15.f224s
            int r1 = r15.f167B
            if (r0 >= r1) goto L_0x01e3
            int r0 = r15.f167B
        L_0x01e3:
            int r1 = r15.f225t
            int r2 = r15.f168C
            if (r1 >= r2) goto L_0x01eb
            int r1 = r15.f168C
        L_0x01eb:
            android.support.constraint.a.a.b$a r2 = r15.f171G
            android.support.constraint.a.a.b$a r3 = android.support.constraint.p000a.p001a.C0010b.C0012a.MATCH_CONSTRAINT
            if (r2 == r3) goto L_0x01f3
            r2 = 1
            goto L_0x01f4
        L_0x01f3:
            r2 = 0
        L_0x01f4:
            android.support.constraint.a.a.b$a r3 = r15.f172H
            android.support.constraint.a.a.b$a r4 = android.support.constraint.p000a.p001a.C0010b.C0012a.MATCH_CONSTRAINT
            if (r3 == r4) goto L_0x01fc
            r3 = 1
            goto L_0x01fd
        L_0x01fc:
            r3 = 0
        L_0x01fd:
            if (r2 != 0) goto L_0x0214
            android.support.constraint.a.a.a r4 = r15.f214i
            if (r4 == 0) goto L_0x0214
            android.support.constraint.a.a.a r4 = r15.f216k
            if (r4 == 0) goto L_0x0214
            android.support.constraint.a.a.a r4 = r15.f214i
            android.support.constraint.a.a.a r4 = r4.f139c
            if (r4 == 0) goto L_0x0213
            android.support.constraint.a.a.a r4 = r15.f216k
            android.support.constraint.a.a.a r4 = r4.f139c
            if (r4 != 0) goto L_0x0214
        L_0x0213:
            r2 = 1
        L_0x0214:
            if (r3 != 0) goto L_0x023f
            android.support.constraint.a.a.a r4 = r15.f215j
            if (r4 == 0) goto L_0x023f
            android.support.constraint.a.a.a r4 = r15.f217l
            if (r4 == 0) goto L_0x023f
            android.support.constraint.a.a.a r4 = r15.f215j
            android.support.constraint.a.a.a r4 = r4.f139c
            if (r4 == 0) goto L_0x022a
            android.support.constraint.a.a.a r4 = r15.f217l
            android.support.constraint.a.a.a r4 = r4.f139c
            if (r4 != 0) goto L_0x023f
        L_0x022a:
            int r4 = r15.f166A
            if (r4 == 0) goto L_0x023e
            android.support.constraint.a.a.a r4 = r15.f218m
            if (r4 == 0) goto L_0x023f
            android.support.constraint.a.a.a r4 = r15.f215j
            android.support.constraint.a.a.a r4 = r4.f139c
            if (r4 == 0) goto L_0x023e
            android.support.constraint.a.a.a r4 = r15.f218m
            android.support.constraint.a.a.a r4 = r4.f139c
            if (r4 != 0) goto L_0x023f
        L_0x023e:
            r3 = 1
        L_0x023f:
            int r4 = r15.f227v
            float r5 = r15.f226u
            float r6 = r15.f226u
            r20 = 0
            int r6 = (r6 > r20 ? 1 : (r6 == r20 ? 0 : -1))
            r21 = r8
            r8 = -1
            if (r6 <= 0) goto L_0x02cb
            int r6 = r15.f204am
            r12 = 8
            if (r6 == r12) goto L_0x02cb
            android.support.constraint.a.a.b$a r6 = r15.f171G
            android.support.constraint.a.a.b$a r12 = android.support.constraint.p000a.p001a.C0010b.C0012a.MATCH_CONSTRAINT
            r20 = 1065353216(0x3f800000, float:1.0)
            if (r6 != r12) goto L_0x0295
            android.support.constraint.a.a.b$a r6 = r15.f172H
            android.support.constraint.a.a.b$a r12 = android.support.constraint.p000a.p001a.C0010b.C0012a.MATCH_CONSTRAINT
            if (r6 != r12) goto L_0x0295
            if (r2 == 0) goto L_0x026f
            if (r3 != 0) goto L_0x026f
            r23 = r0
            r6 = r1
            r24 = r3
            r25 = r5
            r12 = 0
            goto L_0x0292
        L_0x026f:
            if (r2 != 0) goto L_0x028a
            if (r3 == 0) goto L_0x028a
            int r4 = r15.f227v
            if (r4 != r8) goto L_0x0281
            float r20 = r20 / r5
            r23 = r0
            r6 = r1
            r24 = r3
            r25 = r20
            goto L_0x0288
        L_0x0281:
            r23 = r0
            r6 = r1
            r24 = r3
            r25 = r5
        L_0x0288:
            r12 = 1
            goto L_0x0292
        L_0x028a:
            r23 = r0
            r6 = r1
            r24 = r3
            r12 = r4
            r25 = r5
        L_0x0292:
            r20 = 1
            goto L_0x02d5
        L_0x0295:
            android.support.constraint.a.a.b$a r6 = r15.f171G
            android.support.constraint.a.a.b$a r12 = android.support.constraint.p000a.p001a.C0010b.C0012a.MATCH_CONSTRAINT
            if (r6 != r12) goto L_0x02ad
            int r0 = r15.f225t
            float r0 = (float) r0
            float r0 = r0 * r5
            int r0 = (int) r0
            r23 = r0
            r6 = r1
            r24 = r3
            r25 = r5
            r3 = 1
            r12 = 0
            r20 = 0
            goto L_0x02d6
        L_0x02ad:
            android.support.constraint.a.a.b$a r6 = r15.f172H
            android.support.constraint.a.a.b$a r12 = android.support.constraint.p000a.p001a.C0010b.C0012a.MATCH_CONSTRAINT
            if (r6 != r12) goto L_0x02cb
            int r1 = r15.f227v
            if (r1 != r8) goto L_0x02b9
            float r5 = r20 / r5
        L_0x02b9:
            int r1 = r15.f224s
            float r1 = (float) r1
            float r1 = r1 * r5
            int r1 = (int) r1
            r23 = r0
            r6 = r1
            r3 = r2
            r25 = r5
            r12 = 1
            r20 = 0
            r24 = 1
            goto L_0x02d6
        L_0x02cb:
            r23 = r0
            r6 = r1
            r24 = r3
            r12 = r4
            r25 = r5
            r20 = 0
        L_0x02d5:
            r3 = r2
        L_0x02d6:
            if (r20 == 0) goto L_0x02df
            if (r12 == 0) goto L_0x02dc
            if (r12 != r8) goto L_0x02df
        L_0x02dc:
            r26 = 1
            goto L_0x02e1
        L_0x02df:
            r26 = 0
        L_0x02e1:
            android.support.constraint.a.a.b$a r0 = r15.f171G
            android.support.constraint.a.a.b$a r1 = android.support.constraint.p000a.p001a.C0010b.C0012a.WRAP_CONTENT
            if (r0 != r1) goto L_0x02ed
            boolean r0 = r15 instanceof android.support.constraint.p000a.p001a.C0013c
            if (r0 == 0) goto L_0x02ed
            r2 = 1
            goto L_0x02ee
        L_0x02ed:
            r2 = 0
        L_0x02ee:
            int r0 = r15.f191a
            r5 = 2
            r4 = 3
            if (r0 == r5) goto L_0x03db
            r1 = 2147483647(0x7fffffff, float:NaN)
            if (r13 == r1) goto L_0x0305
            android.support.constraint.a.a.a r0 = r15.f214i
            int r0 = r0.f143g
            if (r0 != r13) goto L_0x03db
            android.support.constraint.a.a.a r0 = r15.f216k
            int r0 = r0.f143g
            if (r0 != r13) goto L_0x03db
        L_0x0305:
            if (r26 == 0) goto L_0x0390
            android.support.constraint.a.a.a r0 = r15.f214i
            android.support.constraint.a.a.a r0 = r0.f139c
            if (r0 == 0) goto L_0x0390
            android.support.constraint.a.a.a r0 = r15.f216k
            android.support.constraint.a.a.a r0 = r0.f139c
            if (r0 == 0) goto L_0x0390
            android.support.constraint.a.a.a r0 = r15.f214i
            android.support.constraint.a.g r2 = r14.mo178a(r0)
            android.support.constraint.a.a.a r0 = r15.f216k
            android.support.constraint.a.g r3 = r14.mo178a(r0)
            android.support.constraint.a.a.a r0 = r15.f214i
            android.support.constraint.a.a.a r0 = r0.mo58f()
            android.support.constraint.a.g r0 = r14.mo178a(r0)
            android.support.constraint.a.a.a r1 = r15.f216k
            android.support.constraint.a.a.a r1 = r1.mo58f()
            android.support.constraint.a.g r1 = r14.mo178a(r1)
            android.support.constraint.a.a.a r5 = r15.f214i
            int r5 = r5.mo56d()
            r14.mo184a(r2, r0, r5, r4)
            android.support.constraint.a.a.a r5 = r15.f216k
            int r5 = r5.mo56d()
            int r5 = r5 * -1
            r14.mo187b(r3, r1, r5, r4)
            if (r16 != 0) goto L_0x037b
            android.support.constraint.a.a.a r5 = r15.f214i
            int r5 = r5.mo56d()
            float r4 = r15.f169E
            android.support.constraint.a.a.a r8 = r15.f216k
            int r8 = r8.mo56d()
            r16 = 4
            r22 = r0
            r0 = r14
            r23 = r1
            r27 = 2147483647(0x7fffffff, float:NaN)
            r1 = r2
            r2 = r22
            r22 = r3
            r3 = r5
            r5 = 3
            r5 = r23
            r28 = r6
            r18 = 0
            r6 = r22
            r29 = r7
            r7 = r8
            r30 = r21
            r8 = r16
            r0.mo183a(r1, r2, r3, r4, r5, r6, r7, r8)
            goto L_0x0386
        L_0x037b:
            r28 = r6
            r29 = r7
            r30 = r21
            r18 = 0
            r27 = 2147483647(0x7fffffff, float:NaN)
        L_0x0386:
            r32 = r9
            r33 = r10
            r34 = r11
            r35 = r12
            goto L_0x03eb
        L_0x0390:
            r28 = r6
            r29 = r7
            r30 = r21
            r18 = 0
            r27 = 2147483647(0x7fffffff, float:NaN)
            android.support.constraint.a.a.a r4 = r15.f214i
            android.support.constraint.a.a.a r5 = r15.f216k
            int r6 = r15.f228w
            int r0 = r15.f228w
            int r7 = r0 + r23
            int r8 = r15.f167B
            float r1 = r15.f169E
            int r0 = r15.f208c
            int r13 = r15.f210e
            r31 = r13
            int r13 = r15.f211f
            r19 = r0
            r0 = r15
            r21 = r1
            r1 = r14
            r22 = r8
            r8 = r23
            r32 = r9
            r9 = r22
            r33 = r10
            r10 = r21
            r34 = r11
            r11 = r26
            r35 = r12
            r12 = r16
            r21 = r13
            r16 = r31
            r13 = r19
            r14 = r16
            r15 = r21
            r0.m49a(r1, r2, r3, r4, r5, r6, r7, r8, r9, r10, r11, r12, r13, r14, r15)
            r15 = r44
            goto L_0x03eb
        L_0x03db:
            r28 = r6
            r29 = r7
            r32 = r9
            r33 = r10
            r34 = r11
            r35 = r12
            r30 = r21
            r18 = 0
        L_0x03eb:
            int r0 = r15.f207b
            r1 = 2
            if (r0 != r1) goto L_0x03f1
            return
        L_0x03f1:
            android.support.constraint.a.a.b$a r0 = r15.f172H
            android.support.constraint.a.a.b$a r1 = android.support.constraint.p000a.p001a.C0010b.C0012a.WRAP_CONTENT
            if (r0 != r1) goto L_0x03fd
            boolean r0 = r15 instanceof android.support.constraint.p000a.p001a.C0013c
            if (r0 == 0) goto L_0x03fd
            r2 = 1
            goto L_0x03fe
        L_0x03fd:
            r2 = 0
        L_0x03fe:
            if (r20 == 0) goto L_0x040c
            r14 = r35
            r13 = 1
            if (r14 == r13) goto L_0x0409
            r0 = -1
            if (r14 != r0) goto L_0x0410
            goto L_0x040a
        L_0x0409:
            r0 = -1
        L_0x040a:
            r11 = 1
            goto L_0x0411
        L_0x040c:
            r14 = r35
            r0 = -1
            r13 = 1
        L_0x0410:
            r11 = 0
        L_0x0411:
            int r1 = r15.f166A
            if (r1 <= 0) goto L_0x0517
            android.support.constraint.a.a.a r1 = r15.f217l
            r12 = 5
            r9 = 2147483647(0x7fffffff, float:NaN)
            r10 = r46
            if (r10 == r9) goto L_0x0431
            android.support.constraint.a.a.a r3 = r15.f217l
            int r3 = r3.f143g
            if (r3 != r10) goto L_0x042c
            android.support.constraint.a.a.a r3 = r15.f218m
            int r3 = r3.f143g
            if (r3 != r10) goto L_0x042c
            goto L_0x0431
        L_0x042c:
            r7 = r32
            r8 = r45
            goto L_0x043e
        L_0x0431:
            int r3 = r44.mo123w()
            r4 = r29
            r7 = r32
            r8 = r45
            r8.mo188c(r4, r7, r3, r12)
        L_0x043e:
            android.support.constraint.a.a.a r3 = r15.f218m
            android.support.constraint.a.a.a r3 = r3.f139c
            if (r3 == 0) goto L_0x044c
            int r1 = r15.f166A
            android.support.constraint.a.a.a r3 = r15.f218m
            r16 = r1
            r5 = r3
            goto L_0x044f
        L_0x044c:
            r5 = r1
            r16 = r28
        L_0x044f:
            if (r10 == r9) goto L_0x0464
            android.support.constraint.a.a.a r1 = r15.f215j
            int r1 = r1.f143g
            if (r1 != r10) goto L_0x045c
            int r1 = r5.f143g
            if (r1 != r10) goto L_0x045c
            goto L_0x0464
        L_0x045c:
            r15 = r8
            r39 = r14
            r13 = r30
            r14 = r7
            goto L_0x0537
        L_0x0464:
            if (r11 == 0) goto L_0x04d0
            android.support.constraint.a.a.a r1 = r15.f215j
            android.support.constraint.a.a.a r1 = r1.f139c
            if (r1 == 0) goto L_0x04d0
            android.support.constraint.a.a.a r1 = r15.f217l
            android.support.constraint.a.a.a r1 = r1.f139c
            if (r1 == 0) goto L_0x04d0
            android.support.constraint.a.a.a r1 = r15.f215j
            android.support.constraint.a.g r1 = r8.mo178a(r1)
            android.support.constraint.a.a.a r2 = r15.f217l
            android.support.constraint.a.g r6 = r8.mo178a(r2)
            android.support.constraint.a.a.a r2 = r15.f215j
            android.support.constraint.a.a.a r2 = r2.mo58f()
            android.support.constraint.a.g r2 = r8.mo178a(r2)
            android.support.constraint.a.a.a r3 = r15.f217l
            android.support.constraint.a.a.a r3 = r3.mo58f()
            android.support.constraint.a.g r5 = r8.mo178a(r3)
            android.support.constraint.a.a.a r3 = r15.f215j
            int r3 = r3.mo56d()
            r11 = 3
            r8.mo184a(r1, r2, r3, r11)
            android.support.constraint.a.a.a r3 = r15.f217l
            int r3 = r3.mo56d()
            int r3 = r3 * -1
            r8.mo187b(r6, r5, r3, r11)
            if (r17 != 0) goto L_0x04c4
            android.support.constraint.a.a.a r0 = r15.f215j
            int r3 = r0.mo56d()
            float r4 = r15.f170F
            android.support.constraint.a.a.a r0 = r15.f217l
            int r12 = r0.mo56d()
            r16 = 4
            r0 = r8
            r36 = r7
            r7 = r12
            r12 = r8
            r8 = r16
            r0.mo183a(r1, r2, r3, r4, r5, r6, r7, r8)
            goto L_0x04c7
        L_0x04c4:
            r36 = r7
            r12 = r8
        L_0x04c7:
            r15 = r12
            r39 = r14
            r13 = r30
            r14 = r36
            goto L_0x0537
        L_0x04d0:
            r36 = r7
            r7 = 3
            android.support.constraint.a.a.a r4 = r15.f215j
            int r6 = r15.f229x
            int r0 = r15.f229x
            int r18 = r0 + r16
            int r3 = r15.f168C
            float r1 = r15.f170F
            int r0 = r15.f209d
            r37 = r14
            int r14 = r15.f212g
            r38 = r14
            int r14 = r15.f213h
            r19 = r0
            r0 = r15
            r21 = r1
            r1 = r8
            r22 = r3
            r3 = r24
            r7 = r18
            r8 = r16
            r9 = r22
            r10 = r21
            r12 = r17
            r13 = r19
            r16 = r14
            r39 = r37
            r14 = r38
            r15 = r16
            r0.m49a(r1, r2, r3, r4, r5, r6, r7, r8, r9, r10, r11, r12, r13, r14, r15)
            r8 = r28
            r13 = r30
            r14 = r36
            r0 = 5
            r15 = r45
            r15.mo188c(r13, r14, r8, r0)
            goto L_0x0537
        L_0x0517:
            r39 = r14
            r8 = r28
            r13 = r30
            r14 = r32
            r10 = 2147483647(0x7fffffff, float:NaN)
            r12 = r46
            r15 = r45
            if (r12 == r10) goto L_0x053d
            r9 = r44
            android.support.constraint.a.a.a r1 = r9.f215j
            int r1 = r1.f143g
            if (r1 != r12) goto L_0x0537
            android.support.constraint.a.a.a r1 = r9.f217l
            int r1 = r1.f143g
            if (r1 != r12) goto L_0x0537
            goto L_0x053f
        L_0x0537:
            r42 = r13
            r43 = r14
            goto L_0x05d2
        L_0x053d:
            r9 = r44
        L_0x053f:
            if (r11 == 0) goto L_0x0598
            android.support.constraint.a.a.a r1 = r9.f215j
            android.support.constraint.a.a.a r1 = r1.f139c
            if (r1 == 0) goto L_0x0598
            android.support.constraint.a.a.a r1 = r9.f217l
            android.support.constraint.a.a.a r1 = r1.f139c
            if (r1 == 0) goto L_0x0598
            android.support.constraint.a.a.a r1 = r9.f215j
            android.support.constraint.a.g r1 = r15.mo178a(r1)
            android.support.constraint.a.a.a r2 = r9.f217l
            android.support.constraint.a.g r6 = r15.mo178a(r2)
            android.support.constraint.a.a.a r2 = r9.f215j
            android.support.constraint.a.a.a r2 = r2.mo58f()
            android.support.constraint.a.g r2 = r15.mo178a(r2)
            android.support.constraint.a.a.a r3 = r9.f217l
            android.support.constraint.a.a.a r3 = r3.mo58f()
            android.support.constraint.a.g r5 = r15.mo178a(r3)
            android.support.constraint.a.a.a r3 = r9.f215j
            int r3 = r3.mo56d()
            r11 = 3
            r15.mo184a(r1, r2, r3, r11)
            android.support.constraint.a.a.a r3 = r9.f217l
            int r3 = r3.mo56d()
            int r3 = r3 * -1
            r15.mo187b(r6, r5, r3, r11)
            if (r17 != 0) goto L_0x0537
            android.support.constraint.a.a.a r0 = r9.f215j
            int r3 = r0.mo56d()
            float r4 = r9.f170F
            android.support.constraint.a.a.a r0 = r9.f217l
            int r7 = r0.mo56d()
            r8 = 4
            r0 = r15
            r0.mo183a(r1, r2, r3, r4, r5, r6, r7, r8)
            goto L_0x0537
        L_0x0598:
            r7 = 3
            android.support.constraint.a.a.a r4 = r9.f215j
            android.support.constraint.a.a.a r5 = r9.f217l
            int r6 = r9.f229x
            int r0 = r9.f229x
            int r16 = r0 + r8
            int r3 = r9.f168C
            float r1 = r9.f170F
            int r0 = r9.f209d
            r40 = r14
            int r14 = r9.f212g
            r41 = r14
            int r14 = r9.f213h
            r18 = r0
            r0 = r9
            r19 = r1
            r1 = r15
            r21 = r3
            r3 = r24
            r7 = r16
            r9 = r21
            r10 = r19
            r12 = r17
            r42 = r13
            r13 = r18
            r16 = r14
            r43 = r40
            r14 = r41
            r15 = r16
            r0.m49a(r1, r2, r3, r4, r5, r6, r7, r8, r9, r10, r11, r12, r13, r14, r15)
        L_0x05d2:
            if (r20 == 0) goto L_0x065c
            android.support.constraint.a.b r0 = r45.mo186b()
            r1 = r46
            r2 = 2147483647(0x7fffffff, float:NaN)
            if (r1 == r2) goto L_0x05ee
            r8 = r44
            android.support.constraint.a.a.a r2 = r8.f214i
            int r2 = r2.f143g
            if (r2 != r1) goto L_0x065e
            android.support.constraint.a.a.a r2 = r8.f216k
            int r2 = r2.f143g
            if (r2 != r1) goto L_0x065e
            goto L_0x05f0
        L_0x05ee:
            r8 = r44
        L_0x05f0:
            r4 = r39
            if (r4 != 0) goto L_0x0609
            r2 = r0
            r3 = r33
            r4 = r34
            r5 = r42
            r6 = r43
            r7 = r25
            android.support.constraint.a.b r0 = r2.mo160a(r3, r4, r5, r6, r7)
            r1 = r45
        L_0x0605:
            r1.mo180a(r0)
            return
        L_0x0609:
            r1 = r45
            r2 = 1
            if (r4 != r2) goto L_0x061e
            r2 = r0
            r3 = r42
            r4 = r43
            r5 = r33
            r6 = r34
            r7 = r25
            android.support.constraint.a.b r0 = r2.mo160a(r3, r4, r5, r6, r7)
            goto L_0x0605
        L_0x061e:
            int r2 = r8.f210e
            if (r2 <= 0) goto L_0x062d
            int r2 = r8.f210e
            r3 = r33
            r4 = r34
            r5 = 3
            r1.mo184a(r3, r4, r2, r5)
            goto L_0x0632
        L_0x062d:
            r3 = r33
            r4 = r34
            r5 = 3
        L_0x0632:
            int r2 = r8.f212g
            if (r2 <= 0) goto L_0x0640
            int r2 = r8.f212g
            r7 = r42
            r6 = r43
            r1.mo184a(r7, r6, r2, r5)
            goto L_0x0644
        L_0x0640:
            r7 = r42
            r6 = r43
        L_0x0644:
            r9 = 4
            r2 = r0
            r5 = r7
            r7 = r25
            r2.mo160a(r3, r4, r5, r6, r7)
            android.support.constraint.a.g r2 = r45.mo190d()
            android.support.constraint.a.g r3 = r45.mo190d()
            r2.f308c = r9
            r3.f308c = r9
            r0.mo155a(r2, r3)
            goto L_0x0605
        L_0x065c:
            r8 = r44
        L_0x065e:
            return
        */
        throw new UnsupportedOperationException("Method not decompiled: android.support.constraint.p000a.p001a.C0010b.mo78a(android.support.constraint.a.e, int):void");
    }

    /* renamed from: a */
    public void mo79a(Object obj) {
        this.f202ak = obj;
    }

    /* JADX WARNING: Removed duplicated region for block: B:39:0x0089  */
    /* renamed from: a */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public void mo80a(java.lang.String r9) {
        /*
            r8 = this;
            r0 = 0
            if (r9 == 0) goto L_0x008e
            int r1 = r9.length()
            if (r1 != 0) goto L_0x000b
            goto L_0x008e
        L_0x000b:
            r1 = -1
            int r2 = r9.length()
            r3 = 44
            int r3 = r9.indexOf(r3)
            r4 = 0
            r5 = 1
            if (r3 <= 0) goto L_0x0037
            int r6 = r2 + -1
            if (r3 >= r6) goto L_0x0037
            java.lang.String r6 = r9.substring(r4, r3)
            java.lang.String r7 = "W"
            boolean r7 = r6.equalsIgnoreCase(r7)
            if (r7 == 0) goto L_0x002c
            r1 = 0
            goto L_0x0035
        L_0x002c:
            java.lang.String r4 = "H"
            boolean r4 = r6.equalsIgnoreCase(r4)
            if (r4 == 0) goto L_0x0035
            r1 = 1
        L_0x0035:
            int r4 = r3 + 1
        L_0x0037:
            r3 = 58
            int r3 = r9.indexOf(r3)
            if (r3 < 0) goto L_0x0075
            int r2 = r2 - r5
            if (r3 >= r2) goto L_0x0075
            java.lang.String r2 = r9.substring(r4, r3)
            int r3 = r3 + r5
            java.lang.String r9 = r9.substring(r3)
            int r3 = r2.length()
            if (r3 <= 0) goto L_0x0084
            int r3 = r9.length()
            if (r3 <= 0) goto L_0x0084
            float r2 = java.lang.Float.parseFloat(r2)     // Catch:{ NumberFormatException -> 0x0084 }
            float r9 = java.lang.Float.parseFloat(r9)     // Catch:{ NumberFormatException -> 0x0084 }
            int r3 = (r2 > r0 ? 1 : (r2 == r0 ? 0 : -1))
            if (r3 <= 0) goto L_0x0084
            int r3 = (r9 > r0 ? 1 : (r9 == r0 ? 0 : -1))
            if (r3 <= 0) goto L_0x0084
            if (r1 != r5) goto L_0x006f
            float r9 = r9 / r2
            float r9 = java.lang.Math.abs(r9)     // Catch:{ NumberFormatException -> 0x0084 }
            goto L_0x0085
        L_0x006f:
            float r2 = r2 / r9
            float r9 = java.lang.Math.abs(r2)     // Catch:{ NumberFormatException -> 0x0084 }
            goto L_0x0085
        L_0x0075:
            java.lang.String r9 = r9.substring(r4)
            int r2 = r9.length()
            if (r2 <= 0) goto L_0x0084
            float r9 = java.lang.Float.parseFloat(r9)     // Catch:{ NumberFormatException -> 0x0084 }
            goto L_0x0085
        L_0x0084:
            r9 = 0
        L_0x0085:
            int r0 = (r9 > r0 ? 1 : (r9 == r0 ? 0 : -1))
            if (r0 <= 0) goto L_0x008d
            r8.f226u = r9
            r8.f227v = r1
        L_0x008d:
            return
        L_0x008e:
            r8.f226u = r0
            return
        */
        throw new UnsupportedOperationException("Method not decompiled: android.support.constraint.p000a.p001a.C0010b.mo80a(java.lang.String):void");
    }

    /* renamed from: b */
    public void mo81b(float f) {
        this.f170F = f;
    }

    /* renamed from: b */
    public void mo82b(int i) {
        this.f228w = i;
    }

    /* renamed from: b */
    public void mo83b(int i, int i2) {
        this.f230y = i;
        this.f231z = i2;
    }

    /* renamed from: b */
    public void mo84b(int i, int i2, int i3) {
        this.f209d = i;
        this.f212g = i2;
        this.f213h = i3;
    }

    /* renamed from: b */
    public void mo85b(C0012a aVar) {
        this.f172H = aVar;
        if (this.f172H == C0012a.WRAP_CONTENT) {
            mo97e(this.f201aj);
        }
    }

    /* renamed from: b */
    public void mo86b(C0024e eVar, int i) {
        if (i == Integer.MAX_VALUE) {
            mo73a(eVar.mo185b((Object) this.f214i), eVar.mo185b((Object) this.f215j), eVar.mo185b((Object) this.f216k), eVar.mo185b((Object) this.f217l));
        } else if (i == -2) {
            mo73a(this.f192aa, this.f193ab, this.f194ac, this.f195ad);
        } else {
            if (this.f214i.f143g == i) {
                this.f192aa = eVar.mo185b((Object) this.f214i);
            }
            if (this.f215j.f143g == i) {
                this.f193ab = eVar.mo185b((Object) this.f215j);
            }
            if (this.f216k.f143g == i) {
                this.f194ac = eVar.mo185b((Object) this.f216k);
            }
            if (this.f217l.f143g == i) {
                this.f195ad = eVar.mo185b((Object) this.f217l);
            }
        }
    }

    /* renamed from: b */
    public boolean mo87b() {
        return this.f223r == null;
    }

    /* renamed from: c */
    public C0010b mo88c() {
        return this.f223r;
    }

    /* renamed from: c */
    public void mo89c(float f) {
        this.f187W = f;
    }

    /* renamed from: c */
    public void mo90c(int i) {
        this.f229x = i;
    }

    /* renamed from: c */
    public void mo91c(int i, int i2) {
        this.f228w = i;
        this.f224s = i2 - i;
        if (this.f224s < this.f167B) {
            this.f224s = this.f167B;
        }
    }

    /* renamed from: d */
    public int mo92d() {
        return this.f204am;
    }

    /* renamed from: d */
    public void mo93d(float f) {
        this.f188X = f;
    }

    /* renamed from: d */
    public void mo94d(int i) {
        this.f224s = i;
        if (this.f224s < this.f167B) {
            this.f224s = this.f167B;
        }
    }

    /* renamed from: d */
    public void mo95d(int i, int i2) {
        this.f229x = i;
        this.f225t = i2 - i;
        if (this.f225t < this.f168C) {
            this.f225t = this.f168C;
        }
    }

    /* renamed from: e */
    public String mo96e() {
        return this.f205an;
    }

    /* renamed from: e */
    public void mo97e(int i) {
        this.f225t = i;
        if (this.f225t < this.f168C) {
            this.f225t = this.f168C;
        }
    }

    /* renamed from: f */
    public int mo98f() {
        return this.f228w;
    }

    /* renamed from: f */
    public void mo99f(int i) {
        if (i < 0) {
            i = 0;
        }
        this.f167B = i;
    }

    /* renamed from: g */
    public int mo100g() {
        return this.f229x;
    }

    /* renamed from: g */
    public void mo101g(int i) {
        if (i < 0) {
            i = 0;
        }
        this.f168C = i;
    }

    /* renamed from: h */
    public int mo102h() {
        if (this.f204am == 8) {
            return 0;
        }
        return this.f224s;
    }

    /* renamed from: h */
    public void mo103h(int i) {
        this.f200ai = i;
    }

    /* renamed from: i */
    public int mo104i() {
        int i;
        int i2 = this.f224s;
        if (this.f171G != C0012a.MATCH_CONSTRAINT) {
            return i2;
        }
        if (this.f208c == 1) {
            i = Math.max(this.f210e, i2);
        } else if (this.f210e > 0) {
            i = this.f210e;
            this.f224s = i;
        } else {
            i = 0;
        }
        return (this.f211f <= 0 || this.f211f >= i) ? i : this.f211f;
    }

    /* renamed from: i */
    public void mo105i(int i) {
        this.f201aj = i;
    }

    /* renamed from: j */
    public int mo106j() {
        int i;
        int i2 = this.f225t;
        if (this.f172H != C0012a.MATCH_CONSTRAINT) {
            return i2;
        }
        if (this.f209d == 1) {
            i = Math.max(this.f212g, i2);
        } else if (this.f212g > 0) {
            i = this.f212g;
            this.f225t = i;
        } else {
            i = 0;
        }
        return (this.f213h <= 0 || this.f213h >= i) ? i : this.f213h;
    }

    /* renamed from: j */
    public void mo107j(int i) {
        this.f166A = i;
    }

    /* renamed from: k */
    public int mo108k() {
        return this.f200ai;
    }

    /* renamed from: k */
    public void mo109k(int i) {
        this.f183S = i;
    }

    /* renamed from: l */
    public int mo110l() {
        if (this.f204am == 8) {
            return 0;
        }
        return this.f225t;
    }

    /* renamed from: l */
    public void mo111l(int i) {
        this.f184T = i;
    }

    /* renamed from: m */
    public int mo112m() {
        return this.f201aj;
    }

    /* renamed from: n */
    public int mo113n() {
        return this.f196ae + this.f230y;
    }

    /* renamed from: o */
    public int mo114o() {
        return this.f197af + this.f231z;
    }

    /* renamed from: p */
    public int mo115p() {
        return mo114o() + this.f199ah;
    }

    /* renamed from: q */
    public int mo116q() {
        return mo113n() + this.f198ag;
    }

    /* access modifiers changed from: protected */
    /* renamed from: r */
    public int mo117r() {
        return this.f228w + this.f230y;
    }

    /* access modifiers changed from: protected */
    /* renamed from: s */
    public int mo118s() {
        return this.f229x + this.f231z;
    }

    /* renamed from: t */
    public int mo119t() {
        return mo98f() + this.f224s;
    }

    public String toString() {
        String str;
        String str2;
        StringBuilder sb = new StringBuilder();
        if (this.f206ao != null) {
            StringBuilder sb2 = new StringBuilder();
            sb2.append("type: ");
            sb2.append(this.f206ao);
            sb2.append(" ");
            str = sb2.toString();
        } else {
            str = "";
        }
        sb.append(str);
        if (this.f205an != null) {
            StringBuilder sb3 = new StringBuilder();
            sb3.append("id: ");
            sb3.append(this.f205an);
            sb3.append(" ");
            str2 = sb3.toString();
        } else {
            str2 = "";
        }
        sb.append(str2);
        sb.append("(");
        sb.append(this.f228w);
        sb.append(", ");
        sb.append(this.f229x);
        sb.append(") - (");
        sb.append(this.f224s);
        sb.append(" x ");
        sb.append(this.f225t);
        sb.append(")");
        sb.append(" wrap: (");
        sb.append(this.f200ai);
        sb.append(" x ");
        sb.append(this.f201aj);
        sb.append(")");
        return sb.toString();
    }

    /* renamed from: u */
    public int mo121u() {
        return mo100g() + this.f225t;
    }

    /* renamed from: v */
    public boolean mo122v() {
        return this.f166A > 0;
    }

    /* renamed from: w */
    public int mo123w() {
        return this.f166A;
    }

    /* renamed from: x */
    public Object mo124x() {
        return this.f202ak;
    }

    /* renamed from: y */
    public ArrayList<C0005a> mo125y() {
        return this.f222q;
    }

    /* renamed from: z */
    public void mo126z() {
        int i = this.f228w;
        int i2 = this.f229x;
        int i3 = this.f228w + this.f224s;
        int i4 = this.f229x + this.f225t;
        this.f196ae = i;
        this.f197af = i2;
        this.f198ag = i3 - i;
        this.f199ah = i4 - i2;
    }
}
