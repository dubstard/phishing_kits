package android.support.constraint.p000a.p001a;

import android.support.constraint.p000a.C0024e;
import android.support.constraint.p000a.C0028g;
import android.support.constraint.p000a.p001a.C0010b.C0012a;

/* renamed from: android.support.constraint.a.a.e */
public class C0016e {
    /* renamed from: a */
    static void m143a(C0013c cVar, C0024e eVar, int i, C0010b bVar) {
        int i2;
        float f;
        float f2;
        float f3;
        C0013c cVar2 = cVar;
        C0024e eVar2 = eVar;
        int i3 = i;
        C0010b bVar2 = bVar;
        C0010b bVar3 = null;
        int i4 = 0;
        int i5 = 0;
        float f4 = 0.0f;
        while (true) {
            boolean z = true;
            if (bVar2 == null) {
                break;
            }
            if (bVar2.mo92d() != 8) {
                z = false;
            }
            if (!z) {
                i4++;
                if (bVar2.f171G != C0012a.MATCH_CONSTRAINT) {
                    i5 = i5 + bVar2.mo102h() + (bVar2.f214i.f139c != null ? bVar2.f214i.mo56d() : 0) + (bVar2.f216k.f139c != null ? bVar2.f216k.mo56d() : 0);
                } else {
                    f4 += bVar2.f187W;
                }
            }
            C0010b bVar4 = bVar2.f216k.f139c != null ? bVar2.f216k.f139c.f137a : null;
            if (bVar4 != null && (bVar4.f214i.f139c == null || !(bVar4.f214i.f139c == null || bVar4.f214i.f139c.f137a == bVar2))) {
                bVar4 = null;
            }
            C0010b bVar5 = bVar4;
            bVar3 = bVar2;
            bVar2 = bVar5;
        }
        if (bVar3 != null) {
            i2 = bVar3.f216k.f139c != null ? bVar3.f216k.f139c.f137a.mo98f() : 0;
            if (bVar3.f216k.f139c != null && bVar3.f216k.f139c.f137a == cVar2) {
                i2 = cVar.mo119t();
            }
        } else {
            i2 = 0;
        }
        float f5 = ((float) (i2 - 0)) - ((float) i5);
        float f6 = f5 / ((float) (i4 + 1));
        if (i3 == 0) {
            f2 = f6;
            f = f2;
        } else {
            f = f5 / ((float) i3);
            f2 = 0.0f;
        }
        C0010b bVar6 = bVar;
        while (bVar6 != null) {
            int d = bVar6.f214i.f139c != null ? bVar6.f214i.mo56d() : 0;
            int d2 = bVar6.f216k.f139c != null ? bVar6.f216k.mo56d() : 0;
            if (bVar6.mo92d() != 8) {
                float f7 = (float) d;
                float f8 = f2 + f7;
                eVar2.mo182a(bVar6.f214i.f142f, (int) (f8 + 0.5f));
                if (bVar6.f171G == C0012a.MATCH_CONSTRAINT) {
                    f3 = (f4 == 0.0f ? f - f7 : ((bVar6.f187W * f5) / f4) - f7) - ((float) d2);
                } else {
                    f3 = (float) bVar6.mo102h();
                }
                float f9 = f8 + f3;
                eVar2.mo182a(bVar6.f216k.f142f, (int) (0.5f + f9));
                if (i3 == 0) {
                    f9 += f;
                }
                f2 = f9 + ((float) d2);
            } else {
                int i6 = (int) ((f2 - (f / 2.0f)) + 0.5f);
                eVar2.mo182a(bVar6.f214i.f142f, i6);
                eVar2.mo182a(bVar6.f216k.f142f, i6);
            }
            C0010b bVar7 = bVar6.f216k.f139c != null ? bVar6.f216k.f139c.f137a : null;
            if (!(bVar7 == null || bVar7.f214i.f139c == null || bVar7.f214i.f139c.f137a == bVar6)) {
                bVar7 = null;
            }
            bVar6 = bVar7 == cVar2 ? null : bVar7;
        }
    }

    /* renamed from: a */
    static void m144a(C0013c cVar, C0024e eVar, C0010b bVar) {
        if (cVar.f171G != C0012a.WRAP_CONTENT && bVar.f171G == C0012a.MATCH_PARENT) {
            bVar.f214i.f142f = eVar.mo178a((Object) bVar.f214i);
            bVar.f216k.f142f = eVar.mo178a((Object) bVar.f216k);
            int i = bVar.f214i.f140d;
            int h = cVar.mo102h() - bVar.f216k.f140d;
            eVar.mo182a(bVar.f214i.f142f, i);
            eVar.mo182a(bVar.f216k.f142f, h);
            bVar.mo91c(i, h);
            bVar.f191a = 2;
        }
        if (cVar.f172H != C0012a.WRAP_CONTENT && bVar.f172H == C0012a.MATCH_PARENT) {
            bVar.f215j.f142f = eVar.mo178a((Object) bVar.f215j);
            bVar.f217l.f142f = eVar.mo178a((Object) bVar.f217l);
            int i2 = bVar.f215j.f140d;
            int l = cVar.mo110l() - bVar.f217l.f140d;
            eVar.mo182a(bVar.f215j.f142f, i2);
            eVar.mo182a(bVar.f217l.f142f, l);
            if (bVar.f166A > 0 || bVar.mo92d() == 8) {
                bVar.f218m.f142f = eVar.mo178a((Object) bVar.f218m);
                eVar.mo182a(bVar.f218m.f142f, bVar.f166A + i2);
            }
            bVar.mo95d(i2, l);
            bVar.f207b = 2;
        }
    }

    /* renamed from: b */
    static void m145b(C0013c cVar, C0024e eVar, int i, C0010b bVar) {
        int i2;
        float f;
        float f2;
        float f3;
        C0013c cVar2 = cVar;
        C0024e eVar2 = eVar;
        int i3 = i;
        C0010b bVar2 = bVar;
        C0010b bVar3 = null;
        int i4 = 0;
        int i5 = 0;
        float f4 = 0.0f;
        while (true) {
            boolean z = true;
            if (bVar2 == null) {
                break;
            }
            if (bVar2.mo92d() != 8) {
                z = false;
            }
            if (!z) {
                i4++;
                if (bVar2.f172H != C0012a.MATCH_CONSTRAINT) {
                    i5 = i5 + bVar2.mo110l() + (bVar2.f215j.f139c != null ? bVar2.f215j.mo56d() : 0) + (bVar2.f217l.f139c != null ? bVar2.f217l.mo56d() : 0);
                } else {
                    f4 += bVar2.f188X;
                }
            }
            C0010b bVar4 = bVar2.f217l.f139c != null ? bVar2.f217l.f139c.f137a : null;
            if (bVar4 != null && (bVar4.f215j.f139c == null || !(bVar4.f215j.f139c == null || bVar4.f215j.f139c.f137a == bVar2))) {
                bVar4 = null;
            }
            C0010b bVar5 = bVar4;
            bVar3 = bVar2;
            bVar2 = bVar5;
        }
        if (bVar3 != null) {
            i2 = bVar3.f217l.f139c != null ? bVar3.f217l.f139c.f137a.mo98f() : 0;
            if (bVar3.f217l.f139c != null && bVar3.f217l.f139c.f137a == cVar2) {
                i2 = cVar.mo121u();
            }
        } else {
            i2 = 0;
        }
        float f5 = ((float) (i2 - 0)) - ((float) i5);
        float f6 = f5 / ((float) (i4 + 1));
        if (i3 == 0) {
            f2 = f6;
            f = f2;
        } else {
            f = f5 / ((float) i3);
            f2 = 0.0f;
        }
        C0010b bVar6 = bVar;
        while (bVar6 != null) {
            int d = bVar6.f215j.f139c != null ? bVar6.f215j.mo56d() : 0;
            int d2 = bVar6.f217l.f139c != null ? bVar6.f217l.mo56d() : 0;
            if (bVar6.mo92d() != 8) {
                float f7 = (float) d;
                float f8 = f2 + f7;
                eVar2.mo182a(bVar6.f215j.f142f, (int) (f8 + 0.5f));
                if (bVar6.f172H == C0012a.MATCH_CONSTRAINT) {
                    f3 = (f4 == 0.0f ? f - f7 : ((bVar6.f188X * f5) / f4) - f7) - ((float) d2);
                } else {
                    f3 = (float) bVar6.mo110l();
                }
                float f9 = f8 + f3;
                eVar2.mo182a(bVar6.f217l.f142f, (int) (0.5f + f9));
                if (i3 == 0) {
                    f9 += f;
                }
                f2 = f9 + ((float) d2);
            } else {
                int i6 = (int) ((f2 - (f / 2.0f)) + 0.5f);
                eVar2.mo182a(bVar6.f215j.f142f, i6);
                eVar2.mo182a(bVar6.f217l.f142f, i6);
            }
            C0010b bVar7 = bVar6.f217l.f139c != null ? bVar6.f217l.f139c.f137a : null;
            if (!(bVar7 == null || bVar7.f215j.f139c == null || bVar7.f215j.f139c.f137a == bVar6)) {
                bVar7 = null;
            }
            bVar6 = bVar7 == cVar2 ? null : bVar7;
        }
    }

    /* renamed from: b */
    static void m146b(C0013c cVar, C0024e eVar, C0010b bVar) {
        int d;
        int d2;
        int h;
        int i;
        if (bVar.f171G == C0012a.MATCH_CONSTRAINT) {
            bVar.f191a = 1;
        } else if (cVar.f171G != C0012a.WRAP_CONTENT && bVar.f171G == C0012a.MATCH_PARENT) {
            bVar.f214i.f142f = eVar.mo178a((Object) bVar.f214i);
            bVar.f216k.f142f = eVar.mo178a((Object) bVar.f216k);
            int i2 = bVar.f214i.f140d;
            int h2 = cVar.mo102h() - bVar.f216k.f140d;
            eVar.mo182a(bVar.f214i.f142f, i2);
            eVar.mo182a(bVar.f216k.f142f, h2);
            bVar.mo91c(i2, h2);
            bVar.f191a = 2;
        } else if (bVar.f214i.f139c == null || bVar.f216k.f139c == null) {
            if (bVar.f214i.f139c == null || bVar.f214i.f139c.f137a != cVar) {
                if (bVar.f216k.f139c != null && bVar.f216k.f139c.f137a == cVar) {
                    bVar.f214i.f142f = eVar.mo178a((Object) bVar.f214i);
                    bVar.f216k.f142f = eVar.mo178a((Object) bVar.f216k);
                    d = cVar.mo102h() - bVar.f216k.mo56d();
                } else if (bVar.f214i.f139c != null && bVar.f214i.f139c.f137a.f191a == 2) {
                    C0028g gVar = bVar.f214i.f139c.f142f;
                    bVar.f214i.f142f = eVar.mo178a((Object) bVar.f214i);
                    bVar.f216k.f142f = eVar.mo178a((Object) bVar.f216k);
                    d2 = (int) (gVar.f309d + ((float) bVar.f214i.mo56d()) + 0.5f);
                    h = bVar.mo102h() + d2;
                } else if (bVar.f216k.f139c == null || bVar.f216k.f139c.f137a.f191a != 2) {
                    boolean z = bVar.f214i.f139c != null;
                    boolean z2 = bVar.f216k.f139c != null;
                    if (!z && !z2) {
                        if (bVar instanceof C0014d) {
                            C0014d dVar = (C0014d) bVar;
                            if (dVar.mo127D() == 1) {
                                bVar.f214i.f142f = eVar.mo178a((Object) bVar.f214i);
                                bVar.f216k.f142f = eVar.mo178a((Object) bVar.f216k);
                                float f = dVar.mo139F() != -1 ? (float) dVar.mo139F() : dVar.mo140G() != -1 ? (float) (cVar.mo102h() - dVar.mo140G()) : dVar.mo138E() * ((float) cVar.mo102h());
                                int i3 = (int) (f + 0.5f);
                                eVar.mo182a(bVar.f214i.f142f, i3);
                                eVar.mo182a(bVar.f216k.f142f, i3);
                                bVar.f191a = 2;
                                bVar.f207b = 2;
                                bVar.mo91c(i3, i3);
                                bVar.mo95d(0, cVar.mo110l());
                                return;
                            }
                        } else {
                            bVar.f214i.f142f = eVar.mo178a((Object) bVar.f214i);
                            bVar.f216k.f142f = eVar.mo178a((Object) bVar.f216k);
                            int f2 = bVar.mo98f();
                            int h3 = bVar.mo102h() + f2;
                            eVar.mo182a(bVar.f214i.f142f, f2);
                            eVar.mo182a(bVar.f216k.f142f, h3);
                            bVar.f191a = 2;
                        }
                    }
                    return;
                } else {
                    C0028g gVar2 = bVar.f216k.f139c.f142f;
                    bVar.f214i.f142f = eVar.mo178a((Object) bVar.f214i);
                    bVar.f216k.f142f = eVar.mo178a((Object) bVar.f216k);
                    d = (int) ((gVar2.f309d - ((float) bVar.f216k.mo56d())) + 0.5f);
                }
                int h4 = d - bVar.mo102h();
                eVar.mo182a(bVar.f214i.f142f, h4);
                eVar.mo182a(bVar.f216k.f142f, d);
                bVar.f191a = 2;
                bVar.mo91c(h4, d);
                return;
            }
            d2 = bVar.f214i.mo56d();
            h = bVar.mo102h() + d2;
            bVar.f214i.f142f = eVar.mo178a((Object) bVar.f214i);
            bVar.f216k.f142f = eVar.mo178a((Object) bVar.f216k);
            eVar.mo182a(bVar.f214i.f142f, d2);
            eVar.mo182a(bVar.f216k.f142f, h);
            bVar.f191a = 2;
            bVar.mo91c(d2, h);
        } else if (bVar.f214i.f139c.f137a == cVar && bVar.f216k.f139c.f137a == cVar) {
            int d3 = bVar.f214i.mo56d();
            int d4 = bVar.f216k.mo56d();
            if (cVar.f171G == C0012a.MATCH_CONSTRAINT) {
                i = cVar.mo102h() - d4;
            } else {
                d3 += (int) ((((float) (((cVar.mo102h() - d3) - d4) - bVar.mo102h())) * bVar.f169E) + 0.5f);
                i = bVar.mo102h() + d3;
            }
            bVar.f214i.f142f = eVar.mo178a((Object) bVar.f214i);
            bVar.f216k.f142f = eVar.mo178a((Object) bVar.f216k);
            eVar.mo182a(bVar.f214i.f142f, d3);
            eVar.mo182a(bVar.f216k.f142f, i);
            bVar.f191a = 2;
            bVar.mo91c(d3, i);
        } else {
            bVar.f191a = 1;
        }
    }

    /* JADX WARNING: Code restructure failed: missing block: B:43:0x0143, code lost:
        if (r10.mo92d() != 8) goto L_0x0147;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:53:0x0196, code lost:
        if (r10.mo92d() != 8) goto L_0x01ac;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:64:0x0203, code lost:
        if (r10.mo92d() != 8) goto L_0x0147;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:72:0x0259, code lost:
        if (r10.mo92d() != 8) goto L_0x01ac;
     */
    /* renamed from: c */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    static void m147c(android.support.constraint.p000a.p001a.C0013c r8, android.support.constraint.p000a.C0024e r9, android.support.constraint.p000a.p001a.C0010b r10) {
        /*
            android.support.constraint.a.a.b$a r0 = r10.f172H
            android.support.constraint.a.a.b$a r1 = android.support.constraint.p000a.p001a.C0010b.C0012a.MATCH_CONSTRAINT
            r2 = 1
            if (r0 != r1) goto L_0x000a
            r10.f207b = r2
            return
        L_0x000a:
            android.support.constraint.a.a.b$a r0 = r8.f172H
            android.support.constraint.a.a.b$a r1 = android.support.constraint.p000a.p001a.C0010b.C0012a.WRAP_CONTENT
            r3 = 8
            r4 = 2
            if (r0 == r1) goto L_0x006c
            android.support.constraint.a.a.b$a r0 = r10.f172H
            android.support.constraint.a.a.b$a r1 = android.support.constraint.p000a.p001a.C0010b.C0012a.MATCH_PARENT
            if (r0 != r1) goto L_0x006c
            android.support.constraint.a.a.a r0 = r10.f215j
            android.support.constraint.a.a.a r1 = r10.f215j
            android.support.constraint.a.g r1 = r9.mo178a(r1)
            r0.f142f = r1
            android.support.constraint.a.a.a r0 = r10.f217l
            android.support.constraint.a.a.a r1 = r10.f217l
            android.support.constraint.a.g r1 = r9.mo178a(r1)
            r0.f142f = r1
            android.support.constraint.a.a.a r0 = r10.f215j
            int r0 = r0.f140d
            int r8 = r8.mo110l()
            android.support.constraint.a.a.a r1 = r10.f217l
            int r1 = r1.f140d
            int r8 = r8 - r1
            android.support.constraint.a.a.a r1 = r10.f215j
            android.support.constraint.a.g r1 = r1.f142f
            r9.mo182a(r1, r0)
            android.support.constraint.a.a.a r1 = r10.f217l
            android.support.constraint.a.g r1 = r1.f142f
            r9.mo182a(r1, r8)
            int r1 = r10.f166A
            if (r1 > 0) goto L_0x0052
            int r1 = r10.mo92d()
            if (r1 != r3) goto L_0x0066
        L_0x0052:
            android.support.constraint.a.a.a r1 = r10.f218m
            android.support.constraint.a.a.a r2 = r10.f218m
            android.support.constraint.a.g r2 = r9.mo178a(r2)
            r1.f142f = r2
            android.support.constraint.a.a.a r1 = r10.f218m
            android.support.constraint.a.g r1 = r1.f142f
            int r2 = r10.f166A
            int r2 = r2 + r0
            r9.mo182a(r1, r2)
        L_0x0066:
            r10.mo95d(r0, r8)
            r10.f207b = r4
            return
        L_0x006c:
            android.support.constraint.a.a.a r0 = r10.f215j
            android.support.constraint.a.a.a r0 = r0.f139c
            r1 = 1056964608(0x3f000000, float:0.5)
            if (r0 == 0) goto L_0x0100
            android.support.constraint.a.a.a r0 = r10.f217l
            android.support.constraint.a.a.a r0 = r0.f139c
            if (r0 == 0) goto L_0x0100
            android.support.constraint.a.a.a r0 = r10.f215j
            android.support.constraint.a.a.a r0 = r0.f139c
            android.support.constraint.a.a.b r0 = r0.f137a
            if (r0 != r8) goto L_0x00fd
            android.support.constraint.a.a.a r0 = r10.f217l
            android.support.constraint.a.a.a r0 = r0.f139c
            android.support.constraint.a.a.b r0 = r0.f137a
            if (r0 != r8) goto L_0x00fd
            android.support.constraint.a.a.a r0 = r10.f215j
            int r0 = r0.mo56d()
            android.support.constraint.a.a.a r2 = r10.f217l
            int r2 = r2.mo56d()
            android.support.constraint.a.a.b$a r5 = r8.f172H
            android.support.constraint.a.a.b$a r6 = android.support.constraint.p000a.p001a.C0010b.C0012a.MATCH_CONSTRAINT
            if (r5 != r6) goto L_0x00a2
        L_0x009c:
            int r8 = r10.mo110l()
            int r8 = r8 + r0
            goto L_0x00b7
        L_0x00a2:
            int r5 = r10.mo110l()
            int r8 = r8.mo110l()
            int r8 = r8 - r0
            int r8 = r8 - r2
            int r8 = r8 - r5
            float r0 = (float) r0
            float r8 = (float) r8
            float r2 = r10.f170F
            float r8 = r8 * r2
            float r0 = r0 + r8
            float r0 = r0 + r1
            int r0 = (int) r0
            goto L_0x009c
        L_0x00b7:
            android.support.constraint.a.a.a r1 = r10.f215j
            android.support.constraint.a.a.a r2 = r10.f215j
            android.support.constraint.a.g r2 = r9.mo178a(r2)
            r1.f142f = r2
            android.support.constraint.a.a.a r1 = r10.f217l
            android.support.constraint.a.a.a r2 = r10.f217l
            android.support.constraint.a.g r2 = r9.mo178a(r2)
            r1.f142f = r2
            android.support.constraint.a.a.a r1 = r10.f215j
            android.support.constraint.a.g r1 = r1.f142f
            r9.mo182a(r1, r0)
            android.support.constraint.a.a.a r1 = r10.f217l
            android.support.constraint.a.g r1 = r1.f142f
            r9.mo182a(r1, r8)
            int r1 = r10.f166A
            if (r1 > 0) goto L_0x00e3
            int r1 = r10.mo92d()
            if (r1 != r3) goto L_0x00f7
        L_0x00e3:
            android.support.constraint.a.a.a r1 = r10.f218m
            android.support.constraint.a.a.a r2 = r10.f218m
            android.support.constraint.a.g r2 = r9.mo178a(r2)
            r1.f142f = r2
            android.support.constraint.a.a.a r1 = r10.f218m
            android.support.constraint.a.g r1 = r1.f142f
            int r2 = r10.f166A
            int r2 = r2 + r0
            r9.mo182a(r1, r2)
        L_0x00f7:
            r10.f207b = r4
            r10.mo95d(r0, r8)
            return
        L_0x00fd:
            r10.f207b = r2
            return
        L_0x0100:
            android.support.constraint.a.a.a r0 = r10.f215j
            android.support.constraint.a.a.a r0 = r0.f139c
            if (r0 == 0) goto L_0x014d
            android.support.constraint.a.a.a r0 = r10.f215j
            android.support.constraint.a.a.a r0 = r0.f139c
            android.support.constraint.a.a.b r0 = r0.f137a
            if (r0 != r8) goto L_0x014d
            android.support.constraint.a.a.a r8 = r10.f215j
            int r8 = r8.mo56d()
            int r0 = r10.mo110l()
            int r0 = r0 + r8
            android.support.constraint.a.a.a r1 = r10.f215j
            android.support.constraint.a.a.a r2 = r10.f215j
            android.support.constraint.a.g r2 = r9.mo178a(r2)
            r1.f142f = r2
            android.support.constraint.a.a.a r1 = r10.f217l
            android.support.constraint.a.a.a r2 = r10.f217l
            android.support.constraint.a.g r2 = r9.mo178a(r2)
            r1.f142f = r2
            android.support.constraint.a.a.a r1 = r10.f215j
            android.support.constraint.a.g r1 = r1.f142f
            r9.mo182a(r1, r8)
            android.support.constraint.a.a.a r1 = r10.f217l
            android.support.constraint.a.g r1 = r1.f142f
            r9.mo182a(r1, r0)
            int r1 = r10.f166A
            if (r1 > 0) goto L_0x02a2
            int r1 = r10.mo92d()
            if (r1 != r3) goto L_0x0147
        L_0x0145:
            goto L_0x02a2
        L_0x0147:
            r10.f207b = r4
            r10.mo95d(r8, r0)
            return
        L_0x014d:
            android.support.constraint.a.a.a r0 = r10.f217l
            android.support.constraint.a.a.a r0 = r0.f139c
            if (r0 == 0) goto L_0x01b2
            android.support.constraint.a.a.a r0 = r10.f217l
            android.support.constraint.a.a.a r0 = r0.f139c
            android.support.constraint.a.a.b r0 = r0.f137a
            if (r0 != r8) goto L_0x01b2
            android.support.constraint.a.a.a r0 = r10.f215j
            android.support.constraint.a.a.a r1 = r10.f215j
            android.support.constraint.a.g r1 = r9.mo178a(r1)
            r0.f142f = r1
            android.support.constraint.a.a.a r0 = r10.f217l
            android.support.constraint.a.a.a r1 = r10.f217l
            android.support.constraint.a.g r1 = r9.mo178a(r1)
            r0.f142f = r1
            int r8 = r8.mo110l()
            android.support.constraint.a.a.a r0 = r10.f217l
            int r0 = r0.mo56d()
            int r8 = r8 - r0
            int r0 = r10.mo110l()
            int r0 = r8 - r0
            android.support.constraint.a.a.a r1 = r10.f215j
            android.support.constraint.a.g r1 = r1.f142f
            r9.mo182a(r1, r0)
            android.support.constraint.a.a.a r1 = r10.f217l
            android.support.constraint.a.g r1 = r1.f142f
            r9.mo182a(r1, r8)
            int r1 = r10.f166A
            if (r1 > 0) goto L_0x0198
            int r1 = r10.mo92d()
            if (r1 != r3) goto L_0x01ac
        L_0x0198:
            android.support.constraint.a.a.a r1 = r10.f218m
            android.support.constraint.a.a.a r2 = r10.f218m
            android.support.constraint.a.g r2 = r9.mo178a(r2)
            r1.f142f = r2
            android.support.constraint.a.a.a r1 = r10.f218m
            android.support.constraint.a.g r1 = r1.f142f
            int r2 = r10.f166A
            int r2 = r2 + r0
            r9.mo182a(r1, r2)
        L_0x01ac:
            r10.f207b = r4
            r10.mo95d(r0, r8)
            return
        L_0x01b2:
            android.support.constraint.a.a.a r0 = r10.f215j
            android.support.constraint.a.a.a r0 = r0.f139c
            if (r0 == 0) goto L_0x0207
            android.support.constraint.a.a.a r0 = r10.f215j
            android.support.constraint.a.a.a r0 = r0.f139c
            android.support.constraint.a.a.b r0 = r0.f137a
            int r0 = r0.f207b
            if (r0 != r4) goto L_0x0207
            android.support.constraint.a.a.a r8 = r10.f215j
            android.support.constraint.a.a.a r8 = r8.f139c
            android.support.constraint.a.g r8 = r8.f142f
            android.support.constraint.a.a.a r0 = r10.f215j
            android.support.constraint.a.a.a r2 = r10.f215j
            android.support.constraint.a.g r2 = r9.mo178a(r2)
            r0.f142f = r2
            android.support.constraint.a.a.a r0 = r10.f217l
            android.support.constraint.a.a.a r2 = r10.f217l
            android.support.constraint.a.g r2 = r9.mo178a(r2)
            r0.f142f = r2
            float r8 = r8.f309d
            android.support.constraint.a.a.a r0 = r10.f215j
            int r0 = r0.mo56d()
            float r0 = (float) r0
            float r8 = r8 + r0
            float r8 = r8 + r1
            int r8 = (int) r8
            int r0 = r10.mo110l()
            int r0 = r0 + r8
            android.support.constraint.a.a.a r1 = r10.f215j
            android.support.constraint.a.g r1 = r1.f142f
            r9.mo182a(r1, r8)
            android.support.constraint.a.a.a r1 = r10.f217l
            android.support.constraint.a.g r1 = r1.f142f
            r9.mo182a(r1, r0)
            int r1 = r10.f166A
            if (r1 > 0) goto L_0x02a2
            int r1 = r10.mo92d()
            if (r1 != r3) goto L_0x0147
            goto L_0x0145
        L_0x0207:
            android.support.constraint.a.a.a r0 = r10.f217l
            android.support.constraint.a.a.a r0 = r0.f139c
            if (r0 == 0) goto L_0x025d
            android.support.constraint.a.a.a r0 = r10.f217l
            android.support.constraint.a.a.a r0 = r0.f139c
            android.support.constraint.a.a.b r0 = r0.f137a
            int r0 = r0.f207b
            if (r0 != r4) goto L_0x025d
            android.support.constraint.a.a.a r8 = r10.f217l
            android.support.constraint.a.a.a r8 = r8.f139c
            android.support.constraint.a.g r8 = r8.f142f
            android.support.constraint.a.a.a r0 = r10.f215j
            android.support.constraint.a.a.a r2 = r10.f215j
            android.support.constraint.a.g r2 = r9.mo178a(r2)
            r0.f142f = r2
            android.support.constraint.a.a.a r0 = r10.f217l
            android.support.constraint.a.a.a r2 = r10.f217l
            android.support.constraint.a.g r2 = r9.mo178a(r2)
            r0.f142f = r2
            float r8 = r8.f309d
            android.support.constraint.a.a.a r0 = r10.f217l
            int r0 = r0.mo56d()
            float r0 = (float) r0
            float r8 = r8 - r0
            float r8 = r8 + r1
            int r8 = (int) r8
            int r0 = r10.mo110l()
            int r0 = r8 - r0
            android.support.constraint.a.a.a r1 = r10.f215j
            android.support.constraint.a.g r1 = r1.f142f
            r9.mo182a(r1, r0)
            android.support.constraint.a.a.a r1 = r10.f217l
            android.support.constraint.a.g r1 = r1.f142f
            r9.mo182a(r1, r8)
            int r1 = r10.f166A
            if (r1 > 0) goto L_0x0198
            int r1 = r10.mo92d()
            if (r1 != r3) goto L_0x01ac
            goto L_0x0198
        L_0x025d:
            android.support.constraint.a.a.a r0 = r10.f218m
            android.support.constraint.a.a.a r0 = r0.f139c
            if (r0 == 0) goto L_0x02b8
            android.support.constraint.a.a.a r0 = r10.f218m
            android.support.constraint.a.a.a r0 = r0.f139c
            android.support.constraint.a.a.b r0 = r0.f137a
            int r0 = r0.f207b
            if (r0 != r4) goto L_0x02b8
            android.support.constraint.a.a.a r8 = r10.f218m
            android.support.constraint.a.a.a r8 = r8.f139c
            android.support.constraint.a.g r8 = r8.f142f
            android.support.constraint.a.a.a r0 = r10.f215j
            android.support.constraint.a.a.a r2 = r10.f215j
            android.support.constraint.a.g r2 = r9.mo178a(r2)
            r0.f142f = r2
            android.support.constraint.a.a.a r0 = r10.f217l
            android.support.constraint.a.a.a r2 = r10.f217l
            android.support.constraint.a.g r2 = r9.mo178a(r2)
            r0.f142f = r2
            float r8 = r8.f309d
            int r0 = r10.f166A
            float r0 = (float) r0
            float r8 = r8 - r0
            float r8 = r8 + r1
            int r8 = (int) r8
            int r0 = r10.mo110l()
            int r0 = r0 + r8
            android.support.constraint.a.a.a r1 = r10.f215j
            android.support.constraint.a.g r1 = r1.f142f
            r9.mo182a(r1, r8)
            android.support.constraint.a.a.a r1 = r10.f217l
            android.support.constraint.a.g r1 = r1.f142f
            r9.mo182a(r1, r0)
        L_0x02a2:
            android.support.constraint.a.a.a r1 = r10.f218m
            android.support.constraint.a.a.a r2 = r10.f218m
            android.support.constraint.a.g r2 = r9.mo178a(r2)
            r1.f142f = r2
            android.support.constraint.a.a.a r1 = r10.f218m
            android.support.constraint.a.g r1 = r1.f142f
            int r2 = r10.f166A
            int r2 = r2 + r8
            r9.mo182a(r1, r2)
            goto L_0x0147
        L_0x02b8:
            android.support.constraint.a.a.a r0 = r10.f218m
            android.support.constraint.a.a.a r0 = r0.f139c
            r5 = 0
            if (r0 == 0) goto L_0x02c1
            r0 = 1
            goto L_0x02c2
        L_0x02c1:
            r0 = 0
        L_0x02c2:
            android.support.constraint.a.a.a r6 = r10.f215j
            android.support.constraint.a.a.a r6 = r6.f139c
            if (r6 == 0) goto L_0x02ca
            r6 = 1
            goto L_0x02cb
        L_0x02ca:
            r6 = 0
        L_0x02cb:
            android.support.constraint.a.a.a r7 = r10.f217l
            android.support.constraint.a.a.a r7 = r7.f139c
            if (r7 == 0) goto L_0x02d2
            goto L_0x02d3
        L_0x02d2:
            r2 = 0
        L_0x02d3:
            if (r0 != 0) goto L_0x038d
            if (r6 != 0) goto L_0x038d
            if (r2 != 0) goto L_0x038d
            boolean r0 = r10 instanceof android.support.constraint.p000a.p001a.C0014d
            if (r0 == 0) goto L_0x0342
            r0 = r10
            android.support.constraint.a.a.d r0 = (android.support.constraint.p000a.p001a.C0014d) r0
            int r2 = r0.mo127D()
            if (r2 != 0) goto L_0x038d
            android.support.constraint.a.a.a r2 = r10.f215j
            android.support.constraint.a.a.a r3 = r10.f215j
            android.support.constraint.a.g r3 = r9.mo178a(r3)
            r2.f142f = r3
            android.support.constraint.a.a.a r2 = r10.f217l
            android.support.constraint.a.a.a r3 = r10.f217l
            android.support.constraint.a.g r3 = r9.mo178a(r3)
            r2.f142f = r3
            int r2 = r0.mo139F()
            r3 = -1
            if (r2 == r3) goto L_0x0307
            int r0 = r0.mo139F()
            float r0 = (float) r0
            goto L_0x0323
        L_0x0307:
            int r2 = r0.mo140G()
            if (r2 == r3) goto L_0x0318
            int r2 = r8.mo110l()
            int r0 = r0.mo140G()
            int r2 = r2 - r0
            float r0 = (float) r2
            goto L_0x0323
        L_0x0318:
            int r2 = r8.mo110l()
            float r2 = (float) r2
            float r0 = r0.mo138E()
            float r0 = r0 * r2
        L_0x0323:
            float r0 = r0 + r1
            int r0 = (int) r0
            android.support.constraint.a.a.a r1 = r10.f215j
            android.support.constraint.a.g r1 = r1.f142f
            r9.mo182a(r1, r0)
            android.support.constraint.a.a.a r1 = r10.f217l
            android.support.constraint.a.g r1 = r1.f142f
            r9.mo182a(r1, r0)
            r10.f207b = r4
            r10.f191a = r4
            r10.mo95d(r0, r0)
            int r8 = r8.mo102h()
            r10.mo91c(r5, r8)
            return
        L_0x0342:
            android.support.constraint.a.a.a r8 = r10.f215j
            android.support.constraint.a.a.a r0 = r10.f215j
            android.support.constraint.a.g r0 = r9.mo178a(r0)
            r8.f142f = r0
            android.support.constraint.a.a.a r8 = r10.f217l
            android.support.constraint.a.a.a r0 = r10.f217l
            android.support.constraint.a.g r0 = r9.mo178a(r0)
            r8.f142f = r0
            int r8 = r10.mo100g()
            int r0 = r10.mo110l()
            int r0 = r0 + r8
            android.support.constraint.a.a.a r1 = r10.f215j
            android.support.constraint.a.g r1 = r1.f142f
            r9.mo182a(r1, r8)
            android.support.constraint.a.a.a r1 = r10.f217l
            android.support.constraint.a.g r1 = r1.f142f
            r9.mo182a(r1, r0)
            int r0 = r10.f166A
            if (r0 > 0) goto L_0x0377
            int r0 = r10.mo92d()
            if (r0 != r3) goto L_0x038b
        L_0x0377:
            android.support.constraint.a.a.a r0 = r10.f218m
            android.support.constraint.a.a.a r1 = r10.f218m
            android.support.constraint.a.g r1 = r9.mo178a(r1)
            r0.f142f = r1
            android.support.constraint.a.a.a r0 = r10.f218m
            android.support.constraint.a.g r0 = r0.f142f
            int r1 = r10.f166A
            int r8 = r8 + r1
            r9.mo182a(r0, r8)
        L_0x038b:
            r10.f207b = r4
        L_0x038d:
            return
        */
        throw new UnsupportedOperationException("Method not decompiled: android.support.constraint.p000a.p001a.C0016e.m147c(android.support.constraint.a.a.c, android.support.constraint.a.e, android.support.constraint.a.a.b):void");
    }
}
