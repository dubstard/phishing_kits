package android.support.constraint.p000a.p001a;

import android.support.constraint.p000a.C0024e;
import android.support.constraint.p000a.p001a.C0010b.C0012a;
import java.util.ArrayList;
import java.util.Arrays;

/* renamed from: android.support.constraint.a.a.c */
public class C0013c extends C0020h {

    /* renamed from: ac */
    static boolean f238ac = true;

    /* renamed from: aa */
    protected C0024e f239aa = new C0024e();

    /* renamed from: ab */
    protected C0024e f240ab = null;

    /* renamed from: ad */
    int f241ad;

    /* renamed from: ae */
    int f242ae;

    /* renamed from: af */
    int f243af;

    /* renamed from: ag */
    int f244ag;

    /* renamed from: ah */
    int f245ah;

    /* renamed from: ai */
    int f246ai;

    /* renamed from: ak */
    private C0018g f247ak;

    /* renamed from: al */
    private int f248al = 0;

    /* renamed from: am */
    private int f249am = 0;

    /* renamed from: an */
    private C0010b[] f250an = new C0010b[4];

    /* renamed from: ao */
    private C0010b[] f251ao = new C0010b[4];

    /* renamed from: ap */
    private C0010b[] f252ap = new C0010b[4];

    /* renamed from: aq */
    private int f253aq = 2;

    /* renamed from: ar */
    private boolean[] f254ar = new boolean[3];

    /* renamed from: as */
    private C0010b[] f255as = new C0010b[4];

    /* renamed from: at */
    private boolean f256at = false;

    /* renamed from: au */
    private boolean f257au = false;

    /* renamed from: J */
    private void m112J() {
        this.f248al = 0;
        this.f249am = 0;
    }

    /* renamed from: a */
    private int m113a(C0024e eVar, C0010b[] bVarArr, C0010b bVar, int i, boolean[] zArr) {
        char c;
        char c2;
        C0024e eVar2 = eVar;
        C0010b bVar2 = bVar;
        zArr[0] = true;
        zArr[1] = false;
        C0010b bVar3 = null;
        bVarArr[0] = null;
        bVarArr[2] = null;
        bVarArr[1] = null;
        bVarArr[3] = null;
        float f = 0.0f;
        int i2 = 5;
        int i3 = 8;
        if (i == 0) {
            boolean z = bVar2.f214i.f139c == null || bVar2.f214i.f139c.f137a == this;
            bVar2.f189Y = null;
            C0010b bVar4 = null;
            C0010b bVar5 = bVar.mo92d() != 8 ? bVar2 : null;
            C0010b bVar6 = bVar5;
            int i4 = 0;
            C0010b bVar7 = bVar2;
            while (bVar7.f216k.f139c != null) {
                bVar7.f189Y = bVar3;
                if (bVar7.mo92d() != 8) {
                    if (bVar6 == null) {
                        bVar6 = bVar7;
                    }
                    if (!(bVar5 == null || bVar5 == bVar7)) {
                        bVar5.f189Y = bVar7;
                    }
                    bVar5 = bVar7;
                } else {
                    eVar2.mo188c(bVar7.f214i.f142f, bVar7.f214i.f139c.f142f, 0, 5);
                    eVar2.mo188c(bVar7.f216k.f142f, bVar7.f214i.f142f, 0, 5);
                }
                if (bVar7.mo92d() != 8 && bVar7.f171G == C0012a.MATCH_CONSTRAINT) {
                    if (bVar7.f172H == C0012a.MATCH_CONSTRAINT) {
                        zArr[0] = false;
                    }
                    if (bVar7.f226u <= f) {
                        zArr[0] = false;
                        int i5 = i4 + 1;
                        if (i5 >= this.f250an.length) {
                            this.f250an = (C0010b[]) Arrays.copyOf(this.f250an, this.f250an.length * 2);
                        }
                        this.f250an[i4] = bVar7;
                        i4 = i5;
                    }
                }
                if (bVar7.f216k.f139c.f137a.f214i.f139c == null || bVar7.f216k.f139c.f137a.f214i.f139c.f137a != bVar7 || bVar7.f216k.f139c.f137a == bVar7) {
                    break;
                }
                bVar4 = bVar7.f216k.f139c.f137a;
                bVar7 = bVar4;
                bVar3 = null;
                f = 0.0f;
            }
            if (!(bVar7.f216k.f139c == null || bVar7.f216k.f139c.f137a == this)) {
                z = false;
            }
            if (bVar2.f214i.f139c == null || bVar4.f216k.f139c == null) {
                c2 = 1;
                zArr[1] = true;
            } else {
                c2 = 1;
            }
            bVar2.f185U = z;
            bVar4.f189Y = null;
            bVarArr[0] = bVar2;
            bVarArr[2] = bVar6;
            bVarArr[c2] = bVar4;
            bVarArr[3] = bVar5;
            return i4;
        }
        boolean z2 = bVar2.f215j.f139c == null || bVar2.f215j.f139c.f137a == this;
        C0010b bVar8 = null;
        bVar2.f190Z = null;
        C0010b bVar9 = null;
        C0010b bVar10 = bVar.mo92d() != 8 ? bVar2 : null;
        C0010b bVar11 = bVar10;
        int i6 = 0;
        C0010b bVar12 = bVar2;
        while (bVar12.f217l.f139c != null) {
            bVar12.f190Z = bVar8;
            if (bVar12.mo92d() != i3) {
                if (bVar10 == null) {
                    bVar10 = bVar12;
                }
                if (!(bVar11 == null || bVar11 == bVar12)) {
                    bVar11.f190Z = bVar12;
                }
                bVar11 = bVar12;
            } else {
                eVar2.mo188c(bVar12.f215j.f142f, bVar12.f215j.f139c.f142f, 0, i2);
                eVar2.mo188c(bVar12.f217l.f142f, bVar12.f215j.f142f, 0, i2);
            }
            if (bVar12.mo92d() != i3 && bVar12.f172H == C0012a.MATCH_CONSTRAINT) {
                if (bVar12.f171G == C0012a.MATCH_CONSTRAINT) {
                    zArr[0] = false;
                }
                if (bVar12.f226u <= 0.0f) {
                    zArr[0] = false;
                    int i7 = i6 + 1;
                    if (i7 >= this.f250an.length) {
                        this.f250an = (C0010b[]) Arrays.copyOf(this.f250an, this.f250an.length * 2);
                    }
                    this.f250an[i6] = bVar12;
                    i6 = i7;
                }
            }
            if (bVar12.f217l.f139c.f137a.f215j.f139c == null || bVar12.f217l.f139c.f137a.f215j.f139c.f137a != bVar12 || bVar12.f217l.f139c.f137a == bVar12) {
                break;
            }
            bVar9 = bVar12.f217l.f139c.f137a;
            bVar12 = bVar9;
            bVar8 = null;
            i2 = 5;
            i3 = 8;
        }
        int i8 = i6;
        if (!(bVar12.f217l.f139c == null || bVar12.f217l.f139c.f137a == this)) {
            z2 = false;
        }
        if (bVar2.f215j.f139c == null || bVar9.f217l.f139c == null) {
            c = 1;
            zArr[1] = true;
        } else {
            c = 1;
        }
        bVar2.f186V = z2;
        bVar9.f190Z = null;
        bVarArr[0] = bVar2;
        bVarArr[2] = bVar10;
        bVarArr[c] = bVar9;
        bVarArr[3] = bVar11;
        return i8;
    }

    /* renamed from: a */
    private boolean m114a(C0024e eVar) {
        int size = this.f278aj.size();
        for (int i = 0; i < size; i++) {
            C0010b bVar = (C0010b) this.f278aj.get(i);
            bVar.f191a = -1;
            bVar.f207b = -1;
            if (bVar.f171G == C0012a.MATCH_CONSTRAINT || bVar.f172H == C0012a.MATCH_CONSTRAINT) {
                bVar.f191a = 1;
                bVar.f207b = 1;
            }
        }
        boolean z = false;
        int i2 = 0;
        int i3 = 0;
        while (!z) {
            int i4 = 0;
            int i5 = 0;
            for (int i6 = 0; i6 < size; i6++) {
                C0010b bVar2 = (C0010b) this.f278aj.get(i6);
                if (bVar2.f191a == -1) {
                    if (this.f171G == C0012a.WRAP_CONTENT) {
                        bVar2.f191a = 1;
                    } else {
                        C0016e.m146b(this, eVar, bVar2);
                    }
                }
                if (bVar2.f207b == -1) {
                    if (this.f172H == C0012a.WRAP_CONTENT) {
                        bVar2.f207b = 1;
                    } else {
                        C0016e.m147c(this, eVar, bVar2);
                    }
                }
                if (bVar2.f207b == -1) {
                    i4++;
                }
                if (bVar2.f191a == -1) {
                    i5++;
                }
            }
            if ((i4 == 0 && i5 == 0) || (i2 == i4 && i3 == i5)) {
                z = true;
            }
            i2 = i4;
            i3 = i5;
        }
        int i7 = 0;
        int i8 = 0;
        for (int i9 = 0; i9 < size; i9++) {
            C0010b bVar3 = (C0010b) this.f278aj.get(i9);
            if (bVar3.f191a == 1 || bVar3.f191a == -1) {
                i7++;
            }
            if (bVar3.f207b == 1 || bVar3.f207b == -1) {
                i8++;
            }
        }
        return i7 == 0 && i8 == 0;
    }

    /* JADX WARNING: Removed duplicated region for block: B:195:0x04b4  */
    /* JADX WARNING: Removed duplicated region for block: B:227:0x04b6 A[SYNTHETIC] */
    /* renamed from: b */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    private void m115b(android.support.constraint.p000a.C0024e r35) {
        /*
            r34 = this;
            r6 = r34
            r15 = r35
            r14 = 0
            r13 = 0
        L_0x0006:
            int r0 = r6.f248al
            if (r13 >= r0) goto L_0x0516
            android.support.constraint.a.a.b[] r0 = r6.f252ap
            r12 = r0[r13]
            android.support.constraint.a.a.b[] r2 = r6.f255as
            android.support.constraint.a.a.b[] r0 = r6.f252ap
            r3 = r0[r13]
            r4 = 0
            boolean[] r5 = r6.f254ar
            r0 = r6
            r1 = r15
            int r0 = r0.m113a(r1, r2, r3, r4, r5)
            android.support.constraint.a.a.b[] r1 = r6.f255as
            r2 = 2
            r1 = r1[r2]
            if (r1 != 0) goto L_0x002a
        L_0x0024:
            r4 = r13
            r3 = r15
            r19 = 0
            goto L_0x050e
        L_0x002a:
            boolean[] r3 = r6.f254ar
            r4 = 1
            boolean r3 = r3[r4]
            if (r3 == 0) goto L_0x0055
            int r0 = r12.mo113n()
        L_0x0035:
            if (r1 == 0) goto L_0x0024
            android.support.constraint.a.a.a r2 = r1.f214i
            android.support.constraint.a.g r2 = r2.f142f
            r15.mo182a(r2, r0)
            android.support.constraint.a.a.b r2 = r1.f189Y
            android.support.constraint.a.a.a r3 = r1.f214i
            int r3 = r3.mo56d()
            int r4 = r1.mo102h()
            int r3 = r3 + r4
            android.support.constraint.a.a.a r1 = r1.f216k
            int r1 = r1.mo56d()
            int r3 = r3 + r1
            int r0 = r0 + r3
            r1 = r2
            goto L_0x0035
        L_0x0055:
            int r3 = r12.f183S
            if (r3 != 0) goto L_0x005b
            r3 = 1
            goto L_0x005c
        L_0x005b:
            r3 = 0
        L_0x005c:
            int r5 = r12.f183S
            if (r5 != r2) goto L_0x0062
            r5 = 1
            goto L_0x0063
        L_0x0062:
            r5 = 0
        L_0x0063:
            android.support.constraint.a.a.b$a r7 = r6.f171G
            android.support.constraint.a.a.b$a r8 = android.support.constraint.p000a.p001a.C0010b.C0012a.WRAP_CONTENT
            if (r7 != r8) goto L_0x006b
            r7 = 1
            goto L_0x006c
        L_0x006b:
            r7 = 0
        L_0x006c:
            int r8 = r6.f253aq
            if (r8 == r2) goto L_0x0076
            int r8 = r6.f253aq
            r9 = 8
            if (r8 != r9) goto L_0x008c
        L_0x0076:
            boolean[] r8 = r6.f254ar
            boolean r8 = r8[r14]
            if (r8 == 0) goto L_0x008c
            boolean r8 = r12.f185U
            if (r8 == 0) goto L_0x008c
            if (r5 != 0) goto L_0x008c
            if (r7 != 0) goto L_0x008c
            int r7 = r12.f183S
            if (r7 != 0) goto L_0x008c
            android.support.constraint.p000a.p001a.C0016e.m143a(r6, r15, r0, r12)
            goto L_0x0024
        L_0x008c:
            r11 = 3
            r16 = 0
            if (r0 == 0) goto L_0x0349
            if (r5 == 0) goto L_0x0095
            goto L_0x0349
        L_0x0095:
            r3 = 0
            r3 = r16
            r5 = 0
        L_0x0099:
            if (r1 == 0) goto L_0x015d
            android.support.constraint.a.a.b$a r7 = r1.f171G
            android.support.constraint.a.a.b$a r8 = android.support.constraint.p000a.p001a.C0010b.C0012a.MATCH_CONSTRAINT
            if (r7 == r8) goto L_0x0117
            android.support.constraint.a.a.a r7 = r1.f214i
            int r7 = r7.mo56d()
            if (r3 == 0) goto L_0x00b0
            android.support.constraint.a.a.a r3 = r3.f216k
            int r3 = r3.mo56d()
            int r7 = r7 + r3
        L_0x00b0:
            android.support.constraint.a.a.a r3 = r1.f214i
            android.support.constraint.a.a.a r3 = r3.f139c
            android.support.constraint.a.a.b r3 = r3.f137a
            android.support.constraint.a.a.b$a r3 = r3.f171G
            android.support.constraint.a.a.b$a r8 = android.support.constraint.p000a.p001a.C0010b.C0012a.MATCH_CONSTRAINT
            if (r3 != r8) goto L_0x00be
            r3 = 2
            goto L_0x00bf
        L_0x00be:
            r3 = 3
        L_0x00bf:
            android.support.constraint.a.a.a r8 = r1.f214i
            android.support.constraint.a.g r8 = r8.f142f
            android.support.constraint.a.a.a r9 = r1.f214i
            android.support.constraint.a.a.a r9 = r9.f139c
            android.support.constraint.a.g r9 = r9.f142f
            r15.mo184a(r8, r9, r7, r3)
            android.support.constraint.a.a.a r3 = r1.f216k
            int r3 = r3.mo56d()
            android.support.constraint.a.a.a r7 = r1.f216k
            android.support.constraint.a.a.a r7 = r7.f139c
            android.support.constraint.a.a.b r7 = r7.f137a
            android.support.constraint.a.a.a r7 = r7.f214i
            android.support.constraint.a.a.a r7 = r7.f139c
            if (r7 == 0) goto L_0x00f9
            android.support.constraint.a.a.a r7 = r1.f216k
            android.support.constraint.a.a.a r7 = r7.f139c
            android.support.constraint.a.a.b r7 = r7.f137a
            android.support.constraint.a.a.a r7 = r7.f214i
            android.support.constraint.a.a.a r7 = r7.f139c
            android.support.constraint.a.a.b r7 = r7.f137a
            if (r7 != r1) goto L_0x00f9
            android.support.constraint.a.a.a r7 = r1.f216k
            android.support.constraint.a.a.a r7 = r7.f139c
            android.support.constraint.a.a.b r7 = r7.f137a
            android.support.constraint.a.a.a r7 = r7.f214i
            int r7 = r7.mo56d()
            int r3 = r3 + r7
        L_0x00f9:
            android.support.constraint.a.a.a r7 = r1.f216k
            android.support.constraint.a.a.a r7 = r7.f139c
            android.support.constraint.a.a.b r7 = r7.f137a
            android.support.constraint.a.a.b$a r7 = r7.f171G
            android.support.constraint.a.a.b$a r8 = android.support.constraint.p000a.p001a.C0010b.C0012a.MATCH_CONSTRAINT
            if (r7 != r8) goto L_0x0107
            r7 = 2
            goto L_0x0108
        L_0x0107:
            r7 = 3
        L_0x0108:
            android.support.constraint.a.a.a r8 = r1.f216k
            android.support.constraint.a.g r8 = r8.f142f
            android.support.constraint.a.a.a r9 = r1.f216k
            android.support.constraint.a.a.a r9 = r9.f139c
            android.support.constraint.a.g r9 = r9.f142f
            int r3 = -r3
            r15.mo187b(r8, r9, r3, r7)
            goto L_0x0154
        L_0x0117:
            float r3 = r1.f187W
            float r5 = r5 + r3
            android.support.constraint.a.a.a r3 = r1.f216k
            android.support.constraint.a.a.a r3 = r3.f139c
            if (r3 == 0) goto L_0x013a
            android.support.constraint.a.a.a r3 = r1.f216k
            int r3 = r3.mo56d()
            android.support.constraint.a.a.b[] r7 = r6.f255as
            r7 = r7[r11]
            if (r1 == r7) goto L_0x013b
            android.support.constraint.a.a.a r7 = r1.f216k
            android.support.constraint.a.a.a r7 = r7.f139c
            android.support.constraint.a.a.b r7 = r7.f137a
            android.support.constraint.a.a.a r7 = r7.f214i
            int r7 = r7.mo56d()
            int r3 = r3 + r7
            goto L_0x013b
        L_0x013a:
            r3 = 0
        L_0x013b:
            android.support.constraint.a.a.a r7 = r1.f216k
            android.support.constraint.a.g r7 = r7.f142f
            android.support.constraint.a.a.a r8 = r1.f214i
            android.support.constraint.a.g r8 = r8.f142f
            r15.mo184a(r7, r8, r14, r4)
            android.support.constraint.a.a.a r7 = r1.f216k
            android.support.constraint.a.g r7 = r7.f142f
            android.support.constraint.a.a.a r8 = r1.f216k
            android.support.constraint.a.a.a r8 = r8.f139c
            android.support.constraint.a.g r8 = r8.f142f
            int r3 = -r3
            r15.mo187b(r7, r8, r3, r4)
        L_0x0154:
            android.support.constraint.a.a.b r3 = r1.f189Y
            r33 = r3
            r3 = r1
            r1 = r33
            goto L_0x0099
        L_0x015d:
            if (r0 != r4) goto L_0x01e4
            android.support.constraint.a.a.b[] r0 = r6.f250an
            r0 = r0[r14]
            android.support.constraint.a.a.a r1 = r0.f214i
            int r1 = r1.mo56d()
            android.support.constraint.a.a.a r3 = r0.f214i
            android.support.constraint.a.a.a r3 = r3.f139c
            if (r3 == 0) goto L_0x0178
            android.support.constraint.a.a.a r3 = r0.f214i
            android.support.constraint.a.a.a r3 = r3.f139c
            int r3 = r3.mo56d()
            int r1 = r1 + r3
        L_0x0178:
            android.support.constraint.a.a.a r3 = r0.f216k
            int r3 = r3.mo56d()
            android.support.constraint.a.a.a r5 = r0.f216k
            android.support.constraint.a.a.a r5 = r5.f139c
            if (r5 == 0) goto L_0x018d
            android.support.constraint.a.a.a r5 = r0.f216k
            android.support.constraint.a.a.a r5 = r5.f139c
            int r5 = r5.mo56d()
            int r3 = r3 + r5
        L_0x018d:
            android.support.constraint.a.a.a r5 = r12.f216k
            android.support.constraint.a.a.a r5 = r5.f139c
            android.support.constraint.a.g r5 = r5.f142f
            android.support.constraint.a.a.b[] r7 = r6.f255as
            r7 = r7[r11]
            if (r0 != r7) goto L_0x01a3
            android.support.constraint.a.a.b[] r5 = r6.f255as
            r5 = r5[r4]
            android.support.constraint.a.a.a r5 = r5.f216k
            android.support.constraint.a.a.a r5 = r5.f139c
            android.support.constraint.a.g r5 = r5.f142f
        L_0x01a3:
            int r7 = r0.f208c
            if (r7 != r4) goto L_0x01cd
            android.support.constraint.a.a.a r0 = r12.f214i
            android.support.constraint.a.g r0 = r0.f142f
            android.support.constraint.a.a.a r7 = r12.f214i
            android.support.constraint.a.a.a r7 = r7.f139c
            android.support.constraint.a.g r7 = r7.f142f
            r15.mo184a(r0, r7, r1, r4)
            android.support.constraint.a.a.a r0 = r12.f216k
            android.support.constraint.a.g r0 = r0.f142f
            int r1 = -r3
            r15.mo187b(r0, r5, r1, r4)
            android.support.constraint.a.a.a r0 = r12.f216k
            android.support.constraint.a.g r0 = r0.f142f
            android.support.constraint.a.a.a r1 = r12.f214i
            android.support.constraint.a.g r1 = r1.f142f
            int r3 = r12.mo102h()
            r15.mo188c(r0, r1, r3, r2)
            goto L_0x0024
        L_0x01cd:
            android.support.constraint.a.a.a r2 = r0.f214i
            android.support.constraint.a.g r2 = r2.f142f
            android.support.constraint.a.a.a r7 = r0.f214i
            android.support.constraint.a.a.a r7 = r7.f139c
            android.support.constraint.a.g r7 = r7.f142f
            r15.mo188c(r2, r7, r1, r4)
            android.support.constraint.a.a.a r0 = r0.f216k
            android.support.constraint.a.g r0 = r0.f142f
            int r1 = -r3
            r15.mo188c(r0, r5, r1, r4)
            goto L_0x0024
        L_0x01e4:
            r1 = 0
        L_0x01e5:
            int r3 = r0 + -1
            if (r1 >= r3) goto L_0x0024
            android.support.constraint.a.a.b[] r7 = r6.f250an
            r7 = r7[r1]
            android.support.constraint.a.a.b[] r8 = r6.f250an
            int r1 = r1 + 1
            r8 = r8[r1]
            android.support.constraint.a.a.a r9 = r7.f214i
            android.support.constraint.a.g r9 = r9.f142f
            android.support.constraint.a.a.a r10 = r7.f216k
            android.support.constraint.a.g r10 = r10.f142f
            android.support.constraint.a.a.a r14 = r8.f214i
            android.support.constraint.a.g r14 = r14.f142f
            android.support.constraint.a.a.a r2 = r8.f216k
            android.support.constraint.a.g r2 = r2.f142f
            android.support.constraint.a.a.b[] r4 = r6.f255as
            r4 = r4[r11]
            if (r8 != r4) goto L_0x0212
            android.support.constraint.a.a.b[] r2 = r6.f255as
            r4 = 1
            r2 = r2[r4]
            android.support.constraint.a.a.a r2 = r2.f216k
            android.support.constraint.a.g r2 = r2.f142f
        L_0x0212:
            android.support.constraint.a.a.a r4 = r7.f214i
            int r4 = r4.mo56d()
            android.support.constraint.a.a.a r11 = r7.f214i
            android.support.constraint.a.a.a r11 = r11.f139c
            if (r11 == 0) goto L_0x0245
            android.support.constraint.a.a.a r11 = r7.f214i
            android.support.constraint.a.a.a r11 = r11.f139c
            android.support.constraint.a.a.b r11 = r11.f137a
            android.support.constraint.a.a.a r11 = r11.f216k
            android.support.constraint.a.a.a r11 = r11.f139c
            if (r11 == 0) goto L_0x0245
            android.support.constraint.a.a.a r11 = r7.f214i
            android.support.constraint.a.a.a r11 = r11.f139c
            android.support.constraint.a.a.b r11 = r11.f137a
            android.support.constraint.a.a.a r11 = r11.f216k
            android.support.constraint.a.a.a r11 = r11.f139c
            android.support.constraint.a.a.b r11 = r11.f137a
            if (r11 != r7) goto L_0x0245
            android.support.constraint.a.a.a r11 = r7.f214i
            android.support.constraint.a.a.a r11 = r11.f139c
            android.support.constraint.a.a.b r11 = r11.f137a
            android.support.constraint.a.a.a r11 = r11.f216k
            int r11 = r11.mo56d()
            int r4 = r4 + r11
        L_0x0245:
            android.support.constraint.a.a.a r11 = r7.f214i
            android.support.constraint.a.a.a r11 = r11.f139c
            android.support.constraint.a.g r11 = r11.f142f
            r28 = r0
            r0 = 2
            r15.mo184a(r9, r11, r4, r0)
            android.support.constraint.a.a.a r0 = r7.f216k
            int r0 = r0.mo56d()
            android.support.constraint.a.a.a r4 = r7.f216k
            android.support.constraint.a.a.a r4 = r4.f139c
            if (r4 == 0) goto L_0x0274
            android.support.constraint.a.a.b r4 = r7.f189Y
            if (r4 == 0) goto L_0x0274
            android.support.constraint.a.a.b r4 = r7.f189Y
            android.support.constraint.a.a.a r4 = r4.f214i
            android.support.constraint.a.a.a r4 = r4.f139c
            if (r4 == 0) goto L_0x0272
            android.support.constraint.a.a.b r4 = r7.f189Y
            android.support.constraint.a.a.a r4 = r4.f214i
            int r4 = r4.mo56d()
            goto L_0x0273
        L_0x0272:
            r4 = 0
        L_0x0273:
            int r0 = r0 + r4
        L_0x0274:
            android.support.constraint.a.a.a r4 = r7.f216k
            android.support.constraint.a.a.a r4 = r4.f139c
            android.support.constraint.a.g r4 = r4.f142f
            int r0 = -r0
            r11 = 2
            r15.mo187b(r10, r4, r0, r11)
            if (r1 != r3) goto L_0x0301
            android.support.constraint.a.a.a r0 = r8.f214i
            int r0 = r0.mo56d()
            android.support.constraint.a.a.a r3 = r8.f214i
            android.support.constraint.a.a.a r3 = r3.f139c
            if (r3 == 0) goto L_0x02b4
            android.support.constraint.a.a.a r3 = r8.f214i
            android.support.constraint.a.a.a r3 = r3.f139c
            android.support.constraint.a.a.b r3 = r3.f137a
            android.support.constraint.a.a.a r3 = r3.f216k
            android.support.constraint.a.a.a r3 = r3.f139c
            if (r3 == 0) goto L_0x02b4
            android.support.constraint.a.a.a r3 = r8.f214i
            android.support.constraint.a.a.a r3 = r3.f139c
            android.support.constraint.a.a.b r3 = r3.f137a
            android.support.constraint.a.a.a r3 = r3.f216k
            android.support.constraint.a.a.a r3 = r3.f139c
            android.support.constraint.a.a.b r3 = r3.f137a
            if (r3 != r8) goto L_0x02b4
            android.support.constraint.a.a.a r3 = r8.f214i
            android.support.constraint.a.a.a r3 = r3.f139c
            android.support.constraint.a.a.b r3 = r3.f137a
            android.support.constraint.a.a.a r3 = r3.f216k
            int r3 = r3.mo56d()
            int r0 = r0 + r3
        L_0x02b4:
            android.support.constraint.a.a.a r3 = r8.f214i
            android.support.constraint.a.a.a r3 = r3.f139c
            android.support.constraint.a.g r3 = r3.f142f
            r4 = 2
            r15.mo184a(r14, r3, r0, r4)
            android.support.constraint.a.a.a r0 = r8.f216k
            android.support.constraint.a.a.b[] r3 = r6.f255as
            r4 = 3
            r3 = r3[r4]
            if (r8 != r3) goto L_0x02ce
            android.support.constraint.a.a.b[] r0 = r6.f255as
            r3 = 1
            r0 = r0[r3]
            android.support.constraint.a.a.a r0 = r0.f216k
        L_0x02ce:
            int r3 = r0.mo56d()
            android.support.constraint.a.a.a r4 = r0.f139c
            if (r4 == 0) goto L_0x02f7
            android.support.constraint.a.a.a r4 = r0.f139c
            android.support.constraint.a.a.b r4 = r4.f137a
            android.support.constraint.a.a.a r4 = r4.f214i
            android.support.constraint.a.a.a r4 = r4.f139c
            if (r4 == 0) goto L_0x02f7
            android.support.constraint.a.a.a r4 = r0.f139c
            android.support.constraint.a.a.b r4 = r4.f137a
            android.support.constraint.a.a.a r4 = r4.f214i
            android.support.constraint.a.a.a r4 = r4.f139c
            android.support.constraint.a.a.b r4 = r4.f137a
            if (r4 != r8) goto L_0x02f7
            android.support.constraint.a.a.a r4 = r0.f139c
            android.support.constraint.a.a.b r4 = r4.f137a
            android.support.constraint.a.a.a r4 = r4.f214i
            int r4 = r4.mo56d()
            int r3 = r3 + r4
        L_0x02f7:
            android.support.constraint.a.a.a r0 = r0.f139c
            android.support.constraint.a.g r0 = r0.f142f
            int r3 = -r3
            r4 = 2
            r15.mo187b(r2, r0, r3, r4)
            goto L_0x0302
        L_0x0301:
            r4 = 2
        L_0x0302:
            int r0 = r12.f211f
            if (r0 <= 0) goto L_0x030b
            int r0 = r12.f211f
            r15.mo187b(r10, r9, r0, r4)
        L_0x030b:
            android.support.constraint.a.b r0 = r35.mo186b()
            float r3 = r7.f187W
            float r11 = r8.f187W
            android.support.constraint.a.a.a r4 = r7.f214i
            int r21 = r4.mo56d()
            android.support.constraint.a.a.a r4 = r7.f216k
            int r23 = r4.mo56d()
            android.support.constraint.a.a.a r4 = r8.f214i
            int r25 = r4.mo56d()
            android.support.constraint.a.a.a r4 = r8.f216k
            int r27 = r4.mo56d()
            r16 = r0
            r17 = r3
            r18 = r5
            r19 = r11
            r20 = r9
            r22 = r10
            r24 = r14
            r26 = r2
            r16.mo153a(r17, r18, r19, r20, r21, r22, r23, r24, r25, r26, r27)
            r15.mo180a(r0)
            r0 = r28
            r2 = 2
            r4 = 1
            r11 = 3
            r14 = 0
            goto L_0x01e5
        L_0x0349:
            r0 = r1
            r2 = r16
            r4 = r2
            r7 = 0
        L_0x034e:
            if (r0 == 0) goto L_0x04c5
            android.support.constraint.a.a.b r8 = r0.f189Y
            if (r8 != 0) goto L_0x035c
            android.support.constraint.a.a.b[] r2 = r6.f255as
            r7 = 1
            r2 = r2[r7]
            r14 = r2
            r2 = 1
            goto L_0x035e
        L_0x035c:
            r14 = r2
            r2 = r7
        L_0x035e:
            if (r5 == 0) goto L_0x03b6
            android.support.constraint.a.a.a r7 = r0.f214i
            int r9 = r7.mo56d()
            if (r4 == 0) goto L_0x036f
            android.support.constraint.a.a.a r4 = r4.f216k
            int r4 = r4.mo56d()
            int r9 = r9 + r4
        L_0x036f:
            if (r1 == r0) goto L_0x0373
            r4 = 3
            goto L_0x0374
        L_0x0373:
            r4 = 1
        L_0x0374:
            android.support.constraint.a.g r10 = r7.f142f
            android.support.constraint.a.a.a r11 = r7.f139c
            android.support.constraint.a.g r11 = r11.f142f
            r15.mo184a(r10, r11, r9, r4)
            android.support.constraint.a.a.b$a r4 = r0.f171G
            android.support.constraint.a.a.b$a r9 = android.support.constraint.p000a.p001a.C0010b.C0012a.MATCH_CONSTRAINT
            if (r4 != r9) goto L_0x03b4
            android.support.constraint.a.a.a r4 = r0.f216k
            int r9 = r0.f208c
            r10 = 1
            if (r9 != r10) goto L_0x039e
            int r9 = r0.f210e
            int r10 = r0.mo102h()
            int r9 = java.lang.Math.max(r9, r10)
            android.support.constraint.a.g r4 = r4.f142f
            android.support.constraint.a.g r7 = r7.f142f
            r11 = 3
            r15.mo188c(r4, r7, r9, r11)
            goto L_0x040b
        L_0x039e:
            r11 = 3
            android.support.constraint.a.g r9 = r7.f142f
            android.support.constraint.a.a.a r10 = r7.f139c
            android.support.constraint.a.g r10 = r10.f142f
            int r6 = r7.f140d
            r15.mo184a(r9, r10, r6, r11)
            android.support.constraint.a.g r4 = r4.f142f
            android.support.constraint.a.g r6 = r7.f142f
            int r7 = r0.f210e
            r15.mo187b(r4, r6, r7, r11)
            goto L_0x040b
        L_0x03b4:
            r11 = 3
            goto L_0x040b
        L_0x03b6:
            r11 = 3
            r6 = 5
            if (r3 != 0) goto L_0x03e5
            if (r2 == 0) goto L_0x03e5
            if (r4 == 0) goto L_0x03e5
            android.support.constraint.a.a.a r4 = r0.f216k
            android.support.constraint.a.a.a r4 = r4.f139c
            if (r4 != 0) goto L_0x03d0
            android.support.constraint.a.a.a r4 = r0.f216k
            android.support.constraint.a.g r4 = r4.f142f
            int r6 = r0.mo116q()
        L_0x03cc:
            r15.mo182a(r4, r6)
            goto L_0x040b
        L_0x03d0:
            android.support.constraint.a.a.a r4 = r0.f216k
            int r4 = r4.mo56d()
            android.support.constraint.a.a.a r7 = r0.f216k
            android.support.constraint.a.g r7 = r7.f142f
            android.support.constraint.a.a.a r9 = r14.f216k
            android.support.constraint.a.a.a r9 = r9.f139c
            android.support.constraint.a.g r9 = r9.f142f
            int r4 = -r4
        L_0x03e1:
            r15.mo188c(r7, r9, r4, r6)
            goto L_0x040b
        L_0x03e5:
            if (r3 != 0) goto L_0x0418
            if (r2 != 0) goto L_0x0418
            if (r4 != 0) goto L_0x0418
            android.support.constraint.a.a.a r4 = r0.f214i
            android.support.constraint.a.a.a r4 = r4.f139c
            if (r4 != 0) goto L_0x03fa
            android.support.constraint.a.a.a r4 = r0.f214i
            android.support.constraint.a.g r4 = r4.f142f
            int r6 = r0.mo113n()
            goto L_0x03cc
        L_0x03fa:
            android.support.constraint.a.a.a r4 = r0.f214i
            int r4 = r4.mo56d()
            android.support.constraint.a.a.a r7 = r0.f214i
            android.support.constraint.a.g r7 = r7.f142f
            android.support.constraint.a.a.a r9 = r12.f214i
            android.support.constraint.a.a.a r9 = r9.f139c
            android.support.constraint.a.g r9 = r9.f142f
            goto L_0x03e1
        L_0x040b:
            r29 = r0
            r30 = r3
            r0 = r12
            r4 = r13
            r18 = r14
            r3 = r15
            r19 = 0
            goto L_0x04b2
        L_0x0418:
            android.support.constraint.a.a.a r6 = r0.f214i
            android.support.constraint.a.a.a r7 = r0.f216k
            int r10 = r6.mo56d()
            int r9 = r7.mo56d()
            android.support.constraint.a.g r11 = r6.f142f
            r29 = r0
            android.support.constraint.a.a.a r0 = r6.f139c
            android.support.constraint.a.g r0 = r0.f142f
            r30 = r3
            r3 = 1
            r15.mo184a(r11, r0, r10, r3)
            android.support.constraint.a.g r0 = r7.f142f
            android.support.constraint.a.a.a r11 = r7.f139c
            android.support.constraint.a.g r11 = r11.f142f
            r31 = r13
            int r13 = -r9
            r15.mo187b(r0, r11, r13, r3)
            android.support.constraint.a.a.a r0 = r6.f139c
            if (r0 == 0) goto L_0x0447
            android.support.constraint.a.a.a r0 = r6.f139c
            android.support.constraint.a.g r0 = r0.f142f
            goto L_0x0449
        L_0x0447:
            r0 = r16
        L_0x0449:
            if (r4 != 0) goto L_0x045a
            android.support.constraint.a.a.a r0 = r12.f214i
            android.support.constraint.a.a.a r0 = r0.f139c
            if (r0 == 0) goto L_0x0458
            android.support.constraint.a.a.a r0 = r12.f214i
            android.support.constraint.a.a.a r0 = r0.f139c
            android.support.constraint.a.g r0 = r0.f142f
            goto L_0x045a
        L_0x0458:
            r0 = r16
        L_0x045a:
            if (r8 != 0) goto L_0x046c
            android.support.constraint.a.a.a r3 = r14.f216k
            android.support.constraint.a.a.a r3 = r3.f139c
            if (r3 == 0) goto L_0x046a
            android.support.constraint.a.a.a r3 = r14.f216k
            android.support.constraint.a.a.a r3 = r3.f139c
            android.support.constraint.a.a.b r3 = r3.f137a
            r8 = r3
            goto L_0x046c
        L_0x046a:
            r8 = r16
        L_0x046c:
            r3 = r8
            if (r3 == 0) goto L_0x04a6
            android.support.constraint.a.a.a r4 = r3.f214i
            android.support.constraint.a.g r4 = r4.f142f
            if (r2 == 0) goto L_0x0484
            android.support.constraint.a.a.a r4 = r14.f216k
            android.support.constraint.a.a.a r4 = r4.f139c
            if (r4 == 0) goto L_0x0482
            android.support.constraint.a.a.a r4 = r14.f216k
            android.support.constraint.a.a.a r4 = r4.f139c
            android.support.constraint.a.g r4 = r4.f142f
            goto L_0x0484
        L_0x0482:
            r4 = r16
        L_0x0484:
            if (r0 == 0) goto L_0x04a6
            if (r4 == 0) goto L_0x04a6
            android.support.constraint.a.g r8 = r6.f142f
            r11 = 1056964608(0x3f000000, float:0.5)
            android.support.constraint.a.g r13 = r7.f142f
            r6 = 4
            r7 = r15
            r17 = r9
            r9 = r0
            r0 = 3
            r0 = r12
            r12 = r4
            r4 = r31
            r18 = r14
            r19 = 0
            r14 = r17
            r32 = r3
            r3 = r15
            r15 = r6
            r7.mo183a(r8, r9, r10, r11, r12, r13, r14, r15)
            goto L_0x04b0
        L_0x04a6:
            r32 = r3
            r0 = r12
            r18 = r14
            r3 = r15
            r4 = r31
            r19 = 0
        L_0x04b0:
            r8 = r32
        L_0x04b2:
            if (r2 == 0) goto L_0x04b6
            r8 = r16
        L_0x04b6:
            r12 = r0
            r7 = r2
            r15 = r3
            r13 = r4
            r0 = r8
            r2 = r18
            r4 = r29
            r3 = r30
            r6 = r34
            goto L_0x034e
        L_0x04c5:
            r0 = r12
            r4 = r13
            r3 = r15
            r19 = 0
            if (r5 == 0) goto L_0x050e
            android.support.constraint.a.a.a r1 = r1.f214i
            android.support.constraint.a.a.a r5 = r2.f216k
            int r10 = r1.mo56d()
            int r14 = r5.mo56d()
            android.support.constraint.a.a.a r6 = r0.f214i
            android.support.constraint.a.a.a r6 = r6.f139c
            if (r6 == 0) goto L_0x04e6
            android.support.constraint.a.a.a r6 = r0.f214i
            android.support.constraint.a.a.a r6 = r6.f139c
            android.support.constraint.a.g r6 = r6.f142f
            r9 = r6
            goto L_0x04e8
        L_0x04e6:
            r9 = r16
        L_0x04e8:
            android.support.constraint.a.a.a r6 = r2.f216k
            android.support.constraint.a.a.a r6 = r6.f139c
            if (r6 == 0) goto L_0x04f6
            android.support.constraint.a.a.a r2 = r2.f216k
            android.support.constraint.a.a.a r2 = r2.f139c
            android.support.constraint.a.g r2 = r2.f142f
            r12 = r2
            goto L_0x04f8
        L_0x04f6:
            r12 = r16
        L_0x04f8:
            if (r9 == 0) goto L_0x050e
            if (r12 == 0) goto L_0x050e
            android.support.constraint.a.g r2 = r5.f142f
            int r6 = -r14
            r7 = 1
            r3.mo187b(r2, r12, r6, r7)
            android.support.constraint.a.g r8 = r1.f142f
            float r11 = r0.f169E
            android.support.constraint.a.g r13 = r5.f142f
            r15 = 4
            r7 = r3
            r7.mo183a(r8, r9, r10, r11, r12, r13, r14, r15)
        L_0x050e:
            int r13 = r4 + 1
            r15 = r3
            r6 = r34
            r14 = 0
            goto L_0x0006
        L_0x0516:
            return
        */
        throw new UnsupportedOperationException("Method not decompiled: android.support.constraint.p000a.p001a.C0013c.m115b(android.support.constraint.a.e):void");
    }

    /* JADX WARNING: Removed duplicated region for block: B:205:0x04d7  */
    /* JADX WARNING: Removed duplicated region for block: B:237:0x04d9 A[SYNTHETIC] */
    /* renamed from: c */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    private void m116c(android.support.constraint.p000a.C0024e r35) {
        /*
            r34 = this;
            r6 = r34
            r15 = r35
            r14 = 0
            r13 = 0
        L_0x0006:
            int r0 = r6.f249am
            if (r13 >= r0) goto L_0x0539
            android.support.constraint.a.a.b[] r0 = r6.f251ao
            r12 = r0[r13]
            android.support.constraint.a.a.b[] r2 = r6.f255as
            android.support.constraint.a.a.b[] r0 = r6.f251ao
            r3 = r0[r13]
            r4 = 1
            boolean[] r5 = r6.f254ar
            r0 = r6
            r1 = r15
            int r0 = r0.m113a(r1, r2, r3, r4, r5)
            android.support.constraint.a.a.b[] r1 = r6.f255as
            r2 = 2
            r1 = r1[r2]
            if (r1 != 0) goto L_0x002a
        L_0x0024:
            r4 = r13
            r3 = r15
            r19 = 0
            goto L_0x0531
        L_0x002a:
            boolean[] r3 = r6.f254ar
            r4 = 1
            boolean r3 = r3[r4]
            if (r3 == 0) goto L_0x0055
            int r0 = r12.mo114o()
        L_0x0035:
            if (r1 == 0) goto L_0x0024
            android.support.constraint.a.a.a r2 = r1.f215j
            android.support.constraint.a.g r2 = r2.f142f
            r15.mo182a(r2, r0)
            android.support.constraint.a.a.b r2 = r1.f190Z
            android.support.constraint.a.a.a r3 = r1.f215j
            int r3 = r3.mo56d()
            int r4 = r1.mo110l()
            int r3 = r3 + r4
            android.support.constraint.a.a.a r1 = r1.f217l
            int r1 = r1.mo56d()
            int r3 = r3 + r1
            int r0 = r0 + r3
            r1 = r2
            goto L_0x0035
        L_0x0055:
            int r3 = r12.f184T
            if (r3 != 0) goto L_0x005b
            r3 = 1
            goto L_0x005c
        L_0x005b:
            r3 = 0
        L_0x005c:
            int r5 = r12.f184T
            if (r5 != r2) goto L_0x0062
            r5 = 1
            goto L_0x0063
        L_0x0062:
            r5 = 0
        L_0x0063:
            android.support.constraint.a.a.b$a r7 = r6.f172H
            android.support.constraint.a.a.b$a r8 = android.support.constraint.p000a.p001a.C0010b.C0012a.WRAP_CONTENT
            if (r7 != r8) goto L_0x006b
            r7 = 1
            goto L_0x006c
        L_0x006b:
            r7 = 0
        L_0x006c:
            int r8 = r6.f253aq
            if (r8 == r2) goto L_0x0076
            int r8 = r6.f253aq
            r9 = 8
            if (r8 != r9) goto L_0x008c
        L_0x0076:
            boolean[] r8 = r6.f254ar
            boolean r8 = r8[r14]
            if (r8 == 0) goto L_0x008c
            boolean r8 = r12.f186V
            if (r8 == 0) goto L_0x008c
            if (r5 != 0) goto L_0x008c
            if (r7 != 0) goto L_0x008c
            int r7 = r12.f184T
            if (r7 != 0) goto L_0x008c
            android.support.constraint.p000a.p001a.C0016e.m145b(r6, r15, r0, r12)
            goto L_0x0024
        L_0x008c:
            r11 = 3
            r16 = 0
            if (r0 == 0) goto L_0x0349
            if (r5 == 0) goto L_0x0095
            goto L_0x0349
        L_0x0095:
            r3 = 0
            r3 = r16
            r5 = 0
        L_0x0099:
            if (r1 == 0) goto L_0x015d
            android.support.constraint.a.a.b$a r7 = r1.f172H
            android.support.constraint.a.a.b$a r8 = android.support.constraint.p000a.p001a.C0010b.C0012a.MATCH_CONSTRAINT
            if (r7 == r8) goto L_0x0117
            android.support.constraint.a.a.a r7 = r1.f215j
            int r7 = r7.mo56d()
            if (r3 == 0) goto L_0x00b0
            android.support.constraint.a.a.a r3 = r3.f217l
            int r3 = r3.mo56d()
            int r7 = r7 + r3
        L_0x00b0:
            android.support.constraint.a.a.a r3 = r1.f215j
            android.support.constraint.a.a.a r3 = r3.f139c
            android.support.constraint.a.a.b r3 = r3.f137a
            android.support.constraint.a.a.b$a r3 = r3.f172H
            android.support.constraint.a.a.b$a r8 = android.support.constraint.p000a.p001a.C0010b.C0012a.MATCH_CONSTRAINT
            if (r3 != r8) goto L_0x00be
            r3 = 2
            goto L_0x00bf
        L_0x00be:
            r3 = 3
        L_0x00bf:
            android.support.constraint.a.a.a r8 = r1.f215j
            android.support.constraint.a.g r8 = r8.f142f
            android.support.constraint.a.a.a r9 = r1.f215j
            android.support.constraint.a.a.a r9 = r9.f139c
            android.support.constraint.a.g r9 = r9.f142f
            r15.mo184a(r8, r9, r7, r3)
            android.support.constraint.a.a.a r3 = r1.f217l
            int r3 = r3.mo56d()
            android.support.constraint.a.a.a r7 = r1.f217l
            android.support.constraint.a.a.a r7 = r7.f139c
            android.support.constraint.a.a.b r7 = r7.f137a
            android.support.constraint.a.a.a r7 = r7.f215j
            android.support.constraint.a.a.a r7 = r7.f139c
            if (r7 == 0) goto L_0x00f9
            android.support.constraint.a.a.a r7 = r1.f217l
            android.support.constraint.a.a.a r7 = r7.f139c
            android.support.constraint.a.a.b r7 = r7.f137a
            android.support.constraint.a.a.a r7 = r7.f215j
            android.support.constraint.a.a.a r7 = r7.f139c
            android.support.constraint.a.a.b r7 = r7.f137a
            if (r7 != r1) goto L_0x00f9
            android.support.constraint.a.a.a r7 = r1.f217l
            android.support.constraint.a.a.a r7 = r7.f139c
            android.support.constraint.a.a.b r7 = r7.f137a
            android.support.constraint.a.a.a r7 = r7.f215j
            int r7 = r7.mo56d()
            int r3 = r3 + r7
        L_0x00f9:
            android.support.constraint.a.a.a r7 = r1.f217l
            android.support.constraint.a.a.a r7 = r7.f139c
            android.support.constraint.a.a.b r7 = r7.f137a
            android.support.constraint.a.a.b$a r7 = r7.f172H
            android.support.constraint.a.a.b$a r8 = android.support.constraint.p000a.p001a.C0010b.C0012a.MATCH_CONSTRAINT
            if (r7 != r8) goto L_0x0107
            r7 = 2
            goto L_0x0108
        L_0x0107:
            r7 = 3
        L_0x0108:
            android.support.constraint.a.a.a r8 = r1.f217l
            android.support.constraint.a.g r8 = r8.f142f
            android.support.constraint.a.a.a r9 = r1.f217l
            android.support.constraint.a.a.a r9 = r9.f139c
            android.support.constraint.a.g r9 = r9.f142f
            int r3 = -r3
            r15.mo187b(r8, r9, r3, r7)
            goto L_0x0154
        L_0x0117:
            float r3 = r1.f188X
            float r5 = r5 + r3
            android.support.constraint.a.a.a r3 = r1.f217l
            android.support.constraint.a.a.a r3 = r3.f139c
            if (r3 == 0) goto L_0x013a
            android.support.constraint.a.a.a r3 = r1.f217l
            int r3 = r3.mo56d()
            android.support.constraint.a.a.b[] r7 = r6.f255as
            r7 = r7[r11]
            if (r1 == r7) goto L_0x013b
            android.support.constraint.a.a.a r7 = r1.f217l
            android.support.constraint.a.a.a r7 = r7.f139c
            android.support.constraint.a.a.b r7 = r7.f137a
            android.support.constraint.a.a.a r7 = r7.f215j
            int r7 = r7.mo56d()
            int r3 = r3 + r7
            goto L_0x013b
        L_0x013a:
            r3 = 0
        L_0x013b:
            android.support.constraint.a.a.a r7 = r1.f217l
            android.support.constraint.a.g r7 = r7.f142f
            android.support.constraint.a.a.a r8 = r1.f215j
            android.support.constraint.a.g r8 = r8.f142f
            r15.mo184a(r7, r8, r14, r4)
            android.support.constraint.a.a.a r7 = r1.f217l
            android.support.constraint.a.g r7 = r7.f142f
            android.support.constraint.a.a.a r8 = r1.f217l
            android.support.constraint.a.a.a r8 = r8.f139c
            android.support.constraint.a.g r8 = r8.f142f
            int r3 = -r3
            r15.mo187b(r7, r8, r3, r4)
        L_0x0154:
            android.support.constraint.a.a.b r3 = r1.f190Z
            r33 = r3
            r3 = r1
            r1 = r33
            goto L_0x0099
        L_0x015d:
            if (r0 != r4) goto L_0x01e4
            android.support.constraint.a.a.b[] r0 = r6.f250an
            r0 = r0[r14]
            android.support.constraint.a.a.a r1 = r0.f215j
            int r1 = r1.mo56d()
            android.support.constraint.a.a.a r3 = r0.f215j
            android.support.constraint.a.a.a r3 = r3.f139c
            if (r3 == 0) goto L_0x0178
            android.support.constraint.a.a.a r3 = r0.f215j
            android.support.constraint.a.a.a r3 = r3.f139c
            int r3 = r3.mo56d()
            int r1 = r1 + r3
        L_0x0178:
            android.support.constraint.a.a.a r3 = r0.f217l
            int r3 = r3.mo56d()
            android.support.constraint.a.a.a r5 = r0.f217l
            android.support.constraint.a.a.a r5 = r5.f139c
            if (r5 == 0) goto L_0x018d
            android.support.constraint.a.a.a r5 = r0.f217l
            android.support.constraint.a.a.a r5 = r5.f139c
            int r5 = r5.mo56d()
            int r3 = r3 + r5
        L_0x018d:
            android.support.constraint.a.a.a r5 = r12.f217l
            android.support.constraint.a.a.a r5 = r5.f139c
            android.support.constraint.a.g r5 = r5.f142f
            android.support.constraint.a.a.b[] r7 = r6.f255as
            r7 = r7[r11]
            if (r0 != r7) goto L_0x01a3
            android.support.constraint.a.a.b[] r5 = r6.f255as
            r5 = r5[r4]
            android.support.constraint.a.a.a r5 = r5.f217l
            android.support.constraint.a.a.a r5 = r5.f139c
            android.support.constraint.a.g r5 = r5.f142f
        L_0x01a3:
            int r7 = r0.f209d
            if (r7 != r4) goto L_0x01cd
            android.support.constraint.a.a.a r0 = r12.f215j
            android.support.constraint.a.g r0 = r0.f142f
            android.support.constraint.a.a.a r7 = r12.f215j
            android.support.constraint.a.a.a r7 = r7.f139c
            android.support.constraint.a.g r7 = r7.f142f
            r15.mo184a(r0, r7, r1, r4)
            android.support.constraint.a.a.a r0 = r12.f217l
            android.support.constraint.a.g r0 = r0.f142f
            int r1 = -r3
            r15.mo187b(r0, r5, r1, r4)
            android.support.constraint.a.a.a r0 = r12.f217l
            android.support.constraint.a.g r0 = r0.f142f
            android.support.constraint.a.a.a r1 = r12.f215j
            android.support.constraint.a.g r1 = r1.f142f
            int r3 = r12.mo110l()
            r15.mo188c(r0, r1, r3, r2)
            goto L_0x0024
        L_0x01cd:
            android.support.constraint.a.a.a r2 = r0.f215j
            android.support.constraint.a.g r2 = r2.f142f
            android.support.constraint.a.a.a r7 = r0.f215j
            android.support.constraint.a.a.a r7 = r7.f139c
            android.support.constraint.a.g r7 = r7.f142f
            r15.mo188c(r2, r7, r1, r4)
            android.support.constraint.a.a.a r0 = r0.f217l
            android.support.constraint.a.g r0 = r0.f142f
            int r1 = -r3
            r15.mo188c(r0, r5, r1, r4)
            goto L_0x0024
        L_0x01e4:
            r1 = 0
        L_0x01e5:
            int r3 = r0 + -1
            if (r1 >= r3) goto L_0x0024
            android.support.constraint.a.a.b[] r7 = r6.f250an
            r7 = r7[r1]
            android.support.constraint.a.a.b[] r8 = r6.f250an
            int r1 = r1 + 1
            r8 = r8[r1]
            android.support.constraint.a.a.a r9 = r7.f215j
            android.support.constraint.a.g r9 = r9.f142f
            android.support.constraint.a.a.a r10 = r7.f217l
            android.support.constraint.a.g r10 = r10.f142f
            android.support.constraint.a.a.a r14 = r8.f215j
            android.support.constraint.a.g r14 = r14.f142f
            android.support.constraint.a.a.a r2 = r8.f217l
            android.support.constraint.a.g r2 = r2.f142f
            android.support.constraint.a.a.b[] r4 = r6.f255as
            r4 = r4[r11]
            if (r8 != r4) goto L_0x0212
            android.support.constraint.a.a.b[] r2 = r6.f255as
            r4 = 1
            r2 = r2[r4]
            android.support.constraint.a.a.a r2 = r2.f217l
            android.support.constraint.a.g r2 = r2.f142f
        L_0x0212:
            android.support.constraint.a.a.a r4 = r7.f215j
            int r4 = r4.mo56d()
            android.support.constraint.a.a.a r11 = r7.f215j
            android.support.constraint.a.a.a r11 = r11.f139c
            if (r11 == 0) goto L_0x0245
            android.support.constraint.a.a.a r11 = r7.f215j
            android.support.constraint.a.a.a r11 = r11.f139c
            android.support.constraint.a.a.b r11 = r11.f137a
            android.support.constraint.a.a.a r11 = r11.f217l
            android.support.constraint.a.a.a r11 = r11.f139c
            if (r11 == 0) goto L_0x0245
            android.support.constraint.a.a.a r11 = r7.f215j
            android.support.constraint.a.a.a r11 = r11.f139c
            android.support.constraint.a.a.b r11 = r11.f137a
            android.support.constraint.a.a.a r11 = r11.f217l
            android.support.constraint.a.a.a r11 = r11.f139c
            android.support.constraint.a.a.b r11 = r11.f137a
            if (r11 != r7) goto L_0x0245
            android.support.constraint.a.a.a r11 = r7.f215j
            android.support.constraint.a.a.a r11 = r11.f139c
            android.support.constraint.a.a.b r11 = r11.f137a
            android.support.constraint.a.a.a r11 = r11.f217l
            int r11 = r11.mo56d()
            int r4 = r4 + r11
        L_0x0245:
            android.support.constraint.a.a.a r11 = r7.f215j
            android.support.constraint.a.a.a r11 = r11.f139c
            android.support.constraint.a.g r11 = r11.f142f
            r28 = r0
            r0 = 2
            r15.mo184a(r9, r11, r4, r0)
            android.support.constraint.a.a.a r0 = r7.f217l
            int r0 = r0.mo56d()
            android.support.constraint.a.a.a r4 = r7.f217l
            android.support.constraint.a.a.a r4 = r4.f139c
            if (r4 == 0) goto L_0x0274
            android.support.constraint.a.a.b r4 = r7.f190Z
            if (r4 == 0) goto L_0x0274
            android.support.constraint.a.a.b r4 = r7.f190Z
            android.support.constraint.a.a.a r4 = r4.f215j
            android.support.constraint.a.a.a r4 = r4.f139c
            if (r4 == 0) goto L_0x0272
            android.support.constraint.a.a.b r4 = r7.f190Z
            android.support.constraint.a.a.a r4 = r4.f215j
            int r4 = r4.mo56d()
            goto L_0x0273
        L_0x0272:
            r4 = 0
        L_0x0273:
            int r0 = r0 + r4
        L_0x0274:
            android.support.constraint.a.a.a r4 = r7.f217l
            android.support.constraint.a.a.a r4 = r4.f139c
            android.support.constraint.a.g r4 = r4.f142f
            int r0 = -r0
            r11 = 2
            r15.mo187b(r10, r4, r0, r11)
            if (r1 != r3) goto L_0x0301
            android.support.constraint.a.a.a r0 = r8.f215j
            int r0 = r0.mo56d()
            android.support.constraint.a.a.a r3 = r8.f215j
            android.support.constraint.a.a.a r3 = r3.f139c
            if (r3 == 0) goto L_0x02b4
            android.support.constraint.a.a.a r3 = r8.f215j
            android.support.constraint.a.a.a r3 = r3.f139c
            android.support.constraint.a.a.b r3 = r3.f137a
            android.support.constraint.a.a.a r3 = r3.f217l
            android.support.constraint.a.a.a r3 = r3.f139c
            if (r3 == 0) goto L_0x02b4
            android.support.constraint.a.a.a r3 = r8.f215j
            android.support.constraint.a.a.a r3 = r3.f139c
            android.support.constraint.a.a.b r3 = r3.f137a
            android.support.constraint.a.a.a r3 = r3.f217l
            android.support.constraint.a.a.a r3 = r3.f139c
            android.support.constraint.a.a.b r3 = r3.f137a
            if (r3 != r8) goto L_0x02b4
            android.support.constraint.a.a.a r3 = r8.f215j
            android.support.constraint.a.a.a r3 = r3.f139c
            android.support.constraint.a.a.b r3 = r3.f137a
            android.support.constraint.a.a.a r3 = r3.f217l
            int r3 = r3.mo56d()
            int r0 = r0 + r3
        L_0x02b4:
            android.support.constraint.a.a.a r3 = r8.f215j
            android.support.constraint.a.a.a r3 = r3.f139c
            android.support.constraint.a.g r3 = r3.f142f
            r4 = 2
            r15.mo184a(r14, r3, r0, r4)
            android.support.constraint.a.a.a r0 = r8.f217l
            android.support.constraint.a.a.b[] r3 = r6.f255as
            r4 = 3
            r3 = r3[r4]
            if (r8 != r3) goto L_0x02ce
            android.support.constraint.a.a.b[] r0 = r6.f255as
            r3 = 1
            r0 = r0[r3]
            android.support.constraint.a.a.a r0 = r0.f217l
        L_0x02ce:
            int r3 = r0.mo56d()
            android.support.constraint.a.a.a r4 = r0.f139c
            if (r4 == 0) goto L_0x02f7
            android.support.constraint.a.a.a r4 = r0.f139c
            android.support.constraint.a.a.b r4 = r4.f137a
            android.support.constraint.a.a.a r4 = r4.f215j
            android.support.constraint.a.a.a r4 = r4.f139c
            if (r4 == 0) goto L_0x02f7
            android.support.constraint.a.a.a r4 = r0.f139c
            android.support.constraint.a.a.b r4 = r4.f137a
            android.support.constraint.a.a.a r4 = r4.f215j
            android.support.constraint.a.a.a r4 = r4.f139c
            android.support.constraint.a.a.b r4 = r4.f137a
            if (r4 != r8) goto L_0x02f7
            android.support.constraint.a.a.a r4 = r0.f139c
            android.support.constraint.a.a.b r4 = r4.f137a
            android.support.constraint.a.a.a r4 = r4.f215j
            int r4 = r4.mo56d()
            int r3 = r3 + r4
        L_0x02f7:
            android.support.constraint.a.a.a r0 = r0.f139c
            android.support.constraint.a.g r0 = r0.f142f
            int r3 = -r3
            r4 = 2
            r15.mo187b(r2, r0, r3, r4)
            goto L_0x0302
        L_0x0301:
            r4 = 2
        L_0x0302:
            int r0 = r12.f213h
            if (r0 <= 0) goto L_0x030b
            int r0 = r12.f213h
            r15.mo187b(r10, r9, r0, r4)
        L_0x030b:
            android.support.constraint.a.b r0 = r35.mo186b()
            float r3 = r7.f188X
            float r11 = r8.f188X
            android.support.constraint.a.a.a r4 = r7.f215j
            int r21 = r4.mo56d()
            android.support.constraint.a.a.a r4 = r7.f217l
            int r23 = r4.mo56d()
            android.support.constraint.a.a.a r4 = r8.f215j
            int r25 = r4.mo56d()
            android.support.constraint.a.a.a r4 = r8.f217l
            int r27 = r4.mo56d()
            r16 = r0
            r17 = r3
            r18 = r5
            r19 = r11
            r20 = r9
            r22 = r10
            r24 = r14
            r26 = r2
            r16.mo153a(r17, r18, r19, r20, r21, r22, r23, r24, r25, r26, r27)
            r15.mo180a(r0)
            r0 = r28
            r2 = 2
            r4 = 1
            r11 = 3
            r14 = 0
            goto L_0x01e5
        L_0x0349:
            r0 = r1
            r2 = r16
            r4 = r2
            r7 = 0
        L_0x034e:
            if (r0 == 0) goto L_0x04e8
            android.support.constraint.a.a.b r8 = r0.f190Z
            if (r8 != 0) goto L_0x035c
            android.support.constraint.a.a.b[] r2 = r6.f255as
            r7 = 1
            r2 = r2[r7]
            r14 = r2
            r2 = 1
            goto L_0x035e
        L_0x035c:
            r14 = r2
            r2 = r7
        L_0x035e:
            if (r5 == 0) goto L_0x03d9
            android.support.constraint.a.a.a r7 = r0.f215j
            int r9 = r7.mo56d()
            if (r4 == 0) goto L_0x036f
            android.support.constraint.a.a.a r4 = r4.f217l
            int r4 = r4.mo56d()
            int r9 = r9 + r4
        L_0x036f:
            if (r1 == r0) goto L_0x0373
            r4 = 3
            goto L_0x0374
        L_0x0373:
            r4 = 1
        L_0x0374:
            android.support.constraint.a.a.a r10 = r7.f139c
            if (r10 == 0) goto L_0x037f
            android.support.constraint.a.g r10 = r7.f142f
            android.support.constraint.a.a.a r11 = r7.f139c
            android.support.constraint.a.g r11 = r11.f142f
            goto L_0x0399
        L_0x037f:
            android.support.constraint.a.a.a r10 = r0.f218m
            android.support.constraint.a.a.a r10 = r10.f139c
            if (r10 == 0) goto L_0x0396
            android.support.constraint.a.a.a r10 = r0.f218m
            android.support.constraint.a.g r10 = r10.f142f
            android.support.constraint.a.a.a r11 = r0.f218m
            android.support.constraint.a.a.a r11 = r11.f139c
            android.support.constraint.a.g r11 = r11.f142f
            int r17 = r7.mo56d()
            int r9 = r9 - r17
            goto L_0x0399
        L_0x0396:
            r10 = r16
            r11 = r10
        L_0x0399:
            if (r10 == 0) goto L_0x03a0
            if (r11 == 0) goto L_0x03a0
            r15.mo184a(r10, r11, r9, r4)
        L_0x03a0:
            android.support.constraint.a.a.b$a r4 = r0.f172H
            android.support.constraint.a.a.b$a r9 = android.support.constraint.p000a.p001a.C0010b.C0012a.MATCH_CONSTRAINT
            if (r4 != r9) goto L_0x03d7
            android.support.constraint.a.a.a r4 = r0.f217l
            int r9 = r0.f209d
            r10 = 1
            if (r9 != r10) goto L_0x03c1
            int r9 = r0.f212g
            int r10 = r0.mo110l()
            int r9 = java.lang.Math.max(r9, r10)
            android.support.constraint.a.g r4 = r4.f142f
            android.support.constraint.a.g r7 = r7.f142f
            r11 = 3
            r15.mo188c(r4, r7, r9, r11)
            goto L_0x042e
        L_0x03c1:
            r11 = 3
            android.support.constraint.a.g r9 = r7.f142f
            android.support.constraint.a.a.a r10 = r7.f139c
            android.support.constraint.a.g r10 = r10.f142f
            int r6 = r7.f140d
            r15.mo184a(r9, r10, r6, r11)
            android.support.constraint.a.g r4 = r4.f142f
            android.support.constraint.a.g r6 = r7.f142f
            int r7 = r0.f212g
            r15.mo187b(r4, r6, r7, r11)
            goto L_0x042e
        L_0x03d7:
            r11 = 3
            goto L_0x042e
        L_0x03d9:
            r11 = 3
            r6 = 5
            if (r3 != 0) goto L_0x0408
            if (r2 == 0) goto L_0x0408
            if (r4 == 0) goto L_0x0408
            android.support.constraint.a.a.a r4 = r0.f217l
            android.support.constraint.a.a.a r4 = r4.f139c
            if (r4 != 0) goto L_0x03f3
            android.support.constraint.a.a.a r4 = r0.f217l
            android.support.constraint.a.g r4 = r4.f142f
            int r6 = r0.mo115p()
        L_0x03ef:
            r15.mo182a(r4, r6)
            goto L_0x042e
        L_0x03f3:
            android.support.constraint.a.a.a r4 = r0.f217l
            int r4 = r4.mo56d()
            android.support.constraint.a.a.a r7 = r0.f217l
            android.support.constraint.a.g r7 = r7.f142f
            android.support.constraint.a.a.a r9 = r14.f217l
            android.support.constraint.a.a.a r9 = r9.f139c
            android.support.constraint.a.g r9 = r9.f142f
            int r4 = -r4
        L_0x0404:
            r15.mo188c(r7, r9, r4, r6)
            goto L_0x042e
        L_0x0408:
            if (r3 != 0) goto L_0x043b
            if (r2 != 0) goto L_0x043b
            if (r4 != 0) goto L_0x043b
            android.support.constraint.a.a.a r4 = r0.f215j
            android.support.constraint.a.a.a r4 = r4.f139c
            if (r4 != 0) goto L_0x041d
            android.support.constraint.a.a.a r4 = r0.f215j
            android.support.constraint.a.g r4 = r4.f142f
            int r6 = r0.mo114o()
            goto L_0x03ef
        L_0x041d:
            android.support.constraint.a.a.a r4 = r0.f215j
            int r4 = r4.mo56d()
            android.support.constraint.a.a.a r7 = r0.f215j
            android.support.constraint.a.g r7 = r7.f142f
            android.support.constraint.a.a.a r9 = r12.f215j
            android.support.constraint.a.a.a r9 = r9.f139c
            android.support.constraint.a.g r9 = r9.f142f
            goto L_0x0404
        L_0x042e:
            r29 = r0
            r30 = r3
            r0 = r12
            r4 = r13
            r18 = r14
            r3 = r15
            r19 = 0
            goto L_0x04d5
        L_0x043b:
            android.support.constraint.a.a.a r6 = r0.f215j
            android.support.constraint.a.a.a r7 = r0.f217l
            int r10 = r6.mo56d()
            int r9 = r7.mo56d()
            android.support.constraint.a.g r11 = r6.f142f
            r29 = r0
            android.support.constraint.a.a.a r0 = r6.f139c
            android.support.constraint.a.g r0 = r0.f142f
            r30 = r3
            r3 = 1
            r15.mo184a(r11, r0, r10, r3)
            android.support.constraint.a.g r0 = r7.f142f
            android.support.constraint.a.a.a r11 = r7.f139c
            android.support.constraint.a.g r11 = r11.f142f
            r31 = r13
            int r13 = -r9
            r15.mo187b(r0, r11, r13, r3)
            android.support.constraint.a.a.a r0 = r6.f139c
            if (r0 == 0) goto L_0x046a
            android.support.constraint.a.a.a r0 = r6.f139c
            android.support.constraint.a.g r0 = r0.f142f
            goto L_0x046c
        L_0x046a:
            r0 = r16
        L_0x046c:
            if (r4 != 0) goto L_0x047d
            android.support.constraint.a.a.a r0 = r12.f215j
            android.support.constraint.a.a.a r0 = r0.f139c
            if (r0 == 0) goto L_0x047b
            android.support.constraint.a.a.a r0 = r12.f215j
            android.support.constraint.a.a.a r0 = r0.f139c
            android.support.constraint.a.g r0 = r0.f142f
            goto L_0x047d
        L_0x047b:
            r0 = r16
        L_0x047d:
            if (r8 != 0) goto L_0x048f
            android.support.constraint.a.a.a r3 = r14.f217l
            android.support.constraint.a.a.a r3 = r3.f139c
            if (r3 == 0) goto L_0x048d
            android.support.constraint.a.a.a r3 = r14.f217l
            android.support.constraint.a.a.a r3 = r3.f139c
            android.support.constraint.a.a.b r3 = r3.f137a
            r8 = r3
            goto L_0x048f
        L_0x048d:
            r8 = r16
        L_0x048f:
            r3 = r8
            if (r3 == 0) goto L_0x04c9
            android.support.constraint.a.a.a r4 = r3.f215j
            android.support.constraint.a.g r4 = r4.f142f
            if (r2 == 0) goto L_0x04a7
            android.support.constraint.a.a.a r4 = r14.f217l
            android.support.constraint.a.a.a r4 = r4.f139c
            if (r4 == 0) goto L_0x04a5
            android.support.constraint.a.a.a r4 = r14.f217l
            android.support.constraint.a.a.a r4 = r4.f139c
            android.support.constraint.a.g r4 = r4.f142f
            goto L_0x04a7
        L_0x04a5:
            r4 = r16
        L_0x04a7:
            if (r0 == 0) goto L_0x04c9
            if (r4 == 0) goto L_0x04c9
            android.support.constraint.a.g r8 = r6.f142f
            r11 = 1056964608(0x3f000000, float:0.5)
            android.support.constraint.a.g r13 = r7.f142f
            r6 = 4
            r7 = r15
            r17 = r9
            r9 = r0
            r0 = 3
            r0 = r12
            r12 = r4
            r4 = r31
            r18 = r14
            r19 = 0
            r14 = r17
            r32 = r3
            r3 = r15
            r15 = r6
            r7.mo183a(r8, r9, r10, r11, r12, r13, r14, r15)
            goto L_0x04d3
        L_0x04c9:
            r32 = r3
            r0 = r12
            r18 = r14
            r3 = r15
            r4 = r31
            r19 = 0
        L_0x04d3:
            r8 = r32
        L_0x04d5:
            if (r2 == 0) goto L_0x04d9
            r8 = r16
        L_0x04d9:
            r12 = r0
            r7 = r2
            r15 = r3
            r13 = r4
            r0 = r8
            r2 = r18
            r4 = r29
            r3 = r30
            r6 = r34
            goto L_0x034e
        L_0x04e8:
            r0 = r12
            r4 = r13
            r3 = r15
            r19 = 0
            if (r5 == 0) goto L_0x0531
            android.support.constraint.a.a.a r1 = r1.f215j
            android.support.constraint.a.a.a r5 = r2.f217l
            int r10 = r1.mo56d()
            int r14 = r5.mo56d()
            android.support.constraint.a.a.a r6 = r0.f215j
            android.support.constraint.a.a.a r6 = r6.f139c
            if (r6 == 0) goto L_0x0509
            android.support.constraint.a.a.a r6 = r0.f215j
            android.support.constraint.a.a.a r6 = r6.f139c
            android.support.constraint.a.g r6 = r6.f142f
            r9 = r6
            goto L_0x050b
        L_0x0509:
            r9 = r16
        L_0x050b:
            android.support.constraint.a.a.a r6 = r2.f217l
            android.support.constraint.a.a.a r6 = r6.f139c
            if (r6 == 0) goto L_0x0519
            android.support.constraint.a.a.a r2 = r2.f217l
            android.support.constraint.a.a.a r2 = r2.f139c
            android.support.constraint.a.g r2 = r2.f142f
            r12 = r2
            goto L_0x051b
        L_0x0519:
            r12 = r16
        L_0x051b:
            if (r9 == 0) goto L_0x0531
            if (r12 == 0) goto L_0x0531
            android.support.constraint.a.g r2 = r5.f142f
            int r6 = -r14
            r7 = 1
            r3.mo187b(r2, r12, r6, r7)
            android.support.constraint.a.g r8 = r1.f142f
            float r11 = r0.f170F
            android.support.constraint.a.g r13 = r5.f142f
            r15 = 4
            r7 = r3
            r7.mo183a(r8, r9, r10, r11, r12, r13, r14, r15)
        L_0x0531:
            int r13 = r4 + 1
            r15 = r3
            r6 = r34
            r14 = 0
            goto L_0x0006
        L_0x0539:
            return
        */
        throw new UnsupportedOperationException("Method not decompiled: android.support.constraint.p000a.p001a.C0013c.m116c(android.support.constraint.a.e):void");
    }

    /* renamed from: d */
    private void m117d(C0010b bVar) {
        int i = 0;
        while (i < this.f248al) {
            if (this.f252ap[i] != bVar) {
                i++;
            } else {
                return;
            }
        }
        if (this.f248al + 1 >= this.f252ap.length) {
            this.f252ap = (C0010b[]) Arrays.copyOf(this.f252ap, this.f252ap.length * 2);
        }
        this.f252ap[this.f248al] = bVar;
        this.f248al++;
    }

    /* renamed from: e */
    private void m118e(C0010b bVar) {
        int i = 0;
        while (i < this.f249am) {
            if (this.f251ao[i] != bVar) {
                i++;
            } else {
                return;
            }
        }
        if (this.f249am + 1 >= this.f251ao.length) {
            this.f251ao = (C0010b[]) Arrays.copyOf(this.f251ao, this.f251ao.length * 2);
        }
        this.f251ao[this.f249am] = bVar;
        this.f249am++;
    }

    /* renamed from: D */
    public boolean mo127D() {
        return this.f256at;
    }

    /* renamed from: E */
    public boolean mo128E() {
        return this.f257au;
    }

    /* JADX WARNING: Removed duplicated region for block: B:58:0x0105  */
    /* JADX WARNING: Removed duplicated region for block: B:60:0x010e  */
    /* JADX WARNING: Removed duplicated region for block: B:94:0x01cb  */
    /* JADX WARNING: Removed duplicated region for block: B:97:0x01e4  */
    /* JADX WARNING: Removed duplicated region for block: B:99:0x01ef  */
    /* renamed from: F */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public void mo129F() {
        /*
            r18 = this;
            r1 = r18
            int r2 = r1.f228w
            int r3 = r1.f229x
            int r4 = r18.mo102h()
            r5 = 0
            int r4 = java.lang.Math.max(r5, r4)
            int r6 = r18.mo110l()
            int r6 = java.lang.Math.max(r5, r6)
            r1.f256at = r5
            r1.f257au = r5
            android.support.constraint.a.a.b r7 = r1.f223r
            if (r7 == 0) goto L_0x0046
            android.support.constraint.a.a.g r7 = r1.f247ak
            if (r7 != 0) goto L_0x002a
            android.support.constraint.a.a.g r7 = new android.support.constraint.a.a.g
            r7.<init>(r1)
            r1.f247ak = r7
        L_0x002a:
            android.support.constraint.a.a.g r7 = r1.f247ak
            r7.mo145a(r1)
            int r7 = r1.f243af
            r1.mo82b(r7)
            int r7 = r1.f244ag
            r1.mo90c(r7)
            r18.mo64A()
            android.support.constraint.a.e r7 = r1.f239aa
            android.support.constraint.a.c r7 = r7.mo192f()
            r1.mo77a(r7)
            goto L_0x004a
        L_0x0046:
            r1.f228w = r5
            r1.f229x = r5
        L_0x004a:
            android.support.constraint.a.a.b$a r7 = r1.f172H
            android.support.constraint.a.a.b$a r8 = r1.f171G
            int r9 = r1.f253aq
            r10 = 2
            r11 = 1
            if (r9 != r10) goto L_0x00bd
            android.support.constraint.a.a.b$a r9 = r1.f172H
            android.support.constraint.a.a.b$a r12 = android.support.constraint.p000a.p001a.C0010b.C0012a.WRAP_CONTENT
            if (r9 == r12) goto L_0x0060
            android.support.constraint.a.a.b$a r9 = r1.f171G
            android.support.constraint.a.a.b$a r12 = android.support.constraint.p000a.p001a.C0010b.C0012a.WRAP_CONTENT
            if (r9 != r12) goto L_0x00bd
        L_0x0060:
            java.util.ArrayList r9 = r1.f278aj
            boolean[] r12 = r1.f254ar
            r1.mo134a(r9, r12)
            boolean[] r9 = r1.f254ar
            boolean r9 = r9[r5]
            if (r4 <= 0) goto L_0x0078
            if (r6 <= 0) goto L_0x0078
            int r12 = r1.f241ad
            if (r12 > r4) goto L_0x0077
            int r12 = r1.f242ae
            if (r12 <= r6) goto L_0x0078
        L_0x0077:
            r9 = 0
        L_0x0078:
            if (r9 == 0) goto L_0x00be
            android.support.constraint.a.a.b$a r12 = r1.f171G
            android.support.constraint.a.a.b$a r13 = android.support.constraint.p000a.p001a.C0010b.C0012a.WRAP_CONTENT
            if (r12 != r13) goto L_0x009b
            android.support.constraint.a.a.b$a r12 = android.support.constraint.p000a.p001a.C0010b.C0012a.FIXED
            r1.f171G = r12
            if (r4 <= 0) goto L_0x0090
            int r12 = r1.f241ad
            if (r4 >= r12) goto L_0x0090
            r1.f256at = r11
            r1.mo94d(r4)
            goto L_0x009b
        L_0x0090:
            int r12 = r1.f167B
            int r13 = r1.f241ad
            int r12 = java.lang.Math.max(r12, r13)
            r1.mo94d(r12)
        L_0x009b:
            android.support.constraint.a.a.b$a r12 = r1.f172H
            android.support.constraint.a.a.b$a r13 = android.support.constraint.p000a.p001a.C0010b.C0012a.WRAP_CONTENT
            if (r12 != r13) goto L_0x00be
            android.support.constraint.a.a.b$a r12 = android.support.constraint.p000a.p001a.C0010b.C0012a.FIXED
            r1.f172H = r12
            if (r6 <= 0) goto L_0x00b1
            int r12 = r1.f242ae
            if (r6 >= r12) goto L_0x00b1
            r1.f257au = r11
            r1.mo97e(r6)
            goto L_0x00be
        L_0x00b1:
            int r12 = r1.f168C
            int r13 = r1.f242ae
            int r12 = java.lang.Math.max(r12, r13)
            r1.mo97e(r12)
            goto L_0x00be
        L_0x00bd:
            r9 = 0
        L_0x00be:
            r18.m112J()
            java.util.ArrayList r12 = r1.f278aj
            int r12 = r12.size()
            r13 = 0
        L_0x00c8:
            if (r13 >= r12) goto L_0x00de
            java.util.ArrayList r14 = r1.f278aj
            java.lang.Object r14 = r14.get(r13)
            android.support.constraint.a.a.b r14 = (android.support.constraint.p000a.p001a.C0010b) r14
            boolean r15 = r14 instanceof android.support.constraint.p000a.p001a.C0020h
            if (r15 == 0) goto L_0x00db
            android.support.constraint.a.a.h r14 = (android.support.constraint.p000a.p001a.C0020h) r14
            r14.mo129F()
        L_0x00db:
            int r13 = r13 + 1
            goto L_0x00c8
        L_0x00de:
            r14 = r9
            r9 = 1
            r13 = 0
        L_0x00e1:
            if (r9 == 0) goto L_0x022c
            int r13 = r13 + r11
            r15 = 2147483647(0x7fffffff, float:NaN)
            android.support.constraint.a.e r5 = r1.f239aa     // Catch:{ Exception -> 0x00fd }
            r5.mo179a()     // Catch:{ Exception -> 0x00fd }
            android.support.constraint.a.e r5 = r1.f239aa     // Catch:{ Exception -> 0x00fd }
            boolean r5 = r1.mo136c(r5, r15)     // Catch:{ Exception -> 0x00fd }
            if (r5 == 0) goto L_0x0103
            android.support.constraint.a.e r9 = r1.f239aa     // Catch:{ Exception -> 0x00fa }
            r9.mo191e()     // Catch:{ Exception -> 0x00fa }
            goto L_0x0103
        L_0x00fa:
            r0 = move-exception
            r9 = r5
            goto L_0x00fe
        L_0x00fd:
            r0 = move-exception
        L_0x00fe:
            r5 = r0
            r5.printStackTrace()
            r5 = r9
        L_0x0103:
            if (r5 == 0) goto L_0x010e
            android.support.constraint.a.e r5 = r1.f239aa
            boolean[] r9 = r1.f254ar
            r1.mo133a(r5, r15, r9)
        L_0x010c:
            r9 = 2
            goto L_0x0150
        L_0x010e:
            android.support.constraint.a.e r5 = r1.f239aa
            r1.mo86b(r5, r15)
            r5 = 0
        L_0x0114:
            if (r5 >= r12) goto L_0x010c
            java.util.ArrayList r9 = r1.f278aj
            java.lang.Object r9 = r9.get(r5)
            android.support.constraint.a.a.b r9 = (android.support.constraint.p000a.p001a.C0010b) r9
            android.support.constraint.a.a.b$a r15 = r9.f171G
            android.support.constraint.a.a.b$a r10 = android.support.constraint.p000a.p001a.C0010b.C0012a.MATCH_CONSTRAINT
            if (r15 != r10) goto L_0x0134
            int r10 = r9.mo102h()
            int r15 = r9.mo108k()
            if (r10 >= r15) goto L_0x0134
            boolean[] r5 = r1.f254ar
            r10 = 2
            r5[r10] = r11
            goto L_0x010c
        L_0x0134:
            r10 = 2
            android.support.constraint.a.a.b$a r15 = r9.f172H
            android.support.constraint.a.a.b$a r10 = android.support.constraint.p000a.p001a.C0010b.C0012a.MATCH_CONSTRAINT
            if (r15 != r10) goto L_0x014b
            int r10 = r9.mo110l()
            int r9 = r9.mo112m()
            if (r10 >= r9) goto L_0x014b
            boolean[] r5 = r1.f254ar
            r9 = 2
            r5[r9] = r11
            goto L_0x0150
        L_0x014b:
            r9 = 2
            int r5 = r5 + 1
            r10 = 2
            goto L_0x0114
        L_0x0150:
            r5 = 8
            if (r13 >= r5) goto L_0x01b9
            boolean[] r5 = r1.f254ar
            boolean r5 = r5[r9]
            if (r5 == 0) goto L_0x01b9
            r5 = 0
            r10 = 0
            r15 = 0
        L_0x015d:
            if (r5 >= r12) goto L_0x0183
            java.util.ArrayList r9 = r1.f278aj
            java.lang.Object r9 = r9.get(r5)
            android.support.constraint.a.a.b r9 = (android.support.constraint.p000a.p001a.C0010b) r9
            int r11 = r9.f228w
            int r16 = r9.mo102h()
            int r11 = r11 + r16
            int r10 = java.lang.Math.max(r10, r11)
            int r11 = r9.f229x
            int r9 = r9.mo110l()
            int r11 = r11 + r9
            int r15 = java.lang.Math.max(r15, r11)
            int r5 = r5 + 1
            r9 = 2
            r11 = 1
            goto L_0x015d
        L_0x0183:
            int r5 = r1.f167B
            int r5 = java.lang.Math.max(r5, r10)
            int r9 = r1.f168C
            int r9 = java.lang.Math.max(r9, r15)
            android.support.constraint.a.a.b$a r10 = android.support.constraint.p000a.p001a.C0010b.C0012a.WRAP_CONTENT
            if (r8 != r10) goto L_0x01a3
            int r10 = r18.mo102h()
            if (r10 >= r5) goto L_0x01a3
            r1.mo94d(r5)
            android.support.constraint.a.a.b$a r5 = android.support.constraint.p000a.p001a.C0010b.C0012a.WRAP_CONTENT
            r1.f171G = r5
            r5 = 1
            r11 = 1
            goto L_0x01a5
        L_0x01a3:
            r11 = r14
            r5 = 0
        L_0x01a5:
            android.support.constraint.a.a.b$a r10 = android.support.constraint.p000a.p001a.C0010b.C0012a.WRAP_CONTENT
            if (r7 != r10) goto L_0x01bb
            int r10 = r18.mo110l()
            if (r10 >= r9) goto L_0x01bb
            r1.mo97e(r9)
            android.support.constraint.a.a.b$a r5 = android.support.constraint.p000a.p001a.C0010b.C0012a.WRAP_CONTENT
            r1.f172H = r5
            r5 = 1
            r11 = 1
            goto L_0x01bb
        L_0x01b9:
            r11 = r14
            r5 = 0
        L_0x01bb:
            int r9 = r1.f167B
            int r10 = r18.mo102h()
            int r9 = java.lang.Math.max(r9, r10)
            int r10 = r18.mo102h()
            if (r9 <= r10) goto L_0x01d4
            r1.mo94d(r9)
            android.support.constraint.a.a.b$a r5 = android.support.constraint.p000a.p001a.C0010b.C0012a.FIXED
            r1.f171G = r5
            r5 = 1
            r11 = 1
        L_0x01d4:
            int r9 = r1.f168C
            int r10 = r18.mo110l()
            int r9 = java.lang.Math.max(r9, r10)
            int r10 = r18.mo110l()
            if (r9 <= r10) goto L_0x01ed
            r1.mo97e(r9)
            android.support.constraint.a.a.b$a r5 = android.support.constraint.p000a.p001a.C0010b.C0012a.FIXED
            r1.f172H = r5
            r5 = 1
            r11 = 1
        L_0x01ed:
            if (r11 != 0) goto L_0x0224
            android.support.constraint.a.a.b$a r9 = r1.f171G
            android.support.constraint.a.a.b$a r10 = android.support.constraint.p000a.p001a.C0010b.C0012a.WRAP_CONTENT
            if (r9 != r10) goto L_0x0209
            if (r4 <= 0) goto L_0x0209
            int r9 = r18.mo102h()
            if (r9 <= r4) goto L_0x0209
            r9 = 1
            r1.f256at = r9
            android.support.constraint.a.a.b$a r5 = android.support.constraint.p000a.p001a.C0010b.C0012a.FIXED
            r1.f171G = r5
            r1.mo94d(r4)
            r5 = 1
            r11 = 1
        L_0x0209:
            android.support.constraint.a.a.b$a r9 = r1.f172H
            android.support.constraint.a.a.b$a r10 = android.support.constraint.p000a.p001a.C0010b.C0012a.WRAP_CONTENT
            if (r9 != r10) goto L_0x0224
            if (r6 <= 0) goto L_0x0224
            int r9 = r18.mo110l()
            if (r9 <= r6) goto L_0x0224
            r9 = 1
            r1.f257au = r9
            android.support.constraint.a.a.b$a r5 = android.support.constraint.p000a.p001a.C0010b.C0012a.FIXED
            r1.f172H = r5
            r1.mo97e(r6)
            r5 = 1
            r14 = 1
            goto L_0x0226
        L_0x0224:
            r9 = 1
            r14 = r11
        L_0x0226:
            r9 = r5
            r5 = 0
            r10 = 2
            r11 = 1
            goto L_0x00e1
        L_0x022c:
            android.support.constraint.a.a.b r4 = r1.f223r
            if (r4 == 0) goto L_0x025c
            int r2 = r1.f167B
            int r3 = r18.mo102h()
            int r2 = java.lang.Math.max(r2, r3)
            int r3 = r1.f168C
            int r4 = r18.mo110l()
            int r3 = java.lang.Math.max(r3, r4)
            android.support.constraint.a.a.g r4 = r1.f247ak
            r4.mo146b(r1)
            int r4 = r1.f243af
            int r2 = r2 + r4
            int r4 = r1.f245ah
            int r2 = r2 + r4
            r1.mo94d(r2)
            int r2 = r1.f244ag
            int r3 = r3 + r2
            int r2 = r1.f246ai
            int r3 = r3 + r2
            r1.mo97e(r3)
            goto L_0x0260
        L_0x025c:
            r1.f228w = r2
            r1.f229x = r3
        L_0x0260:
            if (r14 == 0) goto L_0x0266
            r1.f171G = r8
            r1.f172H = r7
        L_0x0266:
            android.support.constraint.a.e r2 = r1.f239aa
            android.support.constraint.a.c r2 = r2.mo192f()
            r1.mo77a(r2)
            android.support.constraint.a.a.c r2 = r18.mo149H()
            if (r1 != r2) goto L_0x0278
            r18.mo126z()
        L_0x0278:
            return
        */
        throw new UnsupportedOperationException("Method not decompiled: android.support.constraint.p000a.p001a.C0013c.mo129F():void");
    }

    /* renamed from: G */
    public boolean mo130G() {
        return false;
    }

    /* renamed from: a */
    public void mo68a() {
        this.f239aa.mo179a();
        this.f243af = 0;
        this.f245ah = 0;
        this.f244ag = 0;
        this.f246ai = 0;
        super.mo68a();
    }

    /* access modifiers changed from: 0000 */
    /* renamed from: a */
    public void mo131a(C0010b bVar, int i) {
        if (i == 0) {
            while (bVar.f214i.f139c != null && bVar.f214i.f139c.f137a.f216k.f139c != null && bVar.f214i.f139c.f137a.f216k.f139c == bVar.f214i && bVar.f214i.f139c.f137a != bVar) {
                bVar = bVar.f214i.f139c.f137a;
            }
            m117d(bVar);
            return;
        }
        if (i == 1) {
            while (bVar.f215j.f139c != null && bVar.f215j.f139c.f137a.f217l.f139c != null && bVar.f215j.f139c.f137a.f217l.f139c == bVar.f215j && bVar.f215j.f139c.f137a != bVar) {
                bVar = bVar.f215j.f139c.f137a;
            }
            m118e(bVar);
        }
    }

    /* JADX WARNING: Removed duplicated region for block: B:119:0x01b9  */
    /* renamed from: a */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public void mo132a(android.support.constraint.p000a.p001a.C0010b r8, boolean[] r9) {
        /*
            r7 = this;
            android.support.constraint.a.a.b$a r0 = r8.f171G
            android.support.constraint.a.a.b$a r1 = android.support.constraint.p000a.p001a.C0010b.C0012a.MATCH_CONSTRAINT
            r2 = 0
            r3 = 0
            if (r0 != r1) goto L_0x0017
            android.support.constraint.a.a.b$a r0 = r8.f172H
            android.support.constraint.a.a.b$a r1 = android.support.constraint.p000a.p001a.C0010b.C0012a.MATCH_CONSTRAINT
            if (r0 != r1) goto L_0x0017
            float r0 = r8.f226u
            int r0 = (r0 > r2 ? 1 : (r0 == r2 ? 0 : -1))
            if (r0 <= 0) goto L_0x0017
            r9[r3] = r3
            return
        L_0x0017:
            int r0 = r8.mo104i()
            android.support.constraint.a.a.b$a r1 = r8.f171G
            android.support.constraint.a.a.b$a r4 = android.support.constraint.p000a.p001a.C0010b.C0012a.MATCH_CONSTRAINT
            if (r1 != r4) goto L_0x0030
            android.support.constraint.a.a.b$a r1 = r8.f172H
            android.support.constraint.a.a.b$a r4 = android.support.constraint.p000a.p001a.C0010b.C0012a.MATCH_CONSTRAINT
            if (r1 == r4) goto L_0x0030
            float r1 = r8.f226u
            int r1 = (r1 > r2 ? 1 : (r1 == r2 ? 0 : -1))
            if (r1 <= 0) goto L_0x0030
            r9[r3] = r3
            return
        L_0x0030:
            r1 = 1
            r8.f181Q = r1
            boolean r2 = r8 instanceof android.support.constraint.p000a.p001a.C0014d
            if (r2 == 0) goto L_0x005e
            r9 = r8
            android.support.constraint.a.a.d r9 = (android.support.constraint.p000a.p001a.C0014d) r9
            int r2 = r9.mo127D()
            if (r2 != r1) goto L_0x005a
            int r0 = r9.mo139F()
            r1 = -1
            if (r0 == r1) goto L_0x004e
            int r9 = r9.mo139F()
            r3 = r9
        L_0x004c:
            r0 = 0
            goto L_0x005b
        L_0x004e:
            int r0 = r9.mo140G()
            if (r0 == r1) goto L_0x004c
            int r9 = r9.mo140G()
            r0 = r9
            goto L_0x005b
        L_0x005a:
            r3 = r0
        L_0x005b:
            r5 = r0
            goto L_0x01b1
        L_0x005e:
            android.support.constraint.a.a.a r2 = r8.f216k
            boolean r2 = r2.mo62j()
            if (r2 != 0) goto L_0x0075
            android.support.constraint.a.a.a r2 = r8.f214i
            boolean r2 = r2.mo62j()
            if (r2 != 0) goto L_0x0075
            int r9 = r8.mo98f()
            int r3 = r0 + r9
            goto L_0x005b
        L_0x0075:
            android.support.constraint.a.a.a r2 = r8.f216k
            android.support.constraint.a.a.a r2 = r2.f139c
            if (r2 == 0) goto L_0x00a6
            android.support.constraint.a.a.a r2 = r8.f214i
            android.support.constraint.a.a.a r2 = r2.f139c
            if (r2 == 0) goto L_0x00a6
            android.support.constraint.a.a.a r2 = r8.f216k
            android.support.constraint.a.a.a r2 = r2.f139c
            android.support.constraint.a.a.a r4 = r8.f214i
            android.support.constraint.a.a.a r4 = r4.f139c
            if (r2 == r4) goto L_0x00a3
            android.support.constraint.a.a.a r2 = r8.f216k
            android.support.constraint.a.a.a r2 = r2.f139c
            android.support.constraint.a.a.b r2 = r2.f137a
            android.support.constraint.a.a.a r4 = r8.f214i
            android.support.constraint.a.a.a r4 = r4.f139c
            android.support.constraint.a.a.b r4 = r4.f137a
            if (r2 != r4) goto L_0x00a6
            android.support.constraint.a.a.a r2 = r8.f216k
            android.support.constraint.a.a.a r2 = r2.f139c
            android.support.constraint.a.a.b r2 = r2.f137a
            android.support.constraint.a.a.b r4 = r8.f223r
            if (r2 == r4) goto L_0x00a6
        L_0x00a3:
            r9[r3] = r3
            return
        L_0x00a6:
            android.support.constraint.a.a.a r2 = r8.f216k
            android.support.constraint.a.a.a r2 = r2.f139c
            r4 = 0
            if (r2 == 0) goto L_0x00c8
            android.support.constraint.a.a.a r2 = r8.f216k
            android.support.constraint.a.a.a r2 = r2.f139c
            android.support.constraint.a.a.b r2 = r2.f137a
            android.support.constraint.a.a.a r5 = r8.f216k
            int r5 = r5.mo56d()
            int r5 = r5 + r0
            boolean r6 = r2.mo87b()
            if (r6 != 0) goto L_0x00ca
            boolean r6 = r2.f181Q
            if (r6 != 0) goto L_0x00ca
            r7.mo132a(r2, r9)
            goto L_0x00ca
        L_0x00c8:
            r5 = r0
            r2 = r4
        L_0x00ca:
            android.support.constraint.a.a.a r6 = r8.f214i
            android.support.constraint.a.a.a r6 = r6.f139c
            if (r6 == 0) goto L_0x00ea
            android.support.constraint.a.a.a r4 = r8.f214i
            android.support.constraint.a.a.a r4 = r4.f139c
            android.support.constraint.a.a.b r4 = r4.f137a
            android.support.constraint.a.a.a r6 = r8.f214i
            int r6 = r6.mo56d()
            int r0 = r0 + r6
            boolean r6 = r4.mo87b()
            if (r6 != 0) goto L_0x00ea
            boolean r6 = r4.f181Q
            if (r6 != 0) goto L_0x00ea
            r7.mo132a(r4, r9)
        L_0x00ea:
            android.support.constraint.a.a.a r9 = r8.f216k
            android.support.constraint.a.a.a r9 = r9.f139c
            if (r9 == 0) goto L_0x014c
            boolean r9 = r2.mo87b()
            if (r9 != 0) goto L_0x014c
            android.support.constraint.a.a.a r9 = r8.f216k
            android.support.constraint.a.a.a r9 = r9.f139c
            android.support.constraint.a.a.a$c r9 = r9.f138b
            android.support.constraint.a.a.a$c r6 = android.support.constraint.p000a.p001a.C0005a.C0009c.RIGHT
            if (r9 != r6) goto L_0x0109
            int r9 = r2.f175K
            int r6 = r2.mo104i()
            int r9 = r9 - r6
        L_0x0107:
            int r5 = r5 + r9
            goto L_0x0118
        L_0x0109:
            android.support.constraint.a.a.a r9 = r8.f216k
            android.support.constraint.a.a.a r9 = r9.f139c
            android.support.constraint.a.a.a$c r9 = r9.mo55c()
            android.support.constraint.a.a.a$c r6 = android.support.constraint.p000a.p001a.C0005a.C0009c.LEFT
            if (r9 != r6) goto L_0x0118
            int r9 = r2.f175K
            goto L_0x0107
        L_0x0118:
            boolean r9 = r2.f178N
            if (r9 != 0) goto L_0x0131
            android.support.constraint.a.a.a r9 = r2.f214i
            android.support.constraint.a.a.a r9 = r9.f139c
            if (r9 == 0) goto L_0x012f
            android.support.constraint.a.a.a r9 = r2.f216k
            android.support.constraint.a.a.a r9 = r9.f139c
            if (r9 == 0) goto L_0x012f
            android.support.constraint.a.a.b$a r9 = r2.f171G
            android.support.constraint.a.a.b$a r6 = android.support.constraint.p000a.p001a.C0010b.C0012a.MATCH_CONSTRAINT
            if (r9 == r6) goto L_0x012f
            goto L_0x0131
        L_0x012f:
            r9 = 0
            goto L_0x0132
        L_0x0131:
            r9 = 1
        L_0x0132:
            r8.f178N = r9
            boolean r9 = r8.f178N
            if (r9 == 0) goto L_0x014c
            android.support.constraint.a.a.a r9 = r2.f214i
            android.support.constraint.a.a.a r9 = r9.f139c
            if (r9 != 0) goto L_0x013f
            goto L_0x0147
        L_0x013f:
            android.support.constraint.a.a.a r9 = r2.f214i
            android.support.constraint.a.a.a r9 = r9.f139c
            android.support.constraint.a.a.b r9 = r9.f137a
            if (r9 == r8) goto L_0x014c
        L_0x0147:
            int r9 = r2.f175K
            int r9 = r5 - r9
            int r5 = r5 + r9
        L_0x014c:
            android.support.constraint.a.a.a r9 = r8.f214i
            android.support.constraint.a.a.a r9 = r9.f139c
            if (r9 == 0) goto L_0x01b0
            boolean r9 = r4.mo87b()
            if (r9 != 0) goto L_0x01b0
            android.support.constraint.a.a.a r9 = r8.f214i
            android.support.constraint.a.a.a r9 = r9.f139c
            android.support.constraint.a.a.a$c r9 = r9.mo55c()
            android.support.constraint.a.a.a$c r2 = android.support.constraint.p000a.p001a.C0005a.C0009c.LEFT
            if (r9 != r2) goto L_0x016d
            int r9 = r4.f174J
            int r2 = r4.mo104i()
            int r9 = r9 - r2
        L_0x016b:
            int r0 = r0 + r9
            goto L_0x017c
        L_0x016d:
            android.support.constraint.a.a.a r9 = r8.f214i
            android.support.constraint.a.a.a r9 = r9.f139c
            android.support.constraint.a.a.a$c r9 = r9.mo55c()
            android.support.constraint.a.a.a$c r2 = android.support.constraint.p000a.p001a.C0005a.C0009c.RIGHT
            if (r9 != r2) goto L_0x017c
            int r9 = r4.f174J
            goto L_0x016b
        L_0x017c:
            boolean r9 = r4.f177M
            if (r9 != 0) goto L_0x0194
            android.support.constraint.a.a.a r9 = r4.f214i
            android.support.constraint.a.a.a r9 = r9.f139c
            if (r9 == 0) goto L_0x0193
            android.support.constraint.a.a.a r9 = r4.f216k
            android.support.constraint.a.a.a r9 = r9.f139c
            if (r9 == 0) goto L_0x0193
            android.support.constraint.a.a.b$a r9 = r4.f171G
            android.support.constraint.a.a.b$a r2 = android.support.constraint.p000a.p001a.C0010b.C0012a.MATCH_CONSTRAINT
            if (r9 == r2) goto L_0x0193
            goto L_0x0194
        L_0x0193:
            r1 = 0
        L_0x0194:
            r8.f177M = r1
            boolean r9 = r8.f177M
            if (r9 == 0) goto L_0x01b0
            android.support.constraint.a.a.a r9 = r4.f216k
            android.support.constraint.a.a.a r9 = r9.f139c
            if (r9 != 0) goto L_0x01a1
            goto L_0x01a9
        L_0x01a1:
            android.support.constraint.a.a.a r9 = r4.f216k
            android.support.constraint.a.a.a r9 = r9.f139c
            android.support.constraint.a.a.b r9 = r9.f137a
            if (r9 == r8) goto L_0x01b0
        L_0x01a9:
            int r9 = r4.f174J
            int r9 = r0 - r9
            int r3 = r0 + r9
            goto L_0x01b1
        L_0x01b0:
            r3 = r0
        L_0x01b1:
            int r9 = r8.mo92d()
            r0 = 8
            if (r9 != r0) goto L_0x01bf
            int r9 = r8.f224s
            int r3 = r3 - r9
            int r9 = r8.f224s
            int r5 = r5 - r9
        L_0x01bf:
            r8.f174J = r3
            r8.f175K = r5
            return
        */
        throw new UnsupportedOperationException("Method not decompiled: android.support.constraint.p000a.p001a.C0013c.mo132a(android.support.constraint.a.a.b, boolean[]):void");
    }

    /* renamed from: a */
    public void mo133a(C0024e eVar, int i, boolean[] zArr) {
        zArr[2] = false;
        mo86b(eVar, i);
        int size = this.f278aj.size();
        for (int i2 = 0; i2 < size; i2++) {
            C0010b bVar = (C0010b) this.f278aj.get(i2);
            bVar.mo86b(eVar, i);
            if (bVar.f171G == C0012a.MATCH_CONSTRAINT && bVar.mo102h() < bVar.mo108k()) {
                zArr[2] = true;
            }
            if (bVar.f172H == C0012a.MATCH_CONSTRAINT && bVar.mo110l() < bVar.mo112m()) {
                zArr[2] = true;
            }
        }
    }

    /* renamed from: a */
    public void mo134a(ArrayList<C0010b> arrayList, boolean[] zArr) {
        ArrayList<C0010b> arrayList2 = arrayList;
        boolean[] zArr2 = zArr;
        int size = arrayList.size();
        char c = 0;
        zArr2[0] = true;
        int i = 0;
        int i2 = 0;
        int i3 = 0;
        int i4 = 0;
        int i5 = 0;
        int i6 = 0;
        int i7 = 0;
        while (i < size) {
            C0010b bVar = (C0010b) arrayList2.get(i);
            if (!bVar.mo87b()) {
                if (!bVar.f181Q) {
                    mo132a(bVar, zArr2);
                }
                if (!bVar.f182R) {
                    mo135b(bVar, zArr2);
                }
                if (zArr2[c]) {
                    int l = (bVar.f173I + bVar.f176L) - bVar.mo110l();
                    int h = bVar.f171G == C0012a.MATCH_PARENT ? bVar.mo102h() + bVar.f214i.f140d + bVar.f216k.f140d : (bVar.f174J + bVar.f175K) - bVar.mo102h();
                    int l2 = bVar.f172H == C0012a.MATCH_PARENT ? bVar.mo110l() + bVar.f215j.f140d + bVar.f217l.f140d : l;
                    if (bVar.mo92d() == 8) {
                        h = 0;
                        l2 = 0;
                    }
                    i2 = Math.max(i2, bVar.f174J);
                    i3 = Math.max(i3, bVar.f175K);
                    i6 = Math.max(i6, bVar.f176L);
                    i5 = Math.max(i5, bVar.f173I);
                    int max = Math.max(i4, h);
                    i7 = Math.max(i7, l2);
                    i4 = max;
                } else {
                    return;
                }
            }
            i++;
            c = 0;
        }
        this.f241ad = Math.max(this.f167B, Math.max(Math.max(i2, i3), i4));
        this.f242ae = Math.max(this.f168C, Math.max(Math.max(i5, i6), i7));
        for (int i8 = 0; i8 < size; i8++) {
            C0010b bVar2 = (C0010b) arrayList2.get(i8);
            bVar2.f181Q = false;
            bVar2.f182R = false;
            bVar2.f177M = false;
            bVar2.f178N = false;
            bVar2.f179O = false;
            bVar2.f180P = false;
        }
    }

    /* JADX WARNING: Removed duplicated region for block: B:131:0x0209  */
    /* renamed from: b */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public void mo135b(android.support.constraint.p000a.p001a.C0010b r9, boolean[] r10) {
        /*
            r8 = this;
            android.support.constraint.a.a.b$a r0 = r9.f172H
            android.support.constraint.a.a.b$a r1 = android.support.constraint.p000a.p001a.C0010b.C0012a.MATCH_CONSTRAINT
            r2 = 0
            if (r0 != r1) goto L_0x0017
            android.support.constraint.a.a.b$a r0 = r9.f171G
            android.support.constraint.a.a.b$a r1 = android.support.constraint.p000a.p001a.C0010b.C0012a.MATCH_CONSTRAINT
            if (r0 == r1) goto L_0x0017
            float r0 = r9.f226u
            r1 = 0
            int r0 = (r0 > r1 ? 1 : (r0 == r1 ? 0 : -1))
            if (r0 <= 0) goto L_0x0017
            r10[r2] = r2
            return
        L_0x0017:
            int r0 = r9.mo106j()
            r1 = 1
            r9.f182R = r1
            boolean r3 = r9 instanceof android.support.constraint.p000a.p001a.C0014d
            r4 = 8
            if (r3 == 0) goto L_0x004b
            r10 = r9
            android.support.constraint.a.a.d r10 = (android.support.constraint.p000a.p001a.C0014d) r10
            int r1 = r10.mo127D()
            if (r1 != 0) goto L_0x0047
            int r0 = r10.mo139F()
            r1 = -1
            if (r0 == r1) goto L_0x003b
            int r10 = r10.mo139F()
            r2 = r10
        L_0x0039:
            r0 = 0
            goto L_0x0048
        L_0x003b:
            int r0 = r10.mo140G()
            if (r0 == r1) goto L_0x0039
            int r10 = r10.mo140G()
            r0 = r10
            goto L_0x0048
        L_0x0047:
            r2 = r0
        L_0x0048:
            r6 = r2
            goto L_0x0203
        L_0x004b:
            android.support.constraint.a.a.a r3 = r9.f218m
            android.support.constraint.a.a.a r3 = r3.f139c
            if (r3 != 0) goto L_0x0064
            android.support.constraint.a.a.a r3 = r9.f215j
            android.support.constraint.a.a.a r3 = r3.f139c
            if (r3 != 0) goto L_0x0064
            android.support.constraint.a.a.a r3 = r9.f217l
            android.support.constraint.a.a.a r3 = r3.f139c
            if (r3 != 0) goto L_0x0064
            int r10 = r9.mo100g()
            int r2 = r0 + r10
            goto L_0x0048
        L_0x0064:
            android.support.constraint.a.a.a r3 = r9.f217l
            android.support.constraint.a.a.a r3 = r3.f139c
            if (r3 == 0) goto L_0x0095
            android.support.constraint.a.a.a r3 = r9.f215j
            android.support.constraint.a.a.a r3 = r3.f139c
            if (r3 == 0) goto L_0x0095
            android.support.constraint.a.a.a r3 = r9.f217l
            android.support.constraint.a.a.a r3 = r3.f139c
            android.support.constraint.a.a.a r5 = r9.f215j
            android.support.constraint.a.a.a r5 = r5.f139c
            if (r3 == r5) goto L_0x0092
            android.support.constraint.a.a.a r3 = r9.f217l
            android.support.constraint.a.a.a r3 = r3.f139c
            android.support.constraint.a.a.b r3 = r3.f137a
            android.support.constraint.a.a.a r5 = r9.f215j
            android.support.constraint.a.a.a r5 = r5.f139c
            android.support.constraint.a.a.b r5 = r5.f137a
            if (r3 != r5) goto L_0x0095
            android.support.constraint.a.a.a r3 = r9.f217l
            android.support.constraint.a.a.a r3 = r3.f139c
            android.support.constraint.a.a.b r3 = r3.f137a
            android.support.constraint.a.a.b r5 = r9.f223r
            if (r3 == r5) goto L_0x0095
        L_0x0092:
            r10[r2] = r2
            return
        L_0x0095:
            android.support.constraint.a.a.a r3 = r9.f218m
            boolean r3 = r3.mo62j()
            if (r3 == 0) goto L_0x00d1
            android.support.constraint.a.a.a r1 = r9.f218m
            android.support.constraint.a.a.a r1 = r1.f139c
            android.support.constraint.a.a.b r1 = r1.mo54b()
            boolean r2 = r1.f182R
            if (r2 != 0) goto L_0x00ac
            r8.mo135b(r1, r10)
        L_0x00ac:
            int r10 = r1.f173I
            int r2 = r1.f225t
            int r10 = r10 - r2
            int r10 = r10 + r0
            int r10 = java.lang.Math.max(r10, r0)
            int r2 = r1.f176L
            int r1 = r1.f225t
            int r2 = r2 - r1
            int r2 = r2 + r0
            int r0 = java.lang.Math.max(r2, r0)
            int r1 = r9.mo92d()
            if (r1 != r4) goto L_0x00cc
            int r1 = r9.f225t
            int r10 = r10 - r1
            int r1 = r9.f225t
            int r0 = r0 - r1
        L_0x00cc:
            r9.f173I = r10
        L_0x00ce:
            r9.f176L = r0
            return
        L_0x00d1:
            android.support.constraint.a.a.a r3 = r9.f215j
            boolean r3 = r3.mo62j()
            r5 = 0
            if (r3 == 0) goto L_0x00f7
            android.support.constraint.a.a.a r3 = r9.f215j
            android.support.constraint.a.a.a r3 = r3.f139c
            android.support.constraint.a.a.b r3 = r3.mo54b()
            android.support.constraint.a.a.a r6 = r9.f215j
            int r6 = r6.mo56d()
            int r6 = r6 + r0
            boolean r7 = r3.mo87b()
            if (r7 != 0) goto L_0x00f9
            boolean r7 = r3.f182R
            if (r7 != 0) goto L_0x00f9
            r8.mo135b(r3, r10)
            goto L_0x00f9
        L_0x00f7:
            r6 = r0
            r3 = r5
        L_0x00f9:
            android.support.constraint.a.a.a r7 = r9.f217l
            boolean r7 = r7.mo62j()
            if (r7 == 0) goto L_0x011d
            android.support.constraint.a.a.a r5 = r9.f217l
            android.support.constraint.a.a.a r5 = r5.f139c
            android.support.constraint.a.a.b r5 = r5.mo54b()
            android.support.constraint.a.a.a r7 = r9.f217l
            int r7 = r7.mo56d()
            int r0 = r0 + r7
            boolean r7 = r5.mo87b()
            if (r7 != 0) goto L_0x011d
            boolean r7 = r5.f182R
            if (r7 != 0) goto L_0x011d
            r8.mo135b(r5, r10)
        L_0x011d:
            android.support.constraint.a.a.a r10 = r9.f215j
            android.support.constraint.a.a.a r10 = r10.f139c
            if (r10 == 0) goto L_0x0191
            boolean r10 = r3.mo87b()
            if (r10 != 0) goto L_0x0191
            android.support.constraint.a.a.a r10 = r9.f215j
            android.support.constraint.a.a.a r10 = r10.f139c
            android.support.constraint.a.a.a$c r10 = r10.mo55c()
            android.support.constraint.a.a.a$c r7 = android.support.constraint.p000a.p001a.C0005a.C0009c.TOP
            if (r10 != r7) goto L_0x013e
            int r10 = r3.f173I
            int r7 = r3.mo106j()
            int r10 = r10 - r7
        L_0x013c:
            int r6 = r6 + r10
            goto L_0x014d
        L_0x013e:
            android.support.constraint.a.a.a r10 = r9.f215j
            android.support.constraint.a.a.a r10 = r10.f139c
            android.support.constraint.a.a.a$c r10 = r10.mo55c()
            android.support.constraint.a.a.a$c r7 = android.support.constraint.p000a.p001a.C0005a.C0009c.BOTTOM
            if (r10 != r7) goto L_0x014d
            int r10 = r3.f173I
            goto L_0x013c
        L_0x014d:
            boolean r10 = r3.f179O
            if (r10 != 0) goto L_0x0176
            android.support.constraint.a.a.a r10 = r3.f215j
            android.support.constraint.a.a.a r10 = r10.f139c
            if (r10 == 0) goto L_0x0174
            android.support.constraint.a.a.a r10 = r3.f215j
            android.support.constraint.a.a.a r10 = r10.f139c
            android.support.constraint.a.a.b r10 = r10.f137a
            if (r10 == r9) goto L_0x0174
            android.support.constraint.a.a.a r10 = r3.f217l
            android.support.constraint.a.a.a r10 = r10.f139c
            if (r10 == 0) goto L_0x0174
            android.support.constraint.a.a.a r10 = r3.f217l
            android.support.constraint.a.a.a r10 = r10.f139c
            android.support.constraint.a.a.b r10 = r10.f137a
            if (r10 == r9) goto L_0x0174
            android.support.constraint.a.a.b$a r10 = r3.f172H
            android.support.constraint.a.a.b$a r7 = android.support.constraint.p000a.p001a.C0010b.C0012a.MATCH_CONSTRAINT
            if (r10 == r7) goto L_0x0174
            goto L_0x0176
        L_0x0174:
            r10 = 0
            goto L_0x0177
        L_0x0176:
            r10 = 1
        L_0x0177:
            r9.f179O = r10
            boolean r10 = r9.f179O
            if (r10 == 0) goto L_0x0191
            android.support.constraint.a.a.a r10 = r3.f217l
            android.support.constraint.a.a.a r10 = r10.f139c
            if (r10 != 0) goto L_0x0184
            goto L_0x018c
        L_0x0184:
            android.support.constraint.a.a.a r10 = r3.f217l
            android.support.constraint.a.a.a r10 = r10.f139c
            android.support.constraint.a.a.b r10 = r10.f137a
            if (r10 == r9) goto L_0x0191
        L_0x018c:
            int r10 = r3.f173I
            int r10 = r6 - r10
            int r6 = r6 + r10
        L_0x0191:
            android.support.constraint.a.a.a r10 = r9.f217l
            android.support.constraint.a.a.a r10 = r10.f139c
            if (r10 == 0) goto L_0x0203
            boolean r10 = r5.mo87b()
            if (r10 != 0) goto L_0x0203
            android.support.constraint.a.a.a r10 = r9.f217l
            android.support.constraint.a.a.a r10 = r10.f139c
            android.support.constraint.a.a.a$c r10 = r10.mo55c()
            android.support.constraint.a.a.a$c r3 = android.support.constraint.p000a.p001a.C0005a.C0009c.BOTTOM
            if (r10 != r3) goto L_0x01b2
            int r10 = r5.f176L
            int r3 = r5.mo106j()
            int r10 = r10 - r3
        L_0x01b0:
            int r0 = r0 + r10
            goto L_0x01c1
        L_0x01b2:
            android.support.constraint.a.a.a r10 = r9.f217l
            android.support.constraint.a.a.a r10 = r10.f139c
            android.support.constraint.a.a.a$c r10 = r10.mo55c()
            android.support.constraint.a.a.a$c r3 = android.support.constraint.p000a.p001a.C0005a.C0009c.TOP
            if (r10 != r3) goto L_0x01c1
            int r10 = r5.f176L
            goto L_0x01b0
        L_0x01c1:
            boolean r10 = r5.f180P
            if (r10 != 0) goto L_0x01e9
            android.support.constraint.a.a.a r10 = r5.f215j
            android.support.constraint.a.a.a r10 = r10.f139c
            if (r10 == 0) goto L_0x01e8
            android.support.constraint.a.a.a r10 = r5.f215j
            android.support.constraint.a.a.a r10 = r10.f139c
            android.support.constraint.a.a.b r10 = r10.f137a
            if (r10 == r9) goto L_0x01e8
            android.support.constraint.a.a.a r10 = r5.f217l
            android.support.constraint.a.a.a r10 = r10.f139c
            if (r10 == 0) goto L_0x01e8
            android.support.constraint.a.a.a r10 = r5.f217l
            android.support.constraint.a.a.a r10 = r10.f139c
            android.support.constraint.a.a.b r10 = r10.f137a
            if (r10 == r9) goto L_0x01e8
            android.support.constraint.a.a.b$a r10 = r5.f172H
            android.support.constraint.a.a.b$a r3 = android.support.constraint.p000a.p001a.C0010b.C0012a.MATCH_CONSTRAINT
            if (r10 == r3) goto L_0x01e8
            goto L_0x01e9
        L_0x01e8:
            r1 = 0
        L_0x01e9:
            r9.f180P = r1
            boolean r10 = r9.f180P
            if (r10 == 0) goto L_0x0203
            android.support.constraint.a.a.a r10 = r5.f215j
            android.support.constraint.a.a.a r10 = r10.f139c
            if (r10 != 0) goto L_0x01f6
            goto L_0x01fe
        L_0x01f6:
            android.support.constraint.a.a.a r10 = r5.f215j
            android.support.constraint.a.a.a r10 = r10.f139c
            android.support.constraint.a.a.b r10 = r10.f137a
            if (r10 == r9) goto L_0x0203
        L_0x01fe:
            int r10 = r5.f176L
            int r10 = r0 - r10
            int r0 = r0 + r10
        L_0x0203:
            int r10 = r9.mo92d()
            if (r10 != r4) goto L_0x020f
            int r10 = r9.f225t
            int r6 = r6 - r10
            int r10 = r9.f225t
            int r0 = r0 - r10
        L_0x020f:
            r9.f173I = r6
            goto L_0x00ce
        */
        throw new UnsupportedOperationException("Method not decompiled: android.support.constraint.p000a.p001a.C0013c.mo135b(android.support.constraint.a.a.b, boolean[]):void");
    }

    /* renamed from: c */
    public boolean mo136c(C0024e eVar, int i) {
        boolean z;
        mo78a(eVar, i);
        int size = this.f278aj.size();
        if (this.f253aq != 2 && this.f253aq != 4) {
            z = true;
        } else if (m114a(eVar)) {
            return false;
        } else {
            z = false;
        }
        for (int i2 = 0; i2 < size; i2++) {
            C0010b bVar = (C0010b) this.f278aj.get(i2);
            if (bVar instanceof C0013c) {
                C0012a aVar = bVar.f171G;
                C0012a aVar2 = bVar.f172H;
                if (aVar == C0012a.WRAP_CONTENT) {
                    bVar.mo75a(C0012a.FIXED);
                }
                if (aVar2 == C0012a.WRAP_CONTENT) {
                    bVar.mo85b(C0012a.FIXED);
                }
                bVar.mo78a(eVar, i);
                if (aVar == C0012a.WRAP_CONTENT) {
                    bVar.mo75a(aVar);
                }
                if (aVar2 == C0012a.WRAP_CONTENT) {
                    bVar.mo85b(aVar2);
                }
            } else {
                if (z) {
                    C0016e.m144a(this, eVar, bVar);
                }
                bVar.mo78a(eVar, i);
            }
        }
        if (this.f248al > 0) {
            m115b(eVar);
        }
        if (this.f249am > 0) {
            m116c(eVar);
        }
        return true;
    }

    /* renamed from: m */
    public void mo137m(int i) {
        this.f253aq = i;
    }
}
