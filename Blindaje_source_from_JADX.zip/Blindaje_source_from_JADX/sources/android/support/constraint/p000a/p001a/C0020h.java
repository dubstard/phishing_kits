package android.support.constraint.p000a.p001a;

import android.support.constraint.p000a.C0022c;
import java.util.ArrayList;

/* renamed from: android.support.constraint.a.a.h */
public class C0020h extends C0010b {

    /* renamed from: aj */
    protected ArrayList<C0010b> f278aj = new ArrayList<>();

    /* renamed from: F */
    public void mo129F() {
        mo126z();
        if (this.f278aj != null) {
            int size = this.f278aj.size();
            for (int i = 0; i < size; i++) {
                C0010b bVar = (C0010b) this.f278aj.get(i);
                if (bVar instanceof C0020h) {
                    ((C0020h) bVar).mo129F();
                }
            }
        }
    }

    /* renamed from: H */
    public C0013c mo149H() {
        C0010b c = mo88c();
        C0013c cVar = this instanceof C0013c ? (C0013c) this : null;
        while (c != null) {
            C0010b c2 = c.mo88c();
            if (c instanceof C0013c) {
                cVar = (C0013c) c;
            }
            c = c2;
        }
        return cVar;
    }

    /* renamed from: I */
    public void mo150I() {
        this.f278aj.clear();
    }

    /* renamed from: a */
    public void mo68a() {
        this.f278aj.clear();
        super.mo68a();
    }

    /* renamed from: a */
    public void mo77a(C0022c cVar) {
        super.mo77a(cVar);
        int size = this.f278aj.size();
        for (int i = 0; i < size; i++) {
            ((C0010b) this.f278aj.get(i)).mo77a(cVar);
        }
    }

    /* renamed from: b */
    public void mo83b(int i, int i2) {
        super.mo83b(i, i2);
        int size = this.f278aj.size();
        for (int i3 = 0; i3 < size; i3++) {
            ((C0010b) this.f278aj.get(i3)).mo83b(mo117r(), mo118s());
        }
    }

    /* renamed from: b */
    public void mo151b(C0010b bVar) {
        this.f278aj.add(bVar);
        if (bVar.mo88c() != null) {
            ((C0020h) bVar.mo88c()).mo152c(bVar);
        }
        bVar.mo76a((C0010b) this);
    }

    /* renamed from: c */
    public void mo152c(C0010b bVar) {
        this.f278aj.remove(bVar);
        bVar.mo76a((C0010b) null);
    }

    /* renamed from: z */
    public void mo126z() {
        super.mo126z();
        if (this.f278aj != null) {
            int size = this.f278aj.size();
            for (int i = 0; i < size; i++) {
                C0010b bVar = (C0010b) this.f278aj.get(i);
                bVar.mo83b(mo113n(), mo114o());
                if (!(bVar instanceof C0013c)) {
                    bVar.mo126z();
                }
            }
        }
    }
}
