package android.support.constraint.p000a.p001a;

import android.support.constraint.p000a.p001a.C0005a.C0008b;
import java.util.ArrayList;

/* renamed from: android.support.constraint.a.a.g */
public class C0018g {

    /* renamed from: a */
    private int f268a;

    /* renamed from: b */
    private int f269b;

    /* renamed from: c */
    private int f270c;

    /* renamed from: d */
    private int f271d;

    /* renamed from: e */
    private ArrayList<C0019a> f272e = new ArrayList<>();

    /* renamed from: android.support.constraint.a.a.g$a */
    static class C0019a {

        /* renamed from: a */
        private C0005a f273a;

        /* renamed from: b */
        private C0005a f274b;

        /* renamed from: c */
        private int f275c;

        /* renamed from: d */
        private C0008b f276d;

        /* renamed from: e */
        private int f277e;

        public C0019a(C0005a aVar) {
            this.f273a = aVar;
            this.f274b = aVar.mo58f();
            this.f275c = aVar.mo56d();
            this.f276d = aVar.mo57e();
            this.f277e = aVar.mo60h();
        }

        /* renamed from: a */
        public void mo147a(C0010b bVar) {
            int i;
            this.f273a = bVar.mo67a(this.f273a.mo55c());
            if (this.f273a != null) {
                this.f274b = this.f273a.mo58f();
                this.f275c = this.f273a.mo56d();
                this.f276d = this.f273a.mo57e();
                i = this.f273a.mo60h();
            } else {
                this.f274b = null;
                i = 0;
                this.f275c = 0;
                this.f276d = C0008b.STRONG;
            }
            this.f277e = i;
        }

        /* renamed from: b */
        public void mo148b(C0010b bVar) {
            bVar.mo67a(this.f273a.mo55c()).mo53a(this.f274b, this.f275c, this.f276d, this.f277e);
        }
    }

    public C0018g(C0010b bVar) {
        this.f268a = bVar.mo98f();
        this.f269b = bVar.mo100g();
        this.f270c = bVar.mo102h();
        this.f271d = bVar.mo110l();
        ArrayList y = bVar.mo125y();
        int size = y.size();
        for (int i = 0; i < size; i++) {
            this.f272e.add(new C0019a((C0005a) y.get(i)));
        }
    }

    /* renamed from: a */
    public void mo145a(C0010b bVar) {
        this.f268a = bVar.mo98f();
        this.f269b = bVar.mo100g();
        this.f270c = bVar.mo102h();
        this.f271d = bVar.mo110l();
        int size = this.f272e.size();
        for (int i = 0; i < size; i++) {
            ((C0019a) this.f272e.get(i)).mo147a(bVar);
        }
    }

    /* renamed from: b */
    public void mo146b(C0010b bVar) {
        bVar.mo82b(this.f268a);
        bVar.mo90c(this.f269b);
        bVar.mo94d(this.f270c);
        bVar.mo97e(this.f271d);
        int size = this.f272e.size();
        for (int i = 0; i < size; i++) {
            ((C0019a) this.f272e.get(i)).mo148b(bVar);
        }
    }
}
