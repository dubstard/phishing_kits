package android.support.constraint;

import android.annotation.TargetApi;
import android.content.Context;
import android.content.res.TypedArray;
import android.os.Build.VERSION;
import android.support.constraint.C0031c.C0032a;
import android.support.constraint.p000a.p001a.C0005a.C0009c;
import android.support.constraint.p000a.p001a.C0010b;
import android.support.constraint.p000a.p001a.C0010b.C0012a;
import android.support.constraint.p000a.p001a.C0013c;
import android.support.constraint.p000a.p001a.C0014d;
import android.util.AttributeSet;
import android.util.SparseArray;
import android.view.View;
import android.view.View.MeasureSpec;
import android.view.ViewGroup;
import android.view.ViewGroup.LayoutParams;
import android.view.ViewGroup.MarginLayoutParams;
import java.util.ArrayList;

public class ConstraintLayout extends ViewGroup {

    /* renamed from: a */
    SparseArray<View> f0a = new SparseArray<>();

    /* renamed from: b */
    C0013c f1b = new C0013c();

    /* renamed from: c */
    private final ArrayList<C0010b> f2c = new ArrayList<>(100);

    /* renamed from: d */
    private int f3d = 0;

    /* renamed from: e */
    private int f4e = 0;

    /* renamed from: f */
    private int f5f = Integer.MAX_VALUE;

    /* renamed from: g */
    private int f6g = Integer.MAX_VALUE;

    /* renamed from: h */
    private boolean f7h = true;

    /* renamed from: i */
    private int f8i = 2;

    /* renamed from: j */
    private C0001a f9j = null;

    /* renamed from: android.support.constraint.ConstraintLayout$a */
    public static class C0000a extends MarginLayoutParams {

        /* renamed from: A */
        int f10A = 1;

        /* renamed from: B */
        public float f11B = 0.0f;

        /* renamed from: C */
        public float f12C = 0.0f;

        /* renamed from: D */
        public int f13D = 0;

        /* renamed from: E */
        public int f14E = 0;

        /* renamed from: F */
        public int f15F = 0;

        /* renamed from: G */
        public int f16G = 0;

        /* renamed from: H */
        public int f17H = 0;

        /* renamed from: I */
        public int f18I = 0;

        /* renamed from: J */
        public int f19J = 0;

        /* renamed from: K */
        public int f20K = 0;

        /* renamed from: L */
        public int f21L = -1;

        /* renamed from: M */
        public int f22M = -1;

        /* renamed from: N */
        public int f23N = -1;

        /* renamed from: O */
        boolean f24O = true;

        /* renamed from: P */
        boolean f25P = true;

        /* renamed from: Q */
        boolean f26Q = false;

        /* renamed from: R */
        boolean f27R = false;

        /* renamed from: S */
        int f28S = -1;

        /* renamed from: T */
        int f29T = -1;

        /* renamed from: U */
        int f30U = -1;

        /* renamed from: V */
        int f31V = -1;

        /* renamed from: W */
        int f32W = -1;

        /* renamed from: X */
        int f33X = -1;

        /* renamed from: Y */
        float f34Y = 0.5f;

        /* renamed from: Z */
        C0010b f35Z = new C0010b();

        /* renamed from: a */
        public int f36a = -1;

        /* renamed from: b */
        public int f37b = -1;

        /* renamed from: c */
        public float f38c = -1.0f;

        /* renamed from: d */
        public int f39d = -1;

        /* renamed from: e */
        public int f40e = -1;

        /* renamed from: f */
        public int f41f = -1;

        /* renamed from: g */
        public int f42g = -1;

        /* renamed from: h */
        public int f43h = -1;

        /* renamed from: i */
        public int f44i = -1;

        /* renamed from: j */
        public int f45j = -1;

        /* renamed from: k */
        public int f46k = -1;

        /* renamed from: l */
        public int f47l = -1;

        /* renamed from: m */
        public int f48m = -1;

        /* renamed from: n */
        public int f49n = -1;

        /* renamed from: o */
        public int f50o = -1;

        /* renamed from: p */
        public int f51p = -1;

        /* renamed from: q */
        public int f52q = -1;

        /* renamed from: r */
        public int f53r = -1;

        /* renamed from: s */
        public int f54s = -1;

        /* renamed from: t */
        public int f55t = -1;

        /* renamed from: u */
        public int f56u = -1;

        /* renamed from: v */
        public int f57v = -1;

        /* renamed from: w */
        public float f58w = 0.5f;

        /* renamed from: x */
        public float f59x = 0.5f;

        /* renamed from: y */
        public String f60y = null;

        /* renamed from: z */
        float f61z = 0.0f;

        public C0000a(int i, int i2) {
            super(i, i2);
        }

        public C0000a(Context context, AttributeSet attributeSet) {
            int i;
            float parseFloat;
            super(context, attributeSet);
            TypedArray obtainStyledAttributes = context.obtainStyledAttributes(attributeSet, C0032a.ConstraintLayout_Layout);
            int indexCount = obtainStyledAttributes.getIndexCount();
            for (int i2 = 0; i2 < indexCount; i2++) {
                int index = obtainStyledAttributes.getIndex(i2);
                if (index == C0032a.ConstraintLayout_Layout_layout_constraintLeft_toLeftOf) {
                    this.f39d = obtainStyledAttributes.getResourceId(index, this.f39d);
                    if (this.f39d == -1) {
                        this.f39d = obtainStyledAttributes.getInt(index, -1);
                    }
                } else if (index == C0032a.ConstraintLayout_Layout_layout_constraintLeft_toRightOf) {
                    this.f40e = obtainStyledAttributes.getResourceId(index, this.f40e);
                    if (this.f40e == -1) {
                        this.f40e = obtainStyledAttributes.getInt(index, -1);
                    }
                } else if (index == C0032a.ConstraintLayout_Layout_layout_constraintRight_toLeftOf) {
                    this.f41f = obtainStyledAttributes.getResourceId(index, this.f41f);
                    if (this.f41f == -1) {
                        this.f41f = obtainStyledAttributes.getInt(index, -1);
                    }
                } else if (index == C0032a.ConstraintLayout_Layout_layout_constraintRight_toRightOf) {
                    this.f42g = obtainStyledAttributes.getResourceId(index, this.f42g);
                    if (this.f42g == -1) {
                        this.f42g = obtainStyledAttributes.getInt(index, -1);
                    }
                } else if (index == C0032a.ConstraintLayout_Layout_layout_constraintTop_toTopOf) {
                    this.f43h = obtainStyledAttributes.getResourceId(index, this.f43h);
                    if (this.f43h == -1) {
                        this.f43h = obtainStyledAttributes.getInt(index, -1);
                    }
                } else if (index == C0032a.ConstraintLayout_Layout_layout_constraintTop_toBottomOf) {
                    this.f44i = obtainStyledAttributes.getResourceId(index, this.f44i);
                    if (this.f44i == -1) {
                        this.f44i = obtainStyledAttributes.getInt(index, -1);
                    }
                } else if (index == C0032a.ConstraintLayout_Layout_layout_constraintBottom_toTopOf) {
                    this.f45j = obtainStyledAttributes.getResourceId(index, this.f45j);
                    if (this.f45j == -1) {
                        this.f45j = obtainStyledAttributes.getInt(index, -1);
                    }
                } else if (index == C0032a.ConstraintLayout_Layout_layout_constraintBottom_toBottomOf) {
                    this.f46k = obtainStyledAttributes.getResourceId(index, this.f46k);
                    if (this.f46k == -1) {
                        this.f46k = obtainStyledAttributes.getInt(index, -1);
                    }
                } else if (index == C0032a.ConstraintLayout_Layout_layout_constraintBaseline_toBaselineOf) {
                    this.f47l = obtainStyledAttributes.getResourceId(index, this.f47l);
                    if (this.f47l == -1) {
                        this.f47l = obtainStyledAttributes.getInt(index, -1);
                    }
                } else if (index == C0032a.ConstraintLayout_Layout_layout_editor_absoluteX) {
                    this.f21L = obtainStyledAttributes.getDimensionPixelOffset(index, this.f21L);
                } else if (index == C0032a.ConstraintLayout_Layout_layout_editor_absoluteY) {
                    this.f22M = obtainStyledAttributes.getDimensionPixelOffset(index, this.f22M);
                } else if (index == C0032a.ConstraintLayout_Layout_layout_constraintGuide_begin) {
                    this.f36a = obtainStyledAttributes.getDimensionPixelOffset(index, this.f36a);
                } else if (index == C0032a.ConstraintLayout_Layout_layout_constraintGuide_end) {
                    this.f37b = obtainStyledAttributes.getDimensionPixelOffset(index, this.f37b);
                } else if (index == C0032a.ConstraintLayout_Layout_layout_constraintGuide_percent) {
                    this.f38c = obtainStyledAttributes.getFloat(index, this.f38c);
                } else if (index == C0032a.ConstraintLayout_Layout_android_orientation) {
                    this.f23N = obtainStyledAttributes.getInt(index, this.f23N);
                } else if (index == C0032a.ConstraintLayout_Layout_layout_constraintStart_toEndOf) {
                    this.f48m = obtainStyledAttributes.getResourceId(index, this.f48m);
                    if (this.f48m == -1) {
                        this.f48m = obtainStyledAttributes.getInt(index, -1);
                    }
                } else if (index == C0032a.ConstraintLayout_Layout_layout_constraintStart_toStartOf) {
                    this.f49n = obtainStyledAttributes.getResourceId(index, this.f49n);
                    if (this.f49n == -1) {
                        this.f49n = obtainStyledAttributes.getInt(index, -1);
                    }
                } else if (index == C0032a.ConstraintLayout_Layout_layout_constraintEnd_toStartOf) {
                    this.f50o = obtainStyledAttributes.getResourceId(index, this.f50o);
                    if (this.f50o == -1) {
                        this.f50o = obtainStyledAttributes.getInt(index, -1);
                    }
                } else if (index == C0032a.ConstraintLayout_Layout_layout_constraintEnd_toEndOf) {
                    this.f51p = obtainStyledAttributes.getResourceId(index, this.f51p);
                    if (this.f51p == -1) {
                        this.f51p = obtainStyledAttributes.getInt(index, -1);
                    }
                } else if (index == C0032a.ConstraintLayout_Layout_layout_goneMarginLeft) {
                    this.f52q = obtainStyledAttributes.getDimensionPixelSize(index, this.f52q);
                } else if (index == C0032a.ConstraintLayout_Layout_layout_goneMarginTop) {
                    this.f53r = obtainStyledAttributes.getDimensionPixelSize(index, this.f53r);
                } else if (index == C0032a.ConstraintLayout_Layout_layout_goneMarginRight) {
                    this.f54s = obtainStyledAttributes.getDimensionPixelSize(index, this.f54s);
                } else if (index == C0032a.ConstraintLayout_Layout_layout_goneMarginBottom) {
                    this.f55t = obtainStyledAttributes.getDimensionPixelSize(index, this.f55t);
                } else if (index == C0032a.ConstraintLayout_Layout_layout_goneMarginStart) {
                    this.f56u = obtainStyledAttributes.getDimensionPixelSize(index, this.f56u);
                } else if (index == C0032a.ConstraintLayout_Layout_layout_goneMarginEnd) {
                    this.f57v = obtainStyledAttributes.getDimensionPixelSize(index, this.f57v);
                } else if (index == C0032a.ConstraintLayout_Layout_layout_constraintHorizontal_bias) {
                    this.f58w = obtainStyledAttributes.getFloat(index, this.f58w);
                } else if (index == C0032a.ConstraintLayout_Layout_layout_constraintVertical_bias) {
                    this.f59x = obtainStyledAttributes.getFloat(index, this.f59x);
                } else if (index == C0032a.ConstraintLayout_Layout_layout_constraintDimensionRatio) {
                    this.f60y = obtainStyledAttributes.getString(index);
                    this.f61z = Float.NaN;
                    this.f10A = -1;
                    if (this.f60y != null) {
                        int length = this.f60y.length();
                        int indexOf = this.f60y.indexOf(44);
                        if (indexOf <= 0 || indexOf >= length - 1) {
                            i = 0;
                        } else {
                            String substring = this.f60y.substring(0, indexOf);
                            if (substring.equalsIgnoreCase("W")) {
                                this.f10A = 0;
                            } else if (substring.equalsIgnoreCase("H")) {
                                this.f10A = 1;
                            }
                            i = indexOf + 1;
                        }
                        int indexOf2 = this.f60y.indexOf(58);
                        if (indexOf2 < 0 || indexOf2 >= length - 1) {
                            String substring2 = this.f60y.substring(i);
                            if (substring2.length() > 0) {
                                parseFloat = Float.parseFloat(substring2);
                            }
                        } else {
                            String substring3 = this.f60y.substring(i, indexOf2);
                            String substring4 = this.f60y.substring(indexOf2 + 1);
                            if (substring3.length() > 0 && substring4.length() > 0) {
                                try {
                                    float parseFloat2 = Float.parseFloat(substring3);
                                    float parseFloat3 = Float.parseFloat(substring4);
                                    if (parseFloat2 > 0.0f && parseFloat3 > 0.0f) {
                                        parseFloat = this.f10A == 1 ? Math.abs(parseFloat3 / parseFloat2) : Math.abs(parseFloat2 / parseFloat3);
                                    }
                                } catch (NumberFormatException unused) {
                                }
                            }
                        }
                        this.f61z = parseFloat;
                    }
                } else if (index == C0032a.ConstraintLayout_Layout_layout_constraintHorizontal_weight) {
                    this.f11B = obtainStyledAttributes.getFloat(index, 0.0f);
                } else if (index == C0032a.ConstraintLayout_Layout_layout_constraintVertical_weight) {
                    this.f12C = obtainStyledAttributes.getFloat(index, 0.0f);
                } else if (index == C0032a.ConstraintLayout_Layout_layout_constraintHorizontal_chainStyle) {
                    this.f13D = obtainStyledAttributes.getInt(index, 0);
                } else if (index == C0032a.ConstraintLayout_Layout_layout_constraintVertical_chainStyle) {
                    this.f14E = obtainStyledAttributes.getInt(index, 0);
                } else if (index == C0032a.ConstraintLayout_Layout_layout_constraintWidth_default) {
                    this.f15F = obtainStyledAttributes.getInt(index, 0);
                } else if (index == C0032a.ConstraintLayout_Layout_layout_constraintHeight_default) {
                    this.f16G = obtainStyledAttributes.getInt(index, 0);
                } else if (index == C0032a.ConstraintLayout_Layout_layout_constraintWidth_min) {
                    this.f17H = obtainStyledAttributes.getDimensionPixelSize(index, this.f17H);
                } else if (index == C0032a.ConstraintLayout_Layout_layout_constraintWidth_max) {
                    this.f19J = obtainStyledAttributes.getDimensionPixelSize(index, this.f19J);
                } else if (index == C0032a.ConstraintLayout_Layout_layout_constraintHeight_min) {
                    this.f18I = obtainStyledAttributes.getDimensionPixelSize(index, this.f18I);
                } else if (index == C0032a.ConstraintLayout_Layout_layout_constraintHeight_max) {
                    this.f20K = obtainStyledAttributes.getDimensionPixelSize(index, this.f20K);
                } else if (!(index == C0032a.ConstraintLayout_Layout_layout_constraintLeft_creator || index == C0032a.ConstraintLayout_Layout_layout_constraintTop_creator || index == C0032a.ConstraintLayout_Layout_layout_constraintRight_creator || index == C0032a.ConstraintLayout_Layout_layout_constraintBottom_creator)) {
                    int i3 = C0032a.ConstraintLayout_Layout_layout_constraintBaseline_creator;
                }
            }
            obtainStyledAttributes.recycle();
            mo26a();
        }

        public C0000a(LayoutParams layoutParams) {
            super(layoutParams);
        }

        /* renamed from: a */
        public void mo26a() {
            this.f27R = false;
            this.f24O = true;
            this.f25P = true;
            if (this.width == 0 || this.width == -1) {
                this.f24O = false;
            }
            if (this.height == 0 || this.height == -1) {
                this.f25P = false;
            }
            if (this.f38c != -1.0f || this.f36a != -1 || this.f37b != -1) {
                this.f27R = true;
                this.f24O = true;
                this.f25P = true;
                if (!(this.f35Z instanceof C0014d)) {
                    this.f35Z = new C0014d();
                }
                ((C0014d) this.f35Z).mo142m(this.f23N);
            }
        }

        @TargetApi(17)
        public void resolveLayoutDirection(int i) {
            super.resolveLayoutDirection(i);
            this.f30U = -1;
            this.f31V = -1;
            this.f28S = -1;
            this.f29T = -1;
            this.f32W = -1;
            this.f33X = -1;
            this.f32W = this.f52q;
            this.f33X = this.f54s;
            this.f34Y = this.f58w;
            boolean z = true;
            if (1 != getLayoutDirection()) {
                z = false;
            }
            if (z) {
                if (this.f48m != -1) {
                    this.f30U = this.f48m;
                } else if (this.f49n != -1) {
                    this.f31V = this.f49n;
                }
                if (this.f50o != -1) {
                    this.f29T = this.f50o;
                }
                if (this.f51p != -1) {
                    this.f28S = this.f51p;
                }
                if (this.f56u != -1) {
                    this.f33X = this.f56u;
                }
                if (this.f57v != -1) {
                    this.f32W = this.f57v;
                }
                this.f34Y = 1.0f - this.f58w;
            } else {
                if (this.f48m != -1) {
                    this.f29T = this.f48m;
                }
                if (this.f49n != -1) {
                    this.f28S = this.f49n;
                }
                if (this.f50o != -1) {
                    this.f30U = this.f50o;
                }
                if (this.f51p != -1) {
                    this.f31V = this.f51p;
                }
                if (this.f56u != -1) {
                    this.f32W = this.f56u;
                }
                if (this.f57v != -1) {
                    this.f33X = this.f57v;
                }
            }
            if (this.f50o == -1 && this.f51p == -1) {
                if (this.f41f != -1) {
                    this.f30U = this.f41f;
                } else if (this.f42g != -1) {
                    this.f31V = this.f42g;
                }
            }
            if (this.f49n == -1 && this.f48m == -1) {
                if (this.f39d != -1) {
                    this.f28S = this.f39d;
                } else if (this.f40e != -1) {
                    this.f29T = this.f40e;
                }
            }
        }
    }

    public ConstraintLayout(Context context) {
        super(context);
        m4b(null);
    }

    public ConstraintLayout(Context context, AttributeSet attributeSet) {
        super(context, attributeSet);
        m4b(attributeSet);
    }

    public ConstraintLayout(Context context, AttributeSet attributeSet, int i) {
        super(context, attributeSet, i);
        m4b(attributeSet);
    }

    /* renamed from: a */
    private final C0010b m0a(int i) {
        if (i == 0) {
            return this.f1b;
        }
        View view = (View) this.f0a.get(i);
        if (view == this) {
            return this.f1b;
        }
        if (view == null) {
            return null;
        }
        return ((C0000a) view.getLayoutParams()).f35Z;
    }

    /* renamed from: a */
    private final C0010b m1a(View view) {
        if (view == this) {
            return this.f1b;
        }
        if (view == null) {
            return null;
        }
        return ((C0000a) view.getLayoutParams()).f35Z;
    }

    /* renamed from: a */
    private void m2a(int i, int i2) {
        boolean z;
        int i3;
        int i4;
        int i5 = i;
        int i6 = i2;
        int paddingTop = getPaddingTop() + getPaddingBottom();
        int paddingLeft = getPaddingLeft() + getPaddingRight();
        int childCount = getChildCount();
        for (int i7 = 0; i7 < childCount; i7++) {
            View childAt = getChildAt(i7);
            if (childAt.getVisibility() != 8) {
                C0000a aVar = (C0000a) childAt.getLayoutParams();
                C0010b bVar = aVar.f35Z;
                if (!aVar.f27R) {
                    int i8 = aVar.width;
                    int i9 = aVar.height;
                    boolean z2 = true;
                    if (aVar.f24O || aVar.f25P || (!aVar.f24O && aVar.f15F == 1) || aVar.width == -1 || (!aVar.f25P && (aVar.f16G == 1 || aVar.height == -1))) {
                        if (i8 == 0 || i8 == -1) {
                            i3 = getChildMeasureSpec(i5, paddingLeft, -2);
                            z = true;
                        } else {
                            i3 = getChildMeasureSpec(i5, paddingLeft, i8);
                            z = false;
                        }
                        if (i9 == 0 || i9 == -1) {
                            i4 = getChildMeasureSpec(i6, paddingTop, -2);
                        } else {
                            i4 = getChildMeasureSpec(i6, paddingTop, i9);
                            z2 = false;
                        }
                        childAt.measure(i3, i4);
                        i8 = childAt.getMeasuredWidth();
                        i9 = childAt.getMeasuredHeight();
                    } else {
                        z2 = false;
                        z = false;
                    }
                    bVar.mo94d(i8);
                    bVar.mo97e(i9);
                    if (z) {
                        bVar.mo103h(i8);
                    }
                    if (z2) {
                        bVar.mo105i(i9);
                    }
                    if (aVar.f26Q) {
                        int baseline = childAt.getBaseline();
                        if (baseline != -1) {
                            bVar.mo107j(baseline);
                        }
                    }
                }
            }
        }
    }

    /* renamed from: b */
    private void m3b(int i, int i2) {
        int mode = MeasureSpec.getMode(i);
        int size = MeasureSpec.getSize(i);
        int mode2 = MeasureSpec.getMode(i2);
        int size2 = MeasureSpec.getSize(i2);
        int paddingTop = getPaddingTop() + getPaddingBottom();
        int paddingLeft = getPaddingLeft() + getPaddingRight();
        C0012a aVar = C0012a.FIXED;
        C0012a aVar2 = C0012a.FIXED;
        getLayoutParams();
        if (mode != Integer.MIN_VALUE) {
            if (mode == 0) {
                aVar = C0012a.WRAP_CONTENT;
            } else if (mode == 1073741824) {
                size = Math.min(this.f5f, size) - paddingLeft;
            }
            size = 0;
        } else {
            aVar = C0012a.WRAP_CONTENT;
        }
        if (mode2 != Integer.MIN_VALUE) {
            if (mode2 == 0) {
                aVar2 = C0012a.WRAP_CONTENT;
            } else if (mode2 == 1073741824) {
                size2 = Math.min(this.f6g, size2) - paddingTop;
            }
            size2 = 0;
        } else {
            aVar2 = C0012a.WRAP_CONTENT;
        }
        this.f1b.mo99f(0);
        this.f1b.mo101g(0);
        this.f1b.mo75a(aVar);
        this.f1b.mo94d(size);
        this.f1b.mo85b(aVar2);
        this.f1b.mo97e(size2);
        this.f1b.mo99f((this.f3d - getPaddingLeft()) - getPaddingRight());
        this.f1b.mo101g((this.f4e - getPaddingTop()) - getPaddingBottom());
    }

    /* renamed from: b */
    private void m4b(AttributeSet attributeSet) {
        this.f1b.mo79a((Object) this);
        this.f0a.put(getId(), this);
        this.f9j = null;
        if (attributeSet != null) {
            TypedArray obtainStyledAttributes = getContext().obtainStyledAttributes(attributeSet, C0032a.ConstraintLayout_Layout);
            int indexCount = obtainStyledAttributes.getIndexCount();
            for (int i = 0; i < indexCount; i++) {
                int index = obtainStyledAttributes.getIndex(i);
                if (index == C0032a.ConstraintLayout_Layout_android_minWidth) {
                    this.f3d = obtainStyledAttributes.getDimensionPixelOffset(index, this.f3d);
                } else if (index == C0032a.ConstraintLayout_Layout_android_minHeight) {
                    this.f4e = obtainStyledAttributes.getDimensionPixelOffset(index, this.f4e);
                } else if (index == C0032a.ConstraintLayout_Layout_android_maxWidth) {
                    this.f5f = obtainStyledAttributes.getDimensionPixelOffset(index, this.f5f);
                } else if (index == C0032a.ConstraintLayout_Layout_android_maxHeight) {
                    this.f6g = obtainStyledAttributes.getDimensionPixelOffset(index, this.f6g);
                } else if (index == C0032a.ConstraintLayout_Layout_layout_optimizationLevel) {
                    this.f8i = obtainStyledAttributes.getInt(index, this.f8i);
                } else if (index == C0032a.ConstraintLayout_Layout_constraintSet) {
                    int resourceId = obtainStyledAttributes.getResourceId(index, 0);
                    this.f9j = new C0001a();
                    this.f9j.mo28a(getContext(), resourceId);
                }
            }
            obtainStyledAttributes.recycle();
        }
        this.f1b.mo137m(this.f8i);
    }

    /* renamed from: c */
    private void m5c() {
        int childCount = getChildCount();
        boolean z = false;
        int i = 0;
        while (true) {
            if (i >= childCount) {
                break;
            } else if (getChildAt(i).isLayoutRequested()) {
                z = true;
                break;
            } else {
                i++;
            }
        }
        if (z) {
            this.f2c.clear();
            m6d();
        }
    }

    /* JADX WARNING: Removed duplicated region for block: B:103:0x0164  */
    /* JADX WARNING: Removed duplicated region for block: B:106:0x0171  */
    /* JADX WARNING: Removed duplicated region for block: B:114:0x018d  */
    /* JADX WARNING: Removed duplicated region for block: B:139:0x0217  */
    /* JADX WARNING: Removed duplicated region for block: B:143:0x023c  */
    /* JADX WARNING: Removed duplicated region for block: B:147:0x024a  */
    /* JADX WARNING: Removed duplicated region for block: B:151:0x0273  */
    /* JADX WARNING: Removed duplicated region for block: B:154:0x0282  */
    /* JADX WARNING: Removed duplicated region for block: B:82:0x0118  */
    /* JADX WARNING: Removed duplicated region for block: B:85:0x0123  */
    /* JADX WARNING: Removed duplicated region for block: B:92:0x013b  */
    /* JADX WARNING: Removed duplicated region for block: B:95:0x0148  */
    /* renamed from: d */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    private void m6d() {
        /*
            r24 = this;
            r0 = r24
            android.support.constraint.a r1 = r0.f9j
            if (r1 == 0) goto L_0x000b
            android.support.constraint.a r1 = r0.f9j
            r1.mo29a(r0)
        L_0x000b:
            int r1 = r24.getChildCount()
            android.support.constraint.a.a.c r2 = r0.f1b
            r2.mo150I()
            r3 = 0
        L_0x0015:
            if (r3 >= r1) goto L_0x02b1
            android.view.View r4 = r0.getChildAt(r3)
            android.support.constraint.a.a.b r11 = r0.m1a(r4)
            if (r11 != 0) goto L_0x0024
        L_0x0021:
            r2 = 0
            goto L_0x02ad
        L_0x0024:
            android.view.ViewGroup$LayoutParams r5 = r4.getLayoutParams()
            r12 = r5
            android.support.constraint.ConstraintLayout$a r12 = (android.support.constraint.ConstraintLayout.C0000a) r12
            r11.mo68a()
            int r5 = r4.getVisibility()
            r11.mo70a(r5)
            r11.mo79a(r4)
            android.support.constraint.a.a.c r4 = r0.f1b
            r4.mo151b(r11)
            boolean r4 = r12.f25P
            if (r4 == 0) goto L_0x0045
            boolean r4 = r12.f24O
            if (r4 != 0) goto L_0x004a
        L_0x0045:
            java.util.ArrayList<android.support.constraint.a.a.b> r4 = r0.f2c
            r4.add(r11)
        L_0x004a:
            boolean r4 = r12.f27R
            r13 = -1
            if (r4 == 0) goto L_0x0071
            android.support.constraint.a.a.d r11 = (android.support.constraint.p000a.p001a.C0014d) r11
            int r4 = r12.f36a
            if (r4 == r13) goto L_0x005a
            int r4 = r12.f36a
            r11.mo143n(r4)
        L_0x005a:
            int r4 = r12.f37b
            if (r4 == r13) goto L_0x0063
            int r4 = r12.f37b
            r11.mo144o(r4)
        L_0x0063:
            float r4 = r12.f38c
            r5 = -1082130432(0xffffffffbf800000, float:-1.0)
            int r4 = (r4 > r5 ? 1 : (r4 == r5 ? 0 : -1))
            if (r4 == 0) goto L_0x0021
            float r4 = r12.f38c
            r11.mo141e(r4)
            goto L_0x0021
        L_0x0071:
            int r4 = r12.f28S
            if (r4 != r13) goto L_0x00a5
            int r4 = r12.f29T
            if (r4 != r13) goto L_0x00a5
            int r4 = r12.f30U
            if (r4 != r13) goto L_0x00a5
            int r4 = r12.f31V
            if (r4 != r13) goto L_0x00a5
            int r4 = r12.f43h
            if (r4 != r13) goto L_0x00a5
            int r4 = r12.f44i
            if (r4 != r13) goto L_0x00a5
            int r4 = r12.f45j
            if (r4 != r13) goto L_0x00a5
            int r4 = r12.f46k
            if (r4 != r13) goto L_0x00a5
            int r4 = r12.f47l
            if (r4 != r13) goto L_0x00a5
            int r4 = r12.f21L
            if (r4 != r13) goto L_0x00a5
            int r4 = r12.f22M
            if (r4 != r13) goto L_0x00a5
            int r4 = r12.width
            if (r4 == r13) goto L_0x00a5
            int r4 = r12.height
            if (r4 != r13) goto L_0x0021
        L_0x00a5:
            int r4 = r12.f28S
            int r5 = r12.f29T
            int r6 = r12.f30U
            int r7 = r12.f31V
            int r8 = r12.f32W
            int r9 = r12.f33X
            float r10 = r12.f34Y
            int r14 = android.os.Build.VERSION.SDK_INT
            r15 = 17
            if (r14 >= r15) goto L_0x00e9
            int r4 = r12.f39d
            int r5 = r12.f40e
            int r6 = r12.f41f
            int r7 = r12.f42g
            int r8 = r12.f52q
            int r9 = r12.f54s
            float r10 = r12.f58w
            if (r4 != r13) goto L_0x00d8
            if (r5 != r13) goto L_0x00d8
            int r14 = r12.f49n
            if (r14 == r13) goto L_0x00d2
            int r4 = r12.f49n
            goto L_0x00d8
        L_0x00d2:
            int r14 = r12.f48m
            if (r14 == r13) goto L_0x00d8
            int r5 = r12.f48m
        L_0x00d8:
            if (r6 != r13) goto L_0x00e9
            if (r7 != r13) goto L_0x00e9
            int r14 = r12.f50o
            if (r14 == r13) goto L_0x00e3
            int r6 = r12.f50o
            goto L_0x00e9
        L_0x00e3:
            int r14 = r12.f51p
            if (r14 == r13) goto L_0x00e9
            int r7 = r12.f51p
        L_0x00e9:
            r14 = r6
            r15 = r7
            r16 = r9
            r9 = r10
            r10 = r8
            if (r4 == r13) goto L_0x0103
            android.support.constraint.a.a.b r7 = r0.m0a(r4)
            if (r7 == 0) goto L_0x0101
            android.support.constraint.a.a.a$c r6 = android.support.constraint.p000a.p001a.C0005a.C0009c.LEFT
            android.support.constraint.a.a.a$c r8 = android.support.constraint.p000a.p001a.C0005a.C0009c.LEFT
            int r4 = r12.leftMargin
            r5 = r11
            r2 = r9
            r9 = r4
            goto L_0x0113
        L_0x0101:
            r2 = r9
            goto L_0x0116
        L_0x0103:
            r2 = r9
            if (r5 == r13) goto L_0x0116
            android.support.constraint.a.a.b r7 = r0.m0a(r5)
            if (r7 == 0) goto L_0x0116
            android.support.constraint.a.a.a$c r6 = android.support.constraint.p000a.p001a.C0005a.C0009c.LEFT
            android.support.constraint.a.a.a$c r8 = android.support.constraint.p000a.p001a.C0005a.C0009c.RIGHT
            int r9 = r12.leftMargin
            r5 = r11
        L_0x0113:
            r5.mo74a(r6, r7, r8, r9, r10)
        L_0x0116:
            if (r14 == r13) goto L_0x0123
            android.support.constraint.a.a.b r7 = r0.m0a(r14)
            if (r7 == 0) goto L_0x0137
            android.support.constraint.a.a.a$c r6 = android.support.constraint.p000a.p001a.C0005a.C0009c.RIGHT
            android.support.constraint.a.a.a$c r8 = android.support.constraint.p000a.p001a.C0005a.C0009c.LEFT
            goto L_0x012f
        L_0x0123:
            if (r15 == r13) goto L_0x0137
            android.support.constraint.a.a.b r7 = r0.m0a(r15)
            if (r7 == 0) goto L_0x0137
            android.support.constraint.a.a.a$c r6 = android.support.constraint.p000a.p001a.C0005a.C0009c.RIGHT
            android.support.constraint.a.a.a$c r8 = android.support.constraint.p000a.p001a.C0005a.C0009c.RIGHT
        L_0x012f:
            int r9 = r12.rightMargin
            r5 = r11
            r10 = r16
            r5.mo74a(r6, r7, r8, r9, r10)
        L_0x0137:
            int r4 = r12.f43h
            if (r4 == r13) goto L_0x0148
            int r4 = r12.f43h
            android.support.constraint.a.a.b r7 = r0.m0a(r4)
            if (r7 == 0) goto L_0x0160
            android.support.constraint.a.a.a$c r6 = android.support.constraint.p000a.p001a.C0005a.C0009c.TOP
            android.support.constraint.a.a.a$c r8 = android.support.constraint.p000a.p001a.C0005a.C0009c.TOP
            goto L_0x0158
        L_0x0148:
            int r4 = r12.f44i
            if (r4 == r13) goto L_0x0160
            int r4 = r12.f44i
            android.support.constraint.a.a.b r7 = r0.m0a(r4)
            if (r7 == 0) goto L_0x0160
            android.support.constraint.a.a.a$c r6 = android.support.constraint.p000a.p001a.C0005a.C0009c.TOP
            android.support.constraint.a.a.a$c r8 = android.support.constraint.p000a.p001a.C0005a.C0009c.BOTTOM
        L_0x0158:
            int r9 = r12.topMargin
            int r10 = r12.f53r
            r5 = r11
            r5.mo74a(r6, r7, r8, r9, r10)
        L_0x0160:
            int r4 = r12.f45j
            if (r4 == r13) goto L_0x0171
            int r4 = r12.f45j
            android.support.constraint.a.a.b r7 = r0.m0a(r4)
            if (r7 == 0) goto L_0x0189
            android.support.constraint.a.a.a$c r6 = android.support.constraint.p000a.p001a.C0005a.C0009c.BOTTOM
            android.support.constraint.a.a.a$c r8 = android.support.constraint.p000a.p001a.C0005a.C0009c.TOP
            goto L_0x0181
        L_0x0171:
            int r4 = r12.f46k
            if (r4 == r13) goto L_0x0189
            int r4 = r12.f46k
            android.support.constraint.a.a.b r7 = r0.m0a(r4)
            if (r7 == 0) goto L_0x0189
            android.support.constraint.a.a.a$c r6 = android.support.constraint.p000a.p001a.C0005a.C0009c.BOTTOM
            android.support.constraint.a.a.a$c r8 = android.support.constraint.p000a.p001a.C0005a.C0009c.BOTTOM
        L_0x0181:
            int r9 = r12.bottomMargin
            int r10 = r12.f55t
            r5 = r11
            r5.mo74a(r6, r7, r8, r9, r10)
        L_0x0189:
            int r4 = r12.f47l
            if (r4 == r13) goto L_0x01df
            android.util.SparseArray<android.view.View> r4 = r0.f0a
            int r5 = r12.f47l
            java.lang.Object r4 = r4.get(r5)
            android.view.View r4 = (android.view.View) r4
            int r5 = r12.f47l
            android.support.constraint.a.a.b r5 = r0.m0a(r5)
            if (r5 == 0) goto L_0x01df
            if (r4 == 0) goto L_0x01df
            android.view.ViewGroup$LayoutParams r6 = r4.getLayoutParams()
            boolean r6 = r6 instanceof android.support.constraint.ConstraintLayout.C0000a
            if (r6 == 0) goto L_0x01df
            android.view.ViewGroup$LayoutParams r4 = r4.getLayoutParams()
            android.support.constraint.ConstraintLayout$a r4 = (android.support.constraint.ConstraintLayout.C0000a) r4
            r6 = 1
            r12.f26Q = r6
            r4.f26Q = r6
            android.support.constraint.a.a.a$c r4 = android.support.constraint.p000a.p001a.C0005a.C0009c.BASELINE
            android.support.constraint.a.a.a r17 = r11.mo67a(r4)
            android.support.constraint.a.a.a$c r4 = android.support.constraint.p000a.p001a.C0005a.C0009c.BASELINE
            android.support.constraint.a.a.a r18 = r5.mo67a(r4)
            r19 = 0
            r20 = -1
            android.support.constraint.a.a.a$b r21 = android.support.constraint.p000a.p001a.C0005a.C0008b.STRONG
            r22 = 0
            r23 = 1
            r17.mo52a(r18, r19, r20, r21, r22, r23)
            android.support.constraint.a.a.a$c r4 = android.support.constraint.p000a.p001a.C0005a.C0009c.TOP
            android.support.constraint.a.a.a r4 = r11.mo67a(r4)
            r4.mo61i()
            android.support.constraint.a.a.a$c r4 = android.support.constraint.p000a.p001a.C0005a.C0009c.BOTTOM
            android.support.constraint.a.a.a r4 = r11.mo67a(r4)
            r4.mo61i()
        L_0x01df:
            r4 = 0
            int r5 = (r2 > r4 ? 1 : (r2 == r4 ? 0 : -1))
            r6 = 1056964608(0x3f000000, float:0.5)
            if (r5 < 0) goto L_0x01ed
            int r5 = (r2 > r6 ? 1 : (r2 == r6 ? 0 : -1))
            if (r5 == 0) goto L_0x01ed
            r11.mo69a(r2)
        L_0x01ed:
            float r2 = r12.f59x
            int r2 = (r2 > r4 ? 1 : (r2 == r4 ? 0 : -1))
            if (r2 < 0) goto L_0x01fe
            float r2 = r12.f59x
            int r2 = (r2 > r6 ? 1 : (r2 == r6 ? 0 : -1))
            if (r2 == 0) goto L_0x01fe
            float r2 = r12.f59x
            r11.mo81b(r2)
        L_0x01fe:
            boolean r2 = r24.isInEditMode()
            if (r2 == 0) goto L_0x0213
            int r2 = r12.f21L
            if (r2 != r13) goto L_0x020c
            int r2 = r12.f22M
            if (r2 == r13) goto L_0x0213
        L_0x020c:
            int r2 = r12.f21L
            int r4 = r12.f22M
            r11.mo71a(r2, r4)
        L_0x0213:
            boolean r2 = r12.f24O
            if (r2 != 0) goto L_0x023c
            int r2 = r12.width
            if (r2 != r13) goto L_0x0235
            android.support.constraint.a.a.b$a r2 = android.support.constraint.p000a.p001a.C0010b.C0012a.MATCH_PARENT
            r11.mo75a(r2)
            android.support.constraint.a.a.a$c r2 = android.support.constraint.p000a.p001a.C0005a.C0009c.LEFT
            android.support.constraint.a.a.a r2 = r11.mo67a(r2)
            int r4 = r12.leftMargin
            r2.f140d = r4
            android.support.constraint.a.a.a$c r2 = android.support.constraint.p000a.p001a.C0005a.C0009c.RIGHT
            android.support.constraint.a.a.a r2 = r11.mo67a(r2)
            int r4 = r12.rightMargin
            r2.f140d = r4
            goto L_0x0246
        L_0x0235:
            android.support.constraint.a.a.b$a r2 = android.support.constraint.p000a.p001a.C0010b.C0012a.MATCH_CONSTRAINT
            r11.mo75a(r2)
            r2 = 0
            goto L_0x0243
        L_0x023c:
            android.support.constraint.a.a.b$a r2 = android.support.constraint.p000a.p001a.C0010b.C0012a.FIXED
            r11.mo75a(r2)
            int r2 = r12.width
        L_0x0243:
            r11.mo94d(r2)
        L_0x0246:
            boolean r2 = r12.f25P
            if (r2 != 0) goto L_0x0273
            int r2 = r12.height
            if (r2 != r13) goto L_0x0269
            android.support.constraint.a.a.b$a r2 = android.support.constraint.p000a.p001a.C0010b.C0012a.MATCH_PARENT
            r11.mo85b(r2)
            android.support.constraint.a.a.a$c r2 = android.support.constraint.p000a.p001a.C0005a.C0009c.TOP
            android.support.constraint.a.a.a r2 = r11.mo67a(r2)
            int r4 = r12.topMargin
            r2.f140d = r4
            android.support.constraint.a.a.a$c r2 = android.support.constraint.p000a.p001a.C0005a.C0009c.BOTTOM
            android.support.constraint.a.a.a r2 = r11.mo67a(r2)
            int r4 = r12.bottomMargin
            r2.f140d = r4
            r2 = 0
            goto L_0x027e
        L_0x0269:
            android.support.constraint.a.a.b$a r2 = android.support.constraint.p000a.p001a.C0010b.C0012a.MATCH_CONSTRAINT
            r11.mo85b(r2)
            r2 = 0
            r11.mo97e(r2)
            goto L_0x027e
        L_0x0273:
            r2 = 0
            android.support.constraint.a.a.b$a r4 = android.support.constraint.p000a.p001a.C0010b.C0012a.FIXED
            r11.mo85b(r4)
            int r4 = r12.height
            r11.mo97e(r4)
        L_0x027e:
            java.lang.String r4 = r12.f60y
            if (r4 == 0) goto L_0x0287
            java.lang.String r4 = r12.f60y
            r11.mo80a(r4)
        L_0x0287:
            float r4 = r12.f11B
            r11.mo89c(r4)
            float r4 = r12.f12C
            r11.mo93d(r4)
            int r4 = r12.f13D
            r11.mo109k(r4)
            int r4 = r12.f14E
            r11.mo111l(r4)
            int r4 = r12.f15F
            int r5 = r12.f17H
            int r6 = r12.f19J
            r11.mo72a(r4, r5, r6)
            int r4 = r12.f16G
            int r5 = r12.f18I
            int r6 = r12.f20K
            r11.mo84b(r4, r5, r6)
        L_0x02ad:
            int r3 = r3 + 1
            goto L_0x0015
        L_0x02b1:
            return
        */
        throw new UnsupportedOperationException("Method not decompiled: android.support.constraint.ConstraintLayout.m6d():void");
    }

    /* renamed from: a */
    public C0000a generateLayoutParams(AttributeSet attributeSet) {
        return new C0000a(getContext(), attributeSet);
    }

    /* access modifiers changed from: protected */
    /* renamed from: a */
    public void mo2a() {
        this.f1b.mo129F();
    }

    public void addView(View view, int i, LayoutParams layoutParams) {
        super.addView(view, i, layoutParams);
        if (VERSION.SDK_INT < 14) {
            onViewAdded(view);
        }
    }

    /* access modifiers changed from: protected */
    /* renamed from: b */
    public C0000a generateDefaultLayoutParams() {
        return new C0000a(-2, -2);
    }

    /* access modifiers changed from: protected */
    public boolean checkLayoutParams(LayoutParams layoutParams) {
        return layoutParams instanceof C0000a;
    }

    /* access modifiers changed from: protected */
    public LayoutParams generateLayoutParams(LayoutParams layoutParams) {
        return new C0000a(layoutParams);
    }

    public int getMaxHeight() {
        return this.f6g;
    }

    public int getMaxWidth() {
        return this.f5f;
    }

    public int getMinHeight() {
        return this.f4e;
    }

    public int getMinWidth() {
        return this.f3d;
    }

    /* access modifiers changed from: protected */
    public void onLayout(boolean z, int i, int i2, int i3, int i4) {
        int childCount = getChildCount();
        boolean isInEditMode = isInEditMode();
        for (int i5 = 0; i5 < childCount; i5++) {
            View childAt = getChildAt(i5);
            C0000a aVar = (C0000a) childAt.getLayoutParams();
            if (childAt.getVisibility() != 8 || aVar.f27R || isInEditMode) {
                C0010b bVar = aVar.f35Z;
                int n = bVar.mo113n();
                int o = bVar.mo114o();
                childAt.layout(n, o, bVar.mo102h() + n, bVar.mo110l() + o);
            }
        }
    }

    /* access modifiers changed from: protected */
    public void onMeasure(int i, int i2) {
        int i3;
        int i4;
        int i5 = i;
        int i6 = i2;
        int paddingLeft = getPaddingLeft();
        int paddingTop = getPaddingTop();
        this.f1b.mo82b(paddingLeft);
        this.f1b.mo90c(paddingTop);
        m3b(i, i2);
        int i7 = 0;
        if (this.f7h) {
            this.f7h = false;
            m5c();
        }
        m2a(i, i2);
        if (getChildCount() > 0) {
            mo2a();
        }
        int size = this.f2c.size();
        int paddingBottom = paddingTop + getPaddingBottom();
        int paddingRight = paddingLeft + getPaddingRight();
        if (size > 0) {
            boolean z = this.f1b.mo65B() == C0012a.WRAP_CONTENT;
            boolean z2 = this.f1b.mo66C() == C0012a.WRAP_CONTENT;
            boolean z3 = false;
            i3 = 0;
            while (i7 < size) {
                C0010b bVar = (C0010b) this.f2c.get(i7);
                if (!(bVar instanceof C0014d)) {
                    View view = (View) bVar.mo124x();
                    if (!(view == null || view.getVisibility() == 8)) {
                        C0000a aVar = (C0000a) view.getLayoutParams();
                        i4 = size;
                        view.measure(aVar.width == -2 ? getChildMeasureSpec(i5, paddingRight, aVar.width) : MeasureSpec.makeMeasureSpec(bVar.mo102h(), 1073741824), aVar.height == -2 ? getChildMeasureSpec(i6, paddingBottom, aVar.height) : MeasureSpec.makeMeasureSpec(bVar.mo110l(), 1073741824));
                        int measuredWidth = view.getMeasuredWidth();
                        int measuredHeight = view.getMeasuredHeight();
                        if (measuredWidth != bVar.mo102h()) {
                            bVar.mo94d(measuredWidth);
                            if (z && bVar.mo119t() > this.f1b.mo102h()) {
                                this.f1b.mo94d(Math.max(this.f3d, bVar.mo119t() + bVar.mo67a(C0009c.RIGHT).mo56d()));
                            }
                            z3 = true;
                        }
                        if (measuredHeight != bVar.mo110l()) {
                            bVar.mo97e(measuredHeight);
                            if (z2 && bVar.mo121u() > this.f1b.mo110l()) {
                                this.f1b.mo97e(Math.max(this.f4e, bVar.mo121u() + bVar.mo67a(C0009c.BOTTOM).mo56d()));
                            }
                            z3 = true;
                        }
                        if (aVar.f26Q) {
                            int baseline = view.getBaseline();
                            if (!(baseline == -1 || baseline == bVar.mo123w())) {
                                bVar.mo107j(baseline);
                                z3 = true;
                            }
                        }
                        if (VERSION.SDK_INT >= 11) {
                            i3 = combineMeasuredStates(i3, view.getMeasuredState());
                        }
                        i7++;
                        size = i4;
                    }
                }
                i4 = size;
                i7++;
                size = i4;
            }
            if (z3) {
                mo2a();
            }
        } else {
            i3 = 0;
        }
        int h = this.f1b.mo102h() + paddingRight;
        int l = this.f1b.mo110l() + paddingBottom;
        if (VERSION.SDK_INT >= 11) {
            int min = Math.min(this.f5f, resolveSizeAndState(h, i5, i3)) & 16777215;
            int min2 = Math.min(this.f6g, resolveSizeAndState(l, i6, i3 << 16)) & 16777215;
            if (this.f1b.mo127D()) {
                min |= 16777216;
            }
            if (this.f1b.mo128E()) {
                min2 |= 16777216;
            }
            setMeasuredDimension(min, min2);
            return;
        }
        setMeasuredDimension(h, l);
    }

    public void onViewAdded(View view) {
        if (VERSION.SDK_INT >= 14) {
            super.onViewAdded(view);
        }
        C0010b a = m1a(view);
        if ((view instanceof C0030b) && !(a instanceof C0014d)) {
            C0000a aVar = (C0000a) view.getLayoutParams();
            aVar.f35Z = new C0014d();
            aVar.f27R = true;
            ((C0014d) aVar.f35Z).mo142m(aVar.f23N);
            C0010b bVar = aVar.f35Z;
        }
        this.f0a.put(view.getId(), view);
        this.f7h = true;
    }

    public void onViewRemoved(View view) {
        if (VERSION.SDK_INT >= 14) {
            super.onViewRemoved(view);
        }
        this.f0a.remove(view.getId());
        this.f1b.mo152c(m1a(view));
        this.f7h = true;
    }

    public void removeView(View view) {
        super.removeView(view);
        if (VERSION.SDK_INT < 14) {
            onViewRemoved(view);
        }
    }

    public void requestLayout() {
        super.requestLayout();
        this.f7h = true;
    }

    public void setConstraintSet(C0001a aVar) {
        this.f9j = aVar;
    }

    public void setId(int i) {
        this.f0a.remove(getId());
        super.setId(i);
        this.f0a.put(getId(), this);
    }

    public void setMaxHeight(int i) {
        if (i != this.f6g) {
            this.f6g = i;
            requestLayout();
        }
    }

    public void setMaxWidth(int i) {
        if (i != this.f5f) {
            this.f5f = i;
            requestLayout();
        }
    }

    public void setMinHeight(int i) {
        if (i != this.f4e) {
            this.f4e = i;
            requestLayout();
        }
    }

    public void setMinWidth(int i) {
        if (i != this.f3d) {
            this.f3d = i;
            requestLayout();
        }
    }

    public void setOptimizationLevel(int i) {
        this.f1b.mo137m(i);
    }
}
