package android.support.constraint;

import android.content.Context;
import android.graphics.Canvas;
import android.view.View;

/* renamed from: android.support.constraint.b */
public class C0030b extends View {
    public C0030b(Context context) {
        super(context);
        super.setVisibility(8);
    }

    public void draw(Canvas canvas) {
    }

    /* access modifiers changed from: protected */
    public void onMeasure(int i, int i2) {
        setMeasuredDimension(0, 0);
    }

    public void setVisibility(int i) {
    }
}
