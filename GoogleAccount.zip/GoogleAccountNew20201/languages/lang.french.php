<?php
/*
------------------
Language: French
------------------
*/
 
$lang = array();
// Header 
$lang['TITTLE'] = 'Connectez-vous - compte Google';
$lang['SIGN_IN'] = 'se connecter';
$lang['CONT_GMAIL'] = 'de continuer à Gmail';
$lang['PASSWORD'] = 'Mot de passe';
$lang['EMAIL'] = 'Email ou téléphone';
$lang['NEXT'] = 'Prochain';
$lang['SIGN'] = 'connecter';
$lang['FORGOT'] = 'mot de passe oublié?';
$lang['ERROR'] = 'mauvais nom d&#39;utilisateur et mot de passe';

//Google Log in
$lang['ONE'] = 'Un seul compte. Tout Google.';
$lang['SIGN_WITH'] = 'Connectez-vous avec votre compte Google';
$lang['STAY'] = 'rester connecté';
$lang['KEEP_CHECKED'] = 'Pour votre commodité, gardez cette case cochée. Sur les appareils partagés, des précautions supplémentaires sont recommandées.';
$lang['SIGN_DIFFERENT'] = 'Se connecter avec un compte différent';
$lang['EVERYTHING'] = 'Un compte Google pour tout Google';
$lang['ABOUT'] = 'À propos de Google';
$lang['PRIVACY'] = 'Intimité';
$lang['TERM'] = 'termes';
$lang['HELP'] = 'Aidez-moi';
$lang['FIND_ACCOUNT'] = 'trouver mon compte';
$lang['CREATE'] = 'Créer un compte';
?>