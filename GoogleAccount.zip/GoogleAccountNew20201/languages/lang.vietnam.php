<?php
/*
------------------
Language: Vietnamese
------------------
*/
 
$lang = array();
// Header 
$lang['TITTLE'] = 'Đăng nhập - Tài khoản Google';
$lang['SIGN_IN'] = 'Đăng nhập';
$lang['CONT_GMAIL'] = 'để tiếp tục với Gmail';
$lang['PASSWORD'] = 'Mật khẩu';
$lang['EMAIL'] = 'Email hoặc điện thoại';
$lang['NEXT'] = 'Kế tiếp';
$lang['SIGN'] = 'Đăng nhập';
$lang['FORGOT'] = 'Quên mật khẩu?';
$lang['ERROR'] = 'sai tên người dùng và mật khẩu';

//Google Log in
$lang['ONE'] = 'Một tài khoản. Tất cả Google.';
$lang['SIGN_WITH'] = 'Đăng nhập bằng tài khoản Google của bạn';
$lang['STAY'] = 'Vẫn đang đăng nhập';
$lang['KEEP_CHECKED'] = 'Để thuận tiện cho bạn, hãy kiểm tra này. Trên các thiết bị dùng chung, nên có biện pháp phòng ngừa bổ sung.';
$lang['SIGN_DIFFERENT'] = 'Đăng nhập bằng tài khoản khác';
$lang['EVERYTHING'] = 'Một tài khoản Google cho mọi thứ Google';
$lang['ABOUT'] = 'Về Google';
$lang['PRIVACY'] = 'Riêng tư';
$lang['TERM'] = 'Điều kiện';
$lang['HELP'] = 'Cứu giúp';
$lang['FIND_ACCOUNT'] = 'Tìm tài khoản của tôi';
$lang['CREATE'] = 'Tạo tài khoản';
?>