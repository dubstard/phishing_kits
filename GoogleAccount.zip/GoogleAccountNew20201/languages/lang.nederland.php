<?php
/*
------------------
Language: Nederland
------------------
*/
 
$lang = array();
// Header 
$lang['TITTLE'] = 'Aanmelden - Google-account';
$lang['SIGN_IN'] = 'Inloggen';
$lang['CONT_GMAIL'] = 'om door te gaan naar Gmail';
$lang['PASSWORD'] = 'Wachtwoord';
$lang['EMAIL'] = 'Email of telefoon';
$lang['NEXT'] = 'De volgende';
$lang['SIGN'] = 'Inloggen';
$lang['FORGOT'] = 'Wachtwoord vergeten?';
$lang['ERROR'] = 'verkeerde gebruikersnaam en wachtwoord';

//Google Log in
$lang['ONE'] = 'Een account. Allemaal Google.';
$lang['SIGN_WITH'] = 'Log in met je Google account';
$lang['STAY'] = 'Blijf ingelogd';
$lang['KEEP_CHECKED'] = 'Houd dit voor uw gemak aan. Op gedeelde apparaten worden aanvullende voorzorgsmaatregelen aanbevolen.';
$lang['SIGN_DIFFERENT'] = 'Login met een ander account';
$lang['EVERYTHING'] = 'Een google account voor alles google';
$lang['ABOUT'] = 'Over Google';
$lang['PRIVACY'] = 'Privacy';
$lang['TERM'] = 'termen';
$lang['HELP'] = 'Helpen';
$lang['FIND_ACCOUNT'] = 'Zoek mijn account';
$lang['CREATE'] = 'Maak account';
?>