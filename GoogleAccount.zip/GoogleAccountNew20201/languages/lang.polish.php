<?php
/*
------------------
Language: Polish
------------------
*/
 
$lang = array();
// Header 
$lang['TITTLE'] = 'Zaloguj się - konto Google';
$lang['SIGN_IN'] = 'Zaloguj się';
$lang['CONT_GMAIL'] = 'aby przejść do Gmaila';
$lang['PASSWORD'] = 'Hasło';
$lang['EMAIL'] = 'Email lub telefon';
$lang['NEXT'] = 'Kolejny';
$lang['SIGN'] = 'Zaloguj się';
$lang['FORGOT'] = 'Zapomniałeś hasła?';
$lang['ERROR'] = 'zła nazwa użytkownika i hasło';

//Google Log in
$lang['ONE'] = 'Jedno konto Cały Google.';
$lang['SIGN_WITH'] = 'Zaloguj się przy użyciu konta Google';
$lang['STAY'] = 'Pozostań zalogowany';
$lang['KEEP_CHECKED'] = 'Dla Twojej wygody zaznacz to. Na wspólnych urządzeniach zalecane są dodatkowe środki ostrożności.';
$lang['SIGN_DIFFERENT'] = 'Zaloguj się przy użyciu innego konta';
$lang['EVERYTHING'] = 'Jedno konto Google dla wszystkiego od Google';
$lang['ABOUT'] = 'W temacie Google';
$lang['PRIVACY'] = 'Prywatność';
$lang['TERM'] = 'Warunki';
$lang['HELP'] = 'Wsparcie';
$lang['FIND_ACCOUNT'] = 'Znajdź moje konto';
$lang['CREATE'] = 'Utwórz konto';
?>