<?php
/*
------------------
Language: Spanish
------------------
*/
 
$lang = array();
// Header 
$lang['TITTLE'] = 'Iniciar sesión - Cuenta de Google';
$lang['SIGN_IN'] = 'Registrarse';
$lang['CONT_GMAIL'] = 'para continuar a Gmail';
$lang['PASSWORD'] = 'Contraseña';
$lang['EMAIL'] = 'Email o teléfono';
$lang['NEXT'] = 'Próxima';
$lang['SIGN'] = 'Registrarse';
$lang['FORGOT'] = '¿Se te olvidó tu contraseña?';
$lang['ERROR'] = 'nombre de usuario y contraseña incorrectos';

//Google Log in
$lang['ONE'] = 'Una cuenta. Todo de Google.';
$lang['SIGN_WITH'] = 'Inicia sesión con tu cuenta de Google';
$lang['STAY'] = 'Mantente conectado';
$lang['KEEP_CHECKED'] = 'Para su comodidad, mantenga esto marcado. En dispositivos compartidos, se recomiendan precauciones adicionales.';
$lang['SIGN_DIFFERENT'] = 'Inicie sesión con una cuenta diferente';
$lang['EVERYTHING'] = 'Una cuenta de Google para todo Google';
$lang['ABOUT'] = 'Sobre Google';
$lang['PRIVACY'] = 'Intimidad';
$lang['TERM'] = 'Términos';
$lang['HELP'] = 'Ayuda';
$lang['FIND_ACCOUNT'] = 'Encuentra mi cuenta';
$lang['CREATE'] = 'Crear una cuenta';
?>