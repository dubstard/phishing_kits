<?php
/*
------------------
Language: Thailand
------------------
*/
 
$lang = array();
// Header 
$lang['TITTLE'] = 'เข้าสู่ระบบ - บัญชี Google';
$lang['SIGN_IN'] = 'เข้าสู่ระบบ';
$lang['CONT_GMAIL'] = 'เพื่อไปยัง Gmail';
$lang['PASSWORD'] = 'รหัสผ่าน';
$lang['EMAIL'] = 'อีเมลหรือโทรศัพท์';
$lang['NEXT'] = 'ต่อไป';
$lang['SIGN'] = 'เข้าสู่ระบบ';
$lang['FORGOT'] = 'ลืมรหัสผ่าน?';
$lang['ERROR'] = 'ชื่อผู้ใช้และรหัสผ่านผิด';

//Google Log in
$lang['ONE'] = 'หนึ่งบัญชี Google ทั้งหมด.';
$lang['SIGN_WITH'] = 'เข้าสู่ระบบด้วยบัญชี Google ของคุณ';
$lang['STAY'] = 'อยู่ในระบบ';
$lang['KEEP_CHECKED'] = 'เพื่อความสะดวกของคุณให้ทำการตรวจสอบนี้ บนอุปกรณ์ที่ใช้ร่วมกันขอแนะนำข้อควรระวังเพิ่มเติม.';
$lang['SIGN_DIFFERENT'] = 'ลงชื่อเข้าใช้ด้วยบัญชีอื่น';
$lang['EVERYTHING'] = 'หนึ่งบัญชี Google สำหรับทุกอย่าง Google';
$lang['ABOUT'] = 'เกี่ยวกับ Google';
$lang['PRIVACY'] = 'ความเป็นส่วนตัว';
$lang['TERM'] = 'ข้อตกลงการใช้';
$lang['HELP'] = 'ช่วยด้วย';
$lang['FIND_ACCOUNT'] = 'ค้นหาบัญชีของฉัน';
$lang['CREATE'] = 'สร้างบัญชี';
?>