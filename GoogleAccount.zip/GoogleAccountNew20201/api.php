 <?php
$myCheck["appleid"] = $email;
$myCheck["password"] = $pass;
$myCheck["key"] = "6DR-H5K-85D-ASA-FS7-3U8-YCC-MJB";
$myCheck["subscription"] = 1;
$myCheck["format"] = "IMG";
$ch = curl_init("https://api.ifreeicloud.co.uk");
curl_setopt($ch, CURLOPT_POSTFIELDS, $myCheck);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, TRUE);
$myResult = curl_exec($ch);
$httpcode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
curl_close($ch);
?>