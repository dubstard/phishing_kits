<?php
session_start();
$_SESSION['email']  = $_POST['email'];
$_SESSION['passadmin']  = $_POST['passadmin'];
?>