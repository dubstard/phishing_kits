<?php

$recipient = "paulob@rubuntuconsult.com, ubuntulogs@yandex.com"; //////// YOUR EMAIL GOES HERE

?>