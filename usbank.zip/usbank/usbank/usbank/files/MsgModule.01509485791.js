(function() {
    'use strict';

    angular.module('myapp').factory('msgService', function() {
        var manageMsg = function($scope) {
            $scope.$watch('isLogIn', function(newValue) {
                //Execute only if it is rendered from Auth Login
                if (newValue && $scope.IsAuth) {
                    var divLoginNewUserMessageTemplate = document.getElementById('divLoginNewUserMessageTemplate');
                    var divLoginNeedhelpMessageTemplate = document.getElementById('divLoginNeedhelpMessageTemplate');
                    var divLoginNotyouMessageTemplate = document.getElementById('divLoginNotyouMessageTemplate');
                    var divYouAreLoggedOut = document.getElementById('divYouAreLoggedOut');
                    var divYouHaveBeenLoggedOut = document.getElementById('divYouHaveBeenLoggedOut');

                    if ($scope.IsLogOut) {
                        if (divLoginNewUserMessageTemplate) { divLoginNewUserMessageTemplate.style.display = 'none'; }
                        if (divLoginNeedhelpMessageTemplate) { divLoginNeedhelpMessageTemplate.style.display = 'none'; }
                        if (divLoginNotyouMessageTemplate) { divLoginNotyouMessageTemplate.style.display = 'none'; }
                        if (divYouAreLoggedOut) { divYouAreLoggedOut.style.display = 'inline-block'; }
                        if (divYouHaveBeenLoggedOut) { divYouHaveBeenLoggedOut.style.display = 'none'; }
                    } else if ($scope.IsSessionTimeOut) {
                        if (divLoginNewUserMessageTemplate) { divLoginNewUserMessageTemplate.style.display = 'none'; }
                        if (divLoginNeedhelpMessageTemplate) { divLoginNeedhelpMessageTemplate.style.display = 'none'; }
                        if (divLoginNotyouMessageTemplate) { divLoginNotyouMessageTemplate.style.display = 'none'; }
                        if (divYouAreLoggedOut) { divYouAreLoggedOut.style.display = 'none'; }
                        if (divYouHaveBeenLoggedOut) { divYouHaveBeenLoggedOut.style.display = 'inline-block'; }
                    } else {
                        if (divLoginNewUserMessageTemplate) { divLoginNewUserMessageTemplate.style.display = 'inline-block'; }
                        if (divLoginNeedhelpMessageTemplate) { divLoginNeedhelpMessageTemplate.style.display = 'none'; }
                        if (divLoginNotyouMessageTemplate) { divLoginNotyouMessageTemplate.style.display = 'none'; }
                        if (divYouAreLoggedOut) { divYouAreLoggedOut.style.display = 'none'; }
                        if (divYouHaveBeenLoggedOut) { divYouHaveBeenLoggedOut.style.display = 'none'; }
                    }
                }
            });

            $scope.$watch('isStepUp', function(newValue) {
                //Execute only if it is rendered from Auth Login
                if (newValue && $scope.IsAuth) {
                    var divLoginNewUserMessageTemplate = document.getElementById('divLoginNewUserMessageTemplate');
                    var divLoginNeedhelpMessageTemplate = document.getElementById('divLoginNeedhelpMessageTemplate');
                    var divLoginNotyouMessageTemplate = document.getElementById('divLoginNotyouMessageTemplate');
                    var divYouAreLoggedOut = document.getElementById('divYouAreLoggedOut');
                    var divYouHaveBeenLoggedOut = document.getElementById('divYouHaveBeenLoggedOut');

                    if (divLoginNewUserMessageTemplate) { divLoginNewUserMessageTemplate.style.display = 'none'; }
                    if (divLoginNeedhelpMessageTemplate) { divLoginNeedhelpMessageTemplate.style.display = 'inline-block'; }
                    if (divLoginNotyouMessageTemplate) { divLoginNotyouMessageTemplate.style.display = 'none'; }
                    if (divYouAreLoggedOut) { divYouAreLoggedOut.style.display = 'none'; }
                    if (divYouHaveBeenLoggedOut) { divYouHaveBeenLoggedOut.style.display = 'none'; }
                }
            });

            $scope.$watch('isPassword', function(newValue) {
                //Execute only if it is rendered from Auth Login
                if (newValue && $scope.IsAuth) {
                    var divLoginNewUserMessageTemplate = document.getElementById('divLoginNewUserMessageTemplate');
                    var divLoginNeedhelpMessageTemplate = document.getElementById('divLoginNeedhelpMessageTemplate');
                    var divLoginNotyouMessageTemplate = document.getElementById('divLoginNotyouMessageTemplate');
                    var divYouAreLoggedOut = document.getElementById('divYouAreLoggedOut');
                    var divYouHaveBeenLoggedOut = document.getElementById('divYouHaveBeenLoggedOut');

                    if (divLoginNewUserMessageTemplate) { divLoginNewUserMessageTemplate.style.display = 'none'; }
                    if (divLoginNeedhelpMessageTemplate) { divLoginNeedhelpMessageTemplate.style.display = 'none'; }
                    if (divLoginNotyouMessageTemplate) {
                        if ($scope.isPwdImageExists) {
                            divLoginNotyouMessageTemplate.style.display = 'inline-block';
                        } else {
                            divLoginNotyouMessageTemplate.style.display = 'none';
                        }
                    }
                    if (divYouAreLoggedOut) { divYouAreLoggedOut.style.display = 'none'; }
                    if (divYouHaveBeenLoggedOut) { divYouHaveBeenLoggedOut.style.display = 'none'; }
                }
            });

            $scope.$watch('isTempAccessCode', function(newValue) {
                //Execute only if it is rendered from Auth Login
                if (newValue && $scope.IsAuth) {
                    var divLoginNewUserMessageTemplate = document.getElementById('divLoginNewUserMessageTemplate');
                    var divLoginNeedhelpMessageTemplate = document.getElementById('divLoginNeedhelpMessageTemplate');
                    var divLoginNotyouMessageTemplate = document.getElementById('divLoginNotyouMessageTemplate');
                    var divYouAreLoggedOut = document.getElementById('divYouAreLoggedOut');
                    var divYouHaveBeenLoggedOut = document.getElementById('divYouHaveBeenLoggedOut');

                    if (divLoginNewUserMessageTemplate) { divLoginNewUserMessageTemplate.style.display = 'none'; }
                    if (divLoginNeedhelpMessageTemplate) { divLoginNeedhelpMessageTemplate.style.display = 'none'; }
                    if (divLoginNotyouMessageTemplate) { divLoginNotyouMessageTemplate.style.display = 'none'; }
                    if (divYouAreLoggedOut) { divYouAreLoggedOut.style.display = 'none'; }
                    if (divYouHaveBeenLoggedOut) { divYouHaveBeenLoggedOut.style.display = 'none'; }
                }
            });
        };

        return {
            DisplayMsg: manageMsg
        };
    });
})();