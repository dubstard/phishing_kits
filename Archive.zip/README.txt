Pearls! Simple Lightweight Questions/Answers Plateform
-------------------------------------------------------------------
* Installation :
- go to http://www.your-domain.com/pearls/install/ and follow instructions to get your script up and running in no time

* Documentation, Quick Start Guide :
- go to http://www.your-domain.com/pearls/guide/ and feel free to contact me on envato anytime =)

* Main Features:
- Full community plateform for posting, answering questions
- Users can follow questions, other users and feeds to get notified of the new posts
- Complete Like/Dislike engine, for upvoting questions to top of the page
- Complete admin section for moderating everything
- Full featured users privileges engine, for complete control over what users can see

* Basic settings:
- Enter admin section --> general settings to edit script title, description and other features

* Support:
- 6 months support included with every purchase, please contact me through codecanyon

* Update:
- backup all of your data first
- patch the new version in your pearls folder
- go to http://www.your-domain.com/pearls/install/update/ and follow instructions to get your script files and database updated in single click
-------------------------------------------------------------------
App developed by:

[ Michael Z. Johny ]
[ http://www.michael-designs.com ]
[ michael.zohney@gmail.com ]