<?php

/* Recipients, Supports multi values seperated by comma */
$recipients = array(
	"maro020199@yandex.com",
	);

?>