<?php

# HijaIyh Project.
/**
* HijaIyh Amazon v1.0
* @version 1.0
* @author shutdown57 < indonesianpeople.shutdown57@gmail.com >
* @copyright (c) HijaIyh Production 2019.
**/

//--++ basic blocker +--

if(preg_match("/bot|crawler|spider|aws|curl|slurp/",$_SERVER['HTTP_USER_AGENT']))
{
	file_put_contents(__DIR__.'/HijaIyh_App/stats/bot.hijaiyh.html','Block by basic bot',FILE_APPEND);
    header('HTTP/1.1 403 Forbidden');exit;
}




// named files.

$iyh['autoloader'] = 'autoloader.php';

$iyh['controller'] = 'AppControl.php';

$iyh['checker'] = 'AppCheck.php';

// named dir.

$iyh['app_path'] = 'HijaIyh_App/';


define('HADIR',__DIR__.DIRECTORY_SEPARATOR);




require_once(HADIR.$iyh['autoloader']);
require_once(HADIR.$iyh['app_path'].$iyh['controller']);
