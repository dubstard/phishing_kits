<?php
require_once 'paytabs.php';

$pt = new paytabs("gazee.tom@gmail.com", "P7TIvHC7F7dwsEMkjXsSjNMRMkQDa9AZhtHNbkVQs8nUMaf67IZrvLii58VfivfzZXnbii1KqpFdzVkHDj895qrbznrSTGsTDP4V");
$result = $pt->verify_payment($_POST['payment_reference']);
echo "<center><h1>" . $result->result . "</h1></center>";

?>