<?php
/*
------------------
Language: indonesia
------------------
*/
 
$lang = array();
// MiAccount
$lang['Mi_Account'] = 'Masuk ke Akun Mi Anda';
$lang['Verifying'] = 'verifikasi...';
$lang['TITTLE'] = 'Akun Mi - Masuk';
$lang['ACCOUNT'] = 'Email / Telepon / Akun Mi';
$lang['PASS'] = 'kata sandi';
$lang['SIGN'] = 'Masuk';
$lang['CREATE'] = 'Buat Akun';
$lang['FORGOT'] = 'Lupa kata sandi?';
$lang['OPTION'] = 'Opsi lanjutan';
$lang['LANGUAGES'] = 'Indonesia';
$lang['FAQ'] = 'Faq';
$lang['PRIVACY'] = 'Kebijakan pribadi';
$lang['COPYRIGHT'] = 'Xiaomi Inc., Hak cipta dilindungi undang-undang';
$lang['COOKIES'] = 'Situs web ini menggunakan cookie untuk menyimpan info di perangkat Anda. Cookie membantu situs web kami bekerja secara normal dan menunjukkan kepada kami bagaimana kami dapat meningkatkan pengalaman pengguna Anda. Dengan menggunakan situs web ini, Anda menyetujui kebijakan cookie kami.';
$lang['ATT'] = 'Perhatian';
$lang['AGREE'] = 'Setuju';

//
?>