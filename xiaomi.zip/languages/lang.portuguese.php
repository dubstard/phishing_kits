<?php
/*
------------------
Language: Portuguese
------------------
*/
 
$lang = array();
// MiAccount
$lang['Mi_Account'] = 'Faça o login em sua Conta Mi';
$lang['Verifying'] = 'Verificando...';
$lang['TITTLE'] = 'Conta Mi - Entrar';
$lang['ACCOUNT'] = 'E-mail / Telefone / Conta Mi';
$lang['PASS'] = 'Senha';
$lang['CREATE'] = 'Criar Conta';
$lang['FORGOT'] = 'Esqueceu a senha?';
$lang['OPTION'] = 'Mais opções';
$lang['SIGN'] = 'Fazer login';
$lang['LANGUAGES'] = 'Português(Brazil)';
$lang['FAQ'] = 'Perguntas frequentes';
$lang['PRIVACY'] = 'Política de Privacidade';
$lang['COPYRIGHT'] = 'Xiaomi Inc., todos os direitos reservados';
$lang['COOKIES'] = 'Este site usa cookies para armazenar informações no seu dispositivo. Os cookies ajudam nosso site a funcionar normalmente e nos mostram como podemos melhorar sua experiência de usuário. Ao usar este site, você concorda com nossa política de cookies.';
$lang['ATT'] = 'Atenção';
$lang['AGREE'] = 'Aceita';

//
?>