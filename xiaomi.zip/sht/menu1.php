					<ul class="nav">
						<li class="nav-item active">
							<button onclick="goBack()">Go Back To Dashboard</button>

<script>
function goBack() {
  window.history.back();
}
</script>
						</li>
					</ul>