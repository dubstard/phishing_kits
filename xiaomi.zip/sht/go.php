<?php

///// Include all functions /////

require_once 'function.inc.php';

/////////////////////////////////

redirect($_GET['id']);

?>
