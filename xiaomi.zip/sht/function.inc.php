<?php

// PHP4 workaround


////////////////////

////////////////////


/////////////////////

function getData($file) {
  $targetz = "../../store/$file";
  if(file_exists($targetz) && is_writable($targetz)) {
    $data = trim(file_get_contents($targetz));
    @list($array['url'],$array['date'], $array['count'], $array['last']) = explode(";", $data);
    if(!isset($array['date']))$array['date'] = "-";
    if(!isset($array['count']))$array['count'] = "-";
    if(!isset($array['last']))$array['last'] = "-";
    return $array;
  } else {
    return false;
  }
}

/////////////////////



/////////////////////



/////////////////////
function clickCount($shortcut, $array) {
  $counter = $array['count'];
  $counter = ($counter == "-" || $counter == "0") ? 1 : ++$counter;
  unlink("../.././store/$shortcut");
  addlinkmain($array['url'], $shortcut, $array['date'], $counter, $array['last']);
}
/////////////////////

function redirect($shortcut) {
  $array = getData($shortcut);
  if($array) {
    $destination = trim($array['url']);
  } else {
    $destination = (empty($conf['redirect'])) ? curPageURL() : $conf['redirect'];
  }
  header('HTTP/1.1 301 Moved Permanently');
  header("Location: $destination");
}

/////////////////////
function curPageURL() {
  $dirname = dirname($_SERVER["PHP_SELF"]);
  if(substr($dirname, -1)!=="/")$dirname .= "/";
  $o = 'https://'.$_SERVER["SERVER_NAME"].$dirname;
  return $o;
}
//////////////////////


//////////////////////


//////////////////////



//////////////////////

//////////////////////



//////////////////////



//////////////////////



//////////////////////

?>